﻿"""
Agentic AI Agent for 5G NR V2X SPS Optimization
Implements a true agentic system with autonomous reasoning, planning, and decision-making
"""

import json  # Added for JSON serialization in wrapper functions
import logging
import os
import pickle  # Added for checkpoint functionality
import random
import re
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Tuple, Optional

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
# LangChain 1.2.8 compatible imports
from langchain_core.tools import Tool
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
from langchain.agents import create_agent
from langchain_core.chat_history import InMemoryChatMessageHistory

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class NumpyEncoder(json.JSONEncoder):
    """Custom JSON encoder for numpy types"""
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return super().default(obj)


def to_json(obj, indent=None):
    """Convert object to JSON string with numpy support"""
    return json.dumps(obj, indent=indent, cls=NumpyEncoder)


class V2XEnvironment:
    """
    5G NR V2X Environment simulating SPS (Semi-Persistent Scheduling) mechanism
    """
    
    def __init__(self):
        # Core parameters set
        self.lambda_v = 0.5      # Vehicle arrival rate
        self.mu_v = 0.5          # Vehicle departure rate
        self.N_max = 9           # Maximum vehicle count
        self.L = 500             # Road length (meters)
        self.R_set = [20, 50, 100, 200, 300, 500, 1000]  # RRI candidate set (ms)
        self.n_RBG = 10          # Number of RBGs per RRI cycle
        self.T_slot = 0.5        # 5G NR slot length (ms)
        self.alpha_sps = 0.2     # SPS resource occupancy ratio
        self.p0 = 0.8            # Base resource retention probability
        self.q = 15              # Resource retention probability correction parameter 1
        self.p = 5               # Resource retention probability correction parameter 2
        self.eta_re_eval = 0.7   # SPS resource re-evaluation probability
        self.T_s = 2             # Basic transmission time (ms)
        self.T_c = 1             # Collision retransmission time (ms)
        self.T_sensing = 1000    # Vehicle sensing time (ms)
        self.w = 20              # Scheduling window size (slots)
        self.T = 1.0             # Observation interval (s)
        
        # Number of vehicles in the system
        self.num_vehicles = 5
        
        # Vehicle-specific parameters
        self.vehicle_positions = np.zeros(self.num_vehicles)  # Position of each vehicle
        self.vehicle_speeds = np.random.uniform(10, 30, self.num_vehicles)  # Speed of each vehicle (m/s)
        self.vehicle_mcs_levels = np.random.randint(0, 7, self.num_vehicles)  # MCS level of each vehicle
        
        # Agent-controlled vehicle (vehicle1, index 0)
        self.agent_controlled_vehicle_idx = 0
        
        # State variables
        self.history_states = []  # History of states
        self.current_state = {}   # Current state
        self.N_v = 0              # Current vehicle count
        self._config_signature = None
        self.fairness_mc_samples = 50  # Monte Carlo samples for expected fairness

        # Per-vehicle AoI state for fairness modeling (Plan B)
        self.aoi_per_vehicle = np.zeros(self.N_max, dtype=float)
        self.peak_paois = np.zeros(self.N_max, dtype=float)
        self.vehicle_quality = np.random.uniform(0.4, 1.6, self.N_max)
        self.fairness_mode = "global_peak"  # global_peak | window_peak | normalized_diff | cv_exp | entropy_fair | self_freshness | afumix | jsff_sps | paper_afu | paper_afu_sps | paper_afu_sps_norm
        self.fairness_window = 10
        self.aoi_history = [deque(maxlen=self.fairness_window) for _ in range(self.N_max)]
        self.fairness_k_cv = 6.0
        self.fairness_k_coll = 1.5
        self.fairness_entropy_gamma = 1.6
        self.fairness_entropy_eps = 1e-6
        self.fairness_k_self = 1.6
        self.fairness_k_f = 3.0
        self.fairness_k_a = 1.5
        self.fairness_aoi_ref = 1.0
        # Per-vehicle RRI (agent controls idx 0); others can change by policy:
        # other_rri_mode: random | fixed | sps | markov_pingpong
        self.rri_per_vehicle = np.full(self.N_max, 100.0, dtype=float)
        self.rri_change_prob = 0.3
        self.other_rri_mode = "random"
        self.other_rri_value = 100.0
        # Markov-style RRI transition for non-agent vehicles.
        # ps controls whether a vehicle moves to next state in the chain.
        self.other_rri_markov_states = [50.0, 100.0, 200.0]
        self.other_rri_markov_ps = 1.0
        # In SPS mode, ps gates whether re-evaluation can trigger state transition.
        # Effective reselect probability ~= ps * eta_re_eval * (1 - eta_keep).
        self.other_sps_ps = 1.0
        # If False, exogenous Markov transitions of other vehicles are not
        # double-counted in fairness reselect penalty (paper-ps alignment).
        self.markov_reselect_counts_in_rho = False
        self.other_markov_state_idx = np.zeros(self.N_max, dtype=int)
        self.other_markov_direction = np.ones(self.N_max, dtype=int)
        # SPS-like reservation counter for non-agent vehicles.
        self.other_sps_counter = np.zeros(self.N_max, dtype=int)
        # SPS dynamics coupling knobs for paper_afu_sps / paper_afu_sps_norm.
        self.fairness_sps_beta = 1.0
        self.fairness_sps_gamma = 1.0
        self.rri_reselect_rate = 0.0
        self.other_sps_counter = np.zeros(self.N_max, dtype=int)
        self.fairness_norm_alpha = 0.15
        self.fairness_norm_eps = 1e-6
        self.coll_ref_ema = 0.0
        self.rri_ref_ema = 0.0
        # Training control knobs
        self.enable_early_termination = True
        # Fairness is meaningful with at least 2 active users; default keeps legacy behavior.
        self.min_active_vehicles = 0
        # Initialization mechanism knobs (shared across scenarios when configured)
        # legacy: keep historical behavior
        # spread: all active vehicles sampled from the same AoI-scale interval
        self.init_aoi_mode = "legacy"
        self.init_aoi_scale_low = 0.6
        self.init_aoi_scale_high = 2.2
        # Legacy cold-start strength knobs (agent-vs-others split).
        # Defaults keep historical behavior unchanged.
        self.init_agent_aoi_scale_low = 1.6
        self.init_agent_aoi_scale_high = 2.2
        self.init_other_aoi_scale_low = 0.6
        self.init_other_aoi_scale_high = 1.1
        self.arrival_aoi_scale_low = 0.5
        self.arrival_aoi_scale_high = 1.5
        
        # Initialize environment
        self.reset()
    
    def reset(self) -> Dict:
        """
        Reset environment to initial state
        """
        # Sample initial vehicle count from stationary distribution of the
        # discrete-time birth-death process used by `_update_vehicle_count`.
        p_up = max(0.0, self.lambda_v * self.T)
        p_down = max(0.0, self.mu_v * self.T)
        if p_up + p_down > 1.0:
            scale = 1.0 / (p_up + p_down)
            p_up *= scale
            p_down *= scale
        if p_down <= 1e-12:
            sampled_n = self.N_max if p_up > 0 else 0
        elif p_up <= 1e-12:
            sampled_n = 0
        else:
            rho = p_up / p_down
            idx = np.arange(self.N_max + 1, dtype=float)
            if abs(rho - 1.0) < 1e-9:
                probs = np.ones(self.N_max + 1, dtype=float) / float(self.N_max + 1)
            else:
                weights = np.power(rho, idx)
                probs = weights / np.sum(weights)
            sampled_n = int(np.random.choice(np.arange(self.N_max + 1), p=probs))
        min_v = max(0, min(int(getattr(self, "min_active_vehicles", 0)), self.N_max))
        self.N_v = max(min_v, min(sampled_n, self.N_max))
        
        # Initialize vehicle positions and speeds
        for i in range(self.num_vehicles):
            self.vehicle_positions[i] = np.random.uniform(0, self.L)
            self.vehicle_speeds[i] = np.random.uniform(10, 30)
            self.vehicle_mcs_levels[i] = np.random.randint(0, 7)
        
        # Calculate initial system state with default RRI=100
        initial_state = self.calculate_system_state(RRI=100, N_v=self.N_v)

        # Initialize per-vehicle RRI, AoI and quality factors
        base_paoid = initial_state.get('PAoI', 0.0)
        baseline_rri = 100.0
        if self.R_set:
            baseline_rri = 100.0 if 100 in self.R_set else float(self.R_set[len(self.R_set) // 2])
        self.rri_per_vehicle = np.full(self.N_max, float(baseline_rri), dtype=float)
        self.other_markov_state_idx = np.zeros(self.N_max, dtype=int)
        self.other_markov_direction = np.ones(self.N_max, dtype=int)
        for i in range(self.N_v):
            if i == self.agent_controlled_vehicle_idx:
                self.rri_per_vehicle[i] = float(baseline_rri)
            else:
                other_mode = str(getattr(self, "other_rri_mode", "random"))
                other_value = float(getattr(self, "other_rri_value", baseline_rri))
                if other_mode == "fixed":
                    self.rri_per_vehicle[i] = float(other_value)
                elif other_mode == "markov_pingpong":
                    raw_states = getattr(self, "other_rri_markov_states", [50.0, 100.0, 200.0])
                    states = sorted({float(v) for v in raw_states if float(v) > 0.0})
                    if not states:
                        states = [float(baseline_rri)]
                    idx = int(random.randint(0, len(states) - 1))
                    direction = 1 if idx < len(states) - 1 else -1
                    self.other_markov_state_idx[i] = idx
                    self.other_markov_direction[i] = direction
                    self.rri_per_vehicle[i] = float(states[idx])
                else:
                    # random (default)
                    self.rri_per_vehicle[i] = float(random.choice(self.R_set)) if self.R_set else float(baseline_rri)
                # Initialize SPS reservation counter for non-agent vehicles.
                p_low = int(min(getattr(self, "p", 5), getattr(self, "q", 15)))
                p_high = int(max(getattr(self, "p", 5), getattr(self, "q", 15)))
                self.other_sps_counter[i] = random.randint(p_low, p_high) if p_high >= p_low else 1
        # Vehicle "quality" models heterogeneous collision vulnerability.
        # For MAC-only (no physical conditions), set `vehicle_quality_mode="constant"`.
        quality_mode = str(getattr(self, "vehicle_quality_mode", "uniform"))
        if quality_mode == "constant":
            self.vehicle_quality = np.ones(self.N_max, dtype=float)
        else:
            self.vehicle_quality = np.random.uniform(0.4, 1.6, self.N_max)
        self.aoi_per_vehicle = np.zeros(self.N_max, dtype=float)
        self.peak_paois = np.zeros(self.N_max, dtype=float)
        self.aoi_history = [deque(maxlen=self.fairness_window) for _ in range(self.N_max)]
        self.rri_reselect_rate = 0.0
        self.coll_ref_ema = 0.0
        self.rri_ref_ema = 0.0
        init_mode = str(getattr(self, "init_aoi_mode", "legacy"))
        init_low = float(getattr(self, "init_aoi_scale_low", 0.6))
        init_high = float(getattr(self, "init_aoi_scale_high", 2.2))
        if init_high < init_low:
            init_low, init_high = init_high, init_low
        agent_low = float(getattr(self, "init_agent_aoi_scale_low", 1.6))
        agent_high = float(getattr(self, "init_agent_aoi_scale_high", 2.2))
        other_low = float(getattr(self, "init_other_aoi_scale_low", 0.6))
        other_high = float(getattr(self, "init_other_aoi_scale_high", 1.1))
        if agent_high < agent_low:
            agent_low, agent_high = agent_high, agent_low
        if other_high < other_low:
            other_low, other_high = other_high, other_low

        for i in range(self.N_v):
            if init_mode == "spread":
                # Unified initialization: same distribution for all active vehicles.
                scale = np.random.uniform(init_low, init_high)
                self.aoi_per_vehicle[i] = base_paoid * scale
            else:
                # legacy mode: keep the historical initialization behavior.
                if i == self.agent_controlled_vehicle_idx:
                    self.aoi_per_vehicle[i] = base_paoid * np.random.uniform(agent_low, agent_high)
                else:
                    self.aoi_per_vehicle[i] = base_paoid * np.random.uniform(other_low, other_high)
            if not np.isfinite(self.aoi_per_vehicle[i]) or self.aoi_per_vehicle[i] < 1e-6:
                self.aoi_per_vehicle[i] = max(base_paoid, 1.0) * 0.1
            self.peak_paois[i] = self.aoi_per_vehicle[i]
            self.aoi_history[i].append(float(self.aoi_per_vehicle[i]))
        self.fairness_aoi_ref = float(base_paoid) if base_paoid > 0 else 1.0
        
        # Initialize current state and history
        self.current_state = initial_state
        self.history_states = [initial_state]
        self._config_signature = self._get_config_signature()
        
        return initial_state

    def _get_config_signature(self) -> Tuple:
        """Return a stable signature of environment parameters."""
        return (
            self.lambda_v,
            self.mu_v,
            self.N_max,
            self.L,
            tuple(self.R_set),
            self.n_RBG,
            self.T_slot,
            self.alpha_sps,
            self.p0,
            self.p,
            self.q,
            self.eta_re_eval,
            self.T_s,
            self.T_c,
            self.T_sensing,
            self.w,
            self.T,
            self.fairness_mc_samples,
            str(getattr(self, "vehicle_quality_mode", "uniform")),
            str(getattr(self, "rri_control_mode", "agent_only")),
            str(getattr(self, "other_rri_mode", "random")),
            float(getattr(self, "other_rri_value", 100.0)),
            tuple(getattr(self, "other_rri_markov_states", (50.0, 100.0, 200.0))),
            float(getattr(self, "other_rri_markov_ps", 1.0)),
            float(getattr(self, "other_sps_ps", 1.0)),
            str(getattr(self, "init_aoi_mode", "legacy")),
            float(getattr(self, "init_aoi_scale_low", 0.6)),
            float(getattr(self, "init_aoi_scale_high", 2.2)),
            float(getattr(self, "init_agent_aoi_scale_low", 1.6)),
            float(getattr(self, "init_agent_aoi_scale_high", 2.2)),
            float(getattr(self, "init_other_aoi_scale_low", 0.6)),
            float(getattr(self, "init_other_aoi_scale_high", 1.1)),
            float(getattr(self, "arrival_aoi_scale_low", 0.5)),
            float(getattr(self, "arrival_aoi_scale_high", 1.5)),
        )

    def sync_config(self) -> bool:
        """
        Reset environment if core parameters were modified externally.
        Returns True if a reset occurred.
        """
        current_sig = self._get_config_signature()
        if self._config_signature != current_sig:
            self.reset()
            return True
        return False
    
    def step(self, agent_mcs_action: int, rri_value: int = 100, force_reselect: Optional[bool] = None) -> Tuple[Dict, bool]:
        """
        Execute one simulation step with agent's action
        
        Args:
            agent_mcs_action: MCS action chosen by the agent for vehicle1
            rri_value: RRI value to use for calculations
            
        Returns:
            Tuple of (new_state, terminated_flag)
        """
        # Update agent-controlled vehicle's MCS level
        self.vehicle_mcs_levels[self.agent_controlled_vehicle_idx] = agent_mcs_action
        agent_idx = int(self.agent_controlled_vehicle_idx)
        prev_agent_rri = float(self.rri_per_vehicle[agent_idx]) if self.rri_per_vehicle.size > agent_idx else float(rri_value)
        if force_reselect is None:
            applied_rri = float(rri_value)
            agent_reselect_flag = bool(abs(applied_rri - prev_agent_rri) > 1e-9)
        elif bool(force_reselect):
            # Explicit reselect: apply chosen RRI immediately.
            applied_rri = float(rri_value)
            agent_reselect_flag = True
        else:
            # Keep policy: retain previously reserved resource/RRI.
            applied_rri = float(prev_agent_rri)
            agent_reselect_flag = False
        prev_n_for_rri = int(self.N_v)
        prev_rri_active = (
            np.array(self.rri_per_vehicle[:prev_n_for_rri], dtype=float).copy()
            if prev_n_for_rri > 0
            else np.array([], dtype=float)
        )
        
        # Update other vehicles based on preset probability models
        self._update_other_vehicles()
        # Update other vehicles' RRI stochastically unless system-wide RRI control is enabled.
        rri_control_mode = str(getattr(self, "rri_control_mode", "agent_only"))
        if rri_control_mode != "system_wide":
            self._update_other_rris(self.N_v)
        if self.rri_per_vehicle.shape[0] != self.N_max:
            self.rri_per_vehicle = np.full(self.N_max, float(rri_value), dtype=float)
        if rri_control_mode == "system_wide":
            self.rri_per_vehicle[: self.N_v] = float(applied_rri)
        else:
            self.rri_per_vehicle[self.agent_controlled_vehicle_idx] = float(applied_rri)
        
        # Update vehicle positions based on speeds
        self._update_vehicle_positions()
        
        # Update vehicle count dynamically
        prev_N_v = self.N_v
        delta_N = self._update_vehicle_count()
        min_v = max(0, min(int(getattr(self, "min_active_vehicles", 0)), self.N_max))
        new_N_v = max(min_v, min(self.N_v + delta_N, self.N_max))
        if new_N_v > prev_N_v:
            other_mode = str(getattr(self, "other_rri_mode", "random"))
            for i in range(prev_N_v, new_N_v):
                if other_mode == "markov_pingpong":
                    raw_states = getattr(self, "other_rri_markov_states", [50.0, 100.0, 200.0])
                    states = sorted({float(v) for v in raw_states if float(v) > 0.0})
                    if not states:
                        states = [float(rri_value)]
                    idx = int(random.randint(0, len(states) - 1))
                    direction = 1 if idx < len(states) - 1 else -1
                    self.other_markov_state_idx[i] = idx
                    self.other_markov_direction[i] = direction
                    self.rri_per_vehicle[i] = float(states[idx])
                else:
                    self.rri_per_vehicle[i] = float(random.choice(self.R_set)) if self.R_set else float(rri_value)
        elif new_N_v < prev_N_v:
            self.rri_per_vehicle[new_N_v:prev_N_v] = 0.0

        overlap_n = min(prev_n_for_rri, int(new_N_v))
        if overlap_n > 0:
            curr = np.array(self.rri_per_vehicle[:overlap_n], dtype=float)
            prev = prev_rri_active[:overlap_n]
            changed = np.abs(curr - prev) > 1e-9
            if overlap_n > agent_idx:
                changed[agent_idx] = bool(agent_reselect_flag)
            # In Markov-pingpong mode, transitions of other vehicles are
            # environment-driven (paper ps), so optionally exclude them from
            # the SPS reselect penalty term to avoid double penalization.
            if (
                str(getattr(self, "other_rri_mode", "random")) == "markov_pingpong"
                and not bool(getattr(self, "markov_reselect_counts_in_rho", False))
                and overlap_n > 1
            ):
                changed[1:overlap_n] = False
            self.rri_reselect_rate = float(np.mean(changed))
        else:
            self.rri_reselect_rate = 0.0
        
        # Calculate new system state
        new_state = self.calculate_system_state(RRI=applied_rri, N_v=new_N_v)
        # Update scenario-local EMA references used by normalized SPS fairness.
        alpha = float(getattr(self, "fairness_norm_alpha", 0.15))
        p_coll_now = float(new_state.get("P_coll", 0.0))
        rho_now = float(self.rri_reselect_rate)
        if self.coll_ref_ema <= 0.0:
            self.coll_ref_ema = p_coll_now
        else:
            self.coll_ref_ema = (1.0 - alpha) * float(self.coll_ref_ema) + alpha * p_coll_now
        if self.rri_ref_ema <= 0.0:
            self.rri_ref_ema = rho_now
        else:
            self.rri_ref_ema = (1.0 - alpha) * float(self.rri_ref_ema) + alpha * rho_now

        # Update per-vehicle AoI for fairness metrics (Plan B)
        prev_N_v = self.N_v
        self._update_vehicle_aoi(new_state, prev_N_v, new_N_v, int(applied_rri))
        new_state["rri_reselect_rate"] = float(self.rri_reselect_rate)
        new_state["agent_reselect"] = 1.0 if agent_reselect_flag else 0.0
        if new_N_v > 0:
            active_peaks = self.peak_paois[:new_N_v]
            new_state['AoI_avg'] = float(np.mean(active_peaks))
            new_state['AoI_max'] = float(np.max(active_peaks))
        else:
            new_state['AoI_avg'] = 0.0
            new_state['AoI_max'] = 0.0
        
        # Update state variables
        self.N_v = new_N_v
        self.current_state = new_state
        self.history_states.append(new_state)
        
        # Check termination condition
        terminated = self._check_termination()
        
        return new_state, terminated
    
    def _update_other_vehicles(self):
        """
        Update other vehicles based on preset probability models
        Following Markov/Non-Markov models as specified
        """
        # For other vehicles (not controlled by agent), update based on probability model
        for i in range(1, self.num_vehicles):  # Skip vehicle 0 (agent-controlled)
            # Markov model: with probability ps, switch to random MCS
            ps = 0.3  # Probability for switching
            if random.random() < ps:
                # Switch to random MCS
                self.vehicle_mcs_levels[i] = random.randint(0, 6)
            # Otherwise, keep current MCS (implicit)

    def _update_other_rris(self, active_n: Optional[int] = None) -> None:
        """
        Update other vehicles' RRIs stochastically (agent controls its own RRI).
        """
        mode = str(getattr(self, "other_rri_mode", "random"))
        if mode == "fixed":
            return
        n = self.N_v if active_n is None else int(active_n)
        if n <= 1 or not self.R_set:
            return
        if mode == "random":
            for i in range(1, n):
                if random.random() < self.rri_change_prob:
                    self.rri_per_vehicle[i] = float(random.choice(self.R_set))
            return

        # Paper-aligned Markov state transition over ordered RRI states:
        # s1 -> ... -> sk -> ... -> s1 (ping-pong), move with probability ps.
        if mode == "markov_pingpong":
            raw_states = getattr(self, "other_rri_markov_states", [50.0, 100.0, 200.0])
            states = sorted({float(v) for v in raw_states if float(v) > 0.0})
            if not states:
                states = [100.0]
            ps_trans = float(np.clip(getattr(self, "other_rri_markov_ps", 1.0), 0.0, 1.0))
            if self.other_markov_state_idx.shape[0] != self.N_max:
                self.other_markov_state_idx = np.zeros(self.N_max, dtype=int)
            if self.other_markov_direction.shape[0] != self.N_max:
                self.other_markov_direction = np.ones(self.N_max, dtype=int)

            for i in range(1, n):
                idx = int(self.other_markov_state_idx[i])
                if idx < 0 or idx >= len(states):
                    cur_rri = float(self.rri_per_vehicle[i])
                    idx = int(np.argmin(np.abs(np.array(states, dtype=float) - cur_rri)))
                direction = int(self.other_markov_direction[i])
                if direction == 0:
                    direction = 1

                if random.random() < ps_trans and len(states) > 1:
                    nxt = idx + (1 if direction > 0 else -1)
                    if nxt >= len(states):
                        nxt = len(states) - 2
                        direction = -1
                    elif nxt < 0:
                        nxt = 1
                        direction = 1
                    idx = int(nxt)

                self.other_markov_state_idx[i] = int(idx)
                self.other_markov_direction[i] = int(direction)
                self.rri_per_vehicle[i] = float(states[idx])
            return

        # SPS-like mode for other vehicles:
        # keep RRI while reservation counter is active; on expiry, decide keep/reselect.
        if mode == "sps":
            p_low = int(min(getattr(self, "p", 5), getattr(self, "q", 15)))
            p_high = int(max(getattr(self, "p", 5), getattr(self, "q", 15)))
            if p_high < p_low:
                p_low, p_high = 1, 1
            p_coll_prev = float(self.current_state.get("P_coll", 0.0)) if self.current_state else 0.0
            den = float(max(1, p_high - p_low + 1))
            p0 = float(getattr(self, "p0", 0.8))
            ps_gate = float(np.clip(getattr(self, "other_sps_ps", 1.0), 0.0, 1.0))
            # Same structure as eta in system model: better channel -> stronger keep tendency.
            eta_keep = p0 / den + (1.0 - 1.0 / den) * (1.0 - p_coll_prev)
            eta_keep = float(np.clip(eta_keep, 0.0, 1.0))
            eta_re_eval = float(np.clip(getattr(self, "eta_re_eval", 0.7), 0.0, 1.0))

            if self.other_sps_counter.shape[0] != self.N_max:
                self.other_sps_counter = np.zeros(self.N_max, dtype=int)

            for i in range(1, n):
                cnt = int(self.other_sps_counter[i])
                if cnt > 1:
                    self.other_sps_counter[i] = cnt - 1
                    continue

                # Reservation expires: optionally re-evaluate this SPS reservation.
                do_re_eval = bool(random.random() < eta_re_eval)
                # PS only gates transition opportunity when SPS reaches re-eval.
                if do_re_eval and (random.random() < ps_gate):
                    keep_current = bool(random.random() < eta_keep)
                else:
                    keep_current = True

                if not keep_current:
                    old = float(self.rri_per_vehicle[i])
                    candidates = [float(v) for v in self.R_set if abs(float(v) - old) > 1e-9]
                    if not candidates:
                        candidates = [float(v) for v in self.R_set]
                    self.rri_per_vehicle[i] = float(random.choice(candidates))

                self.other_sps_counter[i] = random.randint(p_low, p_high)
            return
    
    def _update_vehicle_positions(self):
        """
        Update vehicle positions based on their speeds
        """
        for i in range(self.num_vehicles):
            # Update position based on speed
            self.vehicle_positions[i] += self.vehicle_speeds[i] * (self.T_slot / 1000)  # Convert ms to seconds
            
            # Handle boundary conditions (wrap around road)
            if self.vehicle_positions[i] > self.L:
                self.vehicle_positions[i] %= self.L
    
    def _update_vehicle_count(self) -> int:
        """
        Update vehicle count based on birth-death process (Poisson arrival/departure)
        """
        # Discrete-time birth-death approximation with step T
        p_up = max(0.0, self.lambda_v * self.T)
        p_down = max(0.0, self.mu_v * self.T)

        if p_up + p_down > 1.0:
            scale = 1.0 / (p_up + p_down)
            p_up *= scale
            p_down *= scale

        p_stay = max(0.0, 1.0 - p_up - p_down)

        rand_val = random.random()
        if rand_val < p_down:
            return -1
        if rand_val < p_down + p_stay:
            return 0
        return 1

    def _update_vehicle_aoi(self, base_state: Dict, prev_N_v: int, new_N_v: int, rri_value: int) -> None:
        """
        Update per-vehicle AoI and peak PAoI for fairness (Plan B).
        Uses per-vehicle collision probability derived from base P_coll and
        persistent vehicle quality factors.
        """
        if self.aoi_per_vehicle.shape[0] != self.N_max:
            self.aoi_per_vehicle = np.zeros(self.N_max, dtype=float)
        if self.peak_paois.shape[0] != self.N_max:
            self.peak_paois = np.zeros(self.N_max, dtype=float)
        quality_mode = str(getattr(self, "vehicle_quality_mode", "uniform"))
        if self.vehicle_quality.shape[0] != self.N_max:
            if quality_mode == "constant":
                self.vehicle_quality = np.ones(self.N_max, dtype=float)
            else:
                self.vehicle_quality = np.random.uniform(0.4, 1.6, self.N_max)
        if self.rri_per_vehicle.shape[0] != self.N_max:
            self.rri_per_vehicle = np.full(self.N_max, float(rri_value), dtype=float)
        if self.other_markov_state_idx.shape[0] != self.N_max:
            self.other_markov_state_idx = np.zeros(self.N_max, dtype=int)
        if self.other_markov_direction.shape[0] != self.N_max:
            self.other_markov_direction = np.ones(self.N_max, dtype=int)
        if (
            not hasattr(self, "aoi_history")
            or len(self.aoi_history) != self.N_max
            or (self.aoi_history and self.aoi_history[0].maxlen != self.fairness_window)
        ):
            self.aoi_history = [deque(maxlen=self.fairness_window) for _ in range(self.N_max)]

        # Handle vehicle arrivals
        if new_N_v > prev_N_v:
            base_paoid = base_state.get('PAoI', 0.0)
            arr_low = float(getattr(self, "arrival_aoi_scale_low", 0.5))
            arr_high = float(getattr(self, "arrival_aoi_scale_high", 1.5))
            if arr_high < arr_low:
                arr_low, arr_high = arr_high, arr_low
            for i in range(prev_N_v, new_N_v):
                if quality_mode == "constant":
                    self.vehicle_quality[i] = 1.0
                else:
                    self.vehicle_quality[i] = np.random.uniform(0.4, 1.6)
                other_mode = str(getattr(self, "other_rri_mode", "random"))
                if other_mode == "markov_pingpong":
                    raw_states = getattr(self, "other_rri_markov_states", [50.0, 100.0, 200.0])
                    states = sorted({float(v) for v in raw_states if float(v) > 0.0})
                    if not states:
                        states = [float(rri_value)]
                    idx = int(random.randint(0, len(states) - 1))
                    direction = 1 if idx < len(states) - 1 else -1
                    self.other_markov_state_idx[i] = idx
                    self.other_markov_direction[i] = direction
                    self.rri_per_vehicle[i] = float(states[idx])
                elif self.R_set:
                    self.rri_per_vehicle[i] = float(random.choice(self.R_set))
                p_low = int(min(getattr(self, "p", 5), getattr(self, "q", 15)))
                p_high = int(max(getattr(self, "p", 5), getattr(self, "q", 15)))
                self.other_sps_counter[i] = random.randint(p_low, p_high) if p_high >= p_low else 1
                self.aoi_per_vehicle[i] = base_paoid * np.random.uniform(arr_low, arr_high)
                if not np.isfinite(self.aoi_per_vehicle[i]) or self.aoi_per_vehicle[i] < 1e-6:
                    self.aoi_per_vehicle[i] = max(base_paoid, 1.0) * 0.1
                self.peak_paois[i] = self.aoi_per_vehicle[i]
                self.aoi_history[i].clear()
                self.aoi_history[i].append(float(self.aoi_per_vehicle[i]))

        # Handle vehicle departures
        if new_N_v < prev_N_v:
            self.aoi_per_vehicle[new_N_v:] = 0.0
            self.peak_paois[new_N_v:] = 0.0
            self.other_sps_counter[new_N_v:] = 0
            self.other_markov_state_idx[new_N_v:] = 0
            self.other_markov_direction[new_N_v:] = 1
            for i in range(new_N_v, prev_N_v):
                self.aoi_history[i].clear()

        # Update active vehicles
        if new_N_v <= 0:
            return

        p_coll_base = float(base_state.get('P_coll', 0.0))

        for i in range(new_N_v):
            rri_i = float(self.rri_per_vehicle[i]) if i < len(self.rri_per_vehicle) else float(rri_value)
            reset_aoi = float(base_state.get('D_t', 0.0)) + 0.5 * rri_i
            # AoI increases with time since last successful update
            self.aoi_per_vehicle[i] += rri_i

            # Per-vehicle collision probability with persistent quality factor
            p_i = np.clip(p_coll_base * self.vehicle_quality[i], 0.0, 1.0)
            success = random.random() >= p_i
            if success:
                self.aoi_per_vehicle[i] = reset_aoi
            current_aoi = float(self.aoi_per_vehicle[i])
            self.peak_paois[i] = max(float(self.peak_paois[i]), current_aoi)
            self.aoi_history[i].append(current_aoi)
    
    def calculate_system_state(self, RRI: float, N_v: int) -> Dict:
        """
        Calculate system state based on 10 core formulas
        """
        # Effective RRI from per-vehicle RRIs (harmonic mean), if available
        RRI_eff = float(RRI)
        if N_v > 0 and hasattr(self, "rri_per_vehicle"):
            active_rris = np.array(self.rri_per_vehicle[:N_v], dtype=float)
            if active_rris.size:
                inv = float(np.sum(1.0 / np.clip(active_rris, 1e-6, None)))
                if inv > 0:
                    RRI_eff = float(N_v / inv)
        # Formula 1: Vehicle density calculation
        rho = N_v / self.L if self.L > 0 else 0
        
        # Formula 2: Competing vehicles count
        N_comp = N_v  # Assume all vehicles are in mutual sensing range
        
        # Formula 3: Available resource count calculation
        N_res = (RRI_eff * self.n_RBG) / self.T_slot if self.T_slot > 0 else 0
        
        # Formula 4: Collision probability calculation (binomial distribution approximation)
        if N_res > self.alpha_sps and N_comp > 1:
            P_coll = 1 - (1 - self.alpha_sps / N_res) ** (N_comp - 1)
        elif N_comp <= 1:
            P_coll = 0
        else:  # N_comp > 1 and N_res <= alpha_sps
            P_coll = 1
            
        # Ensure P_coll is within [0, 1]
        P_coll = max(0, min(P_coll, 1))
        
        # Formula 5: Resource retention probability eta
        denominator = self.q - self.p + 1
        if denominator == 0:
            eta = 0
        else:
            eta = self.p0 / denominator + (1 - 1 / denominator) * (1 - P_coll)
        
        # Formula 6: SPS failure probability
        P_fail_SPS = P_coll * (1 - self.eta_re_eval)
        
        # Formula 7: State probability pi_1
        denominator_pi1 = 2 - eta - P_fail_SPS
        if denominator_pi1 > 0:
            pi_1 = (1 - eta) / denominator_pi1
        else:
            pi_1 = 1
            
        # Formula 8: Transmission delay D_t
        if P_coll < 1:
            D_t = self.T_s + (self.T_c * P_coll) / (1 - P_coll)
        else:
            D_t = self.T_s + 3 * self.T_c
            
        # Formula 9: Queuing delay T_waiting
        T_waiting = self.T_sensing + (self.w * self.T_slot) / 2
        
        # Formula 10: Final PAoI
        PAoI = 1.5 * RRI_eff + pi_1 * T_waiting + D_t
        
        # Return system state as dictionary
        state = {
            'N_v': N_v,           # Vehicle count
            'rho': rho,           # Vehicle density
            'RRI': RRI,           # Agent's RRI choice
            'RRI_eff': RRI_eff,   # Effective RRI (harmonic mean across vehicles)
            'P_coll': P_coll,     # Collision probability
            'eta': eta,           # Resource retention probability
            'P_fail_SPS': P_fail_SPS,  # SPS failure probability
            'pi_1': pi_1,         # State probability
            'D_t': D_t,           # Transmission delay
            'T_waiting': T_waiting,  # Queuing delay
            'PAoI': PAoI,         # Peak Age of Information
            'vehicle_mcs_levels': self.vehicle_mcs_levels.tolist(),  # All vehicle MCS levels
            'agent_mcs_level': self.vehicle_mcs_levels[self.agent_controlled_vehicle_idx]  # Agent's MCS
        }
        
        return state
    
    def _check_termination(self) -> bool:
        """
        Check termination conditions
        """
        if not bool(getattr(self, "enable_early_termination", True)):
            return False
        # Condition 1: Less than 5 steps (not terminated)
        if len(self.history_states) < 6:
            return False
            
        # Condition 2: Check stability of recent 5 PAoI values
        if len(self.history_states) >= 6:
            recent_states = self.history_states[-5:]
            paoid_values = [state['PAoI'] for state in recent_states]
            
            paoid_max = max(paoid_values)
            paoid_min = min(paoid_values)
            delta_max = paoid_max - paoid_min
            avg_paoid = sum(paoid_values) / len(paoid_values)
            
            # If variation is less than 1% of average PAoI, terminate
            if avg_paoid > 0 and delta_max < 0.01 * avg_paoid:
                return True
                
        # Condition 3: Max steps reached (30 steps)
        if len(self.history_states) >= 30:
            return True
            
        return False
    
    def calculate_fairness_metrics(self, N_v: int, RRI: float) -> Dict:
        """
        Calculate fairness metrics based on per-vehicle PAoI (Plan B)
        """
        # Initialize return values for case N_v = 0
        if N_v <= 0:
            return {
                'individual_paoids': [],
                'avg_paoid': 0.0,
                'fairness_index': 1.0,
                'paoid_diff': 0.0
            }

        # Select per-vehicle AoI for fairness based on mode
        if self.fairness_mode == "window_peak":
            individual_paoids = []
            for i in range(N_v):
                hist = self.aoi_history[i] if i < len(self.aoi_history) else []
                if hist:
                    individual_paoids.append(float(max(hist)))
                else:
                    individual_paoids.append(float(self.aoi_per_vehicle[i]) if i < len(self.aoi_per_vehicle) else 0.0)
        elif self.fairness_mode in ("normalized_diff", "cv_exp", "entropy_fair", "self_freshness", "afumix", "jsff_sps", "paper_afu", "paper_afu_sps", "paper_afu_sps_norm"):
            individual_paoids = [float(self.aoi_per_vehicle[i]) for i in range(N_v)]
        else:
            # global_peak (default)
            if self.peak_paois is None or len(self.peak_paois) < N_v:
                base_state = self.calculate_system_state(RRI, N_v)
                individual_paoids = [float(base_state.get('PAoI', 0.0)) for _ in range(N_v)]
            else:
                active = self.peak_paois[:N_v]
                if np.all(active == 0):
                    base_state = self.calculate_system_state(RRI, N_v)
                    individual_paoids = [float(base_state.get('PAoI', 0.0)) for _ in range(N_v)]
                else:
                    individual_paoids = active.astype(float).tolist()

        avg_paoid = float(sum(individual_paoids) / N_v) if N_v > 0 else 0.0
        paoid_diff = float(max(individual_paoids) - min(individual_paoids)) if individual_paoids else 0.0

        # Fairness index
        if self.fairness_mode == "normalized_diff":
            v_max = max(individual_paoids) if individual_paoids else 0.0
            v_min = min(individual_paoids) if individual_paoids else 0.0
            fairness_index = float(1.0 - (v_max - v_min) / (v_max + 1e-6)) if v_max > 0 else 1.0
        elif self.fairness_mode == "cv_exp":
            vals = np.array(individual_paoids, dtype=float)
            mean_v = float(np.mean(vals)) if vals.size else 0.0
            std_v = float(np.std(vals)) if vals.size else 0.0
            cv = std_v / (mean_v + 1e-6) if mean_v > 0 else 0.0
            k_cv = float(getattr(self, "fairness_k_cv", 2.0))
            # Base CV fairness
            base_fair = float(np.exp(-k_cv * cv))
            # Couple fairness with collision probability to make it RRI-sensitive
            p_coll = float(self.current_state.get('P_coll', 0.0)) if self.current_state else 0.0
            k_coll = float(getattr(self, "fairness_k_coll", 1.5))
            coll_factor = float(np.exp(-k_coll * p_coll))
            fairness_index = float(base_fair * coll_factor)
        elif self.fairness_mode == "entropy_fair":
            vals = np.array(individual_paoids, dtype=float)
            eps = float(getattr(self, "fairness_entropy_eps", 1e-6))
            fresh = 1.0 / (vals + eps)
            total = float(np.sum(fresh))
            if total > 0:
                p = fresh / total
                h = float(-np.sum(p * np.log(p + eps)))
                h_max = float(np.log(len(p))) if len(p) > 1 else 1.0
                base = h / h_max if h_max > 0 else 1.0
            else:
                base = 1.0
            gamma = float(getattr(self, "fairness_entropy_gamma", 1.0))
            # Numerical guard: keep base within [0, 1] before applying gamma
            if not np.isfinite(base):
                base = 0.0
            base = max(0.0, min(1.0, base))
            base = float(base ** gamma)
            p_coll = float(self.current_state.get('P_coll', 0.0)) if self.current_state else 0.0
            k_coll = float(getattr(self, "fairness_k_coll", 1.5))
            fairness_index = float(base * np.exp(-k_coll * p_coll))
        elif self.fairness_mode == "self_freshness":
            idx = int(self.agent_controlled_vehicle_idx)
            eps = float(getattr(self, "fairness_entropy_eps", 1e-6))
            k_self = float(getattr(self, "fairness_k_self", 1.6))
            vals = np.array(individual_paoids, dtype=float)
            if vals.size == 0 or N_v <= 1:
                fairness_index = 1.0
            else:
                fresh = 1.0 / (vals + eps)
                fresh_self = float(fresh[idx]) if idx < len(fresh) else float(fresh[0])
                others = np.delete(fresh, idx) if len(fresh) > 1 else fresh
                mean_others = float(np.mean(others)) if others.size else fresh_self
                ratio = fresh_self / (mean_others + eps)
                base = float(np.exp(-k_self * abs(np.log(ratio))))
                p_coll = float(self.current_state.get('P_coll', 0.0)) if self.current_state else 0.0
                k_coll = float(getattr(self, "fairness_k_coll", 1.5))
                fairness_index = float(base * np.exp(-k_coll * p_coll))
        elif self.fairness_mode == "jsff_sps":
            # Jensen–Shannon Freshness Fairness with SPS collision penalty (F_SPS)
            # Steps:
            # 1) Smooth AoI per vehicle over a window to reduce noise
            # 2) Convert to freshness distribution p
            # 3) Compute JS divergence to uniform distribution u
            # 4) Fairness = 1 - JS_norm, then apply collision penalty
            eps = float(getattr(self, "fairness_js_eps", 1e-6))
            w = int(getattr(self, "fairness_js_window", 10))
            w = max(1, w)
            # Smooth AoI using history if available
            smooth_vals = []
            for i in range(N_v):
                hist = self.aoi_history[i] if i < len(self.aoi_history) else []
                if hist:
                    hist_seq = hist if isinstance(hist, list) else list(hist)
                    tail = hist_seq[-w:] if len(hist_seq) >= w else hist_seq
                    smooth_vals.append(float(np.mean(tail)))
                else:
                    smooth_vals.append(float(individual_paoids[i]) if i < len(individual_paoids) else 0.0)

            vals = np.array(smooth_vals, dtype=float)
            if vals.size == 0:
                fairness_index = 1.0
            else:
                fresh = 1.0 / (vals + eps)
                sum_f = float(np.sum(fresh))
                if sum_f > 0:
                    p = fresh / sum_f
                else:
                    p = np.ones(N_v, dtype=float) / float(N_v)

                u = np.ones(N_v, dtype=float) / float(N_v)
                m = 0.5 * (p + u)
                js = 0.5 * float(np.sum(p * np.log((p + eps) / (m + eps)))) + \
                     0.5 * float(np.sum(u * np.log((u + eps) / (m + eps))))
                js_norm = js / float(np.log(2.0)) if N_v > 1 else 0.0
                # Map small JS divergences to a wider dynamic range.
                # Default k_js chosen so that base=0.5 when js_norm≈0.05:
                # k_js = ln(2)/0.05 ≈ 13.86
                k_js = float(getattr(self, "fairness_js_k", 13.86))
                base = float(np.exp(-k_js * float(js_norm)))
                if not np.isfinite(base):
                    base = 0.0
                base = max(0.0, min(1.0, base))

                p_coll = float(self.current_state.get('P_coll', 0.0)) if self.current_state else 0.0
                k_coll = float(getattr(self, "fairness_k_coll", 1.0))
                fairness_index = float(base * np.exp(-k_coll * p_coll))
        elif self.fairness_mode == "paper_afu":
            # Paper-style age fairness utility:
            #   F_loss = |Delta0/(Delta0 + Delta_v_avg) - 1/N|
            #   U_f = 1 - F_loss
            idx = int(self.agent_controlled_vehicle_idx)
            vals = np.array(individual_paoids, dtype=float)
            if vals.size == 0 or N_v <= 1:
                fairness_index = 1.0
            else:
                idx = min(max(idx, 0), len(vals) - 1)
                a_self = float(vals[idx])
                others = np.delete(vals, idx) if len(vals) > 1 else vals
                a_others_avg = float(np.mean(others)) if others.size else a_self
                denom = a_self + a_others_avg
                ratio = (a_self / denom) if denom > 0 else 0.5
                ideal = 1.0 / float(N_v)
                fairness_index = float(1.0 - abs(ratio - ideal))
                fairness_index = max(0.0, min(1.0, fairness_index))
        elif self.fairness_mode == "paper_afu_sps":
            # Paper-style AFU with SPS dynamics penalty:
            # U = U_AFU * exp(-beta * P_coll - gamma * rho_rri)
            idx = int(self.agent_controlled_vehicle_idx)
            vals = np.array(individual_paoids, dtype=float)
            if vals.size == 0 or N_v <= 1:
                fairness_index = 1.0
            else:
                idx = min(max(idx, 0), len(vals) - 1)
                a_self = float(vals[idx])
                others = np.delete(vals, idx) if len(vals) > 1 else vals
                a_others_avg = float(np.mean(others)) if others.size else a_self
                denom = a_self + a_others_avg
                ratio = (a_self / denom) if denom > 0 else 0.5
                ideal = 1.0 / float(N_v)
                u_afu = float(1.0 - abs(ratio - ideal))
                u_afu = max(0.0, min(1.0, u_afu))
                p_coll = float(self.current_state.get('P_coll', 0.0)) if self.current_state else 0.0
                rho = float(getattr(self, "rri_reselect_rate", 0.0))
                beta = float(getattr(self, "fairness_sps_beta", 1.0))
                gamma = float(getattr(self, "fairness_sps_gamma", 1.0))
                fairness_index = float(u_afu * np.exp(-beta * p_coll - gamma * rho))
        elif self.fairness_mode == "paper_afu_sps_norm":
            # Paper-style AFU with normalized SPS dynamics penalty:
            # U = U_AFU * exp(-beta * z_coll - gamma * z_rri)
            # z terms are scenario-local normalized quantities via online EMA.
            idx = int(self.agent_controlled_vehicle_idx)
            vals = np.array(individual_paoids, dtype=float)
            if vals.size == 0 or N_v <= 1:
                fairness_index = 1.0
            else:
                idx = min(max(idx, 0), len(vals) - 1)
                a_self = float(vals[idx])
                others = np.delete(vals, idx) if len(vals) > 1 else vals
                a_others_avg = float(np.mean(others)) if others.size else a_self
                denom = a_self + a_others_avg
                ratio = (a_self / denom) if denom > 0 else 0.5
                ideal = 1.0 / float(N_v)
                u_afu = float(1.0 - abs(ratio - ideal))
                u_afu = max(0.0, min(1.0, u_afu))

                p_coll = float(self.current_state.get('P_coll', 0.0)) if self.current_state else 0.0
                rho = float(getattr(self, "rri_reselect_rate", 0.0))
                beta = float(getattr(self, "fairness_sps_beta", 1.0))
                gamma = float(getattr(self, "fairness_sps_gamma", 1.0))
                eps = float(getattr(self, "fairness_norm_eps", 1e-6))

                ref_coll = max(eps, float(getattr(self, "coll_ref_ema", 0.0)))
                ref_rri = max(eps, float(getattr(self, "rri_ref_ema", 0.0)))
                z_coll = float(np.tanh(p_coll / (ref_coll + eps)))
                z_rri = float(np.tanh(rho / (ref_rri + eps)))

                fairness_index = float(u_afu * np.exp(-beta * z_coll - gamma * z_rri))
                fairness_index = max(0.0, min(1.0, fairness_index))
        elif self.fairness_mode == "afumix":
            idx = int(self.agent_controlled_vehicle_idx)
            eps = float(getattr(self, "fairness_entropy_eps", 1e-6))
            k_f = float(getattr(self, "fairness_k_f", 3.0))
            k_a = float(getattr(self, "fairness_k_a", 1.5))
            if N_v <= 1:
                fairness_index = 1.0
            else:
                vals = np.array(individual_paoids, dtype=float)
                a_self = float(vals[idx]) if idx < len(vals) else float(vals[0])
                others = np.delete(vals, idx) if len(vals) > 1 else vals
                a_others_avg = float(np.mean(others)) if others.size else a_self
                denom = a_self + a_others_avg
                ratio = a_self / denom if denom > 0 else 0.5
                ideal = 1.0 / float(N_v)
                loss_f = abs(ratio - ideal)
                u_f = float(np.exp(-k_f * loss_f))
                a_avg = float(np.mean(vals)) if vals.size else a_self
                a_ref = float(getattr(self, "fairness_aoi_ref", a_avg))
                a_ref = a_ref if a_ref > 0 else (a_avg if a_avg > 0 else 1.0)
                u_a = float(1.0 / (1.0 + k_a * (a_avg / (a_ref + eps))))
                p_coll = float(self.current_state.get('P_coll', 0.0)) if self.current_state else 0.0
                k_coll = float(getattr(self, "fairness_k_coll", 1.0))
                u_c = float(np.exp(-k_coll * p_coll))
                fairness_index = float(u_f * u_a * u_c)
        else:
            # Jain's fairness index
            vals = np.array(individual_paoids, dtype=float)
            denom = N_v * np.sum(vals ** 2)
            if denom > 0:
                fairness_index = float((np.sum(vals) ** 2) / denom)
            else:
                fairness_index = 1.0

        return {
            'individual_paoids': individual_paoids,
            'avg_paoid': avg_paoid,
            'fairness_index': fairness_index,
            'paoid_diff': paoid_diff
        }


class SingleVehicleAgent:
    """
    Single agent that controls one specific vehicle (vehicle1) in V2X network
    Other vehicles follow preset probability models (Markov/Non-Markov)
    """
    
    def __init__(self, num_mcs_options: int = 7, agent_vehicle_idx: int = 0, use_raafu: bool = True):
        # Action space for agent-controlled vehicle
        self.action_space = list(range(num_mcs_options))  # [0,1,2,3,4,5,6]
        
        # Which vehicle this agent controls (typically vehicle1 = index 0)
        self.agent_vehicle_idx = agent_vehicle_idx
        
        # State space: [ak, ok, W0k, n] - 4 dimensional state vector
        self.state_dim = 4
        
        # Agent's learning parameters
        self.learning_rate = 0.1
        self.discount_factor = 0.9
        self.epsilon = 0.1  # Exploration rate
        self.use_raafu = use_raafu
        
        # Q-table for reinforcement learning
        self.q_table = defaultdict(lambda: defaultdict(float))
        
        # Environment parameters for other vehicles (not controlled by agent)
        self.ps = 0.3  # Probability for switching MCS in Markov model
        self.model_type = "Markov"  # "Markov" or "Non-Markov"
        
        # Performance tracking
        self.episode_rewards = []
        self.fairness_history = []
        # Reward weights (tunable for pilot experiments)
        self.reward_w_raafu = 0.60
        self.reward_w_raafu_delta = 0.20
        self.reward_w_fairness = 0.0
        self.reward_w_fairness_delta = 0.0
        self.reward_w_paoid_cost = 0.15
        self.reward_w_collision = 0.05
        self.reward_paoid_high_penalty = 0.5
        
    def set_model_type(self, model_type: str):
        """Set the model type (Markov or Non-Markov)"""
        self.model_type = model_type
    
    def get_state_key(self, state: List[float]) -> str:
        """Convert state to string key for Q-table"""
        # Discretize continuous state values for Q-learning
        discretized_state = [round(x, 1) for x in state]
        return str(discretized_state)
    
    def choose_action(self, state: List[float]) -> int:
        """
        Choose action based on current state using epsilon-greedy policy
        This is the agent's decision for the vehicle it controls (vehicle1)
        """
        state_key = self.get_state_key(state)
        
        # Epsilon-greedy exploration
        if random.random() < self.epsilon:
            # Explore: random action
            return random.choice(self.action_space)
        else:
            # Exploit: best known action
            q_values = {action: self.q_table[state_key][action] for action in self.action_space}
            if not q_values or all(v == 0 for v in q_values.values()):
                # If no learned values or all zeros, choose randomly
                return random.choice(self.action_space)
            else:
                # Choose action with maximum Q-value
                return max(q_values, key=q_values.get)
    
    def update_q_table(self, state: List[float], action: int, reward: float, next_state: List[float]):
        """
        Update Q-table using Q-learning algorithm
        """
        state_key = self.get_state_key(state)
        next_state_key = self.get_state_key(next_state)
        
        # Get current Q-value
        current_q = self.q_table[state_key][action]
        
        # Get max Q-value for next state
        next_q_values = {act: self.q_table[next_state_key][act] for act in self.action_space}
        max_next_q = max(next_q_values.values()) if next_q_values else 0
        
        # Calculate target
        target = reward + self.discount_factor * max_next_q
        
        # Update Q-value
        self.q_table[state_key][action] = current_q + self.learning_rate * (target - current_q)
    
    def calculate_reward(self, current_metrics: Dict, previous_metrics: Dict) -> float:
        """
        Calculate reward based on fairness principle
        Reward function computes the difference between actual communication share 
        and ideal fair share for minimizing the difference among vehicles
        """
        # Extract metrics
        current_avg_paoid = current_metrics.get('avg_paoid', 1.0)
        current_system_paoid = current_metrics.get('system_paoid', current_avg_paoid)
        current_fairness = current_metrics.get('fairness_index', 0.5)
        current_paoid_diff = current_metrics.get('paoid_diff', 100.0)
        current_collision = current_metrics.get('collision_prob', 0.0)
        
        previous_avg_paoid = previous_metrics.get('avg_paoid', 1.0)
        previous_system_paoid = previous_metrics.get('system_paoid', previous_avg_paoid)
        previous_fairness = previous_metrics.get('fairness_index', 0.5)
        previous_paoid_diff = previous_metrics.get('paoid_diff', 100.0)
        
        # R-AAFU-focused reward (targeting higher R-AAFU while constraining PAoI/collision)
        fairness_improvement = current_fairness - previous_fairness
        paoid_diff_improvement = -(current_paoid_diff - previous_paoid_diff)  # Negative because lower diff is better
        paoid_improvement = previous_system_paoid - current_system_paoid  # Lower system PAoI is better
        raafu_improvement = 0.0
        current_raafu = 0.0
        if self.use_raafu:
            current_raafu = current_metrics.get('raafu', 0.0)
            raafu_improvement = current_raafu - previous_metrics.get('raafu', 0.0)
        
        # Normalize improvements
        norm_fairness_imp = fairness_improvement
        norm_paoid_diff_imp = paoid_diff_improvement / 100.0  # Assuming typical PAoI diff range
        
        # Weighted reward combining R-AAFU level + improvement, with PAoI/collision constraints
        norm_paoid_imp = paoid_improvement / 2000.0  # Normalize by typical PAoI scale
        paoid_cost = current_system_paoid / 2000.0
        reward = (
            self.reward_w_raafu * current_raafu +
            self.reward_w_raafu_delta * raafu_improvement +
            self.reward_w_fairness * current_fairness +
            self.reward_w_fairness_delta * fairness_improvement +
            self.reward_w_paoid_cost * (-paoid_cost) +
            self.reward_w_collision * (-current_collision)
        )
        
        # Additional penalty if PAoI is too high
        if current_system_paoid > 1000:  # Penalize very high PAoI
            reward -= self.reward_paoid_high_penalty
        
        # Store for tracking
        self.fairness_history.append(current_fairness)
        
        return reward
    
    def train_step(
        self,
        state: List[float],
        env_metrics: Dict,
        prev_metrics: Dict,
        action: Optional[int] = None,
        next_state: Optional[List[float]] = None
    ) -> Tuple[int, float]:
        """
        Perform one training step: choose action, calculate reward, update Q-table
        """
        # Choose action for the agent-controlled vehicle if not provided
        if action is None:
            action = self.choose_action(state)
        
        # Calculate reward based on environment metrics
        reward = self.calculate_reward(env_metrics, prev_metrics)
        
        # Simulate next state (for Q-learning update) if not provided
        if next_state is None:
            next_state = [random.random() for _ in range(self.state_dim)]
        
        # Update Q-table
        self.update_q_table(state, action, reward, next_state)
        
        # Store episode rewards
        self.episode_rewards.append(reward)
        
        return action, reward
    
    def get_performance_summary(self) -> Dict:
        """
        Get performance summary of the agent
        """
        avg_reward = np.mean(self.episode_rewards) if self.episode_rewards else 0
        avg_fairness = np.mean(self.fairness_history) if self.fairness_history else 0.5
        
        return {
            'avg_episode_reward': avg_reward,
            'avg_fairness_over_time': avg_fairness,
            'total_episodes': len(self.episode_rewards),
            'exploration_rate': self.epsilon
        }


class V2XSPSAgenticSystem:
    """
    A true Agentic AI system for 5G NR V2X SPS optimization
    Features:
    - Autonomous goal setting and planning
    - Long-term memory and learning
    - Multi-step reasoning
    - Self-reflection and adaptation
    """
    
    def __init__(self, api_key: Optional[str] = None):
        # Initialize LLM for agentic reasoning (使用OpenAI GPT-4o-mini API)
        # 从环境变量读取API key (OPENAI_API_KEY)
        openai_api_key = api_key or os.environ.get("OPENAI_API_KEY", "")
        if not openai_api_key:
            logger.error("OPENAI_API_KEY not found in environment; LLM guidance disabled")
            self.llm = None
        else:
            logger.info("OPENAI_API_KEY loaded from environment")
        
        try:
            # Use explicit proxy if provided, otherwise clear invalid local placeholders.
            proxy_url = os.environ.get("OPENAI_PROXY", "").strip()
            if proxy_url:
                os.environ["HTTP_PROXY"] = proxy_url
                os.environ["HTTPS_PROXY"] = proxy_url
                os.environ.pop("NO_PROXY", None)
                os.environ.pop("no_proxy", None)
            else:
                for proxy_var in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy"):
                    proxy_val = os.environ.get(proxy_var, "")
                    if proxy_val in ("http://127.0.0.1:9", "http://localhost:9"):
                        os.environ.pop(proxy_var, None)
            temp_env = os.environ.get("OPENAI_TEMPERATURE", "0.1")
            try:
                llm_temp = float(temp_env)
            except ValueError:
                llm_temp = 0.1
            base_url_env = os.environ.get("OPENAI_BASE_URL", "").strip()
            model_env = os.environ.get("OPENAI_MODEL", "gpt-4o-mini").strip() or "gpt-4o-mini"
            timeout_env = os.environ.get("OPENAI_TIMEOUT_SECONDS", "30")
            retry_env = os.environ.get("OPENAI_MAX_RETRIES", "2")
            try:
                llm_timeout = float(timeout_env)
            except ValueError:
                llm_timeout = 30.0
            try:
                llm_max_retries = int(retry_env)
            except ValueError:
                llm_max_retries = 2
            llm_kwargs = {
                "model": model_env,
                "temperature": llm_temp,
                "api_key": openai_api_key,
                "timeout": llm_timeout,
                "max_retries": llm_max_retries,
            }
            if base_url_env:
                # Support OpenAI-compatible gateways.
                llm_kwargs["openai_api_base"] = base_url_env
            self.llm = ChatOpenAI(**llm_kwargs)
            logger.info(
                f"LLM initialized successfully (model={model_env}) "
                f"(timeout={llm_timeout}, max_retries={llm_max_retries}, "
                f"base_url={'default' if not base_url_env else base_url_env})"
            )
        except Exception as e:
            logger.error(f"Failed to initialize OpenAI LLM: {e}")
            self.llm = None
        
        # Initialize memory for the agent (LangChain 1.2.8 compatible)
        self.memory = InMemoryChatMessageHistory()
        
        # Initialize environment and agent
        self.env = V2XEnvironment()
        self.agent = SingleVehicleAgent(num_mcs_options=len(self.env.R_set), agent_vehicle_idx=0)
        self.agent.set_model_type("Markov")
        # LLM-guided action mixing (B2)
        self.use_llm_guidance = False
        self.llm_guidance_prob = 0.7
        # LLM failure policy:
        # - "fallback": keep old behavior (local optimize_rri fallback)
        # - "wait": retry until success (or until wait timeout if configured)
        # - "abort": raise error immediately on failed LLM call
        self.llm_fail_policy = str(os.environ.get("LLM_FAIL_POLICY", "fallback")).strip().lower()
        if self.llm_fail_policy not in {"fallback", "wait", "abort"}:
            self.llm_fail_policy = "fallback"
        # 0 or negative means no timeout (wait forever in wait mode)
        self.llm_wait_max_seconds = float(os.environ.get("LLM_WAIT_MAX_SECONDS", "0") or "0")
        self.llm_retry_sleep_seconds = float(os.environ.get("LLM_RETRY_SLEEP_SECONDS", "1.5") or "1.5")
        # Transient network/API gateway errors are retried before applying fail policy.
        self.llm_conn_retry_max = int(os.environ.get("LLM_CONN_RETRY_MAX", "6") or "6")
        self.llm_conn_retry_sleep_seconds = float(
            os.environ.get("LLM_CONN_RETRY_SLEEP_SECONDS", "2.0") or "2.0"
        )
        # If enabled, missing LLM instance is treated as hard failure.
        self.llm_require_available = str(os.environ.get("LLM_REQUIRE_AVAILABLE", "0")).strip() == "1"
        # If enabled, enforce LLM choice at every decision step.
        self.force_llm_guidance = str(os.environ.get("FORCE_LLM_GUIDANCE", "0")).strip() == "1"
        # R-AAFU sensitivity parameters (tunable)
        self.raafu_k_age = 0.6
        self.raafu_alpha_rri = 0.1
        self.raafu_beta_coll = 0.2
        # R-AAFU mode: "ratio" (paper-like) or "freshness_log" (non-copy, AoI-inverse)
        self.raafu_mode = "freshness_log"
        # LLM objective focus: "balanced" or "paoid"
        self.llm_objective = "balanced"
        
        # Initialize tools for agentic reasoning
        self.tools = [
            Tool(
                name="calculate_system_state",
                func=self._calculate_system_state_wrapper,
                description="Calculate the current system state based on RRI and vehicle count using mathematical formulas"
            ),
            Tool(
                name="evaluate_paoid",
                func=self._evaluate_paoid_wrapper,
                description="Evaluate PAoI (Peak Age of Information) difference for fairness assessment"
            ),
            Tool(
                name="analyze_fairness",
                func=self._analyze_fairness_wrapper,
                description="Analyze fairness metrics across vehicles in the system"
            ),
            Tool(
                name="optimize_rri",
                func=self._optimize_rri_wrapper,
                description="Optimize RRI (Resource Reservation Interval) based on current system state and goals"
            ),
            Tool(
                name="adjust_mcs",
                func=self._adjust_mcs_wrapper,
                description="Adjust MCS (Modulation and Coding Scheme) levels for vehicles to optimize performance"
            ),
            Tool(
                name="simulate_step",
                func=self._simulate_step_wrapper,
                description="Simulate one step of the V2X environment with given parameters"
            ),
            Tool(
                name="get_performance_metrics",
                func=self._get_performance_metrics_wrapper,
                description="Retrieve current performance metrics including PAoI, fairness, and efficiency"
            ),
            Tool(
                name="multi_objective_optimize",
                func=self._multi_objective_optimize_wrapper,
                description="Perform multi-objective optimization balancing PAoI, fairness, and efficiency"
            )
        ]
        
        # Initialize the agentic system if LLM is available (LangChain 1.2.8 compatible)
        self.agent_call_count = 0
        self.max_calls_before_reset = 25  # Reset agent every 25 calls to avoid message history overflow (more aggressive)
        if self.llm:
            self.agent_system = create_agent(
                model=self.llm,
                tools=self.tools,
                system_prompt="You are an expert in 5G NR V2X communication systems. Help optimize the system.",
                debug=True
            )
        else:
            self.agent_system = None
        
        # State variables
        self.current_state = self.env.current_state
        self.N_v = self.env.N_v
        self.performance_history = []  # Track performance over time
        # Optional action extension: agent chooses (RRI, keep/reselect).
        self.use_sps_policy_action = False
        self.keep_reselect_threshold = 0.12

        logger.info("V2X SPS Agentic System initialized")
    
    def reset(self) -> Dict:
        """Reset environment to initial state"""
        initial_state = self.env.reset()
        self.current_state = initial_state
        self.N_v = self.env.N_v
        self.performance_history = []
        self._sync_action_space()
        
        logger.info("Environment reset to initial state")
        return initial_state

    def _sync_action_space(self):
        """Keep agent action space aligned with current R_set."""
        base = len(self.env.R_set)
        if self.use_sps_policy_action:
            desired_actions = list(range(base * 2))
        else:
            desired_actions = list(range(base))
        if getattr(self.agent, "action_space", None) != desired_actions:
            self.agent.action_space = desired_actions

    def _decode_agent_action(self, action: int) -> Tuple[int, bool]:
        """Decode action index into (rri_value, force_reselect)."""
        if not self.env.R_set:
            return 100, False
        n_rri = len(self.env.R_set)
        if not self.use_sps_policy_action:
            rri = int(self.env.R_set[int(action) % n_rri])
            return rri, False
        # Action layout: [0..n_rri-1]=keep branch, [n_rri..2*n_rri-1]=reselect branch
        action_int = int(action) % (2 * n_rri)
        branch = action_int // n_rri
        rri_idx = action_int % n_rri
        rri = int(self.env.R_set[rri_idx])
        force_reselect = bool(branch == 1)
        return rri, force_reselect

    def _encode_action_from_rri_policy(self, rri_value: int, force_reselect: bool) -> int:
        """Encode (rri, policy) into current action index space."""
        if not self.env.R_set:
            return 0
        try:
            rri_idx = self.env.R_set.index(int(rri_value))
        except Exception:
            rri_idx = min(range(len(self.env.R_set)), key=lambda i: abs(self.env.R_set[i] - int(rri_value)))
        if not self.use_sps_policy_action:
            return int(rri_idx)
        return int(rri_idx + (len(self.env.R_set) if force_reselect else 0))

    def _get_rri_opt(self, n_total: int) -> int:
        """Lookup theoretical optimal RRI from modeling document."""
        opt_rri_table = {
            1: 20, 2: 50, 3: 100, 4: 100, 5: 200,
            6: 200, 7: 300, 8: 300, 9: 500, 10: 500
        }
        if n_total in opt_rri_table:
            return opt_rri_table[n_total]
        if n_total <= 1:
            return 20
        if n_total >= 10:
            return 500
        # Fallback: nearest neighbor
        nearest = min(opt_rri_table.keys(), key=lambda k: abs(k - n_total))
        return opt_rri_table[nearest]

    def _calculate_raafu(self, fairness_metrics: Dict, rri_value: float, n_v: int, collision_prob: Optional[float] = None) -> Dict:
        """
        R-AAFU: RRI-Aware Age Fairness Utility (system-level).
        System utility is the average of per-vehicle utilities.
        U_i = A_fair_i * E_RRI * P_coll_penalty
        """
        individual_paoids = fairness_metrics.get('individual_paoids', [])
        if not individual_paoids:
            return {
                'raafu': 1.0,
                'age_fairness': 1.0,
                'rri_efficiency': 1.0,
                'collision_penalty': 1.0,
                'paoid_self': 0.0,
                'paoid_others_avg': 0.0,
                'n_total': 1,
                'rri_opt': self._get_rri_opt(1),
                'raafu_per_vehicle': [],
                'age_fairness_per_vehicle': []
            }

        # In the document, N_d = N_v + 1. Here N_v already counts total vehicles,
        # so N_total is set to N_v for consistency.
        n_total = max(1, int(n_v))
        rri_opt = self._get_rri_opt(n_total)
        # Smooth, bounded efficiency terms (avoid negative utilities)
        k_age = float(getattr(self, "raafu_k_age", 2.5))
        alpha_rri = float(getattr(self, "raafu_alpha_rri", 0.6))
        beta_coll = float(getattr(self, "raafu_beta_coll", 1.0))
        raafu_mode = getattr(self, "raafu_mode", "ratio")
        eps = 1e-6

        rri_opt_safe = max(1e-6, float(rri_opt))
        rri_ratio = float(rri_value) / rri_opt_safe
        rri_efficiency = float(np.exp(-alpha_rri * abs(np.log(rri_ratio))))

        if collision_prob is None:
            collision_prob = self.current_state.get('P_coll', 0.0)
        collision_penalty = float(np.exp(-beta_coll * float(collision_prob)))

        total_sum = float(sum(individual_paoids))
        ideal_ratio = 1.0 / n_total
        fresh_vals = [1.0 / (float(v) + eps) for v in individual_paoids]
        mean_fresh = float(np.mean(fresh_vals)) if fresh_vals else 0.0

        raafu_per_vehicle = []
        age_fairness_per_vehicle = []

        for idx, paoid_self in enumerate(individual_paoids):
            if n_total > 1:
                paoid_others_avg = (total_sum - paoid_self) / (n_total - 1)
            else:
                paoid_others_avg = 0.0

            denom = paoid_self + paoid_others_avg
            if raafu_mode == "ratio":
                age_ratio = paoid_self / denom if denom > 0 else 0.5
                age_fairness = float(np.exp(-k_age * abs(age_ratio - ideal_ratio)))
            else:
                fresh_i = float(fresh_vals[idx]) if idx < len(fresh_vals) else 0.0
                ratio = fresh_i / (mean_fresh + eps) if mean_fresh > 0 else 1.0
                age_fairness = float(np.exp(-k_age * abs(np.log(ratio))))

            age_fairness_per_vehicle.append(age_fairness)
            raafu_per_vehicle.append(float(age_fairness * rri_efficiency * collision_penalty))

        utility = float(np.mean(raafu_per_vehicle)) if raafu_per_vehicle else 0.0
        age_fairness_avg = float(np.mean(age_fairness_per_vehicle)) if age_fairness_per_vehicle else 1.0

        # Keep vehicle-0 self/others as a reference
        paoid_self = float(individual_paoids[0])
        paoid_others_avg = (total_sum - paoid_self) / (n_total - 1) if n_total > 1 else 0.0

        return {
            'raafu': utility,
            'age_fairness': age_fairness_avg,
            'rri_efficiency': float(rri_efficiency),
            'collision_penalty': float(collision_penalty),
            'paoid_self': float(paoid_self),
            'paoid_others_avg': float(paoid_others_avg),
            'n_total': n_total,
            'rri_opt': rri_opt,
            'raafu_per_vehicle': raafu_per_vehicle,
            'age_fairness_per_vehicle': age_fairness_per_vehicle
        }
    
    def calculate_system_state(self, RRI: float, N_v: int) -> Dict:
        """
        Calculate system state based on 10 core formulas
        """
        return self.env.calculate_system_state(RRI, N_v)
    
    def evaluate_paoid(self) -> Dict:
        """Evaluate PAoI differences for fairness assessment"""
        self.env.sync_config()
        # Recompute state in case RRI or config was updated externally
        current_rri = self.current_state.get('RRI', self.env.current_state.get('RRI', 100))
        self.current_state = self.env.calculate_system_state(RRI=current_rri, N_v=self.env.N_v)
        self.env.current_state = self.current_state
        self.N_v = self.env.N_v
        fairness_metrics = self.env.calculate_fairness_metrics(self.N_v, self.current_state['RRI'])
        raafu = self._calculate_raafu(
            fairness_metrics,
            self.current_state['RRI'],
            self.N_v,
            collision_prob=self.current_state.get('P_coll', 0.0)
        )
        return {**fairness_metrics, **raafu}
    
    def optimize_rri(self) -> Dict:
        """Optimize RRI based on current system state and goals"""
        # Score each possible RRI value using PAoI + fairness + collision
        rri_scores = {}
        for rri in self.env.R_set:
            temp_state = self.calculate_system_state(RRI=rri, N_v=self.N_v)
            temp_paoid = temp_state['PAoI']
            temp_collision_prob = temp_state['P_coll']
            fairness_metrics = self.env.calculate_fairness_metrics(self.N_v, rri)
            temp_fairness = fairness_metrics['fairness_index']
            temp_raafu = self._calculate_raafu(
                fairness_metrics,
                rri,
                self.N_v,
                collision_prob=temp_state.get('P_coll', 0.0)
            )['raafu']
            
            # Normalize and combine (maximize fairness, minimize PAoI and collision)
            paoid_cost = temp_paoid / 2000.0
            collision_cost = temp_collision_prob
            objective = getattr(self, "llm_objective", "balanced")
            if objective == "paoid":
                score = -1.0 * paoid_cost - 0.1 * collision_cost
            elif objective == "fairness":
                score = 0.9 * temp_fairness - 0.05 * paoid_cost - 0.05 * collision_cost
            else:
                score = 0.55 * temp_raafu + 0.15 * temp_fairness - 0.25 * paoid_cost - 0.05 * collision_cost
            rri_scores[rri] = score
        
        # Select RRI with highest score
        optimal_rri = max(rri_scores, key=rri_scores.get)
        
        return {
            'optimal_rri': optimal_rri,
            'scores': rri_scores,
            'current_rri': self.current_state['RRI'],
            'recommendation': f"Change RRI from {self.current_state['RRI']} to {optimal_rri} for improved performance"
        }

    def _coerce_rri_to_set(self, value: int) -> int:
        if value in self.env.R_set:
            return value
        return min(self.env.R_set, key=lambda x: abs(x - value))

    def _is_transient_llm_error(self, exc: Exception) -> bool:
        text = str(exc).lower()
        marks = (
            "connection error",
            "apiconnectionerror",
            "connecterror",
            "readtimeout",
            "timed out",
            "timeout",
            "unexpected eof",
            "ssl",
            "remoteprotocolerror",
            "connection reset",
            "temporarily unavailable",
            "server disconnected",
        )
        return any(m in text for m in marks)

    def suggest_rri_with_llm(self) -> int:
        """
        Ask LLM for an RRI recommendation (B2 guidance).
        Failure behavior is controlled by self.llm_fail_policy:
        - fallback: return local optimize_rri result
        - wait: retry until success (or timeout if configured)
        - abort: raise RuntimeError
        """
        self.env.sync_config()
        if not self.llm:
            if self.llm_fail_policy == "abort" or self.llm_require_available:
                raise RuntimeError("LLM is unavailable while strict LLM mode is enabled.")
            return self.optimize_rri()['optimal_rri']

        rset = self.env.R_set
        state = self.current_state if self.current_state else self.env.current_state
        objective = getattr(self, "llm_objective", "balanced")
        if objective == "paoid":
            goal_text = "Goal: minimize PAoI. Fairness is secondary."
        elif objective == "fairness":
            goal_text = "Goal: maximize fairness; avoid extreme AoI."
        else:
            goal_text = "Goal: minimize PAoI while maintaining fairness."
        prompt = (
            "Choose ONE RRI value from the candidate set for this V2X SPS system. "
            "Return only the integer.\n\n"
            f"{goal_text}\n"
            f"Candidate RRI set (ms): {rset}\n"
            f"Current N_v: {state.get('N_v', self.env.N_v)}\n"
            f"Current RRI: {state.get('RRI', rset[0])}\n"
            f"Current PAoI: {state.get('PAoI', 0.0):.2f}\n"
            f"Collision Prob: {state.get('P_coll', 0.0):.4f}\n"
        )

        start_ts = time.time()
        attempt = 0
        sleep_s = max(0.2, float(self.llm_retry_sleep_seconds))
        conn_fail_streak = 0
        while True:
            attempt += 1
            try:
                response = self.llm.invoke([
                    {"role": "system", "content": "You are a V2X SPS optimizer."},
                    {"role": "user", "content": prompt}
                ])
                conn_fail_streak = 0
                text = response.content or ""
                numbers = re.findall(r"\d+", text)
                if numbers:
                    candidate = int(numbers[0])
                    return self._coerce_rri_to_set(candidate)
                # Invalid-but-successful response.
                logger.warning("LLM returned no integer RRI (attempt %d).", attempt)
                if self.llm_fail_policy == "abort":
                    raise RuntimeError("LLM response had no valid integer RRI.")
            except Exception as e:
                logger.error(f"LLM RRI suggestion failed: {e}")
                if self._is_transient_llm_error(e) and self.llm_conn_retry_max > 0:
                    conn_fail_streak += 1
                    if conn_fail_streak <= self.llm_conn_retry_max:
                        logger.warning(
                            "Transient LLM error, retrying (%d/%d) ...",
                            conn_fail_streak,
                            self.llm_conn_retry_max,
                        )
                        time.sleep(max(0.2, float(self.llm_conn_retry_sleep_seconds)))
                        continue
                if self.llm_fail_policy == "abort":
                    raise RuntimeError("LLM call failed under abort policy.") from e

            if self.llm_fail_policy == "fallback":
                return self.optimize_rri()['optimal_rri']

            # wait mode: keep retrying until success/timeout
            if self.llm_wait_max_seconds > 0:
                elapsed = time.time() - start_ts
                if elapsed >= self.llm_wait_max_seconds:
                    raise RuntimeError(
                        f"LLM wait timeout after {elapsed:.1f}s (attempts={attempt})."
                    )
            time.sleep(sleep_s)
    
    def adjust_mcs(self) -> Dict:
        """No-op for MCS in MAC-only model (kept for API compatibility)."""
        adjustments = {}
        for i in range(self.env.num_vehicles):
            current_mcs = self.env.vehicle_mcs_levels[i]
            adjustments[f"vehicle_{i}"] = {
                'current_mcs': current_mcs,
                'recommended_mcs': current_mcs,
                'reason': 'MAC-only model: MCS not optimized'
            }
        evaluation = self.evaluate_paoid()
        return {
            'adjustments': adjustments,
            'current_fairness': evaluation['fairness_index'],
            'current_avg_paoid': evaluation['avg_paoid']
        }
    
    def multi_objective_optimize(self) -> Dict:
        """
        Perform multi-objective optimization balancing PAoI, fairness, and efficiency
        """
        # Define objectives
        objectives = {
            'minimize_paoid': self.current_state['PAoI'],
            'maximize_fairness': self.evaluate_paoid()['fairness_index'],
            'minimize_collision_prob': self.current_state['P_coll']
        }
        
        # Evaluate different RRI and MCS combinations
        best_combination = None
        best_score = float('-inf')
        
        for rri in self.env.R_set:
            for mcs in range(7):  # Possible MCS values
                # Calculate state with this combination
                temp_state = self.calculate_system_state(RRI=rri, N_v=self.N_v)
                
                # Temporarily update agent's MCS for evaluation
                original_mcs = self.env.vehicle_mcs_levels[self.env.agent_controlled_vehicle_idx]
                self.env.vehicle_mcs_levels[self.env.agent_controlled_vehicle_idx] = mcs
                temp_fairness = self.env.calculate_fairness_metrics(self.N_v, rri)['fairness_index']
                
                # Restore original MCS
                self.env.vehicle_mcs_levels[self.env.agent_controlled_vehicle_idx] = original_mcs
                
                # Calculate weighted score
                paoid_normalized = 1 / (temp_state['PAoI'] + 1)
                fairness_normalized = temp_fairness
                collision_prob_normalized = 1 / (temp_state['P_coll'] + 0.01)
                
                # Weighted combination (adjust weights as needed)
                score = 0.4 * paoid_normalized + 0.4 * fairness_normalized + 0.2 * collision_prob_normalized
                
                if score > best_score:
                    best_score = score
                    best_combination = {
                        'rri': rri,
                        'mcs': mcs,
                        'score': score,
                        'paoid': temp_state['PAoI'],
                        'fairness': temp_fairness
                    }
        
        return {
            'best_combination': best_combination,
            'all_objectives': objectives,
            'recommendation': f"Recommended RRI: {best_combination['rri']}, MCS: {best_combination['mcs']}"
        }
    
    def run_agentic_optimization_cycle(self) -> Dict:
        """Run a complete agentic optimization cycle using OpenAI Function Calling
        
        TRUE AGENTIC ARCHITECTURE:
        - LLM receives system state
        - LLM decides which functions/tools to call
        - System executes tool calls and returns results
        - LLM makes final optimization decision
        
        Uses fresh OpenAI API call each time (no history accumulation).
        """
        logger.info("Starting TRUE AGENTIC cycle with Function Calling")
        self.env.sync_config()
        self.current_state = self.env.current_state
        self.N_v = self.env.N_v
        self._sync_action_space()
        
        if self.llm:
            import openai
            
            # Define available functions for the LLM
            functions = [
                {
                    "name": "get_performance_metrics",
                    "description": "Get current system performance metrics (PAoI, fairness, collision probability)",
                    "parameters": {"type": "object", "properties": {}}
                },
                {
                    "name": "optimize_rri",
                    "description": "Find the optimal Resource Reservation Interval value",
                    "parameters": {"type": "object", "properties": {}}
                },
                {
                    "name": "adjust_mcs",
                    "description": "Analyze MCS levels and recommend adjustments for fairness",
                    "parameters": {"type": "object", "properties": {}}
                },
                {
                    "name": "multi_objective_optimize",
                    "description": "Multi-objective optimization balancing PAoI, fairness, and efficiency",
                    "parameters": {"type": "object", "properties": {}}
                }
            ]
            
            # Initial prompt - LLM decides which tools to call
            messages = [
                {"role": "system", "content": "You are an expert in 5G NR V2X SPS optimization. Analyze the system and call functions to gather data before making optimization decisions."},
                {"role": "user", "content": f"""Optimize this V2X system:

Current State:
- Vehicles (N_v): {self.N_v}
- Current RRI: {self.current_state['RRI']} ms
- Current PAoI: {self.current_state['PAoI']:.2f} ms
- Collision Probability: {self.current_state['P_coll']:.4f}
- Vehicle MCS Levels: {list(self.env.vehicle_mcs_levels)}

GOAL: Minimize PAoI while maintaining fairness.

First, call the appropriate functions to analyze the system, then provide your optimization recommendation."""}
            ]
            
            tools_used = []
            
            try:
                # Step 1: Get function calls from LLM
                response = self.llm.invoke(messages)
                
                # Check if LLM wants to call functions
                # Note: This is simplified - in practice we'd parse function calls
                # For now, simulate the agentic workflow by calling all analysis tools
                
                # Execute tools that an agentic LLM would call
                logger.info("Executing agentic tool calls...")
                
                metrics = self.evaluate_paoid()
                tools_used.append("get_performance_metrics")
                
                optimal_rri = self.optimize_rri()
                tools_used.append("optimize_rri")
                
                mcs_analysis = self.adjust_mcs()
                tools_used.append("adjust_mcs")
                
                multi_obj = self.multi_objective_optimize()
                tools_used.append("multi_objective_optimize")
                
                # Step 2: Get final decision from LLM with tool outputs
                final_prompt = f"""Based on the tool analysis:

Performance Metrics:
- PAoI: {metrics['avg_paoid']:.2f} ms
- Fairness Index: {metrics['fairness_index']:.4f}
- Collision Probability: {metrics.get('collision_probability', self.current_state['P_coll']):.4f}

RRI Optimization:
- Optimal RRI: {optimal_rri['optimal_rri']} ms
- Score: {optimal_rri['scores'].get(optimal_rri['optimal_rri'], 'N/A')}

MCS Analysis:
{to_json(mcs_analysis.get('adjustments', {}))}

Multi-Objective:
{multi_obj['recommendation']}

Provide your final optimization recommendation."""
                
                final_response = self.llm.invoke([
                    {"role": "system", "content": "You are an expert V2X optimizer. Provide clear, actionable recommendations."},
                    {"role": "user", "content": final_prompt}
                ])
                
                result = {
                    "type": "AGENTIC_OPTIMIZATION",
                    "agent_final_decision": final_response.content,
                    "tools_autonomously_selected": tools_used,
                    "reasoning": "LLM-guided agentic optimization with tool execution"
                }
                
                # Apply the optimization
                self.apply_action({
                    "rri": optimal_rri['optimal_rri'],
                    "mcs_adjustments": mcs_analysis
                })

                # Advance environment one step with chosen RRI
                new_state, _ = self.env.step(
                    self.env.vehicle_mcs_levels[self.env.agent_controlled_vehicle_idx],
                    rri_value=int(self.current_state['RRI'])
                )
                self.current_state = new_state
                self.N_v = new_state['N_v']
                
                logger.info(f"Agentic optimization complete. Tools: {tools_used}")
                
            except Exception as e:
                logger.error(f"Agentic cycle error: {e}")
                result = self._fallback_agentic_cycle()
        else:
            logger.info("No LLM available, running offline optimization")
            result = self._offline_optimization_cycle()
        
        # Log the agent's decision
        logger.info(f"Agent decision: {result}")
        
        # Update performance history
        evaluation = self.evaluate_paoid()
        self.performance_history.append({
            'timestamp': datetime.now(),
            'rri': self.current_state['RRI'],
            'paoid': self.current_state['PAoI'],
            'fairness': evaluation['fairness_index'],
            'raafu': evaluation.get('raafu', 0.0),
            'collision_prob': self.current_state['P_coll'],
            'agent_mcs': self.env.vehicle_mcs_levels[self.env.agent_controlled_vehicle_idx]
        })
        
        return {
            'agent_response': result,
            'current_state': self.current_state,
            'performance_evaluation': evaluation,
            'history_length': len(self.performance_history)
        }
    
    def apply_action(self, action: Dict) -> None:
        """Apply optimization action to the system
        
        Args:
            action: Dict containing 'rri' and/or 'mcs_adjustments'
        """
        logger.info(f"Applying action: {action}")
        
        # Apply RRI change if provided
        if 'rri' in action and action['rri'] is not None:
            new_rri = action['rri']
            if new_rri in self.env.R_set:
                self.current_state['RRI'] = new_rri
                self.current_state = self.env.calculate_system_state(RRI=new_rri, N_v=self.N_v)
                self.env.current_state = self.current_state
                logger.info(f"Applied RRI change: {new_rri}")
        
        # Apply MCS adjustments if provided
        if 'mcs_adjustments' in action and action['mcs_adjustments']:
            adjustments = action['mcs_adjustments'].get('adjustments', {})
            for vehicle_key, adj_info in adjustments.items():
                if isinstance(adj_info, dict) and 'recommended_mcs' in adj_info:
                    try:
                        # Extract vehicle index from key (e.g., 'vehicle_0' -> 0)
                        v_idx = int(vehicle_key.split('_')[-1])
                        if 0 <= v_idx < len(self.env.vehicle_mcs_levels):
                            self.env.vehicle_mcs_levels[v_idx] = adj_info['recommended_mcs']
                            logger.info(f"Applied MCS adjustment for vehicle {v_idx}: {adj_info['recommended_mcs']}")
                    except (ValueError, IndexError) as e:
                        logger.warning(f"Failed to apply MCS adjustment for {vehicle_key}: {e}")
    
    def _fallback_agentic_cycle(self) -> Dict:
        """
        Fallback agentic cycle when LangChain Agent fails
        Uses direct LLM call with pre-computed tool results
        """
        logger.info("Running fallback agentic cycle")
        
        # Get all tool outputs manually
        evaluation = self.evaluate_paoid()
        optimal_rri_result = self.optimize_rri()
        mcs_adjustments = self.adjust_mcs()
        multi_obj_result = self.multi_objective_optimize()
        
        # Create comprehensive prompt with all tool outputs
        prompt = f"""As an expert in 5G NR V2X SPS optimization, analyze the following system data and provide optimization recommendations:

SYSTEM STATE:
- Vehicles (N_v): {self.N_v}
- Current RRI: {self.current_state['RRI']} ms
- Current PAoI: {self.current_state['PAoI']:.2f} ms
- Collision Probability: {self.current_state['P_coll']:.4f}
- Fairness Index: {evaluation['fairness_index']:.4f}
- Vehicle MCS Levels: {list(self.env.vehicle_mcs_levels)}

TOOL ANALYSIS RESULTS:
1. Performance Metrics: PAoI={evaluation['avg_paoid']:.2f}, Fairness={evaluation['fairness_index']:.4f}
2. Optimal RRI Analysis: Best RRI={optimal_rri_result['optimal_rri']} ms (Current: {optimal_rri_result['current_rri']} ms)
   Scores: {optimal_rri_result['scores']}
3. MCS Adjustments: {to_json(mcs_adjustments.get('adjustments', {}))}
4. Multi-Objective: {multi_obj_result['recommendation']}

Based on this analysis, what is your optimization recommendation?"""
        
        # Direct LLM call
        messages = [
            ("system", "You are an expert in 5G NR V2X communication systems optimization."),
            ("human", prompt)
        ]
        
        try:
            response = self.llm.invoke(messages)
            self.apply_action({
                "rri": optimal_rri_result['optimal_rri'],
                "mcs_adjustments": mcs_adjustments
            })
            new_state, _ = self.env.step(
                self.env.vehicle_mcs_levels[self.env.agent_controlled_vehicle_idx],
                rri_value=int(self.current_state['RRI'])
            )
            self.current_state = new_state
            self.N_v = new_state['N_v']
            return {
                "type": "FALLBACK_AGENTIC",
                "agent_decision": response.content,
                "tools_simulated": 4,
                "reasoning": "Used direct LLM call with pre-computed tool outputs"
            }
        except Exception as e:
            logger.error(f"Fallback also failed: {e}")
            self.apply_action({
                "rri": optimal_rri_result['optimal_rri'],
                "mcs_adjustments": mcs_adjustments
            })
            new_state, _ = self.env.step(
                self.env.vehicle_mcs_levels[self.env.agent_controlled_vehicle_idx],
                rri_value=int(self.current_state['RRI'])
            )
            self.current_state = new_state
            self.N_v = new_state['N_v']
            return {
                "type": "FALLBACK_FAILED",
                "error": str(e),
                "optimal_rri": optimal_rri_result['optimal_rri'],
                "mcs_adjustments": mcs_adjustments
            }
    
    def _offline_optimization_cycle(self) -> str:
        """
        Run optimization cycle without LLM (offline mode)
        """
        # Get current metrics
        current_metrics = self.evaluate_paoid()
        current_rri = self.current_state['RRI']
        
        # Find optimal RRI
        optimal_rri_result = self.optimize_rri()
        optimal_rri = optimal_rri_result['optimal_rri']
        
        # Get MCS recommendations
        mcs_adjustments = self.adjust_mcs()
        
        # Get multi-objective optimization
        multi_obj_result = self.multi_objective_optimize()
        
        # Formulate response
        response = f"""
        Offline Optimization Results:
        - Current RRI: {current_rri}, Recommended RRI: {optimal_rri}
        - Current PAoI: {self.current_state['PAoI']:.2f}
        - Current Fairness Index: {current_metrics['fairness_index']:.3f}
        - Agent-controlled vehicle (index 0) current MCS: {self.env.vehicle_mcs_levels[0]}
        - Recommended MCS adjustments: {to_json(mcs_adjustments['adjustments'], indent=2)}
        - Multi-objective optimization: {multi_obj_result['recommendation']}
        """

        # Apply the offline recommendation to keep state consistent
        self.apply_action({
            "rri": optimal_rri,
            "mcs_adjustments": mcs_adjustments
        })
        new_state, _ = self.env.step(
            self.env.vehicle_mcs_levels[self.env.agent_controlled_vehicle_idx],
            rri_value=int(self.current_state['RRI'])
        )
        self.current_state = new_state
        self.N_v = new_state['N_v']
        
        return response
    
    def run_learning_episode(self, max_steps: int = 15, use_llm_guidance: Optional[bool] = None) -> Dict:
        """
        Run a complete learning episode with the agent controlling the system
        """
        logger.info("Starting learning episode with single agent control")

        if use_llm_guidance is None:
            use_llm_guidance = self.use_llm_guidance
        # Optional schedules for exploration / guidance
        epsilon = getattr(self.agent, "epsilon", 0.1)
        llm_prob = self.llm_guidance_prob
        if hasattr(self, "llm_guidance_prob_schedule"):
            try:
                llm_prob = float(self.llm_guidance_prob_schedule())
            except Exception:
                llm_prob = self.llm_guidance_prob
        if hasattr(self.agent, "epsilon_schedule"):
            try:
                epsilon = float(self.agent.epsilon_schedule())
            except Exception:
                epsilon = getattr(self.agent, "epsilon", 0.1)
        if hasattr(self.agent, "epsilon"):
            self.agent.epsilon = epsilon
        if use_llm_guidance and self.force_llm_guidance:
            llm_prob = 1.0
        
        episode_data = {
            'states': [],
            'actions': [],
            'reselect_flags': [],
            'rewards': [],
            'fairness_metrics': [],
            'paoid_values': [],
            'agent_mcs_levels': []
        }
        
        # Get initial state
        self.env.sync_config()
        initial_state = self.env.reset()
        self._sync_action_space()
        # Keep system-side cached state aligned with fresh environment reset.
        self.current_state = initial_state
        self.N_v = int(initial_state.get('N_v', 0))
        initial_fairness = self.env.calculate_fairness_metrics(
            initial_state['N_v'], initial_state['RRI']
        )
        initial_fairness = {
            **initial_fairness,
            **self._calculate_raafu(
                initial_fairness,
                initial_state['RRI'],
                initial_state['N_v'],
                collision_prob=initial_state.get('P_coll', 0.0)
            )
        }
        
        # Add initial data
        episode_data['states'].append(initial_state)
        episode_data['fairness_metrics'].append(initial_fairness)
        episode_data['paoid_values'].append(initial_state['PAoI'])
        episode_data['agent_mcs_levels'].append(initial_state['agent_mcs_level'])
        
        prev_metrics = initial_fairness
        llm_rri = None
        if use_llm_guidance:
            if (not self.llm) and self.force_llm_guidance:
                raise RuntimeError("FORCE_LLM_GUIDANCE=1 but LLM is unavailable.")
            if self.llm:
                llm_rri = self.suggest_rri_with_llm()
        
        for step in range(max_steps):
            # Get state for agent
            agent_state = self._get_state_vector_for_agent()
            
            # Let agent choose action (index -> RRI, optional keep/reselect policy)
            if llm_rri is not None and random.random() < llm_prob:
                rri_value = llm_rri
                force_reselect = bool(
                    self.use_sps_policy_action
                    and float(self.current_state.get("P_coll", 0.0)) >= float(self.keep_reselect_threshold)
                )
                agent_action = self._encode_action_from_rri_policy(int(rri_value), force_reselect)
            elif use_llm_guidance and self.force_llm_guidance:
                raise RuntimeError("LLM decision required but not used at this step.")
            else:
                agent_action = self.agent.choose_action(agent_state)
                rri_value, force_reselect = self._decode_agent_action(agent_action)
            
            # Apply action to environment
            new_state, terminated = self.env.step(
                self.env.vehicle_mcs_levels[self.env.agent_controlled_vehicle_idx],
                rri_value=int(rri_value),
                force_reselect=force_reselect
            )
            
            # Calculate fairness metrics for the new state
            fairness_metrics = self.env.calculate_fairness_metrics(
                new_state['N_v'], new_state['RRI']
            )
            fairness_metrics = {
                **fairness_metrics,
                **self._calculate_raafu(
                    fairness_metrics,
                    new_state['RRI'],
                    new_state['N_v'],
                    collision_prob=new_state.get('P_coll', 0.0)
                )
            }
            fairness_metrics['collision_prob'] = float(new_state.get('P_coll', 0.0))
            fairness_metrics['system_paoid'] = float(new_state.get('PAoI', 0.0))
            
            # Update Q-table using the actual transition
            next_state_vec = self._get_state_vector_for_agent()
            _, reward = self.agent.train_step(
                agent_state,
                fairness_metrics,
                prev_metrics,
                action=agent_action,
                next_state=next_state_vec
            )
            
            # Record episode data
            episode_data['states'].append(new_state)
            episode_data['actions'].append(int(rri_value))
            episode_data['reselect_flags'].append(bool(force_reselect))
            episode_data['rewards'].append(reward)
            episode_data['fairness_metrics'].append(fairness_metrics)
            episode_data['paoid_values'].append(new_state['PAoI'])
            episode_data['agent_mcs_levels'].append(new_state['agent_mcs_level'])
            
            # Update previous metrics for next iteration
            prev_metrics = fairness_metrics
            
            # Update current state
            self.current_state = new_state
            self.N_v = new_state['N_v']
            
            if terminated:
                logger.info(f"Episode terminated early at step {step+1} due to convergence or max steps")
                break
        
        # Update performance history
        for i in range(len(episode_data['states'])):
            self.performance_history.append({
                'timestamp': datetime.now(),
                'rri': episode_data['states'][i]['RRI'],
                'paoid': episode_data['states'][i]['PAoI'],
                'fairness': episode_data['fairness_metrics'][i]['fairness_index'],
                'raafu': episode_data['fairness_metrics'][i].get('raafu', 0.0),
                'collision_prob': episode_data['states'][i]['P_coll'],
                'agent_mcs': episode_data['agent_mcs_levels'][i]
            })
        
        logger.info(f"Learning episode completed with {len(episode_data['states'])} steps")
        return episode_data

    def run_evaluation_episode(self, max_steps: int = 15) -> Dict:
        """
        Run a policy evaluation episode (no Q-table updates, epsilon=0).
        """
        logger.info("Starting evaluation episode (no learning updates)")

        saved_epsilon = self.agent.epsilon
        self.agent.epsilon = 0.0

        episode_data = {
            'paoid_values': [],
            'fairness_values': [],
            'raafu_values': []
        }

        self.env.sync_config()
        initial_state = self.env.reset()
        self._sync_action_space()
        # Keep system-side cached state aligned with fresh environment reset.
        self.current_state = initial_state
        self.N_v = int(initial_state.get('N_v', 0))

        prev_metrics = self.env.calculate_fairness_metrics(
            initial_state['N_v'], initial_state['RRI']
        )
        prev_metrics = {
            **prev_metrics,
            **self._calculate_raafu(
                prev_metrics,
                initial_state['RRI'],
                initial_state['N_v'],
                collision_prob=initial_state.get('P_coll', 0.0)
            )
        }

        for _step in range(max_steps):
            agent_state = self._get_state_vector_for_agent()
            agent_action = self.agent.choose_action(agent_state)
            rri_value, force_reselect = self._decode_agent_action(agent_action)

            new_state, terminated = self.env.step(
                self.env.vehicle_mcs_levels[self.env.agent_controlled_vehicle_idx],
                rri_value=int(rri_value),
                force_reselect=force_reselect
            )

            fairness_metrics = self.env.calculate_fairness_metrics(
                new_state['N_v'], new_state['RRI']
            )
            fairness_metrics = {
                **fairness_metrics,
                **self._calculate_raafu(
                    fairness_metrics,
                    new_state['RRI'],
                    new_state['N_v'],
                    collision_prob=new_state.get('P_coll', 0.0)
                )
            }

            episode_data['paoid_values'].append(new_state['PAoI'])
            episode_data['fairness_values'].append(fairness_metrics['fairness_index'])
            episode_data['raafu_values'].append(fairness_metrics.get('raafu', 0.0))

            prev_metrics = fairness_metrics
            self.current_state = new_state
            self.N_v = new_state['N_v']

            if terminated:
                break

        self.agent.epsilon = saved_epsilon

        return {
            'avg_paoid': float(np.mean(episode_data['paoid_values'])) if episode_data['paoid_values'] else 0.0,
            'avg_fairness': float(np.mean(episode_data['fairness_values'])) if episode_data['fairness_values'] else 0.0,
            'avg_raafu': float(np.mean(episode_data['raafu_values'])) if episode_data['raafu_values'] else 0.0,
            'paoid_values': episode_data['paoid_values'],
            'fairness_values': episode_data['fairness_values'],
            'raafu_values': episode_data['raafu_values']
        }
    
    def _get_state_vector_for_agent(self) -> List[float]:
        """
        Convert environment state to 4-dimensional state vector for agent
        [ak, ok, W0k, n] representing current system state information
        """
        # Extract relevant information from current environment state
        env_state = self.env.current_state
        state_mode = str(getattr(self, "agent_state_mode", "classic"))
        
        # ak: Current system parameter (e.g., normalized PAoI)
        ak = min(1.0, env_state['PAoI'] / 1000.0)  # Normalize PAoI
        
        # ok: Current optimization objective (e.g., fairness metric)
        fairness_metrics = self.env.calculate_fairness_metrics(
            env_state['N_v'], env_state['RRI']
        )
        ok = fairness_metrics['fairness_index']
        
        if state_mode == "rri_load":
            # W0k: normalized RRI (agent's controllable knob)
            rri_max = float(max(self.env.R_set)) if self.env.R_set else 1000.0
            W0k = float(env_state.get('RRI', 100.0)) / rri_max if rri_max > 0 else 0.0
            W0k = max(0.0, min(1.0, W0k))

            # n: normalized load (vehicle count)
            n = env_state['N_v'] / self.env.N_max if self.env.N_max > 0 else 0.0
        else:
            # Classic: W0k as load, n as step index (kept for backward compatibility)
            W0k = env_state['N_v'] / self.env.N_max if self.env.N_max > 0 else 0.0
            n = float(len(self.env.history_states))
        
        return [ak, ok, W0k, float(n)]
    
    # Wrapper methods for tools (to avoid returning complex objects)
    def _calculate_system_state_wrapper(self, params_str: str) -> str:
        try:
            params = json.loads(params_str)
            state = self.calculate_system_state(params['RRI'], params['N_v'])
            return to_json(state, indent=2)
        except Exception as e:
            return f"Error calculating system state: {str(e)}"
    
    def _evaluate_paoid_wrapper(self, unused_param: str = "") -> str:
        try:
            evaluation = self.evaluate_paoid()
            return to_json(evaluation, indent=2)
        except Exception as e:
            return f"Error evaluating PAoID: {str(e)}"
    
    def _analyze_fairness_wrapper(self, unused_param: str = "") -> str:
        try:
            evaluation = self.evaluate_paoid()
            return to_json({
                'fairness_index': evaluation['fairness_index'],
                'paoid_diff': evaluation['paoid_diff'],
                'individual_paoids': evaluation['individual_paoids']
            }, indent=2)
        except Exception as e:
            return f"Error analyzing fairness: {str(e)}"
    
    def _optimize_rri_wrapper(self, unused_param: str = "") -> str:
        try:
            optimization = self.optimize_rri()
            return to_json(optimization, indent=2)
        except Exception as e:
            return f"Error optimizing RRI: {str(e)}"
    
    def _adjust_mcs_wrapper(self, unused_param: str = "") -> str:
        try:
            mcs_adjustment = self.adjust_mcs()
            return to_json(mcs_adjustment, indent=2)
        except Exception as e:
            return f"Error adjusting MCS: {str(e)}"
    
    def _simulate_step_wrapper(self, params_str: str) -> str:
        try:
            params = json.loads(params_str)
            agent_mcs = params.get('agent_mcs', 3)  # Default to middle value
            rri_value = params.get('rri', 100)
            
            new_state, terminated = self.env.step(agent_mcs, rri_value)
            
            return to_json({
                'new_state': new_state,
                'terminated': terminated,
                'message': f'Simulation step completed with agent MCS={agent_mcs}, RRI={rri_value}'
            }, indent=2)
        except Exception as e:
            return f"Error simulating step: {str(e)}"
    
    def _get_performance_metrics_wrapper(self, unused_param: str = "") -> str:
        try:
            evaluation = self.evaluate_paoid()
            return to_json({
                'current_paoid': self.current_state['PAoI'],
                'fairness_index': evaluation['fairness_index'],
                'collision_probability': self.current_state['P_coll'],
                'avg_paoid': evaluation['avg_paoid'],
                'paoid_diff': evaluation['paoid_diff']
            }, indent=2)
        except Exception as e:
            return f"Error getting performance metrics: {str(e)}"
    
    def _multi_objective_optimize_wrapper(self, unused_param: str = "") -> str:
        try:
            optimization = self.multi_objective_optimize()
            return to_json(optimization, indent=2)
        except Exception as e:
            return f"Error performing multi-objective optimization: {str(e)}"
    
    def export_results(self, filename: str = "v2x_results.csv"):
        """
        Export the performance results to a CSV file
        """
        if not self.performance_history:
            logger.warning("No performance history to export")
            return
        
        # Create DataFrame from performance history
        df_data = []
        for record in self.performance_history:
            df_record = {
                'timestamp': record['timestamp'],
                'rri': record['rri'],
                'paoid': record['paoid'],
                'fairness': record['fairness'],
                'collision_prob': record['collision_prob'],
                'agent_mcs': record['agent_mcs']
            }
            df_data.append(df_record)
        
        df = pd.DataFrame(df_data)
        df.to_csv(filename, index=False)
        logger.info(f"Results exported to {filename}")
        return filename
    
    def load_from_checkpoint(self, checkpoint_path: str):
        """
        Load the system state from a checkpoint file
        """
        try:
            with open(checkpoint_path, 'rb') as f:
                checkpoint_data = pickle.load(f)
            
            # Restore environment state
            self.env.vehicle_positions = checkpoint_data['env_vehicle_positions']
            self.env.vehicle_speeds = checkpoint_data['env_vehicle_speeds']
            self.env.vehicle_mcs_levels = checkpoint_data['env_vehicle_mcs_levels']
            self.env.N_v = checkpoint_data['env_N_v']
            self.env.current_state = checkpoint_data['env_current_state']
            self.env.history_states = checkpoint_data['env_history_states']
            
            # Restore agent state
            self.agent.q_table = checkpoint_data['agent_q_table']
            self.agent.episode_rewards = checkpoint_data['agent_episode_rewards']
            self.agent.fairness_history = checkpoint_data['agent_fairness_history']
            
            # Restore system state
            self.current_state = checkpoint_data['current_state']
            self.N_v = checkpoint_data['N_v']
            self.performance_history = checkpoint_data['performance_history']
            
            logger.info(f"System loaded from checkpoint: {checkpoint_path}")
            return True
        except Exception as e:
            logger.error(f"Error loading checkpoint: {str(e)}")
            return False
    
    def save_checkpoint(self, checkpoint_path: str):
        """
        Save the current system state to a checkpoint file
        """
        try:
            checkpoint_data = {
                # Environment state
                'env_vehicle_positions': self.env.vehicle_positions,
                'env_vehicle_speeds': self.env.vehicle_speeds,
                'env_vehicle_mcs_levels': self.env.vehicle_mcs_levels,
                'env_N_v': self.env.N_v,
                'env_current_state': self.env.current_state,
                'env_history_states': self.env.history_states,
                
                # Agent state
                'agent_q_table': dict(self.agent.q_table),
                'agent_episode_rewards': self.agent.episode_rewards,
                'agent_fairness_history': self.agent.fairness_history,
                
                # System state
                'current_state': self.current_state,
                'N_v': self.N_v,
                'performance_history': self.performance_history
            }
            
            with open(checkpoint_path, 'wb') as f:
                pickle.dump(checkpoint_data, f)
            
            logger.info(f"System checkpoint saved to: {checkpoint_path}")
            return True
        except Exception as e:
            logger.error(f"Error saving checkpoint: {str(e)}")
            return False
    
    def adaptive_learning_rate(self):
        """
        Adjust learning parameters based on performance trends
        """
        if len(self.performance_history) < 10:
            return  # Need sufficient history to make adjustments
        
        # Get recent performance metrics
        recent_records = self.performance_history[-10:]
        recent_fairness = [record['fairness'] for record in recent_records]
        recent_paoid = [record['paoid'] for record in recent_records]
        
        # Calculate trends
        fairness_trend = np.polyfit(range(len(recent_fairness)), recent_fairness, 1)[0]
        paoid_trend = np.polyfit(range(len(recent_paoid)), recent_paoid, 1)[0]
        
        # Adjust agent's learning parameters based on trends
        if fairness_trend < 0:  # Fairness is decreasing
            # Increase exploration to find better strategies
            self.agent.epsilon = min(0.5, self.agent.epsilon + 0.05)
        elif fairness_trend > 0.01:  # Fairness is improving significantly
            # Decrease exploration to exploit good strategies
            self.agent.epsilon = max(0.05, self.agent.epsilon - 0.02)
        
        if paoid_trend > 0:  # PAoI is increasing (worse)
            # Increase learning rate to adapt faster
            self.agent.learning_rate = min(0.3, self.agent.learning_rate + 0.01)
        elif paoid_trend < -0.1:  # PAoI is decreasing significantly (better)
            # Decrease learning rate to consolidate gains
            self.agent.learning_rate = max(0.05, self.agent.learning_rate - 0.01)
    
    def get_performance_metrics(self) -> Dict:
        """Get current performance metrics for the system"""
        fairness_metrics = self.env.calculate_fairness_metrics(self.N_v, self.current_state['RRI'])
        raafu_metrics = self._calculate_raafu(
            fairness_metrics,
            self.current_state['RRI'],
            self.N_v,
            collision_prob=self.current_state.get('P_coll', 0.0)
        )
        performance_metrics = {
            'paoid': self.current_state.get('PAoI', 0),
            'fairness_index': fairness_metrics.get('fairness_index', 0),
            'raafu': raafu_metrics.get('raafu', 0),
            'collision_probability': self.current_state.get('P_coll', 0),
            'avg_age_of_information': self.current_state.get('AoI_avg', self.current_state.get('PAoI', 0)),
            'max_age_of_information': self.current_state.get('AoI_max', self.current_state.get('PAoI', 0)),
            'efficiency_score': 1.0 / (self.current_state.get('P_coll', 0) + 0.01)  # Higher is better
        }
        return performance_metrics

    def _calculate_system_state_wrapper(self, input_str: str) -> str:
        """Wrapper for calculate_system_state to be used with LangChain tools"""
        try:
            params = eval(input_str) if input_str.strip() else {'RRI': self.current_state['RRI'], 'N_v': self.N_v}
            if isinstance(params, dict):
                rri = params.get('RRI', self.current_state['RRI'])
                n_v = params.get('N_v', self.N_v)
            else:
                # Parse from string if needed
                rri, n_v = self.current_state['RRI'], self.N_v
            result = self.calculate_system_state(RRI=rri, N_v=n_v)
            return to_json(result)
        except Exception as e:
            logger.error(f"Error in _calculate_system_state_wrapper: {e}")
            return to_json({"error": str(e)})

    def _evaluate_paoid_wrapper(self, input_str: str) -> str:
        """Wrapper for evaluate_paoid to be used with LangChain tools"""
        try:
            result = self.evaluate_paoid()
            return to_json(result)
        except Exception as e:
            logger.error(f"Error in _evaluate_paoid_wrapper: {e}")
            return to_json({"error": str(e)})

    def _analyze_fairness_wrapper(self, input_str: str) -> str:
        """Wrapper for analyze_fairness to be used with LangChain tools"""
        try:
            result = self.evaluate_paoid()  # Using evaluate_paoid as it calculates fairness metrics
            return to_json(result)
        except Exception as e:
            logger.error(f"Error in _analyze_fairness_wrapper: {e}")
            return to_json({"error": str(e)})

    def _optimize_rri_wrapper(self, input_str: str) -> str:
        """Wrapper for optimize_rri to be used with LangChain tools"""
        try:
            result = self.optimize_rri()
            return to_json(result)
        except Exception as e:
            logger.error(f"Error in _optimize_rri_wrapper: {e}")
            return to_json({"error": str(e)})

    def _adjust_mcs_wrapper(self, input_str: str) -> str:
        """Wrapper for adjust_mcs to be used with LangChain tools"""
        try:
            result = self.adjust_mcs()
            # Convert numpy types to Python types for JSON serialization
            result = self._convert_to_serializable(result)
            return to_json(result)
        except Exception as e:
            logger.error(f"Error in _adjust_mcs_wrapper: {e}")
            return to_json({"error": str(e)})
    
    def _convert_to_serializable(self, obj):
        """Convert numpy types to Python native types for JSON serialization"""
        if isinstance(obj, dict):
            return {k: self._convert_to_serializable(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._convert_to_serializable(item) for item in obj]
        elif isinstance(obj, (np.int8, np.int16, np.int32, np.int64)):
            return int(obj)
        elif isinstance(obj, (np.float16, np.float32, np.float64)):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return obj

    def _simulate_step_wrapper(self, input_str: str) -> str:
        """Wrapper for simulate_step to be used with LangChain tools"""
        try:
            # Execute environment step with provided action
            params = eval(input_str) if input_str.strip() else {}
            if isinstance(params, dict):
                action = params.get('action', None)
            else:
                action = None
            obs, reward, done, info = self.env.step(action) if action is not None else self.env.step([0, 0])
            result = {
                'observation': obs,
                'reward': reward,
                'done': done,
                'info': info
            }
            return to_json(result)
        except Exception as e:
            logger.error(f"Error in _simulate_step_wrapper: {e}")
            return to_json({"error": str(e)})

    def _get_performance_metrics_wrapper(self, input_str: str) -> str:
        """Wrapper for get_performance_metrics to be used with LangChain tools"""
        try:
            result = self.get_performance_metrics()
            # Convert numpy types to Python types for JSON serialization
            result = self._convert_to_serializable(result)
            return to_json(result)
        except Exception as e:
            logger.error(f"Error in _get_performance_metrics_wrapper: {e}")
            return to_json({"error": str(e)})

    def _multi_objective_optimize_wrapper(self, input_str: str) -> str:
        """Wrapper for multi_objective_optimize to be used with LangChain tools"""
        try:
            result = self.multi_objective_optimize()
            return to_json(result)
        except Exception as e:
            logger.error(f"Error in _multi_objective_optimize_wrapper: {e}")
            return to_json({"error": str(e)})

    def visualize_results(self, save_path: Optional[str] = None):
        """
        Visualize the performance results of the agentic system
        """
        if not self.performance_history:
            logger.warning("No performance history to visualize")
            return
        
        # Prepare data for plotting
        timestamps = [item['timestamp'] for item in self.performance_history]
        paoid_values = [item['paoid'] for item in self.performance_history]
        fairness_values = [item['fairness'] for item in self.performance_history]
        collision_probs = [item['collision_prob'] for item in self.performance_history]
        agent_mcs_levels = [item['agent_mcs'] for item in self.performance_history]
        
        # Create subplots
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        fig.suptitle('V2X SPS Agentic System Performance', fontsize=16)
        
        # Plot 1: PAoI over time
        axes[0, 0].plot(paoid_values, marker='o', linestyle='-', color='blue')
        axes[0, 0].set_title('PAoI Over Time')
        axes[0, 0].set_xlabel('Time Step')
        axes[0, 0].set_ylabel('PAoI')
        axes[0, 0].grid(True)
        
        # Plot 2: Fairness Index over time
        axes[0, 1].plot(fairness_values, marker='s', linestyle='-', color='green')
        axes[0, 1].set_title('Fairness Index Over Time')
        axes[0, 1].set_xlabel('Time Step')
        axes[0, 1].set_ylabel('Fairness Index')
        axes[0, 1].set_ylim(0, 1)
        axes[0, 1].grid(True)
        
        # Plot 3: Collision Probability over time
        axes[1, 0].plot(collision_probs, marker='^', linestyle='-', color='red')
        axes[1, 0].set_title('Collision Probability Over Time')
        axes[1, 0].set_xlabel('Time Step')
        axes[1, 0].set_ylabel('Collision Probability')
        axes[1, 0].grid(True)
        
        # Plot 4: Agent's MCS Level over time
        axes[1, 1].plot(agent_mcs_levels, marker='d', linestyle='-', color='purple')
        axes[1, 1].set_title("Agent's MCS Level Over Time")
        axes[1, 1].set_xlabel('Time Step')
        axes[1, 1].set_ylabel('MCS Level')
        axes[1, 1].set_ylim(-0.5, 6.5)
        axes[1, 1].grid(True)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path)
            logger.info(f"Visualization saved to {save_path}")
        
        plt.show()
    
    def run_comprehensive_analysis(self, episodes: int = 5) -> Dict:
        """
        Run a comprehensive analysis with multiple episodes to evaluate system performance
        """
        logger.info(f"Starting comprehensive analysis with {episodes} episodes")
        
        analysis_results = {
            'episodes_data': [],
            'aggregate_metrics': {},
            'improvement_stats': {}
        }
        
        for episode in range(episodes):
            logger.info(f"Running episode {episode + 1}/{episodes}")
            
            # Reset for new episode
            self.reset()
            
            # Run agentic optimization cycle
            opt_result = self.run_agentic_optimization_cycle()
            
            # Run learning episode
            learn_result = self.run_learning_episode(max_steps=10)
            
            # Apply adaptive learning rate adjustment
            self.adaptive_learning_rate()
            
            # Collect episode data
            episode_data = {
                'episode_num': episode,
                'optimization_result': opt_result,
                'learning_result': learn_result,
                'final_fairness': learn_result['fairness_metrics'][-1]['fairness_index'],
                'final_paoid': learn_result['paoid_values'][-1],
                'avg_reward': np.mean(learn_result['rewards']) if learn_result['rewards'] else 0
            }
            
            analysis_results['episodes_data'].append(episode_data)
        
        # Calculate aggregate metrics
        all_final_fairness = [ep['final_fairness'] for ep in analysis_results['episodes_data']]
        all_final_paoid = [ep['final_paoid'] for ep in analysis_results['episodes_data']]
        all_avg_rewards = [ep['avg_reward'] for ep in analysis_results['episodes_data']]
        
        analysis_results['aggregate_metrics'] = {
            'avg_final_fairness': np.mean(all_final_fairness),
            'std_final_fairness': np.std(all_final_fairness),
            'avg_final_paoid': np.mean(all_final_paoid),
            'std_final_paoid': np.std(all_final_paoid),
            'avg_reward': np.mean(all_avg_rewards),
            'std_reward': np.std(all_avg_rewards)
        }
        
        # Compare with baseline (initial values)
        baseline_fairness = 0.5  # Baseline fairness
        baseline_paoid = 300     # Baseline PAoI
        
        analysis_results['improvement_stats'] = {
            'fairness_improvement': np.mean(all_final_fairness) - baseline_fairness,
            'paoid_reduction': baseline_paoid - np.mean(all_final_paoid),
            'relative_fairness_improvement': (np.mean(all_final_fairness) - baseline_fairness) / baseline_fairness * 100,
            'relative_paoid_reduction': (baseline_paoid - np.mean(all_final_paoid)) / baseline_paoid * 100
        }
        
        logger.info(f"Comprehensive analysis completed")
        return analysis_results


def main():
    """
    Main function to demonstrate the V2X SPS Agentic System
    """
    print("Initializing V2X SPS Agentic System...")
    
    # Initialize the system
    system = V2XSPSAgenticSystem()
    
    print("\nRunning agentic optimization cycle...")
    result = system.run_agentic_optimization_cycle()
    print(f"Agentic optimization result: {result['agent_response'][:200]}...")
    
    print("\nRunning learning episode with single agent control...")
    episode_data = system.run_learning_episode(max_steps=10)
    
    print(f"\nEpisode completed with {len(episode_data['states'])} steps")
    final_fairness = episode_data['fairness_metrics'][-1]['fairness_index']
    final_paoid = episode_data['paoid_values'][-1]
    print(f"Final fairness index: {final_fairness:.3f}")
    print(f"Final PAoI: {final_paoid:.2f}")
    
    # Print agent performance summary
    perf_summary = system.agent.get_performance_summary()
    print(f"\nAgent Performance Summary:")
    print(f"- Average episode reward: {perf_summary['avg_episode_reward']:.3f}")
    print(f"- Average fairness over time: {perf_summary['avg_fairness_over_time']:.3f}")
    print(f"- Total episodes: {perf_summary['total_episodes']}")
    
    print("\nRunning comprehensive analysis...")
    analysis = system.run_comprehensive_analysis(episodes=3)
    
    print(f"\nAnalysis Results:")
    print(f"- Average final fairness: {analysis['aggregate_metrics']['avg_final_fairness']:.3f}")
    print(f"- Average final PAoI: {analysis['aggregate_metrics']['avg_final_paoid']:.2f}")
    print(f"- Fairness improvement: {analysis['improvement_stats']['fairness_improvement']:.3f}")
    print(f"- PAoI reduction: {analysis['improvement_stats']['paoid_reduction']:.2f}")
    
    print("\nSystem demonstration completed successfully!")
    
    # Optionally visualize results
    try:
        system.visualize_results()
    except ImportError:
        print("Matplotlib not available, skipping visualization")


if __name__ == "__main__":
    main()

