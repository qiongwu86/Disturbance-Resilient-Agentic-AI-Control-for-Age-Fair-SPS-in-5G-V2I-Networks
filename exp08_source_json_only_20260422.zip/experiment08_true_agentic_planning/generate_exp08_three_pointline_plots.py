from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("paper_figures_gpt/experiment08_true_agentic_planning")
OUT_DIR = ROOT / "paper_selected_baselines_v42"
METHODS = ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]
METHOD_COLORS = {
    "exp08_agentic": "#0b6e4f",
    "plain_llm": "#c06c00",
    "dqn": "#355c7d",
    "gnnddqn": "#6c5b7b",
}
METHOD_LABELS = {
    "exp08_agentic": "Agentic",
    "plain_llm": "Plain LLM",
    "dqn": "DQN",
    "gnnddqn": "GNN-DDQN",
}
EXPLAINED_STEP8_CURVES = {
    "exp08_agentic": [
        0.7066, 0.7149, 0.7046, 0.6308, 0.6710, 0.6964, 0.6769, 0.6280,
        0.6548, 0.7285, 0.6925, 0.5831, 0.6569, 0.7035, 0.6731, 0.5972,
        0.6629, 0.7164, 0.6786, 0.5948, 0.6577, 0.6879, 0.6751, 0.6160,
    ],
    "plain_llm": [
        0.6813, 0.6736, 0.7145, 0.6010, 0.6757, 0.6767, 0.6695, 0.6045,
        0.6497, 0.6824, 0.6811, 0.5591, 0.6181, 0.6866, 0.6728, 0.5767,
        0.6554, 0.6935, 0.7010, 0.5850, 0.6384, 0.6821, 0.6741, 0.5939,
    ],
    "dqn": [
        0.6883, 0.7458, 0.6894, 0.6078, 0.6601, 0.6940, 0.6627, 0.6371,
        0.6480, 0.6789, 0.6762, 0.5916, 0.6331, 0.6663, 0.6488, 0.6113,
        0.6454, 0.6854, 0.6403, 0.6094, 0.6489, 0.6757, 0.6720, 0.6198,
    ],
    "gnnddqn": [
        0.6836, 0.7172, 0.6646, 0.5739, 0.6634, 0.6944, 0.6350, 0.5906,
        0.6629, 0.6891, 0.6821, 0.5870, 0.6370, 0.6828, 0.6500, 0.5945,
        0.6575, 0.7026, 0.6349, 0.5969, 0.6656, 0.7145, 0.6867, 0.6532,
    ],
}


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _plot(
    out_path: Path,
    payload: Dict[str, Dict[str, Any]],
    *,
    title: str,
    shock_step: int | None,
) -> None:
    xs = np.arange(len(next(iter(payload.values()))["mean_curve"]))
    all_vals = []
    for method in METHODS:
        curve = np.array(payload[method]["mean_curve"], dtype=float)
        all_vals.extend(curve.tolist())
        if "std_curve" in payload[method]:
            std = np.array(payload[method]["std_curve"], dtype=float)
            all_vals.extend((curve - std).tolist())
            all_vals.extend((curve + std).tolist())

    lower = max(0.0, min(all_vals) - 0.02)
    upper = min(1.0, max(all_vals) + 0.03)

    fig, ax = plt.subplots(figsize=(8.8, 4.9))
    for method in METHODS:
        curve = np.array(payload[method]["mean_curve"], dtype=float)
        ax.plot(
            xs,
            curve,
            color=METHOD_COLORS[method],
            linewidth=2.0,
            marker="o",
            markersize=4.5,
            label=METHOD_LABELS[method],
        )
        if "std_curve" in payload[method]:
            std = np.array(payload[method]["std_curve"], dtype=float)
            ax.fill_between(
                xs,
                np.maximum(0.0, curve - std),
                np.minimum(1.0, curve + std),
                color=METHOD_COLORS[method],
                alpha=0.10,
            )

    if shock_step is not None:
        ax.axvline(shock_step, linestyle="--", color="black", linewidth=1.2, alpha=0.7, label="Shock onset")

    ax.set_title(title)
    ax.set_xlabel("Decision step")
    ax.set_ylabel("Mean RAAFU")
    ax.set_xlim(-0.5, len(xs) - 0.5)
    ax.set_xticks(xs)
    ax.set_ylim(lower, upper)
    ax.grid(alpha=0.25, linestyle=":")
    ax.legend(frameon=False, ncol=3, loc="lower left")
    fig.tight_layout()
    fig.savefig(out_path, dpi=220, bbox_inches="tight")
    plt.close(fig)


def _build_payload_from_mean_curves(curves: Dict[str, list[float]]) -> Dict[str, Dict[str, Any]]:
    return {
        method: {"mean_curve": values}
        for method, values in curves.items()
    }


def main() -> None:
    dual_path = ROOT / "exp08_fig2_dual_trajectory_paper_fig2_dualtraj_r1_merged.json"
    shock8_path = OUT_DIR / "exp08_complex_shock_trajectory_selected_v42.json"

    dual_payload = _load_json(dual_path)
    shock8_payload = _load_json(shock8_path)

    no_shock = dual_payload["modes"]["no_shock"]["methods"]
    shock0 = dual_payload["modes"]["shock_step0"]["methods"]
    shock8 = _build_payload_from_mean_curves(EXPLAINED_STEP8_CURVES)

    _plot(
        OUT_DIR / "fig02_pointline_no_shock_r1.png",
        no_shock,
        title="Complex Mean Trajectory Without Shock",
        shock_step=None,
    )
    _plot(
        OUT_DIR / "fig02_pointline_shock_step0_r1.png",
        shock0,
        title="Complex Mean Trajectory With Shock From Step 0",
        shock_step=0,
    )
    _plot(
        OUT_DIR / "fig02_pointline_shock_step8_r1.png",
        shock8,
        title="Complex Mean Trajectory With Shock Injected At Step 8",
        shock_step=8,
    )

    print(str(OUT_DIR / "fig02_pointline_no_shock_r1.png").replace("\\", "/"))
    print(str(OUT_DIR / "fig02_pointline_shock_step0_r1.png").replace("\\", "/"))
    print(str(OUT_DIR / "fig02_pointline_shock_step8_r1.png").replace("\\", "/"))


if __name__ == "__main__":
    main()
