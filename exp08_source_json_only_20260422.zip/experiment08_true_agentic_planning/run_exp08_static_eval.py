from __future__ import annotations

import os
from pathlib import Path
import sys
from typing import Dict, List, Optional

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiment08_true_agentic_planning.formal_eval import run_formal_eval
from experiment08_true_agentic_planning.formal_utils import parse_name_list


def _chunk_suffix(
    scenarios: List[str],
    offsets: Dict[str, int],
    limits: Dict[str, Optional[int]],
) -> str:
    parts = []
    for scenario in scenarios:
        limit = limits.get(scenario)
        offset = int(offsets.get(scenario, 0))
        if offset > 0 or limit is not None:
            limit_text = "all" if limit is None else f"{int(limit):03d}"
            parts.append(f"{scenario}_o{offset:03d}_l{limit_text}")
    return "" if not parts else "__" + "__".join(parts)


def main() -> None:
    output_tag = os.getenv("EXP08_OUTPUT_TAG", "latest")
    baseline_tag = os.getenv("EXP08_BASELINE_TAG", output_tag)
    scenarios = parse_name_list(os.getenv("EXP08_STATIC_SCENARIOS", ""), ["simple", "complex"])
    case_counts = {
        "simple": int(os.getenv("EXP08_STATIC_SIMPLE_CASES", "40")),
        "complex": int(os.getenv("EXP08_STATIC_COMPLEX_CASES", "80")),
    }
    max_steps = {
        "simple": int(os.getenv("EXP08_STATIC_SIMPLE_STEPS", "16")),
        "complex": int(os.getenv("EXP08_STATIC_COMPLEX_STEPS", "24")),
    }
    case_offsets = {
        "simple": int(os.getenv("EXP08_STATIC_SIMPLE_OFFSET", "0")),
        "complex": int(os.getenv("EXP08_STATIC_COMPLEX_OFFSET", "0")),
    }
    case_limits: Dict[str, Optional[int]] = {
        "simple": None if os.getenv("EXP08_STATIC_SIMPLE_LIMIT", "").strip() == "" else int(os.getenv("EXP08_STATIC_SIMPLE_LIMIT", "0")),
        "complex": None if os.getenv("EXP08_STATIC_COMPLEX_LIMIT", "").strip() == "" else int(os.getenv("EXP08_STATIC_COMPLEX_LIMIT", "0")),
    }
    effective_output_tag = output_tag + _chunk_suffix(scenarios, case_offsets, case_limits)
    result = run_formal_eval(
        experiment_type="static_eval",
        scenarios=scenarios,
        case_counts=case_counts,
        max_steps=max_steps,
        output_tag=effective_output_tag,
        baseline_tag=baseline_tag,
        shock_mode=False,
        case_offsets=case_offsets,
        case_limits=case_limits,
    )
    print(result["output_path"])


if __name__ == "__main__":
    main()
