from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("/home/ubuntu24/new_5gnr_modeling/paper_figures_gpt/experiment08_true_agentic_planning")
OUT_DIR = ROOT / "paper_selected_baselines_v42"
SOURCE_JSON = ROOT / "exp08_paired_event_study_paper_paired_event_study_r1.json"
OUT_PNG = OUT_DIR / "fig05b_paired_event_study_absolute_r1.png"

METHODS = ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]
METHOD_LABELS = {
    "exp08_agentic": "Agentic",
    "plain_llm": "Plain LLM",
    "dqn": "DQN",
    "gnnddqn": "GNN-DDQN",
}
METHOD_COLORS = {
    "exp08_agentic": "#0b6e4f",
    "plain_llm": "#c06c00",
    "dqn": "#355c7d",
    "gnnddqn": "#6c5b7b",
}


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _plot_panel(ax: plt.Axes, methods: Dict[str, Any], mode_key: str, title: str, shock_step: int | None, shock_duration: int) -> None:
    xs = np.arange(len(methods[METHODS[0]][mode_key]["mean_curve"]))
    all_vals = []
    for method in METHODS:
        mean_curve = np.array(methods[method][mode_key]["mean_curve"], dtype=float)
        std_curve = np.array(methods[method][mode_key]["std_curve"], dtype=float)
        all_vals.extend(mean_curve.tolist())
        all_vals.extend((mean_curve - std_curve).tolist())
        all_vals.extend((mean_curve + std_curve).tolist())
        ax.plot(
            xs,
            mean_curve,
            marker="o",
            markersize=4.2,
            linewidth=2.0,
            color=METHOD_COLORS[method],
            label=METHOD_LABELS[method],
        )
        ax.fill_between(
            xs,
            np.maximum(0.0, mean_curve - std_curve),
            np.minimum(1.0, mean_curve + std_curve),
            color=METHOD_COLORS[method],
            alpha=0.10,
        )

    if shock_step is not None:
        ax.axvspan(
            shock_step - 0.5,
            shock_step + shock_duration - 0.5,
            color="#bfc7d5",
            alpha=0.28,
            label="Shock window",
        )

    ax.set_title(title)
    ax.set_xlabel("Decision step")
    ax.set_ylabel("Mean RAAFU")
    ax.set_xlim(-0.5, len(xs) - 0.5)
    ax.set_xticks(xs)
    ax.set_ylim(max(0.0, min(all_vals) - 0.02), min(1.0, max(all_vals) + 0.03))
    ax.grid(alpha=0.25, linestyle=":")


def main() -> None:
    payload = _load_json(SOURCE_JSON)
    profile = payload["profiles"][0]
    methods = profile["aggregate"]["methods"]
    shock_step = int(profile["shock_profile_template"]["step"])
    shock_duration = int(profile["shock_profile_template"]["duration"])

    fig, axes = plt.subplots(2, 1, figsize=(9.2, 7.0), sharex=False)

    _plot_panel(
        axes[0],
        methods,
        "no_shock",
        "(a) Absolute mean trajectory without shock",
        None,
        shock_duration,
    )
    axes[0].legend(frameon=False, ncol=3, loc="lower left")

    _plot_panel(
        axes[1],
        methods,
        "shock",
        "(b) Absolute mean trajectory with paired shock injection",
        shock_step,
        shock_duration,
    )
    axes[1].legend(frameon=False, ncol=3, loc="lower left")

    fig.tight_layout()
    fig.savefig(OUT_PNG, dpi=240, bbox_inches="tight")
    plt.close(fig)
    print(str(OUT_PNG))


if __name__ == "__main__":
    main()
