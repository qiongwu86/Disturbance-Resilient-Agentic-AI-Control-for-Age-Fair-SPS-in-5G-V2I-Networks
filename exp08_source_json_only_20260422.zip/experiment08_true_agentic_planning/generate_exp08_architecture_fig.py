from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Polygon


OUT_PATH = Path("paper_figures_gpt/experiment08_true_agentic_planning/paper_selected_baselines_v42/fig00_exp08_architecture_selected_v42.png")


def _box(ax, xy, w, h, title, body, color):
    patch = FancyBboxPatch(
        xy,
        w,
        h,
        boxstyle="round,pad=0.012,rounding_size=0.02",
        linewidth=1.5,
        edgecolor=color,
        facecolor=color,
        alpha=0.12,
    )
    ax.add_patch(patch)
    x, y = xy
    ax.text(x + w / 2, y + h * 0.72, title, ha="center", va="center", fontsize=11, fontweight="bold", color="#1b1b1b")
    ax.text(x + w / 2, y + h * 0.36, body, ha="center", va="center", fontsize=9, color="#1b1b1b")


def _parallelogram(ax, xy, w, h, title, body, color, slant=0.018):
    x, y = xy
    points = [
        (x + slant, y),
        (x + w, y),
        (x + w - slant, y + h),
        (x, y + h),
    ]
    patch = Polygon(points, closed=True, linewidth=1.5, edgecolor=color, facecolor=color, alpha=0.12)
    ax.add_patch(patch)
    ax.text(x + w / 2, y + h * 0.68, title, ha="center", va="center", fontsize=11, fontweight="bold", color="#1b1b1b")
    ax.text(x + w / 2, y + h * 0.34, body, ha="center", va="center", fontsize=9, color="#1b1b1b")


def _diamond(ax, center, w, h, title, body, color):
    cx, cy = center
    points = [
        (cx, cy + h / 2),
        (cx + w / 2, cy),
        (cx, cy - h / 2),
        (cx - w / 2, cy),
    ]
    patch = Polygon(points, closed=True, linewidth=1.5, edgecolor=color, facecolor=color, alpha=0.12)
    ax.add_patch(patch)
    ax.text(cx, cy + h * 0.10, title, ha="center", va="center", fontsize=10.5, fontweight="bold", color="#1b1b1b")
    ax.text(cx, cy - h * 0.16, body, ha="center", va="center", fontsize=8.5, color="#1b1b1b")


def _container(ax, xy, w, h, title, color):
    x, y = xy
    patch = FancyBboxPatch(
        xy,
        w,
        h,
        boxstyle="round,pad=0.012,rounding_size=0.02",
        linewidth=1.5,
        edgecolor=color,
        facecolor=color,
        alpha=0.10,
    )
    ax.add_patch(patch)
    ax.text(x + w / 2, y + h * 0.90, title, ha="center", va="center", fontsize=11, fontweight="bold", color="#1b1b1b")


def _small_box(ax, xy, w, h, title, body, color):
    patch = FancyBboxPatch(
        xy,
        w,
        h,
        boxstyle="round,pad=0.010,rounding_size=0.02",
        linewidth=1.2,
        edgecolor=color,
        facecolor=color,
        alpha=0.12,
    )
    ax.add_patch(patch)
    x, y = xy
    ax.text(x + w / 2, y + h * 0.66, title, ha="center", va="center", fontsize=8.8, fontweight="bold", color="#1b1b1b")
    ax.text(x + w / 2, y + h * 0.28, body, ha="center", va="center", fontsize=8.0, color="#1b1b1b")


def _arrow(ax, start, end, color="#4d4d4d"):
    ax.add_patch(
        FancyArrowPatch(
            start,
            end,
            arrowstyle="-|>",
            mutation_scale=12,
            linewidth=1.5,
            color=color,
        )
    )


def main() -> None:
    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(11.6, 5.4))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    colors = {
        "observe": "#4c956c",
        "plan": "#2a6f97",
        "tools": "#b56576",
        "memory": "#6c757d",
        "commit": "#8f5a2a",
        "reflect": "#5f0f40",
        "io": "#6c757d",
    }

    _parallelogram(ax, (0.02, 0.58), 0.16, 0.20, "Observation", "state digest\nload, PAoI\nshock proxy", colors["io"])
    _box(ax, (0.22, 0.56), 0.20, 0.24, "LLM Agent / Planner", "subgoal\nplanning horizon\ncandidate RRIs\nfunction calls", colors["plan"])
    _box(ax, (0.24, 0.16), 0.18, 0.18, "Memory", "retrieve similar\nepisodes\nstore lesson", colors["memory"])

    _container(ax, (0.47, 0.53), 0.21, 0.30, "SPS Tools", colors["tools"])
    _small_box(ax, (0.49, 0.655), 0.08, 0.055, "Rollout", "score", colors["tools"])
    _small_box(ax, (0.585, 0.655), 0.08, 0.055, "Collision", "risk", colors["tools"])
    _small_box(ax, (0.49, 0.565), 0.08, 0.055, "Memory", "match", colors["tools"])
    _small_box(ax, (0.585, 0.565), 0.08, 0.055, "Counterfactual", "delta", colors["tools"])

    _box(ax, (0.70, 0.58), 0.13, 0.20, "Evidence\nSynthesis", "rank safe\ncandidates", colors["commit"])
    _diamond(ax, (0.89, 0.68), 0.10, 0.15, "Safety Gate", "risk <=\nthreshold", colors["commit"])
    _parallelogram(ax, (0.92, 0.22), 0.07, 0.18, "Action", "chosen\nRRI", colors["io"])
    _box(ax, (0.61, 0.15), 0.16, 0.15, "Reflection", "next-step hint\nupdate lesson", colors["reflect"])

    _arrow(ax, (0.18, 0.68), (0.22, 0.68))
    _arrow(ax, (0.42, 0.68), (0.47, 0.68))
    _arrow(ax, (0.68, 0.68), (0.70, 0.68))
    _arrow(ax, (0.83, 0.68), (0.84, 0.68))
    _arrow(ax, (0.42, 0.25), (0.22 + 0.10, 0.56), color="#6b6b6b")
    _arrow(ax, (0.22 + 0.10, 0.56), (0.42, 0.25), color="#6b6b6b")
    _arrow(ax, (0.90, 0.60), (0.955, 0.40), color="#6b6b6b")
    _arrow(ax, (0.95, 0.22), (0.76, 0.22), color="#6b6b6b")
    _arrow(ax, (0.70, 0.22), (0.60, 0.53), color="#6b6b6b")

    ax.text(0.52, 0.46, "tool outputs", fontsize=8.5, color="#4d4d4d", ha="center")
    ax.text(0.31, 0.39, "retrieve / write", fontsize=8.2, color="#4d4d4d", ha="center")
    ax.text(0.86, 0.48, "commit only after ranking\nand safety filtering", fontsize=8.2, color="#4d4d4d", ha="center")

    fig.tight_layout()
    fig.savefig(OUT_PATH, dpi=240, bbox_inches="tight")
    plt.close(fig)
    print(str(OUT_PATH.resolve()))


if __name__ == "__main__":
    main()
