from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


ROOT = Path("paper_figures_gpt/experiment08_true_agentic_planning")
OUT_DIR = ROOT / "paper_selected_baselines_v42"
METHODS = ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]
METHOD_COLORS = {
    "exp08_agentic": "#0b6e4f",
    "plain_llm": "#c06c00",
    "dqn": "#355c7d",
    "gnnddqn": "#6c5b7b",
}
METHOD_LABELS = {
    "exp08_agentic": "Agentic",
    "plain_llm": "Plain LLM",
    "dqn": "DQN",
    "gnnddqn": "GNN-DDQN",
}


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _save_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def _safe_float(value: Any, default: float = 0.0) -> float:
    if value is None:
        return float(default)
    try:
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _extract_markov_profiles(raw_payload: Dict[str, Any]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for profile in raw_payload.get("profiles", []):
        label = str(profile.get("label", ""))
        if not label.startswith("markovps_"):
            continue
        row = {
            "label": label,
            "markov_ps": _safe_float(profile.get("shock_profile", {}).get("markov_ps", 0.0)),
        }
        summary = profile.get("summary", {})
        for method in ["exp08_agentic", "plain_llm", "dqn", "dqn_strong", "gnnddqn"]:
            row[method] = {
                "mean_raafu": _safe_float(summary.get(method, {}).get("mean_raafu", 0.0)),
                "mean_reward": _safe_float(summary.get(method, {}).get("mean_reward", 0.0)),
                "shock_floor": _safe_float(summary.get(method, {}).get("shock_floor", 0.0)),
                "recovery_integrity": _safe_float(summary.get(method, {}).get("recovery_integrity", 0.0)),
                "shock_response_lag": _safe_float(summary.get(method, {}).get("shock_response_lag", 0.0)),
                "degradation_area": _safe_float(summary.get(method, {}).get("degradation_area", 0.0)),
            }
        rows.append(row)
    rows.sort(key=lambda item: item["markov_ps"])
    return rows


def main() -> None:
    output_tag = os.getenv("EXP08_MARKOV_OUTPUT_TAG", "paper_markov_dense_r1")
    source_tags = [tag.strip() for tag in os.getenv("EXP08_MARKOV_SOURCE_TAGS", "").split(",") if tag.strip()]
    if not source_tags:
        source_tags = [os.getenv("EXP08_MARKOV_SWEEP_TAG", output_tag)]
    out_summary = ROOT / f"exp08_shock_intensity_sweep_markovps_summary_{output_tag}.json"
    out_fig = OUT_DIR / f"fig04_shock_intensity_markovps_dense_{output_tag}.png"

    profiles: List[Dict[str, Any]] = []
    source_paths: List[str] = []
    for sweep_tag in source_tags:
        source_path = ROOT / f"exp08_shock_intensity_sweep_{sweep_tag}.json"
        raw_payload = _load_json(source_path)
        profiles.extend(_extract_markov_profiles(raw_payload))
        source_paths.append(str(source_path).replace("\\", "/"))
    deduped = {row["label"]: row for row in profiles}
    profiles = sorted(deduped.values(), key=lambda item: item["markov_ps"])
    summary_payload = {
        "dimension": "markovps",
        "sources": source_paths,
        "profiles": profiles,
    }
    _save_json(out_summary, summary_payload)

    fig, ax = plt.subplots(figsize=(7.8, 4.5))
    xs = [row["markov_ps"] for row in profiles]
    min_y = 1.0
    max_y = 0.0
    for method in METHODS:
        ys = [row[method]["mean_raafu"] for row in profiles]
        min_y = min(min_y, min(ys))
        max_y = max(max_y, max(ys))
        ax.plot(xs, ys, marker="o", linewidth=2.0, color=METHOD_COLORS[method], label=METHOD_LABELS[method])
    ax.set_title("Disturbance-Intensity Sweep: Markov Volatility")
    ax.set_xlabel("markov_ps")
    ax.set_ylabel("mean RAAFU")
    ax.set_xlim(min(xs) - 0.02, max(xs) + 0.02)
    ax.set_ylim(max(0.0, min_y - 0.01), min(1.0, max_y + 0.02))
    ax.set_xticks(xs)
    ax.grid(alpha=0.3)
    ax.legend(frameon=False, ncol=2)
    fig.tight_layout()
    fig.savefig(out_fig, dpi=220, bbox_inches="tight")
    plt.close(fig)

    print(str(out_summary).replace("\\", "/"))
    print(str(out_fig).replace("\\", "/"))


if __name__ == "__main__":
    main()
