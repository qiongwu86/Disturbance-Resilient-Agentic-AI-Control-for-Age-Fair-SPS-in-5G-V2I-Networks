from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _mean(values: List[float]) -> float:
    return float(sum(values) / len(values)) if values else 0.0


def _load(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _case_row(case: Dict[str, Any]) -> Dict[str, Any]:
    agentic = case["results"]["exp08_agentic"]
    plain = case["results"]["plain_llm"]
    dqn = case["results"].get("dqn", [])
    dqn_strong = case["results"]["dqn_strong"]
    gnnddqn = case["results"]["gnnddqn"]
    shock_profile = dict(case.get("shock_profile") or {})
    agentic_stats = dict(agentic.get("agentic_stats") or {})
    return {
        "case_id": str(case["case_id"]),
        "case_seed": int(case["case_seed"]),
        "extra_vehicles": int(shock_profile.get("extra_vehicles", 0)),
        "rri_change_prob": float(shock_profile.get("rri_change_prob", 0.0)),
        "agentic": float(agentic["mean_raafu"]),
        "plain_llm": float(plain["mean_raafu"]),
        "dqn": _mean([float(item["mean_raafu"]) for item in dqn]),
        "dqn_strong": _mean([float(item["mean_raafu"]) for item in dqn_strong]),
        "gnnddqn": _mean([float(item["mean_raafu"]) for item in gnnddqn]),
        "shock_floor": float(agentic.get("shock_floor", 0.0)),
        "recovery_integrity": float(agentic.get("recovery_integrity", 0.0)),
        "degradation_area": float(agentic.get("degradation_area", 0.0)),
        "shock_response_lag": float(agentic.get("shock_response_lag", 0.0) or 0.0),
        "evidence_alignment_rate": float(agentic_stats.get("evidence_alignment_rate", 0.0)),
        "memory_plan_influence_rate": float(agentic_stats.get("memory_plan_influence_rate", 0.0)),
        "memory_action_override_rate": float(agentic_stats.get("memory_action_override_rate", 0.0)),
        "replan_depth": float(agentic_stats.get("replan_depth", 0.0)),
        "reflection_guidance_rate": float(agentic_stats.get("reflection_guidance_rate", 0.0)),
        "tool_counterfactual_rate": float(agentic_stats.get("tool_counterfactual_rate", 0.0)),
    }


def _summarize_group(rows: List[Dict[str, Any]]) -> Dict[str, float]:
    keys = [
        "shock_floor",
        "recovery_integrity",
        "degradation_area",
        "shock_response_lag",
        "evidence_alignment_rate",
        "memory_plan_influence_rate",
        "memory_action_override_rate",
        "replan_depth",
        "reflection_guidance_rate",
        "tool_counterfactual_rate",
    ]
    return {key: _mean([float(row[key]) for row in rows]) for key in keys}


def main() -> None:
    parser = argparse.ArgumentParser(description="Analyze Route-B shock failures for EXP08.")
    parser.add_argument("--input", required=True, help="Path to merged shock evaluation JSON.")
    parser.add_argument("--top-k", type=int, default=8, help="Number of worst cases to print.")
    args = parser.parse_args()

    payload = _load(Path(args.input))
    rows = []
    for case in payload.get("cases", []):
        row = _case_row(case)
        row["vs_plain_llm"] = float(row["agentic"] - row["plain_llm"])
        row["vs_dqn"] = float(row["agentic"] - row["dqn"])
        row["vs_dqn_strong"] = float(row["agentic"] - row["dqn_strong"])
        row["vs_gnnddqn"] = float(row["agentic"] - row["gnnddqn"])
        rows.append(row)

    wins_vs_dqn_strong = [row for row in rows if row["vs_dqn_strong"] > 0.0]
    losses_vs_dqn_strong = [row for row in rows if row["vs_dqn_strong"] <= 0.0]
    worst_cases = sorted(rows, key=lambda row: row["vs_dqn_strong"])[: max(1, int(args.top_k))]

    by_extra = {}
    for extra_vehicles in sorted({row["extra_vehicles"] for row in rows}):
        subset = [row for row in rows if row["extra_vehicles"] == extra_vehicles]
        by_extra[str(extra_vehicles)] = {
            "count": len(subset),
            "mean_vs_dqn": _mean([row["vs_dqn"] for row in subset]),
            "mean_vs_dqn_strong": _mean([row["vs_dqn_strong"] for row in subset]),
            "mean_vs_gnnddqn": _mean([row["vs_gnnddqn"] for row in subset]),
        }

    result = {
        "input": str(args.input),
        "summary": {
            "count": len(rows),
            "mean_vs_plain_llm": _mean([row["vs_plain_llm"] for row in rows]),
            "mean_vs_dqn": _mean([row["vs_dqn"] for row in rows]),
            "mean_vs_dqn_strong": _mean([row["vs_dqn_strong"] for row in rows]),
            "mean_vs_gnnddqn": _mean([row["vs_gnnddqn"] for row in rows]),
            "wins_vs_dqn_strong": len(wins_vs_dqn_strong),
            "losses_vs_dqn_strong": len(losses_vs_dqn_strong),
        },
        "by_extra_vehicles": by_extra,
        "wins_vs_dqn_strong_stats": _summarize_group(wins_vs_dqn_strong),
        "losses_vs_dqn_strong_stats": _summarize_group(losses_vs_dqn_strong),
        "worst_cases_vs_dqn_strong": worst_cases,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
