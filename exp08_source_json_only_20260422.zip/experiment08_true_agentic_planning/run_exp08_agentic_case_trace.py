from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiment08_true_agentic_planning.formal_utils import build_case_seeds, make_shock_profile, save_json, set_global_seed
from experiment08_true_agentic_planning.planner_led_v2x_system import PlannerLedAgenticSystem, PlannerLedConfig


def main() -> None:
    parser = argparse.ArgumentParser(description="Rerun a single EXP08 agentic case with full traces.")
    parser.add_argument("--scenario", default="complex", choices=["simple", "complex"])
    parser.add_argument("--case-idx", type=int, required=True)
    parser.add_argument("--shock", action="store_true")
    parser.add_argument("--max-steps", type=int, default=None)
    parser.add_argument("--tag", default="latest")
    args = parser.parse_args()

    scenario = str(args.scenario)
    total_cases = 32 if scenario == "complex" else 24
    base_seed = 2000 if scenario == "complex" else 1000
    case_seeds = build_case_seeds(total_cases, base_seed=base_seed)
    case_seed = int(case_seeds[int(args.case_idx)])
    shock_profile = make_shock_profile(scenario, case_seed) if args.shock else None
    max_steps = int(args.max_steps or (24 if scenario == "complex" else 20))
    if shock_profile is not None:
        shock_profile = dict(shock_profile)
        shock_profile["step"] = min(int(shock_profile.get("step", 0)), max(1, max_steps - 2))

    set_global_seed(case_seed)
    config = PlannerLedConfig(
        use_llm=os.getenv("EXP08_USE_LLM", "0") == "1",
        strict_llm=False,
        model_name=os.getenv("EXP08_MODEL", "openai/gpt-4o-mini"),
        base_url=os.getenv("OPENAI_BASE_URL", ""),
        api_key=os.getenv("OPENAI_API_KEY", ""),
    )
    system = PlannerLedAgenticSystem(config=config, seed=case_seed)
    result = system.run_episode(scenario=scenario, max_steps=max_steps, shock_profile=shock_profile)

    payload = {
        "scenario": scenario,
        "case_idx": int(args.case_idx),
        "case_seed": case_seed,
        "shock": bool(args.shock),
        "shock_profile": shock_profile,
        "result": result,
    }
    output_path = Path("paper_figures_gpt/experiment08_true_agentic_planning/traces") / f"exp08_agentic_trace_{args.tag}_{scenario}_{int(args.case_idx):03d}{'_shock' if args.shock else ''}.json"
    save_json(output_path, payload)
    print(str(output_path).replace("\\", "/"))


if __name__ == "__main__":
    main()
