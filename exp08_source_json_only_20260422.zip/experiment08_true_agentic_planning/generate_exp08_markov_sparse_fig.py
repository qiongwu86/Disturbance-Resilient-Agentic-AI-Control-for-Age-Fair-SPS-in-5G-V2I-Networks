from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


ROOT = Path("/home/ubuntu24/new_5gnr_modeling/paper_figures_gpt/experiment08_true_agentic_planning")
OUT_DIR = ROOT / "paper_selected_baselines_v42"
SOURCE_JSON = ROOT / "exp08_shock_intensity_sweep_markovps_summary_paper_markov_dense_r1_merged.json"
OUT_PNG = OUT_DIR / "fig04b_shock_intensity_markovps_sparse024681_r1.png"
OUT_PNG_PAPER = OUT_DIR / "fig04b_markov_sparse_r1.png"

TARGET_XS = [0.2, 0.4, 0.6, 0.8, 1.0]
METHODS = ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]
METHOD_LABELS = {
    "exp08_agentic": "Agentic",
    "plain_llm": "Plain LLM",
    "dqn": "DQN",
    "gnnddqn": "GNN-DDQN",
}
METHOD_COLORS = {
    "exp08_agentic": "#0b6e4f",
    "plain_llm": "#c06c00",
    "dqn": "#355c7d",
    "gnnddqn": "#6c5b7b",
}


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    payload = _load_json(SOURCE_JSON)
    all_profiles: List[Dict[str, Any]] = payload["profiles"]

    selected = []
    for target in TARGET_XS:
        matched = None
        for row in all_profiles:
            if abs(float(row["markov_ps"]) - target) < 1e-9:
                matched = row
                break
        if matched is None:
            raise ValueError(f"markov_ps={target} not found in source summary")
        selected.append(matched)

    xs = [float(row["markov_ps"]) for row in selected]
    plt.rcParams.update(
        {
            "font.size": 11,
            "axes.labelsize": 13,
            "axes.titlesize": 13,
            "axes.labelweight": "bold",
            "axes.titleweight": "bold",
            "xtick.labelsize": 11,
            "ytick.labelsize": 11,
            "legend.fontsize": 11,
        }
    )
    fig, ax = plt.subplots(figsize=(8.5, 4.9))
    min_y = 1.0
    max_y = 0.0
    for method in METHODS:
        ys = [float(row[method]["mean_raafu"]) for row in selected]
        min_y = min(min_y, min(ys))
        max_y = max(max_y, max(ys))
        ax.plot(
            xs,
            ys,
            marker="o",
            markersize=5.8,
            linewidth=2.6,
            color=METHOD_COLORS[method],
            label=METHOD_LABELS[method],
        )

    ax.set_title("Disturbance-Intensity Sweep: Markov Volatility (0.2, 0.4, 0.6, 0.8, 1.0)", fontweight="bold")
    ax.set_xlabel("markov_ps", fontweight="bold")
    ax.set_ylabel("mean RAAFU", fontweight="bold")
    ax.set_xticks(xs)
    ax.set_xlim(min(xs) - 0.03, max(xs) + 0.03)
    ax.set_ylim(max(0.0, min_y - 0.01), min(1.0, max_y + 0.02))
    ax.grid(alpha=0.25, linestyle=":")
    ax.legend(frameon=False, ncol=2, prop={"weight": "bold", "size": 11})
    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_fontweight("bold")

    fig.tight_layout()
    fig.savefig(OUT_PNG, dpi=240, bbox_inches="tight")
    fig.savefig(OUT_PNG_PAPER, dpi=240, bbox_inches="tight")
    plt.close(fig)
    print(str(OUT_PNG_PAPER))


if __name__ == "__main__":
    main()
