from __future__ import annotations

import json
import os
import random
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

import numpy as np

try:
    from langchain_core.messages import HumanMessage, SystemMessage
    from langchain_openai import ChatOpenAI
except Exception:  # pragma: no cover - optional dependency
    ChatOpenAI = None
    HumanMessage = None
    SystemMessage = None

from agentic_v2x_system import V2XEnvironment

from .common import build_metrics
from .planner_led_v2x_system import configure_environment_for_scenario


@dataclass
class PlainLLMBaselineConfig:
    use_llm: bool = True
    strict_llm: bool = False
    model_name: str = "gpt-4o-mini"
    base_url: str = ""
    api_key: str = ""
    temperature: float = 0.0
    timeout_seconds: int = 40
    llm_max_retries: int = 2


class PlainLLMBaseline:
    def __init__(self, config: Optional[PlainLLMBaselineConfig] = None, *, seed: int = 0) -> None:
        self.config = config or PlainLLMBaselineConfig()
        self.seed = int(seed)
        random.seed(self.seed)
        np.random.seed(self.seed)
        self.env = V2XEnvironment()
        self.llm = self._init_llm()

    def _init_llm(self):
        if not self.config.use_llm or ChatOpenAI is None:
            return None
        api_key = self.config.api_key or os.getenv("OPENAI_API_KEY", "")
        if not api_key:
            return None
        kwargs = {
            "model": self.config.model_name,
            "temperature": self.config.temperature,
            "timeout": self.config.timeout_seconds,
            "api_key": api_key,
        }
        base_url = self.config.base_url or os.getenv("OPENAI_BASE_URL", "")
        if base_url:
            kwargs["base_url"] = base_url
        try:
            return ChatOpenAI(**kwargs)
        except Exception:
            return None

    @staticmethod
    def _extract_first_json_object(text: str) -> str:
        start = text.find("{")
        if start < 0:
            raise ValueError("No JSON object found in model output.")
        depth = 0
        for idx in range(start, len(text)):
            char = text[idx]
            if char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    return text[start : idx + 1]
        raise ValueError("Unterminated JSON object in model output.")

    def _invoke_json(self, system_prompt: str, user_payload: Dict[str, Any]) -> Dict[str, Any]:
        if self.llm is None or HumanMessage is None or SystemMessage is None:
            raise RuntimeError("LLM is not configured.")
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=json.dumps(user_payload, ensure_ascii=False)),
        ]
        last_error = None
        for _ in range(max(1, self.config.llm_max_retries)):
            try:
                response = self.llm.invoke(messages)
                raw = response.content if hasattr(response, "content") else str(response)
                raw_json = self._extract_first_json_object(raw if isinstance(raw, str) else str(raw))
                return json.loads(raw_json)
            except Exception as exc:  # pragma: no cover - network-dependent
                last_error = exc
                error_text = str(exc).lower()
                if "401" in error_text or "unauthorized" in error_text or "404" in error_text or "not found" in error_text:
                    self.llm = None
                    break
        if self.config.strict_llm and last_error is not None:
            raise last_error
        raise RuntimeError("Failed to obtain valid JSON from LLM.")

    def reset(self, scenario: str) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        configure_environment_for_scenario(self.env, scenario)
        state = dict(self.env.current_state)
        metrics = build_metrics(self.env, state)
        return state, metrics

    def choose_action(self, state: Dict[str, Any], metrics: Dict[str, Any], *, shock_flag: bool) -> Dict[str, Any]:
        if self.llm is not None:
            payload = {
                "observation": {
                    "n_v": int(state.get("N_v", self.env.N_v)),
                    "current_rri": int(state.get("RRI", 100)),
                    "paoi": float(state.get("PAoI", 0.0)),
                    "collision_prob": float(state.get("P_coll", 0.0)),
                    "fairness_index": float(metrics.get("fairness_index", 0.0)),
                    "raafu": float(metrics.get("raafu", 0.0)),
                    "shock_flag": bool(shock_flag),
                },
                "action_space": {
                    "valid_rris": [int(x) for x in self.env.R_set],
                    "branch_options": ["keep", "reselect"],
                },
                "instruction": (
                    "Choose one immediate SPS action to improve age fairness while limiting collision risk. "
                    "This baseline has no tools, no memory, and no multi-step planning."
                ),
            }
            try:
                result = self._invoke_json(
                    "You are a plain single-shot LLM controller baseline for V2X SPS. "
                    "Return JSON only with chosen_rri, final_branch, confidence, rationale.",
                    payload,
                )
                chosen_rri = int(result.get("chosen_rri", state.get("RRI", 100)))
                if chosen_rri not in self.env.R_set:
                    chosen_rri = min(self.env.R_set, key=lambda value: abs(int(value) - chosen_rri))
                branch = str(result.get("final_branch", "keep")).strip().lower()
                if branch not in {"keep", "reselect"}:
                    branch = "keep"
                return {
                    "chosen_rri": int(chosen_rri),
                    "force_reselect": bool(branch == "reselect"),
                    "confidence": float(result.get("confidence", 0.5)),
                    "rationale": str(result.get("rationale", "")),
                    "used_llm": True,
                }
            except Exception:
                pass

        current_rri = int(state.get("RRI", 100))
        paoi = float(state.get("PAoI", 0.0))
        collision = float(state.get("P_coll", 0.0))
        if collision >= 0.25:
            chosen_rri = min([int(x) for x in self.env.R_set if int(x) >= current_rri] or [max(self.env.R_set)])
            branch = "reselect"
        elif paoi >= 800:
            chosen_rri = max([int(x) for x in self.env.R_set if int(x) <= max(current_rri, 100)] or [min(self.env.R_set)])
            branch = "reselect"
        else:
            chosen_rri = current_rri
            branch = "keep"
        return {
            "chosen_rri": int(chosen_rri),
            "force_reselect": bool(branch == "reselect"),
            "confidence": 0.4,
            "rationale": "heuristic single-shot fallback",
            "used_llm": False,
        }
