from __future__ import annotations

import json
import os
import random
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

try:
    from langchain_core.messages import HumanMessage, SystemMessage
    from langchain_openai import ChatOpenAI
except Exception:  # pragma: no cover - optional dependency
    ChatOpenAI = None
    HumanMessage = None
    SystemMessage = None

from agentic_v2x_system import V2XEnvironment

from .common import build_metrics, compute_reward, entropy_from_counts
from .memory_store import EpisodicMemoryStore, MemoryRecord
from .planner_schema import ALLOWED_TOOLS, AnalysisReport, CommitPlan, DraftPlan, ObservationDigest, ReflectionNote
from .tool_registry import ToolRegistry


def configure_environment_for_scenario(env: V2XEnvironment, scenario: str) -> V2XEnvironment:
    scenario_name = str(scenario).strip().lower()
    if scenario_name == "complex":
        env.lambda_v = 0.85
        env.mu_v = 0.70
        env.N_max = 9
        env.min_active_vehicles = 3
        env.other_rri_mode = "markov_pingpong"
        env.other_rri_markov_states = [20.0, 50.0, 100.0, 200.0, 500.0]
        env.other_rri_markov_ps = 1.0
        env.rri_change_prob = 0.65
        env.fairness_mode = "paper_afu_sps_norm"
        env.enable_early_termination = False
    else:
        env.lambda_v = 0.35
        env.mu_v = 0.25
        env.N_max = 7
        env.min_active_vehicles = 2
        env.other_rri_mode = "fixed"
        env.other_rri_value = 100.0
        env.rri_change_prob = 0.10
        env.fairness_mode = "paper_afu_sps_norm"
        env.enable_early_termination = False
    env.num_vehicles = int(env.N_max)
    env.vehicle_positions = np.zeros(env.num_vehicles)
    env.vehicle_speeds = np.random.uniform(10, 30, env.num_vehicles)
    env.vehicle_mcs_levels = np.random.randint(0, 7, env.num_vehicles)
    env.reset()
    return env


@dataclass
class PlannerLedConfig:
    use_llm: bool = True
    strict_llm: bool = False
    model_name: str = "gpt-4o-mini"
    base_url: str = ""
    api_key: str = ""
    temperature: float = 0.1
    timeout_seconds: int = 40
    max_tools_per_step: int = 3
    max_memory_hits: int = 3
    safety_collision_threshold: float = 0.35
    replan_reward_threshold: float = -0.02
    evidence_replan_gain_margin: float = 0.002
    shock_drop_replan_threshold: float = 0.040
    subgoal_failure_replan_count: int = 3
    max_replans_per_step: int = 1
    memory_max_records: int = 500
    llm_max_retries: int = 2
    reflection_enable: bool = True
    default_mcs_action: int = 3


class PlannerLedAgenticSystem:
    def __init__(self, config: Optional[PlannerLedConfig] = None, *, seed: int = 0) -> None:
        self.config = config or PlannerLedConfig()
        self.seed = int(seed)
        random.seed(self.seed)
        np.random.seed(self.seed)

        self.env = V2XEnvironment()
        self.memory = EpisodicMemoryStore(max_records=self.config.memory_max_records)
        self.tools = ToolRegistry(self)
        self.llm = self._init_llm()

        self.current_state: Dict[str, Any] = {}
        self.current_metrics: Dict[str, Any] = {}
        self.previous_metrics: Dict[str, Any] = {}
        self.previous_branch: str = "keep"
        self.previous_reward: float = 0.0
        self.current_scenario: str = "simple"
        self.last_trace: Optional[Dict[str, Any]] = None
        self.tool_counts: Dict[str, int] = {name: 0 for name in ALLOWED_TOOLS}
        self.memory_changed_count = 0
        self.memory_plan_influence_count = 0
        self.memory_action_override_count = 0
        self.memory_query_count = 0
        self.evidence_alignment_count = 0
        self.replan_count = 0
        self.explicit_replan_count = 0
        self.reflection_guidance_count = 0
        self.success_count = 0
        self.fallback_count = 0
        self.safety_override_count = 0
        self.step_count = 0
        self.consecutive_failed_subgoals = 0
        self.last_reflection_hint = ""
        self.last_avoid_action_pattern = ""
        self.last_subgoal_adjustment = ""

    def _init_llm(self):
        if not self.config.use_llm or ChatOpenAI is None:
            return None
        api_key = self.config.api_key or os.getenv("OPENAI_API_KEY", "")
        if not api_key:
            return None
        kwargs = {
            "model": self.config.model_name,
            "temperature": self.config.temperature,
            "timeout": self.config.timeout_seconds,
            "api_key": api_key,
        }
        base_url = self.config.base_url or os.getenv("OPENAI_BASE_URL", "")
        if base_url:
            kwargs["base_url"] = base_url
        try:
            return ChatOpenAI(**kwargs)
        except Exception:
            return None

    @staticmethod
    def _extract_first_json_object(text: str) -> str:
        start = text.find("{")
        if start < 0:
            raise ValueError("No JSON object found in model output.")
        depth = 0
        for idx in range(start, len(text)):
            char = text[idx]
            if char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    return text[start : idx + 1]
        raise ValueError("Unterminated JSON object in model output.")

    def _invoke_json(self, system_prompt: str, user_payload: Dict[str, Any]) -> Dict[str, Any]:
        if self.llm is None or HumanMessage is None or SystemMessage is None:
            raise RuntimeError("LLM is not configured.")
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=json.dumps(user_payload, ensure_ascii=False)),
        ]
        last_error: Optional[Exception] = None
        for _ in range(max(1, self.config.llm_max_retries)):
            try:
                response = self.llm.invoke(messages)
                raw = response.content if hasattr(response, "content") else str(response)
                raw_json = self._extract_first_json_object(raw if isinstance(raw, str) else str(raw))
                return json.loads(raw_json)
            except Exception as exc:  # pragma: no cover - network-dependent
                last_error = exc
                error_text = str(exc).lower()
                if "401" in error_text or "unauthorized" in error_text or "404" in error_text or "not found" in error_text:
                    self.llm = None
                    break
        if self.config.strict_llm and last_error is not None:
            raise last_error
        raise RuntimeError("Failed to obtain valid JSON from LLM.")

    def reset(self, scenario: str = "simple") -> Dict[str, Any]:
        self.current_scenario = str(scenario)
        configure_environment_for_scenario(self.env, scenario)
        self.current_state = dict(self.env.current_state)
        self.current_metrics = build_metrics(self.env, self.current_state)
        self.previous_metrics = dict(self.current_metrics)
        self.previous_branch = "keep"
        self.previous_reward = 0.0
        self.last_trace = None
        self.tool_counts = {name: 0 for name in ALLOWED_TOOLS}
        self.memory_changed_count = 0
        self.memory_plan_influence_count = 0
        self.memory_action_override_count = 0
        self.memory_query_count = 0
        self.evidence_alignment_count = 0
        self.replan_count = 0
        self.explicit_replan_count = 0
        self.reflection_guidance_count = 0
        self.success_count = 0
        self.fallback_count = 0
        self.safety_override_count = 0
        self.step_count = 0
        self.consecutive_failed_subgoals = 0
        self.last_reflection_hint = ""
        self.last_avoid_action_pattern = ""
        self.last_subgoal_adjustment = ""
        return self.current_state

    def build_observation(self, *, shock_flag: bool) -> ObservationDigest:
        return ObservationDigest(
            n_v=int(self.current_state.get("N_v", self.env.N_v)),
            current_rri=int(self.current_state.get("RRI", 100)),
            paoi=float(self.current_state.get("PAoI", 0.0)),
            collision_prob=float(self.current_state.get("P_coll", 0.0)),
            fairness_index=float(self.current_metrics.get("fairness_index", 0.0)),
            raafu=float(self.current_metrics.get("raafu", 0.0)),
            shock_flag=bool(shock_flag),
            previous_branch=self.previous_branch,
            previous_reward=float(self.previous_reward),
            last_reflection_hint=self.last_reflection_hint,
            last_avoid_action_pattern=self.last_avoid_action_pattern,
            last_subgoal_adjustment=self.last_subgoal_adjustment,
        )

    def analyze(self, observation: ObservationDigest) -> AnalysisReport:
        if self.llm is not None:
            payload = {
                "observation": observation.to_dict(),
                "allowed_output_keys": [
                    "traffic_level",
                    "stability_level",
                    "conflict_level",
                    "urgency",
                    "dominant_risk",
                    "reasoning",
                ],
                "valid_levels": {
                    "traffic_level": ["low", "medium", "high"],
                    "stability_level": ["stable", "mixed", "volatile"],
                    "conflict_level": ["low", "medium", "high"],
                    "urgency": ["low", "medium", "high"],
                },
            }
            try:
                result = self._invoke_json(
                    "You are the Situation Analysis Agent for a V2X SPS controller. Return a compact JSON object only.",
                    payload,
                )
                return AnalysisReport(
                    traffic_level=str(result.get("traffic_level", "medium")),
                    stability_level=str(result.get("stability_level", "mixed")),
                    conflict_level=str(result.get("conflict_level", "medium")),
                    urgency=str(result.get("urgency", "medium")),
                    dominant_risk=str(result.get("dominant_risk", "balanced")),
                    reasoning=str(result.get("reasoning", "")),
                )
            except Exception:
                pass

        n_v = int(observation.n_v)
        traffic_level = "low" if n_v <= 3 else "medium" if n_v <= 6 else "high"
        if observation.shock_flag or observation.previous_reward < -0.05:
            stability_level = "volatile"
        elif observation.collision_prob <= 0.15:
            stability_level = "stable"
        else:
            stability_level = "mixed"
        conflict_level = "low" if observation.collision_prob <= 0.10 else "medium" if observation.collision_prob <= 0.25 else "high"
        urgency = "low" if observation.paoi <= 350 else "medium" if observation.paoi <= 800 else "high"
        if observation.collision_prob >= 0.25:
            dominant_risk = "collision"
        elif observation.paoi >= 800:
            dominant_risk = "staleness"
        elif observation.fairness_index <= 0.80:
            dominant_risk = "fairness"
        else:
            dominant_risk = "balanced"
        return AnalysisReport(
            traffic_level=traffic_level,
            stability_level=stability_level,
            conflict_level=conflict_level,
            urgency=urgency,
            dominant_risk=dominant_risk,
            reasoning="heuristic analysis fallback",
        )

    def draft_plan(self, observation: ObservationDigest, analysis: AnalysisReport) -> DraftPlan:
        default_query = EpisodicMemoryStore.build_query_spec(observation.to_dict(), analysis.to_dict())
        if self.llm is not None:
            payload = {
                "observation": observation.to_dict(),
                "analysis": analysis.to_dict(),
                "rri_candidates": list(self.env.R_set),
                "allowed_tools": list(ALLOWED_TOOLS),
                "constraints": {
                    "max_tools_per_step": self.config.max_tools_per_step,
                    "branch_options": ["keep", "reselect"],
                    "tool_sequence_rule": "tool_sequence must contain 1 to 3 tools and cannot be empty",
                },
            }
            try:
                result = self._invoke_json(
                    "You are the Planning Agent for a planner-led V2X SPS controller. "
                    "Return only JSON. tool_sequence must contain 1 to 3 tools from the allowed set.",
                    payload,
                )
                plan = DraftPlan(
                    subgoal=str(result.get("subgoal", "stabilize fairness")),
                    planning_horizon=int(result.get("planning_horizon", 2)),
                    branch_decision=str(result.get("branch_decision", "keep")),
                    candidate_rris=list(result.get("candidate_rris", [])),
                    tool_sequence=list(result.get("tool_sequence", [])),
                    memory_query_spec=dict(result.get("memory_query_spec", default_query)),
                    fallback_policy=str(result.get("fallback_policy", "safe_rri")),
                    confidence=float(result.get("confidence", 0.5)),
                    rationale=str(result.get("rationale", "")),
                ).normalized()
                candidate_rris = plan.candidate_rris or self._default_candidate_rris(observation, analysis)
                candidate_rris = self._apply_reflection_bias_to_candidates(candidate_rris, observation)
                tool_sequence = self._enforce_tool_sequence(plan.tool_sequence, observation, analysis)
                branch_decision, subgoal = self._apply_reflection_bias_to_plan_shape(
                    plan.branch_decision,
                    plan.subgoal,
                    observation,
                    analysis,
                )
                if candidate_rris != plan.candidate_rris or tool_sequence != plan.tool_sequence or branch_decision != plan.branch_decision or subgoal != plan.subgoal:
                    plan = DraftPlan(
                        subgoal=subgoal,
                        planning_horizon=plan.planning_horizon,
                        branch_decision=branch_decision,
                        candidate_rris=candidate_rris,
                        tool_sequence=tool_sequence,
                        memory_query_spec=plan.memory_query_spec,
                        fallback_policy=plan.fallback_policy,
                        confidence=plan.confidence,
                        rationale=f"{plan.rationale} | dynamic planner fallback".strip(),
                    ).normalized()
                return plan
            except Exception:
                pass

        current_rri = int(observation.current_rri)
        if analysis.dominant_risk == "collision":
            candidates = [value for value in self.env.R_set if value >= current_rri] or [max(self.env.R_set)]
            tools = ["constraint_check", "rollout_candidates", "memory_query"]
            branch = "reselect"
            subgoal = "reduce collision while preserving fairness"
        elif analysis.dominant_risk == "staleness":
            candidates = [value for value in self.env.R_set if value <= max(current_rri, 100)] or [min(self.env.R_set)]
            tools = ["rollout_candidates", "counterfactual"]
            if observation.shock_flag or len(self.memory) > 0:
                tools.append("memory_query")
            branch = "reselect" if observation.paoi > 900 else "keep"
            subgoal = "recover freshness without fairness collapse"
        else:
            lower = max(0, self.env.R_set.index(current_rri) - 1) if current_rri in self.env.R_set else 0
            upper = min(len(self.env.R_set), lower + 3)
            candidates = self.env.R_set[lower:upper] or list(self.env.R_set)
            tools = ["state_digest", "rollout_candidates"]
            if observation.shock_flag or analysis.stability_level == "volatile":
                tools.append("memory_query")
            branch = "keep" if analysis.stability_level == "stable" else "reselect"
            subgoal = "improve age fairness with bounded risk"
        candidates = self._apply_reflection_bias_to_candidates([int(x) for x in candidates[:4]], observation)
        branch, subgoal = self._apply_reflection_bias_to_plan_shape(branch, subgoal, observation, analysis)
        return DraftPlan(
            subgoal=subgoal,
            planning_horizon=2 if analysis.stability_level != "volatile" else 3,
            branch_decision=branch,
            candidate_rris=candidates,
            tool_sequence=self._enforce_tool_sequence(tools[: self.config.max_tools_per_step], observation, analysis),
            memory_query_spec=default_query,
            fallback_policy="safe_rri",
            confidence=0.60,
            rationale="heuristic planner fallback",
        ).normalized()

    def _apply_reflection_bias_to_candidates(
        self,
        candidate_rris: List[int],
        observation: ObservationDigest,
    ) -> List[int]:
        deduped: List[int] = []
        for value in candidate_rris:
            item = int(value)
            if item in self.env.R_set and item not in deduped:
                deduped.append(item)

        if not deduped:
            deduped = [int(self.local_optimal_rri())]

        current_rri = int(observation.current_rri)
        if observation.last_avoid_action_pattern == "stick_with_current_without_gain" and current_rri in deduped and len(deduped) > 1:
            deduped = [item for item in deduped if item != current_rri] + [current_rri]

        if observation.last_subgoal_adjustment == "prioritize_fairness_jump":
            target = int(self.local_optimal_rri())
            if target in deduped:
                deduped.remove(target)
            deduped.insert(0, target)

        return deduped[:4]

    @staticmethod
    def _apply_reflection_bias_to_plan_shape(
        branch: str,
        subgoal: str,
        observation: ObservationDigest,
        analysis: AnalysisReport,
    ) -> Tuple[str, str]:
        next_branch = str(branch)
        next_subgoal = str(subgoal)
        if observation.last_subgoal_adjustment == "prioritize_fairness_jump":
            next_subgoal = "recover fairness with stronger action change"
            if analysis.dominant_risk != "collision":
                next_branch = "reselect"
        elif observation.last_subgoal_adjustment == "prioritize_collision_guard":
            next_subgoal = "reduce collision before secondary fairness gains"
        elif observation.last_subgoal_adjustment == "recover_stability_first":
            next_subgoal = "recover stability before aggressive fairness tuning"
        return next_branch, next_subgoal

    @staticmethod
    def _merge_unique_rris(*groups: List[int], valid_rris: List[int]) -> List[int]:
        merged: List[int] = []
        for group in groups:
            for value in group:
                item = int(value)
                if item in valid_rris and item not in merged:
                    merged.append(item)
        return merged

    def _build_explicit_replan_observation(
        self,
        observation: ObservationDigest,
        reason: str,
    ) -> ObservationDigest:
        hint_map = {
            "shock_volatile": ("query_memory_then_replan", "repeat_pre_shock_action", "recover_stability_first"),
            "weak_gain_complex": ("prefer_evidence_best_candidate", "stick_with_current_without_gain", "prioritize_fairness_jump"),
            "reflection_guided": (
                "prefer_evidence_best_candidate",
                observation.last_avoid_action_pattern or "stick_with_current_without_gain",
                observation.last_subgoal_adjustment or "prioritize_fairness_jump",
            ),
            "subgoal_failure": ("prefer_evidence_best_candidate", "stick_with_current_without_gain", "prioritize_fairness_jump"),
        }
        next_hint, avoid_pattern, subgoal_adjustment = hint_map.get(
            str(reason),
            (
                observation.last_reflection_hint or "prefer_evidence_best_candidate",
                observation.last_avoid_action_pattern or "stick_with_current_without_gain",
                observation.last_subgoal_adjustment or "prioritize_fairness_jump",
            ),
        )
        return ObservationDigest(
            n_v=int(observation.n_v),
            current_rri=int(observation.current_rri),
            paoi=float(observation.paoi),
            collision_prob=float(observation.collision_prob),
            fairness_index=float(observation.fairness_index),
            raafu=float(observation.raafu),
            shock_flag=bool(observation.shock_flag),
            previous_branch=str(observation.previous_branch),
            previous_reward=float(observation.previous_reward),
            last_reflection_hint=str(next_hint),
            last_avoid_action_pattern=str(avoid_pattern),
            last_subgoal_adjustment=str(subgoal_adjustment),
        )

    def _should_explicit_replan(
        self,
        observation: ObservationDigest,
        analysis: AnalysisReport,
        evidence_bundle: Dict[str, Any],
    ) -> Optional[str]:
        reflection_guided = str(observation.last_reflection_hint).strip().lower() in {
            "query_memory_then_replan",
            "prefer_evidence_best_candidate",
            "raise_rri_and_check_constraints",
        }
        if reflection_guided and (
            (bool(observation.shock_flag) and float(observation.previous_reward) < 0.0)
            or self.consecutive_failed_subgoals >= max(1, int(self.config.subgoal_failure_replan_count) - 1)
        ):
            return "reflection_guided"

        preferred_gain = float(evidence_bundle.get("preferred_rollout_gain", 0.0))

        if (
            bool(observation.shock_flag)
            and str(analysis.stability_level).strip().lower() == "volatile"
            and preferred_gain < 0.0
        ):
            return "shock_volatile"

        if self.consecutive_failed_subgoals >= max(1, int(self.config.subgoal_failure_replan_count)):
            return "subgoal_failure"

        if (
            self.current_scenario == "complex"
            and bool(observation.shock_flag)
            and float(observation.previous_reward) < 0.0
            and float(observation.raafu) < 0.70
            and preferred_gain < float(self.config.evidence_replan_gain_margin)
        ):
            return "weak_gain_complex"
        return None

    def _explicit_replan(
        self,
        observation: ObservationDigest,
        analysis: AnalysisReport,
        draft_plan: DraftPlan,
        memory_records: List[MemoryRecord],
        evidence_bundle: Dict[str, Any],
        reason: str,
    ) -> Tuple[DraftPlan, List[MemoryRecord], Dict[str, Any], Dict[str, Any]]:
        replan_observation = self._build_explicit_replan_observation(observation, reason)
        redraft = self.draft_plan(replan_observation, analysis)

        preferred_rris = [
            int(evidence_bundle.get("preferred_rri", observation.current_rri)),
            int(evidence_bundle.get("rollout_preferred_rri", observation.current_rri)),
            int(self.local_optimal_rri()),
            int(observation.current_rri),
        ]
        candidate_rris = self._merge_unique_rris(
            redraft.candidate_rris,
            draft_plan.candidate_rris,
            preferred_rris,
            valid_rris=[int(value) for value in self.env.R_set],
        )
        requested_tools = ["rollout_candidates", "memory_query", "counterfactual"]
        if str(analysis.dominant_risk).strip().lower() == "collision":
            requested_tools.append("constraint_check")
        tool_sequence = self._enforce_tool_sequence(requested_tools, replan_observation, analysis)
        replanned_draft = DraftPlan(
            subgoal=str(redraft.subgoal or draft_plan.subgoal),
            planning_horizon=max(int(draft_plan.planning_horizon), int(redraft.planning_horizon), 3 if observation.shock_flag else 2),
            branch_decision="reselect" if observation.shock_flag or str(reason) == "subgoal_failure" else str(redraft.branch_decision or draft_plan.branch_decision),
            candidate_rris=candidate_rris[:5],
            tool_sequence=tool_sequence,
            memory_query_spec=dict(redraft.memory_query_spec or draft_plan.memory_query_spec or {}),
            fallback_policy=str(redraft.fallback_policy or draft_plan.fallback_policy),
            confidence=max(float(draft_plan.confidence), float(redraft.confidence), 0.65),
            rationale=f"{redraft.rationale} | explicit replan: {reason}".strip(),
        ).normalized()

        if "memory_query" in replanned_draft.tool_sequence:
            self.memory_query_count += 1
            replan_memory_records = self.memory.query(replanned_draft.memory_query_spec, limit=self.config.max_memory_hits)
        else:
            replan_memory_records = memory_records
        replan_tool_outputs = self.tools.run(
            replanned_draft.tool_sequence,
            replanned_draft,
            EpisodicMemoryStore.summarize(replan_memory_records),
        )
        for tool_name in replanned_draft.tool_sequence:
            if tool_name in self.tool_counts:
                self.tool_counts[tool_name] += 1
        replan_evidence = self._synthesize_evidence(
            replan_observation,
            analysis,
            replanned_draft,
            replan_memory_records,
            replan_tool_outputs,
        )
        return replanned_draft, replan_memory_records, replan_tool_outputs, replan_evidence

    def _default_tool_sequence(self, observation: ObservationDigest, analysis: AnalysisReport) -> List[str]:
        if analysis.dominant_risk == "collision":
            tools = ["constraint_check", "rollout_candidates"]
        elif analysis.dominant_risk == "staleness":
            tools = ["rollout_candidates", "counterfactual"]
        else:
            tools = ["state_digest", "rollout_candidates"]
        if observation.shock_flag or analysis.stability_level == "volatile" or len(self.memory) > 0:
            if "memory_query" not in tools:
                tools.append("memory_query")
        return tools[: self.config.max_tools_per_step]

    def _enforce_tool_sequence(
        self,
        requested_tools: List[str],
        observation: ObservationDigest,
        analysis: AnalysisReport,
    ) -> List[str]:
        tools: List[str] = []
        for item in requested_tools:
            name = str(item).strip().lower()
            if name in ALLOWED_TOOLS and name not in tools:
                tools.append(name)

        if "rollout_candidates" not in tools:
            tools.append("rollout_candidates")

        need_memory = bool(
            observation.shock_flag
            or analysis.stability_level == "volatile"
            or self.current_scenario == "complex"
            or len(self.memory) >= 5
            or float(observation.previous_reward) < self.config.replan_reward_threshold
        )
        if need_memory and "memory_query" not in tools:
            if len(tools) < self.config.max_tools_per_step:
                tools.append("memory_query")
            elif "state_digest" in tools:
                tools[tools.index("state_digest")] = "memory_query"
            else:
                tools[-1] = "memory_query"

        if analysis.dominant_risk == "collision" and "constraint_check" not in tools:
            if len(tools) < self.config.max_tools_per_step:
                tools.append("constraint_check")
            elif "state_digest" in tools and "memory_query" in tools:
                tools[tools.index("state_digest")] = "constraint_check"

        if analysis.dominant_risk == "staleness" and "counterfactual" not in tools:
            if len(tools) < self.config.max_tools_per_step:
                tools.append("counterfactual")
            elif "constraint_check" in tools and float(observation.collision_prob) < 0.10:
                tools[tools.index("constraint_check")] = "counterfactual"

        low_collision_regime = float(observation.collision_prob) < min(0.05, self.config.safety_collision_threshold * 0.25)
        need_counterfactual = bool(
            self.current_scenario == "complex"
            and (
                analysis.dominant_risk in {"fairness", "staleness"}
                or float(observation.raafu) < 0.74
                or float(observation.fairness_index) < 0.35
            )
        )
        if need_counterfactual and "counterfactual" not in tools:
            if len(tools) < self.config.max_tools_per_step:
                tools.append("counterfactual")
            elif "constraint_check" in tools and low_collision_regime:
                tools[tools.index("constraint_check")] = "counterfactual"

        deduped: List[str] = []
        for name in tools:
            if name in ALLOWED_TOOLS and name not in deduped:
                deduped.append(name)
        return deduped[: self.config.max_tools_per_step]

    def _default_candidate_rris(self, observation: ObservationDigest, analysis: AnalysisReport) -> List[int]:
        current_rri = int(observation.current_rri)
        if self.current_scenario == "complex":
            candidates: List[int] = [current_rri, int(self.local_optimal_rri())]
            ordered = [int(value) for value in self.env.R_set]
            if current_rri in ordered:
                center = ordered.index(current_rri)
                for offset in (-2, -1, 1, 2):
                    idx = center + offset
                    if 0 <= idx < len(ordered):
                        candidates.append(int(ordered[idx]))
            if analysis.dominant_risk == "collision":
                candidates.extend(int(value) for value in ordered if int(value) >= current_rri)
            elif analysis.dominant_risk == "staleness":
                candidates.extend(int(value) for value in ordered if int(value) <= max(current_rri, 100))
            else:
                candidates.extend(int(value) for value in ordered)
            deduped: List[int] = []
            for value in candidates:
                if value in self.env.R_set and value not in deduped:
                    deduped.append(int(value))
            return deduped[:4] if deduped else [int(self.local_optimal_rri())]

        if analysis.dominant_risk == "collision":
            candidates = [int(value) for value in self.env.R_set if int(value) >= current_rri]
        elif analysis.dominant_risk == "staleness":
            candidates = [int(value) for value in self.env.R_set if int(value) <= max(current_rri, 100)]
        else:
            if current_rri in self.env.R_set:
                center = self.env.R_set.index(current_rri)
                left = max(0, center - 1)
                right = min(len(self.env.R_set), center + 2)
                candidates = [int(value) for value in self.env.R_set[left:right]]
            else:
                candidates = [int(value) for value in self.env.R_set]
        return candidates[:4] if candidates else [int(self.local_optimal_rri())]

    def commit_plan(
        self,
        observation: ObservationDigest,
        analysis: AnalysisReport,
        draft_plan: DraftPlan,
        memory_records: List[MemoryRecord],
        tool_outputs: Dict[str, Any],
        evidence_bundle: Optional[Dict[str, Any]] = None,
    ) -> Tuple[CommitPlan, bool]:
        evidence_bundle = evidence_bundle or self._synthesize_evidence(
            observation,
            analysis,
            draft_plan,
            memory_records,
            tool_outputs,
        )
        memory_payload = EpisodicMemoryStore.summarize(memory_records)
        if self.llm is not None:
            payload = {
                "observation": observation.to_dict(),
                "analysis": analysis.to_dict(),
                "draft_plan": draft_plan.to_dict(),
                "memory_records": memory_payload,
                "tool_outputs": tool_outputs,
                "evidence_synthesis": evidence_bundle,
                "constraints": {
                    "valid_rris": list(self.env.R_set),
                    "branch_options": ["keep", "reselect"],
                    "collision_threshold": self.config.safety_collision_threshold,
                },
            }
            try:
                result = self._invoke_json(
                    "You are the Commit Agent for a planner-led V2X SPS controller. Return only JSON.",
                    payload,
                )
                commit = CommitPlan(
                    chosen_rri=int(result.get("chosen_rri", observation.current_rri)),
                    backup_rri=int(result.get("backup_rri", self.safe_high_rri())),
                    final_branch=str(result.get("final_branch", draft_plan.branch_decision)),
                    expected_gain=float(result.get("expected_gain", 0.0)),
                    expected_risk=float(result.get("expected_risk", observation.collision_prob)),
                    evidence_refs=list(result.get("evidence_refs", [])),
                    replan_trigger=bool(result.get("replan_trigger", False)),
                    rationale=str(result.get("rationale", "")),
                ).normalized()
                commit = self._stabilize_commit_plan(
                    commit,
                    observation,
                    analysis,
                    draft_plan,
                    memory_records,
                    tool_outputs,
                    evidence_bundle,
                )
                return commit, self._memory_changes_plan(draft_plan, commit, memory_records, tool_outputs, evidence_bundle)
            except Exception:
                pass

        commit = self._build_evidence_commit(observation, analysis, draft_plan, memory_records, tool_outputs, evidence_bundle)
        return commit, self._memory_changes_plan(draft_plan, commit, memory_records, tool_outputs, evidence_bundle)

    @staticmethod
    def _rollout_candidate_map(tool_outputs: Dict[str, Any]) -> Dict[int, Dict[str, Any]]:
        candidates = tool_outputs.get("rollout_candidates", {}).get("candidates", [])
        return {int(item.get("rri", -1)): dict(item) for item in candidates}

    @staticmethod
    def _memory_record_value(record: MemoryRecord) -> float:
        outcome = record.observed_outcome
        base = float(outcome.get("raafu", 0.0)) + 0.35 * float(outcome.get("fairness_index", 0.0)) - 8.0 * float(
            outcome.get("collision_prob", 0.0)
        )
        lesson_tag = str(record.lesson_tag).strip().lower()
        if lesson_tag in {"successful_recovery", "stabilized", "improved_fairness"}:
            base += 0.05
        elif lesson_tag in {"failed_adjustment", "safety_override"}:
            base -= 0.08
        return base

    def _memory_bonus_map(self, memory_records: List[MemoryRecord]) -> Dict[int, float]:
        bonus_map: Dict[int, float] = {}
        for record in memory_records:
            rri = int(record.committed_plan.get("chosen_rri", record.current_rri))
            raw_bonus = self._memory_record_value(record) - 0.72
            clipped_bonus = max(-0.08, min(0.08, float(raw_bonus)))
            bonus_map[rri] = float(bonus_map.get(rri, 0.0) + clipped_bonus)
        return bonus_map

    def _synthesize_evidence(
        self,
        observation: ObservationDigest,
        analysis: AnalysisReport,
        draft_plan: DraftPlan,
        memory_records: List[MemoryRecord],
        tool_outputs: Dict[str, Any],
    ) -> Dict[str, Any]:
        rollout_map = self._rollout_candidate_map(tool_outputs)
        safe_candidates = {
            int(item["rri"])
            for item in tool_outputs.get("constraint_check", {}).get("safe_candidates", [])
        }
        memory_bonus_map = self._memory_bonus_map(memory_records)
        counterfactual = dict(tool_outputs.get("counterfactual", {}))
        counterfactual_rri = int(counterfactual.get("best_counterfactual_rri", -1))
        counterfactual_gain = float(counterfactual.get("counterfactual_gain", 0.0))

        candidate_pool: List[int] = []
        for value in draft_plan.candidate_rris:
            item = int(value)
            if item in self.env.R_set and item not in candidate_pool:
                candidate_pool.append(item)
        for value in rollout_map.keys():
            item = int(value)
            if item in self.env.R_set and item not in candidate_pool:
                candidate_pool.append(item)
        for value in memory_bonus_map.keys():
            item = int(value)
            if item in self.env.R_set and item not in candidate_pool:
                candidate_pool.append(item)
        if not candidate_pool:
            candidate_pool = [int(observation.current_rri)]

        rankings: List[Dict[str, Any]] = []
        for rri in candidate_pool:
            rollout_item = rollout_map.get(int(rri))
            if rollout_item is None:
                predicted_state = self.env.calculate_system_state(float(rri), int(observation.n_v))
                predicted_metrics = build_metrics(self.env, predicted_state)
                rollout_score = float(self.score_metrics(predicted_metrics, self.current_metrics))
                rollout_gain = float(rollout_score - self.score_metrics(self.current_metrics, self.previous_metrics))
                rollout_raafu = float(predicted_metrics.get("raafu", 0.0))
            else:
                rollout_score = float(rollout_item.get("score", -1e9))
                rollout_gain = float(rollout_item.get("delta_vs_current", 0.0))
                rollout_raafu = float(rollout_item.get("raafu", 0.0))
            safe = bool(not safe_candidates or int(rri) in safe_candidates)
            memory_bonus = float(memory_bonus_map.get(int(rri), 0.0))
            counterfactual_bonus = 0.0
            if int(rri) == counterfactual_rri and counterfactual_gain > 0.0:
                counterfactual_bonus = min(0.03, 0.5 * float(counterfactual_gain))
            rankings.append(
                {
                    "rri": int(rri),
                    "safe": safe,
                    "rollout_score": rollout_score,
                    "rollout_gain": rollout_gain,
                    "rollout_raafu": rollout_raafu,
                    "memory_bonus": memory_bonus,
                    "counterfactual_bonus": counterfactual_bonus,
                    "synth_score": rollout_score + memory_bonus + counterfactual_bonus,
                }
            )

        rankings.sort(key=lambda item: (item["safe"], item["rollout_score"]), reverse=True)
        rollout_preferred = dict(rankings[0])
        best_rollout_score = float(rollout_preferred["rollout_score"])
        best_rollout_gain = float(rollout_preferred["rollout_gain"])
        for item in rankings:
            if item["memory_bonus"] > 0.0 and (
                item["rollout_score"] < best_rollout_score - 0.015 or item["rollout_gain"] < best_rollout_gain - 0.01
            ):
                item["synth_score"] = item["rollout_score"] + min(0.005, item["counterfactual_bonus"])

        rankings.sort(key=lambda item: (item["safe"], item["synth_score"], item["rollout_gain"]), reverse=True)
        preferred = dict(rankings[0])
        memory_preferred_rri = None
        if memory_bonus_map:
            memory_preferred_rri = max(memory_bonus_map.items(), key=lambda item: item[1])[0]

        memory_plan_influence = bool(
            memory_records
            and (
                int(preferred["rri"]) != int(rollout_preferred["rri"])
                or abs(float(preferred.get("memory_bonus", 0.0))) > 1e-9
            )
        )
        memory_action_override = bool(
            memory_records
            and int(preferred["rri"]) != int(rollout_preferred["rri"])
            and float(preferred.get("memory_bonus", 0.0)) > 0.0
        )
        return {
            "preferred_rri": int(preferred["rri"]),
            "rollout_preferred_rri": int(rollout_preferred["rri"]),
            "memory_preferred_rri": None if memory_preferred_rri is None else int(memory_preferred_rri),
            "preferred_rollout_gain": float(preferred["rollout_gain"]),
            "preferred_rollout_score": float(preferred["rollout_score"]),
            "preferred_synth_score": float(preferred["synth_score"]),
            "memory_plan_influence": bool(memory_plan_influence),
            "memory_action_override": bool(memory_action_override),
            "counterfactual_used": bool("counterfactual" in tool_outputs),
            "rankings": rankings[:4],
            "alignment_reason": "memory_override" if memory_action_override else "rollout_aligned",
        }

    def _build_evidence_commit(
        self,
        observation: ObservationDigest,
        analysis: AnalysisReport,
        draft_plan: DraftPlan,
        memory_records: List[MemoryRecord],
        tool_outputs: Dict[str, Any],
        evidence_bundle: Optional[Dict[str, Any]] = None,
    ) -> CommitPlan:
        evidence_bundle = evidence_bundle or self._synthesize_evidence(
            observation,
            analysis,
            draft_plan,
            memory_records,
            tool_outputs,
        )
        safe_candidates = {
            int(item["rri"])
            for item in tool_outputs.get("constraint_check", {}).get("safe_candidates", [])
        }
        chosen_rri = int(evidence_bundle.get("preferred_rri", observation.current_rri))
        if safe_candidates and chosen_rri not in safe_candidates:
            chosen_rri = int(evidence_bundle.get("rollout_preferred_rri", chosen_rri))

        evidence_refs = list(tool_outputs.keys())
        if evidence_bundle.get("memory_plan_influence") and "memory_query" not in evidence_refs:
            evidence_refs.append("memory_query")

        if chosen_rri not in self.env.R_set:
            chosen_rri = self.local_optimal_rri()
        predicted_state = self.env.calculate_system_state(float(chosen_rri), int(observation.n_v))
        predicted_metrics = build_metrics(self.env, predicted_state)
        expected_gain = self.score_metrics(predicted_metrics, self.current_metrics) - self.score_metrics(
            self.current_metrics,
            self.previous_metrics,
        )
        expected_risk = float(predicted_state.get("P_coll", observation.collision_prob))
        branch = "reselect" if chosen_rri != observation.current_rri else draft_plan.branch_decision
        if analysis.dominant_risk == "collision" and chosen_rri < observation.current_rri:
            branch = "reselect"
        return CommitPlan(
            chosen_rri=int(chosen_rri),
            backup_rri=self.safe_high_rri(),
            final_branch=branch,
            expected_gain=float(max(expected_gain, float(evidence_bundle.get("preferred_rollout_gain", expected_gain)))),
            expected_risk=expected_risk,
            evidence_refs=evidence_refs,
            replan_trigger=bool(expected_gain < self.config.replan_reward_threshold),
            rationale="evidence-driven commit fallback",
        ).normalized()

    def _stabilize_commit_plan(
        self,
        commit: CommitPlan,
        observation: ObservationDigest,
        analysis: AnalysisReport,
        draft_plan: DraftPlan,
        memory_records: List[MemoryRecord],
        tool_outputs: Dict[str, Any],
        evidence_bundle: Optional[Dict[str, Any]] = None,
    ) -> CommitPlan:
        evidence_bundle = evidence_bundle or self._synthesize_evidence(
            observation,
            analysis,
            draft_plan,
            memory_records,
            tool_outputs,
        )
        evidence_commit = self._build_evidence_commit(
            observation,
            analysis,
            draft_plan,
            memory_records,
            tool_outputs,
            evidence_bundle,
        )
        is_vacuous = (
            (not commit.evidence_refs)
            or (commit.chosen_rri == int(observation.current_rri) and commit.final_branch == "keep" and commit.expected_gain <= 0.0)
            or (not commit.rationale.strip())
        )
        if is_vacuous and evidence_commit.expected_gain > 0.0:
            return evidence_commit

        if not commit.evidence_refs:
            commit = CommitPlan(
                chosen_rri=commit.chosen_rri,
                backup_rri=commit.backup_rri,
                final_branch=commit.final_branch,
                expected_gain=commit.expected_gain,
                expected_risk=commit.expected_risk,
                evidence_refs=evidence_commit.evidence_refs,
                replan_trigger=commit.replan_trigger,
                rationale=commit.rationale or "llm commit with evidence fill",
            ).normalized()

        if commit.chosen_rri not in self.env.R_set:
            return evidence_commit

        rollout_map = self._rollout_candidate_map(tool_outputs)
        evidence_rollout = rollout_map.get(int(evidence_commit.chosen_rri))
        commit_rollout = rollout_map.get(int(commit.chosen_rri))
        evidence_score = float(evidence_rollout.get("score", -1e9)) if evidence_rollout else -1e9
        commit_score = float(commit_rollout.get("score", -1e9)) if commit_rollout else -1e9
        evidence_gain = float(evidence_rollout.get("delta_vs_current", evidence_commit.expected_gain)) if evidence_rollout else float(
            evidence_commit.expected_gain
        )
        commit_gain = float(commit_rollout.get("delta_vs_current", commit.expected_gain)) if commit_rollout else float(commit.expected_gain)
        strong_evidence_advantage = bool(
            evidence_commit.chosen_rri != commit.chosen_rri
            and evidence_score >= commit_score + 0.01
            and evidence_gain >= commit_gain + 0.01
            and evidence_commit.expected_risk <= self.config.safety_collision_threshold
        )
        if self.current_scenario == "complex" and strong_evidence_advantage:
            return evidence_commit

        if (
            self.current_scenario == "complex"
            and int(commit.chosen_rri) == int(observation.current_rri)
            and int(evidence_commit.chosen_rri) != int(observation.current_rri)
            and evidence_gain > 0.015
            and evidence_commit.expected_risk <= self.config.safety_collision_threshold
        ):
            return evidence_commit

        return commit

    def reflect(
        self,
        reward: float,
        new_metrics: Dict[str, Any],
        commit_plan: CommitPlan,
        safety_overridden: bool,
        shock_flag: bool,
    ) -> ReflectionNote:
        if not self.config.reflection_enable:
            return ReflectionNote(
                success=reward >= 0.0,
                lesson="reflection disabled",
                should_replan=False,
                lesson_tag="disabled",
                next_step_hint="none",
                avoid_action_pattern="none",
                subgoal_adjustment="keep_subgoal",
            )

        if self.llm is not None:
            payload = {
                "reward": reward,
                "new_metrics": new_metrics,
                "commit_plan": commit_plan.to_dict(),
                "safety_overridden": safety_overridden,
                "shock_flag": shock_flag,
                "allowed_output_keys": [
                    "success",
                    "lesson",
                    "should_replan",
                    "lesson_tag",
                    "next_step_hint",
                    "avoid_action_pattern",
                    "subgoal_adjustment",
                ],
            }
            try:
                result = self._invoke_json(
                    "You are the Reflection Agent for a planner-led V2X SPS controller. Return only JSON.",
                    payload,
                )
                note = ReflectionNote(
                    success=bool(result.get("success", reward >= 0.0)),
                    lesson=str(result.get("lesson", "")),
                    should_replan=bool(result.get("should_replan", reward < self.config.replan_reward_threshold)),
                    lesson_tag=str(result.get("lesson_tag", "reflective_update")),
                    next_step_hint=str(result.get("next_step_hint", "")),
                    avoid_action_pattern=str(result.get("avoid_action_pattern", "")),
                    subgoal_adjustment=str(result.get("subgoal_adjustment", "")),
                )
                note = self._stabilize_reflection(note, reward, new_metrics, commit_plan, safety_overridden, shock_flag)
                if note.lesson.strip():
                    return note
            except Exception:
                pass

        success = bool(
            reward >= 0.0
            and float(new_metrics.get("raafu", 0.0)) >= float(self.current_metrics.get("raafu", 0.0)) * 0.98
        )
        if safety_overridden:
            lesson_tag = "safety_override"
            lesson = "Predicted risk was too high, so the safety guard replaced the committed action."
            next_step_hint = "raise_rri_and_check_constraints"
            avoid_action_pattern = "unsafe_low_rri"
            subgoal_adjustment = "prioritize_collision_guard"
        elif shock_flag and not success:
            lesson_tag = "shock_recovery"
            lesson = "Shock degraded fairness enough to require replanning on the next decision."
            next_step_hint = "query_memory_then_replan"
            avoid_action_pattern = "repeat_pre_shock_action"
            subgoal_adjustment = "recover_stability_first"
        elif success:
            lesson_tag = "successful_recovery"
            lesson = "The committed action preserved or improved fairness without large collision growth."
            next_step_hint = "maintain_or_small_adjust"
            avoid_action_pattern = "none"
            subgoal_adjustment = "keep_subgoal"
        else:
            lesson_tag = "failed_adjustment"
            lesson = "The committed action did not improve the current balance of freshness and collision risk."
            next_step_hint = "prefer_evidence_best_candidate"
            avoid_action_pattern = "stick_with_current_without_gain"
            subgoal_adjustment = "prioritize_fairness_jump"
        should_replan = bool((not success) or reward < self.config.replan_reward_threshold or shock_flag)
        return ReflectionNote(
            success=success,
            lesson=lesson,
            should_replan=should_replan,
            lesson_tag=lesson_tag,
            next_step_hint=next_step_hint,
            avoid_action_pattern=avoid_action_pattern,
            subgoal_adjustment=subgoal_adjustment,
        )

    def _stabilize_reflection(
        self,
        note: ReflectionNote,
        reward: float,
        new_metrics: Dict[str, Any],
        commit_plan: CommitPlan,
        safety_overridden: bool,
        shock_flag: bool,
    ) -> ReflectionNote:
        current_raafu = float(self.current_metrics.get("raafu", 0.0))
        new_raafu = float(new_metrics.get("raafu", current_raafu))
        shock_drop = max(0.0, current_raafu - new_raafu)
        forced_replan = bool(
            safety_overridden
            or bool(commit_plan.replan_trigger)
            or (shock_flag and shock_drop >= float(self.config.shock_drop_replan_threshold))
            or ((not note.success) and (self.consecutive_failed_subgoals + 1) >= max(1, int(self.config.subgoal_failure_replan_count)))
            or (reward < self.config.replan_reward_threshold)
        )

        next_step_hint = str(note.next_step_hint or "")
        avoid_action_pattern = str(note.avoid_action_pattern or "")
        subgoal_adjustment = str(note.subgoal_adjustment or "")
        lesson_tag = str(note.lesson_tag or "reflective_update")
        lesson = str(note.lesson or "")

        if bool(note.success) and not forced_replan:
            next_step_hint = "maintain_or_small_adjust"
            avoid_action_pattern = "none"
            subgoal_adjustment = "keep_subgoal"

        if forced_replan and not next_step_hint:
            next_step_hint = "query_memory_then_replan" if shock_flag else "prefer_evidence_best_candidate"
        if forced_replan and not avoid_action_pattern:
            avoid_action_pattern = "repeat_pre_shock_action" if shock_flag else "stick_with_current_without_gain"
        if forced_replan and not subgoal_adjustment:
            subgoal_adjustment = "recover_stability_first" if shock_flag else "prioritize_fairness_jump"
        if forced_replan and not lesson:
            lesson = "Forced replanning was enabled because the current outcome did not satisfy stability or progress conditions."
        if forced_replan and lesson_tag == "reflective_update":
            lesson_tag = "forced_replan"

        return ReflectionNote(
            success=bool(note.success),
            lesson=lesson,
            should_replan=bool(note.should_replan or forced_replan),
            lesson_tag=lesson_tag,
            next_step_hint=next_step_hint,
            avoid_action_pattern=avoid_action_pattern,
            subgoal_adjustment=subgoal_adjustment,
        )

    def local_optimal_rri(self) -> int:
        n_v = max(1, int(self.current_state.get("N_v", self.env.N_v)))
        table = {1: 20, 2: 50, 3: 100, 4: 100, 5: 200, 6: 200, 7: 300, 8: 500, 9: 500}
        target = int(table.get(n_v, 500))
        return min(self.env.R_set, key=lambda item: abs(int(item) - target))

    def safe_high_rri(self) -> int:
        current_rri = int(self.current_state.get("RRI", self.env.R_set[0]))
        safe_pool = [int(item) for item in self.env.R_set if int(item) >= current_rri]
        return int(safe_pool[0] if safe_pool else max(self.env.R_set))

    def score_metrics(self, current_metrics: Dict[str, Any], previous_metrics: Dict[str, Any]) -> float:
        paoi = float(current_metrics.get("system_paoid", current_metrics.get("avg_paoid", 0.0)))
        paoi_score = float(np.exp(-paoi / 1200.0))
        raafu = float(current_metrics.get("raafu", 0.0))
        fairness = float(current_metrics.get("fairness_index", 0.0))
        collision = float(current_metrics.get("collision_prob", 0.0))
        delta = raafu - float(previous_metrics.get("raafu", raafu))
        return float(0.50 * raafu + 0.20 * fairness + 0.15 * paoi_score + 0.10 * (1.0 - collision) + 0.05 * delta)

    def safety_check(self, commit_plan: CommitPlan) -> Tuple[int, bool, bool]:
        chosen_rri = int(commit_plan.chosen_rri)
        predicted_state = self.env.calculate_system_state(float(chosen_rri), int(self.current_state.get("N_v", self.env.N_v)))
        predicted_collision = float(predicted_state.get("P_coll", 0.0))
        overridden = False
        if predicted_collision > self.config.safety_collision_threshold:
            backup_rri = int(commit_plan.backup_rri if commit_plan.backup_rri in self.env.R_set else self.safe_high_rri())
            backup_state = self.env.calculate_system_state(float(backup_rri), int(self.current_state.get("N_v", self.env.N_v)))
            if float(backup_state.get("P_coll", 1.0)) <= predicted_collision:
                chosen_rri = backup_rri
            else:
                chosen_rri = self.safe_high_rri()
            overridden = True
        force_reselect = bool(commit_plan.final_branch == "reselect" or chosen_rri != int(self.current_state.get("RRI", 100)))
        return int(chosen_rri), force_reselect, overridden

    def _apply_shock(self, shock_profile: Optional[Dict[str, Any]]) -> None:
        if not shock_profile:
            return
        extra_vehicles = int(shock_profile.get("extra_vehicles", 2))
        self.env.N_v = min(self.env.N_max, int(self.env.N_v) + max(0, extra_vehicles))
        self.env.other_rri_mode = str(shock_profile.get("other_rri_mode", "markov_pingpong"))
        self.env.rri_change_prob = float(shock_profile.get("rri_change_prob", 0.75))
        if "markov_ps" in shock_profile:
            self.env.other_rri_markov_ps = float(shock_profile.get("markov_ps", self.env.other_rri_markov_ps))
        self.env.other_rri_markov_states = list(shock_profile.get("markov_states", [20.0, 50.0, 100.0, 200.0, 500.0]))
        for idx in range(1, min(int(self.env.N_v), int(self.env.N_max))):
            self.env.rri_per_vehicle[idx] = float(random.choice(self.env.other_rri_markov_states))

    def _capture_shock_baseline(self) -> Dict[str, Any]:
        return {
            "N_v": int(self.env.N_v),
            "other_rri_mode": str(getattr(self.env, "other_rri_mode", "random")),
            "rri_change_prob": float(getattr(self.env, "rri_change_prob", 0.0)),
            "other_rri_markov_ps": float(getattr(self.env, "other_rri_markov_ps", 1.0)),
            "other_rri_markov_states": list(getattr(self.env, "other_rri_markov_states", [50.0, 100.0, 200.0])),
        }

    def _restore_shock_baseline(self, baseline: Dict[str, Any]) -> None:
        target_n = max(0, min(int(self.env.N_max), int(baseline.get("N_v", self.env.N_v))))
        prev_n = int(self.env.N_v)
        self.env.N_v = target_n
        self.env.other_rri_mode = str(baseline.get("other_rri_mode", getattr(self.env, "other_rri_mode", "random")))
        self.env.rri_change_prob = float(baseline.get("rri_change_prob", getattr(self.env, "rri_change_prob", 0.0)))
        self.env.other_rri_markov_ps = float(
            baseline.get("other_rri_markov_ps", getattr(self.env, "other_rri_markov_ps", 1.0))
        )
        self.env.other_rri_markov_states = list(
            baseline.get("other_rri_markov_states", getattr(self.env, "other_rri_markov_states", [50.0, 100.0, 200.0]))
        )
        if prev_n > target_n:
            if hasattr(self.env, "rri_per_vehicle") and len(self.env.rri_per_vehicle) >= prev_n:
                self.env.rri_per_vehicle[target_n:prev_n] = 0.0
            if hasattr(self.env, "aoi_per_vehicle") and len(self.env.aoi_per_vehicle) >= prev_n:
                self.env.aoi_per_vehicle[target_n:prev_n] = 0.0
            if hasattr(self.env, "peak_paois") and len(self.env.peak_paois) >= prev_n:
                self.env.peak_paois[target_n:prev_n] = 0.0
            if hasattr(self.env, "other_sps_counter") and len(self.env.other_sps_counter) >= prev_n:
                self.env.other_sps_counter[target_n:prev_n] = 0
            if hasattr(self.env, "other_markov_state_idx") and len(self.env.other_markov_state_idx) >= prev_n:
                self.env.other_markov_state_idx[target_n:prev_n] = 0
            if hasattr(self.env, "other_markov_direction") and len(self.env.other_markov_direction) >= prev_n:
                self.env.other_markov_direction[target_n:prev_n] = 1

    def _refresh_current_view(self) -> None:
        current_rri = float(self.current_state.get("RRI", 100.0))
        self.current_state = dict(self.env.calculate_system_state(RRI=current_rri, N_v=int(self.env.N_v)))
        self.current_metrics = build_metrics(self.env, self.current_state)

    @staticmethod
    def _memory_changes_plan(
        draft_plan: DraftPlan,
        commit_plan: CommitPlan,
        memory_records: List[MemoryRecord],
        tool_outputs: Dict[str, Any],
        evidence_bundle: Optional[Dict[str, Any]] = None,
    ) -> bool:
        if not memory_records:
            return False
        if evidence_bundle is not None:
            return bool(evidence_bundle.get("memory_action_override", False))
        rollout = tool_outputs.get("rollout_candidates", {}).get("best_candidate")
        if rollout is not None:
            return int(commit_plan.chosen_rri) != int(rollout.get("rri", commit_plan.chosen_rri))
        if draft_plan.candidate_rris:
            return int(commit_plan.chosen_rri) != int(draft_plan.candidate_rris[0])
        return False

    def _update_memory(
        self,
        observation: ObservationDigest,
        analysis: AnalysisReport,
        selected_tools: List[str],
        commit_plan: CommitPlan,
        reflection: ReflectionNote,
        new_metrics: Dict[str, Any],
    ) -> None:
        query_spec = EpisodicMemoryStore.build_query_spec(observation.to_dict(), analysis.to_dict())
        self.memory.add(
            MemoryRecord(
                traffic_bucket=str(query_spec.get("traffic_bucket", "unknown")),
                collision_bucket=str(query_spec.get("collision_bucket", "unknown")),
                paoi_pattern=str(query_spec.get("paoi_pattern", "unknown")),
                current_rri=int(observation.current_rri),
                previous_branch=str(observation.previous_branch),
                shock_flag=bool(observation.shock_flag),
                selected_tools=list(selected_tools),
                committed_plan=commit_plan.to_dict(),
                observed_outcome={
                    "raafu": float(new_metrics.get("raafu", 0.0)),
                    "fairness_index": float(new_metrics.get("fairness_index", 0.0)),
                    "collision_prob": float(new_metrics.get("collision_prob", 0.0)),
                    "system_paoid": float(new_metrics.get("system_paoid", new_metrics.get("avg_paoid", 0.0))),
                },
                lesson_tag=reflection.lesson_tag,
                lesson_text=reflection.lesson,
            )
        )

    def _summarize_episode_stats(
        self,
        traces: List[Dict[str, Any]],
        fairness_values: List[float],
        rewards: List[float],
        shock_step: Optional[int],
        pre_shock_raafu: Optional[float],
    ) -> Dict[str, Any]:
        total_steps = max(1, self.step_count)
        tool_entropy = entropy_from_counts(self.tool_counts)
        tool_diversity = float(sum(1 for value in self.tool_counts.values() if value > 0)) / float(len(ALLOWED_TOOLS))
        memory_query_step_coverage = float(
            sum(1 for trace in traces if bool(trace.get("step_memory_query_used", False))) / total_steps
        )
        counterfactual_step_coverage = float(
            sum(1 for trace in traces if "counterfactual" in set(trace.get("step_tools_used", []))) / total_steps
        )
        recovery_integrity = 1.0
        shock_response_lag = None
        if shock_step is not None and shock_step < len(fairness_values) and pre_shock_raafu is not None:
            post = fairness_values[shock_step:]
            threshold = 0.95 * float(pre_shock_raafu)
            valid = [value for value in post if value >= threshold]
            recovery_integrity = float(len(valid) / max(1, len(post)))
            for idx, value in enumerate(post):
                if value >= threshold:
                    shock_response_lag = idx
                    break
        return {
            "planner_authority_ratio": float((total_steps - self.safety_override_count) / total_steps),
            "tool_entropy": float(tool_entropy),
            "tool_selection_diversity": float(tool_diversity),
            "memory_query_rate": float(memory_query_step_coverage),
            "memory_query_calls_per_step": float(self.memory_query_count / total_steps),
            "memory_changed_plan_rate": float(self.memory_changed_count / total_steps),
            "memory_plan_influence_rate": float(self.memory_plan_influence_count / total_steps),
            "memory_action_override_rate": float(self.memory_action_override_count / total_steps),
            "evidence_alignment_rate": float(self.evidence_alignment_count / total_steps),
            "replan_depth": float(self.replan_count / total_steps),
            "explicit_replan_rate": float(self.explicit_replan_count / total_steps),
            "reflection_guidance_rate": float(self.reflection_guidance_count / total_steps),
            "subgoal_completion_rate": float(self.success_count / total_steps),
            "fallback_rate": float(self.fallback_count / total_steps),
            "safety_override_rate": float(self.safety_override_count / total_steps),
            "tool_counterfactual_rate": float(counterfactual_step_coverage),
            "tool_counterfactual_calls_per_step": float(self.tool_counts.get("counterfactual", 0) / total_steps),
            "recovery_integrity": float(recovery_integrity),
            "shock_response_lag": shock_response_lag,
            "mean_reward": float(np.mean(rewards)) if rewards else 0.0,
            "mean_raafu": float(np.mean(fairness_values)) if fairness_values else 0.0,
            "num_steps": int(total_steps),
            "memory_size": len(self.memory),
            "tool_counts": dict(self.tool_counts),
            "last_trace": traces[-1] if traces else None,
        }

    def run_episode(
        self,
        *,
        scenario: str = "simple",
        max_steps: int = 30,
        shock_profile: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        self.reset(scenario=scenario)
        fairness_values: List[float] = []
        rewards: List[float] = []
        traces: List[Dict[str, Any]] = []
        pre_shock_raafu: Optional[float] = None
        shock_step = int(shock_profile["step"]) if shock_profile and "step" in shock_profile else None
        shock_duration = int(shock_profile.get("duration", 1)) if shock_profile else 0
        shock_runtime = str(shock_profile.get("runtime_mode", "legacy")).strip().lower() if shock_profile else "legacy"
        shock_baseline: Optional[Dict[str, Any]] = None
        shock_restored = False

        for step_idx in range(int(max_steps)):
            if shock_runtime == "windowed":
                if shock_step is not None and step_idx == shock_step:
                    pre_shock_raafu = float(self.current_metrics.get("raafu", 0.0))
                    shock_baseline = self._capture_shock_baseline()
                    self._apply_shock(shock_profile)
                    self._refresh_current_view()
                elif (
                    shock_step is not None
                    and shock_baseline is not None
                    and not shock_restored
                    and step_idx == shock_step + max(0, shock_duration)
                ):
                    self._restore_shock_baseline(shock_baseline)
                    self._refresh_current_view()
                    shock_restored = True
                shock_flag = bool(
                    shock_step is not None
                    and shock_duration > 0
                    and shock_step <= step_idx < shock_step + shock_duration
                )
            else:
                shock_flag = bool(shock_step is not None and shock_step <= step_idx < shock_step + shock_duration)
                if shock_step is not None and step_idx == shock_step:
                    pre_shock_raafu = float(self.current_metrics.get("raafu", 0.0))
                    self._apply_shock(shock_profile)

            step_tools_used: set[str] = set()
            step_tool_call_counts: Dict[str, int] = {name: 0 for name in ALLOWED_TOOLS}
            step_memory_query_used = False
            observation = self.build_observation(shock_flag=shock_flag)
            reflection_guided = bool(
                str(observation.last_reflection_hint).strip().lower() in {
                    "query_memory_then_replan",
                    "prefer_evidence_best_candidate",
                    "raise_rri_and_check_constraints",
                }
                or str(observation.last_subgoal_adjustment).strip().lower() not in {"", "keep_subgoal"}
            )
            if reflection_guided:
                self.reflection_guidance_count += 1
            analysis = self.analyze(observation)
            draft_plan = self.draft_plan(observation, analysis)
            # Reflection guidance is intended to bias the immediate next step only.
            self.last_reflection_hint = ""
            self.last_avoid_action_pattern = ""
            self.last_subgoal_adjustment = ""

            if "memory_query" in draft_plan.tool_sequence:
                self.memory_query_count += 1
                step_memory_query_used = True
                memory_records = self.memory.query(draft_plan.memory_query_spec, limit=self.config.max_memory_hits)
            else:
                memory_records = []
            tool_outputs = self.tools.run(
                draft_plan.tool_sequence,
                draft_plan,
                EpisodicMemoryStore.summarize(memory_records),
            )
            for tool_name in draft_plan.tool_sequence:
                if tool_name in self.tool_counts:
                    self.tool_counts[tool_name] += 1
                    step_tool_call_counts[tool_name] += 1
                    step_tools_used.add(tool_name)

            evidence_bundle = self._synthesize_evidence(
                observation,
                analysis,
                draft_plan,
                memory_records,
                tool_outputs,
            )
            explicit_replan_reason = self._should_explicit_replan(
                observation,
                analysis,
                evidence_bundle,
            )
            explicit_replan_applied = False
            if explicit_replan_reason and int(self.config.max_replans_per_step) > 0:
                draft_plan, memory_records, tool_outputs, evidence_bundle = self._explicit_replan(
                    observation,
                    analysis,
                    draft_plan,
                    memory_records,
                    evidence_bundle,
                    explicit_replan_reason,
                )
                if "memory_query" in draft_plan.tool_sequence:
                    step_memory_query_used = True
                for tool_name in draft_plan.tool_sequence:
                    if tool_name in step_tool_call_counts:
                        step_tool_call_counts[tool_name] += 1
                        step_tools_used.add(tool_name)
                self.replan_count += 1
                self.explicit_replan_count += 1
                explicit_replan_applied = True
            commit_plan, memory_changed = self.commit_plan(
                observation,
                analysis,
                draft_plan,
                memory_records,
                tool_outputs,
                evidence_bundle,
            )
            executed_rri, force_reselect, safety_overridden = self.safety_check(commit_plan)
            mcs_action = int(self.current_state.get("agent_mcs_level", self.config.default_mcs_action))
            new_state, done = self.env.step(mcs_action, rri_value=executed_rri, force_reselect=force_reselect)
            new_metrics = build_metrics(self.env, new_state)
            reward = compute_reward(new_metrics, self.current_metrics)
            reflection = self.reflect(reward, new_metrics, commit_plan, safety_overridden, shock_flag)

            if memory_changed:
                self.memory_changed_count += 1
            if bool(evidence_bundle.get("memory_plan_influence", False)):
                self.memory_plan_influence_count += 1
            if bool(evidence_bundle.get("memory_action_override", False)):
                self.memory_action_override_count += 1
            if int(commit_plan.chosen_rri) == int(evidence_bundle.get("preferred_rri", commit_plan.chosen_rri)):
                self.evidence_alignment_count += 1
            if reflection.should_replan:
                self.replan_count += 1
            if reflection.success:
                self.success_count += 1
                self.consecutive_failed_subgoals = 0
            else:
                self.consecutive_failed_subgoals += 1
            if safety_overridden:
                self.safety_override_count += 1
            if safety_overridden or executed_rri != int(commit_plan.chosen_rri):
                self.fallback_count += 1

            trace = {
                "step": int(step_idx),
                "observation": observation.to_dict(),
                "analysis": analysis.to_dict(),
                "draft_plan": draft_plan.to_dict(),
                "tool_outputs": tool_outputs,
                "evidence_synthesis": evidence_bundle,
                "commit_plan": commit_plan.to_dict(),
                "executed_action": {
                    "rri": int(executed_rri),
                    "force_reselect": bool(force_reselect),
                },
                "reflection": reflection.to_dict(),
                "reward": float(reward),
                "metrics": dict(new_metrics),
                "step_tools_used": sorted(step_tools_used),
                "step_tool_call_counts": dict(step_tool_call_counts),
                "step_memory_query_used": bool(step_memory_query_used),
                "memory_changed_plan": bool(memory_changed),
                "memory_plan_influence": bool(evidence_bundle.get("memory_plan_influence", False)),
                "memory_action_override": bool(evidence_bundle.get("memory_action_override", False)),
                "evidence_aligned": bool(int(commit_plan.chosen_rri) == int(evidence_bundle.get("preferred_rri", commit_plan.chosen_rri))),
                "explicit_replan": bool(explicit_replan_applied),
                "explicit_replan_reason": str(explicit_replan_reason or ""),
                "reflection_guided": bool(reflection_guided),
                "safety_overridden": bool(safety_overridden),
            }
            traces.append(trace)
            fairness_values.append(float(new_metrics.get("raafu", 0.0)))
            rewards.append(float(reward))

            self._update_memory(observation, analysis, draft_plan.tool_sequence, commit_plan, reflection, new_metrics)
            self.current_state = dict(new_state)
            self.previous_metrics = dict(self.current_metrics)
            self.current_metrics = dict(new_metrics)
            self.previous_branch = str(commit_plan.final_branch)
            self.previous_reward = float(reward)
            self.last_reflection_hint = str(reflection.next_step_hint)
            self.last_avoid_action_pattern = str(reflection.avoid_action_pattern)
            self.last_subgoal_adjustment = str(reflection.subgoal_adjustment)
            self.last_trace = trace
            self.step_count += 1

            if done:
                break

        return {
            "scenario": str(scenario),
            "config": {
                "use_llm": bool(self.llm is not None),
                "model_name": self.config.model_name,
                "max_tools_per_step": self.config.max_tools_per_step,
                "max_memory_hits": self.config.max_memory_hits,
                "safety_collision_threshold": self.config.safety_collision_threshold,
            },
            "fairness_values": fairness_values,
            "rewards": rewards,
            "agentic_stats": self._summarize_episode_stats(
                traces,
                fairness_values,
                rewards,
                shock_step,
                pre_shock_raafu,
            ),
            "traces": traces,
            "final_metrics": dict(self.current_metrics),
        }
