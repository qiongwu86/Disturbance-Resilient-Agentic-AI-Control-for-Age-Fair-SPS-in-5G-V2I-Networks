from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("paper_figures_gpt/experiment08_true_agentic_planning")
OUT_DIR = ROOT / "paper_selected_baselines_v42"
METHODS = ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]
METHOD_COLORS = {
    "exp08_agentic": "#0b6e4f",
    "plain_llm": "#c06c00",
    "dqn": "#355c7d",
    "gnnddqn": "#6c5b7b",
}
METHOD_LABELS = {
    "exp08_agentic": "Agentic",
    "plain_llm": "Plain LLM",
    "dqn": "DQN",
    "gnnddqn": "GNN-DDQN",
}


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _mean_std(curves: List[List[float]]) -> Tuple[List[float], List[float]]:
    arr = np.array(curves, dtype=float)
    return arr.mean(axis=0).tolist(), arr.std(axis=0).tolist()


def _smooth_curve(curve: List[float], window: int) -> List[float]:
    if window <= 1:
        return [float(x) for x in curve]
    arr = np.array(curve, dtype=float)
    pad = window // 2
    padded = np.pad(arr, (pad, pad), mode="edge")
    kernel = np.ones(window, dtype=float) / float(window)
    return np.convolve(padded, kernel, mode="valid").tolist()


def _transform_curves(curves: Dict[str, List[List[float]]], fn) -> Dict[str, List[List[float]]]:
    return {method: [fn(curve, idx, method) for idx, curve in enumerate(rows)] for method, rows in curves.items()}


def _collect_noshock_curves(chunk_tags: List[str]) -> Dict[str, List[List[float]]]:
    agg = {method: [] for method in METHODS}
    for tag in chunk_tags:
        cache_path = ROOT / f"exp08_fig2_dual_trajectory_{tag}_cache.json"
        payload = _load_json(cache_path)
        mode = payload.get("modes", {}).get("no_shock", {})
        for method in METHODS:
            agg[method].extend([[float(x) for x in row] for row in mode.get(method, [])])
    return agg


def _plot_pair(
    out_path: Path,
    xs: np.ndarray,
    top_payload: Dict[str, Any],
    bottom_payload: Dict[str, Any],
    *,
    top_title: str,
    bottom_title: str,
    top_ylabel: str,
    bottom_ylabel: str,
    bottom_zero_line: bool = False,
    shock_step: int = 8,
) -> None:
    fig, axes = plt.subplots(2, 1, figsize=(8.8, 7.2), sharex=True)

    top_all = []
    bottom_all = []
    for method in METHODS:
        top_all.extend(top_payload[method]["mean_curve"])
        top_all.extend([x - s for x, s in zip(top_payload[method]["mean_curve"], top_payload[method]["std_curve"])])
        top_all.extend([x + s for x, s in zip(top_payload[method]["mean_curve"], top_payload[method]["std_curve"])])
        bottom_all.extend(bottom_payload[method]["mean_curve"])
        bottom_all.extend([x - s for x, s in zip(bottom_payload[method]["mean_curve"], bottom_payload[method]["std_curve"])])
        bottom_all.extend([x + s for x, s in zip(bottom_payload[method]["mean_curve"], bottom_payload[method]["std_curve"])])

    top_lower = min(top_all)
    top_upper = max(top_all)
    bottom_lower = min(bottom_all)
    bottom_upper = max(bottom_all)

    for ax, payload, title, ylabel, lower, upper in [
        (axes[0], top_payload, top_title, top_ylabel, top_lower, top_upper),
        (axes[1], bottom_payload, bottom_title, bottom_ylabel, bottom_lower, bottom_upper),
    ]:
        for method in METHODS:
            mean_curve = np.array(payload[method]["mean_curve"], dtype=float)
            std_curve = np.array(payload[method]["std_curve"], dtype=float)
            ax.plot(xs, mean_curve, linewidth=2.0, label=METHOD_LABELS[method], color=METHOD_COLORS[method])
            ax.fill_between(xs, mean_curve - std_curve, mean_curve + std_curve, color=METHOD_COLORS[method], alpha=0.12)
        if ax is axes[1]:
            ax.axvline(shock_step, linestyle="--", color="black", alpha=0.65, linewidth=1.2, label="Shock onset")
            if bottom_zero_line:
                ax.axhline(0.0, linestyle=":", color="black", alpha=0.65, linewidth=1.0)
        ax.set_title(title)
        ax.set_ylabel(ylabel)
        ax.grid(alpha=0.25, linestyle=":")
        ax.set_xlim(xs[0] - 0.5, xs[-1] + 0.5)
        ax.set_xticks(xs[::2] if len(xs) > 1 else xs)
        pad = 0.03 if upper > 1.2 else 0.02
        ax.set_ylim(lower - pad, upper + pad)

    axes[0].legend(frameon=False, ncol=2, loc="lower left")
    axes[1].set_xlabel("Decision step")
    fig.tight_layout()
    fig.savefig(out_path, dpi=220, bbox_inches="tight")
    plt.close(fig)


def _summaries(curves: Dict[str, List[List[float]]]) -> Dict[str, Any]:
    payload: Dict[str, Any] = {}
    for method in METHODS:
        mean_curve, std_curve = _mean_std(curves[method])
        payload[method] = {
            "num_cases": len(curves[method]),
            "mean_curve": mean_curve,
            "std_curve": std_curve,
        }
    return payload


def main() -> None:
    output_tag = os.getenv("EXP08_FIG2_REVIEW_TAG", "paper_fig2_review_r1")
    visible_start = int(os.getenv("EXP08_FIG2_VISIBLE_START", "8"))
    baseline_start = int(os.getenv("EXP08_FIG2_BASELINE_START", "5"))
    baseline_end = int(os.getenv("EXP08_FIG2_BASELINE_END", "8"))
    smooth_short = int(os.getenv("EXP08_FIG2_REVIEW_SMOOTH_SHORT", "3"))
    smooth_long = int(os.getenv("EXP08_FIG2_REVIEW_SMOOTH_LONG", "5"))
    chunk_tags = [
        tag.strip()
        for tag in os.getenv(
            "EXP08_FIG2_NOSHOCK_CHUNK_TAGS",
            "paper_fig2_r1_o000_l008,paper_fig2_r1_o008_l008,paper_fig2_r1_o016_l008,paper_fig2_r1_o024_l008",
        ).split(",")
        if tag.strip()
    ]
    shock_cache = Path(
        os.getenv(
            "EXP08_FIG2_OLD_SHOCK_CACHE",
            str(OUT_DIR / "exp08_complex_shock_trajectory_selected_v42_cache.json"),
        )
    )
    shock_source = Path(
        os.getenv(
            "EXP08_FIG2_OLD_SHOCK_SOURCE",
            str(ROOT / "exp08_shock_recovery_paper_complex_shock_v42.json"),
        )
    )

    no_shock = _collect_noshock_curves(chunk_tags)
    shock_payload = _load_json(shock_cache)
    shock_curves = {
        method: [[float(x) for x in row] for row in shock_payload.get("agg", {}).get(method, [])]
        for method in METHODS
    }
    source_payload = _load_json(shock_source)
    shock_step = int(source_payload["cases"][0]["shock_profile"]["step"])
    max_steps = int(source_payload["config"]["max_steps"]["complex"])
    xs = np.arange(visible_start, max_steps)

    def _slice(curve: List[float]) -> List[float]:
        return [float(x) for x in curve[visible_start:max_steps]]

    no_shock_tail = _transform_curves(no_shock, lambda curve, _idx, _m: _slice(curve))
    shock_tail = _transform_curves(shock_curves, lambda curve, _idx, _m: _slice(curve))

    baseline_refs: Dict[str, List[float]] = {method: [] for method in METHODS}
    for method in METHODS:
        for curve in no_shock[method]:
            ref = float(np.mean(np.array(curve[baseline_start:baseline_end], dtype=float)))
            baseline_refs[method].append(ref if abs(ref) > 1e-9 else 1.0)

    retention_no = {method: [] for method in METHODS}
    retention_shock = {method: [] for method in METHODS}
    loss_tail = {method: [] for method in METHODS}
    smooth_no = {method: [] for method in METHODS}
    smooth_shock = {method: [] for method in METHODS}

    for method in METHODS:
        for idx, no_curve in enumerate(no_shock[method]):
            shock_curve = shock_curves[method][idx]
            ref = baseline_refs[method][idx]
            retention_no[method].append(_smooth_curve([float(x) / ref for x in _slice(no_curve)], smooth_short))
            retention_shock[method].append(_smooth_curve([float(x) / ref for x in _slice(shock_curve)], smooth_short))
            loss_tail[method].append(
                _smooth_curve(
                    [float(n) - float(s) for n, s in zip(_slice(no_curve), _slice(shock_curve))],
                    smooth_short,
                )
            )
            smooth_no[method].append(_smooth_curve(_slice(no_curve), smooth_long))
            smooth_shock[method].append(_smooth_curve(_slice(shock_curve), smooth_long))

    payload = {
        "tag": output_tag,
        "visible_range": [int(visible_start), int(max_steps - 1)],
        "shock_step": shock_step,
        "baseline_window": [baseline_start, baseline_end - 1],
        "variants": {
            "retention": {
                "formula_top": "no_shock / mean(no_shock[baseline_window])",
                "formula_bottom": "shock@8 / mean(no_shock[baseline_window])",
                "top": _summaries(retention_no),
                "bottom": _summaries(retention_shock),
            },
            "loss": {
                "formula_top": "smoothed no_shock",
                "formula_bottom": "smoothed(no_shock - shock@8)",
                "top": _summaries(smooth_no),
                "bottom": _summaries(loss_tail),
            },
            "smoothed_absolute": {
                "formula_top": "smoothed no_shock",
                "formula_bottom": "smoothed shock@8",
                "top": _summaries(smooth_no),
                "bottom": _summaries(smooth_shock),
            },
        },
    }

    out_json = ROOT / f"exp08_fig2_review_variants_{output_tag}.json"
    out_json.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    _plot_pair(
        OUT_DIR / "fig02_review_retention_r1.png",
        xs,
        payload["variants"]["retention"]["top"],
        payload["variants"]["retention"]["bottom"],
        top_title="(a) Normalized no-shock retention",
        bottom_title="(b) Normalized shock retention",
        top_ylabel="Retention ratio",
        bottom_ylabel="Retention ratio",
        shock_step=shock_step,
    )
    _plot_pair(
        OUT_DIR / "fig02_review_loss_r1.png",
        xs,
        payload["variants"]["loss"]["top"],
        payload["variants"]["loss"]["bottom"],
        top_title="(a) Smoothed no-shock trajectory",
        bottom_title="(b) Shock loss relative to no-shock",
        top_ylabel="Mean RAAFU",
        bottom_ylabel="no-shock minus shock",
        bottom_zero_line=True,
        shock_step=shock_step,
    )
    _plot_pair(
        OUT_DIR / "fig02_review_smoothed_r1.png",
        xs,
        payload["variants"]["smoothed_absolute"]["top"],
        payload["variants"]["smoothed_absolute"]["bottom"],
        top_title="(a) Smoothed no-shock trajectory",
        bottom_title="(b) Smoothed shock trajectory",
        top_ylabel="Mean RAAFU",
        bottom_ylabel="Mean RAAFU",
        shock_step=shock_step,
    )

    print(str(out_json).replace("\\", "/"))
    print(str((OUT_DIR / "fig02_review_retention_r1.png")).replace("\\", "/"))
    print(str((OUT_DIR / "fig02_review_loss_r1.png")).replace("\\", "/"))
    print(str((OUT_DIR / "fig02_review_smoothed_r1.png")).replace("\\", "/"))


if __name__ == "__main__":
    main()
