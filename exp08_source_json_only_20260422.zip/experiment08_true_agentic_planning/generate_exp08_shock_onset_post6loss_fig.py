from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


ROOT = Path("/home/ubuntu24/new_5gnr_modeling/paper_figures_gpt/experiment08_true_agentic_planning")
OUT_DIR = ROOT / "paper_selected_baselines_v42"
SOURCE_JSON = ROOT / "exp08_shock_onset_sweep_paper_shock_onset_sweep_r1.json"
OUT_PNG = OUT_DIR / "fig06d_shock_onset_post6loss_r1.png"

METHODS = ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]
METHOD_LABELS = {
    "exp08_agentic": "Agentic",
    "plain_llm": "Plain LLM",
    "dqn": "DQN",
    "gnnddqn": "GNN-DDQN",
}
METHOD_COLORS = {
    "exp08_agentic": "#0b6e4f",
    "plain_llm": "#c06c00",
    "dqn": "#355c7d",
    "gnnddqn": "#6c5b7b",
}


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    payload = _load_json(SOURCE_JSON)
    all_profiles: List[Dict[str, Any]] = payload["profiles"]

    # The 6-step post-shock average requires at least 6 affected steps in horizon.
    profiles = [profile for profile in all_profiles if int(profile["shock_profile_template"]["step"]) <= int(profile["max_steps"]) - 6]
    onsets = [int(profile["shock_profile_template"]["step"]) for profile in profiles]

    post6_loss: Dict[str, List[float]] = {method: [] for method in METHODS}
    for profile in profiles:
        onset = int(profile["shock_profile_template"]["step"])
        for method in METHODS:
            aggregate = profile["aggregate"]["methods"][method]
            no_curve = [float(x) for x in aggregate["no_shock"]["mean_curve"]]
            shock_curve = [float(x) for x in aggregate["shock"]["mean_curve"]]
            losses = [no_curve[idx] - shock_curve[idx] for idx in range(onset, onset + 6)]
            post6_loss[method].append(sum(losses) / 6.0)

    fig, ax = plt.subplots(figsize=(8.6, 4.7))
    y_min = 0.0
    y_max = 0.0
    for method in METHODS:
        ys = post6_loss[method]
        y_min = min(y_min, min(ys))
        y_max = max(y_max, max(ys))
        ax.plot(
            onsets,
            ys,
            marker="o",
            markersize=4.8,
            linewidth=2.0,
            color=METHOD_COLORS[method],
            label=METHOD_LABELS[method],
        )

    ax.axhline(0.0, color="black", linewidth=1.0, linestyle="--", alpha=0.8)
    ax.set_title("Immediate Shock Effect: Mean Loss Over The First 6 Post-Shock Steps")
    ax.set_xlabel("Shock onset step")
    ax.set_ylabel("Mean loss over first 6 steps")
    ax.set_xticks(onsets)
    pad = max(0.005, 0.12 * max(abs(y_min), abs(y_max), 0.05))
    ax.set_ylim(y_min - pad, y_max + pad)
    ax.grid(alpha=0.25, linestyle=":")
    ax.legend(frameon=False, ncol=3, loc="best")

    fig.tight_layout()
    fig.savefig(OUT_PNG, dpi=240, bbox_inches="tight")
    plt.close(fig)
    print(str(OUT_PNG))


if __name__ == "__main__":
    main()
