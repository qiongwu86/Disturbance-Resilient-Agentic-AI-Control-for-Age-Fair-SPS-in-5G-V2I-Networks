from __future__ import annotations

import json
import os
from pathlib import Path
import sys
from typing import Any, Dict, List, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import torch

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from experiment08_true_agentic_planning.baseline_models import DQNAgent, GNNDDQNAgent
from experiment08_true_agentic_planning.common import (
    ActionCodec,
    build_graph_observation,
    build_metrics,
    build_state_vector,
    compute_reward,
)
from experiment08_true_agentic_planning.formal_eval import _apply_shock
from experiment08_true_agentic_planning.formal_utils import make_shock_profile, set_global_seed
from experiment08_true_agentic_planning.plain_llm_baseline import PlainLLMBaseline, PlainLLMBaselineConfig
from experiment08_true_agentic_planning.planner_led_v2x_system import PlannerLedAgenticSystem, PlannerLedConfig, configure_environment_for_scenario
from agentic_v2x_system import V2XEnvironment


ROOT = Path("paper_figures_gpt/experiment08_true_agentic_planning")
OUT_DIR = ROOT / "paper_selected_baselines_v42"
TRAIN_DIR = ROOT / "training"
METHOD_LABELS = {
    "exp08_agentic": "Agentic",
    "plain_llm": "Plain LLM",
    "dqn": "DQN",
    "gnnddqn": "GNN-DDQN",
}
METHOD_COLORS = {
    "exp08_agentic": "#0b6e4f",
    "plain_llm": "#c06c00",
    "dqn": "#355c7d",
    "gnnddqn": "#6c5b7b",
}


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _best_checkpoint(method: str, scenario: str) -> Tuple[str, int]:
    manifest = _load_json(TRAIN_DIR / f"{method}_convergence_paper_s5_e1000_1500.json")
    entries = manifest.get("scenario_runs", {}).get(scenario, [])
    best = max(entries, key=lambda item: float(item.get("best_eval_mean_raafu", 0.0)))
    return str(best["checkpoint_path"]), int(best["seed"])


def _decode_action(env: V2XEnvironment, codec: ActionCodec | None, action_idx: int) -> Tuple[int, bool]:
    if codec is not None:
        return codec.decode(action_idx)
    n_rri = len(env.R_set)
    normalized = int(action_idx) % max(1, 2 * n_rri)
    branch = normalized // n_rri
    rri = int(env.R_set[normalized % n_rri])
    return rri, bool(branch == 1)


def _run_dqn_case(case_seed: int, shock_profile: Dict[str, Any], max_steps: int) -> Dict[str, Any]:
    checkpoint_path, train_seed = _best_checkpoint("dqn", "complex")
    set_global_seed(case_seed)
    env = V2XEnvironment()
    configure_environment_for_scenario(env, "complex")
    codec = ActionCodec([int(x) for x in env.R_set])
    agent = DQNAgent(state_dim=9, num_actions=codec.num_actions, seed=train_seed)
    payload = torch.load(checkpoint_path, map_location="cpu")
    agent.policy.load_state_dict(payload["policy_state_dict"])
    agent.target.load_state_dict(payload["target_state_dict"])
    agent.epsilon = 0.0

    state = env.current_state
    metrics = build_metrics(env, state)
    previous_branch = 0
    fairness_values: List[float] = []
    rri_values: List[int] = []
    for step_idx in range(max_steps):
        if step_idx == int(shock_profile["step"]):
            _apply_shock(env, shock_profile)
        obs = build_state_vector(state, metrics, prev_branch=previous_branch, shock_flag=1 if step_idx >= int(shock_profile["step"]) else 0)
        action_idx = agent.act(obs)
        rri, force_reselect = _decode_action(env, codec, action_idx)
        previous_branch = 1 if force_reselect else 0
        next_state, _ = env.step(int(state.get("agent_mcs_level", 3)), rri_value=rri, force_reselect=force_reselect)
        next_metrics = build_metrics(env, next_state)
        fairness_values.append(float(next_metrics.get("raafu", 0.0)))
        rri_values.append(int(rri))
        state = next_state
        metrics = next_metrics
    return {"fairness_values": fairness_values, "rri_values": rri_values}


def _run_gnn_case(case_seed: int, shock_profile: Dict[str, Any], max_steps: int) -> Dict[str, Any]:
    checkpoint_path, train_seed = _best_checkpoint("gnnddqn", "complex")
    set_global_seed(case_seed)
    env = V2XEnvironment()
    configure_environment_for_scenario(env, "complex")
    agent = GNNDDQNAgent(node_feat_dim=6, num_actions=len(env.R_set) * 2, seed=train_seed)
    payload = torch.load(checkpoint_path, map_location="cpu")
    agent.policy.load_state_dict(payload["policy_state_dict"])
    agent.target.load_state_dict(payload["target_state_dict"])
    agent.epsilon = 0.0

    state = env.current_state
    metrics = build_metrics(env, state)
    fairness_values: List[float] = []
    rri_values: List[int] = []
    for step_idx in range(max_steps):
        if step_idx == int(shock_profile["step"]):
            _apply_shock(env, shock_profile)
        node_feats, adjacency = build_graph_observation(env, state, metrics)
        action_idx = agent.act(node_feats, adjacency)
        rri, force_reselect = _decode_action(env, None, action_idx)
        next_state, _ = env.step(int(state.get("agent_mcs_level", 3)), rri_value=rri, force_reselect=force_reselect)
        next_metrics = build_metrics(env, next_state)
        fairness_values.append(float(next_metrics.get("raafu", 0.0)))
        rri_values.append(int(rri))
        state = next_state
        metrics = next_metrics
    return {"fairness_values": fairness_values, "rri_values": rri_values}


def _run_plain_llm_case(case_seed: int, shock_profile: Dict[str, Any], max_steps: int) -> Dict[str, Any]:
    config = PlainLLMBaselineConfig(
        use_llm=os.getenv("EXP08_USE_LLM", "0") == "1",
        strict_llm=False,
        model_name=os.getenv("EXP08_MODEL", "openai/gpt-4o-mini"),
        base_url=os.getenv("OPENAI_BASE_URL", ""),
        api_key=os.getenv("OPENAI_API_KEY", ""),
    )
    set_global_seed(case_seed)
    baseline = PlainLLMBaseline(config=config, seed=case_seed)
    state, metrics = baseline.reset("complex")
    fairness_values: List[float] = []
    rri_values: List[int] = []
    for step_idx in range(max_steps):
        if step_idx == int(shock_profile["step"]):
            _apply_shock(baseline.env, shock_profile)
        decision = baseline.choose_action(state, metrics, shock_flag=step_idx >= int(shock_profile["step"]))
        next_state, _ = baseline.env.step(
            int(state.get("agent_mcs_level", 3)),
            rri_value=int(decision["chosen_rri"]),
            force_reselect=bool(decision["force_reselect"]),
        )
        next_metrics = build_metrics(baseline.env, next_state)
        fairness_values.append(float(next_metrics.get("raafu", 0.0)))
        rri_values.append(int(decision["chosen_rri"]))
        state = next_state
        metrics = next_metrics
    return {"fairness_values": fairness_values, "rri_values": rri_values}


def _run_agentic_case(case_seed: int, shock_profile: Dict[str, Any], max_steps: int) -> Dict[str, Any]:
    config = PlannerLedConfig(
        use_llm=os.getenv("EXP08_USE_LLM", "0") == "1",
        strict_llm=False,
        model_name=os.getenv("EXP08_MODEL", "openai/gpt-4o-mini"),
        base_url=os.getenv("OPENAI_BASE_URL", ""),
        api_key=os.getenv("OPENAI_API_KEY", ""),
    )
    set_global_seed(case_seed)
    system = PlannerLedAgenticSystem(config=config, seed=case_seed)
    payload = system.run_episode(scenario="complex", max_steps=max_steps, shock_profile=shock_profile)
    rri_values = [int(trace.get("executed_action", {}).get("rri", 0)) for trace in payload.get("traces", [])]
    memory_flags = [1 if bool(trace.get("memory_plan_influence", False)) else 0 for trace in payload.get("traces", [])]
    replan_flags = [1 if bool(trace.get("explicit_replan", False)) else 0 for trace in payload.get("traces", [])]
    return {
        "fairness_values": payload.get("fairness_values", []),
        "rri_values": rri_values,
        "memory_flags": memory_flags,
        "replan_flags": replan_flags,
        "traces": payload.get("traces", []),
    }


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    case_idx = int(os.getenv("EXP08_CASE_STUDY_IDX", "1"))
    case_seed = 2000 + case_idx
    max_steps = int(os.getenv("EXP08_CASE_STUDY_STEPS", "24"))
    shock_profile = make_shock_profile("complex", case_seed)
    shock_profile = dict(shock_profile)
    shock_profile["step"] = min(int(shock_profile.get("step", 8)), max_steps - 2)

    agentic = _run_agentic_case(case_seed, shock_profile, max_steps)
    plain_llm = _run_plain_llm_case(case_seed, shock_profile, max_steps)
    dqn = _run_dqn_case(case_seed, shock_profile, max_steps)
    gnnddqn = _run_gnn_case(case_seed, shock_profile, max_steps)

    payload = {
        "case_idx": case_idx,
        "case_seed": case_seed,
        "shock_profile": shock_profile,
        "exp08_agentic": agentic,
        "plain_llm": plain_llm,
        "dqn": dqn,
        "gnnddqn": gnnddqn,
    }
    json_path = OUT_DIR / "exp08_case_study_selected_v42.json"
    json_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    steps = list(range(max_steps))
    fig, axes = plt.subplots(2, 1, figsize=(9.6, 7.2), sharex=True, gridspec_kw={"height_ratios": [2.2, 1.3]})

    for method, series in [("exp08_agentic", agentic), ("plain_llm", plain_llm), ("dqn", dqn), ("gnnddqn", gnnddqn)]:
        axes[0].plot(
            steps[: len(series["fairness_values"])],
            series["fairness_values"],
            marker="o",
            linewidth=2.0,
            markersize=3.5,
            label=METHOD_LABELS[method],
            color=METHOD_COLORS[method],
        )
    axes[0].axvline(int(shock_profile["step"]), color="#333333", linestyle="--", linewidth=1.3)
    axes[0].set_ylabel("RAAFU")
    axes[0].set_title(f"Complex Shock Case Study: case {case_idx:03d} (seed={case_seed}, extra={shock_profile['extra_vehicles']})")
    axes[0].grid(alpha=0.28)
    axes[0].legend(frameon=False, ncol=2)

    agentic_rri = agentic["rri_values"]
    axes[1].step(steps[: len(agentic_rri)], agentic_rri, where="mid", color=METHOD_COLORS["exp08_agentic"], linewidth=2.0, label="Agentic RRI")
    mem_x = [idx for idx, flag in enumerate(agentic.get("memory_flags", [])) if flag]
    rep_x = [idx for idx, flag in enumerate(agentic.get("replan_flags", [])) if flag]
    if mem_x:
        axes[1].scatter(mem_x, [agentic_rri[idx] for idx in mem_x], color="#c06c00", marker="s", s=36, label="memory influence")
    if rep_x:
        axes[1].scatter(rep_x, [agentic_rri[idx] for idx in rep_x], color="#b54d2e", marker="^", s=42, label="explicit replan")
    axes[1].axvline(int(shock_profile["step"]), color="#333333", linestyle="--", linewidth=1.3)
    axes[1].set_ylabel("Agentic RRI")
    axes[1].set_xlabel("Decision step")
    axes[1].grid(alpha=0.28)
    axes[1].legend(frameon=False, ncol=3, fontsize=8)

    fig.tight_layout()
    fig_path = OUT_DIR / "fig07_case_study_selected_v42.png"
    fig.savefig(fig_path, dpi=220)
    plt.close(fig)
    print(str(fig_path.resolve()))


if __name__ == "__main__":
    main()
