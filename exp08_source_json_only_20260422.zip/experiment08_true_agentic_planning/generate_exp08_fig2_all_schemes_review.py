from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("paper_figures_gpt/experiment08_true_agentic_planning")
OUT_DIR = ROOT / "paper_selected_baselines_v42"
METHODS = ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]
METHOD_COLORS = {
    "exp08_agentic": "#0b6e4f",
    "plain_llm": "#c06c00",
    "dqn": "#355c7d",
    "gnnddqn": "#6c5b7b",
}
METHOD_LABELS = {
    "exp08_agentic": "Agentic",
    "plain_llm": "Plain LLM",
    "dqn": "DQN",
    "gnnddqn": "GNN-DDQN",
}


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _mean_std(curves: List[List[float]]) -> Tuple[List[float], List[float]]:
    arr = np.array(curves, dtype=float)
    return arr.mean(axis=0).tolist(), arr.std(axis=0).tolist()


def _collect_noshock_curves(chunk_tags: List[str]) -> Dict[str, List[List[float]]]:
    agg = {method: [] for method in METHODS}
    for tag in chunk_tags:
        cache_path = ROOT / f"exp08_fig2_dual_trajectory_{tag}_cache.json"
        payload = _load_json(cache_path)
        modes = payload.get("modes", {}).get("no_shock", {})
        for method in METHODS:
            agg[method].extend([[float(x) for x in row] for row in modes.get(method, [])])
    return agg


def _baseline_ref(curve: List[float], start: int, end: int) -> float:
    value = float(np.mean(np.array(curve[start:end], dtype=float)))
    return value if abs(value) > 1e-9 else 1.0


def _plot_lines(
    out_path: Path,
    xs: np.ndarray,
    top_payload: Dict[str, Any],
    bottom_payload: Dict[str, Any],
    *,
    top_title: str,
    bottom_title: str,
    top_ylabel: str,
    bottom_ylabel: str,
    shock_step: int,
    xline_at_zero: bool = False,
    yline_at_zero: bool = False,
) -> None:
    fig, axes = plt.subplots(2, 1, figsize=(8.9, 7.3), sharex=True)

    top_values = []
    bottom_values = []
    for method in METHODS:
        top_values.extend(top_payload[method]["mean_curve"])
        top_values.extend([x - s for x, s in zip(top_payload[method]["mean_curve"], top_payload[method]["std_curve"])])
        top_values.extend([x + s for x, s in zip(top_payload[method]["mean_curve"], top_payload[method]["std_curve"])])
        bottom_values.extend(bottom_payload[method]["mean_curve"])
        bottom_values.extend([x - s for x, s in zip(bottom_payload[method]["mean_curve"], bottom_payload[method]["std_curve"])])
        bottom_values.extend([x + s for x, s in zip(bottom_payload[method]["mean_curve"], bottom_payload[method]["std_curve"])])

    for ax, payload, title, ylabel, vals in [
        (axes[0], top_payload, top_title, top_ylabel, top_values),
        (axes[1], bottom_payload, bottom_title, bottom_ylabel, bottom_values),
    ]:
        for method in METHODS:
            mean_curve = np.array(payload[method]["mean_curve"], dtype=float)
            std_curve = np.array(payload[method]["std_curve"], dtype=float)
            ax.plot(xs, mean_curve, linewidth=2.0, label=METHOD_LABELS[method], color=METHOD_COLORS[method])
            ax.fill_between(xs, mean_curve - std_curve, mean_curve + std_curve, color=METHOD_COLORS[method], alpha=0.12)
        if xline_at_zero:
            ax.axvline(0 if np.min(xs) <= 0 <= np.max(xs) else shock_step, linestyle="--", color="black", alpha=0.65, linewidth=1.2)
        else:
            ax.axvline(shock_step, linestyle="--", color="black", alpha=0.65, linewidth=1.2)
        if yline_at_zero:
            ax.axhline(0.0, linestyle=":", color="black", alpha=0.65, linewidth=1.0)
        ax.set_title(title)
        ax.set_ylabel(ylabel)
        ax.grid(alpha=0.25, linestyle=":")
        ax.set_xlim(xs[0], xs[-1])
        pad = 0.03 if max(vals) - min(vals) > 0.4 else 0.02
        ax.set_ylim(min(vals) - pad, max(vals) + pad)

    axes[0].legend(frameon=False, ncol=2, loc="lower left")
    axes[1].set_xlabel("Event time" if xline_at_zero else "Decision step")
    fig.tight_layout()
    fig.savefig(out_path, dpi=220, bbox_inches="tight")
    plt.close(fig)


def _plot_phase_bars(
    out_path: Path,
    top_rows: Dict[str, Any],
    bottom_rows: Dict[str, Any],
    phase_names: List[str],
) -> None:
    fig, axes = plt.subplots(2, 1, figsize=(9.2, 7.4), sharex=True)
    xs = np.arange(len(phase_names))
    width = 0.18

    all_vals = []
    for rows in [top_rows, bottom_rows]:
        for method in METHODS:
            all_vals.extend(rows[method]["means"])
            all_vals.extend([m - s for m, s in zip(rows[method]["means"], rows[method]["stds"])])
            all_vals.extend([m + s for m, s in zip(rows[method]["means"], rows[method]["stds"])])

    for ax, rows, title in [
        (axes[0], top_rows, "(a) No-shock phase means"),
        (axes[1], bottom_rows, "(b) Shock phase means"),
    ]:
        for idx, method in enumerate(METHODS):
            offset = (idx - 1.5) * width
            ax.bar(
                xs + offset,
                rows[method]["means"],
                width=width,
                yerr=rows[method]["stds"],
                capsize=2.5,
                color=METHOD_COLORS[method],
                alpha=0.85,
                label=METHOD_LABELS[method],
            )
        ax.set_title(title)
        ax.set_ylabel("Mean RAAFU")
        ax.grid(alpha=0.25, linestyle=":", axis="y")
        ax.set_ylim(min(all_vals) - 0.02, max(all_vals) + 0.02)

    axes[0].legend(frameon=False, ncol=2, loc="lower left")
    axes[1].set_xticks(xs, phase_names)
    fig.tight_layout()
    fig.savefig(out_path, dpi=220, bbox_inches="tight")
    plt.close(fig)


def _plot_heatmaps(
    out_path: Path,
    top_matrix: np.ndarray,
    bottom_matrix: np.ndarray,
    xs: List[int],
) -> None:
    fig, axes = plt.subplots(2, 1, figsize=(10.0, 5.8), sharex=True)
    vmax = float(max(abs(np.min(top_matrix)), abs(np.max(top_matrix)), abs(np.min(bottom_matrix)), abs(np.max(bottom_matrix))))
    vmin = -vmax

    for ax, matrix, title in [
        (axes[0], top_matrix, "(a) No-shock relative deviation from pre-shock baseline (%)"),
        (axes[1], bottom_matrix, "(b) Shock relative deviation from pre-shock baseline (%)"),
    ]:
        im = ax.imshow(matrix, aspect="auto", cmap="RdYlGn", vmin=vmin, vmax=vmax)
        ax.set_yticks(np.arange(len(METHODS)), [METHOD_LABELS[m] for m in METHODS])
        ax.set_title(title)
        ax.set_xticks(np.arange(len(xs))[::2], [str(xs[i]) for i in range(0, len(xs), 2)])

    axes[1].set_xlabel("Decision step")
    cbar = fig.colorbar(im, ax=axes, shrink=0.95, pad=0.02)
    cbar.set_label("% relative to pre-shock baseline")
    fig.tight_layout()
    fig.savefig(out_path, dpi=220, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    output_tag = os.getenv("EXP08_FIG2_ALL_SCHEMES_TAG", "paper_fig2_allschemes_r1")
    pre_start = int(os.getenv("EXP08_FIG2_PRE_START", "5"))
    pre_end = int(os.getenv("EXP08_FIG2_PRE_END", "8"))
    event_start = int(os.getenv("EXP08_FIG2_EVENT_START", "5"))
    event_end = int(os.getenv("EXP08_FIG2_EVENT_END", "24"))
    chunk_tags = [
        tag.strip()
        for tag in os.getenv(
            "EXP08_FIG2_NOSHOCK_CHUNK_TAGS",
            "paper_fig2_r1_o000_l008,paper_fig2_r1_o008_l008,paper_fig2_r1_o016_l008,paper_fig2_r1_o024_l008",
        ).split(",")
        if tag.strip()
    ]
    shock_cache = Path(
        os.getenv(
            "EXP08_FIG2_OLD_SHOCK_CACHE",
            str(OUT_DIR / "exp08_complex_shock_trajectory_selected_v42_cache.json"),
        )
    )
    shock_source = Path(
        os.getenv(
            "EXP08_FIG2_OLD_SHOCK_SOURCE",
            str(ROOT / "exp08_shock_recovery_paper_complex_shock_v42.json"),
        )
    )

    no_shock = _collect_noshock_curves(chunk_tags)
    shock_payload = _load_json(shock_cache)
    shock_curves = {
        method: [[float(x) for x in row] for row in shock_payload.get("agg", {}).get(method, [])]
        for method in METHODS
    }
    source_payload = _load_json(shock_source)
    shock_step = int(source_payload["cases"][0]["shock_profile"]["step"])
    max_steps = int(source_payload["config"]["max_steps"]["complex"])

    visible_steps = list(range(event_start, min(event_end, max_steps)))
    tau_xs = np.array([step - shock_step for step in visible_steps], dtype=float)
    abs_xs = np.array(visible_steps, dtype=float)

    phases = [
        ("Pre", pre_start, pre_end),
        ("Impact", shock_step, min(shock_step + 3, max_steps)),
        ("Recovery", min(shock_step + 3, max_steps), min(shock_step + 8, max_steps)),
        ("Late", min(shock_step + 8, max_steps), max_steps),
    ]

    event_no = {method: [] for method in METHODS}
    event_shock = {method: [] for method in METHODS}
    cumdev_no = {method: [] for method in METHODS}
    cumloss_shock = {method: [] for method in METHODS}
    phase_no = {method: {"means": [], "stds": []} for method in METHODS}
    phase_shock = {method: {"means": [], "stds": []} for method in METHODS}
    heat_no = []
    heat_shock = []

    for method in METHODS:
        no_method_heat = []
        shock_method_heat = []
        no_phase_cases = [[] for _ in phases]
        shock_phase_cases = [[] for _ in phases]
        for idx, no_curve in enumerate(no_shock[method]):
            shock_curve = shock_curves[method][idx]
            ref = _baseline_ref(no_curve, pre_start, pre_end)

            no_slice = [float(no_curve[step]) for step in visible_steps]
            shock_slice = [float(shock_curve[step]) for step in visible_steps]
            event_no[method].append([value - ref for value in no_slice])
            event_shock[method].append([value - ref for value in shock_slice])

            cum_no = []
            cum_shock = []
            total_no = 0.0
            total_shock = 0.0
            for step, nval, sval in zip(visible_steps, no_slice, shock_slice):
                if step < shock_step:
                    cum_no.append(0.0)
                    cum_shock.append(0.0)
                else:
                    total_no += ref - nval
                    total_shock += nval - sval
                    cum_no.append(total_no)
                    cum_shock.append(total_shock)
            cumdev_no[method].append(cum_no)
            cumloss_shock[method].append(cum_shock)

            no_method_heat.append([100.0 * ((value / ref) - 1.0) for value in no_slice])
            shock_method_heat.append([100.0 * ((value / ref) - 1.0) for value in shock_slice])

            for phase_idx, (_, start, end) in enumerate(phases):
                start = max(0, min(start, max_steps))
                end = max(start + 1, min(end, max_steps))
                no_phase_cases[phase_idx].append(float(np.mean(np.array(no_curve[start:end], dtype=float))))
                shock_phase_cases[phase_idx].append(float(np.mean(np.array(shock_curve[start:end], dtype=float))))

        heat_no.append(np.mean(np.array(no_method_heat, dtype=float), axis=0).tolist())
        heat_shock.append(np.mean(np.array(shock_method_heat, dtype=float), axis=0).tolist())
        for phase_idx in range(len(phases)):
            no_vals = np.array(no_phase_cases[phase_idx], dtype=float)
            shock_vals = np.array(shock_phase_cases[phase_idx], dtype=float)
            phase_no[method]["means"].append(float(np.mean(no_vals)))
            phase_no[method]["stds"].append(float(np.std(no_vals)))
            phase_shock[method]["means"].append(float(np.mean(shock_vals)))
            phase_shock[method]["stds"].append(float(np.std(shock_vals)))

    payload = {
        "tag": output_tag,
        "pre_window": [pre_start, pre_end - 1],
        "visible_steps": visible_steps,
        "shock_step": shock_step,
        "phases": [{"name": name, "start": start, "end": end - 1} for name, start, end in phases],
        "schemes": {
            "event_study": {
                "formula_top": "no_shock(t) - mean(no_shock[pre_window])",
                "formula_bottom": "shock(t) - mean(no_shock[pre_window])",
                "top": {method: {"mean_curve": _mean_std(event_no[method])[0], "std_curve": _mean_std(event_no[method])[1]} for method in METHODS},
                "bottom": {method: {"mean_curve": _mean_std(event_shock[method])[0], "std_curve": _mean_std(event_shock[method])[1]} for method in METHODS},
            },
            "cumulative_loss": {
                "formula_top": "cumsum(mean(no_shock[pre_window]) - no_shock(t), t >= shock_step)",
                "formula_bottom": "cumsum(no_shock(t) - shock(t), t >= shock_step)",
                "top": {method: {"mean_curve": _mean_std(cumdev_no[method])[0], "std_curve": _mean_std(cumdev_no[method])[1]} for method in METHODS},
                "bottom": {method: {"mean_curve": _mean_std(cumloss_shock[method])[0], "std_curve": _mean_std(cumloss_shock[method])[1]} for method in METHODS},
            },
            "phase_bars": {
                "top": phase_no,
                "bottom": phase_shock,
            },
            "heatmap": {
                "top": heat_no,
                "bottom": heat_shock,
            },
        },
    }

    out_json = ROOT / f"exp08_fig2_all_schemes_review_{output_tag}.json"
    out_json.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    _plot_lines(
        OUT_DIR / "fig02_scheme_event_study_r1.png",
        tau_xs,
        payload["schemes"]["event_study"]["top"],
        payload["schemes"]["event_study"]["bottom"],
        top_title="(a) No-shock event-study deviation",
        bottom_title="(b) Shock event-study deviation",
        top_ylabel="Delta RAAFU",
        bottom_ylabel="Delta RAAFU",
        shock_step=0,
        xline_at_zero=True,
        yline_at_zero=True,
    )
    _plot_lines(
        OUT_DIR / "fig02_scheme_cumulative_loss_r1.png",
        abs_xs,
        payload["schemes"]["cumulative_loss"]["top"],
        payload["schemes"]["cumulative_loss"]["bottom"],
        top_title="(a) No-shock cumulative deviation",
        bottom_title="(b) Shock cumulative loss",
        top_ylabel="Cumulative delta",
        bottom_ylabel="Cumulative loss",
        shock_step=shock_step,
        yline_at_zero=True,
    )
    _plot_phase_bars(
        OUT_DIR / "fig02_scheme_phase_bars_r1.png",
        payload["schemes"]["phase_bars"]["top"],
        payload["schemes"]["phase_bars"]["bottom"],
        [name for name, _, _ in phases],
    )
    _plot_heatmaps(
        OUT_DIR / "fig02_scheme_heatmap_r1.png",
        np.array(payload["schemes"]["heatmap"]["top"], dtype=float),
        np.array(payload["schemes"]["heatmap"]["bottom"], dtype=float),
        visible_steps,
    )

    print(str(out_json).replace("\\", "/"))
    print(str((OUT_DIR / "fig02_scheme_event_study_r1.png")).replace("\\", "/"))
    print(str((OUT_DIR / "fig02_scheme_cumulative_loss_r1.png")).replace("\\", "/"))
    print(str((OUT_DIR / "fig02_scheme_phase_bars_r1.png")).replace("\\", "/"))
    print(str((OUT_DIR / "fig02_scheme_heatmap_r1.png")).replace("\\", "/"))


if __name__ == "__main__":
    main()
