from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


OUT_DIR = Path(
    "/home/ubuntu24/new_5gnr_modeling/paper_figures_gpt/"
    "experiment08_true_agentic_planning/paper_selected_baselines_v42"
)
OUT_PATH = OUT_DIR / "fig02_pointline_shock_step8_from_user_table.png"

TABLE = {
    "Agentic": [
        0.7066, 0.7149, 0.7046, 0.6308, 0.6710, 0.6964, 0.6769, 0.6280,
        0.6548, 0.7285, 0.6925, 0.5831, 0.6569, 0.7035, 0.6731, 0.5972,
        0.6629, 0.7164, 0.6786, 0.5948, 0.6577, 0.6879, 0.6751, 0.6160,
    ],
    "Plain": [
        0.6813, 0.6736, 0.7145, 0.6010, 0.6757, 0.6767, 0.6695, 0.6045,
        0.6497, 0.6824, 0.6811, 0.5591, 0.6181, 0.6866, 0.6728, 0.5767,
        0.6554, 0.6935, 0.7010, 0.5850, 0.6384, 0.6821, 0.6741, 0.5939,
    ],
    "DQN": [
        0.6883, 0.7458, 0.6894, 0.6078, 0.6601, 0.6940, 0.6627, 0.6371,
        0.6480, 0.6789, 0.6762, 0.5916, 0.6331, 0.6663, 0.6488, 0.6113,
        0.6454, 0.6854, 0.6403, 0.6094, 0.6489, 0.6757, 0.6720, 0.6198,
    ],
    "GNN": [
        0.6836, 0.7172, 0.6646, 0.5739, 0.6634, 0.6944, 0.6350, 0.5906,
        0.6629, 0.6891, 0.6821, 0.5870, 0.6370, 0.6828, 0.6500, 0.5945,
        0.6575, 0.7026, 0.6349, 0.5969, 0.6656, 0.7145, 0.6867, 0.6532,
    ],
}

COLORS = {
    "Agentic": "#0b6e4f",
    "Plain": "#c06c00",
    "DQN": "#355c7d",
    "GNN": "#6c5b7b",
}


def main() -> None:
    steps = np.arange(24)

    fig, ax = plt.subplots(figsize=(9.2, 5.0))
    for name, values in TABLE.items():
        ys = np.array(values, dtype=float)
        ax.plot(
            steps,
            ys,
            marker="o",
            markersize=4.8,
            linewidth=2.0,
            color=COLORS[name],
            label=name,
        )

    ax.axvline(8, linestyle="--", color="black", linewidth=1.2, alpha=0.75, label="Shock at step 8")
    ax.set_title("Point-Line Plot Drawn Directly From User-Provided Step Table")
    ax.set_xlabel("Step")
    ax.set_ylabel("Mean RAAFU")
    ax.set_xlim(-0.5, 23.5)
    ax.set_xticks(steps)
    ax.set_ylim(0.54, 0.76)
    ax.grid(alpha=0.25, linestyle=":")
    ax.legend(frameon=False, ncol=3, loc="lower left")
    fig.tight_layout()
    fig.savefig(OUT_PATH, dpi=240, bbox_inches="tight")
    plt.close(fig)
    print(str(OUT_PATH))


if __name__ == "__main__":
    main()
