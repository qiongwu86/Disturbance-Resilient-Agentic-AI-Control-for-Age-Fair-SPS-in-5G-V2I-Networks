from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch

from agentic_v2x_system import V2XEnvironment

from .baseline_models import DQNAgent, GNNDDQNAgent
from .common import ActionCodec, build_graph_observation, build_metrics, build_state_vector, compute_reward
from .formal_eval import _apply_shock
from .planner_led_v2x_system import PlannerLedAgenticSystem, PlannerLedConfig, configure_environment_for_scenario
from .plain_llm_baseline import PlainLLMBaseline, PlainLLMBaselineConfig


METHODS = ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]


def load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def planner_config_from_env() -> PlannerLedConfig:
    return PlannerLedConfig(
        use_llm=os.getenv("EXP08_USE_LLM", "0") == "1",
        strict_llm=False,
        model_name=os.getenv("EXP08_MODEL", "openai/gpt-4o-mini"),
        base_url=os.getenv("OPENAI_BASE_URL", ""),
        api_key=os.getenv("OPENAI_API_KEY", ""),
    )


def plain_config_from_env() -> PlainLLMBaselineConfig:
    return PlainLLMBaselineConfig(
        use_llm=os.getenv("EXP08_USE_LLM", "0") == "1",
        strict_llm=False,
        model_name=os.getenv("EXP08_MODEL", "openai/gpt-4o-mini"),
        base_url=os.getenv("OPENAI_BASE_URL", ""),
        api_key=os.getenv("OPENAI_API_KEY", ""),
    )


def load_manifest(method: str, baseline_tag: str) -> Dict[str, Any]:
    path = Path("paper_figures_gpt/experiment08_true_agentic_planning/training") / f"{method}_convergence_{baseline_tag}.json"
    return load_json(path)


def checkpoint_entries(manifest: Dict[str, Any], scenario: str) -> List[Dict[str, Any]]:
    return [entry for entry in manifest.get("scenario_runs", {}).get(scenario, []) if entry.get("checkpoint_path")]


def decode_action(env: V2XEnvironment, codec: Optional[ActionCodec], action_idx: int) -> Tuple[int, bool]:
    if codec is not None:
        return codec.decode(action_idx)
    n_rri = len(env.R_set)
    normalized = int(action_idx) % max(1, 2 * n_rri)
    branch = normalized // n_rri
    rri = int(env.R_set[normalized % n_rri])
    return rri, bool(branch == 1)


def load_dqn(checkpoint_path: str, scenario: str, train_seed: int) -> Tuple[V2XEnvironment, DQNAgent, ActionCodec]:
    env = V2XEnvironment()
    configure_environment_for_scenario(env, scenario)
    codec = ActionCodec([int(x) for x in env.R_set])
    agent = DQNAgent(state_dim=9, num_actions=codec.num_actions, seed=train_seed)
    payload = torch.load(checkpoint_path, map_location="cpu")
    agent.policy.load_state_dict(payload["policy_state_dict"])
    agent.target.load_state_dict(payload["target_state_dict"])
    agent.epsilon = 0.0
    return env, agent, codec


def load_gnnddqn(checkpoint_path: str, scenario: str, train_seed: int) -> Tuple[V2XEnvironment, GNNDDQNAgent]:
    env = V2XEnvironment()
    configure_environment_for_scenario(env, scenario)
    agent = GNNDDQNAgent(node_feat_dim=6, num_actions=len(env.R_set) * 2, seed=train_seed)
    payload = torch.load(checkpoint_path, map_location="cpu")
    agent.policy.load_state_dict(payload["policy_state_dict"])
    agent.target.load_state_dict(payload["target_state_dict"])
    agent.epsilon = 0.0
    return env, agent


def run_agentic_curve(
    scenario: str,
    case_seed: int,
    shock_profile: Optional[Dict[str, Any]],
    max_steps: int,
    planner_config: PlannerLedConfig,
) -> List[float]:
    system = PlannerLedAgenticSystem(config=planner_config, seed=case_seed)
    payload = system.run_episode(scenario=scenario, max_steps=max_steps, shock_profile=shock_profile)
    return [float(x) for x in payload.get("fairness_values", [])]


def run_plain_curve(
    scenario: str,
    case_seed: int,
    shock_profile: Optional[Dict[str, Any]],
    max_steps: int,
    plain_config: PlainLLMBaselineConfig,
) -> List[float]:
    baseline = PlainLLMBaseline(config=plain_config, seed=case_seed)
    state, metrics = baseline.reset(scenario)
    fairness_values: List[float] = []
    shock_step = None if shock_profile is None else int(shock_profile["step"])
    for step_idx in range(int(max_steps)):
        if shock_step is not None and step_idx == shock_step:
            _apply_shock(baseline.env, shock_profile)
        decision = baseline.choose_action(state, metrics, shock_flag=bool(shock_step is not None and step_idx >= shock_step))
        mcs_action = int(state.get("agent_mcs_level", 3))
        next_state, done = baseline.env.step(
            mcs_action,
            rri_value=int(decision["chosen_rri"]),
            force_reselect=bool(decision["force_reselect"]),
        )
        next_metrics = build_metrics(baseline.env, next_state)
        fairness_values.append(float(next_metrics.get("raafu", 0.0)))
        state, metrics = next_state, next_metrics
        if done:
            break
    return fairness_values


def run_dqn_curve(
    scenario: str,
    case_seed: int,
    shock_profile: Optional[Dict[str, Any]],
    max_steps: int,
    checkpoint_path: str,
    train_seed: int,
) -> List[float]:
    env, agent, codec = load_dqn(checkpoint_path, scenario, train_seed)
    state = env.current_state
    metrics = build_metrics(env, state)
    prev_branch = 0
    fairness_values: List[float] = []
    shock_step = None if shock_profile is None else int(shock_profile["step"])
    for step_idx in range(int(max_steps)):
        if shock_step is not None and step_idx == shock_step:
            _apply_shock(env, shock_profile)
        obs = build_state_vector(
            state,
            metrics,
            prev_branch=prev_branch,
            shock_flag=1 if shock_step is not None and step_idx >= shock_step else 0,
        )
        action_idx = agent.act(obs)
        rri, force_reselect = decode_action(env, codec, action_idx)
        prev_branch = 1 if force_reselect else 0
        mcs_action = int(state.get("agent_mcs_level", 3))
        next_state, done = env.step(mcs_action, rri_value=rri, force_reselect=force_reselect)
        next_metrics = build_metrics(env, next_state)
        fairness_values.append(float(next_metrics.get("raafu", 0.0)))
        state, metrics = next_state, next_metrics
        if done:
            break
    return fairness_values


def run_gnnddqn_curve(
    scenario: str,
    case_seed: int,
    shock_profile: Optional[Dict[str, Any]],
    max_steps: int,
    checkpoint_path: str,
    train_seed: int,
) -> List[float]:
    env, agent = load_gnnddqn(checkpoint_path, scenario, train_seed)
    state = env.current_state
    metrics = build_metrics(env, state)
    fairness_values: List[float] = []
    shock_step = None if shock_profile is None else int(shock_profile["step"])
    for step_idx in range(int(max_steps)):
        if shock_step is not None and step_idx == shock_step:
            _apply_shock(env, shock_profile)
        node_feats, adjacency = build_graph_observation(env, state, metrics)
        action_idx = agent.act(node_feats, adjacency)
        rri, force_reselect = decode_action(env, None, action_idx)
        mcs_action = int(state.get("agent_mcs_level", 3))
        next_state, done = env.step(mcs_action, rri_value=rri, force_reselect=force_reselect)
        next_metrics = build_metrics(env, next_state)
        fairness_values.append(float(next_metrics.get("raafu", 0.0)))
        state, metrics = next_state, next_metrics
        if done:
            break
    return fairness_values


def average_curves(curves: List[List[float]]) -> List[float]:
    if not curves:
        return []
    max_len = max(len(curve) for curve in curves)
    arr = np.full((len(curves), max_len), np.nan, dtype=float)
    for row_idx, curve in enumerate(curves):
        arr[row_idx, : len(curve)] = np.array(curve, dtype=float)
    return np.nanmean(arr, axis=0).tolist()


def curve_mean(curve: List[float]) -> float:
    return float(np.mean(np.array(curve, dtype=float))) if curve else 0.0


def build_shock_profile(
    *,
    step: int,
    duration: int,
    extra_vehicles: int,
    rri_change_prob: float,
    markov_ps: float = 1.0,
) -> Dict[str, Any]:
    return {
        "step": int(step),
        "duration": int(duration),
        "extra_vehicles": int(extra_vehicles),
        "rri_change_prob": float(rri_change_prob),
        "markov_ps": float(markov_ps),
        "other_rri_mode": "markov_pingpong",
        "markov_states": [20.0, 50.0, 100.0, 200.0, 500.0],
    }


def paired_curve_statistics(no_shock_curve: List[float], shock_curve: List[float]) -> Dict[str, Any]:
    length = min(len(no_shock_curve), len(shock_curve))
    if length <= 0:
        return {
            "delta_curve": [],
            "retention_curve": [],
            "cumulative_loss": 0.0,
            "worst_drop": 0.0,
            "post_shock_mean_gap": 0.0,
        }

    no_arr = np.array(no_shock_curve[:length], dtype=float)
    shock_arr = np.array(shock_curve[:length], dtype=float)
    delta = shock_arr - no_arr
    retention = np.divide(shock_arr, np.maximum(no_arr, 1e-9))
    losses = np.maximum(0.0, no_arr - shock_arr)
    return {
        "delta_curve": delta.tolist(),
        "retention_curve": retention.tolist(),
        "cumulative_loss": float(losses.sum()),
        "worst_drop": float(delta.min()),
        "post_shock_mean_gap": float(delta.mean()),
    }


def run_all_methods_for_case(
    *,
    scenario: str,
    case_seed: int,
    shock_profile: Optional[Dict[str, Any]],
    max_steps: int,
    baseline_tag: str,
    planner_config: Optional[PlannerLedConfig] = None,
    plain_config: Optional[PlainLLMBaselineConfig] = None,
    dqn_entries: Optional[List[Dict[str, Any]]] = None,
    gnnddqn_entries: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, List[float]]:
    planner_cfg = planner_config or planner_config_from_env()
    plain_cfg = plain_config or plain_config_from_env()
    if dqn_entries is None:
        dqn_entries = checkpoint_entries(load_manifest("dqn", baseline_tag), scenario)
    if gnnddqn_entries is None:
        gnnddqn_entries = checkpoint_entries(load_manifest("gnnddqn", baseline_tag), scenario)

    dqn_curves = [
        run_dqn_curve(
            scenario,
            case_seed,
            shock_profile,
            max_steps,
            str(entry["checkpoint_path"]),
            int(entry.get("train_seed", entry.get("seed", 0))),
        )
        for entry in dqn_entries
    ]
    gnnddqn_curves = [
        run_gnnddqn_curve(
            scenario,
            case_seed,
            shock_profile,
            max_steps,
            str(entry["checkpoint_path"]),
            int(entry.get("train_seed", entry.get("seed", 0))),
        )
        for entry in gnnddqn_entries
    ]

    return {
        "exp08_agentic": run_agentic_curve(scenario, case_seed, shock_profile, max_steps, planner_cfg),
        "plain_llm": run_plain_curve(scenario, case_seed, shock_profile, max_steps, plain_cfg),
        "dqn": average_curves(dqn_curves),
        "gnnddqn": average_curves(gnnddqn_curves),
    }


def mean_curve_by_method(case_curves: Dict[str, List[List[float]]]) -> Dict[str, List[float]]:
    return {method: average_curves(curves) for method, curves in case_curves.items()}


def mean_scalar_by_method(method_rows: Dict[str, List[float]]) -> Dict[str, float]:
    return {
        method: float(np.mean(np.array(values, dtype=float))) if values else 0.0
        for method, values in method_rows.items()
    }


def mean_curve_map(rows: List[Dict[str, List[float]]], key: str) -> Dict[str, List[float]]:
    per_method: Dict[str, List[List[float]]] = {method: [] for method in METHODS}
    for row in rows:
        for method in METHODS:
            per_method[method].append([float(x) for x in row[method][key]])
    return mean_curve_by_method(per_method)
