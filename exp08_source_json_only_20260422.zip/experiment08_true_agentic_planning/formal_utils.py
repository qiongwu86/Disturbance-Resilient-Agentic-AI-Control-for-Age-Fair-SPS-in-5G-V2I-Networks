from __future__ import annotations

import json
import random
from pathlib import Path
from statistics import mean
from typing import Any, Dict, Iterable, List, Optional

import numpy as np


PROTOCOL_VERSION = "exp08_formal_v1"


def parse_seed_list(raw: str, default: Iterable[int]) -> List[int]:
    text = str(raw or "").strip()
    if not text:
        return [int(x) for x in default]
    return [int(item.strip()) for item in text.split(",") if item.strip()]


def parse_name_list(raw: str, default: Iterable[str]) -> List[str]:
    text = str(raw or "").strip()
    if not text:
        return [str(x).strip() for x in default]
    return [item.strip() for item in text.split(",") if item.strip()]


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def save_json(path: Path, payload: Dict[str, Any]) -> Path:
    ensure_dir(path.parent)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def set_global_seed(seed: int) -> None:
    random.seed(int(seed))
    np.random.seed(int(seed))


def build_case_seeds(count: int, *, base_seed: int = 1000) -> List[int]:
    return [int(base_seed + idx) for idx in range(int(count))]


def make_shock_profile(scenario: str, case_seed: int) -> Dict[str, Any]:
    rng = random.Random(int(case_seed))
    is_complex = str(scenario).strip().lower() == "complex"
    return {
        "step": 8 if is_complex else 6,
        "duration": 5 if is_complex else 4,
        "extra_vehicles": rng.randint(2, 4) if is_complex else rng.randint(1, 3),
        "rri_change_prob": 0.80 + 0.05 * rng.random() if is_complex else 0.65 + 0.10 * rng.random(),
        "other_rri_mode": "markov_pingpong",
        "markov_states": [20.0, 50.0, 100.0, 200.0, 500.0],
    }


def summarize_scalar_records(records: List[Dict[str, Any]], keys: Iterable[str]) -> Dict[str, float]:
    summary: Dict[str, float] = {}
    for key in keys:
        values = [float(item.get(key, 0.0)) for item in records]
        summary[str(key)] = float(mean(values)) if values else 0.0
    return summary


def compute_shock_metrics(
    fairness_values: List[float],
    shock_profile: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    if not shock_profile or not fairness_values:
        return {}

    shock_step = int(shock_profile.get("step", 0))
    if shock_step <= 0 or shock_step >= len(fairness_values):
        return {}

    pre_shock = float(fairness_values[max(0, shock_step - 1)])
    post_shock = [float(x) for x in fairness_values[shock_step:]]
    if not post_shock:
        return {}

    shock_floor = min(post_shock)
    threshold = 0.95 * pre_shock
    recovery_integrity = float(sum(1 for value in post_shock if value >= threshold) / len(post_shock))
    response_lag = None
    for idx, value in enumerate(post_shock):
        if value >= threshold:
            response_lag = idx
            break
    degradation_area = float(sum(max(0.0, pre_shock - value) for value in post_shock))
    return {
        "shock_floor": float(shock_floor),
        "recovery_integrity": float(recovery_integrity),
        "shock_response_lag": response_lag,
        "degradation_area": float(degradation_area),
    }


def aggregate_formal_cases(cases: List[Dict[str, Any]]) -> Dict[str, Any]:
    method_records: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}

    for case in cases:
        scenario = str(case.get("scenario", "unknown"))
        results = case.get("results", {})
        for method_name, method_payload in results.items():
            method_records.setdefault(method_name, {}).setdefault(scenario, [])
            if isinstance(method_payload, list):
                for replicate in method_payload:
                    method_records[method_name][scenario].append(replicate)
            elif isinstance(method_payload, dict):
                method_records[method_name][scenario].append(method_payload)

    summary: Dict[str, Any] = {}
    base_keys = ["mean_raafu", "mean_reward"]
    shock_keys = ["shock_floor", "recovery_integrity", "degradation_area"]

    for method_name, by_scenario in method_records.items():
        summary[method_name] = {}
        for scenario, records in by_scenario.items():
            scenario_summary = summarize_scalar_records(records, base_keys)
            shock_present = any("shock_floor" in record for record in records)
            if shock_present:
                scenario_summary.update(summarize_scalar_records(records, shock_keys))
                lags = [record.get("shock_response_lag") for record in records if record.get("shock_response_lag") is not None]
                scenario_summary["shock_response_lag"] = float(mean([float(x) for x in lags])) if lags else None
            if any("agentic_stats" in record for record in records):
                stat_keys = [
                    "planner_authority_ratio",
                    "tool_entropy",
                    "tool_selection_diversity",
                    "memory_query_rate",
                    "memory_changed_plan_rate",
                    "memory_plan_influence_rate",
                    "memory_action_override_rate",
                    "memory_query_calls_per_step",
                    "evidence_alignment_rate",
                    "replan_depth",
                    "explicit_replan_rate",
                    "reflection_guidance_rate",
                    "subgoal_completion_rate",
                    "fallback_rate",
                    "safety_override_rate",
                    "tool_counterfactual_rate",
                    "tool_counterfactual_calls_per_step",
                ]
                agentic_rows = [record.get("agentic_stats", {}) for record in records]
                scenario_summary["agentic_stats"] = summarize_scalar_records(agentic_rows, stat_keys)
            if any("utility_stats" in record for record in records):
                utility_keys = [
                    "memory_utility_gain",
                    "replan_success_gain",
                    "evidence_override_penalty",
                    "reflection_guidance_gain",
                    "avg_step_reward",
                ]
                utility_rows = [record.get("utility_stats", {}) for record in records]
                scenario_summary["utility_stats"] = summarize_scalar_records(utility_rows, utility_keys)
                tool_names = ["memory_query", "rollout_candidates", "counterfactual", "constraint_check", "state_digest"]
                scenario_summary["utility_stats"]["tool_effectiveness_by_type"] = {
                    tool_name: float(
                        mean(
                            float(row.get("tool_effectiveness_by_type", {}).get(tool_name, 0.0))
                            for row in utility_rows
                        )
                    )
                    for tool_name in tool_names
                }
            summary[method_name][scenario] = scenario_summary
    return summary


def formal_payload(
    experiment_type: str,
    tag: str,
    config: Dict[str, Any],
    cases: List[Dict[str, Any]],
) -> Dict[str, Any]:
    return {
        "protocol_version": PROTOCOL_VERSION,
        "experiment_type": str(experiment_type),
        "tag": str(tag),
        "config": config,
        "cases": cases,
        "summary": aggregate_formal_cases(cases),
    }
