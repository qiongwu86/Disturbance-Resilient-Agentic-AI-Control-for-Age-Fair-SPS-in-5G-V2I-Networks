from __future__ import annotations

import os
from pathlib import Path
import sys
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiment08_true_agentic_planning.formal_utils import build_case_seeds, save_json
from experiment08_true_agentic_planning.trajectory_eval import (
    METHODS,
    build_shock_profile,
    checkpoint_entries,
    load_manifest,
    mean_curve_by_method,
    mean_curve_map,
    mean_scalar_by_method,
    paired_curve_statistics,
    planner_config_from_env,
    plain_config_from_env,
    run_all_methods_for_case,
)


def main() -> None:
    output_tag = os.getenv("EXP08_OUTPUT_TAG", "counterfactual_event_study_latest")
    baseline_tag = os.getenv("EXP08_BASELINE_TAG", "paper_s5_e1000_1500")
    scenario = os.getenv("EXP08_SCENARIO", "complex").strip().lower()
    case_count = int(os.getenv("EXP08_CASE_COUNT", "32"))
    max_steps = int(os.getenv("EXP08_MAX_STEPS", "24"))
    base_seed = int(os.getenv("EXP08_BASE_SEED", "2000"))
    shock_step = int(os.getenv("EXP08_SHOCK_STEP", "8"))
    shock_duration = int(os.getenv("EXP08_SHOCK_DURATION", "5"))
    shock_extra = int(os.getenv("EXP08_SHOCK_EXTRA", "3"))
    shock_prob = float(os.getenv("EXP08_SHOCK_PROB", "0.8"))
    shock_markov_ps = float(os.getenv("EXP08_SHOCK_MARKOV_PS", "1.0"))
    output_path = Path("paper_figures_gpt/experiment08_true_agentic_planning") / f"exp08_counterfactual_event_study_{output_tag}.json"

    planner_cfg = planner_config_from_env()
    plain_cfg = plain_config_from_env()
    dqn_entries = checkpoint_entries(load_manifest("dqn", baseline_tag), scenario)
    gnnddqn_entries = checkpoint_entries(load_manifest("gnnddqn", baseline_tag), scenario)

    shock_template = build_shock_profile(
        step=shock_step,
        duration=shock_duration,
        extra_vehicles=shock_extra,
        rri_change_prob=shock_prob,
        markov_ps=shock_markov_ps,
    )

    no_shock_curves: Dict[str, List[List[float]]] = {method: [] for method in METHODS}
    shock_curves: Dict[str, List[List[float]]] = {method: [] for method in METHODS}
    paired_rows: List[Dict[str, Any]] = []

    for case_seed in build_case_seeds(case_count, base_seed=base_seed):
        no_shock = run_all_methods_for_case(
            scenario=scenario,
            case_seed=case_seed,
            shock_profile=None,
            max_steps=max_steps,
            baseline_tag=baseline_tag,
            planner_config=planner_cfg,
            plain_config=plain_cfg,
            dqn_entries=dqn_entries,
            gnnddqn_entries=gnnddqn_entries,
        )
        shock_profile = dict(shock_template)
        shock_profile["seed"] = int(case_seed)
        shock = run_all_methods_for_case(
            scenario=scenario,
            case_seed=case_seed,
            shock_profile=shock_profile,
            max_steps=max_steps,
            baseline_tag=baseline_tag,
            planner_config=planner_cfg,
            plain_config=plain_cfg,
            dqn_entries=dqn_entries,
            gnnddqn_entries=gnnddqn_entries,
        )

        case_stats: Dict[str, Any] = {"case_seed": int(case_seed), "methods": {}}
        for method in METHODS:
            no_shock_curves[method].append(no_shock[method])
            shock_curves[method].append(shock[method])
            case_stats["methods"][method] = {
                "no_shock_curve": no_shock[method],
                "shock_curve": shock[method],
                **paired_curve_statistics(no_shock[method], shock[method]),
            }
        paired_rows.append(case_stats)
        save_json(output_path, {"status": "running", "completed_cases": len(paired_rows), "cases_total": case_count})

    aggregate_metric_rows: Dict[str, Dict[str, List[float]]] = {
        method: {
            "cumulative_loss": [],
            "worst_drop": [],
            "post_shock_mean_gap": [],
        }
        for method in METHODS
    }
    for row in paired_rows:
        for method in METHODS:
            stats = row["methods"][method]
            aggregate_metric_rows[method]["cumulative_loss"].append(float(stats["cumulative_loss"]))
            aggregate_metric_rows[method]["worst_drop"].append(float(stats["worst_drop"]))
            aggregate_metric_rows[method]["post_shock_mean_gap"].append(float(stats["post_shock_mean_gap"]))

    payload = {
        "experiment": "counterfactual_event_study",
        "scenario": scenario,
        "baseline_tag": baseline_tag,
        "case_count": case_count,
        "max_steps": max_steps,
        "base_seed": base_seed,
        "shock_profile_template": shock_template,
        "aggregate": {
            "no_shock_mean_curve": mean_curve_by_method(no_shock_curves),
            "shock_mean_curve": mean_curve_by_method(shock_curves),
            "mean_delta_curve": mean_curve_map(paired_rows, "delta_curve"),
            "mean_retention_curve": mean_curve_map(paired_rows, "retention_curve"),
            "mean_cumulative_loss": mean_scalar_by_method(
                {method: values["cumulative_loss"] for method, values in aggregate_metric_rows.items()}
            ),
            "mean_worst_drop": mean_scalar_by_method(
                {method: values["worst_drop"] for method, values in aggregate_metric_rows.items()}
            ),
            "mean_post_shock_gap": mean_scalar_by_method(
                {method: values["post_shock_mean_gap"] for method, values in aggregate_metric_rows.items()}
            ),
        },
        "cases": paired_rows,
    }
    save_json(output_path, payload)
    print(str(output_path).replace("\\", "/"))


if __name__ == "__main__":
    main()
