from __future__ import annotations

import random
from collections import deque
from dataclasses import dataclass
from typing import Deque, List, Sequence

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class Transition:
    state: np.ndarray
    aux_a: np.ndarray
    aux_b: np.ndarray
    action: int
    reward: float
    next_state: np.ndarray
    next_aux_a: np.ndarray
    next_aux_b: np.ndarray
    done: bool


class ReplayBuffer:
    def __init__(self, capacity: int = 20000) -> None:
        self.capacity = max(1000, int(capacity))
        self.data: Deque[Transition] = deque(maxlen=self.capacity)

    def push(self, transition: Transition) -> None:
        self.data.append(transition)

    def sample(self, batch_size: int) -> List[Transition]:
        return random.sample(self.data, batch_size)

    def __len__(self) -> int:
        return len(self.data)


class MLPQNetwork(nn.Module):
    def __init__(self, input_dim: int, num_actions: int, hidden_dim: int = 128) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, num_actions),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class GraphQNetwork(nn.Module):
    def __init__(self, node_feat_dim: int, num_actions: int, hidden_dim: int = 64) -> None:
        super().__init__()
        self.node_in = nn.Linear(node_feat_dim, hidden_dim)
        self.agg_1 = nn.Linear(hidden_dim * 2, hidden_dim)
        self.agg_2 = nn.Linear(hidden_dim * 2, hidden_dim)
        self.head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, num_actions),
        )

    def forward(self, node_feats: torch.Tensor, adjacency: torch.Tensor) -> torch.Tensor:
        h = F.relu(self.node_in(node_feats))
        neigh = torch.matmul(adjacency, h)
        h = F.relu(self.agg_1(torch.cat([h, neigh], dim=-1)))
        neigh = torch.matmul(adjacency, h)
        h = F.relu(self.agg_2(torch.cat([h, neigh], dim=-1)))
        pooled = h.mean(dim=1)
        return self.head(pooled)


class DQNStrongAgent:
    def __init__(
        self,
        state_dim: int,
        num_actions: int,
        *,
        lr: float = 1e-3,
        gamma: float = 0.98,
        epsilon_start: float = 1.0,
        epsilon_end: float = 0.05,
        epsilon_decay: float = 0.995,
        batch_size: int = 64,
        target_sync: int = 100,
        seed: int = 0,
    ) -> None:
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        self.num_actions = int(num_actions)
        self.gamma = float(gamma)
        self.epsilon = float(epsilon_start)
        self.epsilon_end = float(epsilon_end)
        self.epsilon_decay = float(epsilon_decay)
        self.batch_size = int(batch_size)
        self.target_sync = int(target_sync)
        self.device = torch.device("cpu")
        self.policy = MLPQNetwork(state_dim, num_actions).to(self.device)
        self.target = MLPQNetwork(state_dim, num_actions).to(self.device)
        self.target.load_state_dict(self.policy.state_dict())
        self.optimizer = torch.optim.Adam(self.policy.parameters(), lr=lr)
        self.memory = ReplayBuffer()
        self.train_steps = 0

    def act(self, state: Sequence[float]) -> int:
        if random.random() < self.epsilon:
            return random.randrange(self.num_actions)
        with torch.no_grad():
            state_t = torch.tensor(np.asarray(state, dtype=np.float32), device=self.device).unsqueeze(0)
            return int(torch.argmax(self.policy(state_t), dim=1).item())

    def observe(self, state, action, reward, next_state, done) -> None:
        self.memory.push(
            Transition(
                np.asarray(state, dtype=np.float32),
                np.zeros((1,), dtype=np.float32),
                np.zeros((1,), dtype=np.float32),
                int(action),
                float(reward),
                np.asarray(next_state, dtype=np.float32),
                np.zeros((1,), dtype=np.float32),
                np.zeros((1,), dtype=np.float32),
                bool(done),
            )
        )
        self._train_step()
        self.epsilon = max(self.epsilon_end, self.epsilon * self.epsilon_decay)

    def _train_step(self) -> None:
        if len(self.memory) < self.batch_size:
            return
        batch = self.memory.sample(self.batch_size)
        states = torch.tensor(np.asarray([item.state for item in batch], dtype=np.float32), device=self.device)
        actions = torch.tensor([item.action for item in batch], dtype=torch.long, device=self.device).unsqueeze(1)
        rewards = torch.tensor([item.reward for item in batch], dtype=torch.float32, device=self.device).unsqueeze(1)
        next_states = torch.tensor(np.asarray([item.next_state for item in batch], dtype=np.float32), device=self.device)
        done = torch.tensor([1.0 if item.done else 0.0 for item in batch], dtype=torch.float32, device=self.device).unsqueeze(1)

        q_values = self.policy(states).gather(1, actions)
        next_actions = torch.argmax(self.policy(next_states), dim=1, keepdim=True)
        next_q = self.target(next_states).gather(1, next_actions)
        target = rewards + self.gamma * next_q * (1.0 - done)
        loss = F.smooth_l1_loss(q_values, target.detach())

        self.optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.policy.parameters(), 5.0)
        self.optimizer.step()

        self.train_steps += 1
        if self.train_steps % self.target_sync == 0:
            self.target.load_state_dict(self.policy.state_dict())


class DQNAgent:
    def __init__(
        self,
        state_dim: int,
        num_actions: int,
        *,
        lr: float = 7.5e-4,
        gamma: float = 0.97,
        epsilon_start: float = 1.0,
        epsilon_end: float = 0.10,
        epsilon_decay: float = 0.997,
        batch_size: int = 64,
        target_sync: int = 200,
        seed: int = 0,
    ) -> None:
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        self.num_actions = int(num_actions)
        self.gamma = float(gamma)
        self.epsilon = float(epsilon_start)
        self.epsilon_end = float(epsilon_end)
        self.epsilon_decay = float(epsilon_decay)
        self.batch_size = int(batch_size)
        self.target_sync = int(target_sync)
        self.device = torch.device("cpu")
        self.policy = MLPQNetwork(state_dim, num_actions, hidden_dim=64).to(self.device)
        self.target = MLPQNetwork(state_dim, num_actions, hidden_dim=64).to(self.device)
        self.target.load_state_dict(self.policy.state_dict())
        self.optimizer = torch.optim.Adam(self.policy.parameters(), lr=lr)
        self.memory = ReplayBuffer(capacity=12000)
        self.train_steps = 0

    def act(self, state: Sequence[float]) -> int:
        if random.random() < self.epsilon:
            return random.randrange(self.num_actions)
        with torch.no_grad():
            state_t = torch.tensor(np.asarray(state, dtype=np.float32), device=self.device).unsqueeze(0)
            return int(torch.argmax(self.policy(state_t), dim=1).item())

    def observe(self, state, action, reward, next_state, done) -> None:
        self.memory.push(
            Transition(
                np.asarray(state, dtype=np.float32),
                np.zeros((1,), dtype=np.float32),
                np.zeros((1,), dtype=np.float32),
                int(action),
                float(reward),
                np.asarray(next_state, dtype=np.float32),
                np.zeros((1,), dtype=np.float32),
                np.zeros((1,), dtype=np.float32),
                bool(done),
            )
        )
        self._train_step()
        self.epsilon = max(self.epsilon_end, self.epsilon * self.epsilon_decay)

    def _train_step(self) -> None:
        if len(self.memory) < self.batch_size:
            return
        batch = self.memory.sample(self.batch_size)
        states = torch.tensor(np.asarray([item.state for item in batch], dtype=np.float32), device=self.device)
        actions = torch.tensor([item.action for item in batch], dtype=torch.long, device=self.device).unsqueeze(1)
        rewards = torch.tensor([item.reward for item in batch], dtype=torch.float32, device=self.device).unsqueeze(1)
        next_states = torch.tensor(np.asarray([item.next_state for item in batch], dtype=np.float32), device=self.device)
        done = torch.tensor([1.0 if item.done else 0.0 for item in batch], dtype=torch.float32, device=self.device).unsqueeze(1)

        q_values = self.policy(states).gather(1, actions)
        next_q = self.target(next_states).max(dim=1, keepdim=True).values
        target = rewards + self.gamma * next_q * (1.0 - done)
        loss = F.smooth_l1_loss(q_values, target.detach())

        self.optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.policy.parameters(), 5.0)
        self.optimizer.step()

        self.train_steps += 1
        if self.train_steps % self.target_sync == 0:
            self.target.load_state_dict(self.policy.state_dict())


class GNNDDQNAgent:
    def __init__(
        self,
        node_feat_dim: int,
        num_actions: int,
        *,
        lr: float = 1e-3,
        gamma: float = 0.98,
        epsilon_start: float = 1.0,
        epsilon_end: float = 0.05,
        epsilon_decay: float = 0.995,
        batch_size: int = 64,
        target_sync: int = 100,
        seed: int = 0,
    ) -> None:
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        self.num_actions = int(num_actions)
        self.gamma = float(gamma)
        self.epsilon = float(epsilon_start)
        self.epsilon_end = float(epsilon_end)
        self.epsilon_decay = float(epsilon_decay)
        self.batch_size = int(batch_size)
        self.target_sync = int(target_sync)
        self.device = torch.device("cpu")
        self.policy = GraphQNetwork(node_feat_dim, num_actions).to(self.device)
        self.target = GraphQNetwork(node_feat_dim, num_actions).to(self.device)
        self.target.load_state_dict(self.policy.state_dict())
        self.optimizer = torch.optim.Adam(self.policy.parameters(), lr=lr)
        self.memory = ReplayBuffer()
        self.train_steps = 0

    def act(self, node_feats: np.ndarray, adjacency: np.ndarray) -> int:
        if random.random() < self.epsilon:
            return random.randrange(self.num_actions)
        with torch.no_grad():
            node_t = torch.tensor(node_feats, dtype=torch.float32, device=self.device).unsqueeze(0)
            adj_t = torch.tensor(adjacency, dtype=torch.float32, device=self.device).unsqueeze(0)
            return int(torch.argmax(self.policy(node_t, adj_t), dim=1).item())

    def observe(self, node_feats, adjacency, action, reward, next_node_feats, next_adjacency, done) -> None:
        self.memory.push(
            Transition(
                np.zeros((1,), dtype=np.float32),
                np.asarray(node_feats, dtype=np.float32),
                np.asarray(adjacency, dtype=np.float32),
                int(action),
                float(reward),
                np.zeros((1,), dtype=np.float32),
                np.asarray(next_node_feats, dtype=np.float32),
                np.asarray(next_adjacency, dtype=np.float32),
                bool(done),
            )
        )
        self._train_step()
        self.epsilon = max(self.epsilon_end, self.epsilon * self.epsilon_decay)

    def _train_step(self) -> None:
        if len(self.memory) < self.batch_size:
            return
        batch = self.memory.sample(self.batch_size)
        node_feats = torch.tensor(np.asarray([item.aux_a for item in batch], dtype=np.float32), device=self.device)
        adjacency = torch.tensor(np.asarray([item.aux_b for item in batch], dtype=np.float32), device=self.device)
        actions = torch.tensor([item.action for item in batch], dtype=torch.long, device=self.device).unsqueeze(1)
        rewards = torch.tensor([item.reward for item in batch], dtype=torch.float32, device=self.device).unsqueeze(1)
        next_node_feats = torch.tensor(
            np.asarray([item.next_aux_a for item in batch], dtype=np.float32),
            device=self.device,
        )
        next_adjacency = torch.tensor(
            np.asarray([item.next_aux_b for item in batch], dtype=np.float32),
            device=self.device,
        )
        done = torch.tensor([1.0 if item.done else 0.0 for item in batch], dtype=torch.float32, device=self.device).unsqueeze(1)

        q_values = self.policy(node_feats, adjacency).gather(1, actions)
        next_actions = torch.argmax(self.policy(next_node_feats, next_adjacency), dim=1, keepdim=True)
        next_q = self.target(next_node_feats, next_adjacency).gather(1, next_actions)
        target = rewards + self.gamma * next_q * (1.0 - done)
        loss = F.smooth_l1_loss(q_values, target.detach())

        self.optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.policy.parameters(), 5.0)
        self.optimizer.step()

        self.train_steps += 1
        if self.train_steps % self.target_sync == 0:
            self.target.load_state_dict(self.policy.state_dict())
