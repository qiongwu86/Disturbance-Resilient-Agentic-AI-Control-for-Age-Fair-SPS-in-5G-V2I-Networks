from __future__ import annotations

import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiment08_true_agentic_planning.planner_led_v2x_system import PlannerLedAgenticSystem, PlannerLedConfig


def main() -> None:
    output_dir = Path("paper_figures_gpt/experiment08_true_agentic_planning/stage0_smoke")
    output_dir.mkdir(parents=True, exist_ok=True)

    config = PlannerLedConfig(
        use_llm=os.getenv("EXP08_USE_LLM", "0") == "1",
        strict_llm=False,
        model_name=os.getenv("EXP08_MODEL", "gpt-4o-mini"),
        base_url=os.getenv("OPENAI_BASE_URL", ""),
        api_key=os.getenv("OPENAI_API_KEY", ""),
    )
    system = PlannerLedAgenticSystem(config=config, seed=0)

    results = {
        "simple_static": system.run_episode(scenario="simple", max_steps=18),
        "complex_shock": system.run_episode(
            scenario="complex",
            max_steps=24,
            shock_profile={"step": 8, "duration": 5, "extra_vehicles": 2, "rri_change_prob": 0.80},
        ),
    }

    output_path = output_dir / "exp08_stage0_smoke_latest.json"
    output_path.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
    print(str(output_path))


if __name__ == "__main__":
    main()
