from __future__ import annotations

import json
import logging
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("openai").setLevel(logging.WARNING)
logging.getLogger("openai._base_client").setLevel(logging.WARNING)

from experiment08_true_agentic_planning.baseline_models import DQNAgent, GNNDDQNAgent
from experiment08_true_agentic_planning.common import ActionCodec, build_graph_observation, build_metrics, build_state_vector
from experiment08_true_agentic_planning.formal_eval import _apply_shock
from experiment08_true_agentic_planning.formal_utils import build_case_seeds, make_shock_profile, save_json
from experiment08_true_agentic_planning.plain_llm_baseline import PlainLLMBaseline, PlainLLMBaselineConfig
from experiment08_true_agentic_planning.planner_led_v2x_system import (
    PlannerLedAgenticSystem,
    PlannerLedConfig,
    configure_environment_for_scenario,
)


ROOT = Path("paper_figures_gpt/experiment08_true_agentic_planning")
OUT_DIR = ROOT / "paper_selected_baselines_v42"
METHODS = ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]
METHOD_COLORS = {
    "exp08_agentic": "#0b6e4f",
    "plain_llm": "#c06c00",
    "dqn": "#355c7d",
    "gnnddqn": "#6c5b7b",
}
METHOD_LABELS = {
    "exp08_agentic": "Agentic",
    "plain_llm": "Plain LLM",
    "dqn": "DQN",
    "gnnddqn": "GNN-DDQN",
}


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _planner_config() -> PlannerLedConfig:
    return PlannerLedConfig(
        use_llm=os.getenv("EXP08_USE_LLM", "0") == "1",
        strict_llm=False,
        model_name=os.getenv("EXP08_MODEL", "openai/gpt-4o-mini"),
        base_url=os.getenv("OPENAI_BASE_URL", ""),
        api_key=os.getenv("OPENAI_API_KEY", ""),
    )


def _plain_config() -> PlainLLMBaselineConfig:
    return PlainLLMBaselineConfig(
        use_llm=os.getenv("EXP08_USE_LLM", "0") == "1",
        strict_llm=False,
        model_name=os.getenv("EXP08_MODEL", "openai/gpt-4o-mini"),
        base_url=os.getenv("OPENAI_BASE_URL", ""),
        api_key=os.getenv("OPENAI_API_KEY", ""),
    )


def _load_manifest(method: str, tag: str) -> Dict[str, Any]:
    return _load_json(ROOT / "training" / f"{method}_convergence_{tag}.json")


def _checkpoint_entries(manifest: Dict[str, Any], scenario: str) -> List[Dict[str, Any]]:
    return [entry for entry in manifest.get("scenario_runs", {}).get(scenario, []) if entry.get("checkpoint_path")]


def _load_dqn(checkpoint_path: str, train_seed: int):
    from agentic_v2x_system import V2XEnvironment

    env = V2XEnvironment()
    configure_environment_for_scenario(env, "complex")
    codec = ActionCodec([int(x) for x in env.R_set])
    agent = DQNAgent(state_dim=9, num_actions=codec.num_actions, seed=train_seed)
    payload = torch.load(checkpoint_path, map_location="cpu")
    agent.policy.load_state_dict(payload["policy_state_dict"])
    agent.target.load_state_dict(payload["target_state_dict"])
    agent.epsilon = 0.0
    return env, agent, codec


def _load_gnnddqn(checkpoint_path: str, train_seed: int):
    from agentic_v2x_system import V2XEnvironment

    env = V2XEnvironment()
    configure_environment_for_scenario(env, "complex")
    agent = GNNDDQNAgent(node_feat_dim=6, num_actions=len(env.R_set) * 2, seed=train_seed)
    payload = torch.load(checkpoint_path, map_location="cpu")
    agent.policy.load_state_dict(payload["policy_state_dict"])
    agent.target.load_state_dict(payload["target_state_dict"])
    agent.epsilon = 0.0
    return env, agent


def _decode_action(env, codec: Optional[ActionCodec], action_idx: int) -> Tuple[int, bool]:
    if codec is not None:
        return codec.decode(action_idx)
    n_rri = len(env.R_set)
    normalized = int(action_idx) % max(1, 2 * n_rri)
    branch = normalized // n_rri
    rri = int(env.R_set[normalized % n_rri])
    return rri, bool(branch == 1)


def _run_agentic(case_seed: int, shock_profile: Optional[Dict[str, Any]], max_steps: int) -> List[float]:
    system = PlannerLedAgenticSystem(config=_planner_config(), seed=case_seed)
    payload = system.run_episode(scenario="complex", max_steps=max_steps, shock_profile=shock_profile)
    return [float(x) for x in payload.get("fairness_values", [])]


def _run_plain(case_seed: int, shock_profile: Optional[Dict[str, Any]], max_steps: int) -> List[float]:
    baseline = PlainLLMBaseline(config=_plain_config(), seed=case_seed)
    state, metrics = baseline.reset("complex")
    fairness_values: List[float] = []
    shock_step = None if shock_profile is None else int(shock_profile["step"])
    for step_idx in range(int(max_steps)):
        if shock_step is not None and step_idx == shock_step:
            _apply_shock(baseline.env, shock_profile)
        decision = baseline.choose_action(state, metrics, shock_flag=bool(shock_step is not None and step_idx >= shock_step))
        mcs_action = int(state.get("agent_mcs_level", 3))
        next_state, _ = baseline.env.step(
            mcs_action,
            rri_value=int(decision["chosen_rri"]),
            force_reselect=bool(decision["force_reselect"]),
        )
        next_metrics = build_metrics(baseline.env, next_state)
        fairness_values.append(float(next_metrics.get("raafu", 0.0)))
        state, metrics = next_state, next_metrics
    return fairness_values


def _run_dqn_case(
    case_seed: int,
    shock_profile: Optional[Dict[str, Any]],
    max_steps: int,
    checkpoint_path: str,
    train_seed: int,
) -> List[float]:
    env, agent, codec = _load_dqn(checkpoint_path, train_seed)
    state = env.current_state
    metrics = build_metrics(env, state)
    prev_branch = 0
    fairness_values: List[float] = []
    shock_step = None if shock_profile is None else int(shock_profile["step"])
    for step_idx in range(int(max_steps)):
        if shock_step is not None and step_idx == shock_step:
            _apply_shock(env, shock_profile)
        obs = build_state_vector(
            state,
            metrics,
            prev_branch=prev_branch,
            shock_flag=1 if shock_step is not None and step_idx >= shock_step else 0,
        )
        action_idx = agent.act(obs)
        rri, force_reselect = _decode_action(env, codec, action_idx)
        prev_branch = 1 if force_reselect else 0
        mcs_action = int(state.get("agent_mcs_level", 3))
        next_state, _ = env.step(mcs_action, rri_value=rri, force_reselect=force_reselect)
        next_metrics = build_metrics(env, next_state)
        fairness_values.append(float(next_metrics.get("raafu", 0.0)))
        state, metrics = next_state, next_metrics
    return fairness_values


def _run_gnnddqn_case(
    case_seed: int,
    shock_profile: Optional[Dict[str, Any]],
    max_steps: int,
    checkpoint_path: str,
    train_seed: int,
) -> List[float]:
    env, agent = _load_gnnddqn(checkpoint_path, train_seed)
    state = env.current_state
    metrics = build_metrics(env, state)
    fairness_values: List[float] = []
    shock_step = None if shock_profile is None else int(shock_profile["step"])
    for step_idx in range(int(max_steps)):
        if shock_step is not None and step_idx == shock_step:
            _apply_shock(env, shock_profile)
        node_feats, adjacency = build_graph_observation(env, state, metrics)
        action_idx = agent.act(node_feats, adjacency)
        rri, force_reselect = _decode_action(env, None, action_idx)
        mcs_action = int(state.get("agent_mcs_level", 3))
        next_state, _ = env.step(mcs_action, rri_value=rri, force_reselect=force_reselect)
        next_metrics = build_metrics(env, next_state)
        fairness_values.append(float(next_metrics.get("raafu", 0.0)))
        state, metrics = next_state, next_metrics
    return fairness_values


def _mean_curve(curves: List[List[float]]) -> Tuple[List[float], List[float]]:
    arr = np.array(curves, dtype=float)
    return arr.mean(axis=0).tolist(), arr.std(axis=0).tolist()


def _build_step0_shock(case_seed: int) -> Dict[str, Any]:
    shock_profile = dict(make_shock_profile("complex", case_seed))
    shock_profile["step"] = 0
    return shock_profile


def main() -> None:
    output_tag = os.getenv("EXP08_FIG2_OUTPUT_TAG", "paper_fig2_dualtraj_r1")
    baseline_tag = os.getenv("EXP08_BASELINE_TAG", "paper_s5_e1000_1500")
    case_count = int(os.getenv("EXP08_FIG2_CASES", "32"))
    max_steps = int(os.getenv("EXP08_FIG2_STEPS", "24"))
    base_seed = int(os.getenv("EXP08_FIG2_BASE_SEED", "2000"))
    case_offset = int(os.getenv("EXP08_FIG2_OFFSET", "0"))
    limit_raw = os.getenv("EXP08_FIG2_LIMIT", "").strip()
    case_limit = None if not limit_raw else int(limit_raw)
    out_json = ROOT / f"exp08_fig2_dual_trajectory_{output_tag}.json"
    cache_json = ROOT / f"exp08_fig2_dual_trajectory_{output_tag}_cache.json"
    out_png = OUT_DIR / f"fig02_complex_dual_trajectory_{output_tag}.png"

    all_case_seeds = build_case_seeds(case_count, base_seed=base_seed)
    if case_limit is None:
        case_seeds = all_case_seeds[case_offset:]
    else:
        case_seeds = all_case_seeds[case_offset : case_offset + case_limit]
    dqn_manifest = _load_manifest("dqn", baseline_tag)
    gnnddqn_manifest = _load_manifest("gnnddqn", baseline_tag)
    dqn_entries = _checkpoint_entries(dqn_manifest, "complex")
    gnnddqn_entries = _checkpoint_entries(gnnddqn_manifest, "complex")

    if cache_json.exists():
        cache = _load_json(cache_json)
        agg: Dict[str, Dict[str, List[List[float]]]] = {
            mode: {
                method: [[float(x) for x in curve] for curve in cache.get("modes", {}).get(mode, {}).get(method, [])]
                for method in METHODS
            }
            for mode in ["no_shock", "shock_step0"]
        }
        start_idx = int(cache.get("completed_cases", 0))
    else:
        agg = {
            "no_shock": {method: [] for method in METHODS},
            "shock_step0": {method: [] for method in METHODS},
        }
        start_idx = 0

    def _save_cache(completed_cases: int) -> None:
        save_json(
            cache_json,
            {
                "completed_cases": int(completed_cases),
                "modes": agg,
            },
        )

    for case_idx, case_seed in enumerate(case_seeds[start_idx:], start=start_idx):
        shock_profile = _build_step0_shock(case_seed)

        agg["no_shock"]["exp08_agentic"].append(_run_agentic(case_seed, None, max_steps))
        agg["shock_step0"]["exp08_agentic"].append(_run_agentic(case_seed, shock_profile, max_steps))

        agg["no_shock"]["plain_llm"].append(_run_plain(case_seed, None, max_steps))
        agg["shock_step0"]["plain_llm"].append(_run_plain(case_seed, shock_profile, max_steps))

        dqn_curves_no_shock: List[List[float]] = []
        dqn_curves_shock0: List[List[float]] = []
        for entry in dqn_entries:
            train_seed = int(entry.get("train_seed", entry.get("seed", 0)))
            ckpt_path = str(entry["checkpoint_path"])
            dqn_curves_no_shock.append(_run_dqn_case(case_seed, None, max_steps, ckpt_path, train_seed))
            dqn_curves_shock0.append(_run_dqn_case(case_seed, shock_profile, max_steps, ckpt_path, train_seed))
        agg["no_shock"]["dqn"].append(np.array(dqn_curves_no_shock, dtype=float).mean(axis=0).tolist())
        agg["shock_step0"]["dqn"].append(np.array(dqn_curves_shock0, dtype=float).mean(axis=0).tolist())

        gnn_curves_no_shock: List[List[float]] = []
        gnn_curves_shock0: List[List[float]] = []
        for entry in gnnddqn_entries:
            train_seed = int(entry.get("train_seed", entry.get("seed", 0)))
            ckpt_path = str(entry["checkpoint_path"])
            gnn_curves_no_shock.append(_run_gnnddqn_case(case_seed, None, max_steps, ckpt_path, train_seed))
            gnn_curves_shock0.append(_run_gnnddqn_case(case_seed, shock_profile, max_steps, ckpt_path, train_seed))
        agg["no_shock"]["gnnddqn"].append(np.array(gnn_curves_no_shock, dtype=float).mean(axis=0).tolist())
        agg["shock_step0"]["gnnddqn"].append(np.array(gnn_curves_shock0, dtype=float).mean(axis=0).tolist())

        _save_cache(case_idx + 1)

    payload: Dict[str, Any] = {
        "tag": output_tag,
        "baseline_tag": baseline_tag,
        "case_count_total": int(case_count),
        "case_offset": int(case_offset),
        "case_limit": case_limit,
        "num_cases": int(len(case_seeds)),
        "max_steps": int(max_steps),
        "modes": {},
    }
    min_y = 1.0
    max_y = 0.0
    for mode_name, mode_curves in agg.items():
        payload["modes"][mode_name] = {
            "shock_step": None if mode_name == "no_shock" else 0,
            "methods": {},
        }
        for method, curves in mode_curves.items():
            mean_curve, std_curve = _mean_curve(curves)
            payload["modes"][mode_name]["methods"][method] = {
                "num_cases": len(curves),
                "mean_curve": mean_curve,
                "std_curve": std_curve,
                "mean_raafu": float(np.mean(mean_curve)),
            }
            method_min = min(max(0.0, x - s) for x, s in zip(mean_curve, std_curve))
            method_max = max(min(1.0, x + s) for x, s in zip(mean_curve, std_curve))
            min_y = min(min_y, method_min)
            max_y = max(max_y, method_max)
    save_json(out_json, payload)

    xs = np.arange(max_steps)
    fig, axes = plt.subplots(2, 1, figsize=(8.8, 7.2), sharex=True)
    mode_specs = [
        ("no_shock", "(a) Complex mean trajectory without shock"),
        ("shock_step0", "(b) Complex mean trajectory with shock injected at step 0"),
    ]
    lower = max(0.0, min_y - 0.02)
    upper = min(1.0, max_y + 0.03)
    if upper <= lower:
        lower, upper = 0.45, 0.80

    for ax, (mode_name, title) in zip(axes, mode_specs):
        mode_payload = payload["modes"][mode_name]["methods"]
        for method in METHODS:
            mean_curve = np.array(mode_payload[method]["mean_curve"], dtype=float)
            std_curve = np.array(mode_payload[method]["std_curve"], dtype=float)
            ax.plot(xs, mean_curve, linewidth=2.0, label=METHOD_LABELS[method], color=METHOD_COLORS[method])
            ax.fill_between(
                xs,
                np.maximum(0.0, mean_curve - std_curve),
                np.minimum(1.0, mean_curve + std_curve),
                color=METHOD_COLORS[method],
                alpha=0.12,
            )
        if mode_name == "shock_step0":
            ax.axvline(0, linestyle="--", color="black", alpha=0.65, linewidth=1.2, label="Shock onset")
        ax.set_ylabel("Mean RAAFU")
        ax.set_ylim(lower, upper)
        ax.set_xlim(-0.5, max_steps - 0.5)
        ax.set_title(title)
        ax.grid(alpha=0.25, linestyle=":")

    axes[0].legend(frameon=False, ncol=2, loc="lower left")
    axes[1].set_xlabel("Decision step")
    fig.tight_layout()
    fig.savefig(out_png, dpi=220, bbox_inches="tight")
    plt.close(fig)

    print(str(out_json).replace("\\", "/"))
    print(str(out_png).replace("\\", "/"))


if __name__ == "__main__":
    main()
