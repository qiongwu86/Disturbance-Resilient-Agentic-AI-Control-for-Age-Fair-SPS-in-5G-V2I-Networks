from __future__ import annotations

import json
import random
from pathlib import Path
from statistics import mean
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from agentic_v2x_system import V2XEnvironment
from experiment08_true_agentic_planning.baseline_models import GNNDDQNAgent
from experiment08_true_agentic_planning.common import build_graph_observation, build_metrics, compute_reward
from experiment08_true_agentic_planning.planner_led_v2x_system import configure_environment_for_scenario


def apply_shock(env: V2XEnvironment, shock_profile):
    env.N_v = min(env.N_max, int(env.N_v) + int(shock_profile.get("extra_vehicles", 2)))
    env.other_rri_mode = str(shock_profile.get("other_rri_mode", "markov_pingpong"))
    env.rri_change_prob = float(shock_profile.get("rri_change_prob", 0.75))
    env.other_rri_markov_states = list(shock_profile.get("markov_states", [20.0, 50.0, 100.0, 200.0, 500.0]))
    for idx in range(1, min(int(env.N_v), int(env.N_max))):
        env.rri_per_vehicle[idx] = float(random.choice(env.other_rri_markov_states))


def decode_action(env: V2XEnvironment, action_idx: int):
    n_rri = len(env.R_set)
    normalized = int(action_idx) % max(1, 2 * n_rri)
    branch = normalized // n_rri
    rri = int(env.R_set[normalized % n_rri])
    return rri, bool(branch == 1)


def run_scenario(seed: int, scenario: str, *, episodes: int, max_steps: int, shock_profile=None):
    random.seed(seed)
    np.random.seed(seed)
    env = V2XEnvironment()
    configure_environment_for_scenario(env, scenario)
    agent = GNNDDQNAgent(node_feat_dim=6, num_actions=len(env.R_set) * 2, seed=seed)
    episode_records = []

    for _ in range(int(episodes)):
        state = env.reset()
        metrics = build_metrics(env, state)
        fairness_values = []
        rewards = []
        shock_step = int(shock_profile["step"]) if shock_profile and "step" in shock_profile else None
        for step_idx in range(int(max_steps)):
            if shock_step is not None and step_idx == shock_step:
                apply_shock(env, shock_profile)
            node_feats, adjacency = build_graph_observation(env, state, metrics)
            action_idx = agent.act(node_feats, adjacency)
            rri, force_reselect = decode_action(env, action_idx)
            mcs_action = int(state.get("agent_mcs_level", 3))
            next_state, done = env.step(mcs_action, rri_value=rri, force_reselect=force_reselect)
            next_metrics = build_metrics(env, next_state)
            reward = compute_reward(next_metrics, metrics)
            next_node_feats, next_adjacency = build_graph_observation(env, next_state, next_metrics)
            agent.observe(node_feats, adjacency, action_idx, reward, next_node_feats, next_adjacency, done)
            fairness_values.append(float(next_metrics.get("raafu", 0.0)))
            rewards.append(float(reward))
            state = next_state
            metrics = next_metrics
            if done:
                break
        episode_records.append(
            {
                "mean_raafu": float(np.mean(fairness_values)) if fairness_values else 0.0,
                "mean_reward": float(np.mean(rewards)) if rewards else 0.0,
                "final_metrics": dict(metrics),
            }
        )

    return {
        "scenario": scenario,
        "episodes": episodes,
        "max_steps": max_steps,
        "shock_profile": shock_profile,
        "summary": {
            "mean_raafu": mean(item["mean_raafu"] for item in episode_records),
            "mean_reward": mean(item["mean_reward"] for item in episode_records),
            "epsilon_final": float(agent.epsilon),
        },
        "records": episode_records,
    }


def main() -> None:
    output_dir = Path("paper_figures_gpt/experiment08_true_agentic_planning/baselines")
    output_dir.mkdir(parents=True, exist_ok=True)

    seeds = [0, 1]
    payload = {"seeds": seeds, "runs": []}
    for seed in seeds:
        payload["runs"].append(
            {
                "seed": seed,
                "simple_static": run_scenario(seed, "simple", episodes=12, max_steps=24),
                "complex_static": run_scenario(seed, "complex", episodes=12, max_steps=24),
                "complex_shock": run_scenario(
                    seed,
                    "complex",
                    episodes=12,
                    max_steps=28,
                    shock_profile={"step": 10, "duration": 5, "extra_vehicles": 3, "rri_change_prob": 0.85},
                ),
            }
        )

    output_path = output_dir / "exp08_gnnddqn_baseline_latest.json"
    output_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(str(output_path))


if __name__ == "__main__":
    main()
