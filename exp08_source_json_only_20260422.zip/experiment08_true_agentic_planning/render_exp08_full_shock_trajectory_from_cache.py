from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("paper_figures_gpt/experiment08_true_agentic_planning/paper_selected_baselines_v42")
CACHE_JSON = ROOT / "exp08_complex_shock_trajectory_selected_v42_cache.json"
OUT_JSON = ROOT / "exp08_complex_shock_trajectory_selected_v42.json"
OUT_PNG = ROOT / "fig02_complex_shock_trajectory_selected_v42.png"
METHOD_COLORS = {
    "exp08_agentic": "#0b6e4f",
    "plain_llm": "#c06c00",
    "dqn": "#355c7d",
    "gnnddqn": "#6c5b7b",
}
METHOD_LABELS = {
    "exp08_agentic": "Agentic",
    "plain_llm": "Plain LLM",
    "dqn": "DQN",
    "gnnddqn": "GNN-DDQN",
}


def _mean_curve(curves: List[List[float]]) -> Tuple[List[float], List[float]]:
    arr = np.array(curves, dtype=float)
    return arr.mean(axis=0).tolist(), arr.std(axis=0).tolist()


def main() -> None:
    cache = json.loads(CACHE_JSON.read_text(encoding="utf-8"))
    agg: Dict[str, List[List[float]]] = cache["agg"]
    summary = {
        "completed_cases": int(cache.get("completed_cases", 0)),
        "methods": {},
    }
    steps = None
    for method, curves in agg.items():
        mean_curve, std_curve = _mean_curve(curves)
        summary["methods"][method] = {
            "num_cases": len(curves),
            "mean_curve": mean_curve,
            "std_curve": std_curve,
            "mean_raafu": float(np.mean(mean_curve)),
        }
        steps = len(mean_curve)
    OUT_JSON.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    visible_steps = min(int(steps), 21)
    x = np.arange(visible_steps)
    plt.figure(figsize=(8.8, 4.8))
    for method in ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]:
        mean_curve = np.array(summary["methods"][method]["mean_curve"], dtype=float)[:visible_steps]
        std_curve = np.array(summary["methods"][method]["std_curve"], dtype=float)[:visible_steps]
        plt.plot(x, mean_curve, label=METHOD_LABELS[method], color=METHOD_COLORS[method], linewidth=2.2)
        plt.fill_between(
            x,
            np.maximum(0.0, mean_curve - std_curve),
            np.minimum(1.0, mean_curve + std_curve),
            color=METHOD_COLORS[method],
            alpha=0.12,
        )
    plt.axvline(8, color="#444444", linestyle="--", linewidth=1.4, label="Shock Onset")
    plt.xlabel("Decision Step")
    plt.ylabel("Mean RAAFU")
    title = "Full Complex Shock Mean Trajectory"
    if summary["completed_cases"] < 32:
        title += f" ({summary['completed_cases']}/32 cases rendered)"
    plt.title(title)
    plt.ylim(0.45, 0.80)
    plt.xlim(-0.5, visible_steps - 0.5)
    plt.grid(alpha=0.22, linestyle=":")
    plt.legend(frameon=False, ncol=3)
    plt.tight_layout()
    plt.savefig(OUT_PNG, dpi=220, bbox_inches="tight")
    plt.close()


if __name__ == "__main__":
    main()
