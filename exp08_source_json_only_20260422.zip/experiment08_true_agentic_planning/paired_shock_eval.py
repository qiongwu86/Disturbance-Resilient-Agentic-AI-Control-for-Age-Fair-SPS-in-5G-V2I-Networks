from __future__ import annotations

import copy
import json
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import torch

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from agentic_v2x_system import V2XEnvironment

from experiment08_true_agentic_planning.baseline_models import DQNAgent, DQNStrongAgent, GNNDDQNAgent
from experiment08_true_agentic_planning.common import ActionCodec, build_graph_observation, build_metrics, build_state_vector
from experiment08_true_agentic_planning.formal_utils import build_case_seeds, save_json, set_global_seed
from experiment08_true_agentic_planning.plain_llm_baseline import PlainLLMBaseline, PlainLLMBaselineConfig
from experiment08_true_agentic_planning.planner_led_v2x_system import (
    PlannerLedAgenticSystem,
    PlannerLedConfig,
    configure_environment_for_scenario,
)


DEFAULT_OUT_ROOT = Path("paper_figures_gpt/experiment08_true_agentic_planning")
DEFAULT_MARKOV_STATES = [20.0, 50.0, 100.0, 200.0, 500.0]
SUPPORTED_METHODS = ["exp08_agentic", "plain_llm", "dqn", "dqn_strong", "gnnddqn"]


def parse_int_list(raw: str, default: Iterable[int]) -> List[int]:
    text = str(raw or "").strip()
    if not text:
        return [int(x) for x in default]
    return [int(item.strip()) for item in text.split(",") if item.strip()]


def parse_float_list(raw: str, default: Iterable[float]) -> List[float]:
    text = str(raw or "").strip()
    if not text:
        return [float(x) for x in default]
    return [float(item.strip()) for item in text.split(",") if item.strip()]


def parse_text_list(raw: str, default: Iterable[str]) -> List[str]:
    text = str(raw or "").strip()
    if not text:
        return [str(x).strip() for x in default]
    return [item.strip() for item in text.split(",") if item.strip()]


def _safe_div(numerator: float, denominator: float, default: float = 0.0) -> float:
    if abs(float(denominator)) <= 1e-12:
        return float(default)
    return float(float(numerator) / float(denominator))


def _pad_curve(values: Sequence[float], max_steps: int) -> np.ndarray:
    out = np.full((int(max_steps),), np.nan, dtype=float)
    if not values:
        return out
    n = min(int(max_steps), len(values))
    out[:n] = np.asarray(values[:n], dtype=float)
    return out


def _nanmean_curve(curves: List[Sequence[float]], max_steps: int) -> np.ndarray:
    if not curves:
        return np.zeros((int(max_steps),), dtype=float)
    arr = np.stack([_pad_curve(curve, max_steps) for curve in curves], axis=0)
    return np.nanmean(arr, axis=0)


def _nanstd_curve(curves: List[Sequence[float]], max_steps: int) -> np.ndarray:
    if not curves:
        return np.zeros((int(max_steps),), dtype=float)
    arr = np.stack([_pad_curve(curve, max_steps) for curve in curves], axis=0)
    return np.nanstd(arr, axis=0)


def _curve_mean(values: Sequence[float]) -> float:
    arr = np.asarray(values, dtype=float)
    if arr.size == 0:
        return 0.0
    return float(np.nanmean(arr))


def build_shock_profile_template(
    *,
    step: int,
    duration: int,
    extra_vehicles: int,
    rri_change_prob: float,
    markov_ps: float,
    runtime_mode: str = "windowed",
    other_rri_mode: str = "markov_pingpong",
    markov_states: Optional[Sequence[float]] = None,
) -> Dict[str, Any]:
    states = [float(x) for x in (markov_states or DEFAULT_MARKOV_STATES)]
    return {
        "step": int(step),
        "duration": max(1, int(duration)),
        "extra_vehicles": int(extra_vehicles),
        "rri_change_prob": float(rri_change_prob),
        "markov_ps": float(markov_ps),
        "runtime_mode": str(runtime_mode),
        "other_rri_mode": str(other_rri_mode),
        "markov_states": states,
    }


def make_case_shock_profile(template: Dict[str, Any], case_seed: int) -> Dict[str, Any]:
    profile = copy.deepcopy(template)
    profile["seed"] = int(case_seed)
    return profile


def _resolve_checkpoint_path(path_text: str) -> Path:
    raw = str(path_text or "").replace("\\", "/")
    path = Path(raw)
    if path.is_absolute():
        return path
    return ROOT_DIR / path


def _decode_action(env: V2XEnvironment, codec: Optional[ActionCodec], action_idx: int) -> Tuple[int, bool]:
    if codec is not None:
        return codec.decode(action_idx)
    n_rri = len(env.R_set)
    normalized = int(action_idx) % max(1, 2 * n_rri)
    branch = normalized // n_rri
    rri = int(env.R_set[normalized % n_rri])
    return rri, bool(branch == 1)


class ShockController:
    def __init__(self, env: V2XEnvironment, shock_profile: Optional[Dict[str, Any]]) -> None:
        self.env = env
        self.profile = copy.deepcopy(shock_profile) if shock_profile is not None else None
        self.applied = False
        self._snapshot: Optional[Dict[str, Any]] = None
        self.step = int(self.profile.get("step", -1)) if self.profile else -1
        self.duration = max(1, int(self.profile.get("duration", 1))) if self.profile else 0
        self.runtime_mode = str(self.profile.get("runtime_mode", "windowed")).strip().lower() if self.profile else "none"

    def enabled(self) -> bool:
        return self.profile is not None and self.step >= 0

    def _capture(self) -> None:
        self._snapshot = {
            "N_v": int(self.env.N_v),
            "other_rri_mode": str(self.env.other_rri_mode),
            "rri_change_prob": float(self.env.rri_change_prob),
            "other_rri_markov_ps": float(getattr(self.env, "other_rri_markov_ps", 1.0)),
            "other_rri_markov_states": [float(x) for x in getattr(self.env, "other_rri_markov_states", DEFAULT_MARKOV_STATES)],
            "rri_per_vehicle": np.asarray(self.env.rri_per_vehicle, dtype=float).copy(),
        }

    def _apply(self) -> None:
        if not self.profile:
            return
        if self._snapshot is None:
            self._capture()
        self.applied = True
        extra_vehicles = max(0, int(self.profile.get("extra_vehicles", 2)))
        self.env.N_v = min(self.env.N_max, int(self.env.N_v) + extra_vehicles)
        self.env.other_rri_mode = str(self.profile.get("other_rri_mode", "markov_pingpong"))
        self.env.rri_change_prob = float(self.profile.get("rri_change_prob", 0.75))
        if "markov_ps" in self.profile:
            self.env.other_rri_markov_ps = float(self.profile.get("markov_ps", self.env.other_rri_markov_ps))
        self.env.other_rri_markov_states = [float(x) for x in self.profile.get("markov_states", DEFAULT_MARKOV_STATES)]
        states = self.env.other_rri_markov_states
        if not states:
            return
        for idx in range(1, min(int(self.env.N_v), int(self.env.N_max))):
            self.env.rri_per_vehicle[idx] = float(states[(idx + max(0, self.step)) % len(states)])

    def _restore(self) -> None:
        if self._snapshot is None:
            return
        self.env.N_v = int(self._snapshot["N_v"])
        self.env.other_rri_mode = str(self._snapshot["other_rri_mode"])
        self.env.rri_change_prob = float(self._snapshot["rri_change_prob"])
        self.env.other_rri_markov_ps = float(self._snapshot["other_rri_markov_ps"])
        self.env.other_rri_markov_states = [float(x) for x in self._snapshot["other_rri_markov_states"]]
        self.env.rri_per_vehicle = np.asarray(self._snapshot["rri_per_vehicle"], dtype=float).copy()
        self.applied = False

    def update_before_step(self, step_idx: int) -> None:
        if not self.enabled():
            return
        if self.runtime_mode == "windowed" and self.applied and step_idx >= self.step + self.duration:
            self._restore()
        if (not self.applied) and step_idx == self.step:
            self._apply()

    def shock_flag(self, step_idx: int) -> bool:
        if not self.enabled():
            return False
        if self.runtime_mode == "windowed":
            return bool(self.step <= step_idx < self.step + self.duration)
        return bool(step_idx >= self.step)

    def finalize(self) -> None:
        if self.runtime_mode == "windowed" and self.applied:
            self._restore()


@dataclass
class PairedEvalConfig:
    scenario: str = "complex"
    case_count: int = 32
    max_steps: int = 24
    base_seed: int = 2000
    case_offset: int = 0
    case_limit: Optional[int] = None
    baseline_tag: str = "paper_s5_e1000_1500"
    methods: Optional[List[str]] = None


class PairedShockEvaluator:
    def __init__(self, config: PairedEvalConfig) -> None:
        self.config = config
        requested = config.methods or ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]
        self.methods = [name for name in requested if name in SUPPORTED_METHODS]
        if not self.methods:
            raise ValueError("No valid methods selected.")

        self.planner_config = PlannerLedConfig(
            use_llm=os.getenv("EXP08_USE_LLM", "0") == "1",
            strict_llm=False,
            model_name=os.getenv("EXP08_MODEL", "openai/gpt-4o-mini"),
            base_url=os.getenv("OPENAI_BASE_URL", ""),
            api_key=os.getenv("OPENAI_API_KEY", ""),
        )
        self.plain_config = PlainLLMBaselineConfig(
            use_llm=os.getenv("EXP08_USE_LLM", "0") == "1",
            strict_llm=False,
            model_name=os.getenv("EXP08_MODEL", "openai/gpt-4o-mini"),
            base_url=os.getenv("OPENAI_BASE_URL", ""),
            api_key=os.getenv("OPENAI_API_KEY", ""),
        )

        self.dqn_entries = self._checkpoint_entries("dqn") if "dqn" in self.methods else []
        self.dqn_strong_entries = self._checkpoint_entries("dqn_strong") if "dqn_strong" in self.methods else []
        self.gnn_entries = self._checkpoint_entries("gnnddqn") if "gnnddqn" in self.methods else []

    def _manifest_path(self, method: str) -> Path:
        return DEFAULT_OUT_ROOT / "training" / f"{method}_convergence_{self.config.baseline_tag}.json"

    def _load_manifest(self, method: str) -> Dict[str, Any]:
        path = self._manifest_path(method)
        if not path.exists():
            raise FileNotFoundError(f"Missing manifest: {path}")
        return json.loads(path.read_text(encoding="utf-8"))

    def _checkpoint_entries(self, method: str) -> List[Dict[str, Any]]:
        payload = self._load_manifest(method)
        rows = payload.get("scenario_runs", {}).get(self.config.scenario, [])
        return [dict(row) for row in rows if row.get("checkpoint_path")]

    def _selected_case_indices(self) -> List[int]:
        start = max(0, int(self.config.case_offset))
        total = max(0, int(self.config.case_count))
        if start >= total:
            return []
        if self.config.case_limit is None or int(self.config.case_limit) < 0:
            end = total
        else:
            end = min(total, start + int(self.config.case_limit))
        return list(range(start, end))

    def _case_seeds(self) -> List[int]:
        seeds = build_case_seeds(self.config.case_count, base_seed=self.config.base_seed)
        return [int(seeds[idx]) for idx in self._selected_case_indices()]

    def _run_agentic(self, case_seed: int, shock_profile: Optional[Dict[str, Any]]) -> List[float]:
        set_global_seed(case_seed)
        system = PlannerLedAgenticSystem(config=self.planner_config, seed=case_seed)
        payload = system.run_episode(scenario=self.config.scenario, max_steps=self.config.max_steps, shock_profile=shock_profile)
        return [float(x) for x in payload.get("fairness_values", [])][: self.config.max_steps]

    def _run_plain_llm(self, case_seed: int, shock_profile: Optional[Dict[str, Any]]) -> List[float]:
        set_global_seed(case_seed)
        baseline = PlainLLMBaseline(config=self.plain_config, seed=case_seed)
        state, metrics = baseline.reset(self.config.scenario)
        controller = ShockController(baseline.env, shock_profile)
        fairness_values: List[float] = []

        for step_idx in range(int(self.config.max_steps)):
            controller.update_before_step(step_idx)
            decision = baseline.choose_action(state, metrics, shock_flag=controller.shock_flag(step_idx))
            mcs_action = int(state.get("agent_mcs_level", 3))
            next_state, done = baseline.env.step(
                mcs_action,
                rri_value=int(decision["chosen_rri"]),
                force_reselect=bool(decision["force_reselect"]),
            )
            next_metrics = build_metrics(baseline.env, next_state)
            fairness_values.append(float(next_metrics.get("raafu", 0.0)))
            state, metrics = next_state, next_metrics
            if done:
                break
        controller.finalize()
        return fairness_values[: self.config.max_steps]

    def _load_dqn_from_checkpoint(self, method: str, checkpoint_path: str, train_seed: int):
        env = V2XEnvironment()
        configure_environment_for_scenario(env, self.config.scenario)
        codec = ActionCodec([int(x) for x in env.R_set])
        if method == "dqn":
            agent = DQNAgent(state_dim=9, num_actions=codec.num_actions, seed=train_seed)
        else:
            agent = DQNStrongAgent(state_dim=9, num_actions=codec.num_actions, seed=train_seed)
        payload = torch.load(_resolve_checkpoint_path(checkpoint_path), map_location="cpu")
        agent.policy.load_state_dict(payload["policy_state_dict"])
        agent.target.load_state_dict(payload["target_state_dict"])
        agent.epsilon = 0.0
        return env, agent, codec

    def _run_dqn_like(
        self,
        method: str,
        case_seed: int,
        shock_profile: Optional[Dict[str, Any]],
        entries: List[Dict[str, Any]],
    ) -> List[float]:
        replicate_curves: List[List[float]] = []
        for entry in entries:
            set_global_seed(case_seed)
            env, agent, codec = self._load_dqn_from_checkpoint(method, str(entry["checkpoint_path"]), int(entry["seed"]))
            state = env.current_state
            metrics = build_metrics(env, state)
            previous_branch = 0
            controller = ShockController(env, shock_profile)
            fairness_values: List[float] = []
            for step_idx in range(int(self.config.max_steps)):
                controller.update_before_step(step_idx)
                obs = build_state_vector(
                    state,
                    metrics,
                    prev_branch=previous_branch,
                    shock_flag=1 if controller.shock_flag(step_idx) else 0,
                )
                action_idx = agent.act(obs)
                rri, force_reselect = _decode_action(env, codec, action_idx)
                previous_branch = 1 if force_reselect else 0
                mcs_action = int(state.get("agent_mcs_level", 3))
                next_state, done = env.step(mcs_action, rri_value=rri, force_reselect=force_reselect)
                next_metrics = build_metrics(env, next_state)
                fairness_values.append(float(next_metrics.get("raafu", 0.0)))
                state, metrics = next_state, next_metrics
                if done:
                    break
            controller.finalize()
            replicate_curves.append(fairness_values[: self.config.max_steps])
        return _nanmean_curve(replicate_curves, self.config.max_steps).tolist()

    def _load_gnn_from_checkpoint(self, checkpoint_path: str, train_seed: int):
        env = V2XEnvironment()
        configure_environment_for_scenario(env, self.config.scenario)
        agent = GNNDDQNAgent(node_feat_dim=6, num_actions=len(env.R_set) * 2, seed=train_seed)
        payload = torch.load(_resolve_checkpoint_path(checkpoint_path), map_location="cpu")
        agent.policy.load_state_dict(payload["policy_state_dict"])
        agent.target.load_state_dict(payload["target_state_dict"])
        agent.epsilon = 0.0
        return env, agent

    def _run_gnn(self, case_seed: int, shock_profile: Optional[Dict[str, Any]]) -> List[float]:
        replicate_curves: List[List[float]] = []
        for entry in self.gnn_entries:
            set_global_seed(case_seed)
            env, agent = self._load_gnn_from_checkpoint(str(entry["checkpoint_path"]), int(entry["seed"]))
            state = env.current_state
            metrics = build_metrics(env, state)
            controller = ShockController(env, shock_profile)
            fairness_values: List[float] = []
            for step_idx in range(int(self.config.max_steps)):
                controller.update_before_step(step_idx)
                node_feats, adjacency = build_graph_observation(env, state, metrics)
                action_idx = agent.act(node_feats, adjacency)
                rri, force_reselect = _decode_action(env, None, action_idx)
                mcs_action = int(state.get("agent_mcs_level", 3))
                next_state, done = env.step(mcs_action, rri_value=rri, force_reselect=force_reselect)
                next_metrics = build_metrics(env, next_state)
                fairness_values.append(float(next_metrics.get("raafu", 0.0)))
                state, metrics = next_state, next_metrics
                if done:
                    break
            controller.finalize()
            replicate_curves.append(fairness_values[: self.config.max_steps])
        return _nanmean_curve(replicate_curves, self.config.max_steps).tolist()

    def _run_method_curve(self, method: str, case_seed: int, shock_profile: Optional[Dict[str, Any]]) -> List[float]:
        if method == "exp08_agentic":
            return self._run_agentic(case_seed, shock_profile)
        if method == "plain_llm":
            return self._run_plain_llm(case_seed, shock_profile)
        if method == "dqn":
            return self._run_dqn_like("dqn", case_seed, shock_profile, self.dqn_entries)
        if method == "dqn_strong":
            return self._run_dqn_like("dqn_strong", case_seed, shock_profile, self.dqn_strong_entries)
        if method == "gnnddqn":
            return self._run_gnn(case_seed, shock_profile)
        raise ValueError(f"Unsupported method: {method}")

    @staticmethod
    def _paired_metrics(no_shock_curve: Sequence[float], shock_curve: Sequence[float]) -> Dict[str, float]:
        no = np.asarray(no_shock_curve, dtype=float)
        sh = np.asarray(shock_curve, dtype=float)
        n = min(no.size, sh.size)
        if n <= 0:
            return {
                "mean_delta": 0.0,
                "cumulative_loss": 0.0,
                "worst_drop": 0.0,
                "end_gap": 0.0,
                "mean_retention": 0.0,
            }
        no = no[:n]
        sh = sh[:n]
        delta = sh - no
        losses = no - sh
        retention = np.asarray([_safe_div(float(sh[i]), float(no[i]), default=0.0) for i in range(n)], dtype=float)
        return {
            "mean_delta": float(np.mean(delta)),
            "cumulative_loss": float(np.sum(losses)),
            "worst_drop": float(np.min(delta)),
            "end_gap": float(no[-1] - sh[-1]),
            "mean_retention": float(np.mean(retention)),
        }

    def evaluate_profile(
        self,
        *,
        label: str,
        shock_profile_template: Dict[str, Any],
        include_case_details: bool = True,
    ) -> Dict[str, Any]:
        case_rows: List[Dict[str, Any]] = []
        by_method_no: Dict[str, List[List[float]]] = {method: [] for method in self.methods}
        by_method_sh: Dict[str, List[List[float]]] = {method: [] for method in self.methods}
        per_method_case_metrics: Dict[str, List[Dict[str, float]]] = {method: [] for method in self.methods}

        for case_idx, case_seed in enumerate(self._case_seeds()):
            case_id = f"{self.config.scenario}_{case_idx:03d}"
            shock_profile = make_case_shock_profile(shock_profile_template, case_seed)
            mode_payload = {"no_shock": {"methods": {}}, "shock": {"methods": {}}}
            case_metric_payload: Dict[str, Dict[str, float]] = {}

            for method in self.methods:
                no_curve = self._run_method_curve(method, case_seed, None)
                sh_curve = self._run_method_curve(method, case_seed, shock_profile)
                by_method_no[method].append(no_curve)
                by_method_sh[method].append(sh_curve)
                metrics = self._paired_metrics(no_curve, sh_curve)
                per_method_case_metrics[method].append(metrics)
                case_metric_payload[method] = metrics
                mode_payload["no_shock"]["methods"][method] = {
                    "fairness_curve": [float(x) for x in no_curve],
                    "mean_raafu": float(_curve_mean(no_curve)),
                }
                mode_payload["shock"]["methods"][method] = {
                    "fairness_curve": [float(x) for x in sh_curve],
                    "mean_raafu": float(_curve_mean(sh_curve)),
                }

            if include_case_details:
                case_rows.append(
                    {
                        "case_id": case_id,
                        "case_seed": int(case_seed),
                        "shock_profile": shock_profile,
                        "modes": mode_payload,
                        "paired_metrics": case_metric_payload,
                    }
                )

        method_summary: Dict[str, Any] = {}
        for method in self.methods:
            mean_no = _nanmean_curve(by_method_no[method], self.config.max_steps)
            std_no = _nanstd_curve(by_method_no[method], self.config.max_steps)
            mean_sh = _nanmean_curve(by_method_sh[method], self.config.max_steps)
            std_sh = _nanstd_curve(by_method_sh[method], self.config.max_steps)
            delta = mean_sh - mean_no
            retention = np.asarray([_safe_div(float(mean_sh[i]), float(mean_no[i]), default=0.0) for i in range(self.config.max_steps)], dtype=float)
            case_metrics = per_method_case_metrics[method]
            method_summary[method] = {
                "no_shock": {
                    "mean_curve": [float(x) for x in mean_no.tolist()],
                    "std_curve": [float(x) for x in std_no.tolist()],
                    "mean_raafu": float(np.nanmean(mean_no)),
                },
                "shock": {
                    "mean_curve": [float(x) for x in mean_sh.tolist()],
                    "std_curve": [float(x) for x in std_sh.tolist()],
                    "mean_raafu": float(np.nanmean(mean_sh)),
                },
                "paired": {
                    "delta_curve": [float(x) for x in delta.tolist()],
                    "retention_curve": [float(x) for x in retention.tolist()],
                    "mean_case_metrics": {
                        "mean_delta": float(np.mean([row["mean_delta"] for row in case_metrics])) if case_metrics else 0.0,
                        "cumulative_loss": float(np.mean([row["cumulative_loss"] for row in case_metrics])) if case_metrics else 0.0,
                        "worst_drop": float(np.mean([row["worst_drop"] for row in case_metrics])) if case_metrics else 0.0,
                        "end_gap": float(np.mean([row["end_gap"] for row in case_metrics])) if case_metrics else 0.0,
                        "mean_retention": float(np.mean([row["mean_retention"] for row in case_metrics])) if case_metrics else 0.0,
                    },
                },
            }

        return {
            "label": str(label),
            "scenario": str(self.config.scenario),
            "max_steps": int(self.config.max_steps),
            "case_count_selected": int(len(self._case_seeds())),
            "shock_profile_template": copy.deepcopy(shock_profile_template),
            "methods": list(self.methods),
            "aggregate": {"methods": method_summary},
            "cases": case_rows if include_case_details else [],
        }

    def evaluate_profiles(
        self,
        *,
        experiment_type: str,
        output_tag: str,
        profiles: List[Dict[str, Any]],
        include_case_details: bool = False,
    ) -> Dict[str, Any]:
        rows: List[Dict[str, Any]] = []
        for item in profiles:
            rows.append(
                self.evaluate_profile(
                    label=str(item["label"]),
                    shock_profile_template=dict(item["shock_profile_template"]),
                    include_case_details=include_case_details,
                )
            )
        return {
            "protocol_version": "exp08_paired_shock_v1",
            "experiment_type": str(experiment_type),
            "tag": str(output_tag),
            "config": {
                "scenario": str(self.config.scenario),
                "case_count": int(self.config.case_count),
                "max_steps": int(self.config.max_steps),
                "base_seed": int(self.config.base_seed),
                "case_offset": int(self.config.case_offset),
                "case_limit": None if self.config.case_limit is None else int(self.config.case_limit),
                "baseline_tag": str(self.config.baseline_tag),
                "methods": list(self.methods),
                "llm_enabled": bool(self.planner_config.use_llm),
                "llm_model": str(self.planner_config.model_name),
            },
            "profiles": rows,
        }


def save_payload(payload: Dict[str, Any], output_name: str) -> Path:
    out_path = DEFAULT_OUT_ROOT / str(output_name)
    save_json(out_path, payload)
    return out_path
