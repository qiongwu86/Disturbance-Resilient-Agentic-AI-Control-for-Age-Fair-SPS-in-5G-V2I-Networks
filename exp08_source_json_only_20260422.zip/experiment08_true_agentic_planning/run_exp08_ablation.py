from __future__ import annotations

import json
import os
from dataclasses import replace
from pathlib import Path
import sys
from types import MethodType
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiment08_true_agentic_planning.formal_eval import (  # noqa: E402
    _compute_agentic_utility_stats,
    _planner_config_from_env,
    _plain_llm_config_from_env,
    _run_plain_llm_case,
)
from experiment08_true_agentic_planning.formal_utils import (  # noqa: E402
    build_case_seeds,
    compute_shock_metrics,
    make_shock_profile,
    save_json,
    set_global_seed,
)
from experiment08_true_agentic_planning.planner_led_v2x_system import (  # noqa: E402
    PlannerLedAgenticSystem,
    PlannerLedConfig,
)


ABLATION_VARIANTS = [
    "full",
    "no_memory",
    "fixed_tool_chain",
    "no_counterfactual",
    "no_reflection",
    "plain_llm_like",
]


def _mean(values: List[float]) -> float:
    if not values:
        return 0.0
    return float(sum(values) / len(values))


def _safe_float(value: Any) -> float:
    try:
        return float(value)
    except Exception:
        return 0.0


def _extract_metric(payload: Any, key: str) -> float:
    if isinstance(payload, list):
        return _mean([_safe_float(item.get(key, 0.0)) for item in payload])
    return _safe_float(payload.get(key, 0.0))


def _summarize_cases(case_rows: List[Dict[str, Any]], variants: List[str]) -> Dict[str, Any]:
    metric_keys = [
        "mean_raafu",
        "mean_reward",
        "shock_floor",
        "recovery_integrity",
        "shock_response_lag",
        "degradation_area",
    ]
    summary: Dict[str, Any] = {}
    for variant in variants:
        summary[variant] = {
            key: _mean([_extract_metric(case["results"][variant], key) for case in case_rows])
            for key in metric_keys
        }
    return summary


def _patch_variant(system: PlannerLedAgenticSystem, variant: str) -> None:
    if variant == "no_memory":
        system.memory.query = lambda *_args, **_kwargs: []
        system.memory.add = lambda *_args, **_kwargs: None
        return

    if variant == "fixed_tool_chain":
        def _fixed_enforce(self, requested_tools, observation, analysis):
            chain = ["memory_query", "rollout_candidates", "counterfactual"]
            if str(analysis.dominant_risk).strip().lower() == "collision":
                chain = ["memory_query", "rollout_candidates", "constraint_check"]
            return chain[: self.config.max_tools_per_step]

        system._enforce_tool_sequence = MethodType(_fixed_enforce, system)
        return

    if variant == "no_counterfactual":
        def _no_counterfactual(self, requested_tools, observation, analysis):
            original = PlannerLedAgenticSystem._enforce_tool_sequence(self, requested_tools, observation, analysis)
            filtered = [tool for tool in original if tool != "counterfactual"]
            if not filtered:
                filtered = ["memory_query", "rollout_candidates"][: self.config.max_tools_per_step]
            return filtered

        system._enforce_tool_sequence = MethodType(_no_counterfactual, system)


def _run_agentic_variant_case(
    scenario: str,
    case_seed: int,
    max_steps: int,
    shock_profile: Dict[str, Any],
    base_config: PlannerLedConfig,
    variant: str,
) -> Dict[str, Any]:
    config = replace(base_config)
    if variant == "no_memory":
        config.max_memory_hits = 0
    if variant == "no_reflection":
        config.reflection_enable = False

    set_global_seed(case_seed)
    system = PlannerLedAgenticSystem(config=config, seed=case_seed)
    if variant not in {"full", "no_reflection"}:
        _patch_variant(system, variant)
    payload = system.run_episode(scenario=scenario, max_steps=max_steps, shock_profile=shock_profile)
    result = {
        "mean_raafu": float(payload["agentic_stats"].get("mean_raafu", 0.0)),
        "mean_reward": float(payload["agentic_stats"].get("mean_reward", 0.0)),
        "final_metrics": dict(payload.get("final_metrics", {})),
        "trace_ref": {"num_steps": len(payload.get("traces", []))},
        "agentic_stats": dict(payload.get("agentic_stats", {})),
        "utility_stats": _compute_agentic_utility_stats(payload.get("traces", [])),
    }
    result.update(compute_shock_metrics(payload.get("fairness_values", []), shock_profile))
    return result


def main() -> None:
    output_tag = os.getenv("EXP08_OUTPUT_TAG", "latest")
    case_count = int(os.getenv("EXP08_ABLATION_CASES", "16"))
    max_steps = int(os.getenv("EXP08_ABLATION_STEPS", "24"))
    scenario = os.getenv("EXP08_ABLATION_SCENARIO", "complex")
    case_offset = max(0, int(os.getenv("EXP08_ABLATION_OFFSET", "0")))
    raw_limit = int(os.getenv("EXP08_ABLATION_LIMIT", "-1"))
    case_limit = None if raw_limit < 0 else max(0, raw_limit)
    variants_raw = str(os.getenv("EXP08_ABLATION_VARIANTS", ",".join(ABLATION_VARIANTS))).strip()
    variants = [item.strip() for item in variants_raw.split(",") if item.strip()]

    planner_config = _planner_config_from_env()
    plain_llm_config = _plain_llm_config_from_env()
    case_rows: List[Dict[str, Any]] = []
    case_seeds = build_case_seeds(case_count, base_seed=5000)
    selected_indices = list(range(case_offset, len(case_seeds))) if case_limit is None else list(range(case_offset, min(len(case_seeds), case_offset + case_limit)))
    output_path = Path("paper_figures_gpt/experiment08_true_agentic_planning") / f"exp08_ablation_{output_tag}.json"

    def _save_partial() -> None:
        payload = {
            "protocol_version": "exp08_ablation_v1",
            "experiment_type": "ablation",
            "tag": output_tag,
            "config": {
                "scenario": scenario,
                "case_count": int(case_count),
                "max_steps": int(max_steps),
                "variants": list(variants),
                "llm_enabled": planner_config.use_llm,
                "llm_model": planner_config.model_name,
                "case_offset": int(case_offset),
                "case_limit": case_limit,
                "selected_indices": list(selected_indices),
            },
            "cases": case_rows,
            "summary": _summarize_cases(case_rows, variants),
        }
        save_json(output_path, payload)

    for case_idx in selected_indices:
        case_seed = case_seeds[case_idx]
        set_global_seed(case_seed)
        shock_profile = make_shock_profile(scenario, case_seed)
        shock_profile = dict(shock_profile)
        shock_profile["step"] = min(int(shock_profile.get("step", 0)), max(1, int(max_steps) - 2))

        results: Dict[str, Any] = {}
        for variant in variants:
            if variant == "plain_llm_like":
                results[variant] = _run_plain_llm_case(scenario, case_seed, max_steps, shock_profile, plain_llm_config)
            else:
                results[variant] = _run_agentic_variant_case(
                    scenario,
                    case_seed,
                    max_steps,
                    shock_profile,
                    planner_config,
                    variant,
                )

        case_rows.append(
            {
                "case_id": f"{scenario}_{case_idx:03d}",
                "scenario": scenario,
                "case_seed": int(case_seed),
                "shock_profile": shock_profile,
                "results": results,
            }
        )
        _save_partial()
    _save_partial()
    print(str(output_path).replace("\\", "/"))


if __name__ == "__main__":
    main()
