from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import torch

from agentic_v2x_system import V2XEnvironment

from .baseline_models import DQNAgent, DQNStrongAgent, GNNDDQNAgent
from .common import ActionCodec, build_graph_observation, build_metrics, build_state_vector, compute_reward
from .formal_utils import build_case_seeds, compute_shock_metrics, formal_payload, make_shock_profile, save_json, set_global_seed
from .planner_led_v2x_system import PlannerLedAgenticSystem, PlannerLedConfig, configure_environment_for_scenario
from .plain_llm_baseline import PlainLLMBaseline, PlainLLMBaselineConfig


def _apply_shock(env: V2XEnvironment, shock_profile: Optional[Dict[str, Any]]) -> None:
    if not shock_profile:
        return
    env.N_v = min(env.N_max, int(env.N_v) + int(shock_profile.get("extra_vehicles", 2)))
    env.other_rri_mode = str(shock_profile.get("other_rri_mode", "markov_pingpong"))
    env.rri_change_prob = float(shock_profile.get("rri_change_prob", 0.75))
    if "markov_ps" in shock_profile:
        env.other_rri_markov_ps = float(shock_profile.get("markov_ps", env.other_rri_markov_ps))
    env.other_rri_markov_states = list(shock_profile.get("markov_states", [20.0, 50.0, 100.0, 200.0, 500.0]))
    for idx in range(1, min(int(env.N_v), int(env.N_max))):
        env.rri_per_vehicle[idx] = float(env.other_rri_markov_states[(idx + int(shock_profile.get("step", 0))) % len(env.other_rri_markov_states)])


def _shock_runtime_mode(shock_profile: Optional[Dict[str, Any]]) -> str:
    if not shock_profile:
        return "legacy"
    return str(shock_profile.get("runtime_mode", "legacy")).strip().lower()


def _capture_shock_baseline(env: V2XEnvironment) -> Dict[str, Any]:
    return {
        "N_v": int(env.N_v),
        "other_rri_mode": str(getattr(env, "other_rri_mode", "random")),
        "rri_change_prob": float(getattr(env, "rri_change_prob", 0.0)),
        "other_rri_markov_ps": float(getattr(env, "other_rri_markov_ps", 1.0)),
        "other_rri_markov_states": list(getattr(env, "other_rri_markov_states", [50.0, 100.0, 200.0])),
    }


def _restore_shock_baseline(env: V2XEnvironment, baseline: Dict[str, Any]) -> None:
    target_n = max(0, min(int(env.N_max), int(baseline.get("N_v", env.N_v))))
    prev_n = int(env.N_v)
    env.N_v = target_n
    env.other_rri_mode = str(baseline.get("other_rri_mode", getattr(env, "other_rri_mode", "random")))
    env.rri_change_prob = float(baseline.get("rri_change_prob", getattr(env, "rri_change_prob", 0.0)))
    env.other_rri_markov_ps = float(baseline.get("other_rri_markov_ps", getattr(env, "other_rri_markov_ps", 1.0)))
    env.other_rri_markov_states = list(
        baseline.get("other_rri_markov_states", getattr(env, "other_rri_markov_states", [50.0, 100.0, 200.0]))
    )
    if prev_n > target_n:
        if hasattr(env, "rri_per_vehicle") and len(env.rri_per_vehicle) >= prev_n:
            env.rri_per_vehicle[target_n:prev_n] = 0.0
        if hasattr(env, "aoi_per_vehicle") and len(env.aoi_per_vehicle) >= prev_n:
            env.aoi_per_vehicle[target_n:prev_n] = 0.0
        if hasattr(env, "peak_paois") and len(env.peak_paois) >= prev_n:
            env.peak_paois[target_n:prev_n] = 0.0
        if hasattr(env, "other_sps_counter") and len(env.other_sps_counter) >= prev_n:
            env.other_sps_counter[target_n:prev_n] = 0
        if hasattr(env, "other_markov_state_idx") and len(env.other_markov_state_idx) >= prev_n:
            env.other_markov_state_idx[target_n:prev_n] = 0
        if hasattr(env, "other_markov_direction") and len(env.other_markov_direction) >= prev_n:
            env.other_markov_direction[target_n:prev_n] = 1


def _refresh_state_metrics(env: V2XEnvironment, state: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    current_rri = float(state.get("RRI", 100.0))
    refreshed_state = dict(env.calculate_system_state(RRI=current_rri, N_v=int(env.N_v)))
    env.current_state = dict(refreshed_state)
    refreshed_metrics = build_metrics(env, refreshed_state)
    return refreshed_state, refreshed_metrics


def _decode_action(env: V2XEnvironment, codec: Optional[ActionCodec], action_idx: int) -> Tuple[int, bool]:
    if codec is not None:
        return codec.decode(action_idx)
    n_rri = len(env.R_set)
    normalized = int(action_idx) % max(1, 2 * n_rri)
    branch = normalized // n_rri
    rri = int(env.R_set[normalized % n_rri])
    return rri, bool(branch == 1)


def _load_manifest(method: str, tag: str) -> Dict[str, Any]:
    path = Path("paper_figures_gpt/experiment08_true_agentic_planning/training") / f"{method}_convergence_{tag}.json"
    return json.loads(path.read_text(encoding="utf-8"))


def _maybe_load_manifest(method: str, tag: str) -> Optional[Dict[str, Any]]:
    path = Path("paper_figures_gpt/experiment08_true_agentic_planning/training") / f"{method}_convergence_{tag}.json"
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def _slice_case_indices(
    total_count: int,
    offset: int,
    limit: Optional[int],
) -> List[int]:
    start = max(0, int(offset))
    if start >= int(total_count):
        return []
    if limit is None or int(limit) < 0:
        end = int(total_count)
    else:
        end = min(int(total_count), start + int(limit))
    return list(range(start, end))


def _checkpoint_entries(manifest: Dict[str, Any], scenario: str) -> List[Dict[str, Any]]:
    return [entry for entry in manifest.get("scenario_runs", {}).get(scenario, []) if entry.get("checkpoint_path")]


def _load_dqn_from_checkpoint(method: str, checkpoint_path: str, scenario: str, train_seed: int):
    env = V2XEnvironment()
    configure_environment_for_scenario(env, scenario)
    codec = ActionCodec([int(x) for x in env.R_set])
    if method == "dqn":
        agent = DQNAgent(state_dim=9, num_actions=codec.num_actions, seed=train_seed)
    else:
        agent = DQNStrongAgent(state_dim=9, num_actions=codec.num_actions, seed=train_seed)
    payload = torch.load(checkpoint_path, map_location="cpu")
    agent.policy.load_state_dict(payload["policy_state_dict"])
    agent.target.load_state_dict(payload["target_state_dict"])
    agent.epsilon = 0.0
    return env, agent, codec


def _load_gnn_from_checkpoint(checkpoint_path: str, scenario: str, train_seed: int):
    env = V2XEnvironment()
    configure_environment_for_scenario(env, scenario)
    agent = GNNDDQNAgent(node_feat_dim=6, num_actions=len(env.R_set) * 2, seed=train_seed)
    payload = torch.load(checkpoint_path, map_location="cpu")
    agent.policy.load_state_dict(payload["policy_state_dict"])
    agent.target.load_state_dict(payload["target_state_dict"])
    agent.epsilon = 0.0
    return env, agent, None


def _run_baseline_checkpoint_case(
    method: str,
    checkpoint_path: str,
    scenario: str,
    case_seed: int,
    max_steps: int,
    shock_profile: Optional[Dict[str, Any]],
    train_seed: int,
) -> Dict[str, Any]:
    set_global_seed(case_seed)
    if method in {"dqn", "dqn_strong"}:
        env, agent, codec = _load_dqn_from_checkpoint(method, checkpoint_path, scenario, train_seed)
    else:
        env, agent, codec = _load_gnn_from_checkpoint(checkpoint_path, scenario, train_seed)

    state = env.current_state
    metrics = build_metrics(env, state)
    previous_branch = 0
    fairness_values: List[float] = []
    rewards: List[float] = []
    shock_step = int(shock_profile["step"]) if shock_profile and "step" in shock_profile else None
    shock_duration = int(shock_profile.get("duration", 1)) if shock_profile else 0
    shock_runtime = _shock_runtime_mode(shock_profile)
    shock_baseline: Optional[Dict[str, Any]] = None
    shock_restored = False

    for step_idx in range(int(max_steps)):
        if shock_runtime == "windowed":
            if shock_step is not None and step_idx == shock_step:
                shock_baseline = _capture_shock_baseline(env)
                _apply_shock(env, shock_profile)
                state, metrics = _refresh_state_metrics(env, state)
            elif (
                shock_step is not None
                and shock_baseline is not None
                and not shock_restored
                and step_idx == shock_step + max(0, shock_duration)
            ):
                _restore_shock_baseline(env, shock_baseline)
                state, metrics = _refresh_state_metrics(env, state)
                shock_restored = True
        elif shock_step is not None and step_idx == shock_step:
            _apply_shock(env, shock_profile)
        if method in {"dqn", "dqn_strong"}:
            if shock_runtime == "windowed":
                shock_flag = 1 if shock_step is not None and shock_duration > 0 and shock_step <= step_idx < shock_step + shock_duration else 0
            else:
                shock_flag = 1 if shock_step is not None and step_idx >= shock_step else 0
            obs = build_state_vector(state, metrics, prev_branch=previous_branch, shock_flag=shock_flag)
            action_idx = agent.act(obs)
            rri, force_reselect = _decode_action(env, codec, action_idx)
            previous_branch = 1 if force_reselect else 0
        else:
            node_feats, adjacency = build_graph_observation(env, state, metrics)
            action_idx = agent.act(node_feats, adjacency)
            rri, force_reselect = _decode_action(env, codec, action_idx)
        mcs_action = int(state.get("agent_mcs_level", 3))
        next_state, done = env.step(mcs_action, rri_value=rri, force_reselect=force_reselect)
        next_metrics = build_metrics(env, next_state)
        reward = compute_reward(next_metrics, metrics)
        fairness_values.append(float(next_metrics.get("raafu", 0.0)))
        rewards.append(float(reward))
        state = next_state
        metrics = next_metrics
        if done:
            break

    result = {
        "train_seed": int(train_seed),
        "checkpoint_path": str(checkpoint_path).replace("\\", "/"),
        "mean_raafu": float(sum(fairness_values) / len(fairness_values)) if fairness_values else 0.0,
        "mean_reward": float(sum(rewards) / len(rewards)) if rewards else 0.0,
        "final_metrics": dict(metrics),
        "trace_ref": {"num_steps": len(fairness_values)},
    }
    result.update(compute_shock_metrics(fairness_values, shock_profile))
    return result


def _run_plain_llm_case(
    scenario: str,
    case_seed: int,
    max_steps: int,
    shock_profile: Optional[Dict[str, Any]],
    llm_config: PlainLLMBaselineConfig,
) -> Dict[str, Any]:
    set_global_seed(case_seed)
    baseline = PlainLLMBaseline(config=llm_config, seed=case_seed)
    state, metrics = baseline.reset(scenario)
    fairness_values: List[float] = []
    rewards: List[float] = []
    shock_step = int(shock_profile["step"]) if shock_profile and "step" in shock_profile else None
    shock_duration = int(shock_profile.get("duration", 1)) if shock_profile else 0
    shock_runtime = _shock_runtime_mode(shock_profile)
    shock_baseline: Optional[Dict[str, Any]] = None
    shock_restored = False
    llm_steps = 0

    for step_idx in range(int(max_steps)):
        if shock_runtime == "windowed":
            if shock_step is not None and step_idx == shock_step:
                shock_baseline = _capture_shock_baseline(baseline.env)
                _apply_shock(baseline.env, shock_profile)
                state, metrics = _refresh_state_metrics(baseline.env, state)
            elif (
                shock_step is not None
                and shock_baseline is not None
                and not shock_restored
                and step_idx == shock_step + max(0, shock_duration)
            ):
                _restore_shock_baseline(baseline.env, shock_baseline)
                state, metrics = _refresh_state_metrics(baseline.env, state)
                shock_restored = True
            shock_flag = bool(
                shock_step is not None
                and shock_duration > 0
                and shock_step <= step_idx < shock_step + shock_duration
            )
        else:
            shock_flag = bool(shock_step is not None and step_idx >= shock_step)
            if shock_step is not None and step_idx == shock_step:
                _apply_shock(baseline.env, shock_profile)
        decision = baseline.choose_action(state, metrics, shock_flag=shock_flag)
        mcs_action = int(state.get("agent_mcs_level", 3))
        next_state, done = baseline.env.step(mcs_action, rri_value=int(decision["chosen_rri"]), force_reselect=bool(decision["force_reselect"]))
        next_metrics = build_metrics(baseline.env, next_state)
        reward = compute_reward(next_metrics, metrics)
        fairness_values.append(float(next_metrics.get("raafu", 0.0)))
        rewards.append(float(reward))
        llm_steps += 1 if decision.get("used_llm", False) else 0
        state = next_state
        metrics = next_metrics
        if done:
            break

    result = {
        "mean_raafu": float(sum(fairness_values) / len(fairness_values)) if fairness_values else 0.0,
        "mean_reward": float(sum(rewards) / len(rewards)) if rewards else 0.0,
        "final_metrics": dict(metrics),
        "trace_ref": {"num_steps": len(fairness_values), "llm_step_ratio": float(llm_steps / max(1, len(fairness_values)))},
    }
    result.update(compute_shock_metrics(fairness_values, shock_profile))
    return result


def _run_agentic_case(
    scenario: str,
    case_seed: int,
    max_steps: int,
    shock_profile: Optional[Dict[str, Any]],
    planner_config: PlannerLedConfig,
) -> Dict[str, Any]:
    set_global_seed(case_seed)
    system = PlannerLedAgenticSystem(config=planner_config, seed=case_seed)
    payload = system.run_episode(scenario=scenario, max_steps=max_steps, shock_profile=shock_profile)
    result = {
        "mean_raafu": float(payload["agentic_stats"].get("mean_raafu", 0.0)),
        "mean_reward": float(payload["agentic_stats"].get("mean_reward", 0.0)),
        "final_metrics": dict(payload.get("final_metrics", {})),
        "trace_ref": {"num_steps": len(payload.get("traces", []))},
        "agentic_stats": dict(payload.get("agentic_stats", {})),
        "utility_stats": _compute_agentic_utility_stats(payload.get("traces", [])),
    }
    result.update(compute_shock_metrics(payload.get("fairness_values", []), shock_profile))
    return result


def _mean_or_zero(values: List[float]) -> float:
    if not values:
        return 0.0
    return float(sum(float(x) for x in values) / len(values))


def _difference_or_zero(positive_group: List[float], reference_group: List[float]) -> float:
    if not positive_group or not reference_group:
        return 0.0
    return float(_mean_or_zero(positive_group) - _mean_or_zero(reference_group))


def _compute_agentic_utility_stats(traces: List[Dict[str, Any]]) -> Dict[str, Any]:
    if not traces:
        return {
            "memory_utility_gain": 0.0,
            "replan_success_gain": 0.0,
            "evidence_override_penalty": 0.0,
            "reflection_guidance_gain": 0.0,
            "tool_effectiveness_by_type": {},
        }

    rewards = [float(trace.get("reward", 0.0)) for trace in traces]
    memory_yes = [float(trace.get("reward", 0.0)) for trace in traces if bool(trace.get("memory_plan_influence", False))]
    memory_no = [float(trace.get("reward", 0.0)) for trace in traces if not bool(trace.get("memory_plan_influence", False))]
    replan_yes = [float(trace.get("reward", 0.0)) for trace in traces if bool(trace.get("explicit_replan", False))]
    replan_no = [float(trace.get("reward", 0.0)) for trace in traces if not bool(trace.get("explicit_replan", False))]
    aligned = [float(trace.get("reward", 0.0)) for trace in traces if bool(trace.get("evidence_aligned", False))]
    misaligned = [float(trace.get("reward", 0.0)) for trace in traces if not bool(trace.get("evidence_aligned", False))]
    guided = [float(trace.get("reward", 0.0)) for trace in traces if bool(trace.get("reflection_guided", False))]
    unguided = [float(trace.get("reward", 0.0)) for trace in traces if not bool(trace.get("reflection_guided", False))]

    tool_effectiveness: Dict[str, float] = {}
    tool_names = ["memory_query", "rollout_candidates", "counterfactual", "constraint_check", "state_digest"]
    for tool_name in tool_names:
        used = [float(trace.get("reward", 0.0)) for trace in traces if tool_name in set(trace.get("step_tools_used", []))]
        not_used = [float(trace.get("reward", 0.0)) for trace in traces if tool_name not in set(trace.get("step_tools_used", []))]
        tool_effectiveness[tool_name] = float(_difference_or_zero(used, not_used))

    return {
        "memory_utility_gain": float(_difference_or_zero(memory_yes, memory_no)),
        "replan_success_gain": float(_difference_or_zero(replan_yes, replan_no)),
        "evidence_override_penalty": float(_difference_or_zero(aligned, misaligned)),
        "reflection_guidance_gain": float(_difference_or_zero(guided, unguided)),
        "avg_step_reward": float(_mean_or_zero(rewards)),
        "tool_effectiveness_by_type": tool_effectiveness,
    }


def _planner_config_from_env() -> PlannerLedConfig:
    return PlannerLedConfig(
        use_llm=os.getenv("EXP08_USE_LLM", "0") == "1",
        strict_llm=False,
        model_name=os.getenv("EXP08_MODEL", "openai/gpt-4o-mini"),
        base_url=os.getenv("OPENAI_BASE_URL", ""),
        api_key=os.getenv("OPENAI_API_KEY", ""),
    )


def _plain_llm_config_from_env() -> PlainLLMBaselineConfig:
    return PlainLLMBaselineConfig(
        use_llm=os.getenv("EXP08_USE_LLM", "0") == "1",
        strict_llm=False,
        model_name=os.getenv("EXP08_MODEL", "openai/gpt-4o-mini"),
        base_url=os.getenv("OPENAI_BASE_URL", ""),
        api_key=os.getenv("OPENAI_API_KEY", ""),
    )


def run_formal_eval(
    *,
    experiment_type: str,
    scenarios: List[str],
    case_counts: Dict[str, int],
    max_steps: Dict[str, int],
    output_tag: str,
    baseline_tag: str,
    shock_mode: bool,
    case_offsets: Optional[Dict[str, int]] = None,
    case_limits: Optional[Dict[str, Optional[int]]] = None,
) -> Dict[str, Any]:
    planner_config = _planner_config_from_env()
    plain_llm_config = _plain_llm_config_from_env()
    dqn_manifest = _maybe_load_manifest("dqn", baseline_tag)
    dqn_strong_manifest = _load_manifest("dqn_strong", baseline_tag)
    gnnddqn_manifest = _load_manifest("gnnddqn", baseline_tag)
    case_offsets = {str(k): int(v) for k, v in (case_offsets or {}).items()}
    case_limits = {str(k): (None if v is None else int(v)) for k, v in (case_limits or {}).items()}

    cases: List[Dict[str, Any]] = []
    for scenario in scenarios:
        total_cases = int(case_counts[scenario])
        case_seeds = build_case_seeds(total_cases, base_seed=2000 if scenario == "complex" else 1000)
        selected_indices = _slice_case_indices(
            total_cases,
            case_offsets.get(scenario, 0),
            case_limits.get(scenario),
        )
        dqn_entries = _checkpoint_entries(dqn_manifest, scenario) if dqn_manifest is not None else []
        dqn_strong_entries = _checkpoint_entries(dqn_strong_manifest, scenario)
        gnnddqn_entries = _checkpoint_entries(gnnddqn_manifest, scenario)
        for case_idx in selected_indices:
            case_seed = case_seeds[case_idx]
            shock_profile = make_shock_profile(scenario, case_seed) if shock_mode else None
            if shock_profile is not None:
                shock_profile = dict(shock_profile)
                shock_profile["step"] = min(int(shock_profile.get("step", 0)), max(1, int(max_steps[scenario]) - 2))
            case_record = {
                "case_id": f"{scenario}_{case_idx:03d}",
                "scenario": scenario,
                "case_seed": int(case_seed),
                "shock_profile": shock_profile,
                "results": {
                    "exp08_agentic": _run_agentic_case(scenario, case_seed, max_steps[scenario], shock_profile, planner_config),
                    "plain_llm": _run_plain_llm_case(scenario, case_seed, max_steps[scenario], shock_profile, plain_llm_config),
                    "dqn": [
                        _run_baseline_checkpoint_case(
                            "dqn",
                            entry["checkpoint_path"],
                            scenario,
                            case_seed,
                            max_steps[scenario],
                            shock_profile,
                            int(entry["seed"]),
                        )
                        for entry in dqn_entries
                    ],
                    "dqn_strong": [
                        _run_baseline_checkpoint_case(
                            "dqn_strong",
                            entry["checkpoint_path"],
                            scenario,
                            case_seed,
                            max_steps[scenario],
                            shock_profile,
                            int(entry["seed"]),
                        )
                        for entry in dqn_strong_entries
                    ],
                    "gnnddqn": [
                        _run_baseline_checkpoint_case(
                            "gnnddqn",
                            entry["checkpoint_path"],
                            scenario,
                            case_seed,
                            max_steps[scenario],
                            shock_profile,
                            int(entry["seed"]),
                        )
                        for entry in gnnddqn_entries
                    ],
                },
            }
            cases.append(case_record)

    config = {
        "scenarios": scenarios,
        "case_counts": case_counts,
        "max_steps": max_steps,
        "baseline_tag": baseline_tag,
        "llm_enabled": bool(planner_config.use_llm),
        "llm_model": planner_config.model_name,
        "shock_mode": bool(shock_mode),
        "case_offsets": {scenario: int(case_offsets.get(scenario, 0)) for scenario in scenarios},
        "case_limits": {scenario: case_limits.get(scenario) for scenario in scenarios},
    }
    payload = formal_payload(experiment_type, output_tag, config, cases)
    output_name = "exp08_static_eval" if not shock_mode else "exp08_shock_recovery"
    output_path = Path("paper_figures_gpt/experiment08_true_agentic_planning") / f"{output_name}_{output_tag}.json"
    save_json(output_path, payload)
    return {"output_path": str(output_path).replace("\\", "/"), "payload": payload}
