from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("/home/ubuntu24/new_5gnr_modeling/paper_figures_gpt/experiment08_true_agentic_planning")
OUT_DIR = ROOT / "paper_selected_baselines_v42"
SOURCE_JSON = ROOT / "exp08_shock_onset_sweep_paper_shock_onset_sweep_r1.json"
OUT_PNG = OUT_DIR / "fig06_shock_onset_sweep_main_r1.png"

METHODS = ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]
METHOD_LABELS = {
    "exp08_agentic": "Agentic",
    "plain_llm": "Plain LLM",
    "dqn": "DQN",
    "gnnddqn": "GNN-DDQN",
}
METHOD_COLORS = {
    "exp08_agentic": "#0b6e4f",
    "plain_llm": "#c06c00",
    "dqn": "#355c7d",
    "gnnddqn": "#6c5b7b",
}


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    payload = _load_json(SOURCE_JSON)
    profiles: List[Dict[str, Any]] = payload["profiles"]
    onsets = [int(profile["shock_profile_template"]["step"]) for profile in profiles]

    fig, axes = plt.subplots(2, 1, figsize=(8.8, 7.0), sharex=True)

    ax = axes[0]
    y_min = 0.0
    y_max = 0.0
    for method in METHODS:
        ys = [
            float(profile["aggregate"]["methods"][method]["paired"]["mean_case_metrics"]["cumulative_loss"])
            for profile in profiles
        ]
        y_min = min(y_min, min(ys))
        y_max = max(y_max, max(ys))
        ax.plot(
            onsets,
            ys,
            marker="o",
            markersize=4.8,
            linewidth=2.0,
            color=METHOD_COLORS[method],
            label=METHOD_LABELS[method],
        )
    ax.axhline(0.0, color="black", linewidth=1.0, linestyle="--", alpha=0.8)
    ax.set_title("(a) Mean cumulative loss vs. shock onset")
    ax.set_ylabel("Cumulative loss")
    ax.set_ylim(y_min - 0.03, y_max + 0.05)
    ax.grid(alpha=0.25, linestyle=":")
    ax.legend(frameon=False, ncol=3, loc="upper right")

    ax = axes[1]
    y_min = 0.0
    y_max = 0.0
    for method in METHODS:
        ys = [
            float(profile["aggregate"]["methods"][method]["paired"]["mean_case_metrics"]["worst_drop"])
            for profile in profiles
        ]
        y_min = min(y_min, min(ys))
        y_max = max(y_max, max(ys))
        ax.plot(
            onsets,
            ys,
            marker="o",
            markersize=4.8,
            linewidth=2.0,
            color=METHOD_COLORS[method],
            label=METHOD_LABELS[method],
        )
    ax.axhline(0.0, color="black", linewidth=1.0, linestyle="--", alpha=0.8)
    ax.set_title("(b) Worst instantaneous drop vs. shock onset")
    ax.set_xlabel("Shock onset step")
    ax.set_ylabel("Worst drop")
    ax.set_xticks(onsets)
    ax.set_ylim(y_min - 0.02, y_max + 0.02)
    ax.grid(alpha=0.25, linestyle=":")

    fig.tight_layout()
    fig.savefig(OUT_PNG, dpi=240, bbox_inches="tight")
    plt.close(fig)
    print(str(OUT_PNG))


if __name__ == "__main__":
    main()
