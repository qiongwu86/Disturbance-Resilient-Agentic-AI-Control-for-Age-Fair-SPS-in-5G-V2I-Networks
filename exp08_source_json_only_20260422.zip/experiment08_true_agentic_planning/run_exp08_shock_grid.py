from __future__ import annotations

import os
from pathlib import Path
import sys
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiment08_true_agentic_planning.formal_utils import build_case_seeds, save_json
from experiment08_true_agentic_planning.trajectory_eval import (
    METHODS,
    build_shock_profile,
    checkpoint_entries,
    load_manifest,
    mean_scalar_by_method,
    paired_curve_statistics,
    planner_config_from_env,
    plain_config_from_env,
    run_all_methods_for_case,
)


def _parse_int_list(raw: str, default: List[int]) -> List[int]:
    text = str(raw or "").strip()
    if not text:
        return [int(x) for x in default]
    return [int(item.strip()) for item in text.split(",") if item.strip()]


def main() -> None:
    output_tag = os.getenv("EXP08_OUTPUT_TAG", "shock_grid_latest")
    baseline_tag = os.getenv("EXP08_BASELINE_TAG", "paper_s5_e1000_1500")
    scenario = os.getenv("EXP08_SCENARIO", "complex").strip().lower()
    case_count = int(os.getenv("EXP08_CASE_COUNT", "32"))
    max_steps = int(os.getenv("EXP08_MAX_STEPS", "24"))
    base_seed = int(os.getenv("EXP08_BASE_SEED", "2000"))
    shock_step = int(os.getenv("EXP08_SHOCK_STEP", "8"))
    extra_values = _parse_int_list(os.getenv("EXP08_EXTRA_VALUES", ""), [1, 2, 4, 6])
    duration_values = _parse_int_list(os.getenv("EXP08_DURATION_VALUES", ""), [1, 3, 5, 8])
    shock_prob = float(os.getenv("EXP08_SHOCK_PROB", "0.8"))
    shock_markov_ps = float(os.getenv("EXP08_SHOCK_MARKOV_PS", "1.0"))
    output_path = Path("paper_figures_gpt/experiment08_true_agentic_planning") / f"exp08_shock_grid_{output_tag}.json"

    planner_cfg = planner_config_from_env()
    plain_cfg = plain_config_from_env()
    dqn_entries = checkpoint_entries(load_manifest("dqn", baseline_tag), scenario)
    gnnddqn_entries = checkpoint_entries(load_manifest("gnnddqn", baseline_tag), scenario)
    case_seeds = build_case_seeds(case_count, base_seed=base_seed)
    no_shock_cache = {
        int(case_seed): run_all_methods_for_case(
            scenario=scenario,
            case_seed=case_seed,
            shock_profile=None,
            max_steps=max_steps,
            baseline_tag=baseline_tag,
            planner_config=planner_cfg,
            plain_config=plain_cfg,
            dqn_entries=dqn_entries,
            gnnddqn_entries=gnnddqn_entries,
        )
        for case_seed in case_seeds
    }

    cells: List[Dict[str, Any]] = []
    total_cells = len(extra_values) * len(duration_values)
    for extra in extra_values:
        for duration in duration_values:
            per_method_metrics: Dict[str, Dict[str, List[float]]] = {
                method: {"cumulative_loss": [], "worst_drop": [], "post_shock_mean_gap": []}
                for method in METHODS
            }
            case_rows: List[Dict[str, Any]] = []
            for case_seed in case_seeds:
                no_shock = no_shock_cache[int(case_seed)]
                shock_profile = build_shock_profile(
                    step=min(int(shock_step), max_steps - 1),
                    duration=duration,
                    extra_vehicles=extra,
                    rri_change_prob=shock_prob,
                    markov_ps=shock_markov_ps,
                )
                shock_profile["seed"] = int(case_seed)
                shock = run_all_methods_for_case(
                    scenario=scenario,
                    case_seed=case_seed,
                    shock_profile=shock_profile,
                    max_steps=max_steps,
                    baseline_tag=baseline_tag,
                    planner_config=planner_cfg,
                    plain_config=plain_cfg,
                    dqn_entries=dqn_entries,
                    gnnddqn_entries=gnnddqn_entries,
                )

                method_rows: Dict[str, Any] = {}
                for method in METHODS:
                    stats = paired_curve_statistics(no_shock[method], shock[method])
                    method_rows[method] = stats
                    per_method_metrics[method]["cumulative_loss"].append(float(stats["cumulative_loss"]))
                    per_method_metrics[method]["worst_drop"].append(float(stats["worst_drop"]))
                    per_method_metrics[method]["post_shock_mean_gap"].append(float(stats["post_shock_mean_gap"]))
                case_rows.append({"case_seed": int(case_seed), "methods": method_rows})

            cells.append(
                {
                    "extra_vehicles": int(extra),
                    "duration": int(duration),
                    "summary": {
                        "mean_cumulative_loss": mean_scalar_by_method(
                            {method: values["cumulative_loss"] for method, values in per_method_metrics.items()}
                        ),
                        "mean_worst_drop": mean_scalar_by_method(
                            {method: values["worst_drop"] for method, values in per_method_metrics.items()}
                        ),
                        "mean_post_shock_gap": mean_scalar_by_method(
                            {method: values["post_shock_mean_gap"] for method, values in per_method_metrics.items()}
                        ),
                    },
                    "cases": case_rows,
                }
            )
            save_json(output_path, {"status": "running", "completed_cells": len(cells), "cells_total": total_cells})

    payload = {
        "experiment": "shock_grid",
        "scenario": scenario,
        "baseline_tag": baseline_tag,
        "case_count": case_count,
        "max_steps": max_steps,
        "base_seed": base_seed,
        "shock_step": shock_step,
        "extra_values": extra_values,
        "duration_values": duration_values,
        "shock_prob": shock_prob,
        "shock_markov_ps": shock_markov_ps,
        "cells": cells,
    }
    save_json(output_path, payload)
    print(str(output_path).replace("\\", "/"))


if __name__ == "__main__":
    main()
