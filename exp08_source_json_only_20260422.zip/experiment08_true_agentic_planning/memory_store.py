from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Dict, List

from .common import bucketize


@dataclass
class MemoryRecord:
    traffic_bucket: str
    collision_bucket: str
    paoi_pattern: str
    current_rri: int
    previous_branch: str
    shock_flag: bool
    selected_tools: List[str]
    committed_plan: Dict[str, Any]
    observed_outcome: Dict[str, Any]
    lesson_tag: str
    lesson_text: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class EpisodicMemoryStore:
    def __init__(self, max_records: int = 500) -> None:
        self.max_records = max(10, int(max_records))
        self._records: List[MemoryRecord] = []

    def __len__(self) -> int:
        return len(self._records)

    def add(self, record: MemoryRecord) -> None:
        self._records.append(record)
        if len(self._records) > self.max_records:
            self._records = self._records[-self.max_records :]

    def query(self, query_spec: Dict[str, str], limit: int = 3) -> List[MemoryRecord]:
        if not self._records:
            return []

        scored = []
        for record in self._records:
            score = 0.0
            for key, target in query_spec.items():
                if target in {"", "any", "unknown"}:
                    continue
                if str(getattr(record, key, "")).lower() == str(target).lower():
                    score += 2.0
            if record.shock_flag and str(query_spec.get("shock_flag", "")).lower() in {"true", "1", "yes"}:
                score += 1.0
            scored.append((score, record))

        scored.sort(key=lambda item: item[0], reverse=True)
        return [record for score, record in scored if score > 0][: max(1, int(limit))]

    @staticmethod
    def build_query_spec(observation: Dict[str, Any], analysis: Dict[str, Any]) -> Dict[str, str]:
        collision_bucket = bucketize(
            float(observation.get("collision_prob", 0.0)),
            [0.10, 0.30, 0.60],
            ["low", "medium", "high", "critical"],
        )
        paoi_pattern = bucketize(
            float(observation.get("paoi", 0.0)),
            [250.0, 600.0, 1000.0],
            ["fresh", "moderate", "stale", "critical"],
        )
        return {
            "traffic_bucket": str(analysis.get("traffic_level", "unknown")),
            "collision_bucket": collision_bucket,
            "paoi_pattern": paoi_pattern,
            "previous_branch": str(observation.get("previous_branch", "keep")),
            "shock_flag": str(bool(observation.get("shock_flag", False))).lower(),
        }

    @staticmethod
    def summarize(records: List[MemoryRecord]) -> List[Dict[str, Any]]:
        return [record.to_dict() for record in records]
