from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Dict, List


ALLOWED_TOOLS = (
    "state_digest",
    "memory_query",
    "rollout_candidates",
    "counterfactual",
    "constraint_check",
)


@dataclass
class ObservationDigest:
    n_v: int
    current_rri: int
    paoi: float
    collision_prob: float
    fairness_index: float
    raafu: float
    shock_flag: bool
    previous_branch: str
    previous_reward: float
    last_reflection_hint: str = ""
    last_avoid_action_pattern: str = ""
    last_subgoal_adjustment: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class AnalysisReport:
    traffic_level: str
    stability_level: str
    conflict_level: str
    urgency: str
    dominant_risk: str
    reasoning: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class DraftPlan:
    subgoal: str
    planning_horizon: int
    branch_decision: str
    candidate_rris: List[int]
    tool_sequence: List[str]
    memory_query_spec: Dict[str, str]
    fallback_policy: str
    confidence: float
    rationale: str = ""

    def normalized(self) -> "DraftPlan":
        branch = str(self.branch_decision).strip().lower()
        if branch not in {"keep", "reselect"}:
            branch = "keep"
        tools: List[str] = []
        for item in self.tool_sequence:
            name = str(item).strip().lower()
            if name in ALLOWED_TOOLS and name not in tools:
                tools.append(name)
        return DraftPlan(
            subgoal=str(self.subgoal or "stabilize fairness"),
            planning_horizon=max(1, min(8, int(self.planning_horizon))),
            branch_decision=branch,
            candidate_rris=[int(x) for x in self.candidate_rris],
            tool_sequence=tools[:3],
            memory_query_spec=dict(self.memory_query_spec or {}),
            fallback_policy=str(self.fallback_policy or "safe_rri"),
            confidence=max(0.0, min(1.0, float(self.confidence))),
            rationale=str(self.rationale or ""),
        )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class CommitPlan:
    chosen_rri: int
    backup_rri: int
    final_branch: str
    expected_gain: float
    expected_risk: float
    evidence_refs: List[str]
    replan_trigger: bool
    rationale: str = ""

    def normalized(self) -> "CommitPlan":
        branch = str(self.final_branch).strip().lower()
        if branch not in {"keep", "reselect"}:
            branch = "keep"
        return CommitPlan(
            chosen_rri=int(self.chosen_rri),
            backup_rri=int(self.backup_rri),
            final_branch=branch,
            expected_gain=float(self.expected_gain),
            expected_risk=max(0.0, float(self.expected_risk)),
            evidence_refs=[str(x) for x in self.evidence_refs],
            replan_trigger=bool(self.replan_trigger),
            rationale=str(self.rationale or ""),
        )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ReflectionNote:
    success: bool
    lesson: str
    should_replan: bool
    lesson_tag: str
    next_step_hint: str = ""
    avoid_action_pattern: str = ""
    subgoal_adjustment: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class StepTrace:
    step: int
    observation: Dict[str, Any]
    analysis: Dict[str, Any]
    draft_plan: Dict[str, Any]
    tool_outputs: Dict[str, Any]
    commit_plan: Dict[str, Any]
    executed_action: Dict[str, Any]
    reflection: Dict[str, Any]
    reward: float
    metrics: Dict[str, Any]
    evidence_synthesis: Dict[str, Any]
    memory_changed_plan: bool = False
    memory_plan_influence: bool = False
    memory_action_override: bool = False
    evidence_aligned: bool = False
    explicit_replan: bool = False
    explicit_replan_reason: str = ""
    reflection_guided: bool = False
    safety_overridden: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
