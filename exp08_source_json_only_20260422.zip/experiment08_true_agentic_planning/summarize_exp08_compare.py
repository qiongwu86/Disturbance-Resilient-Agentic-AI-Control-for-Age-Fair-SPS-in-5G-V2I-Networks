from __future__ import annotations

import json
import os
from pathlib import Path
from statistics import mean


ROOT = Path("paper_figures_gpt/experiment08_true_agentic_planning")


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def mean_baseline_summary(data, scenario_key: str):
    runs = data.get("runs", [])
    if not runs:
        return {}
    return {
        "mean_raafu": mean(float(run[scenario_key]["summary"].get("mean_raafu", 0.0)) for run in runs),
        "mean_reward": mean(float(run[scenario_key]["summary"].get("mean_reward", 0.0)) for run in runs),
    }


def main() -> None:
    output_tag = os.getenv("EXP08_OUTPUT_TAG", "latest")
    stage1_path = ROOT / "stage1_validate" / f"exp08_stage1_validate_{output_tag}.json"
    llm_baseline_path = ROOT / "baselines" / f"exp08_llm_baseline_{output_tag}.json"
    dqn_path = ROOT / "baselines" / "exp08_dqn_baseline_latest.json"
    gnnddqn_path = ROOT / "baselines" / "exp08_gnnddqn_baseline_latest.json"

    stage1 = load_json(stage1_path)
    dqn = load_json(dqn_path)
    gnnddqn = load_json(gnnddqn_path)
    llm_baseline = load_json(llm_baseline_path) if llm_baseline_path.exists() else None

    comparison = {
        "tag": output_tag,
        "agentic_method": stage1.get("summary", {}),
        "dqn_baseline": {
            "simple_static": mean_baseline_summary(dqn, "simple_static"),
            "complex_static": mean_baseline_summary(dqn, "complex_static"),
            "complex_shock": mean_baseline_summary(dqn, "complex_shock"),
        },
        "gnnddqn_baseline": {
            "simple_static": mean_baseline_summary(gnnddqn, "simple_static"),
            "complex_static": mean_baseline_summary(gnnddqn, "complex_static"),
            "complex_shock": mean_baseline_summary(gnnddqn, "complex_shock"),
        },
    }
    if llm_baseline is not None:
        comparison["plain_llm_baseline"] = {
            "simple_static": mean_baseline_summary(llm_baseline, "simple_static"),
            "complex_static": mean_baseline_summary(llm_baseline, "complex_static"),
            "complex_shock": mean_baseline_summary(llm_baseline, "complex_shock"),
        }

    output_path = ROOT / f"exp08_compare_summary_{output_tag}.json"
    output_path.write_text(json.dumps(comparison, indent=2, ensure_ascii=False), encoding="utf-8")
    print(str(output_path))


if __name__ == "__main__":
    main()
