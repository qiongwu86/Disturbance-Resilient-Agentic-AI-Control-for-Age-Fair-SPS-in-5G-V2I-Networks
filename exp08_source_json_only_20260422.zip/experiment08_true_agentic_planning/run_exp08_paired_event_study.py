from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any, Dict

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from experiment08_true_agentic_planning.paired_shock_eval import (
    PairedEvalConfig,
    PairedShockEvaluator,
    build_shock_profile_template,
    parse_float_list,
    parse_text_list,
    save_payload,
)


def _env_int(name: str, default: int) -> int:
    return int(os.getenv(name, str(default)))


def _env_float(name: str, default: float) -> float:
    return float(os.getenv(name, str(default)))


def _build_profile_from_env() -> Dict[str, Any]:
    markov_states = parse_float_list(
        os.getenv("EXP08_SHOCK_MARKOV_STATES", ""),
        [20.0, 50.0, 100.0, 200.0, 500.0],
    )
    return build_shock_profile_template(
        step=_env_int("EXP08_SHOCK_STEP", 8),
        duration=_env_int("EXP08_SHOCK_DURATION", 5),
        extra_vehicles=_env_int("EXP08_SHOCK_EXTRA", 3),
        rri_change_prob=_env_float("EXP08_SHOCK_RRI_PROB", 0.8),
        markov_ps=_env_float("EXP08_SHOCK_MARKOV_PS", 1.0),
        runtime_mode=os.getenv("EXP08_SHOCK_RUNTIME_MODE", "windowed"),
        other_rri_mode=os.getenv("EXP08_SHOCK_OTHER_RRI_MODE", "markov_pingpong"),
        markov_states=markov_states,
    )


def main() -> None:
    output_tag = os.getenv("EXP08_OUTPUT_TAG", "paper_paired_event_study_r1")
    baseline_tag = os.getenv("EXP08_BASELINE_TAG", "paper_s5_e1000_1500")
    methods = parse_text_list(
        os.getenv("EXP08_METHODS", ""),
        ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"],
    )
    limit_raw = os.getenv("EXP08_CASE_LIMIT", "").strip()
    case_limit = None if not limit_raw else int(limit_raw)

    config = PairedEvalConfig(
        scenario=os.getenv("EXP08_SCENARIO", "complex"),
        case_count=_env_int("EXP08_CASES", 32),
        max_steps=_env_int("EXP08_STEPS", 24),
        base_seed=_env_int("EXP08_BASE_SEED", 2000),
        case_offset=_env_int("EXP08_CASE_OFFSET", 0),
        case_limit=case_limit,
        baseline_tag=baseline_tag,
        methods=methods,
    )
    evaluator = PairedShockEvaluator(config)
    profile = _build_profile_from_env()
    payload = evaluator.evaluate_profiles(
        experiment_type="paired_event_study",
        output_tag=output_tag,
        profiles=[{"label": "event_study", "shock_profile_template": profile}],
        include_case_details=os.getenv("EXP08_INCLUDE_CASE_DETAILS", "1") == "1",
    )
    output_path = save_payload(payload, f"exp08_paired_event_study_{output_tag}.json")
    print(str(output_path).replace("\\", "/"))


if __name__ == "__main__":
    main()
