from __future__ import annotations

import json
import logging
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

logging.getLogger("httpx").setLevel(logging.WARNING)

from experiment08_true_agentic_planning.baseline_models import DQNAgent, GNNDDQNAgent
from experiment08_true_agentic_planning.common import (
    ActionCodec,
    build_graph_observation,
    build_metrics,
    build_state_vector,
    compute_reward,
)
from experiment08_true_agentic_planning.formal_eval import _apply_shock
from experiment08_true_agentic_planning.plain_llm_baseline import PlainLLMBaseline, PlainLLMBaselineConfig
from experiment08_true_agentic_planning.planner_led_v2x_system import (
    PlannerLedAgenticSystem,
    PlannerLedConfig,
    configure_environment_for_scenario,
)


ROOT = Path("paper_figures_gpt/experiment08_true_agentic_planning")
OUT_DIR = ROOT / "paper_selected_baselines_v42"
METHOD_COLORS = {
    "exp08_agentic": "#0b6e4f",
    "plain_llm": "#c06c00",
    "dqn": "#355c7d",
    "gnnddqn": "#6c5b7b",
}
METHOD_LABELS = {
    "exp08_agentic": "Agentic",
    "plain_llm": "Plain LLM",
    "dqn": "DQN",
    "gnnddqn": "GNN-DDQN",
}


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _planner_config() -> PlannerLedConfig:
    return PlannerLedConfig(
        use_llm=os.getenv("EXP08_USE_LLM", "0") == "1",
        strict_llm=False,
        model_name=os.getenv("EXP08_MODEL", "openai/gpt-4o-mini"),
        base_url=os.getenv("OPENAI_BASE_URL", ""),
        api_key=os.getenv("OPENAI_API_KEY", ""),
    )


def _plain_config() -> PlainLLMBaselineConfig:
    return PlainLLMBaselineConfig(
        use_llm=os.getenv("EXP08_USE_LLM", "0") == "1",
        strict_llm=False,
        model_name=os.getenv("EXP08_MODEL", "openai/gpt-4o-mini"),
        base_url=os.getenv("OPENAI_BASE_URL", ""),
        api_key=os.getenv("OPENAI_API_KEY", ""),
    )


def _load_manifest(method: str, tag: str) -> Dict[str, Any]:
    return _load_json(ROOT / "training" / f"{method}_convergence_{tag}.json")


def _checkpoint_entries(manifest: Dict[str, Any], scenario: str) -> List[Dict[str, Any]]:
    return [entry for entry in manifest.get("scenario_runs", {}).get(scenario, []) if entry.get("checkpoint_path")]


def _load_dqn(checkpoint_path: str, train_seed: int):
    from agentic_v2x_system import V2XEnvironment

    env = V2XEnvironment()
    configure_environment_for_scenario(env, "complex")
    codec = ActionCodec([int(x) for x in env.R_set])
    agent = DQNAgent(state_dim=9, num_actions=codec.num_actions, seed=train_seed)
    payload = torch.load(checkpoint_path, map_location="cpu")
    agent.policy.load_state_dict(payload["policy_state_dict"])
    agent.target.load_state_dict(payload["target_state_dict"])
    agent.epsilon = 0.0
    return env, agent, codec


def _load_gnnddqn(checkpoint_path: str, train_seed: int):
    from agentic_v2x_system import V2XEnvironment

    env = V2XEnvironment()
    configure_environment_for_scenario(env, "complex")
    agent = GNNDDQNAgent(node_feat_dim=6, num_actions=len(env.R_set) * 2, seed=train_seed)
    payload = torch.load(checkpoint_path, map_location="cpu")
    agent.policy.load_state_dict(payload["policy_state_dict"])
    agent.target.load_state_dict(payload["target_state_dict"])
    agent.epsilon = 0.0
    return env, agent


def _decode_action(env, codec: Optional[ActionCodec], action_idx: int) -> Tuple[int, bool]:
    if codec is not None:
        return codec.decode(action_idx)
    n_rri = len(env.R_set)
    normalized = int(action_idx) % max(1, 2 * n_rri)
    branch = normalized // n_rri
    rri = int(env.R_set[normalized % n_rri])
    return rri, bool(branch == 1)


def _run_agentic(case_seed: int, shock_profile: Dict[str, Any], max_steps: int) -> List[float]:
    system = PlannerLedAgenticSystem(config=_planner_config(), seed=case_seed)
    payload = system.run_episode(scenario="complex", max_steps=max_steps, shock_profile=shock_profile)
    return [float(x) for x in payload.get("fairness_values", [])]


def _run_plain(case_seed: int, shock_profile: Dict[str, Any], max_steps: int) -> List[float]:
    baseline = PlainLLMBaseline(config=_plain_config(), seed=case_seed)
    state, metrics = baseline.reset("complex")
    fairness_values: List[float] = []
    shock_step = int(shock_profile["step"])
    for step_idx in range(int(max_steps)):
        if step_idx == shock_step:
            _apply_shock(baseline.env, shock_profile)
        decision = baseline.choose_action(state, metrics, shock_flag=step_idx >= shock_step)
        mcs_action = int(state.get("agent_mcs_level", 3))
        next_state, _ = baseline.env.step(mcs_action, rri_value=int(decision["chosen_rri"]), force_reselect=bool(decision["force_reselect"]))
        next_metrics = build_metrics(baseline.env, next_state)
        fairness_values.append(float(next_metrics.get("raafu", 0.0)))
        state, metrics = next_state, next_metrics
    return fairness_values


def _run_dqn_case(case_seed: int, shock_profile: Dict[str, Any], max_steps: int, checkpoint_path: str, train_seed: int) -> List[float]:
    env, agent, codec = _load_dqn(checkpoint_path, train_seed)
    state = env.current_state
    metrics = build_metrics(env, state)
    prev_branch = 0
    fairness_values: List[float] = []
    shock_step = int(shock_profile["step"])
    for step_idx in range(int(max_steps)):
        if step_idx == shock_step:
            _apply_shock(env, shock_profile)
        obs = build_state_vector(state, metrics, prev_branch=prev_branch, shock_flag=1 if step_idx >= shock_step else 0)
        action_idx = agent.act(obs)
        rri, force_reselect = _decode_action(env, codec, action_idx)
        prev_branch = 1 if force_reselect else 0
        mcs_action = int(state.get("agent_mcs_level", 3))
        next_state, _ = env.step(mcs_action, rri_value=rri, force_reselect=force_reselect)
        next_metrics = build_metrics(env, next_state)
        fairness_values.append(float(next_metrics.get("raafu", 0.0)))
        state, metrics = next_state, next_metrics
    return fairness_values


def _run_gnnddqn_case(case_seed: int, shock_profile: Dict[str, Any], max_steps: int, checkpoint_path: str, train_seed: int) -> List[float]:
    env, agent = _load_gnnddqn(checkpoint_path, train_seed)
    state = env.current_state
    metrics = build_metrics(env, state)
    shock_step = int(shock_profile["step"])
    fairness_values: List[float] = []
    for step_idx in range(int(max_steps)):
        if step_idx == shock_step:
            _apply_shock(env, shock_profile)
        node_feats, adjacency = build_graph_observation(env, state, metrics)
        action_idx = agent.act(node_feats, adjacency)
        rri, force_reselect = _decode_action(env, None, action_idx)
        mcs_action = int(state.get("agent_mcs_level", 3))
        next_state, _ = env.step(mcs_action, rri_value=rri, force_reselect=force_reselect)
        next_metrics = build_metrics(env, next_state)
        fairness_values.append(float(next_metrics.get("raafu", 0.0)))
        state, metrics = next_state, next_metrics
    return fairness_values


def _mean_curve(curves: List[List[float]]) -> Tuple[List[float], List[float]]:
    arr = np.array(curves, dtype=float)
    return arr.mean(axis=0).tolist(), arr.std(axis=0).tolist()


def main() -> None:
    out_json = OUT_DIR / "exp08_complex_shock_trajectory_selected_v42.json"
    out_png = OUT_DIR / "fig02_complex_shock_trajectory_selected_v42.png"
    cache_json = OUT_DIR / "exp08_complex_shock_trajectory_selected_v42_cache.json"

    source = _load_json(ROOT / "exp08_shock_recovery_paper_complex_shock_v42.json")
    cases = source["cases"]
    max_steps = int(source["config"]["max_steps"]["complex"])
    baseline_tag = str(source["config"]["baseline_tag"])
    dqn_manifest = _load_manifest("dqn", baseline_tag)
    gnnddqn_manifest = _load_manifest("gnnddqn", baseline_tag)
    dqn_entries = _checkpoint_entries(dqn_manifest, "complex")
    gnnddqn_entries = _checkpoint_entries(gnnddqn_manifest, "complex")

    if cache_json.exists():
        cache = _load_json(cache_json)
        agg: Dict[str, List[List[float]]] = {
            m: [[float(x) for x in curve] for curve in cache.get("agg", {}).get(m, [])]
            for m in ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]
        }
        start_idx = int(cache.get("completed_cases", 0))
    else:
        agg = {m: [] for m in ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]}
        start_idx = 0

    for case_idx, case in enumerate(cases[start_idx:], start=start_idx):
        case_seed = int(case["case_seed"])
        shock_profile = dict(case["shock_profile"])
        agg["exp08_agentic"].append(_run_agentic(case_seed, shock_profile, max_steps))
        agg["plain_llm"].append(_run_plain(case_seed, shock_profile, max_steps))

        dqn_case_curves = []
        for entry in dqn_entries:
            dqn_case_curves.append(
                _run_dqn_case(
                    case_seed,
                    shock_profile,
                    max_steps,
                    str(entry["checkpoint_path"]),
                    int(entry.get("train_seed", entry.get("seed", 0))),
                )
            )
        dqn_arr = np.array(dqn_case_curves, dtype=float)
        agg["dqn"].append(dqn_arr.mean(axis=0).tolist())

        gnn_case_curves = []
        for entry in gnnddqn_entries:
            gnn_case_curves.append(
                _run_gnnddqn_case(
                    case_seed,
                    shock_profile,
                    max_steps,
                    str(entry["checkpoint_path"]),
                    int(entry.get("train_seed", entry.get("seed", 0))),
                )
            )
        gnn_arr = np.array(gnn_case_curves, dtype=float)
        agg["gnnddqn"].append(gnn_arr.mean(axis=0).tolist())

        cache_json.write_text(
            json.dumps(
                {
                    "completed_cases": case_idx + 1,
                    "agg": agg,
                },
                indent=2,
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )

    payload = {"methods": {}, "shock_step": int(cases[0]["shock_profile"]["step"]), "num_cases": len(cases)}
    for method, curves in agg.items():
        mean_curve, std_curve = _mean_curve(curves)
        payload["methods"][method] = {"mean_curve": mean_curve, "std_curve": std_curve}
    out_json.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    fig, ax = plt.subplots(figsize=(8.6, 4.8))
    xs = np.arange(max_steps)
    for method in ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]:
        mean_curve = np.array(payload["methods"][method]["mean_curve"], dtype=float)
        std_curve = np.array(payload["methods"][method]["std_curve"], dtype=float)
        ax.plot(xs, mean_curve, linewidth=2.2, label=METHOD_LABELS[method], color=METHOD_COLORS[method])
        ax.fill_between(xs, mean_curve - std_curve, mean_curve + std_curve, color=METHOD_COLORS[method], alpha=0.12)
    ax.axvline(payload["shock_step"], linestyle="--", color="black", alpha=0.65, label="Shock onset")
    ax.set_xlabel("Decision step")
    ax.set_ylabel("RAAFU")
    ax.set_title("Full Complex Shock Mean Trajectory")
    ax.grid(alpha=0.25)
    ax.legend(frameon=False, ncol=3)
    fig.tight_layout()
    fig.savefig(out_png, dpi=220)
    plt.close(fig)


if __name__ == "__main__":
    main()
