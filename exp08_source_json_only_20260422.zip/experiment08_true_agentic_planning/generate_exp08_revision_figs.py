from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Iterable, List

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("paper_figures_gpt/experiment08_true_agentic_planning")
OUT_DIR = ROOT / "paper_selected_baselines_v42"

METHOD_COLORS = {
    "exp08_agentic": "#0b6e4f",
    "plain_llm": "#c06c00",
    "dqn": "#355c7d",
    "gnnddqn": "#6c5b7b",
}
ABLATION_COLORS = {
    "full": "#0b6e4f",
    "no_memory": "#6d9f71",
    "fixed_tool_chain": "#7f8c8d",
    "no_reflection": "#2980b9",
    "no_counterfactual": "#9b59b6",
}


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _mean(values: Iterable[float]) -> float:
    vals = [float(v) for v in values]
    return float(sum(vals) / len(vals)) if vals else 0.0


def _case_avg_agentic_stats(cases: List[Dict[str, Any]], variant: str = "exp08_agentic") -> Dict[str, float]:
    keys = [
        "planner_authority_ratio",
        "tool_selection_diversity",
        "memory_plan_influence_rate",
        "memory_action_override_rate",
        "evidence_alignment_rate",
        "explicit_replan_rate",
        "reflection_guidance_rate",
        "tool_counterfactual_rate",
    ]
    agg = {key: [] for key in keys}
    for case in cases:
        stats = case["results"][variant].get("agentic_stats", {})
        for key in keys:
            if key in stats:
                agg[key].append(float(stats[key]))
    return {key: _mean(vals) for key, vals in agg.items()}


def _build_process_summary() -> Dict[str, Any]:
    static_full = _load_json(ROOT / "exp08_static_eval_paper_complex_static_v42_full.json")
    shock_full = _load_json(ROOT / "exp08_shock_recovery_paper_complex_shock_v42.json")
    ablation = _load_json(ROOT / "exp08_ablation_paper_complex_shock_v42_subset6_s16.json")

    static_process = _case_avg_agentic_stats(static_full["cases"], "exp08_agentic")
    shock_process = dict(shock_full["summary"]["exp08_agentic"]["complex"]["agentic_stats"])
    ablation_process = {
        variant: _case_avg_agentic_stats(ablation["cases"], variant)
        for variant in ["full", "no_memory", "fixed_tool_chain", "no_reflection", "no_counterfactual"]
    }

    utility = _load_json(OUT_DIR / "exp08_paper_summary_selected_v42.json")["static_utility"]

    payload = {
        "static_process": static_process,
        "shock_process": shock_process,
        "ablation_process": ablation_process,
        "utility": utility,
    }
    out = OUT_DIR / "exp08_revision_process_summary_v42.json"
    out.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return payload


def _plot_pure_agentic_process(path: Path, summary: Dict[str, Any]) -> None:
    static_process = summary["static_process"]
    shock_process = summary["shock_process"]
    ablation_process = summary["ablation_process"]

    fig, axes = plt.subplots(1, 2, figsize=(12.0, 4.8))

    # Left: full-method process evidence in static vs shock
    metrics_left = [
        ("planner_authority_ratio", "Planner\nAuthority"),
        ("memory_plan_influence_rate", "Memory\nInfluence"),
        ("evidence_alignment_rate", "Evidence\nAlignment"),
        ("tool_selection_diversity", "Tool\nDiversity"),
        ("tool_counterfactual_rate", "Counterfactual\nCoverage"),
        ("reflection_guidance_rate", "Reflection\nGuidance"),
    ]
    x = np.arange(len(metrics_left))
    width = 0.36
    static_vals = [float(static_process.get(k, 0.0)) for k, _ in metrics_left]
    shock_vals = [float(shock_process.get(k, 0.0)) for k, _ in metrics_left]
    axes[0].bar(x - width / 2, static_vals, width, label="Complex Static", color="#4c8a74")
    axes[0].bar(x + width / 2, shock_vals, width, label="Complex Shock", color="#0b6e4f")
    axes[0].set_xticks(x, [label for _, label in metrics_left])
    axes[0].set_ylim(0.0, 1.08)
    axes[0].set_title("Full Agentic Process Evidence")
    axes[0].grid(axis="y", alpha=0.25)
    axes[0].legend(frameon=False, fontsize=8)

    # Right: process ablation profile
    metrics_right = [
        ("memory_plan_influence_rate", "Memory\nInfluence"),
        ("evidence_alignment_rate", "Evidence\nAlignment"),
        ("tool_selection_diversity", "Tool\nDiversity"),
        ("reflection_guidance_rate", "Reflection\nGuidance"),
    ]
    variants = ["full", "no_memory", "fixed_tool_chain", "no_reflection", "no_counterfactual"]
    labels = {
        "full": "Full",
        "no_memory": "No Memory",
        "fixed_tool_chain": "Fixed Tools",
        "no_reflection": "No Reflect",
        "no_counterfactual": "No Cfact",
    }
    xr = np.arange(len(metrics_right))
    bar_w = 0.15
    offsets = np.linspace(-2, 2, len(variants)) * bar_w
    for offset, variant in zip(offsets, variants):
        vals = [float(ablation_process[variant].get(k, 0.0)) for k, _ in metrics_right]
        axes[1].bar(
            xr + offset,
            vals,
            bar_w,
            label=labels[variant],
            color=ABLATION_COLORS[variant],
        )
    axes[1].set_xticks(xr, [label for _, label in metrics_right])
    axes[1].set_ylim(0.0, 1.08)
    axes[1].set_title("Process Ablation Profile")
    axes[1].grid(axis="y", alpha=0.25)
    axes[1].legend(frameon=False, fontsize=7, ncol=2)

    fig.suptitle("Pure Agentic Process Evidence", fontsize=14)
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)


def _plot_utility_split(path: Path, summary: Dict[str, Any]) -> None:
    utility = summary["utility"]
    fig, ax = plt.subplots(1, 1, figsize=(6.6, 4.6))

    internal_labels = ["Memory Utility", "Override Penalty", "Counterfactual", "Rollout"]
    internal_vals = [
        float(utility.get("memory_utility_gain", 0.0)),
        float(utility.get("evidence_override_penalty", 0.0)),
        float(utility.get("tool_effectiveness_by_type", {}).get("counterfactual", 0.0)),
        float(utility.get("tool_effectiveness_by_type", {}).get("rollout_candidates", 0.0)),
    ]
    internal_colors = ["#0b6e4f", "#6c5b7b", "#4c8a74", "#355c7d"]
    x1 = np.arange(len(internal_labels))
    ax.bar(x1, internal_vals, color=internal_colors, width=0.62)
    ax.set_xticks(x1, internal_labels, rotation=10)
    ax.set_ylabel("utility contribution")
    ax.set_title("Internal Agentic Utility")
    ax.grid(axis="y", alpha=0.25)
    for x, val in zip(x1, internal_vals):
        ax.text(x, val, f"{val:.3f}", ha="center", va="bottom", fontsize=8)

    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)


def _enhance_case_study(path: Path) -> None:
    data = _load_json(OUT_DIR / "exp08_case_study_selected_v42.json")
    methods = ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]
    labels = {
        "exp08_agentic": "Agentic",
        "plain_llm": "Plain LLM",
        "dqn": "DQN",
        "gnnddqn": "GNN-DDQN",
    }

    traces = data["exp08_agentic"]["traces"]
    tool_counts: Dict[str, int] = {}
    evidence_ok = 0
    for trace in traces:
        for tool in trace.get("step_tools_used", []):
            tool_counts[tool] = tool_counts.get(tool, 0) + 1
        if bool(trace.get("evidence_aligned", False)):
            evidence_ok += 1
    tool_summary = ", ".join(f"{k}:{v}" for k, v in sorted(tool_counts.items(), key=lambda kv: (-kv[1], kv[0]))[:3])
    memory_steps = int(sum(data["exp08_agentic"]["memory_flags"]))
    replan_steps = int(sum(data["exp08_agentic"]["replan_flags"]))

    fig = plt.figure(figsize=(11.6, 7.2))
    gs = fig.add_gridspec(3, 2, width_ratios=[3.3, 1.5], height_ratios=[2.2, 1.2, 0.1])
    ax_top = fig.add_subplot(gs[0, 0])
    ax_bottom = fig.add_subplot(gs[1, 0], sharex=ax_top)
    ax_text = fig.add_subplot(gs[:, 1])

    xs = list(range(len(data["exp08_agentic"]["fairness_values"])))
    for method in methods:
        ax_top.plot(xs, data[method]["fairness_values"], marker="o", linewidth=2.0, markersize=3.5, label=labels[method], color=METHOD_COLORS[method])
    shock_step = int(data["shock_profile"]["step"])
    ax_top.axvline(shock_step, linestyle="--", color="black", alpha=0.6)
    ax_top.set_ylabel("RAAFU")
    ax_top.set_title(
        f"Complex Shock Case Study: case_{data['case_idx']:03d} "
        f"(seed={data['case_seed']}, extra={data['shock_profile']['extra_vehicles']})"
    )
    ax_top.grid(alpha=0.25)
    ax_top.legend(frameon=False, ncol=2, loc="lower left")

    ax_bottom.step(xs, data["exp08_agentic"]["rri_values"], where="mid", linewidth=2.0, color="#0b6e4f", label="Agentic RRI")
    mem_x = [idx for idx, flag in enumerate(data["exp08_agentic"]["memory_flags"]) if flag]
    mem_y = [data["exp08_agentic"]["rri_values"][idx] for idx in mem_x]
    ax_bottom.scatter(mem_x, mem_y, color="#c06c00", marker="s", s=34, label="memory influence")
    rep_x = [idx for idx, flag in enumerate(data["exp08_agentic"]["replan_flags"]) if flag]
    rep_y = [data["exp08_agentic"]["rri_values"][idx] for idx in rep_x]
    if rep_x:
        ax_bottom.scatter(rep_x, rep_y, color="#8e44ad", marker="^", s=38, label="explicit replan")
    ax_bottom.axvline(shock_step, linestyle="--", color="black", alpha=0.6)
    ax_bottom.set_xlabel("Decision step")
    ax_bottom.set_ylabel("Agentic RRI")
    ax_bottom.grid(alpha=0.25)
    ax_bottom.legend(frameon=False, ncol=3, fontsize=8, loc="upper left")

    ax_text.axis("off")
    method_means = {labels[m]: _mean(data[m]["fairness_values"]) for m in methods}
    text_lines = [
        "Case Summary",
        "",
        f"Shock starts at step {shock_step}",
        f"Duration: {int(data['shock_profile']['duration'])}",
        f"Extra vehicles: {int(data['shock_profile']['extra_vehicles'])}",
        f"RRI change prob: {float(data['shock_profile']['rri_change_prob']):.3f}",
        "",
        "Mean RAAFU:",
        *[f"  {name}: {val:.3f}" for name, val in method_means.items()],
        "",
        f"Memory-active steps: {memory_steps}/{len(xs)}",
        f"Explicit replans: {replan_steps}/{len(xs)}",
        f"Evidence aligned: {evidence_ok}/{len(xs)}",
        "",
        "Top tool usage:",
        f"  {tool_summary if tool_summary else 'n/a'}",
    ]
    ax_text.text(0.02, 0.98, "\n".join(text_lines), va="top", ha="left", fontsize=10)

    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)


def main() -> None:
    _ensure_dir(OUT_DIR)
    summary = _build_process_summary()
    _plot_pure_agentic_process(OUT_DIR / "fig05_pure_agentic_process_selected_v42.png", summary)
    _plot_utility_split(OUT_DIR / "fig06_agentic_utility_split_selected_v42.png", summary)
    _enhance_case_study(OUT_DIR / "fig07_case_study_selected_v42.png")


if __name__ == "__main__":
    main()
