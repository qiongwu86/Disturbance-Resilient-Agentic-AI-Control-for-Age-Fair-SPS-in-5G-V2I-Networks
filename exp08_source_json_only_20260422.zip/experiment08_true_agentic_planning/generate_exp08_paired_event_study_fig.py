from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


REPO_ROOT = Path(__file__).resolve().parents[1]
ROOT = REPO_ROOT / "paper_figures_gpt" / "experiment08_true_agentic_planning"
OUT_DIR = ROOT / "paper_selected_baselines_v42"
SOURCE_JSON = ROOT / "exp08_paired_event_study_paper_paired_event_study_r1.json"
OUT_PNG = OUT_DIR / "fig05_paired_event_study_main_r1.png"

METHODS = ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]
METHOD_LABELS = {
    "exp08_agentic": "Agentic",
    "plain_llm": "Plain LLM",
    "dqn": "DQN",
    "gnnddqn": "GNN-DDQN",
}
METHOD_COLORS = {
    "exp08_agentic": "#0b6e4f",
    "plain_llm": "#c06c00",
    "dqn": "#355c7d",
    "gnnddqn": "#6c5b7b",
}


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    payload = _load_json(SOURCE_JSON)
    profile = payload["profiles"][0]
    methods = profile["aggregate"]["methods"]
    shock_template = profile["shock_profile_template"]
    shock_step = int(shock_template["step"])
    shock_duration = int(shock_template["duration"])

    plt.rcParams.update(
        {
            "font.size": 11,
            "axes.labelsize": 13,
            "axes.titlesize": 13,
            "axes.labelweight": "bold",
            "axes.titleweight": "bold",
            "xtick.labelsize": 11,
            "ytick.labelsize": 11,
            "legend.fontsize": 11,
        }
    )

    xs = np.arange(int(profile["max_steps"]))
    fig, axes = plt.subplots(
        2,
        1,
        figsize=(9.6, 7.4),
        gridspec_kw={"height_ratios": [2.2, 1.2]},
    )

    ax = axes[0]
    delta_min = 0.0
    delta_max = 0.0
    for method in METHODS:
        row = methods[method]
        delta = np.array(row["paired"]["delta_curve"], dtype=float)
        delta_min = min(delta_min, float(np.min(delta)))
        delta_max = max(delta_max, float(np.max(delta)))
        ax.plot(
            xs,
            delta,
            marker="o",
            markersize=5.4,
            linewidth=2.6,
            color=METHOD_COLORS[method],
            label=METHOD_LABELS[method],
        )

    ax.axhline(0.0, color="black", linewidth=1.0, linestyle="--", alpha=0.8)
    ax.axvspan(
        shock_step - 0.5,
        shock_step + shock_duration - 0.5,
        color="#bfc7d5",
        alpha=0.28,
        label="Shock window",
    )
    ax.set_xlabel("Decision step", fontweight="bold")
    ax.set_ylabel("Delta RAAFU", fontweight="bold")
    ax.set_xlim(-0.5, len(xs) - 0.5)
    ax.set_xticks(xs)
    pad = max(0.01, 0.12 * max(abs(delta_min), abs(delta_max), 0.05))
    ax.set_ylim(delta_min - pad, delta_max + pad)
    ax.grid(alpha=0.25, linestyle=":")
    ax.legend(frameon=False, ncol=3, loc="lower left", prop={"weight": "bold", "size": 11})
    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_fontweight("bold")
    ax.text(
        0.5,
        -0.22,
        "(a)",
        transform=ax.transAxes,
        ha="center",
        va="top",
        fontsize=13,
        fontweight="bold",
    )

    ax = axes[1]
    labels = [METHOD_LABELS[m] for m in METHODS]
    cumulative_loss = [float(methods[m]["paired"]["mean_case_metrics"]["cumulative_loss"]) for m in METHODS]
    bars = ax.bar(
        np.arange(len(METHODS)),
        cumulative_loss,
        color=[METHOD_COLORS[m] for m in METHODS],
        width=0.62,
    )
    for idx, value in enumerate(cumulative_loss):
        ax.text(
            idx,
            value + max(cumulative_loss) * 0.03,
            f"{value:.3f}",
            ha="center",
            va="bottom",
            fontsize=10,
            fontweight="bold",
        )
    ax.set_ylabel("Cumulative loss", fontweight="bold")
    ax.set_xticks(np.arange(len(labels)))
    ax.set_xticklabels(labels)
    ax.set_ylim(0.0, max(cumulative_loss) * 1.22)
    ax.grid(axis="y", alpha=0.25, linestyle=":")
    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_fontweight("bold")
    ax.text(
        0.5,
        -0.18,
        "(b)",
        transform=ax.transAxes,
        ha="center",
        va="top",
        fontsize=13,
        fontweight="bold",
    )

    fig.tight_layout(rect=(0.02, 0.04, 0.98, 0.98))
    fig.savefig(OUT_PNG, dpi=240, bbox_inches="tight")
    plt.close(fig)
    print(str(OUT_PNG))


if __name__ == "__main__":
    main()
