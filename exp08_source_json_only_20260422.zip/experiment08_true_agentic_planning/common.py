from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np


@dataclass
class ActionCodec:
    rri_values: List[int]

    @property
    def num_actions(self) -> int:
        return max(1, len(self.rri_values) * 2)

    def encode(self, rri_value: int, force_reselect: bool) -> int:
        if not self.rri_values:
            return 0
        try:
            idx = self.rri_values.index(int(rri_value))
        except Exception:
            idx = min(range(len(self.rri_values)), key=lambda i: abs(self.rri_values[i] - int(rri_value)))
        if force_reselect:
            idx += len(self.rri_values)
        return int(idx)

    def decode(self, action_idx: int) -> Tuple[int, bool]:
        if not self.rri_values:
            return 100, False
        n_rri = len(self.rri_values)
        action_norm = int(action_idx) % max(1, 2 * n_rri)
        branch = action_norm // n_rri
        rri_idx = action_norm % n_rri
        return int(self.rri_values[rri_idx]), bool(branch == 1)


def compute_raafu(
    fairness_metrics: Dict,
    rri_value: float,
    n_v: int,
    collision_prob: float,
    *,
    k_age: float = 0.6,
    alpha_rri: float = 0.1,
    beta_coll: float = 0.2,
    mode: str = "freshness_log",
) -> Dict:
    individual_paoids = fairness_metrics.get("individual_paoids", [])
    if not individual_paoids:
        return {
            "raafu": 1.0,
            "age_fairness": 1.0,
            "rri_efficiency": 1.0,
            "collision_penalty": 1.0,
            "raafu_per_vehicle": [],
        }

    n_total = max(1, int(n_v))
    opt_rri_table = {1: 20, 2: 50, 3: 100, 4: 100, 5: 200, 6: 200, 7: 300, 8: 300, 9: 500, 10: 500}
    if n_total in opt_rri_table:
        rri_opt = opt_rri_table[n_total]
    elif n_total <= 1:
        rri_opt = 20
    elif n_total >= 10:
        rri_opt = 500
    else:
        nearest = min(opt_rri_table.keys(), key=lambda key: abs(key - n_total))
        rri_opt = opt_rri_table[nearest]

    eps = 1e-6
    rri_ratio = float(rri_value) / max(eps, float(rri_opt))
    rri_efficiency = float(np.exp(-alpha_rri * abs(np.log(max(eps, rri_ratio)))))
    collision_penalty = float(np.exp(-beta_coll * float(collision_prob)))

    fresh_vals = [1.0 / (float(v) + eps) for v in individual_paoids]
    mean_fresh = float(np.mean(fresh_vals)) if fresh_vals else 0.0

    per_vehicle = []
    fairness_per_vehicle = []
    total_sum = float(sum(individual_paoids))
    ideal_ratio = 1.0 / n_total

    for idx, paoid_self in enumerate(individual_paoids):
        if n_total > 1:
            paoid_others_avg = (total_sum - float(paoid_self)) / (n_total - 1)
        else:
            paoid_others_avg = 0.0

        denom = float(paoid_self) + paoid_others_avg
        if mode == "ratio":
            age_ratio = float(paoid_self) / denom if denom > 0 else 0.5
            age_fairness = float(np.exp(-k_age * abs(age_ratio - ideal_ratio)))
        else:
            fresh_i = float(fresh_vals[idx]) if idx < len(fresh_vals) else 0.0
            ratio = fresh_i / (mean_fresh + eps) if mean_fresh > 0 else 1.0
            age_fairness = float(np.exp(-k_age * abs(np.log(max(eps, ratio)))))
        fairness_per_vehicle.append(age_fairness)
        per_vehicle.append(float(age_fairness * rri_efficiency * collision_penalty))

    return {
        "raafu": float(np.mean(per_vehicle)) if per_vehicle else 0.0,
        "age_fairness": float(np.mean(fairness_per_vehicle)) if fairness_per_vehicle else 1.0,
        "rri_efficiency": float(rri_efficiency),
        "collision_penalty": float(collision_penalty),
        "raafu_per_vehicle": per_vehicle,
    }


def build_metrics(env, state: Dict) -> Dict:
    fairness = env.calculate_fairness_metrics(int(state.get("N_v", env.N_v)), float(state.get("RRI", 100.0)))
    fairness["collision_prob"] = float(state.get("P_coll", 0.0))
    fairness["system_paoid"] = float(state.get("PAoI", 0.0))
    fairness.update(
        compute_raafu(
            fairness,
            float(state.get("RRI", 100.0)),
            int(state.get("N_v", env.N_v)),
            collision_prob=float(state.get("P_coll", 0.0)),
        )
    )
    return fairness


def compute_reward(current_metrics: Dict, previous_metrics: Dict) -> float:
    current_raafu = float(current_metrics.get("raafu", 0.0))
    previous_raafu = float(previous_metrics.get("raafu", 0.0))
    fairness_delta = float(current_metrics.get("fairness_index", 0.0)) - float(previous_metrics.get("fairness_index", 0.0))
    paoi_delta = float(previous_metrics.get("system_paoid", previous_metrics.get("avg_paoid", 0.0))) - float(
        current_metrics.get("system_paoid", current_metrics.get("avg_paoid", 0.0))
    )
    collision_penalty = float(current_metrics.get("collision_prob", 0.0))
    reward = (
        0.60 * current_raafu
        + 0.20 * (current_raafu - previous_raafu)
        + 0.10 * fairness_delta
        + 0.10 * (paoi_delta / 2000.0)
        - 0.10 * collision_penalty
    )
    if float(current_metrics.get("system_paoid", 0.0)) > 1000.0:
        reward -= 0.25
    return float(reward)


def build_state_vector(state: Dict, metrics: Dict, *, prev_branch: int = 0, shock_flag: int = 0) -> List[float]:
    return [
        float(state.get("N_v", 0)) / 10.0,
        float(state.get("RRI", 100.0)) / 1000.0,
        float(state.get("P_coll", 0.0)),
        float(state.get("PAoI", 0.0)) / 2000.0,
        float(metrics.get("fairness_index", 0.0)),
        float(metrics.get("raafu", 0.0)),
        float(metrics.get("paoid_diff", 0.0)) / 2000.0,
        float(prev_branch),
        float(shock_flag),
    ]


def build_graph_observation(env, state: Dict, metrics: Dict) -> Tuple[np.ndarray, np.ndarray]:
    n_active = max(1, int(state.get("N_v", env.N_v)))
    max_nodes = int(getattr(env, "N_max", n_active))
    node_features = np.zeros((max_nodes, 6), dtype=np.float32)
    adjacency = np.zeros((max_nodes, max_nodes), dtype=np.float32)

    def pad_vector(values, size):
        arr = np.asarray(values, dtype=np.float32).reshape(-1)
        if arr.shape[0] >= size:
            return arr[:size]
        padded = np.zeros(size, dtype=np.float32)
        padded[: arr.shape[0]] = arr
        return padded

    positions = pad_vector(getattr(env, "vehicle_positions", np.zeros(max_nodes)), max_nodes)
    speeds = pad_vector(getattr(env, "vehicle_speeds", np.zeros(max_nodes)), max_nodes)
    mcs_levels = pad_vector(getattr(env, "vehicle_mcs_levels", np.zeros(max_nodes)), max_nodes)
    rri_per_vehicle = np.asarray(
        getattr(env, "rri_per_vehicle", np.full(max_nodes, float(state.get("RRI", 100.0)))),
        dtype=np.float32,
    )
    if rri_per_vehicle.shape[0] < max_nodes:
        padded_rri = np.full(max_nodes, float(state.get("RRI", 100.0)), dtype=np.float32)
        padded_rri[: rri_per_vehicle.shape[0]] = rri_per_vehicle
        rri_per_vehicle = padded_rri

    road_len = max(1.0, float(getattr(env, "L", 500.0)))
    max_rri = max([1.0] + [float(x) for x in getattr(env, "R_set", [100.0])])

    for i in range(min(n_active, max_nodes)):
        node_features[i, 0] = 1.0 if i == int(getattr(env, "agent_controlled_vehicle_idx", 0)) else 0.0
        node_features[i, 1] = float(rri_per_vehicle[i]) / max_rri
        node_features[i, 2] = float(speeds[i]) / 30.0
        node_features[i, 3] = float(mcs_levels[i]) / 7.0
        node_features[i, 4] = float(positions[i]) / road_len
        node_features[i, 5] = float(metrics.get("fairness_index", 0.0))

    for i in range(min(n_active, max_nodes)):
        for j in range(min(n_active, max_nodes)):
            if i == j:
                adjacency[i, j] = 1.0
            else:
                dist = abs(float(positions[i]) - float(positions[j]))
                adjacency[i, j] = 1.0 if dist <= road_len / 4.0 else max(0.0, 1.0 - dist / road_len)

    row_sum = adjacency.sum(axis=1, keepdims=True)
    row_sum[row_sum <= 1e-6] = 1.0
    adjacency = adjacency / row_sum
    return node_features, adjacency


def entropy_from_counts(counts: Dict[str, int]) -> float:
    total = float(sum(max(0, int(v)) for v in counts.values()))
    if total <= 0:
        return 0.0
    entropy = 0.0
    for value in counts.values():
        if value <= 0:
            continue
        p = float(value) / total
        entropy -= p * math.log(p + 1e-12)
    return float(entropy)


def bucketize(value: float, edges: List[float], labels: List[str]) -> str:
    for idx, edge in enumerate(edges):
        if value <= edge:
            return labels[min(idx, len(labels) - 1)]
    return labels[-1] if labels else "unknown"
