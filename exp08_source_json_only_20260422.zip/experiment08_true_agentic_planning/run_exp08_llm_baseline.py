from __future__ import annotations

import json
import os
from pathlib import Path
from statistics import mean
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiment08_true_agentic_planning.common import build_metrics, compute_reward
from experiment08_true_agentic_planning.plain_llm_baseline import PlainLLMBaseline, PlainLLMBaselineConfig


def run_scenario(baseline: PlainLLMBaseline, scenario: str, *, episodes: int, max_steps: int, shock_profile=None):
    episode_records = []
    llm_used_steps = 0
    total_steps = 0

    for _ in range(int(episodes)):
        state, metrics = baseline.reset(scenario)
        fairness_values = []
        rewards = []
        traces = []
        shock_step = int(shock_profile["step"]) if shock_profile and "step" in shock_profile else None
        shock_duration = int(shock_profile.get("duration", 1)) if shock_profile else 0

        for step_idx in range(int(max_steps)):
            shock_flag = bool(shock_step is not None and shock_step <= step_idx < shock_step + shock_duration)
            if shock_step is not None and step_idx == shock_step:
                extra = int(shock_profile.get("extra_vehicles", 2))
                baseline.env.N_v = min(baseline.env.N_max, int(baseline.env.N_v) + extra)
                baseline.env.other_rri_mode = str(shock_profile.get("other_rri_mode", "markov_pingpong"))
                baseline.env.rri_change_prob = float(shock_profile.get("rri_change_prob", 0.75))

            decision = baseline.choose_action(state, metrics, shock_flag=shock_flag)
            mcs_action = int(state.get("agent_mcs_level", 3))
            next_state, done = baseline.env.step(
                mcs_action,
                rri_value=int(decision["chosen_rri"]),
                force_reselect=bool(decision["force_reselect"]),
            )
            next_metrics = build_metrics(baseline.env, next_state)
            reward = compute_reward(next_metrics, metrics)
            fairness_values.append(float(next_metrics.get("raafu", 0.0)))
            rewards.append(float(reward))
            traces.append(
                {
                    "step": int(step_idx),
                    "decision": decision,
                    "reward": float(reward),
                    "metrics": dict(next_metrics),
                }
            )
            llm_used_steps += 1 if decision.get("used_llm", False) else 0
            total_steps += 1
            state = next_state
            metrics = next_metrics
            if done:
                break

        episode_records.append(
            {
                "mean_raafu": float(np.mean(fairness_values)) if fairness_values else 0.0,
                "mean_reward": float(np.mean(rewards)) if rewards else 0.0,
                "final_metrics": dict(metrics),
                "trace_tail": traces[-3:],
            }
        )

    return {
        "scenario": scenario,
        "episodes": episodes,
        "max_steps": max_steps,
        "shock_profile": shock_profile,
        "summary": {
            "mean_raafu": mean(item["mean_raafu"] for item in episode_records),
            "mean_reward": mean(item["mean_reward"] for item in episode_records),
            "llm_step_ratio": float(llm_used_steps / max(1, total_steps)),
        },
        "records": episode_records,
    }


def main() -> None:
    output_dir = Path("paper_figures_gpt/experiment08_true_agentic_planning/baselines")
    output_dir.mkdir(parents=True, exist_ok=True)

    output_tag = os.getenv("EXP08_OUTPUT_TAG", "latest")
    episodes = int(os.getenv("EXP08_LLM_BASELINE_EPISODES", "3"))
    max_steps = int(os.getenv("EXP08_LLM_BASELINE_MAX_STEPS", "18"))
    shock_steps = int(os.getenv("EXP08_LLM_BASELINE_SHOCK_STEPS", "20"))
    config = PlainLLMBaselineConfig(
        use_llm=os.getenv("EXP08_USE_LLM", "0") == "1",
        strict_llm=False,
        model_name=os.getenv("EXP08_MODEL", "gpt-4o-mini"),
        base_url=os.getenv("OPENAI_BASE_URL", ""),
        api_key=os.getenv("OPENAI_API_KEY", ""),
    )
    seeds = [0]
    payload = {"seeds": seeds, "runs": []}

    for seed in seeds:
        baseline = PlainLLMBaseline(config=config, seed=seed)
        payload["runs"].append(
            {
                "seed": seed,
                "simple_static": run_scenario(baseline, "simple", episodes=episodes, max_steps=max_steps),
                "complex_static": run_scenario(baseline, "complex", episodes=episodes, max_steps=max_steps),
                "complex_shock": run_scenario(
                    baseline,
                    "complex",
                    episodes=episodes,
                    max_steps=shock_steps,
                    shock_profile={"step": 8, "duration": 4, "extra_vehicles": 3, "rri_change_prob": 0.85},
                ),
            }
        )

    output_path = output_dir / f"exp08_llm_baseline_{output_tag}.json"
    output_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(str(output_path))


if __name__ == "__main__":
    main()
