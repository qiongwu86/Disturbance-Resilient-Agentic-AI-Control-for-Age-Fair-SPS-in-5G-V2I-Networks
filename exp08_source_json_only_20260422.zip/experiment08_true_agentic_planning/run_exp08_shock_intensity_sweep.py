from __future__ import annotations

import json
import logging
import os
from pathlib import Path
import sys
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("openai").setLevel(logging.WARNING)
logging.getLogger("openai._base_client").setLevel(logging.WARNING)

from experiment08_true_agentic_planning.formal_eval import (
    _checkpoint_entries,
    _load_manifest,
    _maybe_load_manifest,
    _planner_config_from_env,
    _plain_llm_config_from_env,
    _run_agentic_case,
    _run_baseline_checkpoint_case,
    _run_plain_llm_case,
)
from experiment08_true_agentic_planning.formal_utils import build_case_seeds, save_json, set_global_seed


def _parse_int_list(raw: str, default: List[int]) -> List[int]:
    text = str(raw or "").strip()
    if not text:
        return [int(x) for x in default]
    return [int(item.strip()) for item in text.split(",") if item.strip()]


def _parse_float_list(raw: str, default: List[float]) -> List[float]:
    text = str(raw or "").strip()
    if not text:
        return [float(x) for x in default]
    return [float(item.strip()) for item in text.split(",") if item.strip()]


def _parse_text_list(raw: str, default: List[str]) -> List[str]:
    text = str(raw or "").strip()
    if not text:
        return [str(x).strip().lower() for x in default]
    return [item.strip().lower() for item in text.split(",") if item.strip()]


def _safe_float(value: Any, default: float = 0.0) -> float:
    if value is None:
        return float(default)
    try:
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _average_method_value(case_rows: List[Dict[str, Any]], method_name: str, key: str) -> float:
    values: List[float] = []
    for row in case_rows:
        payload = row["results"][method_name]
        if isinstance(payload, list):
            values.append(sum(_safe_float(item.get(key, 0.0)) for item in payload) / max(1, len(payload)))
        else:
            values.append(_safe_float(payload.get(key, 0.0)))
    return float(sum(values) / max(1, len(values)))


def _summarize_profile(case_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    methods = ["exp08_agentic", "plain_llm", "dqn", "dqn_strong", "gnnddqn"]
    metric_keys = ["mean_raafu", "mean_reward", "shock_floor", "recovery_integrity", "shock_response_lag", "degradation_area"]
    summary: Dict[str, Any] = {}
    for method_name in methods:
        summary[method_name] = {key: _average_method_value(case_rows, method_name, key) for key in metric_keys}
    return summary


def _profile_payload(
    *,
    label: str,
    shock_profile_template: Dict[str, Any],
    case_count: int,
    max_steps: int,
    baseline_tag: str,
) -> Dict[str, Any]:
    planner_config = _planner_config_from_env()
    plain_llm_config = _plain_llm_config_from_env()
    dqn_manifest = _maybe_load_manifest("dqn", baseline_tag)
    dqn_strong_manifest = _load_manifest("dqn_strong", baseline_tag)
    gnnddqn_manifest = _load_manifest("gnnddqn", baseline_tag)
    dqn_entries = _checkpoint_entries(dqn_manifest, "complex") if dqn_manifest is not None else []
    dqn_strong_entries = _checkpoint_entries(dqn_strong_manifest, "complex")
    gnnddqn_entries = _checkpoint_entries(gnnddqn_manifest, "complex")

    case_rows: List[Dict[str, Any]] = []
    case_seeds = build_case_seeds(case_count, base_seed=4000)
    for case_idx, case_seed in enumerate(case_seeds):
        set_global_seed(case_seed)
        shock_profile = dict(shock_profile_template)
        shock_profile["seed"] = int(case_seed)
        case_rows.append(
            {
                "case_id": f"{label}_{case_idx:03d}",
                "case_seed": int(case_seed),
                "shock_profile": shock_profile,
                "results": {
                    "exp08_agentic": _run_agentic_case("complex", case_seed, max_steps, shock_profile, planner_config),
                    "plain_llm": _run_plain_llm_case("complex", case_seed, max_steps, shock_profile, plain_llm_config),
                    "dqn": [
                        _run_baseline_checkpoint_case(
                            "dqn",
                            entry["checkpoint_path"],
                            "complex",
                            case_seed,
                            max_steps,
                            shock_profile,
                            int(entry["seed"]),
                        )
                        for entry in dqn_entries
                    ],
                    "dqn_strong": [
                        _run_baseline_checkpoint_case(
                            "dqn_strong",
                            entry["checkpoint_path"],
                            "complex",
                            case_seed,
                            max_steps,
                            shock_profile,
                            int(entry["seed"]),
                        )
                        for entry in dqn_strong_entries
                    ],
                    "gnnddqn": [
                        _run_baseline_checkpoint_case(
                            "gnnddqn",
                            entry["checkpoint_path"],
                            "complex",
                            case_seed,
                            max_steps,
                            shock_profile,
                            int(entry["seed"]),
                        )
                        for entry in gnnddqn_entries
                    ],
                },
            }
        )

    return {
        "label": label,
        "shock_profile": shock_profile_template,
        "cases": case_rows,
        "summary": _summarize_profile(case_rows),
    }


def main() -> None:
    output_tag = os.getenv("EXP08_OUTPUT_TAG", "latest")
    baseline_tag = os.getenv("EXP08_BASELINE_TAG", output_tag)
    case_count = int(os.getenv("EXP08_SWEEP_CASES", "16"))
    max_steps = int(os.getenv("EXP08_SWEEP_STEPS", "24"))
    base_step = int(os.getenv("EXP08_SWEEP_SHOCK_STEP", "8"))
    base_extra = int(os.getenv("EXP08_SWEEP_BASE_EXTRA", "3"))
    base_duration = int(os.getenv("EXP08_SWEEP_BASE_DURATION", "5"))
    base_prob = float(os.getenv("EXP08_SWEEP_BASE_PROB", "0.8"))
    base_markov_ps = float(os.getenv("EXP08_SWEEP_BASE_MARKOV_PS", "1.0"))
    extra_values = _parse_int_list(os.getenv("EXP08_SWEEP_EXTRA_VALUES", ""), [1, 2, 3, 4])
    duration_values = _parse_int_list(os.getenv("EXP08_SWEEP_DURATION_VALUES", ""), [3, 5, 7])
    prob_values = _parse_float_list(
        os.getenv("EXP08_SWEEP_PROB_VALUES", ""),
        [0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 1.00],
    )
    enabled_dimensions = set(_parse_text_list(os.getenv("EXP08_SWEEP_DIMENSIONS", ""), ["extra", "duration", "prob"]))
    output_path = Path("paper_figures_gpt/experiment08_true_agentic_planning") / f"exp08_shock_intensity_sweep_{output_tag}.json"

    dimensions: List[Dict[str, Any]] = []
    
    def _save_partial() -> None:
        save_json(
            output_path,
            {
                "tag": output_tag,
                "baseline_tag": baseline_tag,
                "case_count_per_profile": int(case_count),
                "max_steps": int(max_steps),
                "enabled_dimensions": sorted(enabled_dimensions),
                "profiles": dimensions,
            },
        )

    if "extra" in enabled_dimensions:
        for extra in extra_values:
            dimensions.append(
                _profile_payload(
                    label=f"extra_{int(extra)}",
                    shock_profile_template={
                        "step": base_step,
                        "duration": base_duration,
                        "extra_vehicles": int(extra),
                        "rri_change_prob": base_prob,
                        "markov_ps": base_markov_ps,
                        "other_rri_mode": "markov_pingpong",
                        "markov_states": [20.0, 50.0, 100.0, 200.0, 500.0],
                    },
                    case_count=case_count,
                    max_steps=max_steps,
                    baseline_tag=baseline_tag,
                )
            )
            _save_partial()
    if "duration" in enabled_dimensions:
        for duration in duration_values:
            dimensions.append(
                _profile_payload(
                    label=f"duration_{int(duration)}",
                    shock_profile_template={
                        "step": base_step,
                        "duration": int(duration),
                        "extra_vehicles": base_extra,
                        "rri_change_prob": base_prob,
                        "markov_ps": base_markov_ps,
                        "other_rri_mode": "markov_pingpong",
                        "markov_states": [20.0, 50.0, 100.0, 200.0, 500.0],
                    },
                    case_count=case_count,
                    max_steps=max_steps,
                    baseline_tag=baseline_tag,
                )
            )
            _save_partial()
    if "prob" in enabled_dimensions:
        for prob in prob_values:
            dimensions.append(
                _profile_payload(
                    label=f"markovps_{str(prob).replace('.', 'p')}",
                    shock_profile_template={
                        "step": base_step,
                        "duration": base_duration,
                        "extra_vehicles": base_extra,
                        "rri_change_prob": base_prob,
                        "markov_ps": float(prob),
                        "other_rri_mode": "markov_pingpong",
                        "markov_states": [20.0, 50.0, 100.0, 200.0, 500.0],
                    },
                    case_count=case_count,
                    max_steps=max_steps,
                    baseline_tag=baseline_tag,
                )
            )
            _save_partial()

    payload = {
        "tag": output_tag,
        "baseline_tag": baseline_tag,
        "case_count_per_profile": int(case_count),
        "max_steps": int(max_steps),
        "enabled_dimensions": sorted(enabled_dimensions),
        "profiles": dimensions,
    }
    save_json(output_path, payload)
    print(str(output_path).replace("\\", "/"))


if __name__ == "__main__":
    main()
