from __future__ import annotations

import json
import os
from pathlib import Path
from statistics import mean
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiment08_true_agentic_planning.planner_led_v2x_system import PlannerLedAgenticSystem, PlannerLedConfig


def summarize_runs(runs):
    if not runs:
        return {}
    keys = [
        "planner_authority_ratio",
        "tool_entropy",
        "tool_selection_diversity",
        "memory_query_rate",
        "memory_changed_plan_rate",
        "replan_depth",
        "subgoal_completion_rate",
        "fallback_rate",
        "safety_override_rate",
        "recovery_integrity",
        "mean_reward",
        "mean_raafu",
    ]
    return {
        key: mean(float(run["agentic_stats"].get(key, 0.0)) for run in runs)
        for key in keys
    }


def main() -> None:
    output_dir = Path("paper_figures_gpt/experiment08_true_agentic_planning/stage1_validate")
    output_dir.mkdir(parents=True, exist_ok=True)

    output_tag = os.getenv("EXP08_OUTPUT_TAG", "latest")
    seed_text = os.getenv("EXP08_STAGE1_SEEDS", "0,1")
    seeds = [int(item.strip()) for item in seed_text.split(",") if item.strip()]
    simple_steps = int(os.getenv("EXP08_STAGE1_SIMPLE_STEPS", "24"))
    complex_steps = int(os.getenv("EXP08_STAGE1_COMPLEX_STEPS", "24"))
    simple_shock_steps = int(os.getenv("EXP08_STAGE1_SIMPLE_SHOCK_STEPS", "26"))
    complex_shock_steps = int(os.getenv("EXP08_STAGE1_COMPLEX_SHOCK_STEPS", "28"))
    simple_shock_step = int(os.getenv("EXP08_STAGE1_SIMPLE_SHOCK_AT", "10"))
    complex_shock_step = int(os.getenv("EXP08_STAGE1_COMPLEX_SHOCK_AT", "10"))
    config = PlannerLedConfig(
        use_llm=os.getenv("EXP08_USE_LLM", "0") == "1",
        strict_llm=False,
        model_name=os.getenv("EXP08_MODEL", "gpt-4o-mini"),
        base_url=os.getenv("OPENAI_BASE_URL", ""),
        api_key=os.getenv("OPENAI_API_KEY", ""),
    )
    results = {
        "simple_static": [],
        "complex_static": [],
        "simple_shock": [],
        "complex_shock": [],
    }

    for seed in seeds:
        system = PlannerLedAgenticSystem(config=config, seed=seed)
        results["simple_static"].append(system.run_episode(scenario="simple", max_steps=simple_steps))
        results["complex_static"].append(system.run_episode(scenario="complex", max_steps=complex_steps))
        results["simple_shock"].append(
            system.run_episode(
                scenario="simple",
                max_steps=simple_shock_steps,
                shock_profile={"step": simple_shock_step, "duration": 4, "extra_vehicles": 2, "rri_change_prob": 0.70},
            )
        )
        results["complex_shock"].append(
            system.run_episode(
                scenario="complex",
                max_steps=complex_shock_steps,
                shock_profile={"step": complex_shock_step, "duration": 5, "extra_vehicles": 3, "rri_change_prob": 0.85},
            )
        )

    payload = {
        "seeds": seeds,
        "runs": results,
        "summary": {name: summarize_runs(runs) for name, runs in results.items()},
    }
    output_path = output_dir / f"exp08_stage1_validate_{output_tag}.json"
    output_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(str(output_path))


if __name__ == "__main__":
    main()
