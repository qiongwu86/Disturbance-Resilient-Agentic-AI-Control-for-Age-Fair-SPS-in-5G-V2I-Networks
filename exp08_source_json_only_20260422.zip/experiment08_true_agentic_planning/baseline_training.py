from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from statistics import mean
from typing import Any, Dict, List, Tuple

import torch

from agentic_v2x_system import V2XEnvironment

from .baseline_models import DQNAgent, DQNStrongAgent, GNNDDQNAgent
from .common import ActionCodec, build_graph_observation, build_metrics, build_state_vector, compute_reward
from .formal_utils import PROTOCOL_VERSION, save_json, set_global_seed
from .planner_led_v2x_system import configure_environment_for_scenario


@dataclass
class BaselineTrainConfig:
    method: str
    scenarios: List[str]
    seeds: List[int]
    episodes_simple: int = 1000
    episodes_complex: int = 1500
    max_steps_simple: int = 24
    max_steps_complex: int = 32
    eval_every: int = 100
    eval_episodes: int = 8
    output_tag: str = "latest"


def _decode_action(env: V2XEnvironment, codec: ActionCodec, action_idx: int) -> Tuple[int, bool]:
    if codec is not None:
        return codec.decode(action_idx)
    n_rri = len(env.R_set)
    normalized = int(action_idx) % max(1, 2 * n_rri)
    branch = normalized // n_rri
    rri = int(env.R_set[normalized % n_rri])
    return rri, bool(branch == 1)


def _build_agent(method: str, env: V2XEnvironment, seed: int):
    if method == "dqn":
        codec = ActionCodec([int(x) for x in env.R_set])
        agent = DQNAgent(state_dim=9, num_actions=codec.num_actions, seed=seed)
        return agent, codec
    if method == "dqn_strong":
        codec = ActionCodec([int(x) for x in env.R_set])
        agent = DQNStrongAgent(state_dim=9, num_actions=codec.num_actions, seed=seed)
        return agent, codec
    if method == "gnnddqn":
        agent = GNNDDQNAgent(node_feat_dim=6, num_actions=len(env.R_set) * 2, seed=seed)
        return agent, None
    raise ValueError(f"Unsupported baseline method: {method}")


def _run_train_episode(method: str, agent, codec, env: V2XEnvironment, max_steps: int, episode_seed: int) -> Dict[str, float]:
    set_global_seed(episode_seed)
    state = env.reset()
    metrics = build_metrics(env, state)
    previous_branch = 0
    fairness_values: List[float] = []
    rewards: List[float] = []

    for _ in range(int(max_steps)):
        if method in {"dqn", "dqn_strong"}:
            obs = build_state_vector(state, metrics, prev_branch=previous_branch, shock_flag=0)
            action_idx = agent.act(obs)
            rri, force_reselect = _decode_action(env, codec, action_idx)
            mcs_action = int(state.get("agent_mcs_level", 3))
            next_state, done = env.step(mcs_action, rri_value=rri, force_reselect=force_reselect)
            next_metrics = build_metrics(env, next_state)
            reward = compute_reward(next_metrics, metrics)
            next_obs = build_state_vector(next_state, next_metrics, prev_branch=1 if force_reselect else 0, shock_flag=0)
            agent.observe(obs, action_idx, reward, next_obs, done)
            previous_branch = 1 if force_reselect else 0
        else:
            node_feats, adjacency = build_graph_observation(env, state, metrics)
            action_idx = agent.act(node_feats, adjacency)
            rri, force_reselect = _decode_action(env, codec, action_idx)
            mcs_action = int(state.get("agent_mcs_level", 3))
            next_state, done = env.step(mcs_action, rri_value=rri, force_reselect=force_reselect)
            next_metrics = build_metrics(env, next_state)
            reward = compute_reward(next_metrics, metrics)
            next_node_feats, next_adjacency = build_graph_observation(env, next_state, next_metrics)
            agent.observe(node_feats, adjacency, action_idx, reward, next_node_feats, next_adjacency, done)

        fairness_values.append(float(next_metrics.get("raafu", 0.0)))
        rewards.append(float(reward))
        state = next_state
        metrics = next_metrics
        if done:
            break

    return {
        "mean_raafu": float(mean(fairness_values)) if fairness_values else 0.0,
        "mean_reward": float(mean(rewards)) if rewards else 0.0,
    }


def _run_eval_episode(method: str, agent, codec, scenario: str, case_seed: int, max_steps: int) -> Dict[str, float]:
    set_global_seed(case_seed)
    env = V2XEnvironment()
    configure_environment_for_scenario(env, scenario)
    state = env.current_state
    metrics = build_metrics(env, state)
    previous_branch = 0
    fairness_values: List[float] = []
    rewards: List[float] = []

    epsilon_backup = getattr(agent, "epsilon", None)
    if epsilon_backup is not None:
        agent.epsilon = 0.0

    try:
        for _ in range(int(max_steps)):
            if method in {"dqn", "dqn_strong"}:
                obs = build_state_vector(state, metrics, prev_branch=previous_branch, shock_flag=0)
                action_idx = agent.act(obs)
                rri, force_reselect = _decode_action(env, codec, action_idx)
                previous_branch = 1 if force_reselect else 0
            else:
                node_feats, adjacency = build_graph_observation(env, state, metrics)
                action_idx = agent.act(node_feats, adjacency)
                rri, force_reselect = _decode_action(env, codec, action_idx)
            mcs_action = int(state.get("agent_mcs_level", 3))
            next_state, done = env.step(mcs_action, rri_value=rri, force_reselect=force_reselect)
            next_metrics = build_metrics(env, next_state)
            reward = compute_reward(next_metrics, metrics)
            fairness_values.append(float(next_metrics.get("raafu", 0.0)))
            rewards.append(float(reward))
            state = next_state
            metrics = next_metrics
            if done:
                break
    finally:
        if epsilon_backup is not None:
            agent.epsilon = epsilon_backup

    return {
        "mean_raafu": float(mean(fairness_values)) if fairness_values else 0.0,
        "mean_reward": float(mean(rewards)) if rewards else 0.0,
    }


def _checkpoint_payload(agent, method: str, scenario: str, seed: int, best_eval_raafu: float) -> Dict[str, Any]:
    payload = {
        "protocol_version": PROTOCOL_VERSION,
        "method": method,
        "scenario": scenario,
        "seed": int(seed),
        "best_eval_raafu": float(best_eval_raafu),
        "policy_state_dict": agent.policy.state_dict(),
        "target_state_dict": agent.target.state_dict(),
        "epsilon": float(getattr(agent, "epsilon", 0.0)),
        "train_steps": int(getattr(agent, "train_steps", 0)),
    }
    return payload


def train_baseline_suite(config: BaselineTrainConfig) -> Dict[str, Any]:
    training_dir = Path("paper_figures_gpt/experiment08_true_agentic_planning/training")
    checkpoint_dir = Path("paper_figures_gpt/experiment08_true_agentic_planning/checkpoints") / config.output_tag
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    manifest: Dict[str, Any] = {
        "protocol_version": PROTOCOL_VERSION,
        "method": config.method,
        "output_tag": config.output_tag,
        "scenario_runs": {},
    }

    for scenario in config.scenarios:
        episodes = int(config.episodes_complex if scenario == "complex" else config.episodes_simple)
        max_steps = int(config.max_steps_complex if scenario == "complex" else config.max_steps_simple)
        manifest["scenario_runs"][scenario] = []

        for seed in config.seeds:
            set_global_seed(seed)
            env = V2XEnvironment()
            configure_environment_for_scenario(env, scenario)
            agent, codec = _build_agent(config.method, env, seed)
            history: List[Dict[str, Any]] = []
            best_eval_raafu = -1e9
            best_checkpoint_path = None

            for episode_idx in range(1, episodes + 1):
                train_metrics = _run_train_episode(config.method, agent, codec, env, max_steps, seed * 100000 + episode_idx)
                row: Dict[str, Any] = {"episode": int(episode_idx), **train_metrics}

                if episode_idx % max(1, config.eval_every) == 0 or episode_idx == episodes:
                    eval_rows = [
                        _run_eval_episode(config.method, agent, codec, scenario, seed * 10000 + eval_idx, max_steps)
                        for eval_idx in range(config.eval_episodes)
                    ]
                    eval_raafu = float(mean(item["mean_raafu"] for item in eval_rows)) if eval_rows else 0.0
                    eval_reward = float(mean(item["mean_reward"] for item in eval_rows)) if eval_rows else 0.0
                    row["eval_mean_raafu"] = eval_raafu
                    row["eval_mean_reward"] = eval_reward
                    if eval_raafu > best_eval_raafu:
                        best_eval_raafu = eval_raafu
                        ckpt_name = f"{config.method}_{scenario}_seed{seed}_best.pt"
                        best_checkpoint_path = checkpoint_dir / ckpt_name
                        torch.save(_checkpoint_payload(agent, config.method, scenario, seed, best_eval_raafu), best_checkpoint_path)
                history.append(row)

            manifest["scenario_runs"][scenario].append(
                {
                    "seed": int(seed),
                    "episodes": int(episodes),
                    "max_steps": int(max_steps),
                    "best_eval_mean_raafu": float(best_eval_raafu),
                    "checkpoint_path": str(best_checkpoint_path).replace("\\", "/") if best_checkpoint_path else None,
                    "history": history,
                }
            )

    output_path = training_dir / f"{config.method}_convergence_{config.output_tag}.json"
    save_json(output_path, manifest)
    return {"manifest_path": str(output_path).replace("\\", "/"), "manifest": manifest}


def config_from_env(method: str) -> BaselineTrainConfig:
    seed_text = os.getenv("EXP08_TRAIN_SEEDS", "0,1,2,3,4")
    scenarios_text = os.getenv("EXP08_TRAIN_SCENARIOS", "simple,complex")
    scenarios = [item.strip() for item in scenarios_text.split(",") if item.strip()]
    return BaselineTrainConfig(
        method=method,
        scenarios=scenarios,
        seeds=[int(item.strip()) for item in seed_text.split(",") if item.strip()],
        episodes_simple=int(os.getenv("EXP08_TRAIN_EPISODES_SIMPLE", "1000")),
        episodes_complex=int(os.getenv("EXP08_TRAIN_EPISODES_COMPLEX", "1500")),
        max_steps_simple=int(os.getenv("EXP08_TRAIN_MAX_STEPS_SIMPLE", "24")),
        max_steps_complex=int(os.getenv("EXP08_TRAIN_MAX_STEPS_COMPLEX", "32")),
        eval_every=int(os.getenv("EXP08_TRAIN_EVAL_EVERY", "100")),
        eval_episodes=int(os.getenv("EXP08_TRAIN_EVAL_EPISODES", "8")),
        output_tag=os.getenv("EXP08_OUTPUT_TAG", "latest"),
    )
