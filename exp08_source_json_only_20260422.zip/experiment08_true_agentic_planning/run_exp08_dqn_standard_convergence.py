from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiment08_true_agentic_planning.baseline_training import config_from_env, train_baseline_suite


def main() -> None:
    result = train_baseline_suite(config_from_env("dqn"))
    print(result["manifest_path"])


if __name__ == "__main__":
    main()
