from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("paper_figures_gpt/experiment08_true_agentic_planning")
OUT_DIR = ROOT / "paper_selected_baselines_v42"
METHODS = ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]
METHOD_COLORS = {
    "exp08_agentic": "#0b6e4f",
    "plain_llm": "#c06c00",
    "dqn": "#355c7d",
    "gnnddqn": "#6c5b7b",
}
METHOD_LABELS = {
    "exp08_agentic": "Agentic",
    "plain_llm": "Plain LLM",
    "dqn": "DQN",
    "gnnddqn": "GNN-DDQN",
}


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _mean_std(curves: List[List[float]]) -> Tuple[List[float], List[float]]:
    arr = np.array(curves, dtype=float)
    return arr.mean(axis=0).tolist(), arr.std(axis=0).tolist()


def _collect_noshock_curves(chunk_tags: List[str]) -> Dict[str, List[List[float]]]:
    agg = {method: [] for method in METHODS}
    for tag in chunk_tags:
        cache_path = ROOT / f"exp08_fig2_dual_trajectory_{tag}_cache.json"
        payload = _load_json(cache_path)
        modes = payload.get("modes", {}).get("no_shock", {})
        for method in METHODS:
            agg[method].extend([[float(x) for x in row] for row in modes.get(method, [])])
    return agg


def main() -> None:
    output_tag = os.getenv("EXP08_FIG2_MIXED_TAG", "paper_fig2_noshock_shock8_gap_r1")
    visible_start = int(os.getenv("EXP08_FIG2_VISIBLE_START", "8"))
    chunk_tags = [
        tag.strip()
        for tag in os.getenv(
            "EXP08_FIG2_NOSHOCK_CHUNK_TAGS",
            "paper_fig2_r1_o000_l008,paper_fig2_r1_o008_l008,paper_fig2_r1_o016_l008,paper_fig2_r1_o024_l008",
        ).split(",")
        if tag.strip()
    ]
    old_shock_cache = Path(
        os.getenv(
            "EXP08_FIG2_OLD_SHOCK_CACHE",
            str(OUT_DIR / "exp08_complex_shock_trajectory_selected_v42_cache.json"),
        )
    )
    old_shock_source = Path(
        os.getenv(
            "EXP08_FIG2_OLD_SHOCK_SOURCE",
            str(ROOT / "exp08_shock_recovery_paper_complex_shock_v42.json"),
        )
    )

    no_shock_curves = _collect_noshock_curves(chunk_tags)
    old_shock_payload = _load_json(old_shock_cache)
    old_shock_curves = {
        method: [[float(x) for x in row] for row in old_shock_payload.get("agg", {}).get(method, [])]
        for method in METHODS
    }
    shock_source = _load_json(old_shock_source)
    shock_step = int(shock_source["cases"][0]["shock_profile"]["step"])
    max_steps = int(shock_source["config"]["max_steps"]["complex"])

    num_cases = len(no_shock_curves["exp08_agentic"])
    if num_cases <= 0:
        raise SystemExit("No no-shock curves found.")
    for method in METHODS:
        if len(no_shock_curves[method]) != len(old_shock_curves[method]):
            raise SystemExit(f"Case-count mismatch for {method}: no_shock={len(no_shock_curves[method])}, shock={len(old_shock_curves[method])}")

    payload: Dict[str, Any] = {
        "tag": output_tag,
        "num_cases": num_cases,
        "max_steps": max_steps,
        "shock_step": shock_step,
        "modes": {},
        "gap_to_noshock": {"methods": {}},
    }

    min_y = 1.0
    max_y = 0.0
    for mode_name, curves_by_method in [
        ("no_shock", no_shock_curves),
        ("shock_step8", old_shock_curves),
    ]:
        payload["modes"][mode_name] = {"methods": {}}
        for method in METHODS:
            mean_curve, std_curve = _mean_std(curves_by_method[method])
            payload["modes"][mode_name]["methods"][method] = {
                "num_cases": len(curves_by_method[method]),
                "mean_curve": mean_curve,
                "std_curve": std_curve,
                "mean_raafu": float(np.mean(mean_curve)),
            }
            method_min = min(max(0.0, x - s) for x, s in zip(mean_curve, std_curve))
            method_max = max(min(1.0, x + s) for x, s in zip(mean_curve, std_curve))
            min_y = min(min_y, method_min)
            max_y = max(max_y, method_max)

    gap_min = 0.0
    gap_max = 0.0
    for method in METHODS:
        gap_curves = np.array(old_shock_curves[method], dtype=float) - np.array(no_shock_curves[method], dtype=float)
        mean_gap, std_gap = _mean_std(gap_curves.tolist())
        payload["gap_to_noshock"]["methods"][method] = {
            "num_cases": int(gap_curves.shape[0]),
            "mean_curve": mean_gap,
            "std_curve": std_gap,
            "mean_gap": float(np.mean(mean_gap)),
            "min_gap": float(np.min(mean_gap)),
            "max_gap": float(np.max(mean_gap)),
        }
        gap_min = min(gap_min, min(x - s for x, s in zip(mean_gap, std_gap)))
        gap_max = max(gap_max, max(x + s for x, s in zip(mean_gap, std_gap)))

    out_json = ROOT / f"exp08_fig2_noshock_shock8_gap_{output_tag}.json"
    out_json.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    xs = np.arange(max_steps)
    fig, axes = plt.subplots(2, 1, figsize=(8.8, 7.2), sharex=True)
    lower = max(0.0, min_y - 0.02)
    upper = min(1.0, max_y + 0.03)
    for ax, mode_name, title in [
        (axes[0], "no_shock", "(a) Complex mean trajectory without shock"),
        (axes[1], "shock_step8", "(b) Complex mean trajectory with shock injected at step 8"),
    ]:
        mode_payload = payload["modes"][mode_name]["methods"]
        for method in METHODS:
            mean_curve = np.array(mode_payload[method]["mean_curve"], dtype=float)
            std_curve = np.array(mode_payload[method]["std_curve"], dtype=float)
            ax.plot(xs, mean_curve, linewidth=2.0, label=METHOD_LABELS[method], color=METHOD_COLORS[method])
            ax.fill_between(
                xs,
                np.maximum(0.0, mean_curve - std_curve),
                np.minimum(1.0, mean_curve + std_curve),
                color=METHOD_COLORS[method],
                alpha=0.12,
            )
        if mode_name == "shock_step8":
            ax.axvline(shock_step, linestyle="--", color="black", alpha=0.65, linewidth=1.2, label="Shock onset")
        ax.set_ylabel("Mean RAAFU")
        ax.set_ylim(lower, upper)
        ax.set_xlim(max(-0.5, visible_start - 0.5), max_steps - 0.5)
        ax.set_xticks(np.arange(max(visible_start, 0), max_steps, 2))
        ax.set_title(title)
        ax.grid(alpha=0.25, linestyle=":")
    axes[0].legend(frameon=False, ncol=2, loc="lower left")
    axes[1].set_xlabel("Decision step")
    fig.tight_layout()
    out_png_main = OUT_DIR / "fig02_complex_noshock_shock8_r1.png"
    fig.savefig(out_png_main, dpi=220, bbox_inches="tight")
    plt.close(fig)

    fig_gap, ax_gap = plt.subplots(figsize=(8.8, 4.3))
    for method in METHODS:
        mean_gap = np.array(payload["gap_to_noshock"]["methods"][method]["mean_curve"], dtype=float)
        std_gap = np.array(payload["gap_to_noshock"]["methods"][method]["std_curve"], dtype=float)
        ax_gap.plot(xs, mean_gap, linewidth=2.0, label=METHOD_LABELS[method], color=METHOD_COLORS[method])
        ax_gap.fill_between(
            xs,
            mean_gap - std_gap,
            mean_gap + std_gap,
            color=METHOD_COLORS[method],
            alpha=0.12,
        )
    ax_gap.axhline(0.0, linestyle=":", color="black", alpha=0.65, linewidth=1.1)
    ax_gap.axvline(shock_step, linestyle="--", color="black", alpha=0.65, linewidth=1.2, label="Shock onset")
    ax_gap.set_title("Gap Relative to the No-Shock Trajectory")
    ax_gap.set_xlabel("Decision step")
    ax_gap.set_ylabel("Shock@8 minus no-shock")
    ax_gap.set_xlim(-0.5, max_steps - 0.5)
    ax_gap.set_ylim(gap_min - 0.01, gap_max + 0.01)
    ax_gap.grid(alpha=0.25, linestyle=":")
    ax_gap.legend(frameon=False, ncol=3, loc="lower left")
    fig_gap.tight_layout()
    out_png_gap = OUT_DIR / "fig02b_complex_gap_r1.png"
    fig_gap.savefig(out_png_gap, dpi=220, bbox_inches="tight")
    plt.close(fig_gap)

    print(str(out_json).replace("\\", "/"))
    print(str(out_png_main).replace("\\", "/"))
    print(str(out_png_gap).replace("\\", "/"))


if __name__ == "__main__":
    main()
