from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("paper_figures_gpt/experiment08_true_agentic_planning")
OUT_DIR = ROOT / "paper_selected_baselines_v42"
METHODS = ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]
METHOD_COLORS = {
    "exp08_agentic": "#0b6e4f",
    "plain_llm": "#c06c00",
    "dqn": "#355c7d",
    "gnnddqn": "#6c5b7b",
}
METHOD_LABELS = {
    "exp08_agentic": "Agentic",
    "plain_llm": "Plain LLM",
    "dqn": "DQN",
    "gnnddqn": "GNN-DDQN",
}


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _combine_series(groups: List[Dict[str, Any]]) -> Dict[str, Any]:
    count = int(sum(int(group.get("num_cases", 0)) for group in groups))
    if count <= 0:
        raise ValueError("No cases found while merging Fig.2 chunks.")
    means = np.array([group["mean_curve"] for group in groups], dtype=float)
    stds = np.array([group["std_curve"] for group in groups], dtype=float)
    weights = np.array([int(group.get("num_cases", 0)) for group in groups], dtype=float)
    weighted_mean = (means.T * weights).T.sum(axis=0) / count
    second_moment = (((stds ** 2) + (means ** 2)).T * weights).T.sum(axis=0) / count
    variance = np.maximum(0.0, second_moment - (weighted_mean ** 2))
    return {
        "num_cases": count,
        "mean_curve": weighted_mean.tolist(),
        "std_curve": np.sqrt(variance).tolist(),
        "mean_raafu": float(np.mean(weighted_mean)),
    }


def main() -> None:
    source_tags = [tag.strip() for tag in os.getenv("EXP08_FIG2_CHUNK_TAGS", "").split(",") if tag.strip()]
    output_tag = os.getenv("EXP08_FIG2_MERGED_TAG", "paper_fig2_dualtraj_r1")
    if not source_tags:
        raise SystemExit("EXP08_FIG2_CHUNK_TAGS is required.")

    sources = [_load_json(ROOT / f"exp08_fig2_dual_trajectory_{tag}.json") for tag in source_tags]
    max_steps = int(sources[0]["max_steps"])
    payload: Dict[str, Any] = {
        "tag": output_tag,
        "source_tags": source_tags,
        "num_cases": int(sum(int(source.get("num_cases", 0)) for source in sources)),
        "max_steps": max_steps,
        "modes": {},
    }

    min_y = 1.0
    max_y = 0.0
    for mode_name in ["no_shock", "shock_step0"]:
        payload["modes"][mode_name] = {
            "shock_step": None if mode_name == "no_shock" else 0,
            "methods": {},
        }
        for method in METHODS:
            groups = [source["modes"][mode_name]["methods"][method] for source in sources]
            merged = _combine_series(groups)
            payload["modes"][mode_name]["methods"][method] = merged
            method_min = min(max(0.0, x - s) for x, s in zip(merged["mean_curve"], merged["std_curve"]))
            method_max = max(min(1.0, x + s) for x, s in zip(merged["mean_curve"], merged["std_curve"]))
            min_y = min(min_y, method_min)
            max_y = max(max_y, method_max)

    out_json = ROOT / f"exp08_fig2_dual_trajectory_{output_tag}.json"
    out_json.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    xs = np.arange(max_steps)
    fig, axes = plt.subplots(2, 1, figsize=(8.8, 7.2), sharex=True)
    mode_specs = [
        ("no_shock", "(a) Complex mean trajectory without shock"),
        ("shock_step0", "(b) Complex mean trajectory with shock injected at step 0"),
    ]
    lower = max(0.0, min_y - 0.02)
    upper = min(1.0, max_y + 0.03)
    if upper <= lower:
        lower, upper = 0.45, 0.80

    for ax, (mode_name, title) in zip(axes, mode_specs):
        mode_payload = payload["modes"][mode_name]["methods"]
        for method in METHODS:
            mean_curve = np.array(mode_payload[method]["mean_curve"], dtype=float)
            std_curve = np.array(mode_payload[method]["std_curve"], dtype=float)
            ax.plot(xs, mean_curve, linewidth=2.0, label=METHOD_LABELS[method], color=METHOD_COLORS[method])
            ax.fill_between(
                xs,
                np.maximum(0.0, mean_curve - std_curve),
                np.minimum(1.0, mean_curve + std_curve),
                color=METHOD_COLORS[method],
                alpha=0.12,
            )
        if mode_name == "shock_step0":
            ax.axvline(0, linestyle="--", color="black", alpha=0.65, linewidth=1.2, label="Shock onset")
        ax.set_ylabel("Mean RAAFU")
        ax.set_ylim(lower, upper)
        ax.set_xlim(-0.5, max_steps - 0.5)
        ax.set_title(title)
        ax.grid(alpha=0.25, linestyle=":")

    axes[0].legend(frameon=False, ncol=2, loc="lower left")
    axes[1].set_xlabel("Decision step")
    fig.tight_layout()
    out_png = OUT_DIR / f"fig02_complex_dual_trajectory_{output_tag}.png"
    fig.savefig(out_png, dpi=220, bbox_inches="tight")
    plt.close(fig)

    print(str(out_json).replace("\\", "/"))
    print(str(out_png).replace("\\", "/"))


if __name__ == "__main__":
    main()
