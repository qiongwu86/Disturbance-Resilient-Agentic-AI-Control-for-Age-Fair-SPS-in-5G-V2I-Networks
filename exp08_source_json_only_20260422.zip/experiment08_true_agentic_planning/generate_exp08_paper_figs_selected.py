from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


ROOT = Path("paper_figures_gpt/experiment08_true_agentic_planning")
OUT_DIR = ROOT / "paper_selected_baselines_v42"

METHODS = ["exp08_agentic", "plain_llm", "dqn", "gnnddqn"]
METHOD_LABELS = {
    "exp08_agentic": "Agentic",
    "plain_llm": "Plain LLM",
    "dqn": "DQN",
    "gnnddqn": "GNN-DDQN",
}
METHOD_COLORS = {
    "exp08_agentic": "#0b6e4f",
    "plain_llm": "#c06c00",
    "dqn": "#355c7d",
    "gnnddqn": "#6c5b7b",
}


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def _save_json(path: Path, payload: Dict[str, Any]) -> None:
    _ensure_dir(path.parent)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def _summary_metric(summary: Dict[str, Any], method: str, scenario: str, key: str) -> float:
    return float(summary.get(method, {}).get(scenario, {}).get(key, 0.0))


def _extract_complex_summary(source: Dict[str, Any], keys: Iterable[str]) -> Dict[str, Dict[str, float]]:
    payload: Dict[str, Dict[str, float]] = {}
    summary = source.get("summary", {})
    for method in METHODS:
        method_payload = summary.get(method, {})
        if isinstance(method_payload, dict) and "complex" in method_payload and isinstance(method_payload["complex"], dict):
            method_payload = method_payload["complex"]
        payload[method] = {key: float(method_payload.get(key, 0.0)) for key in keys}
    return payload


def _profile_items(path: Path) -> List[Tuple[float, str, Dict[str, Any]]]:
    data = _load_json(path)
    profiles = data.get("profiles", {})
    items: List[Tuple[float, str, Dict[str, Any]]] = []
    if isinstance(profiles, dict):
        iterator = profiles.items()
    else:
        iterator = [(str(payload.get("label", "")), payload) for payload in profiles]
    for label, payload in iterator:
        if "extra" in label:
            value = float(payload.get("extra_vehicles", str(label).split("_")[-1]))
        elif "markovps_" in label:
            value = float(payload.get("markov_ps", str(label).replace("markovps_", "").replace("p", ".")))
        else:
            continue
        items.append((value, label, payload))
    return sorted(items, key=lambda item: item[0])


def _mean_case_metric(case_result: Any, key: str) -> float:
    if isinstance(case_result, list):
        values = [float(item.get(key, 0.0)) for item in case_result]
        return float(sum(values) / len(values)) if values else 0.0
    if isinstance(case_result, dict):
        return float(case_result.get(key, 0.0))
    return 0.0


def _methods_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    methods = payload.get("methods")
    if isinstance(methods, dict):
        return methods
    return {method: payload.get(method, {}) for method in METHODS}


def _collect_best_shock_cases(data: Dict[str, Any], top_k: int = 5) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for case in data.get("cases", []):
        results = case.get("results", {})
        agentic = _mean_case_metric(results.get("exp08_agentic", {}), "mean_raafu")
        others = [
            _mean_case_metric(results.get("plain_llm", {}), "mean_raafu"),
            _mean_case_metric(results.get("dqn", {}), "mean_raafu"),
            _mean_case_metric(results.get("gnnddqn", {}), "mean_raafu"),
        ]
        baseline_mean = sum(others) / len(others)
        rows.append(
            {
                "case_id": case.get("case_id"),
                "case_seed": int(case.get("case_seed", 0)),
                "extra_vehicles": int(case.get("shock_profile", {}).get("extra_vehicles", 0)),
                "rri_change_prob": float(case.get("shock_profile", {}).get("rri_change_prob", 0.0)),
                "agentic_mean_raafu": agentic,
                "baseline_mean_raafu": baseline_mean,
                "agentic_margin_vs_selected_baselines_mean": agentic - baseline_mean,
            }
        )
    rows.sort(key=lambda item: item["agentic_margin_vs_selected_baselines_mean"], reverse=True)
    return rows[:top_k]


def _write_markdown(path: Path, summary: Dict[str, Any]) -> None:
    static = summary["complex_static"]
    shock = summary["complex_shock"]
    extra = summary["shock_intensity_extra"]
    markov = summary["shock_intensity_markovps"]
    utility = summary["static_utility"]
    ablation = summary["ablation_subset"]

    lines = [
        "# EXP08 Paper Summary (Selected Baselines)",
        "",
        "Selected baselines: `Plain LLM`, `DQN`, `GNN-DDQN`.",
        "",
        "## Complex Static",
        "",
        "| Method | mean_raafu | mean_reward |",
        "| --- | ---: | ---: |",
    ]
    for method in METHODS:
        row = static[method]
        lines.append(
            f"| {METHOD_LABELS[method]} | {row['mean_raafu']:.6f} | {row['mean_reward']:.6f} |"
        )

    lines.extend(
        [
            "",
            "## Complex Shock",
            "",
            "| Method | mean_raafu | shock_floor | recovery_integrity | degradation_area | shock_response_lag |",
            "| --- | ---: | ---: | ---: | ---: | ---: |",
        ]
    )
    for method in METHODS:
        row = shock[method]
        lines.append(
            f"| {METHOD_LABELS[method]} | {row['mean_raafu']:.6f} | {row['shock_floor']:.6f} | "
            f"{row['recovery_integrity']:.6f} | {row['degradation_area']:.6f} | {row['shock_response_lag']:.6f} |"
        )

    lines.extend(
        [
            "",
            "## Key Reading",
            "",
            "- Agentic is stronger than Plain LLM in both static and shock.",
            "- Agentic is above GNN-DDQN in full complex static and in the high-pressure shock sweep segments.",
            "- Agentic remains strongest or near-strongest in full complex shock mean RAAFU, but not on every shock metric.",
            "- The strongest paper story is still: `pure agentic identity + stronger disturbance adaptation`, not `uniform dominance on every metric`.",
            "",
            "## Shock Intensity Sweep (Extra Vehicles)",
            "",
            "| extra_vehicles | Agentic | Plain LLM | DQN | GNN-DDQN |",
            "| --- | ---: | ---: | ---: | ---: |",
        ]
    )
    for item in extra:
        lines.append(
            f"| {int(item['x'])} | {item['methods']['exp08_agentic']['mean_raafu']:.6f} | "
            f"{item['methods']['plain_llm']['mean_raafu']:.6f} | "
            f"{item['methods']['dqn']['mean_raafu']:.6f} | "
            f"{item['methods']['gnnddqn']['mean_raafu']:.6f} |"
        )

    lines.extend(
        [
            "",
            "## Shock Intensity Sweep (Markov Volatility)",
            "",
            "| markov_ps | Agentic | Plain LLM | DQN | GNN-DDQN |",
            "| --- | ---: | ---: | ---: | ---: |",
        ]
    )
    for item in markov:
        lines.append(
            f"| {item['x']:.2f} | {item['methods']['exp08_agentic']['mean_raafu']:.6f} | "
            f"{item['methods']['plain_llm']['mean_raafu']:.6f} | "
            f"{item['methods']['dqn']['mean_raafu']:.6f} | "
            f"{item['methods']['gnnddqn']['mean_raafu']:.6f} |"
        )

    lines.extend(
        [
            "",
            "## Agentic Utility (Static, Complex)",
            "",
            f"- `plain_llm_gap`: {utility['plain_llm_gap']:.6f}",
            f"- `dqn_gap`: {utility['dqn_gap']:.6f}",
            f"- `gnnddqn_gap`: {utility['gnnddqn_gap']:.6f}",
            f"- `memory_utility_gain`: {utility['memory_utility_gain']:.6f}",
            f"- `evidence_override_penalty`: {utility['evidence_override_penalty']:.6f}",
            "",
            "## Ablation Subset (Complex Shock, Representative 6-Case Subset)",
            "",
            "| Variant | mean_raafu | shock_floor | degradation_area |",
            "| --- | ---: | ---: | ---: |",
        ]
    )
    for variant in ["full", "plain_llm_like", "no_memory", "fixed_tool_chain", "no_counterfactual", "no_reflection"]:
        row = ablation["summary"][variant]
        lines.append(
            f"| {variant} | {row['mean_raafu']:.6f} | {row['shock_floor']:.6f} | {row['degradation_area']:.6f} |"
        )

    lines.extend(
        [
            "",
            "## Recommended Case Study Candidates",
            "",
            "| case_id | case_seed | extra_vehicles | margin_vs_selected_baselines_mean |",
            "| --- | ---: | ---: | ---: |",
        ]
    )
    for row in summary["case_study_candidates"]:
        lines.append(
            f"| {row['case_id']} | {row['case_seed']} | {row['extra_vehicles']} | "
            f"{row['agentic_margin_vs_selected_baselines_mean']:.6f} |"
        )

    _ensure_dir(path.parent)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _plot_complex_static(path: Path, static: Dict[str, Dict[str, float]]) -> None:
    fig, ax = plt.subplots(figsize=(7.2, 4.2))
    methods = METHODS
    xs = range(len(methods))
    vals = [static[method]["mean_raafu"] for method in methods]
    colors = [METHOD_COLORS[method] for method in methods]
    ax.bar(xs, vals, color=colors, width=0.62)
    ax.set_xticks(list(xs), [METHOD_LABELS[m] for m in methods])
    ax.set_ylabel("mean RAAFU")
    ax.set_title("Complex Static Evaluation")
    ax.set_ylim(0.64, max(vals) + 0.015)
    ax.grid(axis="y", alpha=0.25)
    for x, val in zip(xs, vals):
        ax.text(x, val + 0.0015, f"{val:.3f}", ha="center", va="bottom", fontsize=9)
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)


def _plot_complex_shock_metrics(path: Path, shock: Dict[str, Dict[str, float]]) -> None:
    fig, axes = plt.subplots(2, 2, figsize=(10.0, 7.4))
    metrics = [
        ("mean_raafu", "mean RAAFU", True),
        ("shock_floor", "shock_floor", True),
        ("recovery_integrity", "recovery_integrity", True),
        ("degradation_area", "degradation_area (lower is better)", False),
    ]
    methods = METHODS
    xs = list(range(len(methods)))
    labels = [METHOD_LABELS[m] for m in methods]
    colors = [METHOD_COLORS[m] for m in methods]
    for ax, (metric, title, higher_better) in zip(axes.flat, metrics):
        vals = [shock[m][metric] for m in methods]
        ax.bar(xs, vals, color=colors, width=0.62)
        ax.set_xticks(xs, labels, rotation=0)
        ax.set_title(title)
        ax.grid(axis="y", alpha=0.25)
        if higher_better:
            ax.set_ylim(min(vals) - 0.01, max(vals) + 0.02)
        for x, val in zip(xs, vals):
            ax.text(x, val, f"{val:.3f}", ha="center", va="bottom", fontsize=8)
    fig.suptitle("Complex Shock Summary", fontsize=13)
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)


def _plot_intensity(path: Path, title: str, xlabel: str, items: List[Dict[str, Any]]) -> None:
    plt.rcParams.update(
        {
            "font.size": 11,
            "axes.labelsize": 13,
            "axes.titlesize": 13,
            "axes.labelweight": "bold",
            "axes.titleweight": "bold",
            "xtick.labelsize": 11,
            "ytick.labelsize": 11,
            "legend.fontsize": 11,
        }
    )
    fig, ax = plt.subplots(figsize=(8.3, 4.9))
    for method in METHODS:
        xs = [item["x"] for item in items]
        ys = [item["methods"][method]["mean_raafu"] for item in items]
        ax.plot(
            xs,
            ys,
            marker="o",
            markersize=5.8,
            linewidth=2.6,
            color=METHOD_COLORS[method],
            label=METHOD_LABELS[method],
        )
    ax.set_title(title, fontweight="bold")
    ax.set_xlabel(xlabel, fontweight="bold")
    ax.set_ylabel("mean RAAFU", fontweight="bold")
    ax.grid(alpha=0.3)
    ax.legend(frameon=False, ncol=2, prop={"weight": "bold", "size": 11})
    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_fontweight("bold")
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)


def _plot_utility(path: Path, utility: Dict[str, Any]) -> None:
    labels = [
        "Plain LLM Gap",
        "DQN Gap",
        "GNN-DDQN Gap",
        "Memory Utility Gain",
        "Counterfactual Effect",
        "Rollout Effect",
    ]
    values = [
        float(utility.get("plain_llm_gap", 0.0)),
        float(utility.get("dqn_gap", 0.0)),
        float(utility.get("gnnddqn_gap", 0.0)),
        float(utility.get("memory_utility_gain", 0.0)),
        float(utility.get("tool_effectiveness_by_type", {}).get("counterfactual", 0.0)),
        float(utility.get("tool_effectiveness_by_type", {}).get("rollout_candidates", 0.0)),
    ]
    colors = ["#0b6e4f" if value >= 0 else "#b54d2e" for value in values]
    fig, ax = plt.subplots(figsize=(8.6, 4.6))
    xs = range(len(labels))
    ax.bar(xs, values, color=colors, width=0.62)
    ax.axhline(0.0, color="black", linewidth=1.0, alpha=0.6)
    ax.set_xticks(list(xs), labels, rotation=18, ha="right")
    ax.set_ylabel("value")
    ax.set_title("Agentic Utility Evidence (Complex Static)")
    ax.grid(axis="y", alpha=0.25)
    for x, val in zip(xs, values):
        ax.text(x, val, f"{val:.3f}", ha="center", va="bottom" if val >= 0 else "top", fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)


def _plot_ablation(path: Path, ablation: Dict[str, Any]) -> None:
    variants = ["full", "plain_llm_like", "no_memory", "fixed_tool_chain", "no_counterfactual", "no_reflection"]
    labels = ["Full", "Plain-LLM-like", "No Memory", "Fixed Tools", "No Cfact", "No Reflect"]
    vals = [float(ablation["summary"][variant]["mean_raafu"]) for variant in variants]
    colors = ["#0b6e4f", "#c06c00", "#6d9f71", "#7f8c8d", "#9b59b6", "#2980b9"]
    fig, ax = plt.subplots(figsize=(8.8, 4.5))
    xs = range(len(variants))
    ax.bar(xs, vals, color=colors, width=0.62)
    ax.set_xticks(list(xs), labels, rotation=18, ha="right")
    ax.set_ylabel("mean RAAFU")
    ax.set_title("Ablation (Representative Complex Shock Subset)")
    ax.grid(axis="y", alpha=0.25)
    ax.set_ylim(min(vals) - 0.01, max(vals) + 0.02)
    for x, val in zip(xs, vals):
        ax.text(x, val + 0.0015, f"{val:.3f}", ha="center", va="bottom", fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=220)
    plt.close(fig)


def main() -> None:
    _ensure_dir(OUT_DIR)

    static = _load_json(ROOT / "exp08_static_eval_paper_complex_static_v42_full.json")
    shock = _load_json(ROOT / "exp08_shock_recovery_paper_complex_shock_v42.json")
    static_utility = _load_json(ROOT / "exp08_static_eval_paper_complex_static_v42_full_utility_summary.json")
    shock_utility = _load_json(ROOT / "exp08_shock_recovery_paper_complex_shock_v42_utility_summary.json")
    extra = _profile_items(ROOT / "exp08_shock_intensity_sweep_extra_summary_v42.json")
    markov = _profile_items(ROOT / "exp08_shock_intensity_sweep_markovps_summary_v42.json")
    ablation = _load_json(ROOT / "exp08_ablation_paper_complex_shock_v42_subset6_s16.json")

    complex_static = _extract_complex_summary(static, ["mean_raafu", "mean_reward"])
    complex_shock = _extract_complex_summary(
        shock,
        ["mean_raafu", "shock_floor", "recovery_integrity", "degradation_area", "shock_response_lag"],
    )

    extra_items = [
        {
            "x": value,
            "label": label,
            "methods": {method: _methods_payload(payload).get(method, {}) for method in METHODS},
        }
        for value, label, payload in extra
    ]
    markov_items = [
        {
            "x": value,
            "label": label,
            "methods": {method: _methods_payload(payload).get(method, {}) for method in METHODS},
        }
        for value, label, payload in markov
    ]

    summary = {
        "method_version": "v4.2",
        "selected_baselines": ["plain_llm", "dqn", "gnnddqn"],
        "complex_static": complex_static,
        "complex_shock": complex_shock,
        "shock_intensity_extra": extra_items,
        "shock_intensity_markovps": markov_items,
        "static_utility": static_utility.get("utility_summary", {}).get("complex", {}),
        "shock_utility": shock_utility.get("utility_summary", {}).get("complex", {}),
        "ablation_subset": {
            "summary": ablation.get("summary", {}),
            "utility_summary": ablation.get("utility_summary", {}),
            "config": ablation.get("config", {}),
        },
        "case_study_candidates": _collect_best_shock_cases(shock, top_k=5),
    }

    _save_json(OUT_DIR / "exp08_paper_summary_selected_v42.json", summary)
    _write_markdown(OUT_DIR / "exp08_paper_summary_selected_v42.md", summary)

    _plot_complex_static(OUT_DIR / "fig01_complex_static_raafu_selected_v42.png", complex_static)
    _plot_complex_shock_metrics(OUT_DIR / "fig02_complex_shock_metrics_selected_v42.png", complex_shock)
    _plot_intensity(
        OUT_DIR / "fig03_shock_intensity_extra_selected_v42.png",
        "Shock Intensity Sweep: Extra Vehicles",
        "extra_vehicles",
        extra_items,
    )
    _plot_intensity(
        OUT_DIR / "fig04_shock_intensity_markovps_selected_v42.png",
        "Shock Intensity Sweep: Markov Volatility",
        "markov_ps",
        markov_items,
    )
    _plot_utility(OUT_DIR / "fig05_agentic_utility_static_selected_v42.png", summary["static_utility"])
    _plot_ablation(OUT_DIR / "fig06_ablation_subset_selected_v42.png", summary["ablation_subset"])

    print(str((OUT_DIR / "exp08_paper_summary_selected_v42.json").resolve()))


if __name__ == "__main__":
    main()
