from __future__ import annotations

from typing import Any, Dict, List

from .common import build_metrics


class ToolRegistry:
    def __init__(self, system: "PlannerLedAgenticSystem") -> None:
        self.system = system

    def run(self, tool_names: List[str], draft_plan, memory_records: List[Dict[str, Any]]) -> Dict[str, Any]:
        outputs: Dict[str, Any] = {}
        for tool_name in tool_names[: self.system.config.max_tools_per_step]:
            if tool_name == "state_digest":
                outputs[tool_name] = self._state_digest()
            elif tool_name == "memory_query":
                outputs[tool_name] = {"records": memory_records}
            elif tool_name == "rollout_candidates":
                outputs[tool_name] = self._rollout_candidates(draft_plan)
            elif tool_name == "counterfactual":
                outputs[tool_name] = self._counterfactual(draft_plan)
            elif tool_name == "constraint_check":
                outputs[tool_name] = self._constraint_check(draft_plan)
        return outputs

    def _state_digest(self) -> Dict[str, Any]:
        state = self.system.current_state
        metrics = self.system.current_metrics
        return {
            "n_v": int(state.get("N_v", self.system.env.N_v)),
            "rri": int(state.get("RRI", 100)),
            "paoi": float(state.get("PAoI", 0.0)),
            "collision_prob": float(state.get("P_coll", 0.0)),
            "fairness_index": float(metrics.get("fairness_index", 0.0)),
            "raafu": float(metrics.get("raafu", 0.0)),
        }

    def _rollout_candidates(self, draft_plan) -> Dict[str, Any]:
        candidates = []
        current_rri = int(self.system.current_state.get("RRI", self.system.env.R_set[0]))
        for rri in draft_plan.candidate_rris:
            temp_state = self.system.env.calculate_system_state(
                float(rri),
                int(self.system.current_state.get("N_v", self.system.env.N_v)),
            )
            temp_metrics = build_metrics(self.system.env, temp_state)
            score = self.system.score_metrics(temp_metrics, self.system.current_metrics)
            candidates.append(
                {
                    "rri": int(rri),
                    "score": float(score),
                    "collision_prob": float(temp_state.get("P_coll", 0.0)),
                    "fairness_index": float(temp_metrics.get("fairness_index", 0.0)),
                    "raafu": float(temp_metrics.get("raafu", 0.0)),
                    "delta_vs_current": float(
                        score - self.system.score_metrics(self.system.current_metrics, self.system.previous_metrics)
                    ),
                }
            )
        candidates.sort(key=lambda item: item["score"], reverse=True)
        return {
            "current_rri": current_rri,
            "best_candidate": candidates[0] if candidates else None,
            "candidates": candidates,
        }

    def _counterfactual(self, draft_plan) -> Dict[str, Any]:
        current_score = self.system.score_metrics(self.system.current_metrics, self.system.previous_metrics)
        alt_scores = []
        for rri in draft_plan.candidate_rris:
            temp_state = self.system.env.calculate_system_state(
                float(rri),
                int(self.system.current_state.get("N_v", self.system.env.N_v)),
            )
            temp_metrics = build_metrics(self.system.env, temp_state)
            alt_scores.append((int(rri), float(self.system.score_metrics(temp_metrics, self.system.current_metrics))))
        alt_scores.sort(key=lambda item: item[1], reverse=True)
        best_rri, best_score = alt_scores[0] if alt_scores else (
            int(self.system.current_state.get("RRI", 100)),
            current_score,
        )
        return {
            "current_score": float(current_score),
            "best_counterfactual_rri": int(best_rri),
            "best_counterfactual_score": float(best_score),
            "counterfactual_gain": float(best_score - current_score),
        }

    def _constraint_check(self, draft_plan) -> Dict[str, Any]:
        safe = []
        unsafe = []
        risk_threshold = float(self.system.config.safety_collision_threshold)
        for rri in draft_plan.candidate_rris:
            temp_state = self.system.env.calculate_system_state(
                float(rri),
                int(self.system.current_state.get("N_v", self.system.env.N_v)),
            )
            record = {
                "rri": int(rri),
                "collision_prob": float(temp_state.get("P_coll", 0.0)),
                "allowed": bool(float(temp_state.get("P_coll", 0.0)) <= risk_threshold),
            }
            if record["allowed"]:
                safe.append(record)
            else:
                unsafe.append(record)
        return {"safe_candidates": safe, "unsafe_candidates": unsafe, "risk_threshold": risk_threshold}
