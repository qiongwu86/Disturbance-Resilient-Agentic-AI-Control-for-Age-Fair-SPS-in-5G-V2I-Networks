from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiment08_true_agentic_planning.formal_utils import PROTOCOL_VERSION, formal_payload, save_json


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _chunk_paths(experiment_type: str, tag: str) -> List[Path]:
    root = Path("paper_figures_gpt/experiment08_true_agentic_planning")
    prefix = "exp08_static_eval" if experiment_type == "static_eval" else "exp08_shock_recovery"
    return sorted(root.glob(f"{prefix}_{tag}__*.json"))


def _merge_config(chunks: List[Dict[str, Any]]) -> Dict[str, Any]:
    first = dict(chunks[0].get("config", {}))
    first["merged_from_chunks"] = len(chunks)
    ranges: List[Dict[str, Any]] = []
    for chunk in chunks:
        cfg = chunk.get("config", {})
        ranges.append(
            {
                "tag": chunk.get("tag"),
                "scenarios": cfg.get("scenarios", []),
                "case_offsets": cfg.get("case_offsets", {}),
                "case_limits": cfg.get("case_limits", {}),
            }
        )
    first["chunk_ranges"] = ranges
    return first


def main() -> None:
    parser = argparse.ArgumentParser(description="Merge sharded EXP08 formal eval outputs.")
    parser.add_argument("--experiment-type", choices=["static_eval", "shock_recovery"], required=True)
    parser.add_argument("--tag", required=True, help="Base output tag without the chunk suffix.")
    args = parser.parse_args()

    chunk_paths = _chunk_paths(args.experiment_type, args.tag)
    if not chunk_paths:
        raise SystemExit(f"No chunk files found for {args.experiment_type} tag={args.tag}")

    chunks = [_load_json(path) for path in chunk_paths]
    for payload in chunks:
        if payload.get("protocol_version") != PROTOCOL_VERSION:
            raise SystemExit(f"Protocol mismatch in {payload.get('tag')}")
        if payload.get("experiment_type") != args.experiment_type:
            raise SystemExit(f"Experiment type mismatch in {payload.get('tag')}")

    cases: List[Dict[str, Any]] = []
    seen_ids = set()
    for path, payload in zip(chunk_paths, chunks):
        for case in payload.get("cases", []):
            case_id = str(case.get("case_id"))
            if case_id in seen_ids:
                raise SystemExit(f"Duplicate case_id {case_id} while merging {path.name}")
            seen_ids.add(case_id)
            cases.append(case)

    def _case_sort_key(case: Dict[str, Any]) -> tuple:
        scenario = str(case.get("scenario", ""))
        case_id = str(case.get("case_id", ""))
        return scenario, case_id

    cases.sort(key=_case_sort_key)
    merged = formal_payload(
        args.experiment_type,
        args.tag,
        _merge_config(chunks),
        cases,
    )
    prefix = "exp08_static_eval" if args.experiment_type == "static_eval" else "exp08_shock_recovery"
    output_path = Path("paper_figures_gpt/experiment08_true_agentic_planning") / f"{prefix}_{args.tag}.json"
    save_json(output_path, merged)
    print(str(output_path).replace("\\", "/"))


if __name__ == "__main__":
    main()
