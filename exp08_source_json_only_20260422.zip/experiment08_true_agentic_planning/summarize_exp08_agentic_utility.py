from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiment08_true_agentic_planning.formal_utils import save_json


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _mean(values: List[float]) -> float:
    if not values:
        return 0.0
    return float(sum(values) / len(values))


def _extract_method_mean(case: Dict[str, Any], method_name: str, key: str) -> float:
    payload = case["results"][method_name]
    if isinstance(payload, list):
        return float(sum(float(item.get(key, 0.0)) for item in payload) / max(1, len(payload)))
    return float(payload.get(key, 0.0))


def summarize_agentic_utility(payload: Dict[str, Any]) -> Dict[str, Any]:
    scenarios = sorted({str(case.get("scenario", "unknown")) for case in payload.get("cases", [])})
    summary: Dict[str, Any] = {}
    for scenario in scenarios:
        scenario_cases = [case for case in payload.get("cases", []) if str(case.get("scenario")) == scenario]
        utility_rows = [case["results"]["exp08_agentic"].get("utility_stats", {}) for case in scenario_cases]
        if not utility_rows:
            continue

        tool_names = ["memory_query", "rollout_candidates", "counterfactual", "constraint_check", "state_digest"]
        scenario_summary = {
            "memory_utility_gain": _mean([float(row.get("memory_utility_gain", 0.0)) for row in utility_rows]),
            "replan_success_gain": _mean([float(row.get("replan_success_gain", 0.0)) for row in utility_rows]),
            "evidence_override_penalty": _mean([float(row.get("evidence_override_penalty", 0.0)) for row in utility_rows]),
            "reflection_guidance_gain": _mean([float(row.get("reflection_guidance_gain", 0.0)) for row in utility_rows]),
            "avg_step_reward": _mean([float(row.get("avg_step_reward", 0.0)) for row in utility_rows]),
            "tool_effectiveness_by_type": {
                tool_name: _mean(
                    [
                        float(row.get("tool_effectiveness_by_type", {}).get(tool_name, 0.0))
                        for row in utility_rows
                    ]
                )
                for tool_name in tool_names
            },
            "plain_llm_gap": _mean(
                [
                    _extract_method_mean(case, "exp08_agentic", "mean_raafu")
                    - _extract_method_mean(case, "plain_llm", "mean_raafu")
                    for case in scenario_cases
                ]
            ),
            "dqn_gap": _mean(
                [
                    _extract_method_mean(case, "exp08_agentic", "mean_raafu")
                    - _extract_method_mean(case, "dqn", "mean_raafu")
                    for case in scenario_cases
                ]
            ),
            "dqn_strong_gap": _mean(
                [
                    _extract_method_mean(case, "exp08_agentic", "mean_raafu")
                    - _extract_method_mean(case, "dqn_strong", "mean_raafu")
                    for case in scenario_cases
                ]
            ),
            "gnnddqn_gap": _mean(
                [
                    _extract_method_mean(case, "exp08_agentic", "mean_raafu")
                    - _extract_method_mean(case, "gnnddqn", "mean_raafu")
                    for case in scenario_cases
                ]
            ),
            "num_cases": len(scenario_cases),
        }
        summary[scenario] = scenario_summary
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description="Summarize EXP08 agentic utility metrics from a formal eval output.")
    parser.add_argument("--input", required=True, help="Formal eval JSON path.")
    parser.add_argument("--output", default="", help="Optional output path.")
    args = parser.parse_args()

    input_path = Path(args.input)
    payload = _load_json(input_path)
    summary = summarize_agentic_utility(payload)
    output_path = Path(args.output) if args.output else input_path.with_name(input_path.stem + "_utility_summary.json")
    save_json(output_path, {"source": str(input_path).replace("\\", "/"), "utility_summary": summary})
    print(str(output_path).replace("\\", "/"))


if __name__ == "__main__":
    main()
