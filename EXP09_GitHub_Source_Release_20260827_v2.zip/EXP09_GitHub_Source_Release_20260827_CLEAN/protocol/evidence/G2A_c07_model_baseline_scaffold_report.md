# G2-A C07 Model and Baseline Correctness Report

REPORT_ID: g2a_c07_model_baseline

STATUS: C07_COMPLETE_G2A_PASSED

G2A_GATE_STATUS: PASSED

METHOD_EXECUTION_ALLOWED: false

- Scope: runner-independent, method-blind correctness evidence only. This report does not execute
  or compare a method and contains no performance, accuracy, robustness, deployment, or superiority
  result.
- Causal state: `ControllerStateEstimator` consumes only `ObservableFrame` and the public
  `ControlOpportunity`, binds source hash/cutoff/current RRI/integer counters/known user ages into an
  immutable `ControllerStateEstimate`, and rejects future observations.
- Independent model: `ApproximateSPSModel` lives outside `plant`, uses a separate integer transition
  implementation, and emits explicit per-millisecond age/collision-risk traces rather than a
  hash-only score. Package-boundary lint forbids model/control/baseline imports of plant or truth.
- Fixed physical horizon: the correctness fixture uses 3,000,000 us, derived method-blind from the
  LCM already recorded in the frozen static-capacity certificate. It covers all seven legal RRI
  periods. The 1,000 us step, 100,000 us packet period, and C=2 are existing frozen protocol facts.
- CRN and budget: KEEP plus seven RESELECT candidates reuse one immutable state and one ordered
  three-member forecast batch. Each member uses 3,000 transitions; the complete evidence consumes
  exactly `8 x 3 x 3000 = 72000` transitions. Exhaustion and conservation fail closed.
- Candidate sensitivity: each legal RRI is substituted into model state before rollout and produces
  a distinct attempted-transmission schedule and controlled-age trajectory, not merely a distinct
  summary hash; input state is unchanged.
- Baselines: KEEP sanity, adapted observable-only AoI heuristic, Greedy-1, and Nominal MPC now return
  evidence-bound implemented decisions. Greedy-1 scores first-attempt summaries; Nominal MPC scores
  full-horizon summaries. Both require a complete action-by-scenario CRN matrix.
- AoI disclosure: the local record contains the reviewer citation but not the full Rolich algorithm
  text. The implementation is therefore explicitly `adapted`, not represented as a literature
  reproduction. Formal literature/runner qualification remains a C12 requirement.
- Mismatch boundary: the frozen 0.8/1.0/1.2 ControllerModel-only load scales multiply the nominal
  model load. In the zero-busy correctness fixture they produce ordered collision-risk values of
  90,000/100,000/110,000 ppm. Forecast and mismatch validators reject semantic resealing;
  supporting-family execution is not authorized.
- Validator: `validate_c07_scaffold_bundle=PASS` verifies semantic fields and every bound SHA-256.
- Gate: G2-A closes C07 correctness only. The hard stop remains before formal C08; C08 constructed
  diagnostics are not promoted by this report.
