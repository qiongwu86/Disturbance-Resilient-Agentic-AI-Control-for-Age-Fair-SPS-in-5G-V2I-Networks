"""Generate the method-free AD-04A static logical-grid certificate."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from math import lcm
from typing import Any

SCHEMA_VERSION = "exp09-static-capacity-certificate-v1"


@dataclass(frozen=True, slots=True)
class FrozenInputs:
    packet_period_us: int = 100_000
    slot_duration_us: int = 1_000
    packet_footprint_slots: int = 1
    packet_footprint_logical_subchannels: int = 1
    pre_influx_population: int = 6
    post_influx_population: int = 9
    max_carry_in_pdus_per_vehicle: int = 2
    headroom_cap_numerator: int = 1
    headroom_cap_denominator: int = 2
    legal_rri_us: tuple[int, ...] = (
        20_000,
        50_000,
        100_000,
        200_000,
        300_000,
        500_000,
        1_000_000,
    )


def _attempt_bound(
    *,
    horizon_us: int,
    population: int,
    packet_period_us: int,
    max_carry_in_pdus_per_vehicle: int,
) -> int:
    # At most one waiting and one separately scheduled/in-flight PDU can cross
    # the left boundary; every later generation can produce at most one attempt.
    return population * (
        max_carry_in_pdus_per_vehicle + horizon_us // packet_period_us
    )


def build_certificate(inputs: FrozenInputs = FrozenInputs()) -> dict[str, Any]:
    if inputs.packet_period_us <= 0 or inputs.slot_duration_us <= 0:
        raise ValueError("time inputs must be positive")
    if any(rri <= 0 for rri in inputs.legal_rri_us):
        raise ValueError("legal RRIs must be positive")
    if inputs.headroom_cap_numerator <= 0 or inputs.headroom_cap_denominator <= 0:
        raise ValueError("headroom cap must be a positive rational")
    if inputs.headroom_cap_numerator > inputs.headroom_cap_denominator:
        raise ValueError("headroom cap must not exceed one")
    if inputs.packet_period_us % inputs.slot_duration_us:
        raise ValueError("packet period must align to the logical slot")
    if any(rri % inputs.slot_duration_us for rri in inputs.legal_rri_us):
        raise ValueError("every RRI must align to the logical slot")
    if inputs.packet_footprint_slots != 1 or inputs.packet_footprint_logical_subchannels != 1:
        raise ValueError("this certificate supports only the frozen 1x1 footprint")

    horizon_us = lcm(inputs.packet_period_us, *inputs.legal_rri_us)
    slots = horizon_us // inputs.slot_duration_us
    footprint_cells = (
        inputs.packet_footprint_slots * inputs.packet_footprint_logical_subchannels
    )

    demand_pre = _attempt_bound(
        horizon_us=horizon_us,
        population=inputs.pre_influx_population,
        packet_period_us=inputs.packet_period_us,
        max_carry_in_pdus_per_vehicle=inputs.max_carry_in_pdus_per_vehicle,
    ) * footprint_cells
    demand_post = _attempt_bound(
        horizon_us=horizon_us,
        population=inputs.post_influx_population,
        packet_period_us=inputs.packet_period_us,
        max_carry_in_pdus_per_vehicle=inputs.max_carry_in_pdus_per_vehicle,
    ) * footprint_cells
    demand_max = max(demand_pre, demand_post)

    minimum_by_headroom = 1
    while (
        demand_max * inputs.headroom_cap_denominator
        > slots * minimum_by_headroom * inputs.headroom_cap_numerator
    ):
        minimum_by_headroom += 1

    # C >= 2 is required to construct same-time/different-frequency and
    # frequency-only-overlap negative witnesses for a two-dimensional grid.
    minimum_by_witness = 2
    selected_c = max(minimum_by_headroom, minimum_by_witness)

    occupancy_numerator = demand_max
    occupancy_denominator = slots * selected_c
    headroom_pass = (
        occupancy_numerator * inputs.headroom_cap_denominator
        <= occupancy_denominator * inputs.headroom_cap_numerator
    )

    return {
        "schema_version": SCHEMA_VERSION,
        "derivation_kind": "METHOD_FREE_STATIC_UPPER_BOUND_AND_WITNESS_CERTIFICATE",
        "frozen_inputs": {
            **asdict(inputs),
            "legal_rri_us": list(inputs.legal_rri_us),
            "headroom_cap": "1/2",
        },
        "audit_horizon": {
            "definition": "lcm(packet_period_us, legal_rri_us)",
            "horizon_us": horizon_us,
            "logical_slots": slots,
        },
        "attempt_upper_bound": {
            "formula": (
                "population * (max_carry_in_pdus_per_vehicle + "
                "H // packet_period_us)"
            ),
            "left_boundary_inventory": ["one_waiting_PDU", "one_scheduled_or_inflight_PDU"],
            "retransmissions": 0,
            "pre_influx_cells": demand_pre,
            "post_influx_cells": demand_post,
            "selected_worst_case_cells": demand_max,
            "reservation_opportunity_bound_not_tighter_in_worst_case_reason": (
                "min legal RRI is shorter than packet period; packet availability "
                "therefore bounds terminal attempts under no retransmission"
            ),
        },
        "selection": {
            "minimum_c_by_headroom": minimum_by_headroom,
            "minimum_c_by_required_2d_witnesses": minimum_by_witness,
            "logical_subchannel_count": selected_c,
            "capacity_cells": occupancy_denominator,
            "occupancy_upper_bound_fraction": (
                f"{occupancy_numerator}/{occupancy_denominator}"
            ),
            "occupancy_upper_bound_decimal": (
                f"{occupancy_numerator / occupancy_denominator:.6f}"
            ),
            "headroom_cap": "0.5",
            "headroom_pass": headroom_pass,
        },
        "structural_requirement": {
            "logical_subchannel_domain": {
                "start_inclusive": 0,
                "stop_exclusive": selected_c,
            },
            "minimum_c_reason": (
                "the frozen two-dimensional logical-grid certificate requires a "
                "same-time/different-frequency non-collision witness"
            ),
            "selector_domain_status": "UNRESOLVED_OUTSIDE_CERTIFICATE_SCOPE",
        },
        "static_witnesses": {
            "legal_grant": {
                "tx": {"slot": 0, "subchannel": 0},
                "reachable": selected_c >= 1,
            },
            "safe_same_time_different_frequency": {
                "tx_a": {"slot": 0, "subchannel": 0},
                "tx_b": {"slot": 0, "subchannel": 1},
                "collision": False,
                "reachable": selected_c >= 2,
            },
            "safe_different_time_same_frequency": {
                "tx_a": {"slot": 0, "subchannel": 0},
                "tx_b": {"slot": 1, "subchannel": 0},
                "collision": False,
                "reachable": slots >= 2,
            },
            "collision_full_overlap": {
                "tx_a": {"slot": 0, "subchannel": 0},
                "tx_b": {"slot": 0, "subchannel": 0},
                "collision": True,
                "reachable": inputs.post_influx_population >= 2,
            },
        },
        "claim_boundary": {
            "establishes": [
                "integer_alignment",
                "conservative_aggregate_headroom",
                "static_cell_level_safe_and_collision_witness_reachability",
                "minimum_logical_subchannel_count_for_the_required_2d_witnesses",
            ],
            "does_not_establish": [
                "legal_grant_offset_domain",
                "selection_window_or_lead_time",
                "selector_candidate_reachability_or_empty_candidate_rule",
                "same_rri_grant_replacement_reachability",
                "dynamic_collision_frequency",
                "selector_candidate_empty_rate",
                "risk_gate_trigger_rate",
                "method_performance_or_ranking",
                "PHY_or_channel_realism",
                "deployment_feasibility",
            ],
            "reopen_rule": (
                "Only method-free static or C04/G1 mechanism evidence may reopen; "
                "method rankings and endpoint effects are forbidden inputs"
            ),
        },
    }


def canonical_bytes(value: dict[str, Any]) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=True,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def certificate_sha256(value: dict[str, Any]) -> str:
    return hashlib.sha256(canonical_bytes(value) + b"\n").hexdigest().upper()


if __name__ == "__main__":
    result = build_certificate()
    print(canonical_bytes(result).decode("ascii"))
    print(certificate_sha256(result))
