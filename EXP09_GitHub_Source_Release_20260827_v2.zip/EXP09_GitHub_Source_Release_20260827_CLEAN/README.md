# Disturbance-Resilient Agentic SPS Control

This repository contains the Python source code used to implement and evaluate the
disturbance-resilient, age-fair SPS controller described in the accompanying paper. The Full
controller combines a deterministic SPS model, candidate rollout, a risk gate, and an
event-triggered LLM supervisor. The deterministic path remains responsible for the final action
and fallback.

## Release scope

This is a **source-only release**. It contains:

- the simulator, controller, metrics, statistical procedures, RL baselines, and validation code
  under `src/exp09/`;
- the experiment and analysis entry points under `scripts/`;
- configuration and schema files required by the source under `protocol/`;
- tests that run without the original experimental outputs under `tests/`;
- locked Python dependency metadata.

The archive intentionally excludes the paper and LaTeX sources, PDFs, figures, experimental
outputs, raw traces, completed-run tables, cached LLM responses, trained checkpoints, logs,
virtual environments, and credentials. Scripts that calculate tables remain included as source.

The simulator generates its disturbance tapes and synthetic scenario families from deterministic
seeds; these inputs do not require a downloaded data set. Therefore, the code-level simulation,
controller, metric, and statistical procedures can be inspected and rerun from this repository.
Reproducing the exact numerical tables in the paper from scratch additionally requires the
computational runs described below. In particular, the DQN and GNN-DDQN comparisons require new
training because checkpoints are not included, while the provider-backed arms require authorized
access to OpenAI GPT-5.4-mini. Provider outputs are not assumed to be bitwise invariant over time.

## Requirements

The locked development environment is Windows AMD64 with CPython 3.12.12 and `uv` 0.9.28. The
core runtime dependencies are NumPy, PyYAML, and jsonschema. PyTorch is needed for RL training and
inference; SciPy, pandas, PyArrow, and Matplotlib are used by some statistical and reporting
scripts. The provider scripts use Python's HTTP client directly; the optional OpenAI dependency is
retained in the lock file for compatibility.

Create the base environment from the repository root:

```powershell
uv sync --locked --prerelease disallow
```

Install optional groups only for the corresponding task:

```powershell
uv sync --locked --prerelease disallow --extra training
uv sync --locked --prerelease disallow --extra analysis
uv sync --locked --prerelease disallow --extra llm
```

No package needs to be installed globally. Set the source path when invoking modules directly:

```powershell
$env:PYTHONPATH = "src"
$env:PYTHONDONTWRITEBYTECODE = "1"
```

## Quick verification without experimental data

The included test suite exercises the deterministic disturbance tape, event-driven SPS plant,
measurement ledger, direct AoI/fairness/collision metrics, candidate model, RMPC selector, risk
gate, observable detector, supervisor contracts, and statistical utilities:

```powershell
.venv/Scripts/python.exe -m pytest -q
.venv/Scripts/python.exe -m ruff check --no-cache src tests scripts/reproduce_smoke.py
```

All included source and experiment scripts are also syntax-checked during release assembly. Some
historical orchestration scripts intentionally retain their original compact style and are not
part of the strict Ruff target above.

A short deterministic smoke run can be executed without data files, checkpoints, API access, or
network access:

```powershell
.venv/Scripts/python.exe scripts/reproduce_smoke.py --output "outputs/smoke"
```

The command writes generated metrics and a SHA-256 index below `outputs/smoke/`. The `outputs/`
directory is ignored by Git.

## Reproduction map

| Component | Main code or entry point | External requirement |
|---|---|---|
| SPS simulator and direct endpoints | `src/exp09/plant/`, `src/exp09/evaluation/runner.py`, `src/exp09/evaluation/metrics_accumulator.py` | None |
| Deterministic Rule/MPC family | `scripts/run_supplement_deterministic_20260813.py` | None; generates synthetic tapes |
| Detector endpoint study | `scripts/run_supplement_detector_endpoint_20260813_0018.py` | None; generates synthetic tapes |
| Controller-model mismatch study | `scripts/run_supplement_mismatch_20260813_0019.py` | None; generates synthetic tapes |
| Eq. (11) endpoint sensitivity | `scripts/run_supplement_eq11_weight_endpoint_20260813_0014.py` | None; generates synthetic tapes |
| Detector diagnostics | `scripts/run_supplement_detector_diagnostics_20260814_0024.py` | None; generates synthetic tapes |
| RL baselines | `src/exp09/baselines/real_training.py` | PyTorch and a new training run |
| LLM contribution study | `scripts/run_c19_shock_confirmatory_llm_20260814_0035.py` | Authorized GPT-5.4-mini access; may incur cost |
| End-to-end latency profile | `scripts/run_c14_2_e2e_latency_profile_20260812.py` | `--live` requires authorized GPT-5.4-mini access; dry run is offline |
| Locked comparison and post-analysis | `scripts/run_c15_locked_test_*.py`, `scripts/c15_*` | Newly generated checkpoints and provider response cache |

Most historical filenames retain their execution date or stage identifier so that the archived
method can be traced without renaming scientific code. The `scripts/` directory contains the
final reproduction chain and omits superseded retry, repair, audit-only, and figure-rendering
utilities. Output paths inside the retained scripts point to `artifacts/` or `paper_outputs/`;
both directories are excluded from this release and will be created by the applicable runner.

Several later scripts are append-only and will stop if their target output already exists. Use a
fresh checkout or remove only a previously generated output directory after preserving it.

## LLM configuration and credentials

The Full and Plain-LLM paths used OpenAI GPT-5.4-mini with temperature zero and schema-constrained
outputs. Prompts and non-secret protocol settings are included. API keys, relay credentials, and
response caches are not included.

The historical provider runners expect a local credential file outside the repository. Do not
commit this file. Networked scripts can incur charges and should be run only with permission from
the account owner. No API call is made by installation, tests, static checks, or
`scripts/reproduce_smoke.py`.

## Repository layout

```text
src/exp09/       Simulator, controller, baselines, metrics, and statistics
scripts/         Experiment, analysis, training, and latency entry points
protocol/        Non-secret configurations and JSON schemas
tests/           Data-free verification tests
RELEASE_VALIDATION.md Assembly-time validation results
pyproject.toml   Project dependencies and tool settings
uv.lock          Locked dependency graph
environment.lock Recorded reference environment
```

## Reproducibility boundary

This repository is sufficient to review and execute the scientific implementation. It is not an
archive of the completed run. Exact published endpoint values cannot be recovered merely by
running a plotting script because the original result rows and checkpoints are deliberately not
distributed in this source-only package. A full from-scratch reproduction requires regenerating
those artifacts under the frozen seeds and configurations, retraining the RL baselines, and, for
the LLM arms, recording new provider responses and latency measurements.
