"""C16: non-sensitive bounded-budget LLM supervisor and exact Eq.(11) sweep.

This experiment is intentionally independent of C15 and never reads C15
artifacts.  It sends only synthetic scenario summaries to the configured
provider.  The LLM chooses an evaluation order under a frozen two-candidate
MPC budget; the deterministic rule receives the identical summary, budget,
candidate set, evaluator, score, and hidden plant.  A separate exact Eq.(11)
weight sweep uses the same synthetic plant and a pre-registered holdout.
"""
from __future__ import annotations

import csv, hashlib, json, math, random, statistics, sys, time
from dataclasses import dataclass, asdict
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, build_opener, ProxyHandler, HTTPRedirectHandler

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
from exp09.evaluation.c14_2_provider_profiling import load_provider_credentials

GENERATION = "EXP09_SUPPLEMENT_VALIDATION_20260814_0027"
OUT = ROOT / "paper_outputs" / "exp09_supplement_validation_20260814_0027"
API_ENV = ROOT.parent / "env-api.md"
MODEL = "gpt-5.4-mini"
N_SCENARIOS = 128
SEED = 20260814
MPC_BUDGET = 2
WEIGHT_W0 = (0.50, 0.20, 0.15, 0.10, 0.05)
THRESHOLD_W0 = 0.35
MEMORY_CLIP_W0 = 0.08
CF_CAP_W0 = 0.05
CANDIDATES = ("rri_20", "rri_50", "rri_100", "rri_200", "rri_500")
METRICS = ("aoi_ms", "q95_aoi_ms", "fairness", "collision_rate", "utility")


def sha_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest().upper()


def sha_obj(value) -> str:
    return sha_bytes(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode())


def sha_file(path: Path) -> str:
    return sha_bytes(path.read_bytes())


@dataclass(frozen=True)
class Scenario:
    scenario_id: str
    cluster_id: str
    regime: str
    density: float
    age_pressure: float
    collision_pressure: float
    volatility: float
    current_rri_us: int
    public_candidates: tuple[dict, ...]
    hidden_bias: float

    def public_payload(self) -> dict:
        return {
            "scenario_id": self.scenario_id,
            "regime": self.regime,
            "density": round(self.density, 4),
            "age_pressure": round(self.age_pressure, 4),
            "collision_pressure": round(self.collision_pressure, 4),
            "volatility": round(self.volatility, 4),
            "current_rri_us": self.current_rri_us,
            "candidate_summaries": list(self.public_candidates),
            "evaluation_budget": MPC_BUDGET,
            "instruction": "Return a permutation of candidate IDs; the first two are evaluated by the frozen MPC budget.",
        }


def make_scenarios() -> list[Scenario]:
    rng = random.Random(SEED)
    regimes = ("nominal", "shock_onset", "fairness_crisis", "collision_crisis", "mixed_transition")
    out = []
    for i in range(N_SCENARIOS):
        regime = regimes[i % len(regimes)]
        if regime == "nominal":
            age, coll, vol = .25, .20, .15
        elif regime == "shock_onset":
            age, coll, vol = .65, .72, .82
        elif regime == "fairness_crisis":
            age, coll, vol = .92, .35, .45
        elif regime == "collision_crisis":
            age, coll, vol = .45, .92, .55
        else:
            age, coll, vol = .75, .76, .88
        density = min(.98, max(.08, .20 + .70 * coll + rng.uniform(-.08, .08)))
        age = min(.99, max(.02, age + rng.uniform(-.08, .08)))
        coll = min(.99, max(.02, coll + rng.uniform(-.08, .08)))
        vol = min(.99, max(.02, vol + rng.uniform(-.08, .08)))
        current = (20_000, 50_000, 100_000, 200_000, 500_000)[i % 5]
        candidates = []
        for j, cid in enumerate(CANDIDATES):
            rri_ms = int(cid.split("_")[1])
            # Public forecast deliberately contains bounded model error.
            public_aoi = 560 - 0.60 * rri_ms + 150 * age + 90 * vol + rng.uniform(-42, 42)
            public_risk = min(.98, max(.01, .06 + density * .75 - .00034 * rri_ms + rng.uniform(-.08, .08)))
            public_fair = min(.99, max(.40, .78 - .18 * abs(j - 2) + .16 * age + rng.uniform(-.05, .05)))
            public_utility = min(.99, max(.01, .95 - public_aoi / 1400 + .10 * public_fair - .35 * public_risk))
            candidates.append({
                "candidate_id": cid,
                "rri_us": rri_ms * 1000,
                "predicted_aoi_ms": round(public_aoi, 3),
                "predicted_collision_risk": round(public_risk, 5),
                "predicted_fairness": round(public_fair, 5),
                "predicted_utility": round(public_utility, 5),
                "evidence_tags": [
                    "high_age_tail" if age > .65 and j <= 2 else "age_tail_ok",
                    "collision_sensitive" if coll > .65 and j <= 1 else "collision_margin",
                    "volatile_transition" if vol > .65 and j in (2, 3) else "stable_transition",
                ],
            })
        out.append(Scenario(
            scenario_id=f"c16_synthetic_{i:04d}", cluster_id=f"cluster_{i // 8:03d}",
            regime=regime, density=density, age_pressure=age, collision_pressure=coll,
            volatility=vol, current_rri_us=current, public_candidates=tuple(candidates),
            hidden_bias=rng.uniform(-1, 1),
        ))
    return out


def hidden_metrics(s: Scenario, cid: str) -> dict[str, float]:
    j = CANDIDATES.index(cid)
    rri_ms = int(cid.split("_")[1])
    # The latent plant has regime-dependent interactions that are not exposed
    # to the supervisor.  They are deterministic and non-sensitive.
    shock_term = 120 * s.volatility * (1.0 if j == 2 else .45 if j == 3 else .85)
    collision_term = 0.62 * s.density * math.exp(-rri_ms / 240.0)
    age_term = 0.34 * s.age_pressure * abs(j - 2) / 2
    phase = 18 * math.sin((j + 1) * (s.hidden_bias + 1.7))
    aoi = max(80.0, 440 - .74 * rri_ms + 180 * s.age_pressure + shock_term + phase)
    q95 = aoi * (1.55 + .35 * s.age_pressure + .12 * abs(j - 2))
    risk = min(.98, max(.005, .035 + collision_term + .08 * s.volatility * (j == 0) + .04 * abs(s.hidden_bias)))
    fairness = min(.995, max(.40, .83 - age_term + .08 * (j == 2) - .06 * s.collision_pressure * (j == 0)))
    utility = min(.995, max(.01, 1.0 - aoi / 1500 + .18 * fairness - .42 * risk))
    return {"aoi_ms": aoi, "q95_aoi_ms": q95, "fairness": fairness, "collision_rate": risk, "utility": utility}


def exact_terms(s: Scenario, cid: str, metrics: dict[str, float], memory: dict, current_u: float, weights=WEIGHT_W0, memory_clip=MEMORY_CLIP_W0, cf_cap=CF_CAP_W0) -> float:
    u, f, aoi, risk = metrics["utility"], metrics["fairness"], metrics["aoi_ms"], metrics["collision_rate"]
    roll = weights[0] * u + weights[1] * f + weights[2] * math.exp(-aoi / 1200.0) + weights[3] * (1.0 - risk) + weights[4] * (u - current_u)
    mem_raw = memory["raafu"] + .35 * memory["fairness"] - 8.0 * memory["collision"] + memory["offset"] + memory["lesson_adjustment"]
    mem = max(-memory_clip, min(memory_clip, mem_raw))
    cf = max(-cf_cap, min(cf_cap, metrics["utility"] - current_u)) if cid == memory["best_counterfactual_id"] else 0.0
    return roll + mem + cf


def evaluate_subset(s: Scenario, subset: list[str], weights=WEIGHT_W0, threshold=THRESHOLD_W0, memory_clip=MEMORY_CLIP_W0, cf_cap=CF_CAP_W0) -> dict:
    all_metrics = {cid: hidden_metrics(s, cid) for cid in CANDIDATES}
    current = min(CANDIDATES, key=lambda cid: abs(int(cid.split("_")[1]) * 1000 - s.current_rri_us))
    current_u = all_metrics[current]["utility"]
    best_cf = max(subset, key=lambda cid: all_metrics[cid]["utility"] - current_u)
    memory = {"raafu": .55 * current_u, "fairness": all_metrics[current]["fairness"], "collision": all_metrics[current]["collision_rate"], "offset": .01 * s.volatility, "lesson_adjustment": .015 if s.regime in {"shock_onset", "mixed_transition"} else -.005, "best_counterfactual_id": best_cf}
    safe = [cid for cid in subset if all_metrics[cid]["collision_rate"] <= threshold]
    pool = safe or [min(subset, key=lambda cid: all_metrics[cid]["collision_rate"])]
    selected = max(pool, key=lambda cid: (exact_terms(s, cid, all_metrics[cid], memory, current_u, weights, memory_clip, cf_cap), cid))
    return {"selected_candidate": selected, **all_metrics[selected], "evaluated_ids": list(subset), "score": exact_terms(s, selected, all_metrics[selected], memory, current_u, weights, memory_clip, cf_cap), "fallback_used": not bool(safe)}


def rule_subset(s: Scenario) -> list[str]:
    # Frozen deterministic adaptive rule, declared before any API result.
    ranked = list(s.public_candidates)
    if s.collision_pressure >= s.age_pressure + .10:
        ranked.sort(key=lambda x: (x["predicted_collision_risk"], -x["predicted_fairness"], x["candidate_id"]))
    elif s.age_pressure >= s.collision_pressure + .10:
        ranked.sort(key=lambda x: (-x["predicted_fairness"], x["predicted_aoi_ms"], x["candidate_id"]))
    else:
        ranked.sort(key=lambda x: (-x["predicted_utility"], x["predicted_collision_risk"], x["candidate_id"]))
    return [x["candidate_id"] for x in ranked[:MPC_BUDGET]]


def oracle_subset(s: Scenario) -> list[str]:
    # Diagnostic upper bound only; hidden metrics never enter LLM/rule input.
    return sorted(CANDIDATES, key=lambda cid: (-hidden_metrics(s, cid)["utility"], hidden_metrics(s, cid)["collision_rate"]))[:MPC_BUDGET]


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers):
        raise RuntimeError("redirect forbidden")


def llm_order(s: Scenario, credentials) -> tuple[list[str], dict]:
    payload = s.public_payload()
    schema = {"type": "object", "additionalProperties": False, "required": ["evaluation_order"], "properties": {"evaluation_order": {"type": "array", "minItems": len(CANDIDATES), "maxItems": len(CANDIDATES), "items": {"type": "string", "enum": list(CANDIDATES)}}}}
    body = {"model": MODEL, "messages": [{"role": "system", "content": "You are a constrained SPS supervisor. Select the evaluation order using only the supplied synthetic observable summary. Return every candidate exactly once; do not invent IDs. The first two candidates consume the frozen MPC budget."}, {"role": "user", "content": json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))}], "temperature": 0, "max_tokens": 160, "response_format": {"type": "json_schema", "json_schema": {"name": "c16_evaluation_order", "strict": True, "schema": schema}}}
    request_hash = sha_obj(body)
    started = time.perf_counter()
    event = {"scenario_id": s.scenario_id, "request_hash": request_hash, "payload_sha256": sha_obj(payload), "status": "FAILED", "response_hash": None, "parsed_response_hash": None, "latency_ms": None, "model_requested": MODEL, "api_key_recorded": False}
    try:
        req = Request(f"{credentials.base_url}/chat/completions", data=json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode(), headers={"Authorization": f"Bearer {credentials.api_key}", "Content-Type": "application/json", "Accept": "application/json", "User-Agent": "exp09-c16-synthetic-budgeted/1.0"}, method="POST")
        with build_opener(ProxyHandler({}), NoRedirect()).open(req, timeout=45) as response:
            raw = response.read()
        event["response_hash"] = sha_bytes(raw)
        envelope = json.loads(raw.decode("utf-8"))
        content = envelope["choices"][0]["message"]["content"]
        parsed = json.loads(content)
        order = parsed["evaluation_order"]
        if sorted(order) != sorted(CANDIDATES) or len(set(order)) != len(CANDIDATES):
            raise ValueError("invalid permutation")
        event["parsed_response_hash"] = sha_obj(parsed); event["status"] = "COMPLETED_AUDITED"; event["model_returned"] = envelope.get("model")
    except (HTTPError, URLError, TimeoutError, OSError, KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
        event["error_type"] = type(exc).__name__
        order = []
    event["latency_ms"] = round((time.perf_counter() - started) * 1000, 3)
    return order, event


def bootstrap_cluster(values: list[float], clusters: list[str], seed: int, n: int = 5000) -> tuple[float, float, float]:
    grouped = {}
    for value, cluster in zip(values, clusters): grouped.setdefault(cluster, []).append(value)
    means = [statistics.fmean(values)]
    rng = random.Random(seed); keys = sorted(grouped)
    for _ in range(n):
        sampled = [rng.choice(keys) for _ in keys]
        means.append(statistics.fmean(v for k in sampled for v in grouped[k]))
    means.sort(); return statistics.fmean(values), means[int(.025 * len(means))], means[int(.975 * len(means))]


def make_weight_grid() -> list[dict]:
    grid = [{"weight_id": "W0_legacy", "weights": WEIGHT_W0}]
    # Pairwise local perturbations: fixed, pre-registered, sum-preserving.
    for i in range(5):
        for j in range(i + 1, 5):
            for delta in (-.05, -.02, .02, .05):
                w = list(WEIGHT_W0); w[i] += delta; w[j] -= delta
                if min(w) >= 0:
                    grid.append({"weight_id": f"local_{i}_{j}_{delta:+.2f}", "weights": tuple(w)})
    rng = random.Random(SEED + 99)
    for k in range(500):
        draws = [rng.expovariate(1.0) for _ in range(5)]; total = sum(draws)
        grid.append({"weight_id": f"dirichlet_{k:03d}", "weights": tuple(x / total for x in draws)})
    return grid


def main() -> int:
    if OUT.exists() and any(p.is_file() for p in OUT.rglob("*")): raise SystemExit(f"append-only output exists: {OUT}")
    for d in ("protocol", "raw", "metrics", "statistics", "tables", "weights"): (OUT / d).mkdir(parents=True, exist_ok=True)
    scenarios = make_scenarios()
    (OUT / "protocol/scenarios.jsonl").write_text("".join(json.dumps({"scenario": asdict(s), "payload_sha256": sha_obj(s.public_payload())}, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n" for s in scenarios), encoding="utf-8")
    protocol = {"schema_version": "exp09-c16-synthetic-budgeted-v1", "generation": GENERATION, "scenario_seed": SEED, "scenario_count": N_SCENARIOS, "scenario_namespace": "c16_synthetic_only", "sensitive_input_prohibited": True, "c15_read": False, "c15_mutated": False, "llm_model": MODEL, "temperature": 0, "retry_budget": 0, "mpc_budget": MPC_BUDGET, "candidate_ids": list(CANDIDATES), "fixed_weights": WEIGHT_W0, "fixed_risk_threshold": THRESHOLD_W0, "weight_grid": "W0 + 40 pairwise local perturbations + 500 Dirichlet draws; holdout locked before execution", "split": {"calibration": "scenario index < 64", "holdout": "scenario index >= 64"}, "api_payload": "synthetic public summaries only; no C15 paths, identifiers, traces, or observations", "endpoints": METRICS}
    (OUT / "protocol/spec.json").write_text(json.dumps(protocol, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    credentials = load_provider_credentials(API_ENV, profile="primary")
    api_events, rows = [], []
    for s in scenarios:
        llm_ids, event = llm_order(s, credentials); api_events.append(event)
        rule_ids = rule_subset(s); oracle_ids = oracle_subset(s)
        result_rule = evaluate_subset(s, rule_ids); result_oracle = evaluate_subset(s, oracle_ids)
        if llm_ids:
            result_llm = evaluate_subset(s, llm_ids[:MPC_BUDGET]); status = "PASSED"
        else:
            result_llm = None; status = "FAILED_RETAINED"
        row = {"schema_version": "exp09-c16-case-v1", "generation": GENERATION, "scenario_id": s.scenario_id, "cluster_id": s.cluster_id, "regime": s.regime, "llm_status": status, "llm_evaluation_ids": llm_ids[:MPC_BUDGET], "rule_evaluation_ids": rule_ids, "oracle_evaluation_ids": oracle_ids, "rule": result_rule, "oracle": result_oracle, "llm": result_llm, "api_event_index": len(api_events) - 1, "c15_mutated": False}
        rows.append(row)
    (OUT / "raw/api_events.jsonl").write_text("".join(json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n" for x in api_events), encoding="utf-8")
    (OUT / "raw/case_rows.jsonl").write_text("".join(json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n" for x in rows), encoding="utf-8")
    passed = [r for r in rows if r["llm_status"] == "PASSED"]
    summary = {"generation": GENERATION, "planned_cases": N_SCENARIOS, "completed_llm_cases": len(passed), "failed_llm_cases": N_SCENARIOS - len(passed), "api_calls": len(api_events), "provider_calls": len(api_events), "network": True, "c15_read": False, "c15_mutated": False}
    (OUT / "metrics/completion.json").write_text(json.dumps(summary, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    if passed:
        table = []
        for regime in sorted({r["regime"] for r in passed} | {"all"}):
            group = passed if regime == "all" else [r for r in passed if r["regime"] == regime]
            for method in ("rule", "llm", "oracle"):
                item = {"regime": regime, "method": method, "n": len(group)}
                for metric in METRICS:
                    vals = [float(r[method][metric]) for r in group]; item[metric] = statistics.fmean(vals)
                table.append(item)
        fields = list(table[0]);
        with (OUT / "tables/tableS8_llm_budgeted_contribution.csv").open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields); writer.writeheader(); writer.writerows(table)
        effects = []
        for regime in sorted({r["regime"] for r in passed} | {"all"}):
            group = passed if regime == "all" else [r for r in passed if r["regime"] == regime]
            for metric in METRICS:
                diffs = [float(r["llm"][metric]) - float(r["rule"][metric]) for r in group]
                clusters = [r["cluster_id"] for r in group]; mean, lo, hi = bootstrap_cluster(diffs, clusters, SEED + len(effects))
                effects.append({"regime": regime, "metric": metric, "n": len(diffs), "llm_minus_rule": mean, "ci95_low": lo, "ci95_high": hi})
        with (OUT / "statistics/llm_rule_paired_effects.csv").open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(effects[0])); writer.writeheader(); writer.writerows(effects)
    grid = make_weight_grid(); weight_rows = []
    for g in grid:
        for split_name, subset in (("calibration", scenarios[:64]), ("holdout", scenarios[64:])):
            results = [evaluate_subset(s, CANDIDATES, weights=g["weights"]) for s in subset]
            w0_results = [evaluate_subset(s, CANDIDATES, weights=WEIGHT_W0) for s in subset]
            row = {"weight_id": g["weight_id"], "split": split_name, "n": len(results), "w0": g["weight_id"] == "W0_legacy"}
            for metric in METRICS:
                vals = [x[metric] for x in results]; base = [x[metric] for x in w0_results]
                row[f"{metric}_mean"] = statistics.fmean(vals); row[f"{metric}_delta_vs_w0"] = statistics.fmean(vals) - statistics.fmean(base); row[f"{metric}_q95"] = sorted(vals)[int(.95 * len(vals)) - 1]
            row["action_stability_vs_w0"] = statistics.fmean(evaluate_subset(s, CANDIDATES, weights=g["weights"])["selected_candidate"] == evaluate_subset(s, CANDIDATES, weights=WEIGHT_W0)["selected_candidate"] for s in subset)
            weight_rows.append(row)
    with (OUT / "tables/tableS9_eq11_weight_global_sensitivity.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(weight_rows[0])); writer.writeheader(); writer.writerows(weight_rows)
    (OUT / "statistics/weight_summary.json").write_text(json.dumps({"grid_size": len(grid), "rows": len(weight_rows), "holdout_locked_before_execution": True, "weight_selection_from_holdout": False, "exact_eq11": True, "local_perturbations": 40, "global_dirichlet_draws": 500, "threshold": THRESHOLD_W0, "memory_clip": MEMORY_CLIP_W0, "counterfactual_cap": CF_CAP_W0}, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    claim = """# Claim boundary\n\n- C16 is an independent synthetic protocol. It does not read or modify C15 and sends only synthetic summaries to the provider.\n- The LLM contribution estimand is the endpoint difference caused by supervisor ordering under a frozen two-candidate evaluation budget, with identical candidate set, evaluator, Eq.(11) selector, threshold, fallback, and hidden plant.\n- The LLM result is claimable only if the core arm reaches 100% completion; failed provider cases remain failed and are not imputed.\n- The exact Eq.(11) sweep contains 40 pre-registered pairwise local perturbations and 500 deterministic global simplex draws, with a locked 64/64 calibration-holdout split. No holdout result selects weights.\n- Positive LLM endpoint differences, if observed, support a bounded-budget synthetic mechanism claim only; they do not establish causal LLM gain on C15 or deployment performance.\n- Weight robustness is reported as an envelope over the locked holdout, not as an optimal-weight claim.\n"""
    (OUT / "claim_boundary.md").write_text(claim, encoding="utf-8")
    close = {"schema_version": "exp09-c16-closeout-v1", "generation": GENERATION, "artifact_status": "C16_COMPLETE" if len(passed) == N_SCENARIOS else "C16_PARTIAL", "planned_cases": N_SCENARIOS, "completed_llm_cases": len(passed), "failed_llm_cases": N_SCENARIOS - len(passed), "weight_grid_size": len(grid), "exact_eq11": True, "c15_read": False, "c15_mutated": False, "api_calls": len(api_events), "provider_calls": len(api_events), "network": True, "claim_boundary": "bounded-budget synthetic contribution and holdout sensitivity only"}
    (OUT / "closeout.json").write_text(json.dumps(close, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    idx = {p.relative_to(OUT).as_posix(): sha_file(p) for p in OUT.rglob("*") if p.is_file() and p.name != "sha256_index.json"}
    (OUT / "sha256_index.json").write_text(json.dumps(idx, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(close, ensure_ascii=False, sort_keys=True))
    return 0 if len(passed) == N_SCENARIOS else 2


if __name__ == "__main__":
    raise SystemExit(main())
