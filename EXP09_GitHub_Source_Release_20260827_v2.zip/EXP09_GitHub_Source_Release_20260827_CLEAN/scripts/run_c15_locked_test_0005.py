"""Append-only C15 0005 continuation for the frozen 0004 offline test.

This continuation exists solely because the 0004 manifest bound an earlier
runner hash.  It keeps the same C15 protocol generation, topology and exact
qualified cache, while binding a new runner and output ordinal.
"""

from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import os
import sys
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

_source = ROOT / "scripts" / "run_c15_locked_test_0004.py"
_spec = importlib.util.spec_from_file_location("exp09_c15_runner_0004", _source)
if _spec is None or _spec.loader is None:
    raise RuntimeError("unable to load frozen 0004 runner")
_base = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = _base
_spec.loader.exec_module(_base)


GEN = _base.GEN
ATTEMPT = "0005"
OUTPUT_LOCATOR = f"artifacts/c15_locked_test_20260807_{ATTEMPT}"
MANIFEST_LOCATOR = f"protocol/c15/c15_locked_test_manifest_20260807_{ATTEMPT}.json"
SPEC_LOCATOR = f"protocol/c15/c15_spec_20260807_{ATTEMPT}.json"
CONTINUATION_LOCATOR = f"protocol/c15/c15_continuation_20260807_{ATTEMPT}.json"
PREFLIGHT_LOCATOR = f"protocol/c15/c15_preflight_evidence_20260807_{ATTEMPT}.json"
LAUNCH_LOCATOR = f"protocol/c15/c15_locked_test_launch_20260807_{ATTEMPT}.json"
TERMINAL_LOCATOR = f"protocol/c15/c15_locked_test_terminal_20260807_{ATTEMPT}.json"
PARENT_MANIFEST = "protocol/c15/c15_locked_test_manifest_20260807_0004.json"
PARENT_MANIFEST_SHA = "9A26745D226D927E52E4CBD3709774CCF771AD8786D1B0CE64DCE84B48106190"


def _file_sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def _canon(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")


def _write_once(rel: str, value: dict[str, Any]) -> str:
    path = ROOT / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = _canon(value)
    with path.open("xb") as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    return hashlib.sha256(payload).hexdigest().upper()


def _read(rel: str) -> dict[str, Any]:
    path = ROOT / rel
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"JSON object required: {rel}")
    return value


def _binding(rel: str) -> dict[str, str]:
    return {"locator": rel, "sha256": _file_sha(ROOT / rel)}


def install_bindings() -> None:
    _base.install_bindings()
    c143 = _base.c143
    c143.PROTOCOL_GENERATION = GEN
    c143.ROOT_NAMESPACE = _base.NAMESPACE
    c143.ROOT_ID_PREFIX = "c15_locked_test_"
    c143.METHODS = _base.METHODS
    c143.LLM_METHODS = ("Full", "Plain_LLM")
    c143.RL_METHODS = _base.RL_METHODS
    c143.RL_SEEDS = _base.RL_SEEDS
    c143.CASE_COUNT = _base.CASE_COUNT
    c143.FRONTIER_CASE_COUNT = 512
    c143.CACHE_OUTPUT_LOCATOR = _base.CACHE_LOCATOR
    c143.SHADOW_OUTPUT_LOCATOR = OUTPUT_LOCATOR
    c143.MANIFEST_LOCATOR = MANIFEST_LOCATOR
    c143.SHADOW_CONCURRENCY = 8


def materialize() -> Path:
    parent_path = ROOT / PARENT_MANIFEST
    if _file_sha(parent_path) != PARENT_MANIFEST_SHA:
        raise RuntimeError("C15 0004 parent manifest hash drift")
    manifest_path = ROOT / MANIFEST_LOCATOR
    output_path = ROOT / OUTPUT_LOCATOR
    if output_path.exists():
        raise RuntimeError("C15 0005 append-only output collision")

    parent = _read(PARENT_MANIFEST)
    manifest = copy.deepcopy(parent)
    manifest["continuation_attempt_ordinal"] = int(ATTEMPT)
    manifest["continuation_of"] = PARENT_MANIFEST
    manifest["source_bindings"]["runner"] = _binding(
        "scripts/run_c15_locked_test_0005.py"
    )
    manifest["source_bindings"]["parent_manifest"] = _binding(PARENT_MANIFEST)

    if manifest_path.exists():
        existing = _read(MANIFEST_LOCATOR)
        if existing != manifest:
            raise RuntimeError("C15 0005 manifest exists with different content")
    else:
        _write_once(MANIFEST_LOCATOR, manifest)

    q = _read(f"{_base.CACHE_LOCATOR}/cache_qualification.json")
    if (
        q.get("passed") is not True
        or q.get("protocol_generation") != GEN
        or q.get("namespace_count") != 4
        or any(
            n.get("missing") != 0
            or n.get("unexpected") != 0
            or n.get("duplicate") != 0
            or n.get("passed") is not True
            for n in q.get("namespaces", [])
        )
    ):
        raise RuntimeError("C15 exact cache gate failed")

    if not (ROOT / SPEC_LOCATOR).exists():
        _write_once(
            SPEC_LOCATOR,
            {
                "schema_version": "exp09-c15-spec-v2",
                "protocol_generation": GEN,
                "continuation_attempt_ordinal": int(ATTEMPT),
                "continuation_of": PARENT_MANIFEST,
                "exact_n": 128,
                "case_count": _base.CASE_COUNT,
                "manifest": MANIFEST_LOCATOR,
                "cache": _base.CACHE_LOCATOR,
                "statistics": _base.read_json(ROOT / "protocol/c15/c15_protocol_20260807_0004.json")["statistics"],
                "api_calls": 0,
                "provider_calls": 0,
                "network_calls": 0,
            },
        )
    if not (ROOT / CONTINUATION_LOCATOR).exists():
        _write_once(
            CONTINUATION_LOCATOR,
            {
                "schema_version": "exp09-c15-continuation-v1",
                "artifact_status": "C15_0005_CONTINUATION_FROZEN_APPEND_ONLY",
                "protocol_generation": GEN,
                "continuation_attempt_ordinal": int(ATTEMPT),
                "continuation_of": PARENT_MANIFEST,
                "manifest": MANIFEST_LOCATOR,
                "output": OUTPUT_LOCATOR,
                "cache": _base.CACHE_LOCATOR,
                "exact_missing_only": True,
                "api_calls": 0,
                "provider_calls": 0,
                "network_calls": 0,
                "training": False,
                "tuning": False,
                "unblinding": False,
                "paper_results_or_figures_generated": False,
                "append_only": True,
            },
        )
    if not (ROOT / PREFLIGHT_LOCATOR).exists():
        _write_once(
            PREFLIGHT_LOCATOR,
            {
                "schema_version": "exp09-c15-preflight-v2",
                "protocol_generation": GEN,
                "continuation_attempt_ordinal": int(ATTEMPT),
                "execution_started": False,
                "execution_authorized": True,
                "manifest": MANIFEST_LOCATOR,
                "manifest_sha256": _file_sha(manifest_path),
                "case_count": _base.CASE_COUNT,
                "cache_qualification": "PASS",
                "api_calls": 0,
                "provider_calls": 0,
                "network_calls": 0,
                "offline_only": True,
                "paper_results_or_figures_generated": False,
            },
        )
    return manifest_path


def _record(rel: str, value: dict[str, Any]) -> None:
    if not (ROOT / rel).exists():
        _write_once(rel, value)


def run_stage() -> dict[str, Any]:
    install_bindings()
    manifest = materialize()
    _record(
        LAUNCH_LOCATOR,
        {
            "schema_version": "exp09-c15-locked-test-launch-v1",
            "artifact_status": "C15_0005_OFFLINE_LOCKED_TEST_STARTED",
            "protocol_generation": GEN,
            "continuation_attempt_ordinal": int(ATTEMPT),
            "manifest": MANIFEST_LOCATOR,
            "manifest_sha256": _file_sha(manifest),
            "execution_started": True,
            "api_calls": 0,
            "provider_calls": 0,
            "network_calls": 0,
            "training": False,
            "tuning": False,
            "unblinding": False,
            "paper_results_or_figures_generated": False,
            "append_only": True,
        },
    )
    try:
        result = _base.c143.C143ShadowExecutor(
            ROOT, expected_manifest_sha256=_file_sha(manifest)
        ).run()
    except BaseException as exc:
        _record(
            TERMINAL_LOCATOR,
            {
                "schema_version": "exp09-c15-locked-test-terminal-v1",
                "artifact_status": "C15_0005_FAIL_CLOSED_STOP",
                "protocol_generation": GEN,
                "continuation_attempt_ordinal": int(ATTEMPT),
                "execution_started": True,
                "error_type": type(exc).__name__,
                "error_message": str(exc),
                "api_calls": 0,
                "provider_calls": 0,
                "network_calls": 0,
                "paper_results_or_figures_generated": False,
                "append_only": True,
            },
        )
        raise
    _record(
        TERMINAL_LOCATOR,
        {
            "schema_version": "exp09-c15-locked-test-terminal-v1",
            "artifact_status": "C15_0005_OFFLINE_LOCKED_TEST_COMPLETED",
            "protocol_generation": GEN,
            "continuation_attempt_ordinal": int(ATTEMPT),
            "execution_started": True,
            "artifact_status_from_executor": result.get("artifact_status"),
            "cases": result.get("scope", {}).get("method_cases_passed"),
            "api_calls": 0,
            "provider_calls": 0,
            "network_calls": 0,
            "paper_results_or_figures_generated": False,
            "append_only": True,
        },
    )
    return result


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("preflight", "run"))
    args = parser.parse_args()
    install_bindings()
    if args.command == "preflight":
        manifest = materialize()
        print(
            json.dumps(
                {
                    "protocol_generation": GEN,
                    "continuation_attempt_ordinal": int(ATTEMPT),
                    "manifest": MANIFEST_LOCATOR,
                    "manifest_sha256": _file_sha(manifest),
                    "case_count": _base.CASE_COUNT,
                    "cache": _base.CACHE_LOCATOR,
                    "execution_authorized": True,
                    "api_calls": 0,
                    "provider_calls": 0,
                    "network_calls": 0,
                },
                sort_keys=True,
            ),
            flush=True,
        )
        return
    result = run_stage()
    print(
        json.dumps(
            {
                "protocol_generation": GEN,
                "continuation_attempt_ordinal": int(ATTEMPT),
                "artifact_status": result.get("artifact_status"),
                "cases": result.get("scope", {}).get("method_cases_passed"),
                "api_calls": 0,
                "provider_calls": 0,
                "network_calls": 0,
            },
            sort_keys=True,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
