"""Append-only final C15 completion freeze with corrected mapping opening."""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
STAGE = Path(tempfile.gettempdir()) / "exp09_c15_final_completion_20260811_0001"
MAP_OUT = STAGE / "artifacts/c15_mapping_release_20260811_0002"
UNBLIND_OUT = STAGE / "artifacts/c15_unblind_20260811_0002"
FINAL_OUT = STAGE / "artifacts/c15_completion_closeout_20260811_0001"
FINAL_PROTOCOL = STAGE / "protocol/c15/c15_completion_closeout_20260811_0001.json"
SOURCE_GEN = "EXP09_C15_LOCKED_TEST_20260807_0004"
MAP_GEN = "EXP09_C15_MAPPING_RELEASE_20260811_0002"
UNBLIND_GEN = "EXP09_C15_UNBLIND_20260811_0002"
POST_GEN = "EXP09_C15_POST_ANALYSIS_20260811_0002"
COMMITMENT = "3C90BB339A4980386C1C6D07E9994BF2B1E4F9C14F1B39F628FA8AB995C1CE9B"
METHODS = ("Full", "RMPC_SameEvaluator", "Rule_SameStack", "TunedNonLLM_SameStack", "Plain_LLM", "DQN", "GNN_DDQN", "AoI_aware_heuristic", "Greedy_1", "Nominal_MPC")
SEEDS = (101, 202, 303, 404, 505)

PATHS = {
    "cache_qualification": ROOT / "artifacts/c15_cache_20260807_0128/cache_qualification.json",
    "cache_terminal": ROOT / "artifacts/c15_cache_20260807_0128/continuation_terminal_evidence.json",
    "authority": ROOT / "protocol/c15/c15_authority_freeze_20260807_0004.json",
    "manifest": ROOT / "protocol/c15/c15_locked_test_manifest_20260807_0018.json",
    "locked_terminal": ROOT / "protocol/c15/c15_locked_test_terminal_20260807_0018.json",
    "case_ledger": ROOT / "artifacts/c15_locked_test_20260807_0018/case_ledger.json",
    "root_cell_ledger": ROOT / "artifacts/c15_locked_test_20260807_0018/root_cell_ledger.json",
    "runtime_closeout": ROOT / "artifacts/c15_closeout_20260811_0003/c15_runtime_closeout.json",
    "statistics": ROOT / "artifacts/c15_closeout_20260811_0003/c15_statistics.json",
    "statistics_spec": ROOT / "protocol/c15/c15_statistics_spec_20260811_0003.json",
    "statistics_gate": ROOT / "protocol/c15/c15_statistics_gate_20260811_0003.json",
    "evidence_freeze": ROOT / "artifacts/c15_closeout_20260811_0003/c15_evidence_freeze.json",
    "c15_closeout": ROOT / "artifacts/c15_closeout_20260811_0003/c15_closeout.json",
    "mapping_release": ROOT / "artifacts/c15_mapping_release_20260811_0002/mapping_release.json",
    "mapping_manifest": ROOT / "protocol/c15/c15_mapping_release_manifest_20260811_0002.json",
    "mapping_index": ROOT / "artifacts/c15_mapping_release_20260811_0002/sha256_index.json",
    "mapping_opening_v1": ROOT / "artifacts/c15_mapping_release_20260811_0002/mapping_opening_evidence.json",
    "unblind": ROOT / "artifacts/c15_unblind_20260811_0002/unblind_evidence.json",
    "unblind_index": ROOT / "artifacts/c15_unblind_20260811_0002/sha256_index.json",
    "post_spec": ROOT / "protocol/c15/c15_post_analysis_spec_20260811_0002.json",
    "post_evidence": ROOT / "artifacts/c15_post_analysis_20260811_0002/post_analysis_evidence.json",
    "post_index": ROOT / "artifacts/c15_post_analysis_20260811_0002/sha256_index.json",
    "post_closeout": ROOT / "artifacts/c15_post_analysis_20260811_0002/post_analysis_closeout.json",
    "post_protocol": ROOT / "protocol/c15/c15_post_analysis_protocol_20260811_0002.json",
    "runner": ROOT / "scripts/run_c15_locked_test_0004.py",
    "statistics_runner": ROOT / "scripts/c15_closeout_statistics_20260811.py",
}


def canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""): h.update(block)
    return h.hexdigest().upper()


def read(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict): raise RuntimeError(f"object required: {path}")
    return value


def write_once(path: Path, value: dict[str, Any]) -> str:
    payload = canonical(value); path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != payload: raise RuntimeError(f"append-only drift: {path}")
    else:
        with path.open("xb") as stream: stream.write(payload); stream.flush(); os.fsync(stream.fileno())
    return hashlib.sha256(payload).hexdigest().upper()


def main() -> None:
    for path in PATHS.values():
        if not path.is_file(): raise RuntimeError(f"missing completion source: {path}")
    docs = {name: read(path) for name, path in PATHS.items() if path.suffix == ".json"}
    q = docs["cache_qualification"]; ledger = docs["case_ledger"]; roots = docs["root_cell_ledger"]
    gate = docs["statistics_gate"]; freeze = docs["evidence_freeze"]
    if q.get("passed") is not True or q.get("protocol_generation") != SOURCE_GEN or any(n.get("missing") or n.get("unexpected") or n.get("duplicate") or n.get("passed") is not True for n in q.get("namespaces", [])): raise RuntimeError("cache qualification drift")
    rows = list(ledger.get("rows", [])); root_rows = list(roots.get("rows", []))
    if len(rows) != 4608 or any(row.get("status") != "PASSED" for row in rows) or len(root_rows) != 256 or any(row.get("status") != "COMPLETE" for row in root_rows): raise RuntimeError("Locked Test ledger drift")
    if gate.get("all_checks_pass") is not True or freeze.get("method_cases", {}).get("passed") != 4608: raise RuntimeError("statistics gate drift")
    mapping = docs["mapping_release"]
    if mapping.get("protocol_generation") != MAP_GEN or mapping.get("mapping_commitment") != COMMITMENT: raise RuntimeError("mapping release drift")
    method_labels = {method: f"LABEL_{i:02d}" for i, method in enumerate(METHODS)}
    units = [
        ("LABEL_00", "Full", "fixed", None, method_labels["Full"]),
        ("LABEL_01", "RMPC_SameEvaluator", "fixed", None, method_labels["RMPC_SameEvaluator"]),
        ("LABEL_02", "Rule_SameStack", "fixed", None, method_labels["Rule_SameStack"]),
        ("LABEL_03", "TunedNonLLM_SameStack", "fixed", None, method_labels["TunedNonLLM_SameStack"]),
        ("LABEL_04", "Plain_LLM", "fixed", None, method_labels["Plain_LLM"]),
        ("LABEL_05", "AoI_aware_heuristic", "fixed", None, method_labels["AoI_aware_heuristic"]),
        ("LABEL_06", "Greedy_1", "fixed", None, method_labels["Greedy_1"]),
        ("LABEL_07", "Nominal_MPC", "fixed", None, method_labels["Nominal_MPC"]),
    ]
    units += [(f"LABEL_{8+i:02d}", "DQN", f"complex_seed{seed}", seed, method_labels["DQN"]) for i, seed in enumerate(SEEDS)]
    units += [(f"LABEL_{13+i:02d}", "GNN_DDQN", f"complex_seed{seed}", seed, method_labels["GNN_DDQN"]) for i, seed in enumerate(SEEDS)]
    unit_rows = [{"execution_unit_label": label, "method_id": method, "variant_id": variant, "train_seed": seed, "root_aggregate_label": aggregate} for label, method, variant, seed, aggregate in units]
    preimage = {"protocol_generation": SOURCE_GEN, "labels": [f"LABEL_{i:02d}" for i in range(18)], "methods": list(METHODS)}
    if hashlib.sha256(canonical(preimage)).hexdigest().upper() != COMMITMENT: raise RuntimeError("mapping commitment preimage mismatch")
    opening = {"schema_version": "exp09-c15-mapping-opening-v2", "artifact_status": "C15_MAPPING_OPENING_V2_CORRECTED_FROZEN", "protocol_generation": MAP_GEN, "source_protocol_generation": SOURCE_GEN, "source_manifest_sha256": sha(PATHS["manifest"]), "source_runner_sha256": sha(PATHS["runner"]), "statistics_runner_sha256": sha(PATHS["statistics_runner"]), "source_mapping_commitment": COMMITMENT, "source_commitment_preimage": preimage, "execution_unit_to_root_aggregate_mapping": unit_rows, "root_aggregate_mapping": mapping.get("mapping"), "rl_seed_aggregation_rule": "five frozen execution units per RL method are averaged within root and arm before inference", "supersedes_mapping_opening_v1_sha256": sha(PATHS["mapping_opening_v1"]), "correction_reason": "v1 repeated method-level labels in the execution-unit table; v2 preserves LABEL_00 through LABEL_17 and explicitly maps them to ten root-aggregate labels.", "api_calls": 0, "provider_calls": 0, "network_calls": 0, "paper_results_or_figures_generated": False, "claim_boundary": "AD-06B"}
    opening_sha = write_once(MAP_OUT / "mapping_opening_evidence_v2.json", opening)
    opening_super_sha = write_once(MAP_OUT / "mapping_opening_supersession.json", {"schema_version": "exp09-c15-mapping-opening-supersession-v1", "protocol_generation": MAP_GEN, "superseded_sha256": sha(PATHS["mapping_opening_v1"]), "replacement_sha256": opening_sha, "use_v2_only": True, "append_only": True, "api_calls": 0, "provider_calls": 0, "network_calls": 0, "paper_results_or_figures_generated": False})
    mapping_closeout_sha = write_once(MAP_OUT / "mapping_release_closeout.json", {"schema_version": "exp09-c15-mapping-release-closeout-v1", "artifact_status": "C15_MAPPING_RELEASE_EVIDENCE_FROZEN", "protocol_generation": MAP_GEN, "source_c15_protocol_generation": SOURCE_GEN, "mapping_release_sha256": sha(PATHS["mapping_release"]), "mapping_manifest_sha256": sha(PATHS["mapping_manifest"]), "mapping_index_sha256": sha(PATHS["mapping_index"]), "mapping_opening_v2_sha256": opening_sha, "mapping_opening_supersession_sha256": opening_super_sha, "mapping_commitment": COMMITMENT, "api_calls": 0, "provider_calls": 0, "network_calls": 0, "training": False, "tuning": False, "paper_results_or_figures_generated": False, "claim_boundary": "AD-06B"})
    unblind_closeout_sha = write_once(UNBLIND_OUT / "unblind_closeout.json", {"schema_version": "exp09-c15-unblind-closeout-v1", "artifact_status": "C15_UNBLIND_EVIDENCE_FROZEN", "protocol_generation": UNBLIND_GEN, "source_c15_protocol_generation": SOURCE_GEN, "mapping_generation": MAP_GEN, "unblind_evidence_sha256": sha(PATHS["unblind"]), "unblind_index_sha256": sha(PATHS["unblind_index"]), "mapping_opening_v2_sha256": opening_sha, "unblinding_after_gate": True, "api_calls": 0, "provider_calls": 0, "network_calls": 0, "training": False, "tuning": False, "paper_results_or_figures_generated": False, "claim_boundary": "AD-06B"})
    core_hashes = {name: sha(path) for name, path in PATHS.items() if name not in {"mapping_opening_v1"}}
    core_hashes.update({"mapping_opening_v2": opening_sha, "mapping_release_closeout": mapping_closeout_sha, "unblind_closeout": unblind_closeout_sha})
    completion = {"schema_version": "exp09-c15-completion-closeout-v1", "artifact_status": "EXP09_C15_AUTHORIZED_SCOPE_COMPLETE_FROZEN", "source_c15_protocol_generation": SOURCE_GEN, "cache_qualification_generation": q.get("continuation_generation"), "locked_test_attempt_ordinal": 18, "statistics_generation": "C15_STATISTICS_20260811_0003", "mapping_generation": MAP_GEN, "unblind_generation": UNBLIND_GEN, "post_analysis_generation": POST_GEN, "scope": {"exact_n": 128, "root_families": 128, "root_cell_groups": 256, "method_cases_planned": 4608, "method_cases_passed": 4608, "method_cases_failed": 0, "method_cases_unknown": 0, "method_cases_quarantine": 0}, "c14_4_closeout_sha256": "BD1A051A587AC325C190602D5632B2B30165D584A323996B29E040064D4A2E9D", "cache_provider_usage": q.get("provider_usage"), "locked_test_budget_usage": docs["runtime_closeout"].get("budget_usage"), "bindings": core_hashes, "api_provider_network_during_locked_test_statistics_and_post_gate": 0, "training": False, "tuning": False, "unblinding_completed_after_gate": True, "claim_boundary": "AD-06B", "paper_final_results_text_generated": False, "paper_final_tables_generated": False, "paper_final_figures_generated": False, "git_operations": False, "stop_boundary": "STOP_BEFORE_PAPER_FINAL_RESULTS_TABLES_FIGURES", "append_only": True}
    completion_sha = write_once(FINAL_OUT / "c15_completion_closeout.json", completion)
    completion_index_sha = write_once(FINAL_OUT / "sha256_index.json", {"schema_version": "exp09-c15-completion-sha256-index-v1", "artifact_status": "C15_COMPLETION_SHA256_INDEX_FROZEN", "source_c15_protocol_generation": SOURCE_GEN, "files": {"c15_completion_closeout.json": completion_sha}, "bindings": core_hashes})
    protocol_sha = write_once(FINAL_PROTOCOL, {"schema_version": "exp09-c15-completion-protocol-v1", "artifact_status": "C15_COMPLETION_REGISTERED_STOP_BOUNDARY_REACHED", "source_c15_protocol_generation": SOURCE_GEN, "completion_closeout_locator": "artifacts/c15_completion_closeout_20260811_0001/c15_completion_closeout.json", "completion_closeout_sha256": completion_sha, "completion_index_sha256": completion_index_sha, "paper_results_or_figures_generated": False, "stop_boundary": "STOP_BEFORE_PAPER_FINAL_RESULTS_TABLES_FIGURES", "claim_boundary": "AD-06B"})
    print(json.dumps({"mapping_opening_v2_sha256": opening_sha, "mapping_closeout_sha256": mapping_closeout_sha, "unblind_closeout_sha256": unblind_closeout_sha, "completion_closeout_sha256": completion_sha, "completion_index_sha256": completion_index_sha, "completion_protocol_sha256": protocol_sha, "api_calls": 0, "provider_calls": 0, "network_calls": 0, "paper_results_or_figures_generated": False}, sort_keys=True))


if __name__ == "__main__": main()
