"""Create an independent post-gate mapping/unblind generation.

This phase only creates append-only offline evidence.  It does not call a
provider and does not create paper-facing tables or figures.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
SOURCE_GEN = "EXP09_C15_LOCKED_TEST_20260807_0004"
MAP_GEN = "EXP09_C15_MAPPING_RELEASE_20260811_0002"
UNBLIND_GEN = "EXP09_C15_UNBLIND_20260811_0002"
POST_GEN = "EXP09_C15_POST_ANALYSIS_20260811_0002"
STAGE = Path(tempfile.gettempdir()) / "exp09_c15_independent_release_20260811_0002"
MAP = STAGE / "artifacts/c15_mapping_release_20260811_0002"
UNBLIND = STAGE / "artifacts/c15_unblind_20260811_0002"
SUPER = STAGE / "artifacts/c15_post_gate_supersession_20260811_0001"
MAP_PROTOCOL = STAGE / "protocol/c15/c15_mapping_release_20260811_0002.json"
MAP_MANIFEST = STAGE / "protocol/c15/c15_mapping_release_manifest_20260811_0002.json"
UNBLIND_PROTOCOL = STAGE / "protocol/c15/c15_unblind_20260811_0002.json"
POST_SPEC = STAGE / "protocol/c15/c15_post_analysis_spec_20260811_0002.json"

BASE = ROOT / "artifacts/c15_closeout_20260811_0003"
GATE = ROOT / "protocol/c15/c15_statistics_gate_20260811_0003.json"
CLOSEOUT = BASE / "c15_closeout.json"
FREEZE = BASE / "c15_evidence_freeze.json"
STAT_SPEC = ROOT / "protocol/c15/c15_statistics_spec_20260811_0003.json"
EXPORT = BASE / "anonymous_root_endpoint_export.json"
OLD_MAP = ROOT / "artifacts/c15_mapping_release_20260811_0001/mapping_release.json"
OLD_UNBLIND = ROOT / "artifacts/c15_unblind_20260811_0001/unblind_evidence.json"
OLD_POST = ROOT / "artifacts/c15_post_analysis_20260811_0001/post_analysis_evidence.json"
COMMITMENT = "3C90BB339A4980386C1C6D07E9994BF2B1E4F9C14F1B39F628FA8AB995C1CE9B"
METHODS = ("Full", "RMPC_SameEvaluator", "Rule_SameStack", "TunedNonLLM_SameStack", "Plain_LLM", "DQN", "GNN_DDQN", "AoI_aware_heuristic", "Greedy_1", "Nominal_MPC")


def canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().upper()


def write_once(path: Path, value: dict[str, Any]) -> str:
    payload = canonical(value)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != payload:
            raise RuntimeError(f"append-only drift: {path}")
    else:
        with path.open("xb") as stream:
            stream.write(payload); stream.flush(); os.fsync(stream.fileno())
    return hashlib.sha256(payload).hexdigest().upper()


def require(path: Path) -> None:
    if not path.is_file():
        raise RuntimeError(f"missing source evidence: {path}")


def main() -> None:
    for path in (GATE, CLOSEOUT, FREEZE, STAT_SPEC, EXPORT, OLD_MAP, OLD_UNBLIND, OLD_POST):
        require(path)
    gate = json.loads(GATE.read_text(encoding="utf-8"))
    close = json.loads(CLOSEOUT.read_text(encoding="utf-8"))
    export = json.loads(EXPORT.read_text(encoding="utf-8"))
    if gate.get("protocol_generation") != SOURCE_GEN or gate.get("all_checks_pass") is not True:
        raise RuntimeError("C15 gate not passed")
    if close.get("mapping_release_authorized") is not True or close.get("post_c15_offline_analysis_authorized") is not True:
        raise RuntimeError("post-gate authorization missing")
    if export.get("method_identity_exported") is not False or export.get("identity_leakage") is not False:
        raise RuntimeError("anonymous export contract drift")
    labels = list(export.get("anonymous_labels", []))
    if labels != [f"LABEL_{i:02d}" for i in range(10)]:
        raise RuntimeError("label topology drift")
    source_hashes = {"gate": sha_file(GATE), "closeout": sha_file(CLOSEOUT), "evidence_freeze": sha_file(FREEZE), "statistics_spec": sha_file(STAT_SPEC), "source_export": sha_file(EXPORT)}
    mapping = [{"anonymous_label": f"LABEL_{i:02d}", "method_id": method} for i, method in enumerate(METHODS)]
    mapping_doc = {"schema_version": "exp09-c15-mapping-release-v2", "artifact_status": "C15_MAPPING_RELEASE_INDEPENDENT_GENERATION_FROZEN", "protocol_generation": MAP_GEN, "source_c15_protocol_generation": SOURCE_GEN, "mapping_commitment": COMMITMENT, "mapping": mapping, "source_hashes": source_hashes, "api_calls": 0, "provider_calls": 0, "network_calls": 0, "training": False, "tuning": False, "unblinding": False, "paper_results_or_figures_generated": False, "claim_boundary": "AD-06B"}
    map_sha = write_once(MAP / "mapping_release.json", mapping_doc)
    manifest_doc = {"schema_version": "exp09-c15-mapping-release-manifest-v1", "artifact_status": "C15_MAPPING_RELEASE_MANIFEST_FROZEN", "protocol_generation": MAP_GEN, "source_c15_protocol_generation": SOURCE_GEN, "mapping_release_sha256": map_sha, "mapping_commitment": COMMITMENT, "label_count": len(mapping), "independent_generation": True, "source_hashes": source_hashes, "append_only": True, "api_calls": 0, "provider_calls": 0, "network_calls": 0, "paper_results_or_figures_generated": False, "claim_boundary": "AD-06B"}
    manifest_sha = write_once(MAP_MANIFEST, manifest_doc)
    map_index_sha = write_once(MAP / "sha256_index.json", {"schema_version": "exp09-c15-mapping-release-sha256-index-v2", "protocol_generation": MAP_GEN, "files": {"mapping_release.json": map_sha, "mapping_release_manifest.json": manifest_sha}, "source_hashes": source_hashes})
    write_once(MAP_PROTOCOL, {"schema_version": "exp09-c15-mapping-release-protocol-v2", "protocol_generation": MAP_GEN, "source_c15_protocol_generation": SOURCE_GEN, "mapping_release_locator": "artifacts/c15_mapping_release_20260811_0002/mapping_release.json", "manifest_locator": "protocol/c15/c15_mapping_release_manifest_20260811_0002.json", "mapping_release_sha256": map_sha, "manifest_sha256": manifest_sha, "mapping_index_sha256": map_index_sha, "mapping_commitment": COMMITMENT, "authorized_after_gate": True, "independent_generation": True, "api_calls": 0, "provider_calls": 0, "network_calls": 0, "paper_results_or_figures_generated": False, "claim_boundary": "AD-06B"})
    unblind_doc = {"schema_version": "exp09-c15-unblind-v2", "artifact_status": "C15_UNBLIND_INDEPENDENT_GENERATION_COMPLETE", "protocol_generation": UNBLIND_GEN, "source_c15_protocol_generation": SOURCE_GEN, "mapping_generation": MAP_GEN, "mapping_release_sha256": map_sha, "mapping_manifest_sha256": manifest_sha, "mapping_commitment": COMMITMENT, "source_export_sha256": sha_file(EXPORT), "method_identity_leakage_before_gate": False, "unblinding_after_gate": True, "api_calls": 0, "provider_calls": 0, "network_calls": 0, "training": False, "tuning": False, "paper_results_or_figures_generated": False, "claim_boundary": "AD-06B"}
    unblind_sha = write_once(UNBLIND / "unblind_evidence.json", unblind_doc)
    unblind_index_sha = write_once(UNBLIND / "sha256_index.json", {"schema_version": "exp09-c15-unblind-sha256-index-v2", "protocol_generation": UNBLIND_GEN, "files": {"unblind_evidence.json": unblind_sha, "mapping_release": map_sha, "mapping_manifest": manifest_sha, "source_export": sha_file(EXPORT)}})
    write_once(UNBLIND_PROTOCOL, {"schema_version": "exp09-c15-unblind-protocol-v2", "protocol_generation": UNBLIND_GEN, "source_c15_protocol_generation": SOURCE_GEN, "mapping_generation": MAP_GEN, "unblind_evidence_sha256": unblind_sha, "unblind_index_sha256": unblind_index_sha, "authorized_after_gate": True, "independent_generation": True, "paper_results_or_figures_generated": False, "claim_boundary": "AD-06B"})
    post_spec = {"schema_version": "exp09-c15-post-analysis-spec-v2", "artifact_status": "C15_POST_ANALYSIS_SPEC_FROZEN_BEFORE_EXECUTION", "protocol_generation": POST_GEN, "source_c15_protocol_generation": SOURCE_GEN, "mapping_generation": MAP_GEN, "unblind_generation": UNBLIND_GEN, "source_export_sha256": sha_file(EXPORT), "mapping_release_sha256": map_sha, "mapping_manifest_sha256": manifest_sha, "unblind_evidence_sha256": unblind_sha, "statistics_spec_sha256": sha_file(STAT_SPEC), "offline_only": True, "preregistered": True, "root_independent_unit": "root_family", "rl_seed_aggregation_before_inference": True, "descriptive_and_AD06B_absolute_effect_audit": True, "paper_results_or_figures_generated": False, "stop_boundary": "STOP_BEFORE_PAPER_FINAL_RESULTS_TABLES_FIGURES", "claim_boundary": "AD-06B"}
    post_spec_sha = write_once(POST_SPEC, post_spec)
    supersession = {"schema_version": "exp09-c15-post-gate-supersession-v1", "artifact_status": "C15_POST_GATE_0001_SUPERSEDED_BY_INDEPENDENT_0002", "source_c15_protocol_generation": SOURCE_GEN, "replacement_mapping_generation": MAP_GEN, "replacement_unblind_generation": UNBLIND_GEN, "replacement_post_analysis_generation": POST_GEN, "superseded_files": {"mapping_0001": sha_file(OLD_MAP), "unblind_0001": sha_file(OLD_UNBLIND), "post_analysis_0001": sha_file(OLD_POST)}, "reason": "0001 used the Locked Test generation for post-gate artifacts; 0002 supplies the required independent generations and mapping manifest.", "use_0002_only": True, "api_calls": 0, "provider_calls": 0, "network_calls": 0, "paper_results_or_figures_generated": False, "claim_boundary": "AD-06B"}
    super_sha = write_once(SUPER / "supersession_evidence.json", supersession)
    write_once(SUPER / "sha256_index.json", {"schema_version": "exp09-c15-post-gate-supersession-sha256-index-v1", "source_c15_protocol_generation": SOURCE_GEN, "files": {"supersession_evidence.json": super_sha}})
    print(json.dumps({"mapping_generation": MAP_GEN, "mapping_sha256": map_sha, "mapping_manifest_sha256": manifest_sha, "unblind_generation": UNBLIND_GEN, "unblind_sha256": unblind_sha, "post_analysis_generation": POST_GEN, "post_spec_sha256": post_spec_sha, "api_calls": 0, "provider_calls": 0, "network_calls": 0, "paper_results_or_figures_generated": False}, sort_keys=True))


if __name__ == "__main__":
    main()
