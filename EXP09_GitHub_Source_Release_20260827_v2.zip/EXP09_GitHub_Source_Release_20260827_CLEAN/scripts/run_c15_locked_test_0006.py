"""C15 0006 append-only continuation wrapper.

Reuses the audited 0005 execution implementation without rewriting its
manifest.  This ordinal is needed because 0005's manifest was already written
before a local helper correction and therefore remains immutable.
"""

from __future__ import annotations

import importlib.util
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
source = ROOT / "scripts" / "run_c15_locked_test_0005.py"
spec = importlib.util.spec_from_file_location("exp09_c15_runner_0005_for_0006", source)
if spec is None or spec.loader is None:
    raise RuntimeError("unable to load C15 0005 implementation")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

module.ATTEMPT = "0006"
module.OUTPUT_LOCATOR = "artifacts/c15_locked_test_20260807_0006"
module.MANIFEST_LOCATOR = "protocol/c15/c15_locked_test_manifest_20260807_0006.json"
module.SPEC_LOCATOR = "protocol/c15/c15_spec_20260807_0006.json"
module.CONTINUATION_LOCATOR = "protocol/c15/c15_continuation_20260807_0006.json"
module.PREFLIGHT_LOCATOR = "protocol/c15/c15_preflight_evidence_20260807_0006.json"
module.LAUNCH_LOCATOR = "protocol/c15/c15_locked_test_launch_20260807_0006.json"
module.TERMINAL_LOCATOR = "protocol/c15/c15_locked_test_terminal_20260807_0006.json"
module.PARENT_MANIFEST = "protocol/c15/c15_locked_test_manifest_20260807_0004.json"
module.PARENT_MANIFEST_SHA = "9A26745D226D927E52E4CBD3709774CCF771AD8786D1B0CE64DCE84B48106190"

original_binding = module._binding


def binding(rel: str) -> dict[str, str]:
    if rel == "scripts/run_c15_locked_test_0005.py":
        rel = "scripts/run_c15_locked_test_0006.py"
    return original_binding(rel)


module._binding = binding


if __name__ == "__main__":
    module.main()
