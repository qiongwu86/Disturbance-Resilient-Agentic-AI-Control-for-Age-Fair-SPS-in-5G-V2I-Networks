"""C15 0018 append-only offline continuation after 0017 preflight fail-close."""
from __future__ import annotations

import copy
import importlib.util
import json
import math
import sys
from dataclasses import replace
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
src = ROOT / "scripts" / "run_c15_locked_test_0017.py"
spec = importlib.util.spec_from_file_location("c15_runner_0017_for_0018", src)
if spec is None or spec.loader is None:
    raise RuntimeError("runner import failed")
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)
base = mod.base

GEN = mod.GEN
CACHE = "artifacts/c15_cache_20260807_0128"
OUT = "artifacts/c15_locked_test_20260807_0018"
MANIFEST = "protocol/c15/c15_locked_test_manifest_20260807_0018.json"
SPEC_REL = "protocol/c15/c15_spec_20260807_0018.json"
CONT = "protocol/c15/c15_continuation_20260807_0018.json"
PREF = "protocol/c15/c15_preflight_evidence_20260807_0018.json"
LAUNCH = "protocol/c15/c15_locked_test_launch_20260807_0018.json"
TERM = "protocol/c15/c15_locked_test_terminal_20260807_0018.json"
PARENT = "protocol/c15/c15_locked_test_manifest_20260807_0016.json"
PRIOR_LEDGER = "artifacts/c15_locked_test_20260807_0016/case_ledger.json"
PRIOR = ROOT / "artifacts/c15_locked_test_20260807_0016"
REMEDIATION = "protocol/c15/c15_wall_time_accounting_remediation_20260807_0017.json"
SUPERSEDED = "protocol/c15/c15_locked_test_terminal_20260807_0017.json"
PRIOR_MANIFEST_SHA = "A2B570B1334E8C2D3BB94382E2818E74F0CDE415FDB88573582A1215DB4E6DC2"


def read(rel: str) -> dict:
    return base._read(rel)


def sha(path: Path) -> str:
    return base._file_sha(path)


def bind(rel: str) -> dict[str, str]:
    return base._binding(rel)


def once(rel: str, value: dict) -> None:
    path = ROOT / rel
    if path.exists():
        if read(rel) != value:
            raise RuntimeError(f"append-only artifact drift: {rel}")
        return
    base._write_once(rel, value)


def prior_rows() -> list[dict]:
    doc = json.loads((PRIOR / "case_ledger.json").read_text(encoding="utf-8"))
    rows = doc.get("rows", [])
    if doc.get("rows_sha256") != base._base.c143.canonical_sha(rows):
        raise RuntimeError("prior 0016 ledger hash drift")
    passed = [r for r in rows if r.get("status") == "PASSED"]
    if len(rows) != 4114 or len(passed) != 4109:
        raise RuntimeError("prior 0016 coverage drift")
    for row in passed:
        p = ROOT / row["artifact_locator"]
        if not p.is_file() or sha(p) != row["artifact_sha256"]:
            raise RuntimeError("prior 0016 artifact drift")
    return sorted(passed, key=lambda r: r["ordinal"])


def active_elapsed() -> int:
    total = 0.0
    for ordinal in (10, 15, 16):
        p = ROOT / f"artifacts/c15_locked_test_20260807_{ordinal:04d}/case_events.ndjson"
        rows = [json.loads(x) for x in p.read_text(encoding="utf-8").splitlines() if x.strip()]
        starts = [__import__("datetime").datetime.fromisoformat(r["started_at"].replace("Z", "+00:00")) for r in rows]
        ends = [__import__("datetime").datetime.fromisoformat(r["ended_at"].replace("Z", "+00:00")) for r in rows]
        total += (max(ends) - min(starts)).total_seconds()
    return math.ceil(total)


def materialize() -> Path:
    parent = ROOT / PARENT
    output = ROOT / OUT
    manifest = ROOT / MANIFEST
    if sha(parent) != PRIOR_MANIFEST_SHA:
        raise RuntimeError("0016 manifest drift")
    if output.exists():
        raise RuntimeError("0018 output collision")
    rows = prior_rows()
    elapsed = active_elapsed()
    if elapsed != 47227 or elapsed >= 345600:
        raise RuntimeError(f"active elapsed drift: {elapsed}")
    remediation = read(REMEDIATION)
    if remediation.get("cumulative_active_elapsed_seconds") != elapsed or remediation.get("budget_cap_changed") is not False:
        raise RuntimeError("wall-time remediation binding drift")
    parent_doc = copy.deepcopy(read(PARENT))
    parent_doc["continuation_attempt_ordinal"] = 18
    parent_doc["continuation_of"] = PARENT
    parent_doc["budget"]["global"]["wall_accounting"] = "ELAPSED_ATTEMPT"
    parent_doc["timeouts_and_abort"]["wall_accounting"] = "ELAPSED_ATTEMPT"
    for name, rel in (
        ("runner", "scripts/run_c15_locked_test_0018.py"),
        ("c14_3_implementation", "src/exp09/evaluation/c14_3_shadow.py"),
        ("parent_manifest", PARENT),
        ("cache_qualification", f"{CACHE}/cache_qualification.json"),
        ("cache_union_provenance", f"{CACHE}/continuation_provenance.json"),
        ("cache_union_index", f"{CACHE}/sha256_index.json"),
        ("prior_case_ledger", PRIOR_LEDGER),
        ("wall_time_accounting_remediation", REMEDIATION),
        ("superseded_preflight_attempt", SUPERSEDED),
    ):
        parent_doc.setdefault("source_bindings", {})[name] = bind(rel)
    once(MANIFEST, parent_doc)
    q = read(f"{CACHE}/cache_qualification.json")
    expected = {("Full", "REFERENCE"): 0, ("Full", "EVENT"): 246, ("Plain_LLM", "REFERENCE"): 3425, ("Plain_LLM", "EVENT"): 3495}
    actual = {(x["method_id"], x["arm"]): x["request_count"] for x in q.get("namespaces", [])}
    if q.get("passed") is not True or q.get("protocol_generation") != GEN or actual != expected or any(q.get(k) != 0 for k in ("api_calls", "provider_calls", "network_calls")):
        raise RuntimeError("0128 cache gate failed")
    proto = read("protocol/c15/c15_protocol_20260807_0004.json")
    once(SPEC_REL, {"schema_version":"exp09-c15-spec-v13","protocol_generation":GEN,"continuation_attempt_ordinal":18,"continuation_of":PARENT,"exact_n":128,"case_count":base._base.CASE_COUNT,"manifest":MANIFEST,"cache":CACHE,"statistics":proto["statistics"],"resume_prior_case_ledger":PRIOR_LEDGER,"imported_completed_cases":len(rows),"missing_cases":499,"wall_accounting":"ELAPSED_ATTEMPT","prior_active_elapsed_seconds":elapsed,"api_calls":0,"provider_calls":0,"network_calls":0})
    once(CONT, {"schema_version":"exp09-c15-continuation-v12","artifact_status":"C15_0018_CONTINUATION_FROZEN_APPEND_ONLY","protocol_generation":GEN,"continuation_attempt_ordinal":18,"continuation_of":PARENT,"manifest":MANIFEST,"output":OUT,"cache":CACHE,"resume_prior_case_ledger":PRIOR_LEDGER,"imported_completed_cases":len(rows),"missing_cases":499,"exact_missing_only":True,"same_frozen_generation":True,"same_scope_cases":True,"wall_accounting":"ELAPSED_ATTEMPT","prior_active_elapsed_seconds":elapsed,"superseded_preflight_attempt":SUPERSEDED,"api_calls":0,"provider_calls":0,"network_calls":0,"training":False,"tuning":False,"unblinding":False,"paper_results_or_figures_generated":False,"append_only":True})
    once(PREF, {"schema_version":"exp09-c15-preflight-v13","protocol_generation":GEN,"continuation_attempt_ordinal":18,"execution_started":False,"execution_authorized":True,"manifest":MANIFEST,"manifest_sha256":sha(manifest),"case_count":base._base.CASE_COUNT,"prior_completed_cases":len(rows),"missing_cases":499,"root_families":128,"root_cell_groups":256,"profile_binding":"PASS","cache_qualification":"PASS_COMPLETE_UNION_0128","wall_accounting_remediation":"PASS","prior_active_elapsed_seconds":elapsed,"api_calls":0,"provider_calls":0,"network_calls":0,"offline_only":True,"paper_results_or_figures_generated":False})
    return manifest


def run() -> dict:
    base.install_bindings()
    c143 = base._base.c143
    c143.CACHE_OUTPUT_LOCATOR = CACHE
    c143.SHADOW_OUTPUT_LOCATOR = OUT
    c143.MANIFEST_LOCATOR = MANIFEST
    c143.PROTOCOL_GENERATION = GEN
    manifest = materialize()
    prior = prior_rows()
    ex = c143.C143ShadowExecutor(ROOT, expected_manifest_sha256=sha(manifest))
    cases = {c.ordinal: c for c in ex.topology.cases}
    have = {r["ordinal"] for r in prior}
    missing = tuple(cases[o] for o in sorted(cases) if o not in have)
    if len(missing) != 499:
        raise RuntimeError(f"exact missing count drift: {len(missing)}")
    ex.rows = prior
    ex.topology = replace(ex.topology, cases=missing)
    for r in prior:
        ex.budget.charge(c143.ShadowBudgetUsage(method_cases=1, environment_steps=int(r.get("environment_steps",0)), model_transitions=int(r.get("model_transitions",0)), cpu_core_seconds=int(r.get("cpu_core_seconds",0)), wall_seconds=0, storage_bytes=int(r.get("storage_bytes",0))))
    ex._initial_elapsed_wall_seconds = active_elapsed()
    ex.budget.set_elapsed_wall_seconds(ex._initial_elapsed_wall_seconds)
    c143.atomic_write_json(ex.output_root / "continuation_provenance.json", {"schema_version":"exp09-c15-locked-test-resume-provenance-v7","artifact_status":"C15_OFFLINE_CASE_ROW_RESUME","protocol_generation":GEN,"continuation_generation":"EXP09_C15_LOCKED_TEST_20260807_0018","continuation_of":["EXP09_C15_LOCKED_TEST_20260807_0016"],"imported_completed_case_count":len(prior),"executed_missing_case_count":len(missing),"excluded_fail_closed_case_count":5,"wall_accounting":"ELAPSED_ATTEMPT","prior_active_elapsed_seconds":ex._initial_elapsed_wall_seconds,"api_key_recorded":False,"api_calls":0,"provider_calls":0,"network_calls":0,"append_only":True}, replace_existing=False)
    once(LAUNCH, {"schema_version":"exp09-c15-locked-test-launch-v12","artifact_status":"C15_0018_OFFLINE_LOCKED_TEST_STARTED","protocol_generation":GEN,"continuation_attempt_ordinal":18,"manifest":MANIFEST,"manifest_sha256":sha(manifest),"execution_started":True,"imported_completed_cases":len(prior),"missing_cases":len(missing),"wall_accounting":"ELAPSED_ATTEMPT","prior_active_elapsed_seconds":ex._initial_elapsed_wall_seconds,"api_calls":0,"provider_calls":0,"network_calls":0,"paper_results_or_figures_generated":False,"append_only":True})
    try:
        result = ex.run()
    except BaseException as exc:
        once(TERM, {"schema_version":"exp09-c15-locked-test-terminal-v13","artifact_status":"C15_0018_FAIL_CLOSED_STOP","protocol_generation":GEN,"continuation_attempt_ordinal":18,"execution_started":True,"error_type":type(exc).__name__,"error_message":str(exc),"api_calls":0,"provider_calls":0,"network_calls":0,"paper_results_or_figures_generated":False,"append_only":True})
        raise
    once(TERM, {"schema_version":"exp09-c15-locked-test-terminal-v13","artifact_status":"C15_0018_OFFLINE_LOCKED_TEST_COMPLETED","protocol_generation":GEN,"continuation_attempt_ordinal":18,"cases":4608,"api_calls":0,"provider_calls":0,"network_calls":0,"paper_results_or_figures_generated":False,"append_only":True})
    return result


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) == 2 else ""
    if cmd not in {"preflight", "run"}:
        raise SystemExit("usage: run_c15_locked_test_0018.py [preflight|run]")
    if cmd == "preflight":
        m = materialize(); rows = prior_rows()
        print(json.dumps({"api_calls":0,"case_count":base._base.CASE_COUNT,"continuation_attempt_ordinal":18,"execution_authorized":True,"manifest":MANIFEST,"manifest_sha256":sha(m),"missing_cases":499,"network_calls":0,"prior_completed_cases":len(rows),"prior_active_elapsed_seconds":active_elapsed(),"protocol_generation":GEN,"provider_calls":0},sort_keys=True))
    else:
        result = run()
        print(json.dumps({"api_calls":0,"artifact_status":result.get("artifact_status"),"cases":result.get("scope",{}).get("method_cases_passed"),"continuation_attempt_ordinal":18,"network_calls":0,"protocol_generation":GEN,"provider_calls":0},sort_keys=True))
