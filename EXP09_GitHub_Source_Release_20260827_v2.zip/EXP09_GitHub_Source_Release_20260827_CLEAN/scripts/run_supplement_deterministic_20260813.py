"""Run append-only deterministic supplement families for EXP09.

This script deliberately excludes Full/Plain_LLM. Those arms require a new
generation-bound API cache and are handled by a separate audited provider step.
The present script runs Rule_NoMPC, Rule_SameStack, TunedNonLLM_SameStack,
RMPC_SameEvaluator, Greedy_1 and Nominal_MPC over paired roots and C07
ControllerModel-only mismatch levels.
"""

from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor, as_completed
from copy import deepcopy
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import random
import statistics
import sys
import time
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from exp09.contracts.actions import (  # noqa: E402
    ACTION_SCHEMA_VERSION,
    ActionKind,
    ControlAction,
    control_action_fingerprint,
)
from exp09.artifacts.canonical import canonical_sha256  # noqa: E402
from exp09.contracts.controller import (  # noqa: E402
    COMMITMENT_SCHEMA_VERSION,
    CommitmentRecord,
    ControllerResetContext,
)
from exp09.contracts.observable import ObservableCounterKind  # noqa: E402
from exp09.contracts.tape import TapeArm  # noqa: E402
from exp09.evaluation.c14_controllers import (  # noqa: E402
    BaselineControllerAdapter,
    C14ControllerFactory,
    RmpcControllerAdapter,
    SupervisorControllerAdapter,
)
from exp09.evaluation.disturbance_tape import build_primary_influx_tape  # noqa: E402
from exp09.evaluation.runner import run_open_loop_case  # noqa: E402
from exp09.model.approximate import ApproximateSPSModelConfig  # noqa: E402
from exp09.control.candidate_generator import ExpiryCandidateGenerator  # noqa: E402

GENERATION = "EXP09_SUPPLEMENT_VALIDATION_20260813_0003"
OUT = ROOT / "paper_outputs" / "exp09_supplement_validation_20260813_0003"
CONFIG_LOCATOR = "protocol/c14/c14_1_method_configs.FROZEN_REMEDIATION_20260728.json"
ROOTS = tuple(f"c15_locked_test_{i:03d}" for i in range(4))
ARMS = ("REFERENCE", "EVENT")
LEVELS = (("nominal", 1_000_000), ("under_predict_load", 800_000), ("over_predict_load", 1_200_000))
METHODS = ("Rule_NoMPC", "Rule_SameStack", "TunedNonLLM_SameStack", "RMPC_SameEvaluator", "Greedy_1", "Nominal_MPC")
MODEL_METHODS = set(METHODS) - {"Rule_NoMPC"}
WORKERS = 4


def sha_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def canonical_sha(value: Any) -> str:
    if hasattr(value, "schema_version"):
        return canonical_sha256(value, expected_schema_version=value.schema_version)
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    return hashlib.sha256(payload).hexdigest().upper()


class RuleNoMpcController:
    """A deterministic no-rollout rule using only the causal observation."""

    def __init__(self) -> None:
        self._reset = False

    def reset(self, context: ControllerResetContext) -> None:
        self._reset = True

    def decide(self, frame, opportunity):
        if not self._reset:
            raise RuntimeError("Rule_NoMPC must be reset before decide")
        counters = {item.kind: int(item.value) for item in frame.counters}
        busy = counters.get(ObservableCounterKind.BUSY_SENSING_UNIT, 0)
        total = counters.get(ObservableCounterKind.TOTAL_SENSING_UNIT, 0)
        busy_ppm = busy * 1_000_000 // total if total else 0
        candidates = ExpiryCandidateGenerator().generate(frame, opportunity)
        if busy_ppm >= 500_000:
            action = min(
                (item for item in candidates.actions if item.target_rri_us is not None),
                key=lambda item: int(item.target_rri_us or 0),
            )
        else:
            action = next(
                (item for item in candidates.actions if item.kind is ActionKind.RETAIN_AT_EXPIRY),
                candidates.actions[0],
            )
        return CommitmentRecord(
            schema_version=COMMITMENT_SCHEMA_VERSION,
            observation_hash=canonical_sha(frame),
            action=action,
        )


def _controller(method: str, config: dict[str, Any], config_hash: str):
    if method == "Rule_NoMPC":
        return RuleNoMpcController()
    if method in {"Rule_SameStack", "TunedNonLLM_SameStack"}:
        return SupervisorControllerAdapter(method, config_hash, config)
    if method == "RMPC_SameEvaluator":
        return RmpcControllerAdapter(config_hash, config)
    if method in {"Greedy_1", "Nominal_MPC"}:
        return BaselineControllerAdapter(method, config_hash, config)
    raise ValueError(method)


def _mismatch_config(base: dict[str, Any], load_scale_ppm: int) -> dict[str, Any]:
    cfg = deepcopy(base)
    model = dict(cfg["shared_model"])
    model["load_scale_ppm"] = int(load_scale_ppm)
    approx = ApproximateSPSModelConfig.create(
        transition_step_us=int(model["transition_step_us"]),
        packet_period_us=int(model["packet_period_us"]),
        logical_subchannel_count=int(model["logical_subchannel_count"]),
        load_scale_ppm=int(model["load_scale_ppm"]),
        forecast_load_scales_ppm=tuple(model["forecast_load_scales_ppm"]),
    )
    model["model_config_hash"] = approx.config_hash
    cfg["shared_model"] = model
    return cfg


def run_one(task: tuple[str, str, str, int]) -> dict[str, Any]:
    root_case_id, arm_name, method, level_id, load_scale_ppm = task
    config_path = ROOT / CONFIG_LOCATOR
    config_hash = sha_file(config_path)
    factory = C14ControllerFactory(ROOT, CONFIG_LOCATOR, expected_config_sha256=config_hash)
    config = factory.config if load_scale_ppm == 1_000_000 else _mismatch_config(factory.config, load_scale_ppm)
    controller = _controller(method, config, config_hash)
    started = time.perf_counter()
    result = run_open_loop_case(root_case_id, TapeArm(arm_name), controller=controller)
    wall_ms = round((time.perf_counter() - started) * 1000, 3)
    metrics = asdict(result.metrics)
    return {
        "schema_version": "exp09-supplement-case-row-v1",
        "generation": GENERATION,
        "root_family": root_case_id,
        "arm": arm_name,
        "regime": "nominal" if arm_name == "REFERENCE" else "harm",
        "method": method,
        "level_id": level_id,
        "load_scale_ppm": load_scale_ppm,
        "status": "PASSED",
        "wall_ms": wall_ms,
        "action_count": len(result.raw_trace.actions),
        "tape_config_hash": result.raw_trace.tape.config_hash,
        "tape_hash": canonical_sha(asdict(result.raw_trace.tape)),
        "result_integrity_hash": result.integrity_hash,
        "metrics": metrics,
    }


def mean_float(rows: list[dict[str, Any]], key: str) -> float:
    values = [float(row["metrics"][key]) for row in rows]
    return statistics.fmean(values) if values else float("nan")


def bootstrap_ci(values: list[float], *, seed: int, n: int = 2000) -> tuple[float, float]:
    if len(values) < 2:
        value = values[0] if values else float("nan")
        return value, value
    rng = random.Random(seed)
    means = []
    for _ in range(n):
        sample = [values[rng.randrange(len(values))] for _ in values]
        means.append(statistics.fmean(sample))
    means.sort()
    return means[int(0.025 * n)], means[int(0.975 * n) - 1]


def summarize(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    groups: dict[tuple[str, str, str, int], list[dict[str, Any]]] = {}
    for row in rows:
        groups.setdefault((row["method"], row["regime"], row["level_id"], row["load_scale_ppm"]), []).append(row)
    output = []
    for index, (group, items) in enumerate(sorted(groups.items())):
        method, regime, level_id, load_scale_ppm = group
        entry = {"method": method, "regime": regime, "level_id": level_id, "load_scale_ppm": load_scale_ppm, "n": len(items)}
        for key in ("mean_aoi_ms", "q95_aoi_ms", "jain_freshness", "collision_event_rate"):
            vals = [float(item["metrics"][key]) for item in items]
            lo, hi = bootstrap_ci(vals, seed=20260813 + index)
            entry[key] = statistics.fmean(vals)
            entry[key + "_ci95_low"] = lo
            entry[key + "_ci95_high"] = hi
        output.append(entry)
    return output


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
    if path.exists():
        if path.read_text(encoding="utf-8") != payload:
            raise RuntimeError(f"append-only artifact collision: {path}")
        return
    path.write_text(payload, encoding="utf-8")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    config_path = ROOT / CONFIG_LOCATOR
    protocol = {
        "schema_version": "exp09-supplement-deterministic-run-v1",
        "generation": GENERATION,
        "config_locator": CONFIG_LOCATOR,
        "config_sha256": sha_file(config_path),
        "roots": list(ROOTS),
        "arms": list(ARMS),
        "levels": [{"level_id": item[0], "load_scale_ppm": item[1]} for item in LEVELS],
        "methods": list(METHODS),
        "workers": WORKERS,
        "api_calls": 0,
        "provider_calls": 0,
        "network_fallback": False,
        "training": False,
        "tuning": False,
        "c15_mutated": False,
        "c07_source": "protocol/c07/mismatch_axis_level_freeze.json",
    }
    write_json(OUT / "protocol/deterministic_run_spec.json", protocol)
    tasks = []
    for root_case_id in ROOTS:
        for arm in ARMS:
            for method in METHODS:
                for level_id, load_scale_ppm in LEVELS:
                    if method == "Rule_NoMPC" and load_scale_ppm != 1_000_000:
                        continue
                    tasks.append((root_case_id, arm, method, level_id, load_scale_ppm))
    rows_path = OUT / "raw/deterministic_case_rows.jsonl"
    if rows_path.exists():
        raise RuntimeError("append-only deterministic rows already exist")
    rows: list[dict[str, Any]] = []
    started = datetime.now(timezone.utc).isoformat()
    with ProcessPoolExecutor(max_workers=WORKERS) as executor:
        futures = [executor.submit(run_one, task) for task in tasks]
        with rows_path.open("x", encoding="utf-8", newline="\n") as stream:
            for index, future in enumerate(as_completed(futures), start=1):
                row = future.result()
                rows.append(row)
                stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
                stream.flush()
                if index % 50 == 0:
                    print(f"completed {index}/{len(tasks)}", flush=True)
    rows.sort(key=lambda row: (row["method"], row["regime"], row["level_id"], row["root_family"]))
    summary = summarize(rows)
    write_json(OUT / "metrics/deterministic_summary.json", summary)
    write_json(OUT / "metrics/deterministic_completion.json", {
        "schema_version": "exp09-supplement-deterministic-closeout-v1",
        "generation": GENERATION,
        "artifact_status": "DETERMINISTIC_FAMILIES_COMPLETE",
        "started_at": started,
        "ended_at": datetime.now(timezone.utc).isoformat(),
        "planned_rows": len(tasks),
        "completed_rows": len(rows),
        "failed_rows": 0,
        "api_calls": 0,
        "provider_calls": 0,
        "training": False,
        "tuning": False,
        "c15_mutated": False,
        "methods": list(METHODS),
        "levels": [item[0] for item in LEVELS],
    })
    print(json.dumps({"completed_rows": len(rows), "summary_rows": len(summary)}, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
