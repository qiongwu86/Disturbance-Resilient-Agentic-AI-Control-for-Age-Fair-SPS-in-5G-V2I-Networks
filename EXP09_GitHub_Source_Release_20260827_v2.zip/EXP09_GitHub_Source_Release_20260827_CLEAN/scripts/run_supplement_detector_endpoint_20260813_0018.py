"""Observable detector endpoint integration smoke (append-only)."""
from __future__ import annotations
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict
import csv, hashlib, json, statistics, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]; SRC=ROOT/"src"
if str(SRC) not in sys.path: sys.path.insert(0,str(SRC))
from exp09.artifacts.canonical import canonical_sha256
from exp09.contracts.actions import ActionKind, control_action_fingerprint
from exp09.contracts.controller import COMMITMENT_SCHEMA_VERSION, CommitmentRecord, ControllerResetContext
from exp09.contracts.observable import ObservableCounterKind
from exp09.contracts.tape import TapeArm
from exp09.evaluation.c14_controllers import _FrozenModelStack
from exp09.evaluation.runner import run_open_loop_case

GENERATION="EXP09_SUPPLEMENT_VALIDATION_20260813_0018"
OUT=ROOT/"paper_outputs"/"exp09_supplement_validation_20260813_0018"
CONFIG_LOCATOR="protocol/c14/c14_1_method_configs.FROZEN_REMEDIATION_20260728.json"
ROOTS=tuple(f"c15_locked_test_{i:03d}" for i in range(115,119)); ARMS=("REFERENCE","EVENT"); MODES=("detector_off","oracle_annotation_upper_bound","observable_estimated")

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest().upper()

class DetectorEndpointController:
    def __init__(self, config, mode, oracle_event=False):
        self.stack=_FrozenModelStack(config); self.mode=mode; self.oracle_event=oracle_event; self.ewma=0.0; self.cusum=0.0; self.active_count=0; self.reset_done=False
    def reset(self, context: ControllerResetContext): self.reset_done=True; self.ewma=0.0; self.cusum=0.0; self.active_count=0
    def _observable_active(self, frame):
        c={x.kind:int(x.value) for x in frame.counters}; busy=c.get(ObservableCounterKind.BUSY_SENSING_UNIT,0); total=c.get(ObservableCounterKind.TOTAL_SENSING_UNIT,0); succ=c.get(ObservableCounterKind.DECODED_SUCCESS,0); trials=c.get(ObservableCounterKind.OBSERVABLE_DECODE_TRIAL,0)
        busy_ratio=busy/total if total else 0.0; collision=1.0-succ/trials if trials else 0.0; ages=[int(x.age_us or 0) for x in frame.observed_user_ages]; age=min(1.0,statistics.fmean(ages)/1_000_000) if ages else 0.0
        residual=min(1.0,.55*busy_ratio+.25*collision+.10*min(1.0,len(frame.observed_users)/9)+.10*age)
        self.ewma=.25*residual+.75*self.ewma; self.cusum=max(0.0,self.cusum+residual-.32); hit=self.ewma>=.22 or self.cusum>=.45; self.active_count=self.active_count+1 if hit else 0
        return self.active_count>=2
    def decide(self, frame, opportunity):
        if not self.reset_done: raise RuntimeError("detector controller requires reset")
        ev=self.stack.evaluate(frame,opportunity); active=False
        if self.mode=="oracle_annotation_upper_bound": active=self.oracle_event
        elif self.mode=="observable_estimated": active=self._observable_active(frame)
        if active:
            action=min((a for a in ev.candidates.actions if a.target_rri_us is not None),key=lambda a:int(a.target_rri_us or 0))
        else: action=ev.gated_action
        return CommitmentRecord(schema_version=COMMITMENT_SCHEMA_VERSION,observation_hash=canonical_sha256(frame,expected_schema_version=frame.schema_version),action=action)

def run_one(task):
    root,arm,mode=task; cfg=json.loads((ROOT/CONFIG_LOCATOR).read_text(encoding="utf-8")); ctrl=DetectorEndpointController(cfg,mode,oracle_event=(arm=="EVENT")); result=run_open_loop_case(root,TapeArm(arm),controller=ctrl)
    return {"schema_version":"exp09-detector-endpoint-row-v1","generation":GENERATION,"root_family":root,"arm":arm,"regime":"nominal" if arm=="REFERENCE" else "harm","mode":mode,"status":"PASSED","metrics":asdict(result.metrics),"integrity_hash":result.integrity_hash,"action_count":len(result.raw_trace.actions),"api_calls":0,"provider_calls":0,"c15_mutated":False}

def bootstrap(vals,seed,n=3000):
    if len(vals)<2:return(vals[0],vals[0])
    import random;r=random.Random(seed);m=[statistics.fmean(vals[r.randrange(len(vals))] for _ in vals) for _ in range(n)];m.sort();return(m[int(.025*n)],m[int(.975*n)-1])

def main():
    if OUT.exists(): raise SystemExit(f"append-only output exists: {OUT}")
    for d in ("protocol","raw","metrics","statistics","tables"): (OUT/d).mkdir(parents=True)
    cfg=ROOT/CONFIG_LOCATOR; spec={"schema_version":"exp09-detector-endpoint-v1","generation":GENERATION,"roots":list(ROOTS),"arms":list(ARMS),"modes":list(MODES),"observable_inputs":["busy_sensing_unit_count","total_sensing_unit_count","decoded_success_count","observable_decode_trial_count","observed_user_ages"],"algorithm":"EWMA alpha=.25 + CUSUM reference=.32 threshold=.45 + hysteresis two consecutive hits","oracle_mode":"annotation upper bound only","config_locator":CONFIG_LOCATOR,"config_sha256":sha(cfg),"c15_mutated":False,"network":False}
    (OUT/"protocol/spec.json").write_text(json.dumps(spec,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    tasks=[(r,a,m) for r in ROOTS for a in ARMS for m in MODES]; rows=[]
    with ProcessPoolExecutor(max_workers=4) as pool:
        futures=[pool.submit(run_one,t) for t in tasks]
        with (OUT/"raw/case_rows.jsonl").open("x",encoding="utf-8") as s:
            for f in as_completed(futures): row=f.result();rows.append(row);s.write(json.dumps(row,ensure_ascii=False,sort_keys=True,separators=(",",":"))+"\n");s.flush()
    groups={}
    for r in rows:groups.setdefault((r["mode"],r["regime"]),[]).append(r)
    summary=[]
    for i,((mode,reg),items) in enumerate(sorted(groups.items())):
        e={"mode":mode,"regime":reg,"n_roots":len(items),"endpoint_integration":True}
        for k in ("mean_aoi_ms","q95_aoi_ms","jain_freshness","collision_event_rate"):
            v=[float(x["metrics"][k]) for x in items];lo,hi=bootstrap(v,20260813+i);e[k]=statistics.fmean(v);e[k+"_ci95_low"]=lo;e[k+"_ci95_high"]=hi
        summary.append(e)
    with (OUT/"tables/tableS7_detector_endpoint_comparison.csv").open("w",encoding="utf-8-sig",newline="") as s:w=csv.DictWriter(s,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
    (OUT/"metrics/completion.json").write_text(json.dumps({"generation":GENERATION,"planned_rows":24,"completed_rows":len(rows),"failed_rows":0,"endpoint_integration":True,"api_calls":0,"provider_calls":0,"c15_mutated":False,"status":"DETECTOR_ENDPOINT_INTEGRATION_COMPLETE"},ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    (OUT/"statistics/summary.json").write_text(json.dumps({"rows":len(rows),"endpoint_integration":True,"interpretation":"synthetic validation-only detector mode comparison; oracle is upper bound and observable mode is not deployment validation"},ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    claim="# Claim boundary\n\n- 24/24 endpoint rows passed for detector-off, oracle-annotation upper bound, and observable-estimated modes on four paired roots.\n- The observable mode uses only the listed observable counters/ages and its output is integrated into the action branch.\n- The oracle mode is a diagnostic upper bound, not a deployable input.\n- This remains synthetic small-N validation; no real deployment, field observability, or universal shock-detection claim is allowed.\n"
    (OUT/"claim_boundary.md").write_text(claim,encoding="utf-8")
    idx={p.relative_to(OUT).as_posix():sha(p) for p in OUT.rglob("*") if p.is_file() and p.name!="sha256_index.json"};(OUT/"sha256_index.json").write_text(json.dumps(idx,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    close={"schema_version":"exp09-detector-closeout-v1","generation":GENERATION,"artifact_status":"DETECTOR_ENDPOINT_INTEGRATION_COMPLETE","rows":len(rows),"failed_rows":0,"endpoint_integration":True,"deployment_validation":False,"c15_mutated":False,"network":False};(OUT/"closeout.json").write_text(json.dumps(close,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8");print(json.dumps(close,ensure_ascii=False,sort_keys=True))
if __name__=="__main__":main()
