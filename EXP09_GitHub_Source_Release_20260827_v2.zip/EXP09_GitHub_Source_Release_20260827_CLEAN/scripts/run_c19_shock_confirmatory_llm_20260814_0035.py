"""C19 independent confirmatory shock-onset LLM contribution experiment.

C17 is treated as exploratory.  C19 uses fresh shock-onset scenarios and a
pre-registered two-endpoint primary family: q95 AoI and collision rate for
LLM versus Tuned-NonLLM.  Rule comparisons and other endpoints are secondary.
"""
from __future__ import annotations

import csv
import json
import math
import random
import statistics
from dataclasses import asdict

import run_c16_llm_budgeted_eq11_20260814_0027 as base
import run_c17_fairness_gated_llm_20260814_0033 as c17

GENERATION = "EXP09_SUPPLEMENT_VALIDATION_20260814_0035"
OUT = base.ROOT / "paper_outputs" / "exp09_supplement_validation_20260814_0035"
SEED = 2026081435
N_SCENARIOS = 256
BATCH_SIZE = 16
PRIMARY_METRICS = ("q95_aoi_ms", "collision_rate")
SECONDARY_METRICS = ("aoi_ms", "fairness", "utility")


def make_scenarios() -> list[base.Scenario]:
    rng = random.Random(SEED); out = []
    for i in range(N_SCENARIOS):
        age = min(.99, max(.02, .62 + rng.uniform(-.09, .09)))
        coll = min(.99, max(.02, .70 + rng.uniform(-.09, .09)))
        vol = min(.99, max(.02, .85 + rng.uniform(-.09, .09)))
        density = min(.98, max(.08, .18 + .73 * coll + rng.uniform(-.08, .08)))
        current = (20_000, 50_000, 100_000, 200_000, 500_000)[i % 5]
        candidates = []
        for j, cid in enumerate(base.CANDIDATES):
            rri_ms = int(cid.split("_")[1])
            p_aoi = 520 - .58 * rri_ms + 145 * age + 82 * vol + rng.uniform(-32, 32)
            p_q95 = p_aoi * (1.45 + .32 * age + .10 * abs(j - 2)) + rng.uniform(-28, 28)
            p_risk = min(.98, max(.01, .055 + density * .72 - .00031 * rri_ms + rng.uniform(-.06, .06)))
            p_fair = min(.995, max(.40, .72 + .22 * age - .15 * abs(j - 2) + rng.uniform(-.04, .04)))
            p_u = min(.995, max(.01, .96 - p_aoi / 1450 + .13 * p_fair - .38 * p_risk))
            candidates.append({"candidate_id": cid, "rri_us": rri_ms * 1000,
                "predicted_mean_aoi_ms": round(p_aoi, 3), "predicted_q95_aoi_ms": round(p_q95, 3),
                "predicted_collision_risk": round(p_risk, 5), "predicted_jain_freshness": round(p_fair, 5),
                "predicted_utility": round(p_u, 5), "evidence_tags": [
                    "fairness_priority" if j in (1, 2, 3) else "fairness_neutral",
                    "risk_margin" if j >= 2 else "risk_sensitive", "volatile_transition" if j in (2, 3) else "stable_transition"]})
        out.append(base.Scenario(scenario_id=f"c19_shock_{i:04d}", cluster_id=f"c19_cluster_{i // 8:03d}",
            regime="shock_onset", density=density, age_pressure=age, collision_pressure=coll, volatility=vol,
            current_rri_us=current, public_candidates=tuple(candidates), hidden_bias=rng.uniform(-1, 1)))
    return out


def cluster_bootstrap(diffs: list[float], clusters: list[str], seed: int, n: int = 10000) -> tuple[float, float, float]:
    grouped: dict[str, list[float]] = {}
    for value, cluster in zip(diffs, clusters): grouped.setdefault(cluster, []).append(value)
    keys = sorted(grouped); rng = random.Random(seed); means = []
    for _ in range(n):
        sampled = [rng.choice(keys) for _ in keys]
        means.append(statistics.fmean(v for k in sampled for v in grouped[k]))
    means.sort(); return statistics.fmean(diffs), means[int(.025 * n)], means[int(.975 * n) - 1]


def cluster_signflip(diffs: list[float], clusters: list[str], seed: int, n: int = 100000) -> float:
    grouped: dict[str, list[float]] = {}
    for value, cluster in zip(diffs, clusters): grouped.setdefault(cluster, []).append(value)
    values = [statistics.fmean(grouped[k]) for k in sorted(grouped)]
    obs = abs(statistics.fmean(values)); rng = random.Random(seed); hits = 1
    for _ in range(n):
        permuted = abs(statistics.fmean(value if rng.random() < .5 else -value for value in values))
        hits += permuted >= obs
    return hits / (n + 1)


def main() -> int:
    if OUT.exists() and any(p.is_file() for p in OUT.rglob("*")): raise SystemExit(f"append-only output exists: {OUT}")
    for d in ("protocol", "raw", "metrics", "statistics", "tables"): (OUT / d).mkdir(parents=True, exist_ok=True)
    scenarios = make_scenarios(); credentials = base.load_provider_credentials(base.API_ENV, profile="primary")
    (OUT / "protocol/scenarios.jsonl").write_text("".join(json.dumps({"scenario": asdict(s), "payload_sha256": base.sha_obj(s.public_payload())}, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n" for s in scenarios), encoding="utf-8")
    spec = {"schema_version": "exp09-c19-shock-confirmatory-v1", "generation": GENERATION, "role": "independent confirmation after exploratory C17", "discovery_generation": c17.GENERATION, "scenario_seed": SEED, "scenario_count": N_SCENARIOS, "cluster_count": N_SCENARIOS // 8, "regime": "shock_onset_only", "batch_size": BATCH_SIZE, "mpc_budget": c17.MPC_BUDGET, "risk_threshold": c17.RISK_THRESHOLD, "core_contrast": "LLM minus TunedNonLLM", "primary_endpoints": list(PRIMARY_METRICS), "primary_multiplicity": "two-sided cluster sign-flip; Holm over exactly two primary endpoints", "secondary_endpoints": list(SECONDARY_METRICS), "secondary_rule_comparison": True, "no_posthoc_case_or_endpoint_selection": True, "c15_read": False, "c15_mutated": False, "payload": "fresh synthetic only"}
    (OUT / "protocol/spec.json").write_text(json.dumps(spec, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    rows = []; events = []
    with (OUT / "raw/batch_events.jsonl").open("x", encoding="utf-8") as event_stream, (OUT / "raw/case_rows.jsonl").open("x", encoding="utf-8") as row_stream:
        for start in range(0, len(scenarios), BATCH_SIZE):
            batch = scenarios[start:start + BATCH_SIZE]; orders, event = c17.call_batch(batch, credentials, f"batch_{start // BATCH_SIZE:02d}"); events.append(event)
            event_stream.write(json.dumps(event, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"); event_stream.flush()
            for scenario in batch:
                llm_order = orders.get(scenario.scenario_id); rule = c17.rule_order(scenario); tuned = c17.tuned_nonllm_order(scenario); oracle = c17.oracle_order(scenario)
                row = {"generation": GENERATION, "scenario_id": scenario.scenario_id, "cluster_id": scenario.cluster_id, "regime": scenario.regime, "status": "PASSED" if llm_order else "FAILED_RETAINED", "llm_order": llm_order, "rule_order": rule, "tuned_nonllm_order": tuned, "oracle_order": oracle, "llm": c17.evaluate(scenario, llm_order) if llm_order else None, "rule": c17.evaluate(scenario, rule), "tuned_nonllm": c17.evaluate(scenario, tuned), "oracle": c17.evaluate(scenario, oracle), "c15_mutated": False}
                rows.append(row); row_stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"); row_stream.flush()
    passed = [r for r in rows if r["status"] == "PASSED"]
    primary = []; secondary = []
    if len(passed) == len(scenarios):
        clusters = [r["cluster_id"] for r in passed]
        for metric in PRIMARY_METRICS:
            diffs = [float(r["llm"][metric]) - float(r["tuned_nonllm"][metric]) for r in passed]
            mean, lo, hi = cluster_bootstrap(diffs, clusters, SEED + len(primary)); p = cluster_signflip(diffs, clusters, SEED + 100 + len(primary))
            primary.append({"contrast": "llm_minus_tuned_nonllm", "metric": metric, "n_cases": len(diffs), "n_clusters": len(set(clusters)), "mean_difference": mean, "ci95_low": lo, "ci95_high": hi, "raw_p_value": p})
        order = sorted(range(len(primary)), key=lambda i: primary[i]["raw_p_value"]); running = 0.0
        for rank, index in enumerate(order):
            running = max(running, min(1.0, primary[index]["raw_p_value"] * (len(primary) - rank))); primary[index]["holm_adjusted_p"] = running
        for comparator in ("tuned_nonllm", "rule"):
            for metric in (*PRIMARY_METRICS, *SECONDARY_METRICS):
                diffs = [float(r["llm"][metric]) - float(r[comparator][metric]) for r in passed]
                mean, lo, hi = cluster_bootstrap(diffs, clusters, SEED + 500 + len(secondary))
                secondary.append({"contrast": f"llm_minus_{comparator}", "metric": metric, "n_cases": len(diffs), "n_clusters": len(set(clusters)), "mean_difference": mean, "ci95_low": lo, "ci95_high": hi, "multiplicity_status": "secondary descriptive CI; not in primary family"})
        with (OUT / "statistics/primary_confirmatory_effects.csv").open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(primary[0])); writer.writeheader(); writer.writerows(primary)
        with (OUT / "statistics/secondary_effects.csv").open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(secondary[0])); writer.writeheader(); writer.writerows(secondary)
        table = []
        for method in ("rule", "tuned_nonllm", "llm", "oracle"):
            item = {"method": method, "n": len(passed), "oracle_first_match": statistics.fmean(r[f"{method}_order"][0] == r["oracle_order"][0] for r in passed)}
            for metric in base.METRICS: item[metric] = statistics.fmean(float(r[method][metric]) for r in passed)
            table.append(item)
        with (OUT / "tables/tableS13_c19_shock_confirmatory.csv").open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(table[0])); writer.writeheader(); writer.writerows(table)
    completion = {"generation": GENERATION, "planned_cases": len(scenarios), "completed_cases": len(passed), "failed_cases": len(scenarios) - len(passed), "batches": len(events), "completed_batches": sum(e["status"] == "COMPLETED_AUDITED" for e in events), "api_calls": len(events), "c15_read": False, "c15_mutated": False}
    (OUT / "metrics/completion.json").write_text(json.dumps(completion, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    claim = "# Claim boundary\n\n- C19 is an independent confirmation over fresh synthetic shock-onset scenarios; C17 cases are not reused.\n- The only confirmatory family is LLM versus TunedNonLLM on q95 AoI and collision rate, with cluster sign-flip tests and Holm correction over exactly those two pre-registered endpoints.\n- Mean AoI, fairness, utility, and Rule comparisons are secondary and are not promoted into the primary family.\n- The result estimates bounded-budget synthetic shock-supervisor contribution; it does not establish deployment feasibility or causal gain on C15.\n- All failed cases, if any, remain failed; no case or endpoint may be removed after execution.\n"
    (OUT / "claim_boundary.md").write_text(claim, encoding="utf-8")
    close = {"schema_version": "exp09-c19-closeout-v1", "generation": GENERATION, "artifact_status": "C19_COMPLETE" if len(passed) == len(scenarios) else "C19_PARTIAL", "planned_cases": len(scenarios), "completed_cases": len(passed), "failed_cases": len(scenarios) - len(passed), "api_calls": len(events), "primary_family_size": 2, "c15_read": False, "c15_mutated": False}
    (OUT / "closeout.json").write_text(json.dumps(close, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    index = {p.relative_to(OUT).as_posix(): base.sha_file(p) for p in OUT.rglob("*") if p.is_file() and p.name != "sha256_index.json"}; (OUT / "sha256_index.json").write_text(json.dumps(index, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(close, ensure_ascii=False, sort_keys=True)); return 0 if len(passed) == len(scenarios) else 2


if __name__ == "__main__": raise SystemExit(main())
