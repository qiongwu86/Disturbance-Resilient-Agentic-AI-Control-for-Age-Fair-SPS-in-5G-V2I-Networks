"""C15 0017 append-only Locked Test continuation with wall-clock remediation.

Only verified PASSED rows from 0016 are imported.  The frozen global wall
budget is charged as cumulative active-attempt elapsed time; per-case wall
times remain diagnostic row fields and are never summed across concurrency.
"""
# Source revision marker: 0017-launcher-reuse-fix-v2.
from __future__ import annotations

import copy
import importlib.util
import json
import math
import sys
from dataclasses import replace
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
source = ROOT / "scripts" / "run_c15_locked_test_0007.py"
spec = importlib.util.spec_from_file_location("c15_runner_0007_for_0017", source)
if spec is None or spec.loader is None:
    raise RuntimeError("runner import failed")
wrapper = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = wrapper
spec.loader.exec_module(wrapper)
base = wrapper.module

GEN = base.GEN
CACHE = "artifacts/c15_cache_20260807_0128"
OUT = "artifacts/c15_locked_test_20260807_0017"
MANIFEST = "protocol/c15/c15_locked_test_manifest_20260807_0017.json"
SPEC_REL = "protocol/c15/c15_spec_20260807_0017.json"
CONT = "protocol/c15/c15_continuation_20260807_0017.json"
PREF = "protocol/c15/c15_preflight_evidence_20260807_0017.json"
LAUNCH = "protocol/c15/c15_locked_test_launch_20260807_0017.json"
TERM = "protocol/c15/c15_locked_test_terminal_20260807_0017.json"
REMEDIATION = "protocol/c15/c15_wall_time_accounting_remediation_20260807_0017.json"
PARENT = "protocol/c15/c15_locked_test_manifest_20260807_0016.json"
PRIOR_LEDGER = "artifacts/c15_locked_test_20260807_0016/case_ledger.json"
PRIOR = ROOT / "artifacts/c15_locked_test_20260807_0016"
PRIOR_MANIFEST_SHA = "A2B570B1334E8C2D3BB94382E2818E74F0CDE415FDB88573582A1215DB4E6DC2"
ATTEMPT_EVENT_LEDGERS = (10, 15, 16)


def read(rel: str) -> dict:
    return base._read(rel)


def sha(path: Path) -> str:
    return base._file_sha(path)


def bind(rel: str) -> dict[str, str]:
    return base._binding(rel)


def write_once(rel: str, value: dict) -> None:
    base._write_once(rel, value)


def write_or_validate(rel: str, value: dict) -> None:
    path = ROOT / rel
    if path.exists():
        if read(rel) != value:
            raise RuntimeError(f"append-only artifact drift: {rel}")
        return
    write_once(rel, value)


def prior_rows() -> list[dict]:
    doc = json.loads((PRIOR / "case_ledger.json").read_text(encoding="utf-8"))
    rows = doc.get("rows", [])
    if doc.get("rows_sha256") != base._base.c143.canonical_sha(rows):
        raise RuntimeError("prior 0016 ledger hash drift")
    passed = [row for row in rows if row.get("status") == "PASSED"]
    if len(rows) != 4114 or len(passed) != 4109:
        raise RuntimeError("prior 0016 row boundary drift")
    if len({row.get("ordinal") for row in passed}) != 4109:
        raise RuntimeError("prior 0016 PASSED ordinal duplication")
    for row in passed:
        artifact = ROOT / row["artifact_locator"]
        if not artifact.is_file() or sha(artifact) != row["artifact_sha256"]:
            raise RuntimeError("prior 0016 PASSED artifact drift")
    return sorted(passed, key=lambda row: row["ordinal"])


def cumulative_active_elapsed_seconds() -> int:
    total = 0.0
    for attempt in ATTEMPT_EVENT_LEDGERS:
        path = ROOT / f"artifacts/c15_locked_test_20260807_{attempt:04d}/case_events.ndjson"
        rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
        starts = [datetime.fromisoformat(row["started_at"].replace("Z", "+00:00")) for row in rows]
        ends = [datetime.fromisoformat(row["ended_at"].replace("Z", "+00:00")) for row in rows]
        total += (max(ends) - min(starts)).total_seconds()
    return math.ceil(total)


def materialize() -> Path:
    parent = ROOT / PARENT
    output = ROOT / OUT
    manifest_path = ROOT / MANIFEST
    if sha(parent) != PRIOR_MANIFEST_SHA:
        raise RuntimeError("0016 manifest drift")
    if output.exists():
        raise RuntimeError("0017 output collision")
    rows = prior_rows()
    elapsed = cumulative_active_elapsed_seconds()
    if elapsed != 47227 or elapsed >= 345600:
        raise RuntimeError(f"cumulative active elapsed boundary drift: {elapsed}")

    if not (ROOT / REMEDIATION).exists():
        write_once(REMEDIATION, {
            "schema_version": "exp09-c15-wall-time-accounting-remediation-v1",
            "artifact_status": "C15_0017_WALL_TIME_ACCOUNTING_REMEDIATION_FROZEN_APPEND_ONLY",
            "protocol_generation": GEN,
            "continuation_attempt_ordinal": 17,
            "defect": "global elapsed wall time was charged as the sum of concurrent case wall times",
            "frozen_cap_wall_seconds": 345600,
            "accounting_rule": "sum non-overlapping active-attempt elapsed intervals; do not sum concurrent case wall_seconds",
            "prior_attempt_event_ledgers": [f"artifacts/c15_locked_test_20260807_{n:04d}/case_events.ndjson" for n in ATTEMPT_EVENT_LEDGERS],
            "cumulative_active_elapsed_seconds": elapsed,
            "prior_passed_cases": len(rows),
            "prior_fail_closed_cases_excluded": 5,
            "scope_changed": False,
            "budget_cap_changed": False,
            "case_results_changed": False,
            "api_calls": 0,
            "provider_calls": 0,
            "network_calls": 0,
            "append_only": True,
        })

    doc = copy.deepcopy(read(PARENT))
    doc["continuation_attempt_ordinal"] = 17
    doc["continuation_of"] = PARENT
    doc["budget"]["global"]["wall_accounting"] = "ELAPSED_ATTEMPT"
    doc["budget"]["global"]["wall_seconds"] = 345600
    doc["timeouts_and_abort"]["global_wall_seconds"] = 345600
    doc["timeouts_and_abort"]["wall_accounting"] = "ELAPSED_ATTEMPT"
    for name, rel in (
        ("runner", "scripts/run_c15_locked_test_0017.py"),
        ("c14_3_implementation", "src/exp09/evaluation/c14_3_shadow.py"),
        ("parent_manifest", PARENT),
        ("cache_qualification", f"{CACHE}/cache_qualification.json"),
        ("cache_union_provenance", f"{CACHE}/continuation_provenance.json"),
        ("cache_union_index", f"{CACHE}/sha256_index.json"),
        ("prior_case_ledger", PRIOR_LEDGER),
        ("wall_time_accounting_remediation", REMEDIATION),
    ):
        doc.setdefault("source_bindings", {})[name] = bind(rel)
    write_or_validate(MANIFEST, doc)

    qualification = read(f"{CACHE}/cache_qualification.json")
    expected = {("Full", "REFERENCE"): 0, ("Full", "EVENT"): 246,
                ("Plain_LLM", "REFERENCE"): 3425, ("Plain_LLM", "EVENT"): 3495}
    actual = {(item["method_id"], item["arm"]): item["request_count"] for item in qualification.get("namespaces", [])}
    if qualification.get("passed") is not True or qualification.get("protocol_generation") != GEN or actual != expected:
        raise RuntimeError("0128 cache gate failed")
    if any(qualification.get(key) != 0 for key in ("api_calls", "provider_calls", "network_calls")):
        raise RuntimeError("offline cache gate failed")

    proto = read("protocol/c15/c15_protocol_20260807_0004.json")
    write_or_validate(SPEC_REL, {
        "schema_version": "exp09-c15-spec-v12", "protocol_generation": GEN,
        "continuation_attempt_ordinal": 17, "continuation_of": PARENT, "exact_n": 128,
        "case_count": base._base.CASE_COUNT, "manifest": MANIFEST, "cache": CACHE,
        "statistics": proto["statistics"], "resume_prior_case_ledger": PRIOR_LEDGER,
        "imported_completed_cases": len(rows), "missing_cases": 499,
        "wall_accounting": "ELAPSED_ATTEMPT", "prior_active_elapsed_seconds": elapsed,
        "api_calls": 0, "provider_calls": 0, "network_calls": 0,
    })
    write_or_validate(CONT, {
        "schema_version": "exp09-c15-continuation-v11", "artifact_status": "C15_0017_CONTINUATION_FROZEN_APPEND_ONLY",
        "protocol_generation": GEN, "continuation_attempt_ordinal": 17, "continuation_of": PARENT,
        "manifest": MANIFEST, "output": OUT, "cache": CACHE, "resume_prior_case_ledger": PRIOR_LEDGER,
        "imported_completed_cases": len(rows), "missing_cases": 499, "exact_missing_only": True,
        "same_frozen_generation": True, "same_scope_cases": True, "wall_accounting": "ELAPSED_ATTEMPT",
        "prior_active_elapsed_seconds": elapsed, "excluded_fail_closed_rows": 5,
        "api_calls": 0, "provider_calls": 0, "network_calls": 0, "training": False,
        "tuning": False, "unblinding": False, "paper_results_or_figures_generated": False, "append_only": True,
    })
    write_or_validate(PREF, {
        "schema_version": "exp09-c15-preflight-v12", "protocol_generation": GEN,
        "continuation_attempt_ordinal": 17, "execution_started": False, "execution_authorized": True,
        "manifest": MANIFEST, "manifest_sha256": sha(manifest_path), "case_count": base._base.CASE_COUNT,
        "prior_completed_cases": len(rows), "missing_cases": 499, "root_families": 128,
        "root_cell_groups": 256, "profile_binding": "PASS", "cache_qualification": "PASS_COMPLETE_UNION_0128",
        "wall_accounting_remediation": "PASS", "prior_active_elapsed_seconds": elapsed,
        "api_calls": 0, "provider_calls": 0, "network_calls": 0, "offline_only": True,
        "paper_results_or_figures_generated": False,
    })
    return manifest_path


def run() -> dict:
    base.install_bindings()
    c143 = base._base.c143
    c143.CACHE_OUTPUT_LOCATOR = CACHE
    c143.SHADOW_OUTPUT_LOCATOR = OUT
    c143.MANIFEST_LOCATOR = MANIFEST
    c143.PROTOCOL_GENERATION = GEN
    c143.CASE_COUNT = base._base.CASE_COUNT
    manifest = materialize()
    prior = prior_rows()
    executor = c143.C143ShadowExecutor(ROOT, expected_manifest_sha256=sha(manifest))
    cases = {case.ordinal: case for case in executor.topology.cases}
    have = {row["ordinal"] for row in prior}
    missing = tuple(cases[ordinal] for ordinal in sorted(cases) if ordinal not in have)
    if len(missing) != 499:
        raise RuntimeError(f"exact missing count drift: {len(missing)}")
    executor.rows = prior
    executor.topology = replace(executor.topology, cases=missing)
    for row in prior:
        executor.budget.charge(c143.ShadowBudgetUsage(
            method_cases=1, environment_steps=int(row.get("environment_steps", 0)),
            model_transitions=int(row.get("model_transitions", 0)),
            cpu_core_seconds=int(row.get("cpu_core_seconds", 0)), wall_seconds=0,
            storage_bytes=int(row.get("storage_bytes", 0))))
    executor._initial_elapsed_wall_seconds = cumulative_active_elapsed_seconds()
    executor.budget.set_elapsed_wall_seconds(executor._initial_elapsed_wall_seconds)
    c143.atomic_write_json(executor.output_root / "continuation_provenance.json", {
        "schema_version": "exp09-c15-locked-test-resume-provenance-v6",
        "artifact_status": "C15_OFFLINE_CASE_ROW_RESUME", "protocol_generation": GEN,
        "continuation_generation": "EXP09_C15_LOCKED_TEST_20260807_0017",
        "continuation_of": ["EXP09_C15_LOCKED_TEST_20260807_0016"],
        "imported_completed_case_count": len(prior), "executed_missing_case_count": len(missing),
        "excluded_fail_closed_case_count": 5, "wall_accounting": "ELAPSED_ATTEMPT",
        "prior_active_elapsed_seconds": executor._initial_elapsed_wall_seconds,
        "api_key_recorded": False, "api_calls": 0, "provider_calls": 0, "network_calls": 0, "append_only": True,
    }, replace_existing=False)
    write_once(LAUNCH, {
        "schema_version": "exp09-c15-locked-test-launch-v11", "artifact_status": "C15_0017_OFFLINE_LOCKED_TEST_STARTED",
        "protocol_generation": GEN, "continuation_attempt_ordinal": 17, "manifest": MANIFEST,
        "manifest_sha256": sha(manifest), "execution_started": True, "imported_completed_cases": len(prior),
        "missing_cases": len(missing), "wall_accounting": "ELAPSED_ATTEMPT",
        "prior_active_elapsed_seconds": executor._initial_elapsed_wall_seconds,
        "api_calls": 0, "provider_calls": 0, "network_calls": 0,
        "paper_results_or_figures_generated": False, "append_only": True,
    })
    try:
        result = executor.run()
    except BaseException as exc:
        write_once(TERM, {
            "schema_version": "exp09-c15-locked-test-terminal-v12", "artifact_status": "C15_0017_FAIL_CLOSED_STOP",
            "protocol_generation": GEN, "continuation_attempt_ordinal": 17, "execution_started": True,
            "error_type": type(exc).__name__, "error_message": str(exc), "api_calls": 0,
            "provider_calls": 0, "network_calls": 0, "paper_results_or_figures_generated": False, "append_only": True,
        })
        raise
    write_once(TERM, {
        "schema_version": "exp09-c15-locked-test-terminal-v12", "artifact_status": "C15_0017_OFFLINE_LOCKED_TEST_COMPLETED",
        "protocol_generation": GEN, "continuation_attempt_ordinal": 17, "cases": 4608,
        "api_calls": 0, "provider_calls": 0, "network_calls": 0,
        "paper_results_or_figures_generated": False, "append_only": True,
    })
    return result


if __name__ == "__main__":
    command = sys.argv[1] if len(sys.argv) == 2 else ""
    if command not in {"preflight", "run"}:
        raise SystemExit("usage: run_c15_locked_test_0017.py [preflight|run]")
    base.install_bindings()
    if command == "preflight":
        manifest = materialize()
        rows = prior_rows()
        print(json.dumps({"api_calls": 0, "case_count": base._base.CASE_COUNT,
            "continuation_attempt_ordinal": 17, "execution_authorized": True,
            "manifest": MANIFEST, "manifest_sha256": sha(manifest), "missing_cases": 499,
            "network_calls": 0, "prior_completed_cases": len(rows),
            "prior_active_elapsed_seconds": cumulative_active_elapsed_seconds(),
            "protocol_generation": GEN, "provider_calls": 0}, sort_keys=True))
    else:
        result = run()
        print(json.dumps({"api_calls": 0, "artifact_status": result.get("artifact_status"),
            "cases": result.get("scope", {}).get("method_cases_passed"),
            "continuation_attempt_ordinal": 17, "network_calls": 0,
            "protocol_generation": GEN, "provider_calls": 0}, sort_keys=True))
