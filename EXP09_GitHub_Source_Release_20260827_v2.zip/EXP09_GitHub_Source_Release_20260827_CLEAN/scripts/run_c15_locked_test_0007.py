"""C15 0007 append-only offline Locked Test continuation.

0006 proved the execution path reaches the frozen executor but failed before
the first case because the C15 manifest omitted the empirical-profile binding
required by that executor.  This continuation preserves the 0004 authority,
scope, cases and exact-qualified cache and adds only the already-frozen C14.2
profile binding plus explicit C15 execution metadata.
"""

from __future__ import annotations

import copy
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
source = ROOT / "scripts" / "run_c15_locked_test_0005.py"
spec = importlib.util.spec_from_file_location("exp09_c15_runner_0005_for_0007", source)
if spec is None or spec.loader is None:
    raise RuntimeError("unable to load C15 continuation implementation")
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)

module.ATTEMPT = "0007"
module.OUTPUT_LOCATOR = "artifacts/c15_locked_test_20260807_0007"
module.MANIFEST_LOCATOR = "protocol/c15/c15_locked_test_manifest_20260807_0007.json"
module.SPEC_LOCATOR = "protocol/c15/c15_spec_20260807_0007.json"
module.CONTINUATION_LOCATOR = "protocol/c15/c15_continuation_20260807_0007.json"
module.PREFLIGHT_LOCATOR = "protocol/c15/c15_preflight_evidence_20260807_0007.json"
module.LAUNCH_LOCATOR = "protocol/c15/c15_locked_test_launch_20260807_0007.json"
module.TERMINAL_LOCATOR = "protocol/c15/c15_locked_test_terminal_20260807_0007.json"
module.PARENT_MANIFEST = "protocol/c15/c15_locked_test_manifest_20260807_0004.json"
module.PARENT_MANIFEST_SHA = "9A26745D226D927E52E4CBD3709774CCF771AD8786D1B0CE64DCE84B48106190"

PROFILE_SOURCE = "protocol/c14/c14_3_shadow_manifest.CORRECTED_20260805_attempt0071.json"
RUNNER = "scripts/run_c15_locked_test_0007.py"
CONTINUATION_IMPLEMENTATION = "scripts/run_c15_locked_test_0005.py"
BASE_IMPLEMENTATION = "scripts/run_c15_locked_test_0004.py"


def materialize() -> Path:
    parent_path = ROOT / module.PARENT_MANIFEST
    if module._file_sha(parent_path) != module.PARENT_MANIFEST_SHA:
        raise RuntimeError("C15 0004 parent manifest hash drift")
    manifest_path = ROOT / module.MANIFEST_LOCATOR
    output_path = ROOT / module.OUTPUT_LOCATOR
    if output_path.exists():
        raise RuntimeError("C15 0007 append-only output collision")

    parent = module._read(module.PARENT_MANIFEST)
    profile_source = module._read(PROFILE_SOURCE)
    profile_binding = profile_source.get("profile_binding")
    if not isinstance(profile_binding, dict):
        raise RuntimeError("frozen C14.3 empirical profile binding is absent")

    manifest = copy.deepcopy(parent)
    manifest["stage"] = "C15_LOCKED_TEST"
    manifest["continuation_attempt_ordinal"] = 7
    manifest["continuation_of"] = module.PARENT_MANIFEST
    manifest["profile_binding"] = copy.deepcopy(profile_binding)
    manifest["budget"] = {
        "global": {
            "api_calls": 0,
            "provider_calls": 0,
            "network_calls": 0,
            "llm_tokens": 0,
            "gpu_seconds": 0,
            "training": False,
            "tuning": False,
            "method_cases": module._base.CASE_COUNT,
            "root_families": 128,
            "root_cell_groups": 256,
            "concurrency": 8,
            "cpu_core_seconds": 1_382_400,
            "environment_steps": 7_680_000,
            "model_transitions": 138_240_000_000,
            "storage_bytes": 21_474_836_480,
            "wall_seconds": 345_600,
        }
    }
    manifest["rules"] = {
        "append_only": True,
        "one_shot_per_attempt": True,
        "no_api_network_provider_fallback": True,
        "no_training": True,
        "no_tuning": True,
        "no_method_or_root_filtering": True,
        "no_result_driven_expansion": True,
        "failure_unknown_quarantine_never_success": True,
        "mapping_release_only_after_gate_pass": True,
        "paper_results_and_figures_outside_authority": True,
    }
    manifest["success_failure_rule"] = {
        "success": "all 4608 cases pass; all 256 root/cell groups complete; all frozen bindings and budgets remain valid; API/provider/network remain zero",
        "failure": "any case failure, timeout, missing/duplicate/unexpected row, non-finite value, leakage, hash/config/schema/provenance drift, budget breach, or forbidden API/network/training/tuning activity",
        "abort_threshold_failures": 1,
        "abort_threshold_timeouts": 1,
        "claim_boundary": "AD-06B",
    }
    manifest["timeouts_and_abort"] = {
        "global_wall_seconds": 345_600,
        "per_case_timeout_seconds": 900,
        "retry": 0,
        "resume_after_process_interruption": False,
    }
    manifest["source_bindings"]["runner"] = module._binding(RUNNER)
    manifest["source_bindings"]["continuation_implementation"] = module._binding(
        CONTINUATION_IMPLEMENTATION
    )
    manifest["source_bindings"]["base_implementation"] = module._binding(
        BASE_IMPLEMENTATION
    )
    manifest["source_bindings"]["parent_manifest"] = module._binding(
        module.PARENT_MANIFEST
    )
    manifest["source_bindings"]["profile_binding_source"] = module._binding(
        PROFILE_SOURCE
    )

    if manifest_path.exists():
        if module._read(module.MANIFEST_LOCATOR) != manifest:
            raise RuntimeError("C15 0007 manifest exists with different content")
    else:
        module._write_once(module.MANIFEST_LOCATOR, manifest)

    qualification = module._read(f"{module._base.CACHE_LOCATOR}/cache_qualification.json")
    if (
        qualification.get("passed") is not True
        or qualification.get("protocol_generation") != module.GEN
        or qualification.get("namespace_count") != 4
        or any(
            item.get("missing") != 0
            or item.get("unexpected") != 0
            or item.get("duplicate") != 0
            or item.get("passed") is not True
            for item in qualification.get("namespaces", [])
        )
    ):
        raise RuntimeError("C15 exact cache gate failed")

    protocol = module._base.read_json("protocol/c15/c15_protocol_20260807_0004.json")
    if not (ROOT / module.SPEC_LOCATOR).exists():
        module._write_once(
            module.SPEC_LOCATOR,
            {
                "schema_version": "exp09-c15-spec-v3",
                "protocol_generation": module.GEN,
                "continuation_attempt_ordinal": 7,
                "continuation_of": module.PARENT_MANIFEST,
                "exact_n": 128,
                "case_count": module._base.CASE_COUNT,
                "manifest": module.MANIFEST_LOCATOR,
                "cache": module._base.CACHE_LOCATOR,
                "statistics": protocol["statistics"],
                "api_calls": 0,
                "provider_calls": 0,
                "network_calls": 0,
            },
        )
    if not (ROOT / module.CONTINUATION_LOCATOR).exists():
        module._write_once(
            module.CONTINUATION_LOCATOR,
            {
                "schema_version": "exp09-c15-continuation-v2",
                "artifact_status": "C15_0007_CONTINUATION_FROZEN_APPEND_ONLY",
                "protocol_generation": module.GEN,
                "continuation_attempt_ordinal": 7,
                "continuation_of": module.PARENT_MANIFEST,
                "manifest": module.MANIFEST_LOCATOR,
                "output": module.OUTPUT_LOCATOR,
                "cache": module._base.CACHE_LOCATOR,
                "reason": "0006 failed before case zero because profile_binding was absent",
                "same_frozen_generation": True,
                "same_scope_cases_cache": True,
                "api_calls": 0,
                "provider_calls": 0,
                "network_calls": 0,
                "training": False,
                "tuning": False,
                "unblinding": False,
                "paper_results_or_figures_generated": False,
                "append_only": True,
            },
        )
    if not (ROOT / module.PREFLIGHT_LOCATOR).exists():
        module._write_once(
            module.PREFLIGHT_LOCATOR,
            {
                "schema_version": "exp09-c15-preflight-v3",
                "protocol_generation": module.GEN,
                "continuation_attempt_ordinal": 7,
                "execution_started": False,
                "execution_authorized": True,
                "manifest": module.MANIFEST_LOCATOR,
                "manifest_sha256": module._file_sha(manifest_path),
                "case_count": module._base.CASE_COUNT,
                "root_families": 128,
                "root_cell_groups": 256,
                "profile_binding": "PASS",
                "cache_qualification": "PASS",
                "api_calls": 0,
                "provider_calls": 0,
                "network_calls": 0,
                "offline_only": True,
                "paper_results_or_figures_generated": False,
            },
        )
    return manifest_path


def run_stage() -> dict[str, Any]:
    module.install_bindings()
    manifest = materialize()
    module._record(
        module.LAUNCH_LOCATOR,
        {
            "schema_version": "exp09-c15-locked-test-launch-v2",
            "artifact_status": "C15_0007_OFFLINE_LOCKED_TEST_STARTED",
            "protocol_generation": module.GEN,
            "continuation_attempt_ordinal": 7,
            "manifest": module.MANIFEST_LOCATOR,
            "manifest_sha256": module._file_sha(manifest),
            "execution_started": True,
            "api_calls": 0,
            "provider_calls": 0,
            "network_calls": 0,
            "training": False,
            "tuning": False,
            "unblinding": False,
            "paper_results_or_figures_generated": False,
            "append_only": True,
        },
    )
    try:
        result = module._base.c143.C143ShadowExecutor(
            ROOT, expected_manifest_sha256=module._file_sha(manifest)
        ).run()
    except BaseException as exc:
        module._record(
            module.TERMINAL_LOCATOR,
            {
                "schema_version": "exp09-c15-locked-test-terminal-v2",
                "artifact_status": "C15_0007_FAIL_CLOSED_STOP",
                "protocol_generation": module.GEN,
                "continuation_attempt_ordinal": 7,
                "execution_started": True,
                "error_type": type(exc).__name__,
                "error_message": str(exc),
                "api_calls": 0,
                "provider_calls": 0,
                "network_calls": 0,
                "paper_results_or_figures_generated": False,
                "append_only": True,
            },
        )
        raise
    module._record(
        module.TERMINAL_LOCATOR,
        {
            "schema_version": "exp09-c15-locked-test-terminal-v2",
            "artifact_status": "C15_0007_OFFLINE_LOCKED_TEST_COMPLETED",
            "protocol_generation": module.GEN,
            "continuation_attempt_ordinal": 7,
            "cases": result.get("scope", {}).get("method_cases_passed"),
            "api_calls": 0,
            "provider_calls": 0,
            "network_calls": 0,
            "paper_results_or_figures_generated": False,
            "append_only": True,
        },
    )
    return result


module.materialize = materialize
module.run_stage = run_stage


if __name__ == "__main__":
    module.main()
