"""Run a small, data-free deterministic reproduction check."""

from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys
from typing import Any


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from exp09.contracts.tape import TapeArm  # noqa: E402
from exp09.evaluation.runner import run_open_loop_case  # noqa: E402


ROOTS = ("release_smoke_000", "release_smoke_001")
ARMS = (TapeArm.REFERENCE, TapeArm.EVENT)


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest().upper()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def run() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for root in ROOTS:
        for arm in ARMS:
            first = run_open_loop_case(root, arm)
            second = run_open_loop_case(root, arm)
            if first.integrity_hash != second.integrity_hash or first.metrics != second.metrics:
                raise RuntimeError(f"deterministic replay mismatch: {root}/{arm.value}")
            rows.append(
                {
                    "root_family": root,
                    "arm": arm.value,
                    "metrics": asdict(first.metrics),
                    "integrity_hash": first.integrity_hash,
                    "observable_frame_count": first.observable_frame_count,
                }
            )
    rows.sort(key=lambda row: (row["root_family"], row["arm"]))
    return rows


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("outputs/smoke"))
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists() and any(output.iterdir()):
        raise SystemExit(f"output directory is not empty: {output}")
    output.mkdir(parents=True, exist_ok=True)

    rows = run()
    rows_path = output / "case_metrics.json"
    write_json(rows_path, {"schema_version": "exp09-source-release-smoke-v1", "rows": rows})
    summary = {
        "schema_version": "exp09-source-release-smoke-closeout-v1",
        "status": "PASS",
        "case_count": len(rows),
        "deterministic_replay_verified": True,
        "api_calls": 0,
        "network_calls": 0,
        "training_runs": 0,
        "case_metrics_sha256": sha256_file(rows_path),
        "case_set_sha256": sha256_bytes(canonical_bytes(rows)),
    }
    write_json(output / "closeout.json", summary)
    write_json(
        output / "sha256_index.json",
        {
            "case_metrics.json": sha256_file(rows_path),
            "closeout.json": sha256_file(output / "closeout.json"),
        },
    )
    print(json.dumps(summary, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

