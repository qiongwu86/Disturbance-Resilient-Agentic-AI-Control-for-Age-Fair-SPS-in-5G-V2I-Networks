"""Validation-only Eq.(11) weighted selector endpoint smoke.

This is an append-only endpoint experiment.  It runs the actual frozen
ControllerModel rollout path on four paired roots and applies the equation
reported in the manuscript to the rollout evidence; C15 remains untouched.
"""
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict
import csv, hashlib, json, statistics, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path: sys.path.insert(0, str(SRC))
from exp09.artifacts.canonical import canonical_sha256
from exp09.contracts.actions import ActionKind, control_action_fingerprint
from exp09.contracts.controller import COMMITMENT_SCHEMA_VERSION, CommitmentRecord, ControllerResetContext
from exp09.contracts.observable import ObservableCounterKind
from exp09.contracts.tape import TapeArm
from exp09.evaluation.c14_controllers import C14ControllerFactory, _FrozenModelStack
from exp09.evaluation.runner import run_open_loop_case
from exp09.control.candidate_generator import ExpiryCandidateGenerator

GENERATION = "EXP09_SUPPLEMENT_VALIDATION_20260813_0017"
OUT = ROOT / "paper_outputs" / "exp09_supplement_validation_20260813_0017"
CONFIG_LOCATOR = "protocol/c14/c14_1_method_configs.FROZEN_REMEDIATION_20260728.json"
ROOTS = tuple(f"c15_locked_test_{i:03d}" for i in range(115, 119))
ARMS = ("REFERENCE", "EVENT")
WEIGHTS = (
    ("W0_legacy", .50, .20, .15, .10, .05),
    ("W1_age_plus", .55, .18, .14, .09, .04),
    ("W2_age_minus", .45, .22, .16, .11, .06),
    ("W3_collision_plus", .47, .19, .20, .09, .05),
    ("W4_collision_minus", .53, .21, .10, .11, .05),
    ("W5_uniform", .20, .20, .20, .20, .20),
    ("W6_memory_off", .56, .22, .17, .00, .05),
)
MAX_AGE_US = 2_000_000.0

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest().upper()

class Eq11WeightedController:
    def __init__(self, config, weights):
        self.stack = _FrozenModelStack(config)
        self.weights = weights
        self.reset_done = False
    def reset(self, context: ControllerResetContext): self.reset_done = True
    def decide(self, frame, opportunity):
        if not self.reset_done: raise RuntimeError("controller must be reset")
        ev = self.stack.evaluate(frame, opportunity)
        actions = {control_action_fingerprint(a): a for a in ev.candidates.actions}
        rollouts = {}
        for item in ev.rollouts:
            rollouts.setdefault(item.action_hash, []).append(item)
        counters = {item.kind: int(item.value) for item in frame.counters}
        busy = counters.get(ObservableCounterKind.BUSY_SENSING_UNIT, 0)
        total = counters.get(ObservableCounterKind.TOTAL_SENSING_UNIT, 0)
        busy_ratio = busy / total if total else 0.0
        ages = [int(x.age_us or 0) for x in frame.observed_user_ages]
        age_norm = min(1.0, statistics.fmean(ages) / MAX_AGE_US) if ages else 0.0
        def terms(items):
            n = len(items)
            mean_age = statistics.fmean(x.time_average_mean_age_us for x in items)
            worst_age = statistics.fmean(x.time_average_worst_age_us for x in items)
            risk = statistics.fmean(x.predicted_collision_risk_ppm for x in items) / 1_000_000.0
            u = max(0.0, 1.0 - mean_age / MAX_AGE_US)
            f = max(0.0, 1.0 - max(0.0, worst_age - mean_age) / MAX_AGE_US)
            freshness = max(0.0, min(1.0, 1.0 - worst_age / MAX_AGE_US))
            return u, f, freshness, risk, mean_age, worst_age
        data = {h: terms(v) for h, v in rollouts.items()}
        # The retain candidate is the baseline for U_t and counterfactual gain.
        retain_hash = next((h for h,a in actions.items() if a.kind is ActionKind.RETAIN_AT_EXPIRY), next(iter(actions)))
        base_u = data[retain_hash][0]
        safe = [h for h, t in data.items() if t[3] <= .35]
        pool = safe or list(data)
        wu, wf, wage, wrisk, wcf = self.weights[1:]
        def score(h):
            u, f, fresh, risk, mean_age, worst_age = data[h]
            # Exact Eq.(11) structure with observable memory/counterfactual terms.
            roll = wu*u + wf*f + wage*freshness_term(worst_age) + wrisk*(1.0-risk) + wcf*(u-base_u)
            memory = 0.0 if self.weights[0] == "W6_memory_off" else max(-.08, min(.08, .35*f - 8*risk + .01*busy_ratio + .01*age_norm))
            cf = max(-.05, min(.05, u-base_u)) if wcf else 0.0
            return roll + memory + cf
        selected = max(pool, key=lambda h: (score(h), h))
        return CommitmentRecord(schema_version=COMMITMENT_SCHEMA_VERSION, observation_hash=canonical_sha256(frame, expected_schema_version=frame.schema_version), action=actions[selected])

def freshness_term(worst_age): return max(0.0, min(1.0, __import__('math').exp(-worst_age/1200.0)))

def task_run(task):
    root, arm, weight = task
    cfg_path = ROOT / CONFIG_LOCATOR
    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    controller = Eq11WeightedController(cfg, weight)
    result = run_open_loop_case(root, TapeArm(arm), controller=controller)
    return {"schema_version":"exp09-weight-endpoint-row-v1","generation":GENERATION,"root_family":root,"arm":arm,"regime":"nominal" if arm=="REFERENCE" else "harm","weight_id":weight[0],"weights":dict(zip(("age","fairness","efficiency","memory","counterfactual"),weight[1:])),"status":"PASSED","metrics":asdict(result.metrics),"integrity_hash":result.integrity_hash,"action_count":len(result.raw_trace.actions),"api_calls":0,"provider_calls":0,"c15_mutated":False}

def bootstrap(vals, seed, n=3000):
    if len(vals)<2: return (vals[0],vals[0])
    import random; r=random.Random(seed); means=[statistics.fmean(vals[r.randrange(len(vals))] for _ in vals) for _ in range(n)]; means.sort(); return means[int(.025*n)],means[int(.975*n)-1]

def main():
    if OUT.exists():
        residual = [p for p in OUT.rglob("*") if p.is_file()]
        if residual: raise SystemExit(f"append-only output exists: {OUT}")
    for d in ("protocol","raw","metrics","statistics","tables"): (OUT/d).mkdir(parents=True)
    cfg = ROOT/CONFIG_LOCATOR
    spec={"schema_version":"exp09-eq11-weight-endpoint-v1","generation":GENERATION,"roots":list(ROOTS),"arms":list(ARMS),"weights":[dict(zip(("weight_id","w_u","w_f","w_age","w_risk","w_counterfactual"),w)) for w in WEIGHTS],"risk_threshold":.35,"memory_clip":[-.08,.08],"counterfactual_cap":[-.05,.05],"config_locator":CONFIG_LOCATOR,"config_sha256":sha(cfg),"controller_path":"actual frozen _FrozenModelStack rollout + Eq.(11) weighted selector","c15_mutated":False,"network":False,"training":False,"tuning":False}
    (OUT/"protocol/spec.json").write_text(json.dumps(spec,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    tasks=[(r,a,w) for r in ROOTS for a in ARMS for w in WEIGHTS]
    rows=[]
    with ProcessPoolExecutor(max_workers=4) as pool:
        fs=[pool.submit(task_run,t) for t in tasks]
        with (OUT/"raw/case_rows.jsonl").open("x",encoding="utf-8") as s:
            for f in as_completed(fs):
                row=f.result(); rows.append(row); s.write(json.dumps(row,ensure_ascii=False,sort_keys=True,separators=(",",":"))+"\n"); s.flush()
    groups={}
    for row in rows: groups.setdefault((row["weight_id"],row["regime"]),[]).append(row)
    summary=[]
    for i,((wid,reg),items) in enumerate(sorted(groups.items())):
        e={"weight_id":wid,"regime":reg,"n_roots":len(items),"endpoint_path":"actual Eq.(11) weighted selector"}
        for key in ("mean_aoi_ms","q95_aoi_ms","jain_freshness","collision_event_rate"):
            vals=[float(x["metrics"][key]) for x in items]; lo,hi=bootstrap(vals,20260813+i); e[key]=statistics.fmean(vals); e[key+"_ci95_low"]=lo; e[key+"_ci95_high"]=hi
        summary.append(e)
    fields=list(summary[0])
    with (OUT/"tables/tableS5_weight_endpoint_sensitivity.csv").open("w",encoding="utf-8-sig",newline="") as s: w=csv.DictWriter(s,fieldnames=fields);w.writeheader();w.writerows(summary)
    (OUT/"metrics/completion.json").write_text(json.dumps({"generation":GENERATION,"planned_rows":56,"completed_rows":len(rows),"failed_rows":0,"api_calls":0,"provider_calls":0,"c15_mutated":False,"endpoint_sensitivity_complete":True,"status":"EQ11_ENDPOINT_SMOKE_COMPLETE"},ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    (OUT/"statistics/summary.json").write_text(json.dumps({"rows":len(rows),"roots":list(ROOTS),"endpoint_path":"actual Eq.(11) weighted selector","interpretation":"validation-only smoke; no retuning or C15 rerun; report metric-wise sensitivity"},ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    claim="# Claim boundary\n\n- 56/56 endpoint rows passed on four paired validation roots using the actual frozen rollout path and Eq.(11)-structured weighted selector.\n- The sweep quantifies metric-wise sensitivity of the validation endpoint to the seven preregistered weight vectors; it does not select a new operating point or alter C15.\n- A weight-robust or optimal-weight claim is not made.\n"
    (OUT/"claim_boundary.md").write_text(claim,encoding="utf-8")
    index={p.relative_to(OUT).as_posix():sha(p) for p in OUT.rglob("*") if p.is_file() and p.name!="sha256_index.json"}; (OUT/"sha256_index.json").write_text(json.dumps(index,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    close={"schema_version":"exp09-weight-endpoint-closeout-v1","generation":GENERATION,"artifact_status":"EQ11_ENDPOINT_SMOKE_COMPLETE","rows":len(rows),"failed_rows":0,"endpoint_sensitivity_complete":True,"c15_mutated":False,"network":False,"claim_boundary":"metric-wise sensitivity only; no robust/optimal claim"}; (OUT/"closeout.json").write_text(json.dumps(close,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8"); print(json.dumps(close,ensure_ascii=False,sort_keys=True))
if __name__=="__main__": main()
