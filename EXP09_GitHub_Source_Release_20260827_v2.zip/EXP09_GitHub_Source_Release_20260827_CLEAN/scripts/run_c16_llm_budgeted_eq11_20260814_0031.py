"""C16 retry using the verified system network path; protocol is unchanged."""
import json, time
from urllib.request import Request, urlopen
import run_c16_llm_budgeted_eq11_20260814_0027 as base

base.GENERATION = "EXP09_SUPPLEMENT_VALIDATION_20260814_0031"
base.OUT = base.ROOT / "paper_outputs" / "exp09_supplement_validation_20260814_0031"

def llm_order_system_path(s, credentials):
    payload = s.public_payload()
    schema = {"type": "object", "additionalProperties": False, "required": ["evaluation_order"], "properties": {"evaluation_order": {"type": "array", "minItems": len(base.CANDIDATES), "maxItems": len(base.CANDIDATES), "items": {"type": "string", "enum": list(base.CANDIDATES)}}}}
    body = {"model": base.MODEL, "messages": [{"role": "system", "content": "You are a constrained SPS supervisor. Select the evaluation order using only the supplied synthetic observable summary. Return every candidate exactly once; do not invent IDs. The first two candidates consume the frozen MPC budget."}, {"role": "user", "content": json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))}], "temperature": 0, "max_tokens": 160, "response_format": {"type": "json_schema", "json_schema": {"name": "c16_evaluation_order", "strict": True, "schema": schema}}}
    request_hash = base.sha_obj(body); started = time.perf_counter(); event = {"scenario_id": s.scenario_id, "request_hash": request_hash, "payload_sha256": base.sha_obj(payload), "status": "FAILED", "response_hash": None, "parsed_response_hash": None, "latency_ms": None, "model_requested": base.MODEL, "api_key_recorded": False}
    try:
        req = Request(f"{credentials.base_url}/chat/completions", data=json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode(), headers={"Authorization": f"Bearer {credentials.api_key}", "Content-Type": "application/json", "Accept": "application/json", "User-Agent": "exp09-c16-synthetic-budgeted/1.0"}, method="POST")
        with urlopen(req, timeout=30) as response: raw = response.read()
        event["response_hash"] = base.sha_bytes(raw); envelope = json.loads(raw.decode()); parsed = json.loads(envelope["choices"][0]["message"]["content"]); order = parsed["evaluation_order"]
        if sorted(order) != sorted(base.CANDIDATES) or len(set(order)) != len(base.CANDIDATES): raise ValueError("invalid permutation")
        event["parsed_response_hash"] = base.sha_obj(parsed); event["status"] = "COMPLETED_AUDITED"; event["model_returned"] = envelope.get("model")
    except Exception as exc:
        event["error_type"] = type(exc).__name__; order = []
    event["latency_ms"] = round((time.perf_counter()-started)*1000,3); return order,event

base.llm_order = llm_order_system_path

if __name__ == "__main__": raise SystemExit(base.main())
