"""C16-B batched transport over the immutable 0027 synthetic scenarios.

The statistical cases, hidden plant, Rule baseline, two-candidate MPC budget,
and exact Eq.(11) selector are inherited unchanged.  Batching is disclosed as
a transport change and each completed batch is appended immediately.
"""
from __future__ import annotations
import csv, hashlib, json, random, statistics, sys, time
from pathlib import Path
from urllib.request import Request, urlopen

import run_c16_llm_budgeted_eq11_20260814_0027 as base

GENERATION = "EXP09_SUPPLEMENT_VALIDATION_20260814_0032"
OUT = base.ROOT / "paper_outputs" / "exp09_supplement_validation_20260814_0032"
SOURCE = base.ROOT / "paper_outputs/exp09_supplement_validation_20260814_0027/protocol/scenarios.jsonl"
BATCH_SIZE = 16


def load_scenarios():
    scenarios = base.make_scenarios()
    source_rows = [json.loads(line) for line in SOURCE.read_text(encoding="utf-8").splitlines() if line]
    if len(source_rows) != len(scenarios): raise RuntimeError("source scenario count drift")
    for s, row in zip(scenarios, source_rows):
        if base.sha_obj(s.public_payload()) != row["payload_sha256"]: raise RuntimeError("source scenario hash drift")
    return scenarios


def call_batch(batch, credentials, batch_id):
    payloads = [s.public_payload() for s in batch]
    item_schema = {"type": "object", "additionalProperties": False, "required": ["scenario_id", "evaluation_order"], "properties": {"scenario_id": {"type": "string", "enum": [s.scenario_id for s in batch]}, "evaluation_order": {"type": "array", "minItems": len(base.CANDIDATES), "maxItems": len(base.CANDIDATES), "items": {"type": "string", "enum": list(base.CANDIDATES)}}}}
    schema = {"type": "object", "additionalProperties": False, "required": ["decisions"], "properties": {"decisions": {"type": "array", "minItems": len(batch), "maxItems": len(batch), "items": item_schema}}}
    body = {"model": base.MODEL, "messages": [{"role": "system", "content": "You are a constrained SPS supervisor. For each independent synthetic scenario, rank every candidate exactly once. The first two consume its frozen MPC budget. Use only that scenario's observable summary; never transfer values between scenarios."}, {"role": "user", "content": json.dumps({"scenarios": payloads}, ensure_ascii=False, sort_keys=True, separators=(",", ":"))}], "temperature": 0, "max_tokens": 3000, "response_format": {"type": "json_schema", "json_schema": {"name": "c16_batched_orders", "strict": True, "schema": schema}}}
    started=time.perf_counter(); event={"batch_id":batch_id,"scenario_ids":[s.scenario_id for s in batch],"request_hash":base.sha_obj(body),"payload_sha256":base.sha_obj(payloads),"status":"FAILED","response_hash":None,"parsed_response_hash":None,"api_key_recorded":False}
    try:
        req=Request(f"{credentials.base_url}/chat/completions",data=json.dumps(body,ensure_ascii=False,sort_keys=True,separators=(",", ":")).encode(),headers={"Authorization":f"Bearer {credentials.api_key}","Content-Type":"application/json","Accept":"application/json","User-Agent":"exp09-c16b-batched/1.0"},method="POST")
        with urlopen(req,timeout=120) as response: raw=response.read()
        event["response_hash"]=base.sha_bytes(raw); envelope=json.loads(raw.decode()); parsed=json.loads(envelope["choices"][0]["message"]["content"]); decisions=parsed["decisions"]
        by_id={d["scenario_id"]:d["evaluation_order"] for d in decisions}
        if set(by_id)!={s.scenario_id for s in batch}: raise ValueError("scenario coverage mismatch")
        for order in by_id.values():
            if sorted(order)!=sorted(base.CANDIDATES) or len(set(order))!=len(base.CANDIDATES): raise ValueError("invalid permutation")
        event["parsed_response_hash"]=base.sha_obj(parsed);event["status"]="COMPLETED_AUDITED";event["model_returned"]=envelope.get("model")
    except Exception as exc:
        event["error_type"]=type(exc).__name__;by_id={}
    event["latency_ms"]=round((time.perf_counter()-started)*1000,3)
    return by_id,event


def bootstrap(diffs, clusters, seed, n=5000):
    groups={}
    for d,c in zip(diffs,clusters):groups.setdefault(c,[]).append(d)
    keys=sorted(groups);rng=random.Random(seed);means=[]
    for _ in range(n):means.append(statistics.fmean(v for k in [rng.choice(keys) for _ in keys] for v in groups[k]))
    means.sort();return statistics.fmean(diffs),means[125],means[4874]


def holm(rows):
    # Paired sign-flip Monte Carlo p values; one global endpoint/regime family.
    rng=random.Random(base.SEED+321); raw=[]
    for row in rows:
        diffs=row.pop("_diffs");obs=abs(statistics.fmean(diffs));hits=1
        for _ in range(20000):
            value=abs(statistics.fmean(d if rng.random()<.5 else -d for d in diffs))
            hits+=value>=obs
        p=hits/20001;row["raw_p_value"]=p;raw.append(p)
    order=sorted(range(len(rows)),key=lambda i:raw[i]);running=0
    for rank,i in enumerate(order):running=max(running,min(1.0,raw[i]*(len(rows)-rank)));rows[i]["holm_adjusted_p"]=running


def main():
    if OUT.exists() and any(p.is_file() for p in OUT.rglob("*")):raise SystemExit(f"append-only output exists: {OUT}")
    for d in ("protocol","raw","metrics","statistics","tables"): (OUT/d).mkdir(parents=True,exist_ok=True)
    scenarios=load_scenarios();credentials=base.load_provider_credentials(base.API_ENV,profile="primary")
    spec={"schema_version":"exp09-c16b-v1","generation":GENERATION,"source_scenarios":str(SOURCE.relative_to(base.ROOT)).replace('\\','/'),"source_scenarios_sha256":base.sha_file(SOURCE),"scenario_count":len(scenarios),"batch_size":BATCH_SIZE,"batching_disclosed":True,"transport_only_change":True,"mpc_budget":base.MPC_BUDGET,"rule_baseline":"unchanged from 0027","hidden_plant":"unchanged from 0027","exact_eq11":"unchanged from 0027","c15_read":False,"c15_mutated":False,"payload":"synthetic only"}
    (OUT/"protocol/spec.json").write_text(json.dumps(spec,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    all_rows=[];events=[]
    with (OUT/"raw/batch_events.jsonl").open("x",encoding="utf-8") as es,(OUT/"raw/case_rows.jsonl").open("x",encoding="utf-8") as rs:
        for start in range(0,len(scenarios),BATCH_SIZE):
            batch=scenarios[start:start+BATCH_SIZE];orders,event=call_batch(batch,credentials,f"batch_{start//BATCH_SIZE:02d}");events.append(event);es.write(json.dumps(event,ensure_ascii=False,sort_keys=True,separators=(",", ":"))+"\n");es.flush()
            for s in batch:
                order=orders.get(s.scenario_id);rule_ids=base.rule_subset(s);oracle_ids=base.oracle_subset(s)
                row={"generation":GENERATION,"scenario_id":s.scenario_id,"cluster_id":s.cluster_id,"regime":s.regime,"status":"PASSED" if order else "FAILED_RETAINED","llm_order":order,"rule_evaluation_ids":rule_ids,"llm":base.evaluate_subset(s,order[:base.MPC_BUDGET]) if order else None,"rule":base.evaluate_subset(s,rule_ids),"oracle":base.evaluate_subset(s,oracle_ids),"c15_mutated":False}
                all_rows.append(row);rs.write(json.dumps(row,ensure_ascii=False,sort_keys=True,separators=(",", ":"))+"\n");rs.flush()
    passed=[r for r in all_rows if r["status"]=="PASSED"]
    effects=[]
    if len(passed)==len(scenarios):
        for regime in sorted({r["regime"] for r in passed}|{"all"}):
            group=passed if regime=="all" else [r for r in passed if r["regime"]==regime]
            for metric in base.METRICS:
                diffs=[float(r["llm"][metric])-float(r["rule"][metric]) for r in group];mean,lo,hi=bootstrap(diffs,[r["cluster_id"] for r in group],base.SEED+len(effects));effects.append({"regime":regime,"metric":metric,"n":len(diffs),"llm_minus_rule":mean,"ci95_low":lo,"ci95_high":hi,"_diffs":diffs})
        holm(effects)
        with (OUT/"statistics/llm_rule_paired_effects.csv").open("w",encoding="utf-8-sig",newline="") as f:w=csv.DictWriter(f,fieldnames=list(effects[0]));w.writeheader();w.writerows(effects)
        summary=[]
        for method in ("rule","llm","oracle"):
            item={"method":method,"n":len(passed)}
            for metric in base.METRICS:item[metric]=statistics.fmean(r[method][metric] for r in passed)
            summary.append(item)
        with (OUT/"tables/tableS8_llm_budgeted_contribution.csv").open("w",encoding="utf-8-sig",newline="") as f:w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
    completion={"generation":GENERATION,"planned_cases":len(scenarios),"completed_cases":len(passed),"failed_cases":len(scenarios)-len(passed),"batches":len(events),"completed_batches":sum(e["status"]=="COMPLETED_AUDITED" for e in events),"api_calls":len(events),"c15_read":False,"c15_mutated":False}
    (OUT/"metrics/completion.json").write_text(json.dumps(completion,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    claim="# Claim boundary\n\n- This is a disclosed batched synthetic supervisor experiment over the immutable 0027 scenarios; it is not a C15 rerun.\n- A successful result estimates LLM-vs-rule candidate-ordering effects under a two-candidate MPC budget with the same evaluator, Eq.(11), safety threshold, fallback, and hidden plant.\n- It supports only a bounded-budget synthetic mechanism claim, not LLM causal gain on C15 or deployment performance.\n- Batching may introduce cross-case context and is reported as a limitation.\n"
    (OUT/"claim_boundary.md").write_text(claim,encoding="utf-8")
    close={"schema_version":"exp09-c16b-closeout-v1","generation":GENERATION,"artifact_status":"C16B_COMPLETE" if len(passed)==len(scenarios) else "C16B_PARTIAL","planned_cases":len(scenarios),"completed_cases":len(passed),"failed_cases":len(scenarios)-len(passed),"api_calls":len(events),"c15_read":False,"c15_mutated":False,"batching_disclosed":True}
    (OUT/"closeout.json").write_text(json.dumps(close,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    idx={p.relative_to(OUT).as_posix():base.sha_file(p) for p in OUT.rglob("*") if p.is_file() and p.name!="sha256_index.json"};(OUT/"sha256_index.json").write_text(json.dumps(idx,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(close,ensure_ascii=False,sort_keys=True));return 0 if len(passed)==len(scenarios) else 2

if __name__=="__main__":raise SystemExit(main())
