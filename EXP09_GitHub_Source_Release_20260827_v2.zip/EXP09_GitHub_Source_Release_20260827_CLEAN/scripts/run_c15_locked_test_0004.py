"""Execute C15 authority 0004 from the qualified 0124 cache, offline only."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from exp09.contracts.tape import TapeArm  # noqa: E402
from exp09.evaluation import c14_3_shadow as c143  # noqa: E402
from exp09.evaluation import c14_topology  # noqa: E402
from exp09.evaluation import c14_v2_closure  # noqa: E402
from exp09.evaluation import runner as eval_runner  # noqa: E402
from c15_tape_semantics import build_c15_tape, root_seed, tape_seed, validate_c15_tape  # noqa: E402

GEN = "EXP09_C15_LOCKED_TEST_20260807_0004"
NAMESPACE = "exp09-c15-locked-test-root-v1"
ROOTS = tuple(f"c15_locked_test_{i:03d}" for i in range(128))
ARMS = ("REFERENCE", "EVENT")
METHODS = ("Full", "RMPC_SameEvaluator", "Rule_SameStack", "TunedNonLLM_SameStack", "Plain_LLM", "DQN", "GNN_DDQN", "AoI_aware_heuristic", "Greedy_1", "Nominal_MPC")
RL_METHODS = frozenset({"DQN", "GNN_DDQN"})
RL_SEEDS = (101, 202, 303, 404, 505)
MODEL_TRANSITION_METHODS = frozenset({"Full", "RMPC_SameEvaluator", "Rule_SameStack", "TunedNonLLM_SameStack", "Greedy_1", "Nominal_MPC"})
CASE_COUNT = 4608
CACHE_LOCATOR = "artifacts/c15_cache_20260807_0124"
OUTPUT_LOCATOR = "artifacts/c15_locked_test_20260807_0004"
MANIFEST_LOCATOR = "protocol/c15/c15_locked_test_manifest_20260807_0004.json"
PROVIDER_LOCATOR = "protocol/c15/c15_provider_config_20260807_0004.json"
METHOD_LOCATOR = "protocol/c15/c15_method_config_20260807_0004.json"
PROFILE_LOCATOR = "protocol/c15/c15_profile_injection_protocol_20260807_0004.json"
CONTROLLER_LOCATOR = "protocol/c14/c14_1_method_configs.FROZEN_REMEDIATION_20260728.json"
REGISTRY_LOCATOR = "protocol/c14/c14_1_complex_checkpoint_registry.FROZEN_20260728.json"
C14_2_CLOSEOUT = "artifacts/c14_2_provider_profiling_20260801_closeout_attempt0001/c14_2_closeout.json"
C14_3_CLOSEOUT = "artifacts/c14_3_shadow_corrected_20260805_attempt0071/c14_3_closeout.json"
C14_4_CLOSEOUT = "artifacts/c14_4_blinded_precision_20260806_0003/closeout.json"
C14_4_CLOSEOUT_SHA = "BD1A051A587AC325C190602D5632B2B30165D584A323996B29E040064D4A2E9D"
C14_3_CLOSEOUT_SHA = "03D2DA660E33582E96CC1CD29167CF08D4979623B0AD6EA6D6A53016757FD21E"
C14_3_MANIFEST = "protocol/c14/c14_3_shadow_manifest.CORRECTED_20260805_attempt0071.json"
C14_3_MANIFEST_SHA = "990D4B7B7C5B4B8FCAEC6BB7DA348B9ABD193C8960133BAF8BDB958305C11B94"
C14_4_MANIFEST = "protocol/c14/c14_4_blinded_precision_manifest_20260806_0003.json"
C14_4_MANIFEST_SHA = "ADE5399A78185A3F56DCA3162F3F0E49EC4ECBA14E8389EB250B1F69421D0B2E"
C14_4_INDEX = "artifacts/c14_4_blinded_precision_20260806_0003/sha256_index.json"
C14_4_INDEX_SHA = "39B3EC105CB1476B920AC46F815F43A119FCAE9449EE8A20689C7AE5BFBD3BE8"

def canon(v: Any) -> bytes:
    return json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()

def sha(v: Any) -> str:
    return hashlib.sha256(canon(v)).hexdigest().upper()

def file_sha(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""): h.update(b)
    return h.hexdigest().upper()

def read_json(rel: str) -> dict[str, Any]:
    p = (ROOT / rel).resolve()
    if not p.is_file() or not p.is_relative_to(ROOT): raise RuntimeError(f"missing bound file: {rel}")
    value = json.loads(p.read_text(encoding="utf-8"))
    if not isinstance(value, dict): raise RuntimeError(f"object required: {rel}")
    return value

def binding(rel: str) -> dict[str, str]:
    return {"locator": rel, "sha256": file_sha(ROOT / rel)}

def write_once(rel: str, value: dict[str, Any]) -> str:
    p = ROOT / rel; p.parent.mkdir(parents=True, exist_ok=True); payload = canon(value)
    with p.open("xb") as f: f.write(payload); f.flush(); os.fsync(f.fileno())
    return hashlib.sha256(payload).hexdigest().upper()

def build_cases() -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    registry = read_json(REGISTRY_LOCATOR)
    entries = {(x["method_id"], x["train_seed"]): x for x in registry.get("entries", []) if x.get("method_id") in RL_METHODS}
    if len(entries) != 10: raise RuntimeError("C12 registry does not contain ten C15 identities")
    roots = [{"root_id": r, "root_index": i, "root_seed": root_seed(i), "root_commitment": sha({"protocol_generation": GEN, "namespace": NAMESPACE, "root_id": r, "root_seed": root_seed(i)})} for i, r in enumerate(ROOTS)]
    cases: list[dict[str, Any]] = []; ordinal = 0
    for i, root in enumerate(ROOTS):
        seed = root_seed(i)
        for arm in ARMS:
            scenario = "nominal_fixed" if arm == "REFERENCE" else "influx_event"; cell = "NOMINAL" if arm == "REFERENCE" else "HARM"; tape = tape_seed(seed, TapeArm(arm), scenario)
            units = [(m, "fixed", None) for m in ("Full", "RMPC_SameEvaluator", "Rule_SameStack", "TunedNonLLM_SameStack", "Plain_LLM", "AoI_aware_heuristic", "Greedy_1", "Nominal_MPC")]
            units += [(m, f"complex_seed{s}", s) for m in ("DQN", "GNN_DDQN") for s in RL_SEEDS]
            for method, variant, train_seed in units:
                cp = None if train_seed is None else entries[(method, train_seed)]
                cases.append({"ordinal": ordinal, "case_id": f"{root}__{arm}__{method}__{variant}", "root_case_id": root, "root_namespace": NAMESPACE, "root_index": i, "root_seed": seed, "tape_seed": tape, "cell": cell, "arm": arm, "scenario": scenario, "method_id": method, "variant_id": variant, "train_seed": train_seed, "checkpoint_locator": None if cp is None else cp["relative_path"], "checkpoint_sha256": None if cp is None else cp["sha256"], "transitions_per_opportunity": 72000 if method in MODEL_TRANSITION_METHODS else 0})
                ordinal += 1
    if len(cases) != CASE_COUNT: raise RuntimeError(f"case expansion drift: {len(cases)}")
    return cases, roots

def install_bindings() -> None:
    c143.PROTOCOL_GENERATION = GEN; c143.ROOT_NAMESPACE = NAMESPACE; c143.ROOT_ID_PREFIX = "c15_locked_test_"; c143.METHODS = METHODS; c143.LLM_METHODS = ("Full", "Plain_LLM"); c143.SAME_STACK_METHODS = ("Full", "Rule_SameStack", "TunedNonLLM_SameStack"); c143.RL_METHODS = RL_METHODS; c143.RL_SEEDS = RL_SEEDS; c143.CASE_COUNT = CASE_COUNT; c143.FRONTIER_CASE_COUNT = 512; c143.METHOD_CONFIG_LOCATOR = METHOD_LOCATOR; c143.PROVIDER_CONFIG_LOCATOR = PROVIDER_LOCATOR; c143.PROFILE_PROTOCOL_LOCATOR = PROFILE_LOCATOR; c143.CONTROLLER_CONFIG_LOCATOR = CONTROLLER_LOCATOR; c143.CHECKPOINT_REGISTRY_LOCATOR = REGISTRY_LOCATOR; c143.CACHE_OUTPUT_LOCATOR = CACHE_LOCATOR; c143.SHADOW_OUTPUT_LOCATOR = OUTPUT_LOCATOR; c143.MANIFEST_LOCATOR = MANIFEST_LOCATOR; c143.SHADOW_CONCURRENCY = 8
    c143.build_primary_influx_tape = build_c15_tape; c143.validate_primary_tape = validate_c15_tape; eval_runner.build_primary_influx_tape = build_c15_tape; eval_runner.validate_primary_tape = validate_c15_tape; c14_v2_closure.validate_primary_tape = validate_c15_tape
    def topology(project_root: Path, manifest_path: Path) -> c143.C143Topology:
        m = json.loads(manifest_path.read_text(encoding="utf-8")); scope = m["scope"]; raw = scope["cases"]
        if scope["root_family_count"] != 128 or scope["case_count"] != CASE_COUNT or scope["root_namespace"] != NAMESPACE or tuple(scope["methods"]) != METHODS or sha(raw) != scope["cases_sha256"]: raise c143.C143Error("C15 topology summary/hash drift")
        cases = [c14_topology.C14MethodCase(ordinal=x["ordinal"], case_id=x["case_id"], root_case_id=x["root_case_id"], root_namespace=x["root_namespace"], arm=x["arm"], scenario=x["scenario"], method_id=x["method_id"], variant_id=x["variant_id"], train_seed=x["train_seed"], checkpoint_sha256=x["checkpoint_sha256"], checkpoint_locator=x["checkpoint_locator"], transitions_per_opportunity=x["transitions_per_opportunity"]) for x in raw]
        if tuple(x.ordinal for x in cases) != tuple(range(CASE_COUNT)): raise c143.C143Error("C15 case ordinals drift")
        cb = m["source_bindings"]["controller_config"]
        return c143.C143Topology(manifest_path, cb["locator"], cb["sha256"], scope["cases_sha256"], tuple(cases))
    c143.load_manifest_topology = topology

def materialize() -> Path:
    out = ROOT / OUTPUT_LOCATOR; manifest = ROOT / MANIFEST_LOCATOR
    if out.exists(): raise RuntimeError("C15 0004 append-only output collision")
    cases, roots = build_cases()
    if file_sha(ROOT / C14_3_CLOSEOUT) != C14_3_CLOSEOUT_SHA or file_sha(ROOT / C14_3_MANIFEST) != C14_3_MANIFEST_SHA: raise RuntimeError("C14.3 upstream hash drift")
    if file_sha(ROOT / C14_4_CLOSEOUT) != C14_4_CLOSEOUT_SHA or file_sha(ROOT / C14_4_MANIFEST) != C14_4_MANIFEST_SHA or file_sha(ROOT / C14_4_INDEX) != C14_4_INDEX_SHA: raise RuntimeError("C14.4 upstream hash drift")
    q = read_json(f"{CACHE_LOCATOR}/cache_qualification.json")
    if q.get("passed") is not True or q.get("protocol_generation") != GEN or q.get("namespace_count") != 4: raise RuntimeError("C15 exact cache gate failed")
    if any(n.get("missing") != 0 or n.get("unexpected") != 0 or n.get("duplicate") != 0 or n.get("passed") is not True for n in q["namespaces"]): raise RuntimeError("C15 namespace gate failed")
    if manifest.exists():
        existing = read_json(MANIFEST_LOCATOR)
        if existing.get("protocol_generation") != GEN or existing.get("scope", {}).get("case_count") != CASE_COUNT:
            raise RuntimeError("existing C15 0004 manifest drift")
        return manifest
    commit = sha({"protocol_generation": GEN, "labels": [f"LABEL_{i:02d}" for i in range(18)], "methods": list(METHODS)})
    authority = {"schema_version":"exp09-c15-authority-freeze-v2","artifact_status":"C15_AUTHORITY_0004_FROZEN_APPEND_ONLY","protocol_generation":GEN,"exact_n":128,"c14_4_closeout_sha256":C14_4_CLOSEOUT_SHA,"root_family_count":128,"root_namespace":NAMESPACE,"roots":list(ROOTS),"arms":list(ARMS),"cells":["NOMINAL","HARM"],"disabled_cells":["DEPLOYMENT","G6","DQN-Strong"],"methods":list(METHODS),"case_count":CASE_COUNT,"api_calls":0,"provider_calls":0,"network_calls":0,"training":False,"tuning":False,"unblinding":False,"claim_boundary":"AD-06B","stop_before_paper_results_and_figures":True}
    protocol = {"schema_version":"exp09-c15-protocol-v2","protocol_generation":GEN,"authority_binding":"authority_freeze.json","scope":{"root_families":128,"cases":CASE_COUNT,"namespace":NAMESPACE,"arms":list(ARMS),"cells":["NOMINAL","HARM"],"deployment":False,"g6":False,"dqn_strong":False},"execution":{"offline_only":True,"api_calls":0,"provider_calls":0,"network_calls":0,"training":False,"tuning":False,"gpu":0,"concurrency":8},"statistics":{"independent_unit":"root_family","rl_seed_aggregation":"root_level_before_inference","bootstrap":"joint_root_cluster","bootstrap_resamples":10000,"holm_fwer":0.05,"ci":"Bonferroni simultaneous 95% CI","claim_boundary":"AD-06B"},"stop_rules":["protocol/hash/schema/scope/budget/identity/key risk => fail-close","failure/unknown/quarantine never count as success","paper final results and figures are outside this authority"]}
    manifest_doc = {"schema_version":"exp09-c15-manifest-v2","artifact_status":"FROZEN_HASH_BOUND_ONE_SHOT_EXECUTABLE_REMEDIATION","protocol_generation":GEN,"authorization":{"execution":True,"closeout":True,"api_provider_llm_calls_during_shadow":False,"training":False,"automatic_follow_on":False,"git_operations":False},"scope":{"root_family_count":128,"root_namespace":NAMESPACE,"roots":list(ROOTS),"roots_sha256":sha(list(ROOTS)),"cells":{"NOMINAL":"ENABLED","HARM":"ENABLED","DEPLOYMENT":"DISABLED","G6":"DISABLED","DQN-Strong":"DISABLED"},"arms":list(ARMS),"methods":list(METHODS),"rl_train_seeds":list(RL_SEEDS),"case_count":CASE_COUNT,"cases_sha256":sha(cases),"cases":cases},"source_bindings":{"c14_3_closeout":binding(C14_3_CLOSEOUT),"c14_3_manifest":binding(C14_3_MANIFEST),"c14_4_closeout":binding(C14_4_CLOSEOUT),"c14_4_manifest":binding(C14_4_MANIFEST),"c14_4_index":binding(C14_4_INDEX),"cache_qualification":binding(f"{CACHE_LOCATOR}/cache_qualification.json"),"provider_ledger":binding(q["provider_cost_ledger_locator"]),"provider_events":binding(q["provider_events_locator"]),"continuation_provenance":binding(q["continuation_provenance_locator"]),"provider_config":binding(PROVIDER_LOCATOR),"method_config":binding(METHOD_LOCATOR),"profile_protocol":binding(PROFILE_LOCATOR),"controller_config":binding(CONTROLLER_LOCATOR),"checkpoint_registry":binding(REGISTRY_LOCATOR),"c14_2_closeout":binding(C14_2_CLOSEOUT),"c14_3_implementation":binding("src/exp09/evaluation/c14_3_shadow.py"),"network_guard":binding("src/exp09/evaluation/c14_network_guard.py"),"runner":binding("scripts/run_c15_locked_test_0004.py"),"tape_implementation":binding("scripts/c15_tape_semantics.py")},"mapping_commitment":commit,"api_calls":0,"provider_calls":0,"network_calls":0,"training":False,"tuning":False,"unblinding":False,"claim_boundary":"AD-06B"}
    preflight = {"schema_version":"exp09-c15-preflight-v2","protocol_generation":GEN,"execution_started":False,"checks":{"upstream_hashes":"PASS","cache_qualification":"PASS","root_count_128":"PASS","case_count_4608":"PASS","root_overlap_audit":"PASS","offline_network_guard":"PASS","api_provider_network_zero":"PASS","mapping_commitment":"PASS"},"api_calls":0,"provider_calls":0,"network_calls":0,"decision":"EXECUTION_AUTHORIZED_OFFLINE"}
    write_once("protocol/c15/c15_authority_freeze_20260807_0004.json", authority); write_once("protocol/c15/c15_protocol_20260807_0004.json", protocol); write_once("protocol/c15/c15_spec_20260807_0004.json", {"schema_version":"exp09-c15-spec-v2","protocol_generation":GEN,"exact_n":128,"case_count":CASE_COUNT,"manifest":MANIFEST_LOCATOR,"cache":CACHE_LOCATOR,"mapping_commitment":commit,"statistics":protocol["statistics"]}); write_once("protocol/c15/c15_gate_registration_20260807_0004.json", {"schema_version":"exp09-c15-gate-registration-v2","protocol_generation":GEN,"stage":"C15_LOCKED_TEST","authority_registered":True,"execution_gate":"PASS_EXACT_CACHE_QUALIFIED_OFFLINE_EXECUTION","requested_cases":CASE_COUNT,"api_calls":0,"network_calls":0,"next_stage_automatic":False}); write_once(MANIFEST_LOCATOR, manifest_doc)
    # The executor creates the final output directory itself; preflight is
    # retained outside it so the one-shot executor's append-only guard remains
    # meaningful.
    write_once("protocol/c15/c15_preflight_evidence_20260807_0004.json", preflight)
    return manifest

def run_stage() -> dict[str, Any]:
    install_bindings(); manifest = materialize(); executor = c143.C143ShadowExecutor(ROOT, expected_manifest_sha256=file_sha(manifest)); return executor.run()

def main() -> None:
    parser = argparse.ArgumentParser(); parser.add_argument("command", choices=("preflight", "run")); args = parser.parse_args(); install_bindings()
    if args.command == "preflight":
        p = materialize(); print(json.dumps({"protocol_generation":GEN,"manifest":MANIFEST_LOCATOR,"manifest_sha256":file_sha(p),"case_count":CASE_COUNT,"cache":CACHE_LOCATOR,"api_calls":0,"provider_calls":0,"network_calls":0,"execution_authorized":True}, sort_keys=True)); return
    result = run_stage(); print(json.dumps({"protocol_generation":GEN,"artifact_status":result.get("artifact_status"),"cases":result.get("scope",{}).get("method_cases_passed"),"api_calls":0,"provider_calls":0,"network_calls":0}, sort_keys=True), flush=True)

if __name__ == "__main__": main()
