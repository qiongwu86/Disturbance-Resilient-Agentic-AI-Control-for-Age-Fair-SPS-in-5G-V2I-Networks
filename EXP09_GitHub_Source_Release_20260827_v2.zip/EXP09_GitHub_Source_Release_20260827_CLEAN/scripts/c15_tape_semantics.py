"""C15-specific deterministic disturbance tape semantics.

The legacy C14 tape builder keys exogenous draws by the global C03 generation
and root id.  C15 binds the root and tape seeds explicitly, so cache requests
must be generated from this builder rather than by changing only manifest
metadata.  The module is imported by C15 runners and is intentionally
append-only: it does not rewrite any prior generation or evidence.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import replace
from typing import Any

from exp09.contracts import tape as tape_contract
from exp09.contracts.ids import RootCaseId, TapeId, VehicleId
from exp09.contracts.tape import (
    CounterNamespace,
    DisturbanceTape,
    TapeArm,
    TapeArrival,
    TapeChannelDraw,
    TapeCounter,
    TapeReselection,
    TAPE_ARRIVAL_SCHEMA_VERSION,
    TAPE_CHANNEL_DRAW_SCHEMA_VERSION,
    TAPE_COUNTER_SCHEMA_VERSION,
    TAPE_RESELECTION_SCHEMA_VERSION,
    DISTURBANCE_TAPE_SCHEMA_VERSION,
)
from exp09.contracts.time import SimTimeUs
from exp09.evaluation import disturbance_tape as legacy


GENERATION = "EXP09_C15_LOCKED_TEST_20260807_0004"
ROOT_NAMESPACE = "exp09-c15-locked-test-root-v1"


def root_seed(index: int) -> int:
    digest = hashlib.sha256(f"{GENERATION}|root|{index:03d}".encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big") & 0xFFFFFFFF


def tape_seed(seed: int, arm: TapeArm, scenario: str) -> int:
    digest = hashlib.sha256(f"{seed}|{arm.value}|{scenario}".encode("utf-8")).digest()
    return int.from_bytes(digest[:4], "big")


def _config_hash(root_case_id: str, seed: int, arm: TapeArm, scenario: str, tape: int) -> str:
    primitive = {
        "schema_version": "exp09-c15-tape-config-v1",
        "protocol_generation": GENERATION,
        "root_namespace": ROOT_NAMESPACE,
        "root_case_id": root_case_id,
        "root_seed": seed,
        "arm": arm.value,
        "scenario": scenario,
        "tape_seed": tape,
        "legacy_tape_config_schema": legacy.TAPE_CONFIG_SCHEMA_VERSION,
    }
    payload = json.dumps(primitive, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest().upper()


def _materialize(root_case_id: str, arm: TapeArm, seed: int, tape: int) -> DisturbanceTape:
    scenario = "nominal_fixed" if arm is TapeArm.REFERENCE else "influx_event"
    # Include every frozen C15 identity field in the keyed RNG root.  This is
    # deliberately different from the legacy C14 generation/root-only key.
    rng = legacy._TapeKeyedRng(GENERATION, ROOT_NAMESPACE, root_case_id, seed, arm.value, scenario, tape, "primary_influx")
    hidden_onset_analysis_tau_us = legacy.ONSET_ANALYSIS_TAU_CANDIDATES_US[
        rng.draw_uint("onset", 0, len(legacy.ONSET_ANALYSIS_TAU_CANDIDATES_US))
    ]
    hidden_onset_simulation_time_us = legacy.ANALYSIS_ORIGIN_SIMULATION_TIME_US + hidden_onset_analysis_tau_us

    vehicles: list[Any] = []
    arrivals: list[Any] = []
    for index in range(6):
        vehicle_id = f"vehicle_{index}"
        vehicles.append(
            legacy._vehicle(
                rng,
                vehicle_id=vehicle_id,
                key=vehicle_id,
                arrival_simulation_time_us=legacy.SIMULATION_START_US,
                last_success_generation_us=-legacy.PACKET_PERIOD_US - rng.draw_uint(
                    f"pre_entry:vehicle_{index}", 0, legacy.PACKET_PERIOD_US
                ),
            )
        )
    for vehicle_index in range(6, 9):
        vehicle_id = f"vehicle_{vehicle_index}"
        vehicles.append(
            legacy._vehicle(
                rng,
                vehicle_id=vehicle_id,
                key=vehicle_id,
                arrival_simulation_time_us=hidden_onset_simulation_time_us,
                last_success_generation_us=hidden_onset_simulation_time_us
                - legacy.PACKET_PERIOD_US
                - rng.draw_uint(f"pre_entry:{vehicle_id}", 0, legacy.PACKET_PERIOD_US),
            )
        )
        arrivals.append(
            TapeArrival(
                schema_version=TAPE_ARRIVAL_SCHEMA_VERSION,
                vehicle_id=VehicleId(vehicle_id),
                simulation_time_us=SimTimeUs(hidden_onset_simulation_time_us),
                analysis_tau_us=hidden_onset_analysis_tau_us,
            )
        )

    reselections = tuple(
        TapeReselection(
            schema_version=TAPE_RESELECTION_SCHEMA_VERSION,
            vehicle_id=VehicleId(f"vehicle_{vehicle_index}"),
            ordinal=ordinal,
            grant=legacy._grant(rng, f"background:vehicle_{vehicle_index}:{ordinal}"),
        )
        for vehicle_index in range(1, 9)
        for ordinal in range(legacy.BACKGROUND_RESELECTION_COUNT)
    )
    channel_draws = tuple(
        TapeChannelDraw(
            schema_version=TAPE_CHANNEL_DRAW_SCHEMA_VERSION,
            vehicle_id=VehicleId(f"vehicle_{vehicle_index}"),
            ordinal=ordinal,
            uniform_u64=int(
                legacy._fast_stable_digest_hex(
                    GENERATION, ROOT_NAMESPACE, root_case_id, seed, arm.value, scenario, tape,
                    "channel_error", f"vehicle_{vehicle_index}", ordinal
                )[:16],
                16,
            ),
        )
        for vehicle_index in range(9)
        for ordinal in range(legacy.CHANNEL_DRAW_COUNT_PER_VEHICLE)
    )
    counters = tuple(
        TapeCounter(
            schema_version=TAPE_COUNTER_SCHEMA_VERSION,
            vehicle_id=VehicleId(f"vehicle_{vehicle_index}"),
            counter_namespace=namespace,
            counter_ordinal=ordinal,
            value=5
            + int(
                legacy._fast_stable_digest_hex(
                    GENERATION, ROOT_NAMESPACE, root_case_id, seed, arm.value, scenario, tape,
                    f"vehicle_{vehicle_index}", namespace.value, ordinal
                )[:16],
                16,
            )
            % 11,
        )
        for vehicle_index in range(9)
        for namespace, ordinals in (
            (CounterNamespace.INITIAL, (0,)),
            (CounterNamespace.REBUILD, range(1, legacy.REBUILD_COUNTER_COUNT_PER_VEHICLE + 1)),
        )
        for ordinal in ordinals
    )

    if arm is TapeArm.REFERENCE:
        vehicles = vehicles[: legacy.PRIMARY_REFERENCE_POPULATION]
        arrivals = []
        shared_ids = {str(vehicle.vehicle_id) for vehicle in vehicles}
        counters = [item for item in counters if str(item.vehicle_id) in shared_ids]

    # DisturbanceTape's contract is generation-bound.  Patch only the current
    # Python process so C15 tapes are validated against the C15 generation;
    # no source or prior artifact is modified.
    tape_contract.PROTOCOL_GENERATION_ID = GENERATION
    legacy.PROTOCOL_GENERATION_ID = GENERATION
    value = DisturbanceTape(
        schema_version=DISTURBANCE_TAPE_SCHEMA_VERSION,
        protocol_generation=GENERATION,
        tape_id=TapeId("UNBOUND"),
        root_case_id=RootCaseId(root_case_id),
        arm=arm,
        config_hash=_config_hash(root_case_id, seed, arm, scenario, tape),
        simulation_start_us=SimTimeUs(legacy.SIMULATION_START_US),
        simulation_end_us=SimTimeUs(legacy.SIMULATION_END_US),
        analysis_origin_simulation_time_us=SimTimeUs(legacy.ANALYSIS_ORIGIN_SIMULATION_TIME_US),
        analysis_tau_start_us=SimTimeUs(legacy.ANALYSIS_TAU_START_US),
        analysis_tau_end_us=SimTimeUs(legacy.ANALYSIS_TAU_END_US),
        paired_anchor_simulation_time_us=SimTimeUs(hidden_onset_simulation_time_us),
        paired_anchor_analysis_tau_us=SimTimeUs(hidden_onset_analysis_tau_us),
        packet_period_us=legacy.PACKET_PERIOD_US,
        slot_duration_us=legacy.SLOT_DURATION_US,
        logical_subchannel_count=legacy.LOGICAL_SUBCHANNEL_COUNT,
        controlled_vehicle_id=VehicleId("vehicle_0"),
        vehicles=tuple(vehicles),
        arrivals=tuple(arrivals),
        background_reselections=reselections,
        channel_draws=channel_draws,
        counters=tuple(counters),
    )
    return replace(value, tape_id=TapeId(legacy._expected_tape_id(value)))


def build_c15_tape(root_case_id: str, arm: TapeArm) -> DisturbanceTape:
    if not root_case_id.startswith("c15_locked_test_"):
        raise ValueError("C15 tape requires a frozen C15 root id")
    try:
        index = int(root_case_id.rsplit("_", 1)[1])
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid C15 root id") from exc
    if not 0 <= index < 128:
        raise ValueError("C15 root index outside frozen scope")
    if not isinstance(arm, TapeArm):
        arm = TapeArm(arm)
    seed = root_seed(index)
    scenario = "nominal_fixed" if arm is TapeArm.REFERENCE else "influx_event"
    return _materialize(root_case_id, arm, seed, tape_seed(seed, arm, scenario))


def validate_c15_tape(tape: DisturbanceTape) -> None:
    expected = build_c15_tape(str(tape.root_case_id), tape.arm)
    if tape != expected:
        raise ValueError("C15 tape does not match frozen root/tape seed semantics")

