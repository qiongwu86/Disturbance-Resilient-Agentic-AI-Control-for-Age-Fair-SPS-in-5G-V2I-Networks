"""Freeze the deterministic 18-unit to 10-method mapping opening."""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
STAGE = Path(tempfile.gettempdir()) / "exp09_c15_mapping_opening_20260811_0002"
OUT = STAGE / "artifacts/c15_mapping_release_20260811_0002"
MANIFEST = ROOT / "protocol/c15/c15_locked_test_manifest_20260807_0018.json"
RELEASE = ROOT / "artifacts/c15_mapping_release_20260811_0002/mapping_release.json"
MAP_PROTOCOL = ROOT / "protocol/c15/c15_mapping_release_20260811_0002.json"
COMMITMENT = "3C90BB339A4980386C1C6D07E9994BF2B1E4F9C14F1B39F628FA8AB995C1CE9B"
GEN = "EXP09_C15_MAPPING_RELEASE_20260811_0002"
SOURCE_GEN = "EXP09_C15_LOCKED_TEST_20260807_0004"
METHODS = ("Full", "RMPC_SameEvaluator", "Rule_SameStack", "TunedNonLLM_SameStack", "Plain_LLM", "DQN", "GNN_DDQN", "AoI_aware_heuristic", "Greedy_1", "Nominal_MPC")
RL = {"DQN", "GNN_DDQN"}
SEEDS = (101, 202, 303, 404, 505)


def canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def sha_file(path: Path) -> str:
    h = hashlib.sha256();
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""): h.update(block)
    return h.hexdigest().upper()


def write_once(path: Path, value: dict[str, Any]) -> str:
    payload = canonical(value); path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != payload: raise RuntimeError(f"append-only drift: {path}")
    else:
        with path.open("xb") as stream: stream.write(payload); stream.flush(); os.fsync(stream.fileno())
    return hashlib.sha256(payload).hexdigest().upper()


def main() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8")); release = json.loads(RELEASE.read_text(encoding="utf-8")); protocol = json.loads(MAP_PROTOCOL.read_text(encoding="utf-8"))
    if manifest.get("protocol_generation") != SOURCE_GEN or manifest.get("mapping_commitment") != COMMITMENT: raise RuntimeError("source commitment drift")
    units = []
    for method in METHODS:
        if method in RL:
            units.extend({"anonymous_label": f"LABEL_{METHODS.index(method):02d}", "method_id": method, "train_seed": seed} for seed in SEEDS)
        else:
            units.append({"anonymous_label": f"LABEL_{METHODS.index(method):02d}", "method_id": method, "train_seed": None})
    if len(units) != 18: raise RuntimeError("18-unit topology drift")
    method_mapping = [{"anonymous_label": f"LABEL_{i:02d}", "method_id": method} for i, method in enumerate(METHODS)]
    opening = {"schema_version": "exp09-c15-mapping-opening-v1", "artifact_status": "C15_MAPPING_COMMITMENT_OPENING_FROZEN", "protocol_generation": GEN, "source_protocol_generation": SOURCE_GEN, "source_manifest_sha256": sha_file(MANIFEST), "source_mapping_commitment": COMMITMENT, "source_commitment_preimage": {"protocol_generation": SOURCE_GEN, "labels": [f"LABEL_{i:02d}" for i in range(18)], "methods": list(METHODS)}, "source_commitment_preimage_sha256": hashlib.sha256(canonical({"protocol_generation": SOURCE_GEN, "labels": [f"LABEL_{i:02d}" for i in range(18)], "methods": list(METHODS)})).hexdigest().upper(), "unit_to_method": units, "root_level_method_mapping": method_mapping, "rl_seed_aggregation_rule": "five_seed_units_to_one_method_root_value_before_inference", "mapping_release_sha256": sha_file(RELEASE), "mapping_manifest_sha256": protocol.get("manifest_sha256"), "api_calls": 0, "provider_calls": 0, "network_calls": 0, "paper_results_or_figures_generated": False, "claim_boundary": "AD-06B"}
    evidence_sha = write_once(OUT / "mapping_opening_evidence.json", opening)
    index_sha = write_once(OUT / "mapping_opening_sha256_index.json", {"schema_version": "exp09-c15-mapping-opening-sha256-index-v1", "protocol_generation": GEN, "files": {"mapping_opening_evidence.json": evidence_sha, "mapping_release": sha_file(RELEASE), "mapping_manifest": protocol.get("manifest_sha256")}})
    print(json.dumps({"evidence_sha256": evidence_sha, "index_sha256": index_sha, "api_calls": 0, "provider_calls": 0, "network_calls": 0, "paper_results_or_figures_generated": False}, sort_keys=True))


if __name__ == "__main__": main()
