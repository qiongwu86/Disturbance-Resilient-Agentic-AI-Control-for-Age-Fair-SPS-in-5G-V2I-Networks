"""C18 extended exact Eq.(11) and legacy-knob sensitivity analysis.

The experiment uses a fresh deterministic synthetic cohort and never reads or
modifies C15.  It evaluates the pre-existing W0 operating point without
retuning: local sum-preserving perturbations, global simplex interior/edge
coverage, and one-factor sweeps of the principal non-weight knobs.  Memory is
candidate-specific, matching the legacy RRI-keyed bonus-map structure.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import random
import statistics
from dataclasses import replace
from pathlib import Path

import run_c16_llm_budgeted_eq11_20260814_0027 as base
import run_c17_fairness_gated_llm_20260814_0033 as c17

GENERATION = "EXP09_SUPPLEMENT_VALIDATION_20260814_0034"
OUT = base.ROOT / "paper_outputs" / "exp09_supplement_validation_20260814_0034"
SEED = 2026081434
N_SCENARIOS = 320
W0 = base.WEIGHT_W0
METRICS = base.METRICS


def sha_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest().upper()


def sha_file(path: Path) -> str:
    return sha_bytes(path.read_bytes())


def scenarios() -> list[base.Scenario]:
    old_seed, old_n = c17.SEED, c17.N_SCENARIOS
    try:
        c17.SEED, c17.N_SCENARIOS = SEED, N_SCENARIOS
        generated = c17.make_scenarios()
    finally:
        c17.SEED, c17.N_SCENARIOS = old_seed, old_n
    return [replace(s, scenario_id=f"c18_synthetic_{i:04d}", cluster_id=f"c18_cluster_{i // 8:03d}") for i, s in enumerate(generated)]


def weight_grid() -> list[dict]:
    rows: list[dict] = [{"weight_id": "W0_legacy", "family": "w0", "weights": W0}]
    seen = {tuple(round(x, 12) for x in W0)}
    for i in range(5):
        for j in range(i + 1, 5):
            for delta in (-.10, -.05, -.02, -.01, .01, .02, .05, .10):
                w = list(W0); w[i] += delta; w[j] -= delta
                key = tuple(round(x, 12) for x in w)
                if min(w) >= 0 and key not in seen:
                    seen.add(key); rows.append({"weight_id": f"local_{i}_{j}_{delta:+.2f}", "family": "local", "weights": tuple(w)})
    for i in range(5):
        w = tuple(1.0 if k == i else 0.0 for k in range(5)); key = tuple(w)
        if key not in seen:
            seen.add(key); rows.append({"weight_id": f"vertex_{i}", "family": "boundary", "weights": w})
    for i in range(5):
        for j in range(i + 1, 5):
            for step in range(1, 20):
                p = step / 20; w = tuple(p if k == i else 1 - p if k == j else 0.0 for k in range(5)); key = tuple(round(x, 12) for x in w)
                if key not in seen:
                    seen.add(key); rows.append({"weight_id": f"edge_{i}_{j}_{step:02d}", "family": "boundary", "weights": w})
    rng = random.Random(SEED + 91)
    for alpha, count, name in ((.2, 1000, "edge_biased"), (1.0, 2000, "uniform_simplex"), (5.0, 1000, "interior")):
        for index in range(count):
            draws = [rng.gammavariate(alpha, 1.0) for _ in range(5)]; total = sum(draws); w = tuple(x / total for x in draws)
            rows.append({"weight_id": f"{name}_{index:04d}", "family": name, "weights": w})
    return rows


def public_by_id(s: base.Scenario) -> dict[str, dict]:
    return {str(x["candidate_id"]): x for x in s.public_candidates}


def memory_bonus(s: base.Scenario, cid: str, *, clip: float, fairness_coefficient: float, collision_coefficient: float) -> float:
    item = public_by_id(s)[cid]
    lesson = .05 if "fairness_priority" in item["evidence_tags"] or "risk_margin" in item["evidence_tags"] else -.005
    raw = float(item["predicted_utility"]) + fairness_coefficient * float(item["predicted_jain_freshness"]) - collision_coefficient * float(item["predicted_collision_risk"]) + lesson - .72
    return max(-clip, min(clip, raw))


def select(s: base.Scenario, weights=W0, *, risk_threshold=.35, memory_clip=.08, fairness_coefficient=.35, collision_coefficient=8.0, cf_cap=.05) -> dict:
    public = public_by_id(s); hidden = {cid: c17.hidden_metrics(s, cid) for cid in base.CANDIDATES}
    current = min(base.CANDIDATES, key=lambda cid: abs(int(cid.split("_")[1]) * 1000 - s.current_rri_us))
    current_u = float(public[current]["predicted_utility"])
    best_cf = max(base.CANDIDATES, key=lambda cid: float(public[cid]["predicted_utility"]) - current_u)
    safe = [cid for cid in base.CANDIDATES if float(public[cid]["predicted_collision_risk"]) <= risk_threshold]
    pool = safe or [min(base.CANDIDATES, key=lambda cid: float(public[cid]["predicted_collision_risk"]))]
    def score(cid: str) -> float:
        item = public[cid]; u = float(item["predicted_utility"]); fair = float(item["predicted_jain_freshness"]); age = float(item["predicted_q95_aoi_ms"]); risk = float(item["predicted_collision_risk"])
        rollout = weights[0] * u + weights[1] * fair + weights[2] * math.exp(-age / 1200.0) + weights[3] * (1 - risk) + weights[4] * (u - current_u)
        mem = memory_bonus(s, cid, clip=memory_clip, fairness_coefficient=fairness_coefficient, collision_coefficient=collision_coefficient)
        cf = max(-cf_cap, min(cf_cap, u - current_u)) if cid == best_cf else 0.0
        return rollout + mem + cf
    selected = max(pool, key=lambda cid: (score(cid), cid))
    return {"selected_candidate": selected, **hidden[selected], "score": score(selected), "fallback_used": not bool(safe)}


def mean_metrics(results: list[dict]) -> dict[str, float]:
    return {metric: statistics.fmean(float(x[metric]) for x in results) for metric in METRICS}


def summarize_config(config_id: str, family: str, weights: tuple[float, ...], cohort: list[base.Scenario], split: str, regime: str, w0_selected: dict[str, str], **knobs) -> dict:
    subset = cohort if regime == "all" else [s for s in cohort if s.regime == regime]
    results = [select(s, weights, **knobs) for s in subset]; means = mean_metrics(results)
    row = {"config_id": config_id, "family": family, "split": split, "regime": regime, "n": len(subset), **{f"w{i}": weights[i] for i in range(5)}}
    for metric, value in means.items(): row[metric] = value
    row["action_stability_vs_w0"] = statistics.fmean(r["selected_candidate"] == w0_selected[s.scenario_id] for s, r in zip(subset, results, strict=True))
    row["fallback_rate"] = statistics.fmean(bool(x["fallback_used"]) for x in results)
    return row


def percentile(values: list[float], q: float) -> float:
    ordered = sorted(values); return ordered[int(q * (len(ordered) - 1))]


def acceptable(row: dict, w0: dict) -> bool:
    return (row["aoi_ms"] <= 1.05 * w0["aoi_ms"] and row["q95_aoi_ms"] <= 1.05 * w0["q95_aoi_ms"]
            and row["collision_rate"] <= 1.05 * w0["collision_rate"] and row["fairness"] >= w0["fairness"] - .02
            and row["utility"] >= w0["utility"] - .02)


def main() -> int:
    if OUT.exists() and any(p.is_file() for p in OUT.rglob("*")): raise SystemExit(f"append-only output exists: {OUT}")
    for d in ("protocol", "raw", "statistics", "tables"): (OUT / d).mkdir(parents=True, exist_ok=True)
    cohort = scenarios(); grid = weight_grid(); calibration, holdout = cohort[:160], cohort[160:]
    (OUT / "protocol/scenarios.jsonl").write_text("".join(json.dumps({"scenario_id": s.scenario_id, "cluster_id": s.cluster_id, "regime": s.regime, "public_payload_sha256": base.sha_obj(s.public_payload())}, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n" for s in cohort), encoding="utf-8")
    spec = {"schema_version": "exp09-c18-eq11-extended-v1", "generation": GENERATION, "seed": SEED, "scenario_count": len(cohort), "split": {"calibration": 160, "locked_holdout": 160}, "w0": W0, "weight_grid": {"count": len(grid), "families": {name: sum(x["family"] == name for x in grid) for name in sorted({x["family"] for x in grid})}}, "local_deltas": ["+/-0.01", "+/-0.02", "+/-0.05", "+/-0.10"], "boundary": "five vertices plus 19-point lattice on every pairwise edge", "global_simplex": "Dirichlet alpha 0.2/1/5", "non_weight_axes": {"risk_threshold": [.25, .30, .35, .40, .45], "memory_clip": [0, .04, .08, .12, .16], "memory_fairness_coefficient": [0, .175, .35, .525, .70], "memory_collision_coefficient": [2, 4, 8, 12, 16], "counterfactual_cap": [0, .015, .03, .05, .08]}, "candidate_specific_memory": True, "memory_structure_source": "legacy RRI-keyed bonus map", "selection": False, "c15_read": False, "c15_mutated": False, "network": False}
    (OUT / "protocol/spec.json").write_text(json.dumps(spec, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    weight_rows: list[dict] = []
    regimes = ("all", *c17.REGIMES)
    for split, subset in (("calibration", calibration), ("holdout", holdout)):
        w0_selected = {s.scenario_id: select(s)["selected_candidate"] for s in subset}
        for config in grid:
            for regime in regimes:
                weight_rows.append(summarize_config(config["weight_id"], config["family"], config["weights"], subset, split, regime, w0_selected))
    with (OUT / "raw/weight_config_endpoints.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(weight_rows[0])); writer.writeheader(); writer.writerows(weight_rows)
    envelope_rows = []
    for split in ("calibration", "holdout"):
        for regime in regimes:
            scoped = [r for r in weight_rows if r["split"] == split and r["regime"] == regime]; w0 = next(r for r in scoped if r["config_id"] == "W0_legacy")
            for family in sorted({r["family"] for r in scoped}):
                group = [r for r in scoped if r["family"] == family]; stability = [r["action_stability_vs_w0"] for r in group]
                item = {"split": split, "regime": regime, "family": family, "configurations": len(group), "acceptable_fraction": statistics.fmean(acceptable(r, w0) for r in group), "action_stability_min": min(stability), "action_stability_p05": percentile(stability, .05), "action_stability_median": percentile(stability, .5)}
                for metric in METRICS:
                    deltas = [r[metric] - w0[metric] for r in group]; item[f"{metric}_delta_min"] = min(deltas); item[f"{metric}_delta_max"] = max(deltas)
                envelope_rows.append(item)
    with (OUT / "tables/tableS11_eq11_weight_envelope.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(envelope_rows[0])); writer.writeheader(); writer.writerows(envelope_rows)
    axes = {
        "risk_threshold": [.25, .30, .35, .40, .45], "memory_clip": [0, .04, .08, .12, .16],
        "fairness_coefficient": [0, .175, .35, .525, .70], "collision_coefficient": [2, 4, 8, 12, 16],
        "cf_cap": [0, .015, .03, .05, .08],
    }
    knob_rows = []
    for split, subset in (("calibration", calibration), ("holdout", holdout)):
        w0_selected = {s.scenario_id: select(s)["selected_candidate"] for s in subset}
        for axis, values in axes.items():
            for value in values:
                knobs = {"risk_threshold": .35, "memory_clip": .08, "fairness_coefficient": .35, "collision_coefficient": 8.0, "cf_cap": .05}; knobs[axis] = value
                for regime in regimes:
                    row = summarize_config(f"{axis}_{value:g}", f"axis_{axis}", W0, subset, split, regime, w0_selected, **knobs)
                    row.update({"axis": axis, "value": value}); knob_rows.append(row)
    with (OUT / "tables/tableS12_eq11_key_parameter_sensitivity.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(knob_rows[0])); writer.writeheader(); writer.writerows(knob_rows)
    holdout_all = [r for r in weight_rows if r["split"] == "holdout" and r["regime"] == "all"]
    holdout_w0 = next(r for r in holdout_all if r["config_id"] == "W0_legacy")
    local = [r for r in holdout_all if r["family"] == "local"]; global_rows = [r for r in holdout_all if r["family"] not in {"w0", "local"}]
    summary = {"generation": GENERATION, "weight_configurations": len(grid), "weight_endpoint_rows": len(weight_rows), "knob_endpoint_rows": len(knob_rows), "w0_selected_from_holdout": False, "w0_claim": "pre-existing operating point; not optimized", "holdout_w0": holdout_w0, "local": {"configurations": len(local), "acceptable_fraction": statistics.fmean(acceptable(r, holdout_w0) for r in local), "action_stability_min": min(r["action_stability_vs_w0"] for r in local), "action_stability_median": percentile([r["action_stability_vs_w0"] for r in local], .5)}, "global": {"configurations": len(global_rows), "acceptable_fraction": statistics.fmean(acceptable(r, holdout_w0) for r in global_rows), "action_stability_min": min(r["action_stability_vs_w0"] for r in global_rows), "action_stability_median": percentile([r["action_stability_vs_w0"] for r in global_rows], .5)}, "claim": "local plateau and global sensitivity are reported together; no robust or optimal claim"}
    (OUT / "statistics/holdout_summary.json").write_text(json.dumps(summary, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    claim = "# Claim boundary\n\n- C18 uses 320 fresh synthetic scenarios and does not read or modify C15.\n- W0 is the pre-existing manuscript operating point; no calibration or holdout result selects new weights.\n- The analysis covers local perturbations, simplex interiors, vertices, pairwise boundaries, five disturbance regimes, and five non-weight axes.\n- Candidate-specific memory follows the legacy RRI-keyed bonus-map structure.\n- Results support only a synthetic sensitivity characterization. Local stability must not be restated as global robustness or optimality.\n"
    (OUT / "claim_boundary.md").write_text(claim, encoding="utf-8")
    close = {"schema_version": "exp09-c18-closeout-v1", "generation": GENERATION, "artifact_status": "C18_COMPLETE", "weight_configurations": len(grid), "weight_endpoint_rows": len(weight_rows), "knob_endpoint_rows": len(knob_rows), "c15_read": False, "c15_mutated": False, "network": False}
    (OUT / "closeout.json").write_text(json.dumps(close, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    idx = {p.relative_to(OUT).as_posix(): sha_file(p) for p in OUT.rglob("*") if p.is_file() and p.name != "sha256_index.json"}; (OUT / "sha256_index.json").write_text(json.dumps(idx, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(close, ensure_ascii=False, sort_keys=True)); return 0


if __name__ == "__main__": raise SystemExit(main())
