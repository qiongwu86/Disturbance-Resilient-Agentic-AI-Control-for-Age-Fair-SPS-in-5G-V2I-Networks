"""Expanded C07 ControllerModel-only mismatch validation (append-only)."""
from __future__ import annotations
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict
from copy import deepcopy
import csv, hashlib, json, statistics, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]; SRC=ROOT/"src"
if str(SRC) not in sys.path: sys.path.insert(0,str(SRC))
from exp09.contracts.tape import TapeArm
from exp09.evaluation.runner import run_open_loop_case
from exp09.evaluation.c14_controllers import C14ControllerFactory
from exp09.artifacts.canonical import canonical_sha256
from exp09.evaluation.c14_controllers import BaselineControllerAdapter, RmpcControllerAdapter, SupervisorControllerAdapter
from exp09.model.approximate import ApproximateSPSModelConfig

GENERATION="EXP09_SUPPLEMENT_VALIDATION_20260813_0021"; OUT=ROOT/"paper_outputs"/"exp09_supplement_validation_20260813_0021"
CONFIG_LOCATOR="protocol/c14/c14_1_method_configs.FROZEN_REMEDIATION_20260728.json"; C07=ROOT/"protocol/c07/mismatch_axis_level_freeze.json"
ROOTS=tuple(f"c15_locked_test_{i:03d}" for i in range(8)); ARMS=("REFERENCE","EVENT"); LEVELS=(("under_predict_load",800000),("nominal",1000000),("over_predict_load",1200000)); METHODS=("Rule_NoMPC","Rule_SameStack","TunedNonLLM_SameStack","RMPC_SameEvaluator","Greedy_1","Nominal_MPC")

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest().upper()

def mismatch_config(base, load_scale_ppm):
    cfg=deepcopy(base)
    model=dict(cfg["shared_model"])
    model["load_scale_ppm"]=int(load_scale_ppm)
    approx=ApproximateSPSModelConfig.create(
        transition_step_us=int(model["transition_step_us"]),
        packet_period_us=int(model["packet_period_us"]),
        logical_subchannel_count=int(model["logical_subchannel_count"]),
        load_scale_ppm=int(model["load_scale_ppm"]),
        forecast_load_scales_ppm=tuple(model["forecast_load_scales_ppm"]),
    )
    model["model_config_hash"]=approx.config_hash
    cfg["shared_model"]=model
    return cfg
class RuleNoMpc:
    def reset(self,c): self.ok=True
    def decide(self,frame,opportunity):
        from exp09.contracts.controller import CommitmentRecord, COMMITMENT_SCHEMA_VERSION
        from exp09.contracts.observable import ObservableCounterKind
        from exp09.contracts.actions import ActionKind
        from exp09.control.candidate_generator import ExpiryCandidateGenerator
        c={x.kind:int(x.value) for x in frame.counters};busy=c.get(ObservableCounterKind.BUSY_SENSING_UNIT,0);total=c.get(ObservableCounterKind.TOTAL_SENSING_UNIT,0);ppm=busy*1000000//total if total else 0; cs=ExpiryCandidateGenerator().generate(frame,opportunity)
        a=min((x for x in cs.actions if x.target_rri_us is not None),key=lambda x:int(x.target_rri_us or 0)) if ppm>=500000 else next((x for x in cs.actions if x.kind is ActionKind.RETAIN_AT_EXPIRY),cs.actions[0])
        return CommitmentRecord(schema_version=COMMITMENT_SCHEMA_VERSION,observation_hash=canonical_sha256(frame,expected_schema_version=frame.schema_version),action=a)
def ctrl(method,config,config_hash):
    if method=="Rule_NoMPC":return RuleNoMpc()
    if method in {"Rule_SameStack","TunedNonLLM_SameStack"}:return SupervisorControllerAdapter(method,config_hash,config)
    if method=="RMPC_SameEvaluator":return RmpcControllerAdapter(config_hash,config)
    return BaselineControllerAdapter(method,config_hash,config)
def one(task):
    root,arm,method,level,scale=task; cp=ROOT/CONFIG_LOCATOR; base=json.loads(cp.read_text(encoding="utf-8")); ch=sha(cp); config=base if scale==1000000 else mismatch_config(base,scale); c=ctrl(method,config,ch); result=run_open_loop_case(root,TapeArm(arm),controller=c)
    return {"schema_version":"exp09-mismatch-case-v2","generation":GENERATION,"root_family":root,"arm":arm,"regime":"nominal" if arm=="REFERENCE" else "harm","method":method,"level_id":level,"load_scale_ppm":scale,"controller_model_config_hash":config["shared_model"]["model_config_hash"],"c07_source_sha256":sha(C07),"metrics":asdict(result.metrics),"integrity_hash":result.integrity_hash,"status":"PASSED","api_calls":0,"provider_calls":0,"c15_mutated":False}
def boot(v,seed,n=2000):
    if len(v)<2:return(v[0],v[0])
    import random;r=random.Random(seed);m=[statistics.fmean(v[r.randrange(len(v))] for _ in v) for _ in range(n)];m.sort();return m[int(.025*n)],m[int(.975*n)-1]
def main():
    if OUT.exists():raise SystemExit(f"append-only output exists: {OUT}")
    for d in ("protocol","raw","metrics","statistics","tables","mismatch"): (OUT/d).mkdir(parents=True)
    cp=ROOT/CONFIG_LOCATOR;spec={"schema_version":"exp09-mismatch-expanded-v1","generation":GENERATION,"roots":list(ROOTS),"arms":list(ARMS),"levels":[{"level_id":a,"load_scale_ppm":b} for a,b in LEVELS],"methods":list(METHODS),"injection_point":"ControllerModel_only","ground_truth_plant_unchanged":True,"disturbance_tape_unchanged":True,"c07_locator":"protocol/c07/mismatch_axis_level_freeze.json","c07_sha256":sha(C07),"config_sha256":sha(cp),"c15_mutated":False,"network":False}
    (OUT/"protocol/spec.json").write_text(json.dumps(spec,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    tasks=[(r,a,m,l,s) for r in ROOTS for a in ARMS for m in METHODS for l,s in LEVELS if not(m=="Rule_NoMPC" and s!=1000000)]
    rows=[]
    with ProcessPoolExecutor(max_workers=4) as pool:
        fs=[pool.submit(one,t) for t in tasks]
        with (OUT/"raw/case_rows.jsonl").open("x",encoding="utf-8") as out:
            for f in as_completed(fs):row=f.result();rows.append(row);out.write(json.dumps(row,ensure_ascii=False,sort_keys=True,separators=(",",":"))+"\n");out.flush()
    by={(r["method"],r["regime"],r["level_id"]):[] for r in rows}
    for r in rows:by[(r["method"],r["regime"],r["level_id"])].append(r)
    nominal={(m,g):statistics.fmean(float(x["metrics"]["mean_aoi_ms"]) for x in rs) for (m,g,l),rs in by.items() if l=="nominal"}
    summary=[]
    for i,((m,g,l),rs) in enumerate(sorted(by.items())):
        e={"method":m,"regime":g,"level_id":l,"load_scale_ppm":next(s for x,s in LEVELS if x==l),"n_roots":len(rs)}
        for k in ("mean_aoi_ms","q95_aoi_ms","jain_freshness","collision_event_rate"):
            v=[float(x["metrics"][k]) for x in rs];lo,hi=boot(v,20260813+i);e[k]=statistics.fmean(v);e[k+"_ci95_low"]=lo;e[k+"_ci95_high"]=hi
            if l!="nominal":
                base=statistics.fmean(float(x["metrics"][k]) for x in by[(m,g,"nominal")]);e[k+"_relative_degradation"]=(e[k]-base)/abs(base) if base else 0.0
        summary.append(e)
    fields=sorted({key for row in summary for key in row});
    with (OUT/"tables/tableS6_mismatch_expanded.csv").open("w",encoding="utf-8-sig",newline="") as s:w=csv.DictWriter(s,fieldnames=fields);w.writeheader();w.writerows(summary)
    (OUT/"metrics/completion.json").write_text(json.dumps({"generation":GENERATION,"planned_rows":len(tasks),"completed_rows":len(rows),"failed_rows":0,"root_count":len(ROOTS),"api_calls":0,"provider_calls":0,"c15_mutated":False,"status":"MISMATCH_EXPANDED_COMPLETE"},ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    (OUT/"statistics/summary.json").write_text(json.dumps({"rows":len(rows),"root_count":len(ROOTS),"interpretation":"tested-range ControllerModel-only mismatch sensitivity; not universal robustness"},ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    (OUT/"claim_boundary.md").write_text("# Claim boundary\n\n- Expanded 8-root ControllerModel-only mismatch validation is complete for the frozen 0.8/1.0/1.2 load-scale levels and listed methods.\n- GroundTruthPlant, disturbance tape and observable input remain unchanged.\n- Results support only tested-range sensitivity/degradation reporting; C07 remains a protocol freeze, not a performance result.\n- No universal robustness, deployment, or C15 mutation claim is allowed.\n",encoding="utf-8")
    idx={p.relative_to(OUT).as_posix():sha(p) for p in OUT.rglob("*") if p.is_file() and p.name!="sha256_index.json"};(OUT/"sha256_index.json").write_text(json.dumps(idx,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    close={"schema_version":"exp09-mismatch-closeout-v1","generation":GENERATION,"artifact_status":"MISMATCH_EXPANDED_COMPLETE","rows":len(rows),"root_count":len(ROOTS),"failed_rows":0,"tested_range_claim_only":True,"c15_mutated":False,"network":False};(OUT/"closeout.json").write_text(json.dumps(close,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8");print(json.dumps(close,ensure_ascii=False,sort_keys=True))
if __name__=="__main__":main()
