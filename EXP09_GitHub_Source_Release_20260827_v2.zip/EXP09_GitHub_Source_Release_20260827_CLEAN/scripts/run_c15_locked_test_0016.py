"""C15 0016 append-only offline resume of 595 exact missing cases."""
from __future__ import annotations
import copy, importlib.util, json, sys
from dataclasses import replace
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
src = ROOT / "scripts" / "run_c15_locked_test_0007.py"
spec = importlib.util.spec_from_file_location("c15_runner_0007_for_0016", src)
if spec is None or spec.loader is None:
    raise RuntimeError("runner import failed")
wrapper = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = wrapper
spec.loader.exec_module(wrapper)
base = wrapper.module

GEN = base.GEN
CACHE = "artifacts/c15_cache_20260807_0128"
OUT = "artifacts/c15_locked_test_20260807_0016"
MANIFEST = "protocol/c15/c15_locked_test_manifest_20260807_0016.json"
SPEC_REL = "protocol/c15/c15_spec_20260807_0016.json"
CONT = "protocol/c15/c15_continuation_20260807_0016.json"
PREF = "protocol/c15/c15_preflight_evidence_20260807_0016.json"
LAUNCH = "protocol/c15/c15_locked_test_launch_20260807_0016.json"
TERM = "protocol/c15/c15_locked_test_terminal_20260807_0016.json"
PARENT = "protocol/c15/c15_locked_test_manifest_20260807_0015.json"
PRIOR = ROOT / "artifacts/c15_locked_test_20260807_0015"

def read(rel): return base._read(rel)
def sha(path): return base._file_sha(path)
def bind(rel): return base._binding(rel)
def write_once(rel, value): return base._write_once(rel, value)

def prior_rows():
    doc = json.loads((PRIOR / "case_ledger.json").read_text(encoding="utf-8"))
    rows = doc.get("rows", [])
    if doc.get("rows_sha256") != base._base.c143.canonical_sha(rows): raise RuntimeError("prior 0015 ledger hash drift")
    if len(rows) != 4013 or len({r.get("ordinal") for r in rows}) != 4013: raise RuntimeError("prior 0015 coverage drift")
    if any(r.get("status") != "PASSED" for r in rows): raise RuntimeError("prior 0015 non-PASSED row")
    for row in rows:
        p = ROOT / row["artifact_locator"]
        if not p.is_file() or sha(p) != row["artifact_sha256"]: raise RuntimeError("prior 0015 artifact drift")
    return sorted(rows, key=lambda r: r["ordinal"])

def materialize():
    parent, out, mp = ROOT / PARENT, ROOT / OUT, ROOT / MANIFEST
    if sha(parent) != "076ECB523A5D8A2762B48EB008D21F1F9FCECA88AA3F3D95464296A4A5AD4100": raise RuntimeError("0015 manifest drift")
    if out.exists(): raise RuntimeError("0016 output collision")
    doc = copy.deepcopy(read(PARENT)); doc["continuation_attempt_ordinal"] = 16; doc["continuation_of"] = PARENT
    for name, rel in (("runner", "scripts/run_c15_locked_test_0016.py"), ("parent_manifest", PARENT), ("cache_qualification", f"{CACHE}/cache_qualification.json"), ("cache_union_provenance", f"{CACHE}/continuation_provenance.json"), ("cache_union_index", f"{CACHE}/sha256_index.json"), ("prior_case_ledger", "artifacts/c15_locked_test_20260807_0015/case_ledger.json")):
        doc.setdefault("source_bindings", {})[name] = bind(rel)
    if mp.exists():
        if read(MANIFEST) != doc: raise RuntimeError("0016 existing manifest drift")
    else: write_once(MANIFEST, doc)
    q = read(f"{CACHE}/cache_qualification.json"); expected = {("Full", "REFERENCE"):0, ("Full", "EVENT"):246, ("Plain_LLM", "REFERENCE"):3425, ("Plain_LLM", "EVENT"):3495}; actual = {(x["method_id"],x["arm"]):x["request_count"] for x in q.get("namespaces",[])}
    if q.get("passed") is not True or q.get("protocol_generation") != GEN or actual != expected or any(q.get(k) != 0 for k in ("api_calls","provider_calls","network_calls")): raise RuntimeError("0128 cache gate failed")
    rows = prior_rows(); proto = read("protocol/c15/c15_protocol_20260807_0004.json")
    if not (ROOT / SPEC_REL).exists(): write_once(SPEC_REL, {"schema_version":"exp09-c15-spec-v11","protocol_generation":GEN,"continuation_attempt_ordinal":16,"continuation_of":PARENT,"exact_n":128,"case_count":base._base.CASE_COUNT,"manifest":MANIFEST,"cache":CACHE,"statistics":proto["statistics"],"resume_prior_case_ledger":"artifacts/c15_locked_test_20260807_0015/case_ledger.json","imported_completed_cases":len(rows),"missing_cases":595,"api_calls":0,"provider_calls":0,"network_calls":0})
    if not (ROOT / CONT).exists(): write_once(CONT, {"schema_version":"exp09-c15-continuation-v10","artifact_status":"C15_0016_CONTINUATION_FROZEN_APPEND_ONLY","protocol_generation":GEN,"continuation_attempt_ordinal":16,"continuation_of":PARENT,"manifest":MANIFEST,"output":OUT,"cache":CACHE,"resume_prior_case_ledger":"artifacts/c15_locked_test_20260807_0015/case_ledger.json","imported_completed_cases":len(rows),"missing_cases":595,"exact_missing_only":True,"same_frozen_generation":True,"same_scope_cases":True,"api_calls":0,"provider_calls":0,"network_calls":0,"training":False,"tuning":False,"unblinding":False,"paper_results_or_figures_generated":False,"append_only":True})
    if not (ROOT / PREF).exists(): write_once(PREF, {"schema_version":"exp09-c15-preflight-v11","protocol_generation":GEN,"continuation_attempt_ordinal":16,"execution_started":False,"execution_authorized":True,"manifest":MANIFEST,"manifest_sha256":sha(mp),"case_count":base._base.CASE_COUNT,"prior_completed_cases":len(rows),"missing_cases":595,"root_families":128,"root_cell_groups":256,"profile_binding":"PASS","cache_qualification":"PASS_COMPLETE_UNION_0128","api_calls":0,"provider_calls":0,"network_calls":0,"offline_only":True,"paper_results_or_figures_generated":False})
    return mp

def run():
    base.install_bindings(); c143 = base._base.c143; c143.CACHE_OUTPUT_LOCATOR = CACHE; c143.SHADOW_OUTPUT_LOCATOR = OUT; c143.MANIFEST_LOCATOR = MANIFEST
    mp, prior = materialize(), prior_rows(); ex = c143.C143ShadowExecutor(ROOT, expected_manifest_sha256=sha(mp)); by = {c.ordinal:c for c in ex.topology.cases}; have = {r["ordinal"] for r in prior}; missing = tuple(by[o] for o in sorted(by) if o not in have)
    if len(missing) != 595: raise RuntimeError(f"exact missing count drift: {len(missing)}")
    ex.rows = prior; ex.topology = replace(ex.topology, cases=missing)
    for r in prior: ex.budget.charge(c143.ShadowBudgetUsage(method_cases=1, environment_steps=int(r.get("environment_steps",0)), model_transitions=int(r.get("model_transitions",0)), cpu_core_seconds=int(r.get("cpu_core_seconds",0)), wall_seconds=int(r.get("wall_seconds",0)), storage_bytes=int(r.get("storage_bytes",0))))
    c143.atomic_write_json(ex.output_root/"continuation_provenance.json", {"schema_version":"exp09-c15-locked-test-resume-provenance-v5","artifact_status":"C15_OFFLINE_CASE_ROW_RESUME","protocol_generation":GEN,"continuation_generation":"EXP09_C15_LOCKED_TEST_20260807_0016","continuation_of":["EXP09_C15_LOCKED_TEST_20260807_0015"],"imported_completed_case_count":len(prior),"executed_missing_case_count":len(missing),"api_key_recorded":False,"api_calls":0,"provider_calls":0,"network_calls":0,"append_only":True}, replace_existing=False)
    write_once(LAUNCH, {"schema_version":"exp09-c15-locked-test-launch-v10","artifact_status":"C15_0016_OFFLINE_LOCKED_TEST_STARTED","protocol_generation":GEN,"continuation_attempt_ordinal":16,"manifest":MANIFEST,"manifest_sha256":sha(mp),"execution_started":True,"imported_completed_cases":len(prior),"missing_cases":len(missing),"api_calls":0,"provider_calls":0,"network_calls":0,"paper_results_or_figures_generated":False,"append_only":True})
    try: result = ex.run()
    except BaseException as exc:
        write_once(TERM, {"schema_version":"exp09-c15-locked-test-terminal-v10","artifact_status":"C15_0016_FAIL_CLOSED_STOP","protocol_generation":GEN,"continuation_attempt_ordinal":16,"execution_started":True,"error_type":type(exc).__name__,"error_message":str(exc),"api_calls":0,"provider_calls":0,"network_calls":0,"paper_results_or_figures_generated":False,"append_only":True}); raise
    write_once(TERM, {"schema_version":"exp09-c15-locked-test-terminal-v10","artifact_status":"C15_0016_OFFLINE_LOCKED_TEST_COMPLETED","protocol_generation":GEN,"continuation_attempt_ordinal":16,"cases":4608,"api_calls":0,"provider_calls":0,"network_calls":0,"paper_results_or_figures_generated":False,"append_only":True}); return result

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv)==2 else ""
    if cmd not in {"preflight","run"}: raise SystemExit("usage: run_c15_locked_test_0016.py [preflight|run]")
    base.install_bindings()
    if cmd == "preflight":
        mp = materialize(); rows=prior_rows(); print(json.dumps({"api_calls":0,"case_count":base._base.CASE_COUNT,"continuation_attempt_ordinal":16,"execution_authorized":True,"manifest":MANIFEST,"manifest_sha256":sha(mp),"missing_cases":595,"network_calls":0,"prior_completed_cases":len(rows),"protocol_generation":GEN,"provider_calls":0},sort_keys=True))
    else:
        result=run(); print(json.dumps({"api_calls":0,"artifact_status":result.get("artifact_status"),"cases":result.get("scope",{}).get("method_cases_passed"),"continuation_attempt_ordinal":16,"network_calls":0,"protocol_generation":GEN,"provider_calls":0},sort_keys=True))
