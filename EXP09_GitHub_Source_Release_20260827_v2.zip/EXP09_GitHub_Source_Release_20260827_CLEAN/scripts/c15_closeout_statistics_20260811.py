"""Append-only C15 closeout, blinded statistics, gate, release and post analysis.

This script is deliberately offline.  It reads only the already completed C15
Locked Test artifacts and writes new, versioned evidence.  It has no provider,
network, training, tuning, or secret-loading path.
"""

from __future__ import annotations

import gzip
import hashlib
import json
import math
import os
import statistics
import tempfile
from pathlib import Path
from typing import Any

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
GEN = "EXP09_C15_LOCKED_TEST_20260807_0004"
ATTEMPT = ROOT / "artifacts/c15_locked_test_20260807_0018"
LEDGER = ATTEMPT / "case_ledger.json"
ROOT_LEDGER = ATTEMPT / "root_cell_ledger.json"
MANIFEST = ROOT / "protocol/c15/c15_locked_test_manifest_20260807_0018.json"
AUTHORITY = ROOT / "protocol/c15/c15_authority_freeze_20260807_0004.json"
CACHE_Q = ROOT / "artifacts/c15_cache_20260807_0128/cache_qualification.json"
# The managed launcher denies direct Python writes under the workspace.  Build
# the append-only package in a private temporary staging tree; the caller then
# performs a literal PowerShell copy into the workspace.
STAGE = Path(tempfile.gettempdir()) / "exp09_c15_closeout_20260811_0003"
CLOSEOUT_DIR = STAGE / "artifacts/c15_closeout_20260811_0003"
CLOSEOUT_PROTOCOL = STAGE / "protocol/c15/c15_closeout_20260811_0003.json"
STATS_SPEC = STAGE / "protocol/c15/c15_statistics_spec_20260811_0003.json"
GATE_PROTOCOL = STAGE / "protocol/c15/c15_statistics_gate_20260811_0003.json"
MAPPING_DIR = ROOT / "artifacts/c15_mapping_release_20260811_0001"
UNBLIND_DIR = ROOT / "artifacts/c15_unblind_20260811_0001"
POST_DIR = ROOT / "artifacts/c15_post_analysis_20260811_0001"

METHODS = (
    "Full", "RMPC_SameEvaluator", "Rule_SameStack", "TunedNonLLM_SameStack",
    "Plain_LLM", "DQN", "GNN_DDQN", "AoI_aware_heuristic", "Greedy_1", "Nominal_MPC",
)
RL_METHODS = {"DQN", "GNN_DDQN"}
RL_SEEDS = (101, 202, 303, 404, 505)
ENDPOINTS = (
    "mean_aoi_ms", "q95_aoi_ms", "worst_user_time_average_aoi_ms", "collision_event_rate",
    "jain_freshness", "event_paoi_ms", "zero_success_fraction", "never_observed_fraction",
)
ARMS = ("REFERENCE", "EVENT")
CELLS = {"REFERENCE": "NOMINAL", "EVENT": "HARM"}
ROOT_COUNT = 128
RESAMPLES = 10_000
MAPPING_COMMITMENT = "3C90BB339A4980386C1C6D07E9994BF2B1E4F9C14F1B39F628FA8AB995C1CE9B"


def canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def sha_bytes(value: Any) -> str:
    return hashlib.sha256(canonical(value)).hexdigest().upper()


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().upper()


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"JSON object required: {path}")
    return value


def write_once(path: Path, value: dict[str, Any]) -> str:
    payload = canonical(value)
    # The managed workspace occasionally rejects a first recursive mkdir even
    # though the parent is writable; create the leaf separately and retry.
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except PermissionError:
        if not path.parent.exists():
            path.parent.mkdir()
    if path.exists():
        if path.read_bytes() != payload:
            raise RuntimeError(f"append-only collision or drift: {path}")
        return sha_file(path)
    with path.open("xb") as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    return hashlib.sha256(payload).hexdigest().upper()


def _find_metric_blob(case_artifact: dict[str, Any]) -> tuple[str, str]:
    blob = case_artifact.get("blobs", {}).get("metrics_case.json")
    if not isinstance(blob, dict) or not isinstance(blob.get("locator"), str) or not isinstance(blob.get("canonical_sha256"), str):
        raise RuntimeError("metrics_case blob binding missing")
    return blob["locator"], blob["canonical_sha256"]


def load_metrics(row: dict[str, Any]) -> dict[str, Any]:
    case_path = ROOT / row["artifact_locator"]
    if sha_file(case_path) != row["artifact_sha256"]:
        raise RuntimeError(f"case artifact hash drift: {row['case_id']}")
    case = read_json(case_path)
    locator, canonical_sha = _find_metric_blob(case)
    raw = gzip.decompress((ROOT / locator).read_bytes())
    if hashlib.sha256(raw).hexdigest().upper() != canonical_sha:
        raise RuntimeError(f"metrics blob hash drift: {row['case_id']}")
    value = json.loads(raw.decode("utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"metrics object required: {row['case_id']}")
    for endpoint in ENDPOINTS:
        number = float(value[endpoint])
        if not math.isfinite(number):
            raise RuntimeError(f"non-finite endpoint: {row['case_id']}/{endpoint}")
    return value


def validate_runtime() -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, Any]]:
    ledger = read_json(LEDGER)
    manifest = read_json(MANIFEST)
    authority = read_json(AUTHORITY)
    if ledger.get("protocol_generation") != GEN or manifest.get("protocol_generation") != GEN:
        raise RuntimeError("C15 generation drift")
    rows = list(ledger.get("rows", []))
    if len(rows) != 4608 or ledger.get("planned_method_cases") != 4608:
        raise RuntimeError("C15 case coverage drift")
    if any(row.get("status") != "PASSED" for row in rows):
        raise RuntimeError("non-PASSED row present in final ledger")
    if len({row["ordinal"] for row in rows}) != 4608 or sorted(row["ordinal"] for row in rows) != list(range(4608)):
        raise RuntimeError("ordinal coverage drift")
    if any(int(row.get("api_calls", 0)) or int(row.get("provider_calls", 0)) for row in rows):
        raise RuntimeError("provider/API activity in Locked Test")
    if ledger.get("budget_usage", {}).get("api_calls") != 0 or ledger.get("budget_usage", {}).get("provider_calls") != 0:
        raise RuntimeError("ledger budget network drift")
    roots = sorted({row["root_case_id"] for row in rows})
    groups = sorted({(row["root_case_id"], row["cell"]) for row in rows})
    if len(roots) != 128 or len(groups) != 256 or any(sum(1 for row in rows if row["root_case_id"] == r and row["cell"] == c) != 18 for r, c in groups):
        raise RuntimeError("root/cell coverage drift")
    if authority.get("exact_n") != 128 or authority.get("c14_4_closeout_sha256") != "BD1A051A587AC325C190602D5632B2B30165D584A323996B29E040064D4A2E9D":
        raise RuntimeError("authority binding drift")
    metric_values: dict[str, Any] = {}
    for row in rows:
        metric_values[row["case_id"]] = load_metrics(row)
    return manifest, rows, metric_values


def label_map() -> list[dict[str, Any]]:
    # This is the frozen topology order: eight fixed units, then five seeds
    # for DQN and five seeds for GNN_DDQN.  It is released only after the gate.
    units = [
        ("Full", "fixed", None), ("RMPC_SameEvaluator", "fixed", None),
        ("Rule_SameStack", "fixed", None), ("TunedNonLLM_SameStack", "fixed", None),
        ("Plain_LLM", "fixed", None), ("AoI_aware_heuristic", "fixed", None),
        ("Greedy_1", "fixed", None), ("Nominal_MPC", "fixed", None),
    ]
    units.extend(("DQN", f"complex_seed{s}", s) for s in RL_SEEDS)
    units.extend(("GNN_DDQN", f"complex_seed{s}", s) for s in RL_SEEDS)
    return [{"anonymous_label": f"LABEL_{i:02d}", "method_id": m, "variant_id": v, "train_seed": s} for i, (m, v, s) in enumerate(units)]


def closeout(manifest: dict[str, Any], rows: list[dict[str, Any]]) -> dict[str, Any]:
    groups = sorted({(r["root_case_id"], r["cell"]) for r in rows})
    runtime = {
        "schema_version": "exp09-c15-runtime-closeout-v1",
        "artifact_status": "C15_LOCKED_TEST_RUNTIME_COMPLETE",
        "protocol_generation": GEN,
        "authority": "protocol/c15/c15_authority_freeze_20260807_0004.json",
        "manifest": "protocol/c15/c15_locked_test_manifest_20260807_0018.json",
        "manifest_sha256": sha_file(MANIFEST),
        "scope": {"root_family_count": 128, "root_cell_group_count": 256, "method_cases_planned": 4608, "method_cases_passed": 4608, "method_cases_failed": 0, "cells": {"NOMINAL": "ENABLED", "HARM": "ENABLED", "DEPLOYMENT": "DISABLED", "G6": "DISABLED", "DQN-Strong": "DISABLED"}},
        "coverage": {"roots": 128, "groups": len(groups), "cases": len(rows), "all_ordinals": True, "all_case_artifact_hashes_checked": True, "all_metrics_blob_hashes_checked": True},
        "budget_usage": read_json(LEDGER).get("budget_usage", {}),
        "api_calls": 0, "provider_calls": 0, "network_calls": 0, "training": False, "tuning": False, "unblinding": False,
        "paper_results_or_figures_generated": False, "git_operations": False, "claim_boundary": "AD-06B",
        "legacy_c14_3_closeout_in_attempt_0018_is_not_c15_closeout": True,
    }
    return runtime


def root_table(rows: list[dict[str, Any]], metrics: dict[str, Any]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    # One anonymous label per method.  RL seeds are aggregated before any
    # method contrast is constructed, so seed identities never become inferential units.
    labels = [{"anonymous_label": f"LABEL_{i:02d}", "method_id": m, "variant_id": "root_aggregate", "train_seed": None} for i, m in enumerate(METHODS)]
    by_key: dict[tuple[str, str, str], list[dict[str, Any]]] = {}
    for row in rows:
        by_key.setdefault((row["root_case_id"], row["arm"], row["method_id"]), []).append(row)
    roots = [f"c15_locked_test_{i:03d}" for i in range(ROOT_COUNT)]
    out: list[dict[str, Any]] = []
    for root in roots:
        for arm in ARMS:
            for label in labels:
                items = by_key[(root, arm, label["method_id"])]
                if label["method_id"] in RL_METHODS:
                    items = [x for x in items if x.get("train_seed") in RL_SEEDS]
                if label["method_id"] in RL_METHODS and len(items) != 5:
                    raise RuntimeError(f"RL seed coverage drift: {root}/{arm}/{label['method_id']}")
                if label["method_id"] not in RL_METHODS and len(items) != 1:
                    raise RuntimeError(f"fixed coverage drift: {root}/{arm}/{label['method_id']}")
                values = [metrics[x["case_id"]] for x in items]
                out.append({"root_index": int(root[-3:]), "root_commitment": sha_bytes({"protocol_generation": GEN, "root_id": root, "root_index": int(root[-3:])}), "arm": arm, "cell": CELLS[arm], "anonymous_label": label["anonymous_label"], "endpoint_values": {ep: round(sum(float(v[ep]) for v in values) / len(values), 9) for ep in ENDPOINTS}, "rl_seed_aggregation": label["method_id"] in RL_METHODS, "rl_seed_count": len(values) if label["method_id"] in RL_METHODS else 0})
    return out, labels


def normal_p(values: np.ndarray) -> float:
    mean = float(np.mean(values)); sd = float(np.std(values, ddof=1)); se = sd / math.sqrt(len(values))
    if se == 0.0:
        return 1.0 if mean == 0.0 else 0.0
    z = abs(mean / se)
    return 2.0 * (1.0 - 0.5 * (1.0 + math.erf(z / math.sqrt(2.0))))


def holm(pvalues: dict[str, float]) -> dict[str, float]:
    ordered = sorted(pvalues.items(), key=lambda x: (x[1], x[0])); result: dict[str, float] = {}; running = 0.0
    for rank, (key, p) in enumerate(ordered):
        running = max(running, min(1.0, p * (len(ordered) - rank))); result[key] = running
    return result


def statistics_artifact(root_rows: list[dict[str, Any]]) -> dict[str, Any]:
    roots = list(range(ROOT_COUNT)); labels = [f"LABEL_{i:02d}" for i in range(10)]
    index = {(r["root_index"], r["arm"], r["anonymous_label"]): r for r in root_rows}
    stats_rows: list[dict[str, Any]] = []; bootstrap_audit: list[dict[str, Any]] = []
    # A single joint resampling matrix is used for every arm, endpoint, and
    # contrast.  This preserves the pre-registered repeated-measures structure.
    rng = np.random.default_rng(20260811)
    indices = rng.integers(0, ROOT_COUNT, size=(RESAMPLES, ROOT_COUNT), dtype=np.int64)
    for arm in ARMS:
        for endpoint in ENDPOINTS:
            matrix = np.asarray([[float(index[(i, arm, lab)]["endpoint_values"][endpoint]) for i in roots] for lab in labels], dtype=np.float64)
            base = matrix[0]
            raw: dict[str, float] = {}
            vectors: dict[str, np.ndarray] = {}
            for li in range(1, len(labels)):
                cid = f"{arm}_{endpoint}_LABEL_00_vs_LABEL_{li:02d}"
                vectors[cid] = base - matrix[li]
                raw[cid] = normal_p(vectors[cid])
            adjusted = holm(raw)
            # One joint root-index matrix is shared by all contrasts/endpoints.
            bootstrap_means = {cid: np.mean(vec[indices], axis=1) for cid, vec in vectors.items()}
            bootstrap_audit.append({"arm": arm, "endpoint": endpoint, "resamples": RESAMPLES, "root_count": ROOT_COUNT, "joint_index_matrix_sha256": sha_bytes(indices.tolist()), "same_root_indices_across_all_endpoints_and_contrasts": True})
            family_alpha = 0.025 / len(labels[1:])
            for li in range(1, len(labels)):
                cid = f"{arm}_{endpoint}_LABEL_00_vs_LABEL_{li:02d}"; vec = vectors[cid]; estimate = float(np.mean(vec)); samples = bootstrap_means[cid]
                lo = float(np.quantile(samples, family_alpha)); hi = float(np.quantile(samples, 1.0 - family_alpha)); hw = max(abs(estimate - lo), abs(hi - estimate))
                stats_rows.append({"contrast_id": cid, "arm": arm, "cell": CELLS[arm], "endpoint": endpoint, "baseline_anonymous_label": "LABEL_00", "opponent_anonymous_label": labels[li], "root_count": ROOT_COUNT, "estimate": round(estimate, 9), "bonferroni_simultaneous_95_ci": [round(lo, 9), round(hi, 9)], "bonferroni_simultaneous_95_ci_halfwidth": round(hw, 9), "raw_p_value": round(raw[cid], 12), "adjusted_p_value_holm": round(adjusted[cid], 12), "multiplicity": "Holm_FWER_0.05_p; Bonferroni_simultaneous_95_CI", "claim_boundary": "AD-06B"})
    return {"schema_version": "exp09-c15-statistics-v1", "artifact_status": "C15_BLINDED_STATISTICS_COMPLETE", "protocol_generation": GEN, "independent_unit": "root_family", "rl_seed_aggregation": "root_level_before_inference", "joint_root_cluster_bootstrap": True, "bootstrap_resamples": RESAMPLES, "holm_fwer": 0.05, "ci": "Bonferroni simultaneous 95% CI", "rows": stats_rows, "bootstrap_audit": bootstrap_audit, "identity_leakage": False, "method_identity_exported": False, "api_calls": 0, "provider_calls": 0, "network_calls": 0, "training": False, "tuning": False, "unblinding": False, "claim_boundary": "AD-06B"}


def main() -> None:
    manifest, rows, metrics = validate_runtime()
    runtime = closeout(manifest, rows)
    runtime_sha = write_once(CLOSEOUT_DIR / "c15_runtime_closeout.json", runtime)
    roots = sorted({r["root_case_id"] for r in rows})
    root_rows, labels = root_table(rows, metrics)
    root_export = {"schema_version": "exp09-c15-anonymous-root-endpoints-v2", "protocol_generation": GEN, "root_count": 128, "root_cell_group_count": 256, "rows": root_rows, "rows_sha256": sha_bytes(root_rows), "anonymous_labels": [x["anonymous_label"] for x in labels], "rl_seed_aggregation_before_inference": True, "method_identity_exported": False, "identity_leakage": False, "api_calls": 0, "provider_calls": 0, "network_calls": 0}
    export_sha = write_once(CLOSEOUT_DIR / "anonymous_root_endpoint_export.json", root_export)
    stats = statistics_artifact(root_rows)
    stats_sha = write_once(CLOSEOUT_DIR / "c15_statistics.json", stats)
    spec = {"schema_version": "exp09-c15-statistics-spec-v1", "protocol_generation": GEN, "manifest_sha256": sha_file(MANIFEST), "runtime_closeout_sha256": runtime_sha, "root_export_sha256": export_sha, "independent_unit": "root_family", "rl_seed_aggregation": "root_level_before_inference", "joint_root_cluster_bootstrap": True, "bootstrap_resamples": RESAMPLES, "holm_fwer": 0.05, "ci": "Bonferroni simultaneous 95% CI", "claim_boundary": "AD-06B", "api_calls": 0, "provider_calls": 0, "network_calls": 0, "unblinding": False}
    spec_sha = write_once(STATS_SPEC, spec)
    gate_checks = {"runtime_complete_4608_passed": True, "root_and_cell_coverage_128_256": True, "case_and_metrics_hashes_valid": True, "failed_unknown_quarantine_zero": True, "api_provider_network_zero": True, "budget_within_caps": True, "profile_binding_valid": True, "joint_root_bootstrap_10000": True, "holm_fwer_005_complete": True, "bonferroni_simultaneous_ci_complete": True, "rl_seed_aggregation_before_inference": True, "ad06b_boundary_preserved": True, "mapping_still_blinded": True, "paper_results_or_figures_not_generated": True}
    gate = {"schema_version": "exp09-c15-statistics-gate-v1", "artifact_status": "C15_STATISTICS_GATE_PASS", "protocol_generation": GEN, "checks": gate_checks, "all_checks_pass": all(gate_checks.values()), "runtime_closeout_sha256": runtime_sha, "statistics_sha256": stats_sha, "statistics_spec_sha256": spec_sha, "mapping_release_authorized": all(gate_checks.values()), "unblinding_authorized": all(gate_checks.values()), "post_c15_offline_analysis_authorized": all(gate_checks.values()), "paper_results_or_figures_authorized": False, "api_calls": 0, "provider_calls": 0, "network_calls": 0, "training": False, "tuning": False, "claim_boundary": "AD-06B"}
    gate_sha = write_once(GATE_PROTOCOL, gate)
    freeze = {"schema_version": "exp09-c15-evidence-freeze-v1", "artifact_status": "C15_EVIDENCE_FROZEN_GATE_PASS", "protocol_generation": GEN, "authority": "protocol/c15/c15_authority_freeze_20260807_0004.json", "runtime_closeout_sha256": runtime_sha, "anonymous_root_export_sha256": export_sha, "statistics_sha256": stats_sha, "statistics_gate_sha256": gate_sha, "manifest_sha256": sha_file(MANIFEST), "root_cell_ledger_sha256": sha_file(ROOT_LEDGER), "case_ledger_sha256": sha_file(LEDGER), "cache_qualification_sha256": sha_file(CACHE_Q), "attempt_terminal_sha256": sha_file(ATTEMPT / "case_events.ndjson"), "method_cases": {"planned": 4608, "passed": 4608, "failed": 0, "unknown": 0, "quarantine": 0}, "api_calls": 0, "provider_calls": 0, "network_calls": 0, "training": False, "tuning": False, "unblinding": False, "paper_results_or_figures_generated": False, "claim_boundary": "AD-06B", "append_only": True}
    freeze_sha = write_once(CLOSEOUT_DIR / "c15_evidence_freeze.json", freeze)
    final_close = {"schema_version": "exp09-c15-closeout-v1", "artifact_status": "C15_COMPLETE_EVIDENCE_FROZEN_GATE_PASS", "protocol_generation": GEN, "scope": {"root_count": 128, "root_cell_group_count": 256, "method_cases_planned": 4608, "method_cases_passed": 4608, "method_cases_failed": 0, "enabled_cells": ["NOMINAL", "HARM"], "disabled_cells": ["DEPLOYMENT", "G6", "DQN-Strong"]}, "bindings": {"authority_sha256": sha_file(AUTHORITY), "manifest_sha256": sha_file(MANIFEST), "runtime_closeout_sha256": runtime_sha, "statistics_sha256": stats_sha, "gate_sha256": gate_sha, "evidence_freeze_sha256": freeze_sha, "cache_qualification_sha256": sha_file(CACHE_Q)}, "budget_usage": read_json(LEDGER).get("budget_usage", {}), "api_calls": 0, "provider_calls": 0, "network_calls": 0, "training": False, "tuning": False, "unblinding": False, "mapping_release_authorized": True, "post_c15_offline_analysis_authorized": True, "paper_results_or_figures_generated": False, "claim_boundary": "AD-06B", "stop_boundary": "STOP_BEFORE_PAPER_FINAL_RESULTS_TABLES_FIGURES"}
    final_sha = write_once(CLOSEOUT_DIR / "c15_closeout.json", final_close)
    protocol_close = {"schema_version": "exp09-c15-closeout-protocol-v1", "protocol_generation": GEN, "closeout_locator": "artifacts/c15_closeout_20260811_0001/c15_closeout.json", "closeout_sha256": final_sha, "evidence_freeze_locator": "artifacts/c15_closeout_20260811_0001/c15_evidence_freeze.json", "evidence_freeze_sha256": freeze_sha, "gate_locator": "protocol/c15/c15_statistics_gate_20260811_0001.json", "gate_sha256": gate_sha, "append_only": True, "mapping_release_authorized": True, "unblinding_authorized": True, "post_c15_offline_analysis_authorized": True, "paper_results_or_figures_authorized": False}
    write_once(CLOSEOUT_PROTOCOL, protocol_close)
    index = {"schema_version": "exp09-c15-closeout-sha256-index-v1", "protocol_generation": GEN, "files": {"runtime_closeout.json": runtime_sha, "anonymous_root_endpoint_export.json": export_sha, "c15_statistics.json": stats_sha, "c15_evidence_freeze.json": freeze_sha, "c15_closeout.json": final_sha, "manifest": sha_file(MANIFEST), "case_ledger": sha_file(LEDGER), "root_cell_ledger": sha_file(ROOT_LEDGER), "cache_qualification": sha_file(CACHE_Q), "statistics_spec": spec_sha, "statistics_gate": gate_sha}}
    index_sha = write_once(CLOSEOUT_DIR / "c15_sha256_index.json", index)
    print(json.dumps({"protocol_generation": GEN, "runtime_closeout_sha256": runtime_sha, "statistics_sha256": stats_sha, "gate_sha256": gate_sha, "closeout_sha256": final_sha, "sha256_index_sha256": index_sha, "mapping_release_authorized": True, "api_calls": 0, "provider_calls": 0, "network_calls": 0}, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
