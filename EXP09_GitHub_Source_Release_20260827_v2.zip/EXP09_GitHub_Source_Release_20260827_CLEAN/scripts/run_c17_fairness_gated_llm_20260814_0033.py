"""C17: fairness-gated LLM ordering against Rule and Tuned-NonLLM.

This is a fresh, non-sensitive synthetic mechanism experiment.  All providers
see the same observable candidate summaries, candidate set, two-candidate MPC
budget, risk gate, evaluator, and hidden plant.  The only intervention is the
supervisor ordering.  The oracle is pre-registered as a lexicographic
age-fairness objective; it is diagnostic and never enters provider input.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import random
import statistics
import sys
import time
from pathlib import Path
from urllib.request import Request, urlopen

import run_c16_llm_budgeted_eq11_20260814_0027 as base

GENERATION = "EXP09_SUPPLEMENT_VALIDATION_20260814_0033"
OUT = base.ROOT / "paper_outputs" / "exp09_supplement_validation_20260814_0033"
N_SCENARIOS = 160
SEED = 2026081433
BATCH_SIZE = 16
MPC_BUDGET = 2
RISK_THRESHOLD = 0.35
REGIMES = ("nominal", "shock_onset", "fairness_crisis", "collision_crisis", "mixed_transition")


def sha_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest().upper()


def sha_obj(value) -> str:
    return sha_bytes(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode())


def sha_file(path: Path) -> str:
    return sha_bytes(path.read_bytes())


def make_scenarios() -> list[base.Scenario]:
    rng = random.Random(SEED)
    out: list[base.Scenario] = []
    for i in range(N_SCENARIOS):
        regime = REGIMES[i % len(REGIMES)]
        if regime == "nominal":
            age, coll, vol = .30, .22, .18
        elif regime == "shock_onset":
            age, coll, vol = .62, .70, .85
        elif regime == "fairness_crisis":
            age, coll, vol = .94, .38, .46
        elif regime == "collision_crisis":
            age, coll, vol = .46, .94, .56
        else:
            age, coll, vol = .78, .74, .90
        density = min(.98, max(.08, .18 + .73 * coll + rng.uniform(-.07, .07)))
        age = min(.99, max(.02, age + rng.uniform(-.07, .07)))
        coll = min(.99, max(.02, coll + rng.uniform(-.07, .07)))
        vol = min(.99, max(.02, vol + rng.uniform(-.07, .07)))
        current = (20_000, 50_000, 100_000, 200_000, 500_000)[i % 5]
        candidates = []
        for j, cid in enumerate(base.CANDIDATES):
            rri_ms = int(cid.split("_")[1])
            # Public values are forecasts with bounded error, not hidden truth.
            p_aoi = 520 - .58 * rri_ms + 145 * age + 82 * vol + rng.uniform(-30, 30)
            p_q95 = p_aoi * (1.45 + .32 * age + .10 * abs(j - 2)) + rng.uniform(-25, 25)
            p_risk = min(.98, max(.01, .055 + density * .72 - .00031 * rri_ms + rng.uniform(-.055, .055)))
            p_fair = min(.995, max(.40, .72 + .22 * age - .15 * abs(j - 2) + rng.uniform(-.035, .035)))
            p_u = min(.995, max(.01, .96 - p_aoi / 1450 + .13 * p_fair - .38 * p_risk))
            candidates.append({
                "candidate_id": cid,
                "rri_us": rri_ms * 1000,
                "predicted_mean_aoi_ms": round(p_aoi, 3),
                "predicted_q95_aoi_ms": round(p_q95, 3),
                "predicted_collision_risk": round(p_risk, 5),
                "predicted_jain_freshness": round(p_fair, 5),
                "predicted_utility": round(p_u, 5),
                "evidence_tags": [
                    "fairness_priority" if age > .65 and j in (1, 2, 3) else "fairness_neutral",
                    "risk_margin" if coll > .65 and j >= 2 else "risk_sensitive",
                    "volatile_transition" if vol > .65 and j in (2, 3) else "stable_transition",
                ],
            })
        out.append(base.Scenario(
            scenario_id=f"c17_synthetic_{i:04d}", cluster_id=f"c17_cluster_{i // 8:03d}",
            regime=regime, density=density, age_pressure=age, collision_pressure=coll,
            volatility=vol, current_rri_us=current, public_candidates=tuple(candidates),
            hidden_bias=rng.uniform(-1, 1),
        ))
    return out


def hidden_metrics(s: base.Scenario, cid: str) -> dict[str, float]:
    j = base.CANDIDATES.index(cid)
    rri_ms = int(cid.split("_")[1])
    # Hidden plant contains deterministic, regime-dependent interactions.
    shock = 105 * s.volatility * (1.0 if j == 2 else .48 if j == 3 else .82)
    age_penalty = 0.42 * s.age_pressure * abs(j - 2) / 2
    coll = min(.98, max(.005, .032 + .64 * s.density * math.exp(-rri_ms / 235.0)
                         + .07 * s.volatility * (j == 0) + .035 * abs(s.hidden_bias)))
    mean_aoi = max(80.0, 430 - .70 * rri_ms + 165 * s.age_pressure + shock
                   + 14 * math.sin((j + 1) * (s.hidden_bias + 1.3)))
    q95 = mean_aoi * (1.52 + .33 * s.age_pressure + .13 * abs(j - 2))
    fairness = min(.995, max(.35, .82 - age_penalty + .10 * (j == 2)
                              - .09 * s.collision_pressure * (j == 0)
                              + .025 * math.cos((j + 1) * s.hidden_bias)))
    utility = min(.995, max(.01, 1.0 - mean_aoi / 1500 + .17 * fairness - .43 * coll))
    return {"aoi_ms": mean_aoi, "q95_aoi_ms": q95, "fairness": fairness,
            "collision_rate": coll, "utility": utility}


def rule_order(s: base.Scenario) -> list[str]:
    rows = list(s.public_candidates)
    if s.collision_pressure >= s.age_pressure + .10:
        rows.sort(key=lambda x: (x["predicted_collision_risk"], -x["predicted_jain_freshness"], x["candidate_id"]))
    elif s.age_pressure >= s.collision_pressure + .10:
        rows.sort(key=lambda x: (-x["predicted_jain_freshness"], x["predicted_q95_aoi_ms"], x["candidate_id"]))
    else:
        rows.sort(key=lambda x: (-x["predicted_utility"], x["predicted_collision_risk"], x["candidate_id"]))
    return [x["candidate_id"] for x in rows]


def tuned_nonllm_order(s: base.Scenario) -> list[str]:
    # Frozen axis-aligned deterministic approximation, declared before API calls.
    rows = list(s.public_candidates)
    safe = [x for x in rows if x["predicted_collision_risk"] <= RISK_THRESHOLD]
    pool = safe or rows
    def score(x: dict) -> tuple[float, float, float, str]:
        fairness = float(x["predicted_jain_freshness"])
        freshness = math.exp(-float(x["predicted_q95_aoi_ms"]) / 1200.0)
        utility = float(x["predicted_utility"])
        risk = float(x["predicted_collision_risk"])
        return (0.55 * fairness + 0.30 * freshness + 0.15 * utility - 0.25 * risk,
                fairness, freshness, x["candidate_id"])
    return [x["candidate_id"] for x in sorted(pool, key=score, reverse=True)] + [
        x["candidate_id"] for x in rows if x["candidate_id"] not in {y["candidate_id"] for y in pool}
    ]


def oracle_order(s: base.Scenario) -> list[str]:
    rows = [(cid, hidden_metrics(s, cid)) for cid in base.CANDIDATES]
    safe = [(cid, m) for cid, m in rows if m["collision_rate"] <= RISK_THRESHOLD]
    pool = safe or rows
    # Pre-registered lexicographic age-fairness objective.
    return [cid for cid, _ in sorted(pool, key=lambda item: (
        item[1]["fairness"], -item[1]["q95_aoi_ms"], item[1]["utility"], -item[1]["collision_rate"], item[0]
    ), reverse=True)] + [cid for cid, _ in rows if cid not in {x[0] for x in pool}]


def evaluate(s: base.Scenario, order: list[str]) -> dict[str, float | str | list[str]]:
    subset = order[:MPC_BUDGET]
    metrics = {cid: hidden_metrics(s, cid) for cid in base.CANDIDATES}
    safe = [cid for cid in subset if metrics[cid]["collision_rate"] <= RISK_THRESHOLD]
    pool = safe or [min(subset, key=lambda cid: metrics[cid]["collision_rate"])]
    # Same deterministic Eq.(11) selector for every provider.
    current = min(base.CANDIDATES, key=lambda cid: abs(int(cid.split("_")[1]) * 1000 - s.current_rri_us))
    current_u = metrics[current]["utility"]
    selected = max(pool, key=lambda cid: (
        .50 * metrics[cid]["utility"] + .20 * metrics[cid]["fairness"]
        + .15 * math.exp(-metrics[cid]["aoi_ms"] / 1200.0)
        + .10 * (1 - metrics[cid]["collision_rate"])
        + .05 * (metrics[cid]["utility"] - current_u), cid
    ))
    return {"selected_candidate": selected, **metrics[selected], "evaluated_ids": subset,
            "fallback_used": not bool(safe)}


def bootstrap_cluster(values: list[float], clusters: list[str], seed: int, n: int = 5000) -> tuple[float, float, float]:
    grouped: dict[str, list[float]] = {}
    for value, cluster in zip(values, clusters): grouped.setdefault(cluster, []).append(value)
    keys = sorted(grouped); rng = random.Random(seed); means = []
    for _ in range(n):
        sampled = [rng.choice(keys) for _ in keys]
        means.append(statistics.fmean(v for k in sampled for v in grouped[k]))
    means.sort(); return statistics.fmean(values), means[int(.025 * n)], means[int(.975 * n) - 1]


def signflip_p(diffs: list[float], seed: int, n: int = 20000) -> float:
    if not diffs or all(abs(x) < 1e-15 for x in diffs): return 1.0
    rng = random.Random(seed); obs = abs(statistics.fmean(diffs)); hits = 1
    for _ in range(n):
        value = abs(statistics.fmean(x if rng.random() < .5 else -x for x in diffs))
        hits += value >= obs
    return hits / (n + 1)


def holm(rows: list[dict]) -> None:
    order = sorted(range(len(rows)), key=lambda i: rows[i]["raw_p_value"])
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, min(1.0, rows[i]["raw_p_value"] * (len(rows) - rank)))
        rows[i]["holm_adjusted_p"] = running


def call_batch(batch: list[base.Scenario], credentials, batch_id: str) -> tuple[dict[str, list[str]], dict]:
    payloads = [s.public_payload() | {"objective": "lexicographic: safety, Jain freshness, q95 AoI, utility"} for s in batch]
    item_schema = {"type": "object", "additionalProperties": False, "required": ["scenario_id", "evaluation_order"], "properties": {
        "scenario_id": {"type": "string", "enum": [s.scenario_id for s in batch]},
        "evaluation_order": {"type": "array", "minItems": len(base.CANDIDATES), "maxItems": len(base.CANDIDATES), "items": {"type": "string", "enum": list(base.CANDIDATES)}}}}
    schema = {"type": "object", "additionalProperties": False, "required": ["decisions"], "properties": {
        "decisions": {"type": "array", "minItems": len(batch), "maxItems": len(batch), "items": item_schema}}}
    body = {"model": base.MODEL, "messages": [
        {"role": "system", "content": "You are a constrained age-fair SPS supervisor. For each independent synthetic scenario, rank every candidate exactly once. The first two candidates consume a frozen MPC budget. Apply lexicographic priorities: reject candidates with predicted collision risk above 0.35 when a safe candidate exists; among safe candidates prioritize Jain freshness, then q95 AoI, then utility. Use only that scenario's observable summary; never transfer values between scenarios."},
        {"role": "user", "content": json.dumps({"scenarios": payloads}, ensure_ascii=False, sort_keys=True, separators=(",", ":"))}],
        "temperature": 0, "max_tokens": 4000, "response_format": {"type": "json_schema", "json_schema": {"name": "c17_fairness_orders", "strict": True, "schema": schema}}}
    started = time.perf_counter(); event = {"batch_id": batch_id, "scenario_ids": [s.scenario_id for s in batch], "request_hash": sha_obj(body), "payload_sha256": sha_obj(payloads), "status": "FAILED", "response_hash": None, "parsed_response_hash": None, "api_key_recorded": False}
    orders: dict[str, list[str]] = {}
    try:
        req = Request(f"{credentials.base_url}/chat/completions", data=json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode(), headers={"Authorization": f"Bearer {credentials.api_key}", "Content-Type": "application/json", "Accept": "application/json", "User-Agent": "exp09-c17-fairness-gated/1.0"}, method="POST")
        with urlopen(req, timeout=120) as response: raw = response.read()
        event["response_hash"] = sha_bytes(raw); envelope = json.loads(raw.decode()); parsed = json.loads(envelope["choices"][0]["message"]["content"])
        orders = {d["scenario_id"]: d["evaluation_order"] for d in parsed["decisions"]}
        if set(orders) != {s.scenario_id for s in batch}: raise ValueError("scenario coverage mismatch")
        for order in orders.values():
            if sorted(order) != sorted(base.CANDIDATES) or len(set(order)) != len(base.CANDIDATES): raise ValueError("invalid permutation")
        event["parsed_response_hash"] = sha_obj(parsed); event["status"] = "COMPLETED_AUDITED"; event["model_returned"] = envelope.get("model")
    except Exception as exc:
        event["error_type"] = type(exc).__name__
    event["latency_ms"] = round((time.perf_counter() - started) * 1000, 3)
    return orders, event


def main() -> int:
    if OUT.exists() and any(p.is_file() for p in OUT.rglob("*")): raise SystemExit(f"append-only output exists: {OUT}")
    for d in ("protocol", "raw", "metrics", "statistics", "tables"): (OUT / d).mkdir(parents=True, exist_ok=True)
    scenarios = make_scenarios(); credentials = base.load_provider_credentials(base.API_ENV, profile="primary")
    (OUT / "protocol/scenarios.jsonl").write_text("".join(json.dumps({"scenario": s.__dict__, "payload_sha256": sha_obj(s.public_payload())}, ensure_ascii=False, sort_keys=True, default=list, separators=(",", ":")) + "\n" for s in scenarios), encoding="utf-8")
    spec = {"schema_version": "exp09-c17-fairness-gated-v1", "generation": GENERATION, "scenario_seed": SEED, "scenario_count": N_SCENARIOS, "batch_size": BATCH_SIZE, "batching_disclosed": True, "candidate_ids": list(base.CANDIDATES), "mpc_budget": MPC_BUDGET, "risk_threshold": RISK_THRESHOLD, "oracle": "lexicographic safety/Jain/q95-AoI/utility", "providers": ["LLM", "Rule", "TunedNonLLM"], "c15_read": False, "c15_mutated": False, "payload": "synthetic only", "no_posthoc_selection": True}
    (OUT / "protocol/spec.json").write_text(json.dumps(spec, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    rows: list[dict] = []; events: list[dict] = []
    with (OUT / "raw/batch_events.jsonl").open("x", encoding="utf-8") as event_stream, (OUT / "raw/case_rows.jsonl").open("x", encoding="utf-8") as row_stream:
        for start in range(0, len(scenarios), BATCH_SIZE):
            batch = scenarios[start:start + BATCH_SIZE]; orders, event = call_batch(batch, credentials, f"batch_{start // BATCH_SIZE:02d}"); events.append(event)
            event_stream.write(json.dumps(event, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"); event_stream.flush()
            for s in batch:
                llm_order = orders.get(s.scenario_id); rule_order_v = rule_order(s); tuned_order_v = tuned_nonllm_order(s); oracle_order_v = oracle_order(s)
                row = {"generation": GENERATION, "scenario_id": s.scenario_id, "cluster_id": s.cluster_id, "regime": s.regime, "status": "PASSED" if llm_order else "FAILED_RETAINED", "llm_order": llm_order, "rule_order": rule_order_v, "tuned_nonllm_order": tuned_order_v, "oracle_order": oracle_order_v, "llm": evaluate(s, llm_order) if llm_order else None, "rule": evaluate(s, rule_order_v), "tuned_nonllm": evaluate(s, tuned_order_v), "oracle": evaluate(s, oracle_order_v), "c15_mutated": False}
                rows.append(row); row_stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"); row_stream.flush()
    passed = [r for r in rows if r["status"] == "PASSED"]; effects: list[dict] = []
    if len(passed) == len(scenarios):
        for comparator in ("rule", "tuned_nonllm"):
            for regime in sorted({r["regime"] for r in passed} | {"all"}):
                group = passed if regime == "all" else [r for r in passed if r["regime"] == regime]
                for metric in base.METRICS:
                    diffs = [float(r["llm"][metric]) - float(r[comparator][metric]) for r in group]
                    mean, lo, hi = bootstrap_cluster(diffs, [r["cluster_id"] for r in group], SEED + len(effects))
                    effects.append({"contrast": f"llm_minus_{comparator}", "regime": regime, "metric": metric, "n": len(diffs), "llm_minus_comparator": mean, "ci95_low": lo, "ci95_high": hi, "raw_p_value": signflip_p(diffs, SEED + 700 + len(effects))})
        holm(effects)
        with (OUT / "statistics/llm_rule_tuned_effects.csv").open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(effects[0])); writer.writeheader(); writer.writerows(effects)
        summary = []
        for method in ("rule", "tuned_nonllm", "llm", "oracle"):
            item = {"method": method, "n": len(passed), "oracle_match": sum(r[f"{method}_order"][0] == r["oracle_order"][0] for r in passed) / len(passed)}
            for metric in base.METRICS: item[metric] = statistics.fmean(float(r[method][metric]) for r in passed)
            summary.append(item)
        with (OUT / "tables/tableS10_c17_llm_fairness_contribution.csv").open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(summary[0])); writer.writeheader(); writer.writerows(summary)
    completion = {"generation": GENERATION, "planned_cases": len(scenarios), "completed_cases": len(passed), "failed_cases": len(scenarios) - len(passed), "batches": len(events), "completed_batches": sum(e["status"] == "COMPLETED_AUDITED" for e in events), "api_calls": len(events), "c15_read": False, "c15_mutated": False, "batching_disclosed": True}
    (OUT / "metrics/completion.json").write_text(json.dumps(completion, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    claim = "# Claim boundary\n\n- C17 is a fresh synthetic fairness-gated supervisor experiment; it does not read or modify C15.\n- The estimand is the paired endpoint difference caused by provider ordering under an identical two-candidate MPC budget, risk gate, Eq.(11) evaluator, and hidden plant.\n- The LLM claim is bounded to the pre-registered synthetic age-fairness mechanism and is compared with both Rule and TunedNonLLM.\n- Batching is disclosed as a transport limitation; no case or regime is removed after observing outcomes.\n- A result cannot establish deployment feasibility or C15 causal gain.\n"
    (OUT / "claim_boundary.md").write_text(claim, encoding="utf-8")
    close = {"schema_version": "exp09-c17-closeout-v1", "generation": GENERATION, "artifact_status": "C17_COMPLETE" if len(passed) == len(scenarios) else "C17_PARTIAL", "planned_cases": len(scenarios), "completed_cases": len(passed), "failed_cases": len(scenarios) - len(passed), "api_calls": len(events), "c15_read": False, "c15_mutated": False, "batching_disclosed": True}
    (OUT / "closeout.json").write_text(json.dumps(close, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    idx = {p.relative_to(OUT).as_posix(): sha_file(p) for p in OUT.rglob("*") if p.is_file() and p.name != "sha256_index.json"}; (OUT / "sha256_index.json").write_text(json.dumps(idx, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(close, ensure_ascii=False, sort_keys=True)); return 0 if len(passed) == len(scenarios) else 2


if __name__ == "__main__": raise SystemExit(main())
