"""Independent end-to-end latency profile for the EXP09 controller stack.

This stage is deliberately separate from C15 Locked Test.  It measures a
representative corrected local decision pipeline plus the frozen C14.2
provider-call task.  It never changes performance evidence, training state,
or existing artifacts.  Credentials are read only in --live mode and are
never written to the ledger.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import statistics
import time
from typing import Any, Callable

from exp09.contracts.actions import OPPORTUNITY_SCHEMA_VERSION, ControlOpportunity
from exp09.contracts.ids import ControlOpportunityId, VehicleId
from exp09.contracts.observable import (
    OBSERVABLE_COUNTER_SCHEMA_VERSION,
    OBSERVABLE_FRAME_SCHEMA_VERSION,
    OBSERVED_USER_AGE_SCHEMA_VERSION,
    OBSERVED_USER_STATE_SCHEMA_VERSION,
    IdentityState,
    ObservableCounter,
    ObservableCounterKind,
    ObservableFrame,
    ObservedUserAge,
    ObservedUserState,
)
from exp09.contracts.time import DurationUs, SimTimeUs
from exp09.contracts.controller import ControllerResetContext
from exp09.contracts.actions import control_action_fingerprint
from exp09.evaluation.c14_2_provider_profiling import (
    TASKS,
    build_request,
    call_provider,
    load_provider_credentials,
    _credential_path,
    validate_binding,
)
from exp09.evaluation.c14_controllers import _FrozenModelStack, _supervisor_evidence
from exp09.evaluation.c14_controllers import _plain_input


PROTOCOL_GENERATION = "EXP09_C14_2_E2E_LATENCY_PROFILE_20260812"
DEFAULT_ATTEMPTS_PER_TASK = 64
FULL_CONFIG_LOCATOR = "protocol/c14/method_config.C14_1_OFFLINE_CACHE_V3_GPT54MINI_20260730.json"
PROVIDER_CONFIG_LOCATOR = "protocol/c14/provider_config.C14_1_OFFLINE_CACHE_V3_GPT54MINI_20260730.json"
CONTROLLER_CONFIG_LOCATOR = "protocol/c14/c14_1_method_configs.FROZEN_REMEDIATION_20260728.json"


def _sha_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest().upper()


def _sha_file(path: Path) -> str:
    return _sha_bytes(path.read_bytes())


def _canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _canonical_sha(value: Any) -> str:
    return _sha_bytes(_canonical(value))


def _append_jsonl(path: Path, value: dict[str, Any]) -> None:
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
        stream.flush()


def _frame(index: int) -> ObservableFrame:
    vehicle = VehicleId(f"latency-vehicle-{index % 4}")
    users = tuple(
        ObservedUserState(
            schema_version=OBSERVED_USER_STATE_SCHEMA_VERSION,
            vehicle_id=VehicleId(f"latency-user-{item}"),
            ledger_state=IdentityState.FRESH if item % 2 == 0 else IdentityState.STALE_RETAINED,
            identity_silence_us=0,
            age_us=250_000 + index * 100 + item * 20_000,
            age_missing_reason=None,
        )
        for item in range(4)
    )
    counters = tuple(
        ObservableCounter(schema_version=OBSERVABLE_COUNTER_SCHEMA_VERSION, kind=kind, value=value)
        for kind, value in (
            (ObservableCounterKind.FRESH_OBSERVED, 3),
            (ObservableCounterKind.STALE_RETAINED, 1),
            (ObservableCounterKind.UNKNOWN_RETAINED, 0),
            (ObservableCounterKind.BUSY_SENSING_UNIT, 3 + index % 3),
            (ObservableCounterKind.TOTAL_SENSING_UNIT, 10),
            (ObservableCounterKind.DECODED_SUCCESS, 8),
            (ObservableCounterKind.OBSERVABLE_DECODE_TRIAL, 10),
        )
    )
    ages = tuple(
        ObservedUserAge(
            schema_version=OBSERVED_USER_AGE_SCHEMA_VERSION,
            vehicle_id=item.vehicle_id,
            age_us=item.age_us,
        )
        for item in users
    )
    payload = {
        "index": index,
        "vehicle": str(vehicle),
        "ages": [(str(item.vehicle_id), item.age_us) for item in ages],
        "counters": [(item.kind.value, item.value) for item in counters],
    }
    return ObservableFrame(
        schema_version=OBSERVABLE_FRAME_SCHEMA_VERSION,
        source_sequence=index + 1,
        causal_cutoff_us=SimTimeUs(100_000 + index * 100_000),
        summary_payload_hash=_canonical_sha(payload),
        counters=counters,
        missing_reasons=(),
        observed_user_ages=ages,
        observed_users=users,
        removals=(),
    )


def _opportunity(index: int) -> ControlOpportunity:
    return ControlOpportunity(
        schema_version=OPPORTUNITY_SCHEMA_VERSION,
        opportunity_id=ControlOpportunityId(f"c14-2-e2e-latency-{index:04d}"),
        vehicle_id=VehicleId(f"latency-vehicle-{index % 4}"),
        time_us=SimTimeUs(100_000 + index * 100_000),
        reservation_version=1,
        current_rri_us=DurationUs(100_000),
        legal_rri_us=tuple(DurationUs(value) for value in (20_000, 50_000, 100_000, 200_000, 300_000, 500_000, 1_000_000)),
    )


def _timed(fn: Callable[[], Any]) -> tuple[Any, int]:
    started = time.perf_counter_ns()
    value = fn()
    elapsed = max(0, round((time.perf_counter_ns() - started) / 1_000_000))
    return value, elapsed


def _load_config(project_root: Path) -> dict[str, Any]:
    return json.loads((project_root / CONTROLLER_CONFIG_LOCATOR).read_text(encoding="utf-8"))


def _actual_provider_request(project_root: Path, task: str, index: int, frame: ObservableFrame, opportunity: ControlOpportunity, provider_evidence: Any, model_evidence: Any) -> tuple[dict[str, Any], dict[str, Any]]:
    """Build a live request from the measured frame while retaining C14.2 schema."""
    body, synthetic_payload = build_request(project_root, task, index)
    if task == "ProgramProposal":
        payload = {
            "schema_version": "exp09-c14-1-full-supervisor-input-v2",
            "causal_cutoff_us": int(frame.causal_cutoff_us),
            "based_on_sequence": int(frame.source_sequence),
            "program_state": {
                "schema_version": "exp09-program-state-v1",
                "state_hash": _canonical_sha({"index": index, "program": "balanced"}),
                "current_program_id": "balanced",
                "current_started_us": 0,
                "last_transition_us": 0,
                "remaining_budget_units": 1,
            },
            "eligible_proposals": [
                {"transition_id": "HOLD", "target_program_id": "balanced"},
                {"transition_id": "SWITCH", "target_program_id": "protect-freshness"},
            ],
            "evidence": {
                "schema_version": "exp09-evidence-bundle-v1",
                "evidence_id": str(provider_evidence.evidence_id),
                "causal_cutoff_us": int(provider_evidence.causal_cutoff_us),
                "detector_active": bool(provider_evidence.detector_active),
                "risk_ppm": int(provider_evidence.risk_ppm),
                "memory_interval_low_ppm": int(provider_evidence.memory_interval_low_ppm),
                "memory_interval_high_ppm": int(provider_evidence.memory_interval_high_ppm),
            },
            "evidence_hash": str(provider_evidence.evidence_hash),
            "remaining_budget": {"program_transition_units": 1, "provider_request_units": 1},
        }
    else:
        action_ids = tuple(
            control_action_fingerprint(action)
                for action in model_evidence.candidates.actions
        )
        payload = _plain_input(frame, opportunity, action_ids)
    # Replace the synthetic JSON wrapper with the measured observable payload.
    prompt_path = project_root / ("protocol/c14/full_protocol.C14_1_OFFLINE_CACHE_V2_20260729.json" if task == "ProgramProposal" else "protocol/c14/plain_llm_protocol.C14_1_OFFLINE_CACHE_V2_20260729.json")
    prompt = json.loads(prompt_path.read_text(encoding="utf-8"))
    body["messages"][1]["content"] = json.dumps(
        {"instruction": prompt["user_prompt_template"]["instruction"], "input": payload},
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    if task == "Plain_LLM":
        actions = list(payload["eligible_actions"])
        schema = body["response_format"]["json_schema"]["schema"]
        schema["properties"]["candidate_order"]["items"]["enum"] = actions
        schema["properties"]["candidate_order"]["minItems"] = len(actions)
        schema["properties"]["candidate_order"]["maxItems"] = len(actions)
        schema["properties"]["chosen_action_id"]["enum"] = actions
    return body, payload


def _profile_one(project_root: Path, task: str, index: int, *, live: bool, stack: _FrozenModelStack, credentials: Any | None) -> dict[str, Any]:
    started_ns = time.perf_counter_ns()
    frame, input_ms = _timed(lambda: _frame(index))
    opportunity, opportunity_ms = _timed(lambda: _opportunity(index))
    evidence, tool_ms = _timed(lambda: stack.evaluate(frame, opportunity))
    evidence_started = time.perf_counter_ns()
    supervisor_evidence = _supervisor_evidence(
            frame,
            opportunity,
            selected_risk_ppm=evidence.selected_risk_ppm,
            detector_threshold_ppm=250_000,
        )
    evidence_ms = max(0, round((time.perf_counter_ns() - evidence_started) / 1_000_000))
    body, payload = _actual_provider_request(project_root, task, index, frame, opportunity, supervisor_evidence, evidence)
    provider_ms = 0
    provider_status = "DRY_RUN_SIMULATED"
    provider_error = None
    request_hash = _canonical_sha(body)
    response_hash = None
    if live:
        if credentials is None:
            raise RuntimeError("live profiling requires provider credentials")
        result, provider_ms = _timed(lambda: call_provider(credentials, body, task, payload))
        provider_status = result.status
        provider_error = result.error_category
        response_hash = result.response_body_sha256
    else:
        # Dry-run intentionally avoids network/API and exercises only local stages.
        time.sleep(0.001)
    post_started = time.perf_counter_ns()
    post_value = {
            "action_fingerprint": control_action_fingerprint(evidence.gated_action),
            "observation_hash": frame.summary_payload_hash,
            "provider_status": provider_status,
        }
    post_ms = max(0, round((time.perf_counter_ns() - post_started) / 1_000_000))
    total_ms = max(0, round((time.perf_counter_ns() - started_ns) / 1_000_000))
    return {
        "schema_version": "exp09-c14-2-e2e-latency-row-v1",
        "protocol_generation": PROTOCOL_GENERATION,
        "task": task,
        "index": index,
        "mode": "live" if live else "dry_run",
        "provider_payload_kind": "C14.2_frozen_synthetic_profile_payload",
        "request_hash": request_hash,
        "response_body_sha256": response_hash,
        "provider_status": provider_status,
        "provider_error_category": provider_error,
        "stage_ms": {
            "input_prepare": input_ms,
            "opportunity_prepare": opportunity_ms,
            "tool_execution_and_candidate_rollout": tool_ms,
            "evidence_synthesis": evidence_ms,
            "provider_call_and_response_validation": provider_ms,
            "post_provider_safety_commit": post_ms,
        },
        "total_decision_ms": total_ms,
        "notes": [
            "C15 Locked Test is not rerun or modified.",
            "The provider payload follows the frozen C14.2 synthetic profile contract; local model/rollout stages use the corrected controller stack.",
            "This is a latency profile, not a performance endpoint or deployment-feasibility proof.",
        ],
        "post_value": post_value,
    }


def _percentile(values: list[int], fraction: float) -> int | None:
    if not values:
        return None
    ordered = sorted(values)
    index = max(0, min(len(ordered) - 1, int((len(ordered) * fraction + 0.999999999) - 1)))
    return int(ordered[index])


def _summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    by_task: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        by_task.setdefault(str(row["task"]), []).append(row)
    result: dict[str, Any] = {}
    for task, items in sorted(by_task.items()):
        totals = [int(item["total_decision_ms"]) for item in items]
        provider = [int(item["stage_ms"]["provider_call_and_response_validation"]) for item in items if item["mode"] == "live"]
        result[task] = {
            "n": len(items),
            "completed": sum(item["provider_status"] in {"COMPLETED_AUDITED", "DRY_RUN_SIMULATED"} for item in items),
            "failed": sum(item["provider_status"] not in {"COMPLETED_AUDITED", "DRY_RUN_SIMULATED"} for item in items),
            "total_decision_ms": {
                "median": int(statistics.median(totals)),
                "p95": _percentile(totals, 0.95),
                "p99": _percentile(totals, 0.99),
                "max": max(totals),
            },
            "provider_call_ms": {
                "median": int(statistics.median(provider)) if provider else None,
                "p95": _percentile(provider, 0.95),
                "p99": _percentile(provider, 0.99),
                "max": max(provider) if provider else None,
            },
            "stage_median_ms": {
                name: int(statistics.median(int(item["stage_ms"][name]) for item in items))
                for name in items[0]["stage_ms"]
            },
        }
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--attempts-per-task", type=int, default=DEFAULT_ATTEMPTS_PER_TASK)
    parser.add_argument("--live", action="store_true")
    args = parser.parse_args()
    project_root = args.project_root.resolve()
    output_root = args.output_root.resolve()
    if output_root.exists():
        raise SystemExit(f"append-only output already exists: {output_root}")
    if args.attempts_per_task <= 0 or args.attempts_per_task > 128:
        raise SystemExit("attempts-per-task must be in 1..128")
    if args.live:
        binding = validate_binding(project_root)
    else:
        binding = {
            "provider_validation": "SKIPPED_IN_DRY_RUN",
            "credential_file_read": False,
            "api_key_recorded": False,
            "model_config_sha256": _sha_file(project_root / CONTROLLER_CONFIG_LOCATOR),
        }
    output_root.mkdir(parents=True, exist_ok=False)
    manifest = {
        "schema_version": "exp09-c14-2-e2e-latency-manifest-v1",
        "artifact_status": "AUTHORIZED_EXECUTION_STARTED",
        "protocol_generation": PROTOCOL_GENERATION,
        "mode": "live" if args.live else "dry_run",
        "tasks": list(TASKS),
        "attempts_per_task": args.attempts_per_task,
        "training": False,
        "tuning": False,
        "c15_locked_test_touched": False,
        "api_key_recorded": False,
        "provider_binding": binding,
        "source_files": {
            FULL_CONFIG_LOCATOR: _sha_file(project_root / FULL_CONFIG_LOCATOR),
            PROVIDER_CONFIG_LOCATOR: _sha_file(project_root / PROVIDER_CONFIG_LOCATOR),
        },
    }
    (output_root / "profiling_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    rows_path = output_root / "e2e_latency_rows.ndjson"
    stack = _FrozenModelStack(_load_config(project_root))
    credentials = load_provider_credentials(_credential_path(project_root), profile="primary") if args.live else None
    rows: list[dict[str, Any]] = []
    try:
        for task in TASKS:
            for index in range(args.attempts_per_task):
                row = _profile_one(project_root, task, index, live=args.live, stack=stack, credentials=credentials)
                rows.append(row)
                _append_jsonl(rows_path, row)
    except BaseException as exc:
        (output_root / "profiling_summary.json").write_text(json.dumps({"artifact_status": "FAIL_CLOSED", "failure": type(exc).__name__, "message": str(exc), "api_key_recorded": False}, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        raise
    summary = {
        "schema_version": "exp09-c14-2-e2e-latency-summary-v1",
        "artifact_status": "COMPLETE_APPEND_ONLY_STOP",
        "protocol_generation": PROTOCOL_GENERATION,
        "mode": "live" if args.live else "dry_run",
        "rows": len(rows),
        "summary_by_task": _summarize(rows),
        "api_key_recorded": False,
        "c15_locked_test_touched": False,
        "claim_boundary": {
            "allowed": ["measured end-to-end profile under this provider/model/software configuration"],
            "forbidden": ["universal real-time feasibility", "deployment-ready", "performance superiority", "C15 endpoint claims"],
        },
        "rows_sha256": _sha_file(rows_path),
    }
    summary_path = output_root / "profiling_summary.json"
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    index = {name: _sha_file(output_root / name) for name in ("profiling_manifest.json", "e2e_latency_rows.ndjson", "profiling_summary.json")}
    index["integrity_index_sha256"] = _canonical_sha(index)
    (output_root / "sha256_index.json").write_text(json.dumps(index, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, sort_keys=True, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
