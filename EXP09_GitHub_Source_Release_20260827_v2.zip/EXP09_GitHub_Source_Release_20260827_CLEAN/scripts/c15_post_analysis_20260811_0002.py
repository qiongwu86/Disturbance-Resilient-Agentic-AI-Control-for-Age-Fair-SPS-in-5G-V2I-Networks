"""Run the frozen C15 0002 post-analysis specification offline."""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
SOURCE_GEN = "EXP09_C15_LOCKED_TEST_20260807_0004"
POST_GEN = "EXP09_C15_POST_ANALYSIS_20260811_0002"
MAP_GEN = "EXP09_C15_MAPPING_RELEASE_20260811_0002"
UNBLIND_GEN = "EXP09_C15_UNBLIND_20260811_0002"
STAGE = Path(tempfile.gettempdir()) / "exp09_c15_post_analysis_20260811_0002"
OUT = STAGE / "artifacts/c15_post_analysis_20260811_0002"
SPEC = ROOT / "protocol/c15/c15_post_analysis_spec_20260811_0002.json"
EXPORT = ROOT / "artifacts/c15_closeout_20260811_0003/anonymous_root_endpoint_export.json"
MAPPING = ROOT / "artifacts/c15_mapping_release_20260811_0002/mapping_release.json"
UNBLIND = ROOT / "artifacts/c15_unblind_20260811_0002/unblind_evidence.json"
METHODS = ("Full", "RMPC_SameEvaluator", "Rule_SameStack", "TunedNonLLM_SameStack", "Plain_LLM", "DQN", "GNN_DDQN", "AoI_aware_heuristic", "Greedy_1", "Nominal_MPC")


def canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().upper()


def write_once(path: Path, value: dict[str, Any]) -> str:
    payload = canonical(value)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != payload:
            raise RuntimeError(f"append-only drift: {path}")
    else:
        with path.open("xb") as stream:
            stream.write(payload); stream.flush(); os.fsync(stream.fileno())
    return hashlib.sha256(payload).hexdigest().upper()


def read(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"JSON object required: {path}")
    return value


def main() -> None:
    spec = read(SPEC); export = read(EXPORT); mapping = read(MAPPING); unblind = read(UNBLIND)
    if spec.get("protocol_generation") != POST_GEN or spec.get("artifact_status") != "C15_POST_ANALYSIS_SPEC_FROZEN_BEFORE_EXECUTION":
        raise RuntimeError("post-analysis spec is not frozen")
    if spec.get("source_c15_protocol_generation") != SOURCE_GEN or spec.get("mapping_generation") != MAP_GEN or spec.get("unblind_generation") != UNBLIND_GEN:
        raise RuntimeError("post-analysis generation binding drift")
    if mapping.get("protocol_generation") != MAP_GEN or unblind.get("protocol_generation") != UNBLIND_GEN:
        raise RuntimeError("mapping/unblind generation drift")
    if export.get("protocol_generation") != SOURCE_GEN or export.get("method_identity_exported") is not False or export.get("identity_leakage") is not False:
        raise RuntimeError("anonymous export contract drift")
    labels = list(export.get("anonymous_labels", []))
    if labels != [f"LABEL_{i:02d}" for i in range(10)]:
        raise RuntimeError("label topology drift")
    rows = export.get("rows", [])
    by_label_arm: dict[tuple[str, str], list[float]] = {}
    for row in rows:
        by_label_arm.setdefault((row["anonymous_label"], row["arm"]), []).append(float(row["endpoint_values"]["mean_aoi_ms"]))
    summary = []
    for i, method in enumerate(METHODS):
        label = f"LABEL_{i:02d}"
        for arm in ("REFERENCE", "EVENT"):
            values = by_label_arm[(label, arm)]
            summary.append({"method_id": method, "anonymous_label": label, "arm": arm, "root_count": len(values), "mean_mean_aoi_ms": round(sum(values) / len(values), 9)})
    evidence = {"schema_version": "exp09-c15-post-analysis-v2", "artifact_status": "C15_POST_ANALYSIS_COMPLETE_INDEPENDENT_GENERATION", "protocol_generation": POST_GEN, "source_c15_protocol_generation": SOURCE_GEN, "mapping_generation": MAP_GEN, "unblind_generation": UNBLIND_GEN, "spec_sha256": sha_file(SPEC), "source_export_sha256": sha_file(EXPORT), "mapping_release_sha256": sha_file(MAPPING), "unblind_evidence_sha256": sha_file(UNBLIND), "analysis_type": "offline_descriptive_and_AD06B_absolute_effect_audit", "root_independent_unit": True, "rl_seed_aggregation_before_inference": True, "summary": summary, "summary_unit": "method_label_by_arm_root_rows", "descriptive_only": True, "practical_margin": False, "superiority": False, "non_inferiority": False, "non_harm": False, "fairness_improvement": False, "all_baseline_best": False, "deployment_claim": False, "api_calls": 0, "provider_calls": 0, "network_calls": 0, "training": False, "tuning": False, "paper_results_or_figures_generated": False, "claim_boundary": "AD-06B"}
    evidence_sha = write_once(OUT / "post_analysis_evidence.json", evidence)
    index_sha = write_once(OUT / "sha256_index.json", {"schema_version": "exp09-c15-post-analysis-sha256-index-v2", "protocol_generation": POST_GEN, "files": {"post_analysis_evidence.json": evidence_sha, "spec": sha_file(SPEC), "source_export": sha_file(EXPORT), "mapping_release": sha_file(MAPPING), "unblind_evidence": sha_file(UNBLIND)}})
    closeout_sha = write_once(OUT / "post_analysis_closeout.json", {"schema_version": "exp09-c15-post-analysis-closeout-v1", "artifact_status": "C15_POST_ANALYSIS_EVIDENCE_FROZEN", "protocol_generation": POST_GEN, "spec_sha256": sha_file(SPEC), "evidence_sha256": evidence_sha, "index_sha256": index_sha, "summary_rows": len(summary), "api_calls": 0, "provider_calls": 0, "network_calls": 0, "training": False, "tuning": False, "paper_results_or_figures_generated": False, "stop_boundary": "STOP_BEFORE_PAPER_FINAL_RESULTS_TABLES_FIGURES", "claim_boundary": "AD-06B"})
    print(json.dumps({"protocol_generation": POST_GEN, "evidence_sha256": evidence_sha, "index_sha256": index_sha, "closeout_sha256": closeout_sha, "summary_rows": len(summary), "api_calls": 0, "provider_calls": 0, "network_calls": 0, "paper_results_or_figures_generated": False}, sort_keys=True))


if __name__ == "__main__":
    main()
