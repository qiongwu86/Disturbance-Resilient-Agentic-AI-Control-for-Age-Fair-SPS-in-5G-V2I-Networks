"""Bind the frozen post-analysis spec to its completed offline evidence."""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
STAGE = Path(tempfile.gettempdir()) / "exp09_c15_post_analysis_20260811_0002"
SPEC = ROOT / "protocol/c15/c15_post_analysis_spec_20260811_0002.json"
EVIDENCE = STAGE / "artifacts/c15_post_analysis_20260811_0002/post_analysis_evidence.json"
INDEX = STAGE / "artifacts/c15_post_analysis_20260811_0002/sha256_index.json"
CLOSEOUT = STAGE / "artifacts/c15_post_analysis_20260811_0002/post_analysis_closeout.json"
PROTOCOL = STAGE / "protocol/c15/c15_post_analysis_protocol_20260811_0002.json"


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().upper()


def canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def write_once(path: Path, value: dict[str, Any]) -> str:
    payload = canonical(value); path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != payload: raise RuntimeError(f"append-only drift: {path}")
    else:
        with path.open("xb") as stream:
            stream.write(payload); stream.flush(); os.fsync(stream.fileno())
    return hashlib.sha256(payload).hexdigest().upper()


def main() -> None:
    for path in (SPEC, EVIDENCE, INDEX, CLOSEOUT):
        if not path.is_file(): raise RuntimeError(f"missing post-analysis evidence: {path}")
    spec = json.loads(SPEC.read_text(encoding="utf-8")); evidence = json.loads(EVIDENCE.read_text(encoding="utf-8")); close = json.loads(CLOSEOUT.read_text(encoding="utf-8"))
    if spec.get("protocol_generation") != "EXP09_C15_POST_ANALYSIS_20260811_0002" or spec.get("artifact_status") != "C15_POST_ANALYSIS_SPEC_FROZEN_BEFORE_EXECUTION": raise RuntimeError("spec drift")
    if evidence.get("spec_sha256") != sha(SPEC) or close.get("evidence_sha256") != sha(EVIDENCE) or close.get("spec_sha256") != sha(SPEC): raise RuntimeError("post-analysis binding drift")
    protocol = {"schema_version": "exp09-c15-post-analysis-protocol-v1", "protocol_generation": spec["protocol_generation"], "spec_sha256": sha(SPEC), "evidence_sha256": sha(EVIDENCE), "index_sha256": sha(INDEX), "closeout_sha256": sha(CLOSEOUT), "offline_only": True, "preregistered": True, "summary_rows": len(evidence.get("summary", [])), "api_calls": 0, "provider_calls": 0, "network_calls": 0, "training": False, "tuning": False, "paper_results_or_figures_generated": False, "stop_boundary": "STOP_BEFORE_PAPER_FINAL_RESULTS_TABLES_FIGURES", "claim_boundary": "AD-06B"}
    protocol_sha = write_once(PROTOCOL, protocol)
    print(json.dumps({"protocol_sha256": protocol_sha, "api_calls": 0, "provider_calls": 0, "network_calls": 0, "paper_results_or_figures_generated": False}, sort_keys=True))


if __name__ == "__main__": main()
