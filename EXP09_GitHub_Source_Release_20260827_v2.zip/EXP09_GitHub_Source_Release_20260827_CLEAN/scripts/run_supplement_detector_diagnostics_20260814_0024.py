"""Observable-only detector quality + endpoint diagnostics (append-only).

The detector is evaluated with exactly the 0018 EWMA/CUSUM/hysteresis rule.
The controller receives only observable frames; the synthetic tape anchor is
used after the run, solely as an offline scoring label.  No C15 artifact is
written and no network/provider call is made.
"""
from __future__ import annotations

import csv, hashlib, json, statistics, sys
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
from exp09.artifacts.canonical import canonical_sha256
from exp09.contracts.actions import ActionKind
from exp09.contracts.controller import COMMITMENT_SCHEMA_VERSION, CommitmentRecord, ControllerResetContext
from exp09.contracts.observable import ObservableCounterKind
from exp09.contracts.tape import TapeArm
from exp09.evaluation.disturbance_tape import build_primary_influx_tape
from exp09.evaluation.runner import replay_observable_frames, run_open_loop_case
from exp09.evaluation.c14_controllers import _FrozenModelStack

GENERATION = "EXP09_SUPPLEMENT_VALIDATION_20260814_0024"
OUT = ROOT / "paper_outputs" / "exp09_supplement_validation_20260814_0024"
CONFIG_LOCATOR = "protocol/c14/c14_1_method_configs.FROZEN_REMEDIATION_20260728.json"
ROOTS = tuple(f"c15_locked_test_{i:03d}" for i in range(115, 119))
ARMS = ("REFERENCE", "EVENT")
SOURCE_0018 = ROOT / "paper_outputs/exp09_supplement_validation_20260813_0018"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


class DiagnosticDetectorController:
    """Exact 0018 observable detector with an audit record per decision."""

    def __init__(self, config: dict):
        self.stack = _FrozenModelStack(config)
        self.ewma = 0.0
        self.cusum = 0.0
        self.active_count = 0
        self.reset_done = False
        self.records: list[dict] = []

    def reset(self, context: ControllerResetContext) -> None:
        self.reset_done = True
        self.ewma = 0.0
        self.cusum = 0.0
        self.active_count = 0
        self.records = []

    def _active(self, frame) -> tuple[bool, float, float, float]:
        counters = {x.kind: int(x.value) for x in frame.counters}
        busy = counters.get(ObservableCounterKind.BUSY_SENSING_UNIT, 0)
        total = counters.get(ObservableCounterKind.TOTAL_SENSING_UNIT, 0)
        succ = counters.get(ObservableCounterKind.DECODED_SUCCESS, 0)
        trials = counters.get(ObservableCounterKind.OBSERVABLE_DECODE_TRIAL, 0)
        busy_ratio = busy / total if total else 0.0
        collision = 1.0 - succ / trials if trials else 0.0
        ages = [int(x.age_us or 0) for x in frame.observed_user_ages]
        age = min(1.0, statistics.fmean(ages) / 1_000_000.0) if ages else 0.0
        residual = min(1.0, 0.55 * busy_ratio + 0.25 * collision + 0.10 * min(1.0, len(frame.observed_users) / 9) + 0.10 * age)
        self.ewma = 0.25 * residual + 0.75 * self.ewma
        self.cusum = max(0.0, self.cusum + residual - 0.32)
        hit = self.ewma >= 0.22 or self.cusum >= 0.45
        self.active_count = self.active_count + 1 if hit else 0
        return self.active_count >= 2, residual, self.ewma, self.cusum

    def decide(self, frame, opportunity) -> CommitmentRecord:
        if not self.reset_done:
            raise RuntimeError("detector controller requires reset")
        ev = self.stack.evaluate(frame, opportunity)
        active, residual, ewma, cusum = self._active(frame)
        if active:
            action = min((a for a in ev.candidates.actions if a.target_rri_us is not None), key=lambda a: int(a.target_rri_us or 0))
        else:
            action = ev.gated_action
        self.records.append({
            "time_us": int(opportunity.time_us),
            "active": bool(active),
            "residual": residual,
            "ewma": ewma,
            "cusum": cusum,
            "action_kind": action.kind.value,
            "target_rri_us": action.target_rri_us,
        })
        return CommitmentRecord(schema_version=COMMITMENT_SCHEMA_VERSION, observation_hash=canonical_sha256(frame, expected_schema_version=frame.schema_version), action=action)


def diagnostic_row(root: str, arm: str, result, controller: DiagnosticDetectorController) -> dict:
    tape = build_primary_influx_tape(root, TapeArm(arm))
    onset = int(tape.paired_anchor_simulation_time_us) if arm == "EVENT" else None
    records = list(controller.records)
    pre = [r for r in records if onset is not None and r["time_us"] < onset]
    post = [r for r in records if onset is not None and r["time_us"] >= onset]
    if arm == "EVENT":
        first = next((r["time_us"] for r in post if r["active"]), None)
        delay = None if first is None else (first - onset) / 1000.0
        fp_count = sum(1 for r in pre if r["active"])
        fn_count = sum(1 for r in post if not r["active"])
        fpr = fp_count / len(pre) if pre else 0.0
        fnr = fn_count / len(post) if post else 0.0
        missed = int(first is None)
    else:
        first = None
        delay = None
        fp_count = sum(1 for r in records if r["active"])
        fn_count = None
        fpr = fp_count / len(records) if records else 0.0
        fnr = None
        missed = 0
    triggers = sum(1 for prev, cur in zip([False] + [bool(r["active"]) for r in records[:-1]], [bool(r["active"]) for r in records]) if cur and not prev)
    return {
        "generation": GENERATION,
        "root_family": root,
        "arm": arm,
        "regime": "nominal" if arm == "REFERENCE" else "harm",
        "onset_simulation_us": onset,
        "decision_count": len(records),
        "first_active_simulation_us": first,
        "detection_delay_ms": delay,
        "false_positive_count": fp_count,
        "false_positive_rate": fpr,
        "false_negative_count": fn_count,
        "false_negative_rate": fnr,
        "missed_event_count": missed,
        "trigger_count": triggers,
        "pre_onset_decision_count": len(pre) if onset is not None else len(records),
        "post_onset_decision_count": len(post) if onset is not None else 0,
        "endpoint_mean_aoi_ms": float(result.metrics.mean_aoi_ms),
        "endpoint_q95_aoi_ms": float(result.metrics.q95_aoi_ms),
        "endpoint_jain_freshness": float(result.metrics.jain_freshness),
        "endpoint_collision_event_rate": float(result.metrics.collision_event_rate),
        "integrity_hash": result.integrity_hash,
        "status": "PASSED_EXECUTED",
        "api_calls": 0,
        "provider_calls": 0,
        "c15_mutated": False,
    }


def mean_ci(vals: list[float], seed: int) -> tuple[float, float, float]:
    if not vals:
        return (None, None, None)
    if len(vals) == 1:
        return (vals[0], vals[0], vals[0])
    import random
    rng = random.Random(seed)
    boots = [statistics.fmean(vals[rng.randrange(len(vals))] for _ in vals) for _ in range(5000)]
    boots.sort()
    return statistics.fmean(vals), boots[125], boots[4874]


def main() -> None:
    if OUT.exists() and any(p.is_file() for p in OUT.rglob("*")):
        raise SystemExit(f"append-only output exists: {OUT}")
    for d in ("protocol", "raw", "detector", "statistics", "tables"):
        (OUT / d).mkdir(parents=True, exist_ok=True)
    config_path = ROOT / CONFIG_LOCATOR
    spec = {
        "schema_version": "exp09-detector-diagnostics-v1",
        "generation": GENERATION,
        "algorithm": "EWMA alpha=.25 + CUSUM reference=.32 threshold=.45 + two consecutive hits",
        "observable_inputs": ["busy_sensing_unit_count", "total_sensing_unit_count", "decoded_success_count", "observable_decode_trial_count", "observed_user_ages"],
        "roots": list(ROOTS), "arms": list(ARMS), "config_locator": CONFIG_LOCATOR, "config_sha256": sha(config_path),
        "truth_label_use": "offline scoring only; onset never enters controller observation",
        "source_endpoint_generation": "EXP09_SUPPLEMENT_VALIDATION_20260813_0018",
        "source_endpoint_table_sha256": sha(SOURCE_0018 / "tables/tableS7_detector_endpoint_comparison.csv"),
        "network": False, "api_calls": 0, "provider_calls": 0, "c15_mutated": False,
    }
    (OUT / "protocol/spec.json").write_text(json.dumps(spec, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    rows = []
    for root in ROOTS:
        for arm in ARMS:
            cfg = json.loads(config_path.read_text(encoding="utf-8"))
            controller = DiagnosticDetectorController(cfg)
            result = run_open_loop_case(root, TapeArm(arm), controller=controller)
            rows.append(diagnostic_row(root, arm, result, controller))
    with (OUT / "raw/diagnostic_case_rows.jsonl").open("w", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
    with (OUT / "detector/detection_events.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    aggregate = []
    for regime in ("nominal", "harm"):
        group = [r for r in rows if r["regime"] == regime]
        entry = {"generation": GENERATION, "regime": regime, "n_cases": len(group), "quality_unit": "case"}
        for metric in ("detection_delay_ms", "false_positive_rate", "false_negative_rate", "missed_event_count", "trigger_count"):
            vals = [float(r[metric]) for r in group if r[metric] is not None]
            mean, lo, hi = mean_ci(vals, 20260814 + len(aggregate))
            entry[f"{metric}_mean"] = mean; entry[f"{metric}_ci95_low"] = lo; entry[f"{metric}_ci95_high"] = hi
        for metric in ("endpoint_mean_aoi_ms", "endpoint_q95_aoi_ms", "endpoint_jain_freshness", "endpoint_collision_event_rate"):
            vals = [float(r[metric]) for r in group]
            mean, lo, hi = mean_ci(vals, 20400 + len(aggregate))
            entry[f"{metric}_mean"] = mean; entry[f"{metric}_ci95_low"] = lo; entry[f"{metric}_ci95_high"] = hi
        aggregate.append(entry)
    with (OUT / "detector/diagnostics.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(aggregate[0])); writer.writeheader(); writer.writerows(aggregate)
    # Preserve the already audited endpoint table in a new generation, with a source hash.
    endpoint_rows = list(csv.DictReader((SOURCE_0018 / "tables/tableS7_detector_endpoint_comparison.csv").open(encoding="utf-8-sig")))
    table_rows = []
    for row in endpoint_rows:
        row = dict(row); row["evidence_type"] = "endpoint_impact"; table_rows.append(row)
    for row in aggregate:
        row = dict(row); row["evidence_type"] = "detector_quality"; table_rows.append(row)
    fields = sorted({key for row in table_rows for key in row})
    with (OUT / "tables/tableS7_detector_metrics.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore"); writer.writeheader(); writer.writerows(table_rows)
    summary = {"generation": GENERATION, "planned_cases": 8, "completed_cases": len(rows), "failed_cases": 0, "quality_metrics": ["detection_delay_ms", "false_positive_rate", "false_negative_rate", "missed_event_count", "trigger_count"], "endpoint_rows_reused": len(endpoint_rows), "deployment_validation": False, "synthetic_small_n": True, "c15_mutated": False, "api_calls": 0, "provider_calls": 0}
    (OUT / "statistics/summary.json").write_text(json.dumps(summary, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    claim = """# Claim boundary\n\n- 8/8 observable-detector diagnostic cases completed on the same 4-root/2-arm protocol used by endpoint generation 0018.\n- Detection delay, FPR, FNR, missed events, and trigger counts are reported per case and by regime; endpoint rows are carried forward with their source hash.\n- The onset and EVENT/REFERENCE labels are used only for offline scoring. They are not observable inputs to the controller.\n- This is synthetic small-N validation of an observable interface and action-branch integration. It is not field observability, deployment validation, universal detector accuracy, or real-time certification.\n"""
    (OUT / "claim_boundary.md").write_text(claim, encoding="utf-8")
    closeout = {"schema_version": "exp09-detector-diagnostics-closeout-v1", "generation": GENERATION, "artifact_status": "DETECTOR_DIAGNOSTICS_COMPLETE", "planned_cases": 8, "completed_cases": len(rows), "failed_cases": 0, "endpoint_rows_reused": len(endpoint_rows), "deployment_validation": False, "synthetic_small_n": True, "network": False, "api_calls": 0, "provider_calls": 0, "c15_mutated": False}
    (OUT / "closeout.json").write_text(json.dumps(closeout, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    index = {p.relative_to(OUT).as_posix(): sha(p) for p in OUT.rglob("*") if p.is_file() and p.name != "sha256_index.json"}
    (OUT / "sha256_index.json").write_text(json.dumps(index, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(closeout, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
