"""Causal receiver ledger, retained-identity FSM, and summary transport."""

from dataclasses import dataclass

from exp09.artifacts.canonical import canonical_sha256
from exp09.contracts.observable import (
    IDENTITY_REMOVAL_SCHEMA_VERSION,
    MEASUREMENT_SUMMARY_HEADER_SCHEMA_VERSION,
    OBSERVABLE_COUNTER_SCHEMA_VERSION,
    OBSERVABLE_FRAME_SCHEMA_VERSION,
    OBSERVED_USER_AGE_SCHEMA_VERSION,
    OBSERVED_USER_STATE_SCHEMA_VERSION,
    IdentityRemoval,
    IdentityRemovalReason,
    IdentityState,
    MeasurementDeliveryEvent,
    MeasurementSummaryHeader,
    MissingReasonCode,
    ObservableCounter,
    ObservableCounterKind,
    ObservableFrame,
    ObservedUserAge,
    ObservedUserState,
    ReceiverAttemptObservation,
    ReceiverIdentityEvent,
    ReceiverObservableKind,
    ReceiverPacketObservation,
)
from exp09.contracts.ids import require_identifier
from exp09.contracts.time import SimTimeUs, require_non_negative_int

FRESH_TIMEOUT_US = 300_000
UNKNOWN_TIMEOUT_US = 1_000_000
SUMMARY_PERIOD_US = 50_000
AGGREGATION_WINDOW_US = 500_000
SUMMARY_MAX_AGE_US = 100_000
MEASUREMENT_DELAY_US = 10_000
TELEMETRY_DROPOUT_DURATION_US = 500_000
SENSING_SLOT_US = 1_000
MEASUREMENT_SUMMARY_SCHEMA_VERSION = "exp09-measurement-summary-v2"
DELIVERED_SUMMARY_SCHEMA_VERSION = "exp09-delivered-summary-v1"
LEDGER_SNAPSHOT_SCHEMA_VERSION = "exp09-ledger-snapshot-v2"


@dataclass(frozen=True, slots=True)
class MeasurementSummary:
    schema_version: str
    header: MeasurementSummaryHeader
    known_vehicle_count: int
    fresh_count: int
    stale_count: int
    unknown_count: int
    decoded_success_count: int
    decode_trial_count: int
    busy_sensing_slot_count: int
    eligible_sensing_slot_count: int
    last_success_by_vehicle: tuple[tuple[str, int], ...]
    last_observed_at_by_vehicle: tuple[tuple[str, int], ...]
    removed_vehicle_ids: tuple[str, ...]
    observed_users: tuple[ObservedUserState, ...]
    removals: tuple[IdentityRemoval, ...]

    def __post_init__(self) -> None:
        if self.schema_version != MEASUREMENT_SUMMARY_SCHEMA_VERSION:
            raise ValueError("unsupported measurement-summary schema version")
        if not isinstance(self.header, MeasurementSummaryHeader):
            raise ValueError("header must be a MeasurementSummaryHeader")
        count_fields = (
            "known_vehicle_count",
            "fresh_count",
            "stale_count",
            "unknown_count",
            "decoded_success_count",
            "decode_trial_count",
            "busy_sensing_slot_count",
            "eligible_sensing_slot_count",
        )
        for field_name in count_fields:
            require_non_negative_int(getattr(self, field_name), field_name)
        if self.fresh_count + self.stale_count + self.unknown_count != self.known_vehicle_count:
            raise ValueError("identity-state counts must equal known_vehicle_count")
        if self.decoded_success_count > self.decode_trial_count:
            raise ValueError("decoded_success_count cannot exceed decode_trial_count")
        if self.busy_sensing_slot_count > self.eligible_sensing_slot_count:
            raise ValueError("busy_sensing_slot_count cannot exceed eligible_sensing_slot_count")

        cutoff_us = int(self.header.causal_cutoff_us)
        if cutoff_us % SUMMARY_PERIOD_US or self.header.sequence != cutoff_us // SUMMARY_PERIOD_US:
            raise ValueError("summary sequence does not match the frozen generation lattice")
        expected_eligible_slots = (
            cutoff_us - int(self.header.window_start_us)
        ) // SENSING_SLOT_US
        if self.eligible_sensing_slot_count != expected_eligible_slots:
            raise ValueError("eligible_sensing_slot_count does not match the summary window")

        last_success = _validate_vehicle_time_pairs(
            self.last_success_by_vehicle,
            "last_success_by_vehicle",
            cutoff_us,
        )
        last_observed = _validate_vehicle_time_pairs(
            self.last_observed_at_by_vehicle,
            "last_observed_at_by_vehicle",
            cutoff_us,
        )
        if not isinstance(self.observed_users, tuple) or not all(
            isinstance(item, ObservedUserState) for item in self.observed_users
        ):
            raise ValueError("observed_users must contain only ObservedUserState values")
        if self.observed_users != tuple(
            sorted(self.observed_users, key=lambda item: str(item.vehicle_id))
        ):
            raise ValueError("observed_users must be in canonical vehicle order")
        observed_by_id = {str(item.vehicle_id): item for item in self.observed_users}
        if len(observed_by_id) != len(self.observed_users):
            raise ValueError("observed user IDs must be unique")
        if set(observed_by_id) != set(last_observed):
            raise ValueError("observed_users must match last_observed_by_vehicle")
        if len(observed_by_id) != self.known_vehicle_count:
            raise ValueError("observed_users must match known_vehicle_count")
        actual_state_counts = {
            state: sum(item.ledger_state is state for item in self.observed_users)
            for state in IdentityState
        }
        if (
            actual_state_counts[IdentityState.FRESH] != self.fresh_count
            or actual_state_counts[IdentityState.STALE_RETAINED] != self.stale_count
            or actual_state_counts[IdentityState.UNKNOWN_RETAINED] != self.unknown_count
        ):
            raise ValueError("observed user states do not match identity-state counts")
        for vehicle_id, user in observed_by_id.items():
            observed_at_us = last_observed[vehicle_id]
            if user.identity_silence_us != cutoff_us - observed_at_us:
                raise ValueError("observed user silence does not match last observation time")
            expected_state = _state_at_delivery(user.identity_silence_us)
            if user.ledger_state is not expected_state:
                raise ValueError("observed user state does not match identity silence")
            generation_us = last_success.get(vehicle_id)
            if generation_us is None:
                if user.age_us is not None:
                    raise ValueError("observed user age lacks a last-success record")
            elif user.age_us != cutoff_us - generation_us:
                raise ValueError("observed user age does not match last success time")
        if not set(last_success).issubset(observed_by_id):
            raise ValueError("last-success IDs must be known observed users")

        if not isinstance(self.removals, tuple) or not all(
            isinstance(item, IdentityRemoval) for item in self.removals
        ):
            raise ValueError("removals must contain only IdentityRemoval values")
        removal_ids = tuple(str(item.vehicle_id) for item in self.removals)
        if len(set(removal_ids)) != len(removal_ids):
            raise ValueError("removal vehicle IDs must be unique")
        if any(int(item.event_us) > cutoff_us for item in self.removals):
            raise ValueError("removal cannot follow the summary causal cutoff")
        if not isinstance(self.removed_vehicle_ids, tuple):
            raise ValueError("removed_vehicle_ids must be a tuple")
        if self.removed_vehicle_ids != removal_ids:
            raise ValueError("removed_vehicle_ids must match removals in canonical order")
        if set(removal_ids) & set(observed_by_id):
            raise ValueError("removed and observed vehicle IDs must be disjoint")


@dataclass(frozen=True, slots=True)
class DeliveredSummary:
    schema_version: str
    summary: MeasurementSummary
    received_at_vehicle_us: int

    def __post_init__(self) -> None:
        if self.schema_version != DELIVERED_SUMMARY_SCHEMA_VERSION:
            raise ValueError("unsupported delivered-summary schema version")
        if not isinstance(self.summary, MeasurementSummary):
            raise ValueError("delivered summary payload must be a MeasurementSummary")
        require_non_negative_int(
            self.received_at_vehicle_us, "received_at_vehicle_us"
        )
        if self.received_at_vehicle_us < int(self.summary.header.causal_cutoff_us):
            raise ValueError("a summary cannot be received before it is generated")


@dataclass(frozen=True, slots=True)
class LedgerSnapshot:
    schema_version: str
    packet_observations: tuple[ReceiverPacketObservation, ...]
    attempt_observations: tuple[ReceiverAttemptObservation, ...]
    identity_events: tuple[ReceiverIdentityEvent, ...]

    def __post_init__(self) -> None:
        if self.schema_version != LEDGER_SNAPSHOT_SCHEMA_VERSION:
            raise ValueError("unsupported ledger-snapshot schema version")
        groups = (
            (self.packet_observations, ReceiverPacketObservation, "packet_observations"),
            (self.attempt_observations, ReceiverAttemptObservation, "attempt_observations"),
            (self.identity_events, ReceiverIdentityEvent, "identity_events"),
        )
        for values, expected_type, field_name in groups:
            if not isinstance(values, tuple) or not all(
                isinstance(item, expected_type) for item in values
            ):
                raise ValueError(f"{field_name} must contain only {expected_type.__name__} values")
            if values != tuple(sorted(values, key=_observation_sort_key)):
                raise ValueError(f"{field_name} must be in canonical causal order")
        observations = (
            *self.packet_observations,
            *self.attempt_observations,
            *self.identity_events,
        )
        event_ids = tuple(str(item.event_id) for item in observations)
        if len(set(event_ids)) != len(event_ids):
            raise ValueError("ledger snapshot event IDs must be globally unique")


class ReceiverMeasurementLedger:
    def __init__(self) -> None:
        self._packets: dict[str, ReceiverPacketObservation] = {}
        self._attempts: dict[str, ReceiverAttemptObservation] = {}
        self._identity_events: dict[str, ReceiverIdentityEvent] = {}
        self._observations_by_id: dict[
            str,
            ReceiverPacketObservation
            | ReceiverAttemptObservation
            | ReceiverIdentityEvent,
        ] = {}

    def ingest(
        self,
        observation: ReceiverPacketObservation
        | ReceiverAttemptObservation
        | ReceiverIdentityEvent,
    ) -> None:
        if isinstance(observation, ReceiverPacketObservation):
            target = self._packets
        elif isinstance(observation, ReceiverAttemptObservation):
            target = self._attempts
        elif isinstance(observation, ReceiverIdentityEvent):
            target = self._identity_events
        else:
            raise ValueError("unsupported receiver observation type")
        event_id = str(observation.event_id)
        previous = self._observations_by_id.get(event_id)
        if previous is not None:
            if previous == observation:
                return
            raise ValueError("event ID collision across receiver ledger observation types")
        self._observations_by_id[event_id] = observation
        target[event_id] = observation

    def ingest_delivery(self, event: MeasurementDeliveryEvent) -> None:
        payload = event.packet or event.attempt or event.identity
        if payload is None:  # Guarded by the DTO; keeps this boundary fail-closed.
            raise ValueError("measurement delivery has no payload")
        self.ingest(payload)

    def snapshot(self) -> LedgerSnapshot:
        return LedgerSnapshot(
            schema_version=LEDGER_SNAPSHOT_SCHEMA_VERSION,
            packet_observations=tuple(
                sorted(self._packets.values(), key=_observation_sort_key)
            ),
            attempt_observations=tuple(
                sorted(self._attempts.values(), key=_observation_sort_key)
            ),
            identity_events=tuple(
                sorted(self._identity_events.values(), key=_observation_sort_key)
            ),
        )

    @classmethod
    def from_snapshot(cls, snapshot: LedgerSnapshot) -> "ReceiverMeasurementLedger":
        ledger = cls()
        for observation in (
            *snapshot.packet_observations,
            *snapshot.attempt_observations,
            *snapshot.identity_events,
        ):
            ledger.ingest(observation)
        return ledger

    def packet_prefix(self, cutoff_us: int) -> tuple[ReceiverPacketObservation, ...]:
        return tuple(
            sorted(
                (
                    item
                    for item in self._packets.values()
                    if int(item.observed_at_us) <= cutoff_us
                ),
                key=lambda item: (int(item.observed_at_us), str(item.event_id)),
            )
        )

    def observation_prefix(
        self, cutoff_us: int
    ) -> tuple[ReceiverPacketObservation | ReceiverAttemptObservation | ReceiverIdentityEvent, ...]:
        return tuple(
            sorted(
                (
                    *(
                        item
                        for item in self._packets.values()
                        if int(item.observed_at_us) <= cutoff_us
                    ),
                    *(
                        item
                        for item in self._attempts.values()
                        if int(item.observed_at_us) <= cutoff_us
                    ),
                    *(
                        item
                        for item in self._identity_events.values()
                        if int(item.observed_at_us) <= cutoff_us
                    ),
                ),
                key=lambda item: (int(item.observed_at_us), str(item.event_id)),
            )
        )

    def summarize(self, generated_at_us: int, window_start_us: int | None = None) -> MeasurementSummary:
        if generated_at_us % SUMMARY_PERIOD_US:
            raise ValueError("measurement summaries must be generated on the 50 ms lattice")
        effective_start = max(
            0,
            generated_at_us - AGGREGATION_WINDOW_US,
            window_start_us if window_start_us is not None else 0,
        )
        identity: dict[str, tuple[int | None, int]] = {}
        latest_removal: dict[str, IdentityRemoval] = {}
        for event in self.observation_prefix(generated_at_us):
            if isinstance(event, ReceiverIdentityEvent):
                vehicle_id = str(event.vehicle_id)
                if event.kind is ReceiverObservableKind.AUTHENTICATED_HANDOVER:
                    identity[vehicle_id] = (
                        None
                        if event.last_success_generation_us is None
                        else int(event.last_success_generation_us),
                        int(event.observed_at_us),
                    )
                    latest_removal.pop(vehicle_id, None)
                else:
                    identity.pop(vehicle_id, None)
                    latest_removal[vehicle_id] = IdentityRemoval(
                        schema_version=IDENTITY_REMOVAL_SCHEMA_VERSION,
                        vehicle_id=event.vehicle_id,
                        reason=event.removal_reason
                        or IdentityRemovalReason.AUTHENTICATED_DEPARTURE,
                        event_us=event.observed_at_us,
                    )
            elif isinstance(event, ReceiverPacketObservation):
                vehicle_id = str(event.vehicle_id)
                identity[vehicle_id] = (
                    int(event.packet_generation_us),
                    int(event.observed_at_us),
                )
                latest_removal.pop(vehicle_id, None)
        fresh = stale = unknown = 0
        last_success: list[tuple[str, int]] = []
        last_observed: list[tuple[str, int]] = []
        observed_users: list[ObservedUserState] = []
        for vehicle_id, (generation, observed_at) in identity.items():
            silence_us = generated_at_us - observed_at
            if silence_us < FRESH_TIMEOUT_US:
                state = IdentityState.FRESH
                fresh += 1
            elif silence_us < UNKNOWN_TIMEOUT_US:
                state = IdentityState.STALE_RETAINED
                stale += 1
            else:
                state = IdentityState.UNKNOWN_RETAINED
                unknown += 1
            if generation is not None:
                last_success.append((vehicle_id, generation))
            last_observed.append((vehicle_id, observed_at))
            observed_users.append(
                ObservedUserState(
                    schema_version=OBSERVED_USER_STATE_SCHEMA_VERSION,
                    vehicle_id=vehicle_id,
                    ledger_state=state,
                    identity_silence_us=silence_us,
                    age_us=None if generation is None else generated_at_us - generation,
                    age_missing_reason=(
                        MissingReasonCode.SOURCE_FIELD_ABSENT if generation is None else None
                    ),
                )
            )
        attempts = tuple(
            item
            for item in self._attempts.values()
            if effective_start < int(item.observed_at_us) <= generated_at_us
        )
        busy_slots = {int(item.busy_slot_us) for item in attempts}
        eligible_slots = max(0, (generated_at_us - effective_start) // SENSING_SLOT_US)
        delta_start = generated_at_us - SUMMARY_PERIOD_US
        removals = tuple(
            IdentityRemoval(
                schema_version=IDENTITY_REMOVAL_SCHEMA_VERSION,
                vehicle_id=event.vehicle_id,
                reason=event.removal_reason
                or IdentityRemovalReason.AUTHENTICATED_DEPARTURE,
                event_us=event.observed_at_us,
            )
            for event in sorted(
                self._identity_events.values(), key=_observation_sort_key
            )
            if event.kind is ReceiverObservableKind.AUTHENTICATED_DEPARTURE
            and delta_start < int(event.observed_at_us) <= generated_at_us
        )
        return MeasurementSummary(
            schema_version=MEASUREMENT_SUMMARY_SCHEMA_VERSION,
            header=MeasurementSummaryHeader(
                schema_version=MEASUREMENT_SUMMARY_HEADER_SCHEMA_VERSION,
                sequence=generated_at_us // SUMMARY_PERIOD_US,
                causal_cutoff_us=SimTimeUs(generated_at_us),
                window_start_us=SimTimeUs(effective_start),
            ),
            known_vehicle_count=len(identity),
            fresh_count=fresh,
            stale_count=stale,
            unknown_count=unknown,
            decoded_success_count=sum(item.decoded for item in attempts),
            decode_trial_count=len(attempts),
            busy_sensing_slot_count=len(busy_slots),
            eligible_sensing_slot_count=eligible_slots,
            last_success_by_vehicle=tuple(sorted(last_success)),
            last_observed_at_by_vehicle=tuple(sorted(last_observed)),
            removed_vehicle_ids=tuple(str(item.vehicle_id) for item in removals),
            observed_users=tuple(sorted(observed_users, key=lambda item: str(item.vehicle_id))),
            removals=removals,
        )


class ObservationAdapter:
    def build(self, summary: MeasurementSummary, received_at_vehicle_us: int) -> ObservableFrame:
        generated_at_us = int(summary.header.causal_cutoff_us)
        if received_at_vehicle_us < generated_at_us:
            raise ValueError("a summary cannot be received before it is generated")
        age = received_at_vehicle_us - generated_at_us
        if age > SUMMARY_MAX_AGE_US:
            return ObservableFrame(
                schema_version=OBSERVABLE_FRAME_SCHEMA_VERSION,
                source_sequence=summary.header.sequence,
                causal_cutoff_us=summary.header.causal_cutoff_us,
                summary_payload_hash=_summary_hash(summary),
                counters=(),
                missing_reasons=(MissingReasonCode.SUMMARY_STALE,),
                observed_user_ages=(),
                observed_users=(),
                removals=(),
            )
        reasons: list[MissingReasonCode] = []
        if summary.decode_trial_count == 0:
            reasons.append(MissingReasonCode.ZERO_DECODE_TRIAL)
        if summary.eligible_sensing_slot_count == 0:
            reasons.append(MissingReasonCode.ZERO_SENSING_DENOMINATOR)
        delivered_users = tuple(
            ObservedUserState(
                schema_version=item.schema_version,
                vehicle_id=item.vehicle_id,
                ledger_state=_state_at_delivery(
                    item.identity_silence_us + received_at_vehicle_us - generated_at_us
                ),
                identity_silence_us=(
                    item.identity_silence_us + received_at_vehicle_us - generated_at_us
                ),
                age_us=(
                    None
                    if item.age_us is None
                    else item.age_us + received_at_vehicle_us - generated_at_us
                ),
                age_missing_reason=item.age_missing_reason,
            )
            for item in summary.observed_users
        )
        state_counts = {
            state: sum(item.ledger_state is state for item in delivered_users)
            for state in IdentityState
        }
        counters = (
            _counter(ObservableCounterKind.FRESH_OBSERVED, state_counts[IdentityState.FRESH]),
            _counter(
                ObservableCounterKind.STALE_RETAINED,
                state_counts[IdentityState.STALE_RETAINED],
            ),
            _counter(
                ObservableCounterKind.UNKNOWN_RETAINED,
                state_counts[IdentityState.UNKNOWN_RETAINED],
            ),
            _counter(ObservableCounterKind.DECODED_SUCCESS, summary.decoded_success_count),
            _counter(ObservableCounterKind.OBSERVABLE_DECODE_TRIAL, summary.decode_trial_count),
            _counter(ObservableCounterKind.BUSY_SENSING_UNIT, summary.busy_sensing_slot_count),
            _counter(
                ObservableCounterKind.TOTAL_SENSING_UNIT,
                summary.eligible_sensing_slot_count,
            ),
        )
        observed_ages = tuple(
            ObservedUserAge(
                schema_version=OBSERVED_USER_AGE_SCHEMA_VERSION,
                vehicle_id=vehicle_id,
                age_us=received_at_vehicle_us - generation_us,
            )
            for vehicle_id, generation_us in summary.last_success_by_vehicle
        )
        return ObservableFrame(
            schema_version=OBSERVABLE_FRAME_SCHEMA_VERSION,
            source_sequence=summary.header.sequence,
            causal_cutoff_us=summary.header.causal_cutoff_us,
            summary_payload_hash=_summary_hash(summary),
            counters=counters,
            missing_reasons=tuple(reasons),
            observed_user_ages=observed_ages,
            observed_users=delivered_users,
            removals=summary.removals,
        )


class SummaryDeliveryReceiver:
    """Accept a monotonic summary stream and reject replay or reordering."""

    def __init__(self, adapter: ObservationAdapter | None = None) -> None:
        self._adapter = adapter or ObservationAdapter()
        self._last_sequence: int | None = None
        self._last_generated_at_us: int | None = None
        self._last_received_at_us: int | None = None

    def receive(self, delivery: DeliveredSummary) -> ObservableFrame:
        if not isinstance(delivery, DeliveredSummary):
            raise ValueError("summary receiver accepts only DeliveredSummary values")
        sequence = delivery.summary.header.sequence
        generated_at_us = int(delivery.summary.header.causal_cutoff_us)
        received_at_us = delivery.received_at_vehicle_us
        if sequence != generated_at_us // SUMMARY_PERIOD_US or (
            generated_at_us % SUMMARY_PERIOD_US
        ):
            raise ValueError("summary sequence does not match the frozen generation lattice")
        if self._last_sequence is not None:
            if sequence == self._last_sequence:
                raise ValueError("duplicate summary sequence")
            if (
                sequence < self._last_sequence
                or generated_at_us <= self._last_generated_at_us
                or received_at_us <= self._last_received_at_us
            ):
                raise ValueError("out-of-order summary delivery")
        frame = self._adapter.build(delivery.summary, received_at_us)
        self._last_sequence = sequence
        self._last_generated_at_us = generated_at_us
        self._last_received_at_us = received_at_us
        return frame


def deliver_summary(summary: MeasurementSummary) -> DeliveredSummary:
    return DeliveredSummary(
        schema_version=DELIVERED_SUMMARY_SCHEMA_VERSION,
        summary=summary,
        received_at_vehicle_us=int(summary.header.causal_cutoff_us) + MEASUREMENT_DELAY_US,
    )


def transport_summary(
    summary: MeasurementSummary, *, dropout_anchor_us: int | None = None
) -> DeliveredSummary | None:
    """Apply the frozen assistance-only dropout without mutating RSU state."""

    if dropout_anchor_us is not None:
        require_non_negative_int(dropout_anchor_us, "dropout_anchor_us")
        generated_at_us = int(summary.header.causal_cutoff_us)
        if (
            dropout_anchor_us
            <= generated_at_us
            < dropout_anchor_us + TELEMETRY_DROPOUT_DURATION_US
        ):
            return None
    return deliver_summary(summary)


def _counter(kind: ObservableCounterKind, value: int) -> ObservableCounter:
    return ObservableCounter(schema_version=OBSERVABLE_COUNTER_SCHEMA_VERSION, kind=kind, value=value)


def _validate_vehicle_time_pairs(
    values: tuple[tuple[str, int], ...], field_name: str, cutoff_us: int
) -> dict[str, int]:
    if not isinstance(values, tuple):
        raise ValueError(f"{field_name} must be a tuple")
    parsed: dict[str, int] = {}
    for item in values:
        if not isinstance(item, tuple) or len(item) != 2:
            raise ValueError(f"{field_name} entries must be vehicle/time pairs")
        vehicle_id, time_us = item
        require_identifier(vehicle_id, f"{field_name}.vehicle_id")
        require_non_negative_int(time_us, f"{field_name}.time_us")
        if time_us > cutoff_us:
            raise ValueError(f"{field_name} cannot contain a future timestamp")
        if vehicle_id in parsed:
            raise ValueError(f"{field_name} vehicle IDs must be unique")
        parsed[vehicle_id] = time_us
    if values != tuple(sorted(values)):
        raise ValueError(f"{field_name} must be in canonical vehicle order")
    return parsed


def _state_at_delivery(silence_us: int) -> IdentityState:
    if silence_us < FRESH_TIMEOUT_US:
        return IdentityState.FRESH
    if silence_us < UNKNOWN_TIMEOUT_US:
        return IdentityState.STALE_RETAINED
    return IdentityState.UNKNOWN_RETAINED


def _observation_sort_key(
    item: ReceiverPacketObservation | ReceiverAttemptObservation | ReceiverIdentityEvent,
) -> tuple[int, int, str]:
    if isinstance(item, ReceiverIdentityEvent):
        order = (
            10
            if item.kind is ReceiverObservableKind.AUTHENTICATED_HANDOVER
            else 40
        )
    elif isinstance(item, ReceiverAttemptObservation):
        order = 20
    else:
        order = 30
    return (int(item.observed_at_us), order, str(item.event_id))


def _summary_hash(summary: MeasurementSummary) -> str:
    return canonical_sha256(
        summary, expected_schema_version=MEASUREMENT_SUMMARY_SCHEMA_VERSION
    )
