"""C05 measurement and observability boundary."""
