"""Causal C07 state estimator built only from public controller records."""

from exp09.contracts.actions import ControlOpportunity
from exp09.contracts.observable import (
    MissingReasonCode,
    ObservableCounterKind,
    ObservableFrame,
)
from exp09.model.interfaces import (
    ESTIMATED_USER_AGE_SCHEMA_VERSION,
    ControllerStateEstimate,
    EstimatedUserAge,
    PPM_DENOMINATOR,
)


class ControllerStateEstimator:
    """Convert one immutable public frame into one immutable model state."""

    def estimate(
        self,
        frame: ObservableFrame,
        opportunity: ControlOpportunity,
    ) -> ControllerStateEstimate:
        if not isinstance(frame, ObservableFrame):
            raise ValueError("frame must be an ObservableFrame")
        if not isinstance(opportunity, ControlOpportunity):
            raise ValueError("opportunity must be a ControlOpportunity")
        if int(frame.causal_cutoff_us) > int(opportunity.time_us):
            raise ValueError("observation cutoff cannot follow the control opportunity")

        counters = {counter.kind: counter.value for counter in frame.counters}
        busy = counters.get(ObservableCounterKind.BUSY_SENSING_UNIT, 0)
        total = counters.get(ObservableCounterKind.TOTAL_SENSING_UNIT, 0)
        decoded = counters.get(ObservableCounterKind.DECODED_SUCCESS, 0)
        trials = counters.get(ObservableCounterKind.OBSERVABLE_DECODE_TRIAL, 0)
        summary_available = not bool(
            {MissingReasonCode.SUMMARY_STALE, MissingReasonCode.SUMMARY_UNAVAILABLE}
            & set(frame.missing_reasons)
        )
        user_ages = tuple(
            EstimatedUserAge(
                schema_version=ESTIMATED_USER_AGE_SCHEMA_VERSION,
                vehicle_id=str(item.vehicle_id),
                age_us=item.age_us,
                ledger_state=item.ledger_state.value,
            )
            for item in sorted(frame.observed_users, key=lambda item: str(item.vehicle_id))
        )
        return ControllerStateEstimate.create(
            source_observation_hash=frame.summary_payload_hash,
            causal_cutoff_us=frame.causal_cutoff_us,
            summary_available=summary_available,
            controlled_vehicle_id=str(opportunity.vehicle_id),
            current_rri_us=opportunity.current_rri_us,
            fresh_observed_count=counters.get(ObservableCounterKind.FRESH_OBSERVED, 0),
            stale_retained_count=counters.get(ObservableCounterKind.STALE_RETAINED, 0),
            unknown_retained_count=counters.get(ObservableCounterKind.UNKNOWN_RETAINED, 0),
            busy_sensing_unit_count=busy,
            total_sensing_unit_count=total,
            decoded_success_count=decoded,
            observable_decode_trial_count=trials,
            busy_fraction_ppm=_ratio_ppm(busy, total),
            decode_success_ppm=_ratio_ppm(decoded, trials),
            user_ages=user_ages,
        )


def _ratio_ppm(numerator: int, denominator: int) -> int | None:
    if denominator == 0:
        return None
    return numerator * PPM_DENOMINATOR // denominator
