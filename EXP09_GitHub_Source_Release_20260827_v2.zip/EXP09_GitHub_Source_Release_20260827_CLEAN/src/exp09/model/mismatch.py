"""C07 mismatch profile DTOs without concrete axis-level choices."""

from dataclasses import dataclass
from enum import Enum

from exp09.contracts.ids import require_identifier, require_sha256

MISMATCH_LEVEL_SCHEMA_VERSION = "exp09-mismatch-level-v1"
MISMATCH_PROFILE_SCHEMA_VERSION = "exp09-mismatch-profile-v1"

CONTROLLER_MODEL_INJECTION_POINT = "ControllerModel_only"


class MismatchDirection(str, Enum):
    NOMINAL = "NOMINAL"
    INCREASE = "INCREASE"
    DECREASE = "DECREASE"
    CUSTOM = "CUSTOM"


@dataclass(frozen=True, slots=True)
class MismatchLevel:
    schema_version: str
    axis_id: str
    level_id: str
    parameterization_hash: str
    direction: MismatchDirection
    injection_point: str

    def __post_init__(self) -> None:
        if self.schema_version != MISMATCH_LEVEL_SCHEMA_VERSION:
            raise ValueError("unsupported mismatch-level schema version")
        require_identifier(self.axis_id, "axis_id")
        require_identifier(self.level_id, "level_id")
        require_sha256(self.parameterization_hash, "parameterization_hash")
        if not isinstance(self.direction, MismatchDirection):
            raise ValueError("direction must be a MismatchDirection")
        if self.injection_point != CONTROLLER_MODEL_INJECTION_POINT:
            raise ValueError("mismatch levels may only target ControllerModel")


@dataclass(frozen=True, slots=True)
class MismatchProfile:
    schema_version: str
    profile_id: str
    axis_level_grid_hash: str
    method_blind_freeze_record_hash: str
    levels: tuple[MismatchLevel, ...]
    supporting_family_run_allowed: bool

    def __post_init__(self) -> None:
        if self.schema_version != MISMATCH_PROFILE_SCHEMA_VERSION:
            raise ValueError("unsupported mismatch-profile schema version")
        require_identifier(self.profile_id, "profile_id")
        require_sha256(self.axis_level_grid_hash, "axis_level_grid_hash")
        require_sha256(self.method_blind_freeze_record_hash, "method_blind_freeze_record_hash")
        if not isinstance(self.levels, tuple):
            raise ValueError("levels must be a tuple")
        if not all(isinstance(level, MismatchLevel) for level in self.levels):
            raise ValueError("levels must contain MismatchLevel values")
        keys = tuple((level.axis_id, level.level_id) for level in self.levels)
        if len(set(keys)) != len(keys):
            raise ValueError("mismatch profile levels must be unique by axis and level")
        if not isinstance(self.supporting_family_run_allowed, bool):
            raise ValueError("supporting_family_run_allowed must be boolean")
        if self.supporting_family_run_allowed and not self.levels:
            raise ValueError("supporting family runs require at least one mismatch level")
