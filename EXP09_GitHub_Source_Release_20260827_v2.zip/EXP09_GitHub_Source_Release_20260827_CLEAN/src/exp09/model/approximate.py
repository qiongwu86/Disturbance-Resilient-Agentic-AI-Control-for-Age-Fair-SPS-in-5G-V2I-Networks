"""Independent integer C07 approximation of periodic SPS age and collision risk."""

from dataclasses import dataclass

from exp09.contracts.actions import ActionKind, ControlAction, control_action_fingerprint
from exp09.contracts.determinism import stable_digest_hex
from exp09.contracts.ids import require_sha256
from exp09.contracts.observable import ObservableFrame
from exp09.contracts.time import DurationUs, require_positive_int
from exp09.model.interfaces import (
    PPM_DENOMINATOR,
    PREDICTED_TRACE_STEP_SCHEMA_VERSION,
    ROLLOUT_SET_SCHEMA_VERSION,
    ControllerStateEstimate,
    ModelTransitionBudget,
    PredictedTraceStep,
    PredictiveModel,
    RolloutEvaluation,
    RolloutSet,
    ScenarioBatch,
)
from exp09.model.scenarios import (
    DEFAULT_LOAD_SCALES_PPM,
    ForecastBatchConfig,
    ForecastBatchFactory,
)

MODEL_CONFIG_SCHEMA_VERSION = "exp09-approximate-sps-model-config-v2"
MODEL_CONFIG_HASH_DOMAIN = "exp09-approximate-sps-model-config-v2"
TRANSITION_STEP_US = 1_000
DEFAULT_PACKET_PERIOD_US = 100_000
DEFAULT_LOGICAL_SUBCHANNEL_COUNT = 2


@dataclass(frozen=True, slots=True)
class ApproximateSPSModelConfig:
    schema_version: str
    config_hash: str
    transition_step_us: int
    packet_period_us: int
    logical_subchannel_count: int
    load_scale_ppm: int
    forecast_load_scales_ppm: tuple[int, ...]

    @classmethod
    def create(
        cls,
        *,
        transition_step_us: int = TRANSITION_STEP_US,
        packet_period_us: int = DEFAULT_PACKET_PERIOD_US,
        logical_subchannel_count: int = DEFAULT_LOGICAL_SUBCHANNEL_COUNT,
        load_scale_ppm: int = PPM_DENOMINATOR,
        forecast_load_scales_ppm: tuple[int, ...] = DEFAULT_LOAD_SCALES_PPM,
    ) -> "ApproximateSPSModelConfig":
        return cls(
            schema_version=MODEL_CONFIG_SCHEMA_VERSION,
            config_hash=stable_digest_hex(
                MODEL_CONFIG_HASH_DOMAIN,
                transition_step_us,
                packet_period_us,
                logical_subchannel_count,
                load_scale_ppm,
                len(forecast_load_scales_ppm),
                *forecast_load_scales_ppm,
            ),
            transition_step_us=transition_step_us,
            packet_period_us=packet_period_us,
            logical_subchannel_count=logical_subchannel_count,
            load_scale_ppm=load_scale_ppm,
            forecast_load_scales_ppm=forecast_load_scales_ppm,
        )

    def __post_init__(self) -> None:
        if self.schema_version != MODEL_CONFIG_SCHEMA_VERSION:
            raise ValueError("unsupported approximate-model config schema version")
        require_sha256(self.config_hash, "config_hash")
        require_positive_int(self.transition_step_us, "transition_step_us")
        require_positive_int(self.packet_period_us, "packet_period_us")
        require_positive_int(self.logical_subchannel_count, "logical_subchannel_count")
        require_positive_int(self.load_scale_ppm, "load_scale_ppm")
        if not isinstance(self.forecast_load_scales_ppm, tuple) or not self.forecast_load_scales_ppm:
            raise ValueError("forecast_load_scales_ppm must be a non-empty tuple")
        if len(set(self.forecast_load_scales_ppm)) != len(self.forecast_load_scales_ppm):
            raise ValueError("forecast_load_scales_ppm must be unique")
        for load_scale_ppm in self.forecast_load_scales_ppm:
            require_positive_int(load_scale_ppm, "forecast_load_scale_ppm")
            if load_scale_ppm > 2 * PPM_DENOMINATOR:
                raise ValueError("forecast load scale is outside the supported range")
        expected_hash = stable_digest_hex(
            MODEL_CONFIG_HASH_DOMAIN,
            self.transition_step_us,
            self.packet_period_us,
            self.logical_subchannel_count,
            self.load_scale_ppm,
            len(self.forecast_load_scales_ppm),
            *self.forecast_load_scales_ppm,
        )
        if self.config_hash != expected_hash:
            raise ValueError("config_hash does not bind approximate-model parameters")


class ApproximateSPSModel(PredictiveModel):
    """Roll out public state with a model implementation independent of the plant."""

    def __init__(self, config: ApproximateSPSModelConfig) -> None:
        if not isinstance(config, ApproximateSPSModelConfig):
            raise ValueError("config must be an ApproximateSPSModelConfig")
        self._config = config

    @property
    def config(self) -> ApproximateSPSModelConfig:
        return self._config

    def rollout(
        self,
        frame: ObservableFrame,
        state: ControllerStateEstimate,
        action: ControlAction,
        scenarios: ScenarioBatch,
        horizon_us: DurationUs,
        budget: ModelTransitionBudget,
    ) -> RolloutSet:
        self._validate_inputs(frame, state, action, scenarios, horizon_us, budget)
        transition_count = int(horizon_us) // self._config.transition_step_us
        required = transition_count * len(scenarios.members)
        budget_after = budget.consume(required)
        action_hash = control_action_fingerprint(action)
        selected_rri_us = (
            int(action.target_rri_us)
            if action.kind is ActionKind.RESELECT
            else int(state.current_rri_us)
        )
        evaluations = tuple(
            self._rollout_member(
                state=state,
                action_hash=action_hash,
                selected_rri_us=selected_rri_us,
                member=member,
                horizon_us=int(horizon_us),
                transition_count=transition_count,
            )
            for member in scenarios.members
        )
        return RolloutSet(
            schema_version=ROLLOUT_SET_SCHEMA_VERSION,
            budget_before=budget,
            budget_after=budget_after,
            evaluations=evaluations,
        )

    def _validate_inputs(
        self,
        frame: ObservableFrame,
        state: ControllerStateEstimate,
        action: ControlAction,
        scenarios: ScenarioBatch,
        horizon_us: DurationUs,
        budget: ModelTransitionBudget,
    ) -> None:
        if not isinstance(frame, ObservableFrame):
            raise ValueError("frame must be an ObservableFrame")
        if not isinstance(state, ControllerStateEstimate):
            raise ValueError("state must be a ControllerStateEstimate")
        if not isinstance(action, ControlAction):
            raise ValueError("action must be a ControlAction")
        if not isinstance(scenarios, ScenarioBatch):
            raise ValueError("scenarios must be a ScenarioBatch")
        if not isinstance(budget, ModelTransitionBudget):
            raise ValueError("budget must be a ModelTransitionBudget")
        require_positive_int(horizon_us, "horizon_us")
        if int(horizon_us) % self._config.transition_step_us:
            raise ValueError("horizon_us must align to the physical model step")
        if frame.summary_payload_hash != state.source_observation_hash:
            raise ValueError("state source does not match the observable frame")
        if frame.causal_cutoff_us != state.causal_cutoff_us:
            raise ValueError("state cutoff does not match the observable frame")
        if scenarios.causal_cutoff_us != state.causal_cutoff_us:
            raise ValueError("ScenarioBatch cutoff does not match the state")
        if scenarios.model_config_hash != self._config.config_hash:
            raise ValueError("ScenarioBatch model config hash mismatch")
        mismatch_hashes = {member.mismatch_profile_hash for member in scenarios.members}
        if len(mismatch_hashes) != 1:
            raise ValueError("ScenarioBatch mismatch profile must be common across members")
        expected_scenarios = ForecastBatchFactory(
            ForecastBatchConfig.create(
                model_config_hash=self._config.config_hash,
                load_scales_ppm=self._config.forecast_load_scales_ppm,
            )
        ).build(
            state,
            mismatch_profile_hash=next(iter(mismatch_hashes)),
        )
        if scenarios != expected_scenarios:
            raise ValueError("ScenarioBatch does not match the deterministic frozen forecast")

    def _rollout_member(
        self,
        *,
        state: ControllerStateEstimate,
        action_hash: str,
        selected_rri_us: int,
        member,
        horizon_us: int,
        transition_count: int,
    ) -> RolloutEvaluation:
        known_ages = tuple(item.age_us for item in state.user_ages if item.age_us is not None)
        controlled_age = next(
            (
                int(item.age_us)
                for item in state.user_ages
                if item.vehicle_id == state.controlled_vehicle_id and item.age_us is not None
            ),
            max(known_ages, default=self._config.packet_period_us),
        )
        background_ages = tuple(
            int(item.age_us)
            for item in state.user_ages
            if item.vehicle_id != state.controlled_vehicle_id and item.age_us is not None
        )
        total_observed = max(
            1,
            state.fresh_observed_count
            + state.stale_retained_count
            + state.unknown_retained_count,
            len(state.user_ages),
        )
        nominal_load_ppm = (
            total_observed
            * self._config.load_scale_ppm
            // max(1, self._config.logical_subchannel_count * 10)
        )
        load_ppm = _clamp_ppm(
            nominal_load_ppm * member.load_scale_ppm // PPM_DENOMINATOR
        )
        observed_busy_ppm = state.busy_fraction_ppm or 0
        controlled_attempt_pressure_ppm = min(
            PPM_DENOMINATOR,
            self._config.packet_period_us * PPM_DENOMINATOR // selected_rri_us,
        )
        collision_risk_ppm = _clamp_ppm(
            max(load_ppm, observed_busy_ppm) // 2
            + controlled_attempt_pressure_ppm // 20
        )
        success_ppm = _clamp_ppm(PPM_DENOMINATOR - collision_risk_ppm)
        next_attempt_us = _phase_offset(selected_rri_us, member.grant_phase_ppm)
        background_phase_us = _phase_offset(
            self._config.packet_period_us,
            member.background_phase_ppm,
        )

        trace: list[PredictedTraceStep] = []
        sum_mean = 0
        sum_worst = 0
        collision_event_sum = 0
        first_attempt_mean: int | None = None
        first_attempt_worst: int | None = None
        for ordinal in range(1, transition_count + 1):
            elapsed_us = ordinal * self._config.transition_step_us
            controlled_age += self._config.transition_step_us
            attempted = elapsed_us == next_attempt_us
            step_success_ppm = 0
            if attempted:
                step_success_ppm = success_ppm
                controlled_age = controlled_age * collision_risk_ppm // PPM_DENOMINATOR
                collision_event_sum += collision_risk_ppm
                next_attempt_us += selected_rri_us
            advanced_background = tuple(age + elapsed_us for age in background_ages)
            known = (controlled_age, *advanced_background)
            mean_age = sum(known) // len(known)
            worst_age = max(known)
            if elapsed_us >= background_phase_us and background_ages:
                mean_age = max(0, mean_age - self._config.transition_step_us // len(known))
            step = PredictedTraceStep(
                schema_version=PREDICTED_TRACE_STEP_SCHEMA_VERSION,
                elapsed_us=DurationUs(elapsed_us),
                controlled_age_us=controlled_age,
                mean_age_us=mean_age,
                worst_age_us=worst_age,
                collision_risk_ppm=collision_risk_ppm,
                attempted=attempted,
                expected_success_ppm=step_success_ppm,
            )
            trace.append(step)
            sum_mean += mean_age
            sum_worst += worst_age
            if attempted and first_attempt_mean is None:
                first_attempt_mean = mean_age
                first_attempt_worst = worst_age

        trace_tuple = tuple(trace)
        first_attempt_mean = first_attempt_mean or trace_tuple[-1].mean_age_us
        first_attempt_worst = first_attempt_worst or trace_tuple[-1].worst_age_us
        return RolloutEvaluation.create(
            action_hash=action_hash,
            scenario_member_id=member.member_id,
            scenario_artifact_hash=member.scenario_artifact_hash,
            source_state_hash=state.state_hash,
            selected_rri_us=DurationUs(selected_rri_us),
            horizon_us=DurationUs(horizon_us),
            transition_count=transition_count,
            time_average_mean_age_us=sum_mean // transition_count,
            time_average_worst_age_us=sum_worst // transition_count,
            terminal_mean_age_us=trace_tuple[-1].mean_age_us,
            terminal_worst_age_us=trace_tuple[-1].worst_age_us,
            first_attempt_mean_age_us=first_attempt_mean,
            first_attempt_worst_age_us=first_attempt_worst,
            predicted_collision_risk_ppm=collision_risk_ppm,
            expected_collision_events_ppm=collision_event_sum,
            trace=trace_tuple,
        )


def _phase_offset(period_us: int, phase_ppm: int) -> int:
    offset = max(TRANSITION_STEP_US, period_us * phase_ppm // PPM_DENOMINATOR)
    return ((offset + TRANSITION_STEP_US - 1) // TRANSITION_STEP_US) * TRANSITION_STEP_US


def _clamp_ppm(value: int) -> int:
    return min(PPM_DENOMINATOR, max(0, value))
