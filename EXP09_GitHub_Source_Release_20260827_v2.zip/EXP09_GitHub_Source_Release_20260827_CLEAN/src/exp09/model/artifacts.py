"""C07 model artifact metadata contracts without training outputs."""

from dataclasses import dataclass
from enum import Enum

from exp09.contracts.ids import ModelArtifactId, require_identifier, require_sha256

MODEL_ARTIFACT_METADATA_SCHEMA_VERSION = "exp09-model-artifact-metadata-v1"


class ModelArtifactStatus(str, Enum):
    PLANNED = "PLANNED"
    GENERATED_NOT_QUALIFIED = "GENERATED_NOT_QUALIFIED"
    QUALIFIED = "QUALIFIED"


@dataclass(frozen=True, slots=True)
class ModelArtifactMetadata:
    schema_version: str
    artifact_id: ModelArtifactId
    model_kind: str
    config_hash: str
    interface_hash: str
    training_source: str
    status: ModelArtifactStatus
    evidence_hashes: tuple[str, ...]

    def __post_init__(self) -> None:
        if self.schema_version != MODEL_ARTIFACT_METADATA_SCHEMA_VERSION:
            raise ValueError("unsupported model-artifact-metadata schema version")
        require_identifier(self.artifact_id, "artifact_id")
        require_identifier(self.model_kind, "model_kind")
        require_sha256(self.config_hash, "config_hash")
        require_sha256(self.interface_hash, "interface_hash")
        require_identifier(self.training_source, "training_source")
        if not isinstance(self.status, ModelArtifactStatus):
            raise ValueError("status must be a ModelArtifactStatus")
        if not isinstance(self.evidence_hashes, tuple):
            raise ValueError("evidence_hashes must be a tuple")
        for digest in self.evidence_hashes:
            require_sha256(digest, "evidence_hash")
        if self.status is ModelArtifactStatus.QUALIFIED and not self.evidence_hashes:
            raise ValueError("qualified model artifacts require evidence hashes")

