"""Deterministic method-blind forecast batch construction for C07."""

from dataclasses import dataclass

from exp09.contracts.determinism import stable_digest_hex
from exp09.contracts.ids import require_sha256
from exp09.model.interfaces import (
    PPM_DENOMINATOR,
    SCENARIO_BATCH_SCHEMA_VERSION,
    ControllerStateEstimate,
    ScenarioBatch,
    ScenarioMember,
)

FORECAST_BATCH_CONFIG_SCHEMA_VERSION = "exp09-forecast-batch-config-v2"
FORECAST_MEMBER_DOMAIN = "exp09-c07-forecast-member-v1"
FORECAST_BATCH_DOMAIN = "exp09-c07-forecast-batch-v1"
DEFAULT_LOAD_SCALES_PPM = (800_000, 1_000_000, 1_200_000)


def forecast_batch_config_hash(
    model_config_hash: str,
    load_scales_ppm: tuple[int, ...],
) -> str:
    return stable_digest_hex(
        FORECAST_BATCH_CONFIG_SCHEMA_VERSION,
        model_config_hash,
        len(load_scales_ppm),
        *load_scales_ppm,
    )


@dataclass(frozen=True, slots=True)
class ForecastBatchConfig:
    schema_version: str
    config_hash: str
    model_config_hash: str
    load_scales_ppm: tuple[int, ...]

    @classmethod
    def create(
        cls,
        *,
        model_config_hash: str,
        load_scales_ppm: tuple[int, ...] = DEFAULT_LOAD_SCALES_PPM,
    ) -> "ForecastBatchConfig":
        return cls(
            schema_version=FORECAST_BATCH_CONFIG_SCHEMA_VERSION,
            config_hash=forecast_batch_config_hash(model_config_hash, load_scales_ppm),
            model_config_hash=model_config_hash,
            load_scales_ppm=load_scales_ppm,
        )

    def __post_init__(self) -> None:
        if self.schema_version != FORECAST_BATCH_CONFIG_SCHEMA_VERSION:
            raise ValueError("unsupported forecast-batch config schema version")
        require_sha256(self.config_hash, "config_hash")
        require_sha256(self.model_config_hash, "model_config_hash")
        if not isinstance(self.load_scales_ppm, tuple) or not self.load_scales_ppm:
            raise ValueError("load_scales_ppm must be a non-empty tuple")
        if len(set(self.load_scales_ppm)) != len(self.load_scales_ppm):
            raise ValueError("load_scales_ppm must be unique")
        for load_scale_ppm in self.load_scales_ppm:
            if (
                isinstance(load_scale_ppm, bool)
                or not isinstance(load_scale_ppm, int)
                or load_scale_ppm <= 0
                or load_scale_ppm > 2 * PPM_DENOMINATOR
            ):
                raise ValueError("load_scales_ppm contains an unsupported scale")
        expected_hash = forecast_batch_config_hash(
            self.model_config_hash,
            self.load_scales_ppm,
        )
        if self.config_hash != expected_hash:
            raise ValueError("config_hash does not bind forecast-batch parameters")


class ForecastBatchFactory:
    def __init__(self, config: ForecastBatchConfig) -> None:
        if not isinstance(config, ForecastBatchConfig):
            raise ValueError("config must be a ForecastBatchConfig")
        self._config = config

    def build(
        self,
        state: ControllerStateEstimate,
        *,
        mismatch_profile_hash: str | None = None,
    ) -> ScenarioBatch:
        if not isinstance(state, ControllerStateEstimate):
            raise ValueError("state must be a ControllerStateEstimate")
        if mismatch_profile_hash is not None:
            require_sha256(mismatch_profile_hash, "mismatch_profile_hash")
        denominator = len(self._config.load_scales_ppm)
        members = tuple(
            ScenarioMember.create(
                member_id=f"forecast-{ordinal}",
                mismatch_profile_hash=mismatch_profile_hash,
                load_scale_ppm=load_scale_ppm,
                grant_phase_ppm=_phase_ppm(state.state_hash, ordinal, "grant"),
                background_phase_ppm=_phase_ppm(state.state_hash, ordinal, "background"),
                weight_numerator=1,
                weight_denominator=denominator,
            )
            for ordinal, load_scale_ppm in enumerate(self._config.load_scales_ppm)
        )
        return ScenarioBatch(
            schema_version=SCENARIO_BATCH_SCHEMA_VERSION,
            batch_id=stable_digest_hex(
                FORECAST_BATCH_DOMAIN,
                self._config.config_hash,
                state.state_hash,
                mismatch_profile_hash,
            )[:32],
            causal_cutoff_us=state.causal_cutoff_us,
            model_config_hash=self._config.model_config_hash,
            forecast_config_hash=self._config.config_hash,
            members=members,
        )


def _phase_ppm(state_hash: str, ordinal: int, kind: str) -> int:
    digest = stable_digest_hex(FORECAST_MEMBER_DOMAIN, state_hash, ordinal, kind)
    return int(digest[:16], 16) % 1_000_000
