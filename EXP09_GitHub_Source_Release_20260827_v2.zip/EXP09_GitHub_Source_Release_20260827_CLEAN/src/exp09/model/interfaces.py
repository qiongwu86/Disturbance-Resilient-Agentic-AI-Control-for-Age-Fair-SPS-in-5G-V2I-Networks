"""C07 causal predictive-model DTOs and protocols without plant imports."""

from dataclasses import dataclass, replace
from typing import Protocol

from exp09.contracts.actions import ControlAction
from exp09.contracts.determinism import stable_digest_hex
from exp09.contracts.ids import require_identifier, require_sha256
from exp09.contracts.observable import ObservableFrame
from exp09.contracts.time import DurationUs, SimTimeUs, require_non_negative_int, require_positive_int

CONTROLLER_STATE_ESTIMATE_SCHEMA_VERSION = "exp09-controller-state-estimate-v2"
ESTIMATED_USER_AGE_SCHEMA_VERSION = "exp09-estimated-user-age-v1"
SCENARIO_MEMBER_SCHEMA_VERSION = "exp09-scenario-member-v2"
SCENARIO_BATCH_SCHEMA_VERSION = "exp09-scenario-batch-v3"
MODEL_TRANSITION_BUDGET_SCHEMA_VERSION = "exp09-model-transition-budget-v1"
PREDICTED_TRACE_STEP_SCHEMA_VERSION = "exp09-predicted-trace-step-v1"
ROLLOUT_EVALUATION_SCHEMA_VERSION = "exp09-rollout-evaluation-v2"
ROLLOUT_SET_SCHEMA_VERSION = "exp09-rollout-set-v1"

STATE_HASH_DOMAIN = "exp09-controller-state-estimate-v2"
SCENARIO_MEMBER_HASH_DOMAIN = "exp09-scenario-member-v2"
ROLLOUT_METRIC_HASH_DOMAIN = "exp09-rollout-metrics-v2"
PPM_DENOMINATOR = 1_000_000


_CONTROLLER_HIDDEN_TOKENS = (
    "scenario_id",
    "family_id",
    "arm",
    "shock_label",
    "future_tape",
    "true_active_set",
    "plant_truth",
    "evaluation_truth",
    "method_identity",
    "test_ranking",
)


def _reject_hidden_token(value: str, field_name: str) -> None:
    lowered = value.lower()
    if any(token in lowered for token in _CONTROLLER_HIDDEN_TOKENS):
        raise ValueError(f"{field_name} contains controller-hidden protocol content")


def _require_ppm(value: int, field_name: str) -> None:
    require_non_negative_int(value, field_name)
    if value > PPM_DENOMINATOR:
        raise ValueError(f"{field_name} must not exceed {PPM_DENOMINATOR}")


@dataclass(frozen=True, slots=True)
class EstimatedUserAge:
    schema_version: str
    vehicle_id: str
    age_us: int | None
    ledger_state: str

    def __post_init__(self) -> None:
        if self.schema_version != ESTIMATED_USER_AGE_SCHEMA_VERSION:
            raise ValueError("unsupported estimated-user-age schema version")
        require_identifier(self.vehicle_id, "vehicle_id")
        if self.age_us is not None:
            require_non_negative_int(self.age_us, "age_us")
        if self.ledger_state not in {"FRESH", "STALE_RETAINED", "UNKNOWN_RETAINED"}:
            raise ValueError("ledger_state is not controller-observable")


@dataclass(frozen=True, slots=True)
class ControllerStateEstimate:
    schema_version: str
    state_hash: str
    source_observation_hash: str
    causal_cutoff_us: SimTimeUs
    summary_available: bool
    controlled_vehicle_id: str
    current_rri_us: DurationUs
    fresh_observed_count: int
    stale_retained_count: int
    unknown_retained_count: int
    busy_sensing_unit_count: int
    total_sensing_unit_count: int
    decoded_success_count: int
    observable_decode_trial_count: int
    busy_fraction_ppm: int | None
    decode_success_ppm: int | None
    user_ages: tuple[EstimatedUserAge, ...]

    @classmethod
    def create(
        cls,
        *,
        source_observation_hash: str,
        causal_cutoff_us: SimTimeUs,
        summary_available: bool,
        controlled_vehicle_id: str,
        current_rri_us: DurationUs,
        fresh_observed_count: int,
        stale_retained_count: int,
        unknown_retained_count: int,
        busy_sensing_unit_count: int,
        total_sensing_unit_count: int,
        decoded_success_count: int,
        observable_decode_trial_count: int,
        busy_fraction_ppm: int | None,
        decode_success_ppm: int | None,
        user_ages: tuple[EstimatedUserAge, ...],
    ) -> "ControllerStateEstimate":
        values = (
            source_observation_hash,
            int(causal_cutoff_us),
            summary_available,
            controlled_vehicle_id,
            int(current_rri_us),
            fresh_observed_count,
            stale_retained_count,
            unknown_retained_count,
            busy_sensing_unit_count,
            total_sensing_unit_count,
            decoded_success_count,
            observable_decode_trial_count,
            busy_fraction_ppm,
            decode_success_ppm,
            user_ages,
        )
        return cls(
            schema_version=CONTROLLER_STATE_ESTIMATE_SCHEMA_VERSION,
            state_hash=_controller_state_digest(*values),
            source_observation_hash=source_observation_hash,
            causal_cutoff_us=causal_cutoff_us,
            summary_available=summary_available,
            controlled_vehicle_id=controlled_vehicle_id,
            current_rri_us=current_rri_us,
            fresh_observed_count=fresh_observed_count,
            stale_retained_count=stale_retained_count,
            unknown_retained_count=unknown_retained_count,
            busy_sensing_unit_count=busy_sensing_unit_count,
            total_sensing_unit_count=total_sensing_unit_count,
            decoded_success_count=decoded_success_count,
            observable_decode_trial_count=observable_decode_trial_count,
            busy_fraction_ppm=busy_fraction_ppm,
            decode_success_ppm=decode_success_ppm,
            user_ages=user_ages,
        )

    def __post_init__(self) -> None:
        if self.schema_version != CONTROLLER_STATE_ESTIMATE_SCHEMA_VERSION:
            raise ValueError("unsupported controller-state-estimate schema version")
        require_sha256(self.state_hash, "state_hash")
        require_sha256(self.source_observation_hash, "source_observation_hash")
        require_non_negative_int(self.causal_cutoff_us, "causal_cutoff_us")
        if not isinstance(self.summary_available, bool):
            raise ValueError("summary_available must be boolean")
        require_identifier(self.controlled_vehicle_id, "controlled_vehicle_id")
        require_positive_int(self.current_rri_us, "current_rri_us")
        for field_name in (
            "fresh_observed_count",
            "stale_retained_count",
            "unknown_retained_count",
            "busy_sensing_unit_count",
            "total_sensing_unit_count",
            "decoded_success_count",
            "observable_decode_trial_count",
        ):
            require_non_negative_int(getattr(self, field_name), field_name)
        if self.busy_sensing_unit_count > self.total_sensing_unit_count:
            raise ValueError("busy sensing count cannot exceed its denominator")
        if self.decoded_success_count > self.observable_decode_trial_count:
            raise ValueError("decoded success count cannot exceed its denominator")
        _validate_ratio(
            self.busy_fraction_ppm,
            self.busy_sensing_unit_count,
            self.total_sensing_unit_count,
            "busy_fraction_ppm",
        )
        _validate_ratio(
            self.decode_success_ppm,
            self.decoded_success_count,
            self.observable_decode_trial_count,
            "decode_success_ppm",
        )
        if not isinstance(self.user_ages, tuple) or not all(
            isinstance(item, EstimatedUserAge) for item in self.user_ages
        ):
            raise ValueError("user_ages must contain EstimatedUserAge values")
        vehicle_ids = tuple(item.vehicle_id for item in self.user_ages)
        if vehicle_ids != tuple(sorted(vehicle_ids)) or len(set(vehicle_ids)) != len(vehicle_ids):
            raise ValueError("user_ages must be uniquely sorted by vehicle_id")
        if self.state_hash != controller_state_hash(self):
            raise ValueError("state_hash does not bind the state estimate")


def _validate_ratio(value: int | None, numerator: int, denominator: int, field_name: str) -> None:
    if denominator == 0:
        if value is not None:
            raise ValueError(f"{field_name} must be missing when its denominator is zero")
        return
    if value != numerator * PPM_DENOMINATOR // denominator:
        raise ValueError(f"{field_name} does not match its integer counters")


def controller_state_hash(state: ControllerStateEstimate) -> str:
    return _controller_state_digest(
        state.source_observation_hash,
        int(state.causal_cutoff_us),
        state.summary_available,
        state.controlled_vehicle_id,
        int(state.current_rri_us),
        state.fresh_observed_count,
        state.stale_retained_count,
        state.unknown_retained_count,
        state.busy_sensing_unit_count,
        state.total_sensing_unit_count,
        state.decoded_success_count,
        state.observable_decode_trial_count,
        state.busy_fraction_ppm,
        state.decode_success_ppm,
        state.user_ages,
    )


def _controller_state_digest(
    source_observation_hash: str,
    causal_cutoff_us: int,
    summary_available: bool,
    controlled_vehicle_id: str,
    current_rri_us: int,
    fresh_observed_count: int,
    stale_retained_count: int,
    unknown_retained_count: int,
    busy_sensing_unit_count: int,
    total_sensing_unit_count: int,
    decoded_success_count: int,
    observable_decode_trial_count: int,
    busy_fraction_ppm: int | None,
    decode_success_ppm: int | None,
    user_ages: tuple[EstimatedUserAge, ...],
) -> str:
    parts: list[str | int | bool | None] = [
        STATE_HASH_DOMAIN,
        source_observation_hash,
        causal_cutoff_us,
        summary_available,
        controlled_vehicle_id,
        current_rri_us,
        fresh_observed_count,
        stale_retained_count,
        unknown_retained_count,
        busy_sensing_unit_count,
        total_sensing_unit_count,
        decoded_success_count,
        observable_decode_trial_count,
        busy_fraction_ppm,
        decode_success_ppm,
        len(user_ages),
    ]
    for item in user_ages:
        parts.extend((item.vehicle_id, item.age_us, item.ledger_state))
    return stable_digest_hex(*parts)


def seal_controller_state(state: ControllerStateEstimate) -> ControllerStateEstimate:
    """Return the immutable estimate with its canonical content hash."""

    return replace(state, state_hash=controller_state_hash(state))


@dataclass(frozen=True, slots=True)
class ScenarioMember:
    schema_version: str
    member_id: str
    scenario_artifact_hash: str
    mismatch_profile_hash: str | None
    load_scale_ppm: int
    grant_phase_ppm: int
    background_phase_ppm: int
    weight_numerator: int
    weight_denominator: int

    @classmethod
    def create(
        cls,
        *,
        member_id: str,
        mismatch_profile_hash: str | None,
        load_scale_ppm: int,
        grant_phase_ppm: int,
        background_phase_ppm: int,
        weight_numerator: int,
        weight_denominator: int,
    ) -> "ScenarioMember":
        digest = _scenario_member_digest(
            member_id,
            mismatch_profile_hash,
            load_scale_ppm,
            grant_phase_ppm,
            background_phase_ppm,
            weight_numerator,
            weight_denominator,
        )
        return cls(
            schema_version=SCENARIO_MEMBER_SCHEMA_VERSION,
            member_id=member_id,
            scenario_artifact_hash=digest,
            mismatch_profile_hash=mismatch_profile_hash,
            load_scale_ppm=load_scale_ppm,
            grant_phase_ppm=grant_phase_ppm,
            background_phase_ppm=background_phase_ppm,
            weight_numerator=weight_numerator,
            weight_denominator=weight_denominator,
        )

    def __post_init__(self) -> None:
        if self.schema_version != SCENARIO_MEMBER_SCHEMA_VERSION:
            raise ValueError("unsupported scenario-member schema version")
        require_identifier(self.member_id, "member_id")
        _reject_hidden_token(self.member_id, "member_id")
        require_sha256(self.scenario_artifact_hash, "scenario_artifact_hash")
        if self.mismatch_profile_hash is not None:
            require_sha256(self.mismatch_profile_hash, "mismatch_profile_hash")
        require_positive_int(self.load_scale_ppm, "load_scale_ppm")
        if self.load_scale_ppm > 2 * PPM_DENOMINATOR:
            raise ValueError("load_scale_ppm is outside the supported range")
        _require_ppm(self.grant_phase_ppm, "grant_phase_ppm")
        _require_ppm(self.background_phase_ppm, "background_phase_ppm")
        if self.grant_phase_ppm == PPM_DENOMINATOR:
            raise ValueError("grant_phase_ppm upper bound is exclusive")
        if self.background_phase_ppm == PPM_DENOMINATOR:
            raise ValueError("background_phase_ppm upper bound is exclusive")
        require_positive_int(self.weight_numerator, "weight_numerator")
        require_positive_int(self.weight_denominator, "weight_denominator")
        if self.weight_numerator > self.weight_denominator:
            raise ValueError("scenario member weight cannot exceed one")
        if self.scenario_artifact_hash != scenario_member_hash(self):
            raise ValueError("scenario_artifact_hash does not bind forecast parameters")


def scenario_member_hash(member: ScenarioMember) -> str:
    return _scenario_member_digest(
        member.member_id,
        member.mismatch_profile_hash,
        member.load_scale_ppm,
        member.grant_phase_ppm,
        member.background_phase_ppm,
        member.weight_numerator,
        member.weight_denominator,
    )


def _scenario_member_digest(
    member_id: str,
    mismatch_profile_hash: str | None,
    load_scale_ppm: int,
    grant_phase_ppm: int,
    background_phase_ppm: int,
    weight_numerator: int,
    weight_denominator: int,
) -> str:
    return stable_digest_hex(
        SCENARIO_MEMBER_HASH_DOMAIN,
        member_id,
        mismatch_profile_hash,
        load_scale_ppm,
        grant_phase_ppm,
        background_phase_ppm,
        weight_numerator,
        weight_denominator,
    )


def seal_scenario_member(member: ScenarioMember) -> ScenarioMember:
    return replace(member, scenario_artifact_hash=scenario_member_hash(member))


@dataclass(frozen=True, slots=True)
class ScenarioBatch:
    schema_version: str
    batch_id: str
    causal_cutoff_us: SimTimeUs
    model_config_hash: str
    forecast_config_hash: str
    members: tuple[ScenarioMember, ...]

    def __post_init__(self) -> None:
        if self.schema_version != SCENARIO_BATCH_SCHEMA_VERSION:
            raise ValueError("unsupported scenario-batch schema version")
        require_identifier(self.batch_id, "batch_id")
        require_non_negative_int(self.causal_cutoff_us, "causal_cutoff_us")
        require_sha256(self.model_config_hash, "model_config_hash")
        require_sha256(self.forecast_config_hash, "forecast_config_hash")
        if not isinstance(self.members, tuple) or not self.members:
            raise ValueError("members must be a non-empty tuple")
        if not all(isinstance(member, ScenarioMember) for member in self.members):
            raise ValueError("members must contain ScenarioMember values")
        member_ids = tuple(member.member_id for member in self.members)
        if len(set(member_ids)) != len(member_ids):
            raise ValueError("scenario member IDs must be unique")


@dataclass(frozen=True, slots=True)
class ModelTransitionBudget:
    schema_version: str
    budget_id: str
    total_transitions: int
    consumed_transitions: int

    def __post_init__(self) -> None:
        if self.schema_version != MODEL_TRANSITION_BUDGET_SCHEMA_VERSION:
            raise ValueError("unsupported model-transition-budget schema version")
        require_identifier(self.budget_id, "budget_id")
        require_non_negative_int(self.total_transitions, "total_transitions")
        require_non_negative_int(self.consumed_transitions, "consumed_transitions")
        if self.consumed_transitions > self.total_transitions:
            raise ValueError("consumed transitions cannot exceed total transitions")

    @property
    def remaining_transitions(self) -> int:
        return self.total_transitions - self.consumed_transitions

    def consume(self, transition_count: int) -> "ModelTransitionBudget":
        require_positive_int(transition_count, "transition_count")
        if transition_count > self.remaining_transitions:
            raise ValueError("model transition budget is exhausted")
        return replace(
            self,
            consumed_transitions=self.consumed_transitions + transition_count,
        )


@dataclass(frozen=True, slots=True)
class PredictedTraceStep:
    schema_version: str
    elapsed_us: DurationUs
    controlled_age_us: int
    mean_age_us: int
    worst_age_us: int
    collision_risk_ppm: int
    attempted: bool
    expected_success_ppm: int

    def __post_init__(self) -> None:
        if self.schema_version != PREDICTED_TRACE_STEP_SCHEMA_VERSION:
            raise ValueError("unsupported predicted-trace-step schema version")
        require_positive_int(self.elapsed_us, "elapsed_us")
        require_non_negative_int(self.controlled_age_us, "controlled_age_us")
        require_non_negative_int(self.mean_age_us, "mean_age_us")
        require_non_negative_int(self.worst_age_us, "worst_age_us")
        if self.worst_age_us < self.mean_age_us:
            raise ValueError("worst_age_us cannot be below mean_age_us")
        _require_ppm(self.collision_risk_ppm, "collision_risk_ppm")
        if not isinstance(self.attempted, bool):
            raise ValueError("attempted must be boolean")
        _require_ppm(self.expected_success_ppm, "expected_success_ppm")
        if not self.attempted and self.expected_success_ppm != 0:
            raise ValueError("a non-attempt step cannot carry expected success")


@dataclass(frozen=True, slots=True)
class RolloutEvaluation:
    schema_version: str
    action_hash: str
    scenario_member_id: str
    scenario_artifact_hash: str
    source_state_hash: str
    predicted_metric_hash: str
    selected_rri_us: DurationUs
    horizon_us: DurationUs
    transition_count: int
    time_average_mean_age_us: int
    time_average_worst_age_us: int
    terminal_mean_age_us: int
    terminal_worst_age_us: int
    first_attempt_mean_age_us: int
    first_attempt_worst_age_us: int
    predicted_collision_risk_ppm: int
    expected_collision_events_ppm: int
    trace: tuple[PredictedTraceStep, ...]

    @classmethod
    def create(
        cls,
        *,
        action_hash: str,
        scenario_member_id: str,
        scenario_artifact_hash: str,
        source_state_hash: str,
        selected_rri_us: DurationUs,
        horizon_us: DurationUs,
        transition_count: int,
        time_average_mean_age_us: int,
        time_average_worst_age_us: int,
        terminal_mean_age_us: int,
        terminal_worst_age_us: int,
        first_attempt_mean_age_us: int,
        first_attempt_worst_age_us: int,
        predicted_collision_risk_ppm: int,
        expected_collision_events_ppm: int,
        trace: tuple[PredictedTraceStep, ...],
    ) -> "RolloutEvaluation":
        values = (
            action_hash,
            scenario_member_id,
            scenario_artifact_hash,
            source_state_hash,
            int(selected_rri_us),
            int(horizon_us),
            transition_count,
            time_average_mean_age_us,
            time_average_worst_age_us,
            terminal_mean_age_us,
            terminal_worst_age_us,
            first_attempt_mean_age_us,
            first_attempt_worst_age_us,
            predicted_collision_risk_ppm,
            expected_collision_events_ppm,
            trace,
        )
        return cls(
            schema_version=ROLLOUT_EVALUATION_SCHEMA_VERSION,
            action_hash=action_hash,
            scenario_member_id=scenario_member_id,
            scenario_artifact_hash=scenario_artifact_hash,
            source_state_hash=source_state_hash,
            predicted_metric_hash=_rollout_metric_digest(*values),
            selected_rri_us=selected_rri_us,
            horizon_us=horizon_us,
            transition_count=transition_count,
            time_average_mean_age_us=time_average_mean_age_us,
            time_average_worst_age_us=time_average_worst_age_us,
            terminal_mean_age_us=terminal_mean_age_us,
            terminal_worst_age_us=terminal_worst_age_us,
            first_attempt_mean_age_us=first_attempt_mean_age_us,
            first_attempt_worst_age_us=first_attempt_worst_age_us,
            predicted_collision_risk_ppm=predicted_collision_risk_ppm,
            expected_collision_events_ppm=expected_collision_events_ppm,
            trace=trace,
        )

    def __post_init__(self) -> None:
        if self.schema_version != ROLLOUT_EVALUATION_SCHEMA_VERSION:
            raise ValueError("unsupported rollout-evaluation schema version")
        require_sha256(self.action_hash, "action_hash")
        require_identifier(self.scenario_member_id, "scenario_member_id")
        require_sha256(self.scenario_artifact_hash, "scenario_artifact_hash")
        require_sha256(self.source_state_hash, "source_state_hash")
        require_sha256(self.predicted_metric_hash, "predicted_metric_hash")
        require_positive_int(self.selected_rri_us, "selected_rri_us")
        require_positive_int(self.horizon_us, "horizon_us")
        require_positive_int(self.transition_count, "transition_count")
        for field_name in (
            "time_average_mean_age_us",
            "time_average_worst_age_us",
            "terminal_mean_age_us",
            "terminal_worst_age_us",
            "first_attempt_mean_age_us",
            "first_attempt_worst_age_us",
            "expected_collision_events_ppm",
        ):
            require_non_negative_int(getattr(self, field_name), field_name)
        _require_ppm(self.predicted_collision_risk_ppm, "predicted_collision_risk_ppm")
        if not isinstance(self.trace, tuple) or not all(
            isinstance(step, PredictedTraceStep) for step in self.trace
        ):
            raise ValueError("trace must contain PredictedTraceStep values")
        if len(self.trace) != self.transition_count:
            raise ValueError("trace length must equal transition_count")
        if int(self.trace[-1].elapsed_us) != int(self.horizon_us):
            raise ValueError("trace must end at the fixed physical horizon")
        if self.terminal_mean_age_us != self.trace[-1].mean_age_us:
            raise ValueError("terminal mean age does not match the trace")
        if self.terminal_worst_age_us != self.trace[-1].worst_age_us:
            raise ValueError("terminal worst age does not match the trace")
        if self.predicted_metric_hash != rollout_metric_hash(self):
            raise ValueError("predicted_metric_hash does not bind numeric rollout evidence")


def rollout_metric_hash(rollout: RolloutEvaluation) -> str:
    return _rollout_metric_digest(
        rollout.action_hash,
        rollout.scenario_member_id,
        rollout.scenario_artifact_hash,
        rollout.source_state_hash,
        int(rollout.selected_rri_us),
        int(rollout.horizon_us),
        rollout.transition_count,
        rollout.time_average_mean_age_us,
        rollout.time_average_worst_age_us,
        rollout.terminal_mean_age_us,
        rollout.terminal_worst_age_us,
        rollout.first_attempt_mean_age_us,
        rollout.first_attempt_worst_age_us,
        rollout.predicted_collision_risk_ppm,
        rollout.expected_collision_events_ppm,
        rollout.trace,
    )


def _rollout_metric_digest(
    action_hash: str,
    scenario_member_id: str,
    scenario_artifact_hash: str,
    source_state_hash: str,
    selected_rri_us: int,
    horizon_us: int,
    transition_count: int,
    time_average_mean_age_us: int,
    time_average_worst_age_us: int,
    terminal_mean_age_us: int,
    terminal_worst_age_us: int,
    first_attempt_mean_age_us: int,
    first_attempt_worst_age_us: int,
    predicted_collision_risk_ppm: int,
    expected_collision_events_ppm: int,
    trace: tuple[PredictedTraceStep, ...],
) -> str:
    parts: list[str | int | bool] = [
        ROLLOUT_METRIC_HASH_DOMAIN,
        action_hash,
        scenario_member_id,
        scenario_artifact_hash,
        source_state_hash,
        selected_rri_us,
        horizon_us,
        transition_count,
        time_average_mean_age_us,
        time_average_worst_age_us,
        terminal_mean_age_us,
        terminal_worst_age_us,
        first_attempt_mean_age_us,
        first_attempt_worst_age_us,
        predicted_collision_risk_ppm,
        expected_collision_events_ppm,
    ]
    for step in trace:
        parts.extend(
            (
                int(step.elapsed_us),
                step.controlled_age_us,
                step.mean_age_us,
                step.worst_age_us,
                step.collision_risk_ppm,
                step.attempted,
                step.expected_success_ppm,
            )
        )
    return stable_digest_hex(*parts)


def seal_rollout(rollout: RolloutEvaluation) -> RolloutEvaluation:
    return replace(rollout, predicted_metric_hash=rollout_metric_hash(rollout))


@dataclass(frozen=True, slots=True)
class RolloutSet:
    schema_version: str
    budget_before: ModelTransitionBudget
    budget_after: ModelTransitionBudget
    evaluations: tuple[RolloutEvaluation, ...]

    def __post_init__(self) -> None:
        if self.schema_version != ROLLOUT_SET_SCHEMA_VERSION:
            raise ValueError("unsupported rollout-set schema version")
        if not isinstance(self.budget_before, ModelTransitionBudget) or not isinstance(
            self.budget_after, ModelTransitionBudget
        ):
            raise ValueError("rollout budgets must be ModelTransitionBudget values")
        if self.budget_before.budget_id != self.budget_after.budget_id:
            raise ValueError("rollout cannot change budget identity")
        if self.budget_before.total_transitions != self.budget_after.total_transitions:
            raise ValueError("rollout cannot change total transition budget")
        if not isinstance(self.evaluations, tuple) or not self.evaluations:
            raise ValueError("evaluations must be a non-empty tuple")
        if not all(isinstance(item, RolloutEvaluation) for item in self.evaluations):
            raise ValueError("evaluations must contain RolloutEvaluation values")
        charged = self.budget_after.consumed_transitions - self.budget_before.consumed_transitions
        expected = sum(item.transition_count for item in self.evaluations)
        if charged != expected:
            raise ValueError("rollout budget charge does not equal evaluated transitions")


class PredictiveModel(Protocol):
    def rollout(
        self,
        frame: ObservableFrame,
        state: ControllerStateEstimate,
        action: ControlAction,
        scenarios: ScenarioBatch,
        horizon_us: DurationUs,
        budget: ModelTransitionBudget,
    ) -> RolloutSet: ...
