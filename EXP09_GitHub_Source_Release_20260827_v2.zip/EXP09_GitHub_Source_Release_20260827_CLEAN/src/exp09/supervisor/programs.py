"""C10 recovery-program library, verifier, executor, and orchestration scaffold."""

from dataclasses import dataclass, replace
from enum import Enum

from exp09.contracts.determinism import stable_digest_hex
from exp09.contracts.ids import ProgramId, require_identifier, require_sha256
from exp09.contracts.supervisor import (
    ELIGIBLE_PROPOSAL_SCHEMA_VERSION,
    PROGRAM_PROPOSAL_SCHEMA_VERSION,
    EligibleProposal,
    ProgramProposal,
    RationaleCode,
    TransitionId,
)
from exp09.contracts.time import SimTimeUs, require_non_negative_int, require_positive_int

RECOVERY_PROGRAM_SCHEMA_VERSION = "exp09-recovery-program-v1"
PROGRAM_LIBRARY_SCHEMA_VERSION = "exp09-program-library-v1"
PROGRAM_STATE_SCHEMA_VERSION = "exp09-program-state-v1"
PROGRAM_TRANSITION_RECORD_SCHEMA_VERSION = "exp09-program-transition-record-v1"
ORCHESTRATOR_RECORD_SCHEMA_VERSION = "exp09-orchestrator-record-v1"
PROGRAM_LIBRARY_HASH_DOMAIN = "exp09-program-library-v1"
PROGRAM_STATE_HASH_DOMAIN = "exp09-program-state-v1"


class ProviderOutcome(str, Enum):
    ACCEPTED = "ACCEPTED"
    REJECTED = "REJECTED"
    FALLBACK = "FALLBACK"


@dataclass(frozen=True, slots=True)
class RecoveryProgram:
    schema_version: str
    program_id: ProgramId
    priority: int
    ttl_us: int
    min_dwell_us: int
    budget_cost_units: int

    def __post_init__(self) -> None:
        if self.schema_version != RECOVERY_PROGRAM_SCHEMA_VERSION:
            raise ValueError("unsupported recovery-program schema version")
        require_identifier(self.program_id, "program_id")
        require_non_negative_int(self.priority, "priority")
        require_positive_int(self.ttl_us, "ttl_us")
        require_non_negative_int(self.min_dwell_us, "min_dwell_us")
        require_positive_int(self.budget_cost_units, "budget_cost_units")


@dataclass(frozen=True, slots=True)
class ProgramLibrary:
    schema_version: str
    library_id: str
    programs: tuple[RecoveryProgram, ...]

    def __post_init__(self) -> None:
        if self.schema_version != PROGRAM_LIBRARY_SCHEMA_VERSION:
            raise ValueError("unsupported program-library schema version")
        require_identifier(self.library_id, "library_id")
        if not isinstance(self.programs, tuple) or not self.programs:
            raise ValueError("programs must be a non-empty tuple")
        if not all(isinstance(program, RecoveryProgram) for program in self.programs):
            raise ValueError("programs must contain RecoveryProgram values")
        program_ids = tuple(program.program_id for program in self.programs)
        if len(program_ids) != len(set(program_ids)):
            raise ValueError("program IDs must be unique")

    @property
    def library_hash(self) -> str:
        parts: list[str | int] = [PROGRAM_LIBRARY_HASH_DOMAIN, self.library_id, len(self.programs)]
        for program in self.programs:
            parts.extend(
                (
                    str(program.program_id),
                    program.priority,
                    program.ttl_us,
                    program.min_dwell_us,
                    program.budget_cost_units,
                )
            )
        return stable_digest_hex(*parts)

    def require_program(self, program_id: ProgramId) -> RecoveryProgram:
        for program in self.programs:
            if program.program_id == program_id:
                return program
        raise ValueError("program_id is not in the library")


@dataclass(frozen=True, slots=True)
class ProgramState:
    schema_version: str
    state_hash: str
    current_program_id: ProgramId
    current_started_us: SimTimeUs
    last_transition_us: SimTimeUs
    remaining_budget_units: int

    @classmethod
    def create(
        cls,
        *,
        current_program_id: ProgramId,
        current_started_us: SimTimeUs,
        last_transition_us: SimTimeUs,
        remaining_budget_units: int,
    ) -> "ProgramState":
        return cls(
            schema_version=PROGRAM_STATE_SCHEMA_VERSION,
            state_hash="0" * 64,
            current_program_id=current_program_id,
            current_started_us=current_started_us,
            last_transition_us=last_transition_us,
            remaining_budget_units=remaining_budget_units,
        ).seal()

    def seal(self) -> "ProgramState":
        return replace(self, state_hash=program_state_hash(self))

    def __post_init__(self) -> None:
        if self.schema_version != PROGRAM_STATE_SCHEMA_VERSION:
            raise ValueError("unsupported program-state schema version")
        require_sha256(self.state_hash, "state_hash")
        require_identifier(self.current_program_id, "current_program_id")
        require_non_negative_int(self.current_started_us, "current_started_us")
        require_non_negative_int(self.last_transition_us, "last_transition_us")
        require_non_negative_int(self.remaining_budget_units, "remaining_budget_units")
        if self.last_transition_us < self.current_started_us:
            raise ValueError("last_transition_us cannot precede current_started_us")
        if self.state_hash != "0" * 64 and self.state_hash != program_state_hash(self):
            raise ValueError("state_hash does not bind program state")


def program_state_hash(state: ProgramState) -> str:
    return stable_digest_hex(
        PROGRAM_STATE_HASH_DOMAIN,
        str(state.current_program_id),
        int(state.current_started_us),
        int(state.last_transition_us),
        state.remaining_budget_units,
    )


def eligible_proposals(
    *,
    library: ProgramLibrary,
    state: ProgramState,
    now_us: SimTimeUs,
    trigger_active: bool,
) -> tuple[EligibleProposal, ...]:
    require_non_negative_int(now_us, "now_us")
    current = library.require_program(state.current_program_id)
    age_us = int(now_us) - int(state.current_started_us)
    dwell_us = int(now_us) - int(state.last_transition_us)
    if age_us < 0 or dwell_us < 0:
        raise ValueError("program eligibility cannot evaluate future state")
    proposals = [
        EligibleProposal(
            schema_version=ELIGIBLE_PROPOSAL_SCHEMA_VERSION,
            transition_id=TransitionId.HOLD,
            target_program_id=state.current_program_id,
        )
    ]
    if age_us >= current.ttl_us:
        proposals.append(
            EligibleProposal(
                schema_version=ELIGIBLE_PROPOSAL_SCHEMA_VERSION,
                transition_id=TransitionId.RETURN_BALANCED,
                target_program_id=ProgramId("balanced"),
            )
        )
    if trigger_active and dwell_us >= current.min_dwell_us:
        for program in sorted(library.programs, key=lambda item: (item.priority, str(item.program_id))):
            if (
                program.program_id != state.current_program_id
                and program.budget_cost_units <= state.remaining_budget_units
            ):
                proposals.append(
                    EligibleProposal(
                        schema_version=ELIGIBLE_PROPOSAL_SCHEMA_VERSION,
                        transition_id=TransitionId.SWITCH,
                        target_program_id=program.program_id,
                    )
                )
    return tuple(proposals)


class ProgramProposalVerifier:
    def verify(
        self,
        *,
        proposal: ProgramProposal,
        eligible: tuple[EligibleProposal, ...],
    ) -> None:
        if not isinstance(proposal, ProgramProposal):
            raise ValueError("proposal must be a ProgramProposal")
        if not isinstance(eligible, tuple) or not eligible:
            raise ValueError("eligible proposals must be a non-empty tuple")
        allowed = {
            (item.transition_id, item.target_program_id)
            for item in eligible
        }
        if (proposal.transition_id, proposal.target_program_id) not in allowed:
            raise ValueError("proposal is not in the eligible set")


@dataclass(frozen=True, slots=True)
class ProgramTransitionRecord:
    schema_version: str
    prior_state_hash: str
    next_state: ProgramState
    transition_id: TransitionId
    target_program_id: ProgramId | None
    outcome: ProviderOutcome

    def __post_init__(self) -> None:
        if self.schema_version != PROGRAM_TRANSITION_RECORD_SCHEMA_VERSION:
            raise ValueError("unsupported program-transition-record schema version")
        require_sha256(self.prior_state_hash, "prior_state_hash")
        if not isinstance(self.next_state, ProgramState):
            raise ValueError("next_state must be a ProgramState")
        if not isinstance(self.transition_id, TransitionId):
            raise ValueError("transition_id must be a TransitionId")
        if self.target_program_id is not None:
            require_identifier(self.target_program_id, "target_program_id")
        if not isinstance(self.outcome, ProviderOutcome):
            raise ValueError("outcome must be a ProviderOutcome")


class ProgramExecutor:
    def execute(
        self,
        *,
        library: ProgramLibrary,
        state: ProgramState,
        proposal: ProgramProposal,
        now_us: SimTimeUs,
    ) -> ProgramTransitionRecord:
        prior_hash = state.state_hash
        if proposal.transition_id in {TransitionId.HOLD, TransitionId.START}:
            next_state = replace(
                state,
                state_hash="0" * 64,
                last_transition_us=now_us,
            ).seal()
        else:
            if proposal.target_program_id is None:
                raise ValueError("program transition requires a target")
            target = library.require_program(proposal.target_program_id)
            remaining = state.remaining_budget_units
            if proposal.transition_id is TransitionId.SWITCH:
                if target.budget_cost_units > remaining:
                    raise ValueError("program transition budget is exhausted")
                remaining -= target.budget_cost_units
            next_state = ProgramState.create(
                current_program_id=target.program_id,
                current_started_us=now_us,
                last_transition_us=now_us,
                remaining_budget_units=remaining,
            )
        return ProgramTransitionRecord(
            schema_version=PROGRAM_TRANSITION_RECORD_SCHEMA_VERSION,
            prior_state_hash=prior_hash,
            next_state=next_state,
            transition_id=proposal.transition_id,
            target_program_id=proposal.target_program_id,
            outcome=ProviderOutcome.ACCEPTED,
        )


@dataclass(frozen=True, slots=True)
class OrchestratorRecord:
    schema_version: str
    eligible_count: int
    provider_outcome: ProviderOutcome
    transition_record: ProgramTransitionRecord
    fast_path_blocked: bool

    def __post_init__(self) -> None:
        if self.schema_version != ORCHESTRATOR_RECORD_SCHEMA_VERSION:
            raise ValueError("unsupported orchestrator-record schema version")
        require_positive_int(self.eligible_count, "eligible_count")
        if not isinstance(self.provider_outcome, ProviderOutcome):
            raise ValueError("provider_outcome must be a ProviderOutcome")
        if not isinstance(self.transition_record, ProgramTransitionRecord):
            raise ValueError("transition_record must be a ProgramTransitionRecord")
        if self.fast_path_blocked is not False:
            raise ValueError("C10 constructed fast path must remain non-blocking")


class ProgramOrchestrator:
    def apply_provider_proposal(
        self,
        *,
        library: ProgramLibrary,
        state: ProgramState,
        proposal: ProgramProposal | None,
        now_us: SimTimeUs,
        trigger_active: bool,
    ) -> OrchestratorRecord:
        eligible = eligible_proposals(
            library=library,
            state=state,
            now_us=now_us,
            trigger_active=trigger_active,
        )
        if proposal is None:
            proposal = ProgramProposal(
                schema_version=PROGRAM_PROPOSAL_SCHEMA_VERSION,
                transition_id=TransitionId.HOLD,
                target_program_id=state.current_program_id,
                rationale_code=RationaleCode.HOLD_UNCERTAIN_EVIDENCE,
            )
            outcome = ProviderOutcome.FALLBACK
        else:
            ProgramProposalVerifier().verify(proposal=proposal, eligible=eligible)
            outcome = ProviderOutcome.ACCEPTED
        transition = ProgramExecutor().execute(
            library=library,
            state=state,
            proposal=proposal,
            now_us=now_us,
        )
        transition = ProgramTransitionRecord(
            schema_version=PROGRAM_TRANSITION_RECORD_SCHEMA_VERSION,
            prior_state_hash=transition.prior_state_hash,
            next_state=transition.next_state,
            transition_id=transition.transition_id,
            target_program_id=transition.target_program_id,
            outcome=outcome,
        )
        return OrchestratorRecord(
            schema_version=ORCHESTRATOR_RECORD_SCHEMA_VERSION,
            eligible_count=len(eligible),
            provider_outcome=outcome,
            transition_record=transition,
            fast_path_blocked=False,
        )
