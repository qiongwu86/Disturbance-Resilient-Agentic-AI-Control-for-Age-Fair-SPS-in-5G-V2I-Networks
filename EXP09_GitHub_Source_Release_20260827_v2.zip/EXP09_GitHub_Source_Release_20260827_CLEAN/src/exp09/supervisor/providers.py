"""C11 same-stack supervisor provider adapters without network access."""

from dataclasses import dataclass
from enum import Enum

from exp09.contracts.determinism import stable_digest_hex
from exp09.contracts.ids import RequestId, require_identifier, require_sha256
from exp09.contracts.supervisor import (
    PROGRAM_PROPOSAL_SCHEMA_VERSION,
    ProgramProposal,
    RationaleCode,
    TransitionId,
)
from exp09.contracts.time import SimTimeUs, require_non_negative_int, require_positive_int
from exp09.supervisor.programs import ProgramLibrary

EVIDENCE_BUNDLE_SCHEMA_VERSION = "exp09-evidence-bundle-v1"
PROVIDER_CONFIG_SCHEMA_VERSION = "exp09-provider-config-v1"
PROVIDER_REQUEST_SCHEMA_VERSION = "exp09-provider-request-v1"
PROVIDER_RESPONSE_SCHEMA_VERSION = "exp09-provider-response-v1"
PROVIDER_CACHE_SCHEMA_VERSION = "exp09-provider-cache-v1"
EVIDENCE_BUNDLE_HASH_DOMAIN = "exp09-evidence-bundle-v1"
PROVIDER_STACK_HASH_DOMAIN = "exp09-provider-stack-v1"
PROVIDER_REQUEST_HASH_DOMAIN = "exp09-provider-request-v1"


class ProviderKind(str, Enum):
    RULE = "RULE"
    TUNED_NON_LLM = "TUNED_NON_LLM"
    OFFLINE_LLM_REPLAY = "OFFLINE_LLM_REPLAY"


@dataclass(frozen=True, slots=True)
class EvidenceBundle:
    schema_version: str
    evidence_id: str
    causal_cutoff_us: SimTimeUs
    detector_active: bool
    risk_ppm: int
    memory_interval_low_ppm: int
    memory_interval_high_ppm: int

    @property
    def evidence_hash(self) -> str:
        return stable_digest_hex(
            EVIDENCE_BUNDLE_HASH_DOMAIN,
            self.evidence_id,
            int(self.causal_cutoff_us),
            self.detector_active,
            self.risk_ppm,
            self.memory_interval_low_ppm,
            self.memory_interval_high_ppm,
        )

    def __post_init__(self) -> None:
        if self.schema_version != EVIDENCE_BUNDLE_SCHEMA_VERSION:
            raise ValueError("unsupported evidence-bundle schema version")
        require_identifier(self.evidence_id, "evidence_id")
        require_non_negative_int(self.causal_cutoff_us, "causal_cutoff_us")
        if not isinstance(self.detector_active, bool):
            raise ValueError("detector_active must be boolean")
        for field_name in ("risk_ppm", "memory_interval_low_ppm", "memory_interval_high_ppm"):
            require_non_negative_int(getattr(self, field_name), field_name)
            if getattr(self, field_name) > 1_000_000:
                raise ValueError(f"{field_name} cannot exceed 1,000,000")
        if self.memory_interval_low_ppm > self.memory_interval_high_ppm:
            raise ValueError("memory interval is inverted")


@dataclass(frozen=True, slots=True)
class ProviderConfig:
    schema_version: str
    provider_id: str
    provider_kind: ProviderKind
    program_library_hash: str
    request_budget_units: int
    retry_budget: int
    prompt_schema_hash: str

    @property
    def stack_hash(self) -> str:
        return stable_digest_hex(
            PROVIDER_STACK_HASH_DOMAIN,
            self.program_library_hash,
            self.request_budget_units,
            self.retry_budget,
            self.prompt_schema_hash,
        )

    def __post_init__(self) -> None:
        if self.schema_version != PROVIDER_CONFIG_SCHEMA_VERSION:
            raise ValueError("unsupported provider-config schema version")
        require_identifier(self.provider_id, "provider_id")
        if not isinstance(self.provider_kind, ProviderKind):
            raise ValueError("provider_kind must be a ProviderKind")
        require_sha256(self.program_library_hash, "program_library_hash")
        require_positive_int(self.request_budget_units, "request_budget_units")
        require_non_negative_int(self.retry_budget, "retry_budget")
        require_sha256(self.prompt_schema_hash, "prompt_schema_hash")


@dataclass(frozen=True, slots=True)
class ProviderRequest:
    schema_version: str
    request_id: RequestId
    config_hash: str
    evidence_hash: str
    namespace: str
    attempt_ordinal: int

    @property
    def request_hash(self) -> str:
        return stable_digest_hex(
            PROVIDER_REQUEST_HASH_DOMAIN,
            str(self.request_id),
            self.config_hash,
            self.evidence_hash,
            self.namespace,
            self.attempt_ordinal,
        )

    def __post_init__(self) -> None:
        if self.schema_version != PROVIDER_REQUEST_SCHEMA_VERSION:
            raise ValueError("unsupported provider-request schema version")
        require_identifier(self.request_id, "request_id")
        require_sha256(self.config_hash, "config_hash")
        require_sha256(self.evidence_hash, "evidence_hash")
        require_identifier(self.namespace, "namespace")
        require_non_negative_int(self.attempt_ordinal, "attempt_ordinal")


@dataclass(frozen=True, slots=True)
class ProviderResponse:
    schema_version: str
    request_hash: str
    proposal: ProgramProposal
    response_hash: str

    def __post_init__(self) -> None:
        if self.schema_version != PROVIDER_RESPONSE_SCHEMA_VERSION:
            raise ValueError("unsupported provider-response schema version")
        require_sha256(self.request_hash, "request_hash")
        if not isinstance(self.proposal, ProgramProposal):
            raise ValueError("proposal must be a ProgramProposal")
        require_sha256(self.response_hash, "response_hash")
        if self.response_hash != provider_response_hash(self.request_hash, self.proposal):
            raise ValueError("response_hash does not bind provider response content")


def provider_response_hash(request_hash: str, proposal: ProgramProposal) -> str:
    return stable_digest_hex(
        "exp09-provider-response-v1",
        request_hash,
        proposal.transition_id.value,
        str(proposal.target_program_id) if proposal.target_program_id is not None else "NONE",
        proposal.rationale_code.value,
    )


class ProviderCache:
    def __init__(self, *, schema_version: str, namespace: str) -> None:
        if schema_version != PROVIDER_CACHE_SCHEMA_VERSION:
            raise ValueError("unsupported provider-cache schema version")
        require_identifier(namespace, "namespace")
        self._namespace = namespace
        self._records: dict[str, ProviderResponse] = {}

    @property
    def namespace(self) -> str:
        return self._namespace

    def get(self, request: ProviderRequest) -> ProviderResponse | None:
        if request.namespace != self._namespace:
            raise ValueError("cache namespace mismatch")
        return self._records.get(request.request_hash)

    def put(self, request: ProviderRequest, response: ProviderResponse) -> None:
        if request.namespace != self._namespace:
            raise ValueError("cache namespace mismatch")
        if response.request_hash != request.request_hash:
            raise ValueError("response does not match request")
        existing = self._records.get(request.request_hash)
        if existing is not None and existing != response:
            raise ValueError("cache cannot replace a response for the same request")
        self._records[request.request_hash] = response


def canonical_provider_request(
    *,
    request_id: RequestId,
    config: ProviderConfig,
    evidence: EvidenceBundle,
    namespace: str,
    attempt_ordinal: int,
) -> ProviderRequest:
    return ProviderRequest(
        schema_version=PROVIDER_REQUEST_SCHEMA_VERSION,
        request_id=request_id,
        config_hash=config.stack_hash,
        evidence_hash=evidence.evidence_hash,
        namespace=namespace,
        attempt_ordinal=attempt_ordinal,
    )


class RuleProvider:
    def propose(
        self,
        *,
        library: ProgramLibrary,
        evidence: EvidenceBundle,
    ) -> ProgramProposal:
        target = None
        transition = TransitionId.HOLD
        rationale = RationaleCode.HOLD_UNCERTAIN_EVIDENCE
        if evidence.detector_active:
            ordered = sorted(library.programs, key=lambda item: (item.priority, str(item.program_id)))
            target = ordered[0].program_id
            transition = TransitionId.SWITCH
            rationale = RationaleCode.EVIDENCE_SUPPORTED_TRANSITION
        return ProgramProposal(
            schema_version=PROGRAM_PROPOSAL_SCHEMA_VERSION,
            transition_id=transition,
            target_program_id=target,
            rationale_code=rationale,
        )


class TunedNonLLMProvider:
    def __init__(self, *, risk_threshold_ppm: int) -> None:
        require_non_negative_int(risk_threshold_ppm, "risk_threshold_ppm")
        self._risk_threshold_ppm = risk_threshold_ppm

    def propose(
        self,
        *,
        library: ProgramLibrary,
        evidence: EvidenceBundle,
    ) -> ProgramProposal:
        return RuleProvider().propose(
            library=library,
            evidence=EvidenceBundle(
                schema_version=evidence.schema_version,
                evidence_id=evidence.evidence_id,
                causal_cutoff_us=evidence.causal_cutoff_us,
                detector_active=evidence.risk_ppm >= self._risk_threshold_ppm,
                risk_ppm=evidence.risk_ppm,
                memory_interval_low_ppm=evidence.memory_interval_low_ppm,
                memory_interval_high_ppm=evidence.memory_interval_high_ppm,
            ),
        )


class OfflineLlmReplayAdapter:
    """Canonical parser/cache adapter for offline replayed responses only."""

    def __init__(self, *, cache: ProviderCache, scripted_responses: tuple[ProviderResponse, ...]) -> None:
        self._cache = cache
        if not isinstance(scripted_responses, tuple):
            raise ValueError("scripted_responses must be a tuple")
        self._scripted: dict[str, ProviderResponse] = {}
        for response in scripted_responses:
            if not isinstance(response, ProviderResponse):
                raise ValueError("scripted_responses must contain ProviderResponse values")
            if response.request_hash in self._scripted:
                raise ValueError("offline replay responses must not duplicate request_hash")
            self._scripted[response.request_hash] = response

    def propose(self, request: ProviderRequest) -> ProviderResponse:
        cached = self._cache.get(request)
        if cached is not None:
            return cached
        response = self._scripted.get(request.request_hash)
        if response is None:
            raise ValueError("offline LLM replay has no response for request; network calls are forbidden")
        self._cache.put(request, response)
        return response
