"""C06 deterministic runner with causal observation transport and raw replay."""

from dataclasses import dataclass
from typing import Protocol

from exp09.artifacts.canonical import canonical_sha256
from exp09.contracts.actions import ACTION_SCHEMA_VERSION, ActionKind, ControlAction, ControlOpportunity
from exp09.contracts.controller import (
    COMMITMENT_SCHEMA_VERSION,
    CONTROLLER_RESET_SCHEMA_VERSION,
    CommitmentRecord,
    Controller,
    ControllerResetContext,
)
from exp09.contracts.determinism import stable_event_id
from exp09.contracts.ids import RootCaseId, RunId
from exp09.contracts.observable import MeasurementDeliveryEvent, ObservableFrame
from exp09.contracts.tape import DisturbanceTape, TapeArm
from exp09.measurement.receiver_ledger import (
    AGGREGATION_WINDOW_US,
    MEASUREMENT_DELAY_US,
    SUMMARY_PERIOD_US,
    LedgerSnapshot,
    MeasurementSummary,
    ObservationAdapter,
    ReceiverMeasurementLedger,
)
from exp09.plant.plant import DiscreteEventSPSPlant
from exp09.plant.state import PlantTrace, TerminalOutcome

from .disturbance_tape import build_primary_influx_tape, validate_primary_tape
from .metrics_accumulator import CaseMetrics, compute_case_metrics

RAW_RUN_TRACE_SCHEMA_VERSION = "exp09-raw-run-trace-v3"
ACTION_RECORD_SCHEMA_VERSION = "exp09-action-record-v1"
SUMMARY_DELIVERY_RECORD_SCHEMA_VERSION = "exp09-summary-delivery-record-v1"
RUN_RESULT_SCHEMA_VERSION = "exp09-run-result-v2"
RECORDED_ACTION_REPLAY_SCHEMA_VERSION = "exp09-recorded-action-replay-v1"


class ActionReplay(Protocol):
    def action_for(
        self, frame: ObservableFrame, opportunity: ControlOpportunity
    ) -> ControlAction: ...


@dataclass(frozen=True, slots=True)
class ActionRecord:
    schema_version: str
    opportunity_id: str
    time_us: int
    kind: str
    target_rri_us: int | None
    frame_hash: str

    def __post_init__(self) -> None:
        if self.schema_version != ACTION_RECORD_SCHEMA_VERSION:
            raise ValueError("unsupported action-record schema")


@dataclass(frozen=True, slots=True)
class SummaryDeliveryRecord:
    schema_version: str
    sequence: int
    generated_at_us: int
    received_at_us: int
    payload_hash: str
    frame: ObservableFrame

    def __post_init__(self) -> None:
        if self.schema_version != SUMMARY_DELIVERY_RECORD_SCHEMA_VERSION:
            raise ValueError("unsupported summary-delivery-record schema")


@dataclass(frozen=True, slots=True)
class RawRunTrace:
    schema_version: str
    tape: DisturbanceTape
    plant_trace: PlantTrace
    actions: tuple[ActionRecord, ...]
    measurement_deliveries: tuple[MeasurementDeliveryEvent, ...]
    ledger_snapshot: LedgerSnapshot
    summaries: tuple[MeasurementSummary, ...]
    summary_deliveries: tuple[SummaryDeliveryRecord, ...]

    def __post_init__(self) -> None:
        if self.schema_version != RAW_RUN_TRACE_SCHEMA_VERSION:
            raise ValueError("unsupported raw-run-trace schema version")


@dataclass(frozen=True, slots=True)
class RunResult:
    schema_version: str
    root_case_id: str
    arm: TapeArm
    metrics: CaseMetrics
    observable_frame_count: int
    tx_attempts: int
    raw_trace: RawRunTrace
    integrity_hash: str

    def __post_init__(self) -> None:
        if self.schema_version != RUN_RESULT_SCHEMA_VERSION:
            raise ValueError("unsupported run-result schema")


class RetainController:
    def reset(self, context: ControllerResetContext) -> None:
        self._context = context

    def decide(
        self, frame: ObservableFrame, opportunity: ControlOpportunity
    ) -> CommitmentRecord:
        action = ControlAction(
            schema_version=ACTION_SCHEMA_VERSION,
            opportunity_id=opportunity.opportunity_id,
            kind=ActionKind.RETAIN_AT_EXPIRY,
            target_rri_us=None,
        )
        return CommitmentRecord(
            schema_version=COMMITMENT_SCHEMA_VERSION,
            observation_hash=_frame_hash(frame),
            action=action,
        )


@dataclass(frozen=True, slots=True)
class RecordedActionReplay:
    schema_version: str
    actions: tuple[ActionRecord, ...]

    def __post_init__(self) -> None:
        if self.schema_version != RECORDED_ACTION_REPLAY_SCHEMA_VERSION:
            raise ValueError("unsupported recorded-action-replay schema")

    def action_for(
        self, frame: ObservableFrame, opportunity: ControlOpportunity
    ) -> ControlAction:
        matches = tuple(
            item
            for item in self.actions
            if item.opportunity_id == str(opportunity.opportunity_id)
        )
        if len(matches) != 1:
            raise ValueError("action replay requires exactly one matching opportunity")
        record = matches[0]
        if record.time_us != int(opportunity.time_us):
            raise ValueError("action replay time does not match the opportunity")
        if record.frame_hash != _frame_hash(frame):
            raise ValueError("action replay observation hash does not match")
        return ControlAction(
            schema_version=ACTION_SCHEMA_VERSION,
            opportunity_id=opportunity.opportunity_id,
            kind=ActionKind(record.kind),
            target_rri_us=record.target_rri_us,
        )


def run_open_loop_case(
    root_case_id: str,
    arm: TapeArm,
    *,
    controller: Controller | None = None,
    action_replay: ActionReplay | None = None,
) -> RunResult:
    return run_case(
        build_primary_influx_tape(root_case_id, arm),
        controller=controller,
        action_replay=action_replay,
    )


def run_case(
    tape: DisturbanceTape,
    *,
    controller: Controller | None = None,
    action_replay: ActionReplay | None = None,
) -> RunResult:
    validate_primary_tape(tape)
    if controller is not None and action_replay is not None:
        raise ValueError("controller and action_replay are mutually exclusive")
    selected_controller = controller or RetainController()
    controller_reset = False

    plant = DiscreteEventSPSPlant()
    plant.reset(tape)
    ledger = ReceiverMeasurementLedger()
    adapter = ObservationAdapter()
    actions: list[ActionRecord] = []
    measurement_deliveries: list[MeasurementDeliveryEvent] = []
    summaries: list[MeasurementSummary] = []
    summary_deliveries: list[SummaryDeliveryRecord] = []
    next_summary_us = int(tape.simulation_start_us)
    next_delivery_sequence = 0
    latest_snapshot = plant.snapshot()

    while latest_snapshot.time_us < int(tape.simulation_end_us):
        previous_time_us = latest_snapshot.time_us
        result = plant.advance_until(int(tape.simulation_end_us))
        latest_snapshot = result.snapshot
        boundary_us = latest_snapshot.time_us
        if (
            not result.opportunities
            and boundary_us < int(tape.simulation_end_us)
            and boundary_us <= previous_time_us
        ):
            raise RuntimeError(
                "plant made no forward progress without a control opportunity"
            )
        for event in result.measurement_delivery_delta:
            ledger.ingest_delivery(event)
            measurement_deliveries.append(event)
        while next_summary_us <= boundary_us and next_summary_us < int(tape.simulation_end_us):
            summaries.append(
                ledger.summarize(
                    next_summary_us,
                    window_start_us=int(tape.simulation_start_us),
                )
            )
            next_summary_us += SUMMARY_PERIOD_US
        next_delivery_sequence = _deliver_due_summaries(
            summaries,
            next_delivery_sequence,
            boundary_us,
            adapter,
            summary_deliveries,
        )
        if result.opportunities:
            opportunity = result.opportunities[0]
            frame = _latest_frame_or_unavailable(
                summary_deliveries,
                summaries,
                adapter,
                int(opportunity.time_us),
            )
            if action_replay is None:
                if not controller_reset:
                    selected_controller.reset(_reset_context(tape))
                    controller_reset = True
                commitment = selected_controller.decide(frame, opportunity)
                if commitment.observation_hash != _frame_hash(frame):
                    raise ValueError("controller commitment observation hash mismatch")
                action = commitment.action
            else:
                action = action_replay.action_for(frame, opportunity)
            actions.append(_action_record(action, opportunity, frame))
            latest_snapshot = plant.apply(opportunity, action)
        elif boundary_us >= int(tape.simulation_end_us):
            break

    final_snapshot = plant.snapshot()
    raw = RawRunTrace(
        schema_version=RAW_RUN_TRACE_SCHEMA_VERSION,
        tape=tape,
        plant_trace=final_snapshot.trace,
        actions=tuple(actions),
        measurement_deliveries=tuple(measurement_deliveries),
        ledger_snapshot=ledger.snapshot(),
        summaries=tuple(summaries),
        summary_deliveries=tuple(summary_deliveries),
    )
    metrics = rebuild_metrics(raw)
    return RunResult(
        schema_version=RUN_RESULT_SCHEMA_VERSION,
        root_case_id=str(tape.root_case_id),
        arm=tape.arm,
        metrics=metrics,
        observable_frame_count=len(summary_deliveries),
        tx_attempts=metrics.tx_attempts,
        raw_trace=raw,
        integrity_hash=canonical_sha256(
            raw, expected_schema_version=RAW_RUN_TRACE_SCHEMA_VERSION
        ),
    )


def rebuild_metrics(raw: RawRunTrace) -> CaseMetrics:
    rebuilt_snapshot = _validate_raw(raw)
    _replay_observable_frames_validated(raw)
    observable_history = tuple(
        sorted(
            (
                *rebuilt_snapshot.packet_observations,
                *rebuilt_snapshot.identity_events,
            ),
            key=lambda item: (int(item.observed_at_us), str(item.event_id)),
        )
    )
    return compute_case_metrics(
        raw.tape,
        raw.plant_trace,
        observable_history=observable_history,
    )


def replay_observable_frames(raw: RawRunTrace) -> tuple[ObservableFrame, ...]:
    _validate_raw(raw)
    return _replay_observable_frames_validated(raw)


def _replay_observable_frames_validated(
    raw: RawRunTrace,
) -> tuple[ObservableFrame, ...]:
    ledger = ReceiverMeasurementLedger()
    delivery_index = 0
    summary_by_sequence = {item.header.sequence: item for item in raw.summaries}
    rebuilt_frames: list[ObservableFrame] = []
    for recorded_summary in raw.summaries:
        generated_at_us = int(recorded_summary.header.causal_cutoff_us)
        while (
            delivery_index < len(raw.measurement_deliveries)
            and int(raw.measurement_deliveries[delivery_index].delivered_at_us)
            <= generated_at_us
        ):
            ledger.ingest_delivery(raw.measurement_deliveries[delivery_index])
            delivery_index += 1
        rebuilt_summary = ledger.summarize(
            generated_at_us,
            window_start_us=int(raw.tape.simulation_start_us),
        )
        if recorded_summary != rebuilt_summary:
            raise ValueError("raw ledger replay does not reproduce the recorded summary")
    for record in raw.summary_deliveries:
        recorded_summary = summary_by_sequence.get(record.sequence)
        if recorded_summary is None:
            raise ValueError("raw delivery references an unknown summary sequence")
        frame = ObservationAdapter().build(recorded_summary, record.received_at_us)
        if frame != record.frame or frame.summary_payload_hash != record.payload_hash:
            raise ValueError("raw ledger replay does not reproduce the recorded frame")
        rebuilt_frames.append(frame)
    for action in raw.actions:
        decision_frame = _latest_frame_or_unavailable(
            list(raw.summary_deliveries),
            list(raw.summaries),
            ObservationAdapter(),
            action.time_us,
        )
        if _frame_hash(decision_frame) != action.frame_hash:
            raise ValueError("raw action frame hash does not replay at decision time")
    return tuple(rebuilt_frames)


def _deliver_due_summaries(
    summaries: list[MeasurementSummary],
    start_index: int,
    boundary_us: int,
    adapter: ObservationAdapter,
    records: list[SummaryDeliveryRecord],
) -> int:
    index = start_index
    while index < len(summaries):
        summary = summaries[index]
        received_at = int(summary.header.causal_cutoff_us) + MEASUREMENT_DELAY_US
        if received_at > boundary_us:
            break
        frame = adapter.build(summary, received_at)
        records.append(
            SummaryDeliveryRecord(
                schema_version=SUMMARY_DELIVERY_RECORD_SCHEMA_VERSION,
                sequence=summary.header.sequence,
                generated_at_us=int(summary.header.causal_cutoff_us),
                received_at_us=received_at,
                payload_hash=frame.summary_payload_hash,
                frame=frame,
            )
        )
        index += 1
    return index


def _latest_frame_or_unavailable(
    deliveries: list[SummaryDeliveryRecord],
    summaries: list[MeasurementSummary],
    adapter: ObservationAdapter,
    opportunity_us: int,
) -> ObservableFrame:
    arrived = tuple(item for item in deliveries if item.received_at_us <= opportunity_us)
    if arrived:
        latest = arrived[-1]
        summary = next(
            (item for item in summaries if item.header.sequence == latest.sequence),
            None,
        )
        if summary is None:
            raise RuntimeError("delivered summary is absent from the summary history")
        return adapter.build(summary, opportunity_us)
    if not summaries:
        # The 0-us summary is generated before any positive-time opportunity.
        raise RuntimeError("no causal measurement summary exists for the control opportunity")
    summary = summaries[0]
    received_at = int(summary.header.causal_cutoff_us) + MEASUREMENT_DELAY_US
    if received_at > opportunity_us:
        raise RuntimeError("no summary has arrived before the control opportunity")
    return adapter.build(summary, opportunity_us)


def _action_record(
    action: ControlAction, opportunity: ControlOpportunity, frame: ObservableFrame
) -> ActionRecord:
    return ActionRecord(
        opportunity_id=str(opportunity.opportunity_id),
        time_us=int(opportunity.time_us),
        kind=action.kind.value,
        target_rri_us=(None if action.target_rri_us is None else int(action.target_rri_us)),
        frame_hash=_frame_hash(frame),
        schema_version=ACTION_RECORD_SCHEMA_VERSION,
    )


def _frame_hash(frame: ObservableFrame) -> str:
    return canonical_sha256(frame, expected_schema_version=frame.schema_version)


def _reset_context(tape: DisturbanceTape) -> ControllerResetContext:
    return ControllerResetContext(
        schema_version=CONTROLLER_RESET_SCHEMA_VERSION,
        run_id=RunId(
            stable_event_id(
                None,
                "run",
                str(tape.root_case_id),
                str(tape.tape_id),
                0,
            )
        ),
        root_case_id=RootCaseId(str(tape.root_case_id)),
        config_hash=tape.config_hash,
    )


def _validate_raw(raw: RawRunTrace) -> LedgerSnapshot:
    if raw.schema_version != RAW_RUN_TRACE_SCHEMA_VERSION:
        raise ValueError("unsupported raw-run-trace schema")
    event_ids = tuple(str(item.event_id) for item in raw.measurement_deliveries)
    if len(set(event_ids)) != len(event_ids):
        raise ValueError("raw measurement-delivery IDs must be unique")
    if tuple(
        sorted(
            raw.measurement_deliveries,
            key=lambda item: (int(item.delivered_at_us), str(item.event_id)),
        )
    ) != raw.measurement_deliveries:
        raise ValueError("raw measurement deliveries must be in causal order")
    summary_times = tuple(int(item.header.causal_cutoff_us) for item in raw.summaries)
    if tuple(sorted(summary_times)) != summary_times or len(set(summary_times)) != len(
        summary_times
    ):
        raise ValueError("raw summaries must form a unique temporal prefix")
    start_sequence = int(raw.tape.simulation_start_us) // SUMMARY_PERIOD_US
    expected_summary_sequences = tuple(
        range(start_sequence, start_sequence + len(raw.summaries))
    )
    expected_summary_count = (
        int(raw.tape.simulation_end_us) - int(raw.tape.simulation_start_us) - 1
    ) // SUMMARY_PERIOD_US + 1
    if len(raw.summaries) != expected_summary_count:
        raise ValueError("raw summary history is not complete for the analysis window")
    if tuple(item.header.sequence for item in raw.summaries) != expected_summary_sequences:
        raise ValueError("raw summary sequences must be contiguous from the analysis start")
    if any(
        int(item.header.causal_cutoff_us) != sequence * SUMMARY_PERIOD_US
        for item, sequence in zip(raw.summaries, expected_summary_sequences, strict=True)
    ):
        raise ValueError("raw summaries must use the frozen summary lattice")
    if any(
        int(item.header.window_start_us)
        != max(
            int(raw.tape.simulation_start_us),
            int(item.header.causal_cutoff_us) - AGGREGATION_WINDOW_US,
        )
        for item in raw.summaries
    ):
        raise ValueError("raw summary windows must be clipped to the analysis start")
    if any(
        item.generated_at_us != int(item.frame.causal_cutoff_us)
        or item.generated_at_us != item.sequence * SUMMARY_PERIOD_US
        or item.received_at_us != item.generated_at_us + MEASUREMENT_DELAY_US
        or item.payload_hash != item.frame.summary_payload_hash
        or item.frame.source_sequence != item.sequence
        for item in raw.summary_deliveries
    ):
        raise ValueError("raw summary-delivery metadata is inconsistent")
    delivery_sequences = tuple(item.sequence for item in raw.summary_deliveries)
    expected_delivery_sequences = tuple(
        sequence
        for sequence in expected_summary_sequences
        if sequence * SUMMARY_PERIOD_US + MEASUREMENT_DELAY_US
        < int(raw.tape.simulation_end_us)
    )
    if delivery_sequences != expected_delivery_sequences:
        raise ValueError("raw summary-delivery history is not complete")
    if any(
        item.received_at_us >= int(raw.tape.simulation_end_us)
        for item in raw.summary_deliveries
    ):
        raise ValueError("raw summary delivery lies outside the analysis window")
    action_ids = tuple(item.opportunity_id for item in raw.actions)
    if len(set(action_ids)) != len(action_ids):
        raise ValueError("raw action opportunity IDs must be unique")
    if tuple(sorted(item.time_us for item in raw.actions)) != tuple(
        item.time_us for item in raw.actions
    ):
        raise ValueError("raw actions must be in temporal order")
    opportunity_ids = tuple(
        stable_event_id(
            None,
            "opportunity",
            item.vehicle_id,
            None,
            item.reservation_version,
        )
        for item in raw.plant_trace.truth_events
        if item.kind.value == "CONTROL_OPPORTUNITY"
    )
    if action_ids != opportunity_ids:
        raise ValueError("raw action history is not complete for plant opportunities")
    _validate_measurement_trace_consistency(raw)
    _validate_plant_replay(raw)
    replayed_ledger = ReceiverMeasurementLedger()
    for event in raw.measurement_deliveries:
        replayed_ledger.ingest_delivery(event)
    rebuilt_snapshot = replayed_ledger.snapshot()
    if rebuilt_snapshot != raw.ledger_snapshot:
        raise ValueError("raw measurement deliveries do not reproduce the ledger snapshot")
    return rebuilt_snapshot


def _validate_measurement_trace_consistency(raw: RawRunTrace) -> None:
    attempts = raw.plant_trace.tx_attempts
    attempts_by_id = {item.attempt_id: item for item in attempts}
    if len(attempts_by_id) != len(attempts):
        raise ValueError("raw plant trace contains duplicate TX attempt IDs")

    attempt_deliveries = tuple(
        item
        for item in raw.measurement_deliveries
        if item.attempt is not None
    )
    attempt_observations = tuple(item.attempt for item in attempt_deliveries)
    observed_attempts = {str(item.event_id): item for item in attempt_observations}
    if len(observed_attempts) != len(attempt_observations):
        raise ValueError("raw attempt deliveries contain duplicate attempt IDs")
    if set(observed_attempts) != set(attempts_by_id):
        raise ValueError("raw TX attempts and attempt deliveries must be one-to-one")
    ordinal_by_attempt_id: dict[str, int] = {}
    next_ordinal_by_vehicle: dict[str, int] = {}
    for attempt in attempts:
        ordinal = next_ordinal_by_vehicle.get(attempt.vehicle_id, 0)
        ordinal_by_attempt_id[attempt.attempt_id] = ordinal
        next_ordinal_by_vehicle[attempt.vehicle_id] = ordinal + 1

    for attempt_id, attempt in attempts_by_id.items():
        ordinal = ordinal_by_attempt_id[attempt_id]
        expected_attempt_id = stable_event_id(
            None,
            "attempt",
            attempt.vehicle_id,
            None,
            ordinal,
        )
        if attempt_id != expected_attempt_id:
            raise ValueError("raw TX attempt ID does not match its causal components")
        expected_draw = next(
            (
                item.uniform_u64
                for item in raw.tape.channel_draws
                if str(item.vehicle_id) == attempt.vehicle_id
                and item.ordinal == ordinal
            ),
            None,
        )
        if expected_draw is None or attempt.channel_uniform_u64 != expected_draw:
            raise ValueError("raw TX attempt channel draw does not match the tape")
        observation = observed_attempts[attempt_id]
        if (
            int(observation.observed_at_us) != attempt.time_us
            or str(observation.vehicle_id) != attempt.vehicle_id
            or bool(observation.decoded) != attempt.success
            or int(observation.busy_slot_us) != attempt.time_us
        ):
            raise ValueError("raw attempt delivery conflicts with its TX attempt")
        delivery = next(
            item
            for item in attempt_deliveries
            if item.attempt is not None and str(item.attempt.event_id) == attempt_id
        )
        expected_delivery_id = stable_event_id(
            attempt_id,
            "measurement_delivery",
            attempt.vehicle_id,
            "attempt",
            0,
        )
        if str(delivery.event_id) != expected_delivery_id:
            raise ValueError("raw attempt-delivery ID does not match its causal components")

    groups: dict[tuple[int, int], list] = {}
    for attempt in attempts:
        channel = attempt.logical_subchannel_id
        if (
            isinstance(channel, bool)
            or not isinstance(channel, int)
            or not 0 <= channel < raw.tape.logical_subchannel_count
        ):
            raise ValueError("raw TX attempt uses a channel outside the logical grid")
        if attempt.time_us % raw.tape.slot_duration_us:
            raise ValueError("raw TX attempt time is not aligned to the logical slot grid")
        groups.setdefault((attempt.time_us, channel), []).append(attempt)
    for group in groups.values():
        expected_collision = len(group) > 1
        expected_outcome = (
            TerminalOutcome.COLLISION
            if expected_collision
            else TerminalOutcome.RX_SUCCESS
        )
        if any(
            item.collided != expected_collision
            or item.success == expected_collision
            or item.outcome is not expected_outcome
            for item in group
        ):
            raise ValueError("raw TX terminal outcome conflicts with logical-grid collision physics")

    successful_attempts = {
        stable_event_id(
            item.attempt_id,
            "rx_success",
            item.vehicle_id,
            str(item.logical_subchannel_id),
            0,
        ): item
        for item in attempts
        if item.success
    }
    packet_deliveries = tuple(
        item
        for item in raw.measurement_deliveries
        if item.packet is not None
    )
    observed_packets = {
        str(item.packet.event_id): item
        for item in packet_deliveries
        if item.packet is not None
    }
    if len(observed_packets) != len(packet_deliveries):
        raise ValueError("raw packet deliveries contain duplicate successful observations")
    if set(observed_packets) != set(successful_attempts):
        raise ValueError("raw successful TX attempts and packet deliveries must be one-to-one")
    for packet_id, attempt in successful_attempts.items():
        delivery = observed_packets[packet_id]
        packet = delivery.packet
        assert packet is not None
        if (
            str(packet.vehicle_id) != attempt.vehicle_id
            or int(packet.observed_at_us) != attempt.time_us
            or int(packet.packet_generation_us) != attempt.packet_generation_us
        ):
            raise ValueError("raw packet observation conflicts with its successful TX attempt")
        expected_delivery_id = stable_event_id(
            packet_id,
            "measurement_delivery",
            attempt.vehicle_id,
            "packet",
            0,
        )
        if str(delivery.event_id) != expected_delivery_id:
            raise ValueError("raw packet-delivery ID does not match its causal components")


def _validate_plant_replay(raw: RawRunTrace) -> None:
    """Rebuild the physical run so resealed but impossible traces fail closed."""

    plant = DiscreteEventSPSPlant()
    plant.reset(raw.tape)
    action_index = 0
    simulation_end_us = int(raw.tape.simulation_end_us)
    while plant.snapshot().time_us < simulation_end_us:
        previous_time_us = plant.snapshot().time_us
        result = plant.advance_until(simulation_end_us)
        if result.opportunities:
            if len(result.opportunities) != 1 or action_index >= len(raw.actions):
                raise ValueError("raw actions do not replay the physical control opportunities")
            opportunity = result.opportunities[0]
            record = raw.actions[action_index]
            if (
                record.opportunity_id != str(opportunity.opportunity_id)
                or record.time_us != int(opportunity.time_us)
            ):
                raise ValueError("raw action does not match the replayed control opportunity")
            plant.apply(
                opportunity,
                ControlAction(
                    schema_version=ACTION_SCHEMA_VERSION,
                    opportunity_id=opportunity.opportunity_id,
                    kind=ActionKind(record.kind),
                    target_rri_us=record.target_rri_us,
                ),
            )
            action_index += 1
            continue
        if result.snapshot.time_us < simulation_end_us:
            if result.snapshot.time_us <= previous_time_us:
                raise ValueError("physical plant replay made no forward progress")
            continue
        break
    snapshot = plant.snapshot()
    if action_index != len(raw.actions):
        raise ValueError("raw action history contains actions absent from physical replay")
    if snapshot.trace != raw.plant_trace:
        raise ValueError("raw plant trace does not reproduce the physical plant replay")
    if snapshot.measurement_deliveries != raw.measurement_deliveries:
        raise ValueError("raw measurement history does not reproduce the physical plant replay")
