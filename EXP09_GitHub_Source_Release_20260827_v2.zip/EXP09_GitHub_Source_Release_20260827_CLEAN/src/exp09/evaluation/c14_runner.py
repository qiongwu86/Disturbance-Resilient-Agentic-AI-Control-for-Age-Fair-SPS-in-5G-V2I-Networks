"""Fail-closed orchestration boundary for the frozen C14.1 topology."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
from threading import Event, RLock
import time
from uuid import uuid4

from exp09.contracts.tape import TapeArm

from .c14_controllers import C14ControllerFactory
from .c14_cas_writer import prepare_c14_cas_run, publish_prepared_c14_cas_run
from .c14_ledger import C14BudgetUsage, C14LedgerRow, C14RunLedger
from .c14_network_guard import NoNetworkGuard
from .c14_request_adapters import build_request_aware_controller
from .c14_topology import C14MethodCase, C14MethodCaseTopology
from .disturbance_tape import build_primary_influx_tape
from .runner import run_case


class C14ExecutionBlocked(PermissionError):
    """Raised before a real C14.1 case when the execution gate is not enabled."""


FORMAL_CHECKPOINT_SCHEMA_VERSION = "exp09-c14-1-formal-checkpoint-v1"
CHECKPOINT_WRITE_ATTEMPTS = 20
CHECKPOINT_WRITE_BASE_DELAY_SECONDS = 0.025


@dataclass(frozen=True, slots=True)
class C14ExecutionContext:
    execution_authorized: bool
    cache_qualified: bool
    training_capability: str
    api_allowed: bool
    provider_calls_allowed: bool
    llm_calls_allowed: bool
    shadow_allowed: bool
    precision_allowed: bool
    locked_test_allowed: bool

    @classmethod
    def preflight_only(cls) -> C14ExecutionContext:
        return cls(
            execution_authorized=False,
            cache_qualified=False,
            training_capability="DISABLED",
            api_allowed=False,
            provider_calls_allowed=False,
            llm_calls_allowed=False,
            shadow_allowed=False,
            precision_allowed=False,
            locked_test_allowed=False,
        )

    def require_real_execution(self) -> None:
        if self.training_capability != "DISABLED":
            raise C14ExecutionBlocked("C14.1 requires training capability to remain disabled")
        forbidden = (
            self.api_allowed,
            self.provider_calls_allowed,
            self.llm_calls_allowed,
            self.shadow_allowed,
            self.precision_allowed,
            self.locked_test_allowed,
        )
        if any(forbidden):
            raise C14ExecutionBlocked("C14.1 context enables a forbidden external or later stage")
        if not self.cache_qualified:
            raise C14ExecutionBlocked("C14.1 offline caches are not qualified")
        if not self.execution_authorized:
            raise C14ExecutionBlocked("C14.1 method-case execution is not authorized")


class C14UnifiedRunner:
    """Execute one frozen method case only after all external gates are explicit."""

    def __init__(
        self,
        project_root: Path,
        topology: C14MethodCaseTopology,
        ledger: C14RunLedger,
        controller_factory: C14ControllerFactory,
        *,
        output_root: Path,
        ledger_path: Path,
        stop_event: Event | None = None,
    ) -> None:
        self.project_root = project_root.resolve()
        self.topology = topology
        self.ledger = ledger
        self.controller_factory = controller_factory
        self.output_root = output_root
        self.runs_root = output_root
        self.cas_root = output_root.parent / "cas"
        self.ledger_path = ledger_path
        self.checkpoint_root = ledger_path.parent / "checkpoint_journals"
        self.stop_event = stop_event
        self._artifact_lock = RLock()

    def execute_case(
        self,
        case_id: str,
        *,
        context: C14ExecutionContext,
        full_cache=None,
        plain_cache=None,
        full_materializer=None,
        plain_materializer=None,
        started_at: str,
        ended_at: str,
    ):
        del ended_at
        context.require_real_execution()
        case = self.topology.by_case_id.get(case_id)
        if case is None:
            raise C14ExecutionBlocked("case_id is not in the frozen C14.1 topology")
        if self.stop_event is not None and self.stop_event.is_set():
            raise C14ExecutionBlocked("parallel C14.1 stopped after a peer failure")
        with self._artifact_lock:
            row = self.ledger.start_job(case_id, started_at=started_at)
            try:
                self.ledger.write(self.ledger_path, execution_authorized=False)
            except BaseException as exc:
                self.ledger.abort_job(
                    row.run_id,
                    ended_at=_timestamp(),
                    error_code=type(exc).__name__,
                    abort_reason=str(exc),
                    failed=True,
                )
                self.ledger.write(self.ledger_path, execution_authorized=False)
                raise
        meter = None
        terminal_recorded = False
        wall_started = time.monotonic()
        cpu_started = _cpu_time()
        try:
            with NoNetworkGuard():
                controller = self._controller_for(
                    case,
                    full_cache=full_cache,
                    plain_cache=plain_cache,
                    full_materializer=full_materializer,
                    plain_materializer=plain_materializer,
                )
                meter = _MeteredController(
                    controller,
                    transitions_per_opportunity=case.transitions_per_opportunity,
                    accountant=self.ledger.accountant,
                    checkpoint=lambda delta: self._checkpoint(row.run_id, delta),
                    stop_event=self.stop_event,
                )
                tape = build_primary_influx_tape(case.root_case_id, TapeArm(case.arm))
                result = run_case(tape, controller=meter)
            prepared = prepare_c14_cas_run(
                result,
                self._output_root_for_case(case_id),
                runs_root=self.runs_root,
                cas_root=self.cas_root,
            )
            with self._artifact_lock:
                cpu_core_seconds = math.ceil(_cpu_time() - cpu_started)
                wall_seconds = math.ceil(time.monotonic() - wall_started)
                published_storage_bytes = 0
                try:
                    artifact = publish_prepared_c14_cas_run(
                        prepared,
                        runs_root=self.runs_root,
                        cas_root=self.cas_root,
                        expected_existing_storage_bytes=(
                            self.ledger.accountant.usage.storage_bytes
                        ),
                        ensure_storage_budget=lambda size: (
                            self.ledger.accountant.ensure_can_charge(
                                C14BudgetUsage(
                                    cpu_core_seconds=cpu_core_seconds,
                                    wall_seconds=wall_seconds,
                                    storage_bytes=size,
                                )
                            )
                        ),
                    )
                    published_storage_bytes = artifact.storage_bytes_added
                    usage = C14BudgetUsage(
                        cpu_core_seconds=cpu_core_seconds,
                        wall_seconds=wall_seconds,
                        storage_bytes=artifact.storage_bytes_added,
                    )
                    self.ledger.pass_job(
                        row.run_id,
                        ended_at=_timestamp(),
                        artifact_sha256=_directory_sha256(artifact.path),
                        usage=usage,
                    )
                    self.ledger.write(
                        self.ledger_path, execution_authorized=False
                    )
                except Exception as exc:
                    usage = C14BudgetUsage(
                        cpu_core_seconds=cpu_core_seconds,
                        wall_seconds=wall_seconds,
                        storage_bytes=max(
                            published_storage_bytes,
                            int(getattr(exc, "storage_bytes_added", 0)),
                        ),
                    )
                    self.ledger.abort_job(
                        row.run_id,
                        ended_at=_timestamp(),
                        error_code=type(exc).__name__,
                        abort_reason=str(exc),
                        failed=True,
                        usage=usage,
                    )
                    self.ledger.write(
                        self.ledger_path, execution_authorized=False
                    )
                    terminal_recorded = True
                    raise
            terminal_recorded = True
            return artifact
        except Exception as exc:
            usage = (
                C14BudgetUsage()
                if meter is None
                else C14BudgetUsage(
                    cpu_core_seconds=math.ceil(_cpu_time() - cpu_started),
                    wall_seconds=math.ceil(time.monotonic() - wall_started),
                    storage_bytes=max(
                        0, int(getattr(exc, "storage_bytes_added", 0))
                    ),
                )
            )
            if not terminal_recorded:
                with self._artifact_lock:
                    self.ledger.abort_job(
                        row.run_id,
                        ended_at=_timestamp(),
                        error_code=type(exc).__name__,
                        abort_reason=str(exc),
                        failed=True,
                        usage=usage,
                    )
                    self.ledger.write(
                        self.ledger_path, execution_authorized=False
                    )
                terminal_recorded = True
            raise

    def _output_root_for_case(self, case_id: str) -> Path:
        del case_id
        return self.output_root

    def _controller_for(
        self,
        case: C14MethodCase,
        *,
        full_cache,
        plain_cache,
        full_materializer,
        plain_materializer,
    ):
        if case.train_seed is None:
            if case.method_id == "Full":
                if full_cache is None or full_materializer is None:
                    raise C14ExecutionBlocked(
                        "Full requires qualified cache and request materializer"
                    )
                return build_request_aware_controller(
                    self.controller_factory,
                    "Full",
                    cache=full_cache,
                    materializer=full_materializer,
                )
            if case.method_id == "Plain_LLM":
                if plain_cache is None or plain_materializer is None:
                    raise C14ExecutionBlocked(
                        "Plain_LLM requires qualified cache and request materializer"
                    )
                return build_request_aware_controller(
                    self.controller_factory,
                    "Plain_LLM",
                    cache=plain_cache,
                    materializer=plain_materializer,
                )
            return self.controller_factory.build_non_rl(
                case.method_id,
                full_cache=full_cache,
                plain_cache=plain_cache,
            )
        mapping_entry = {
            "method_id": case.method_id,
            "train_seed": case.train_seed,
            "scenario": "complex",
            "arms": ["REFERENCE", "EVENT"],
            "relative_path": case.checkpoint_locator,
            "sha256": case.checkpoint_sha256,
        }
        # Episode identity is checked by the factory and therefore must come from the frozen registry.
        registry = json.loads(
            (
                self.project_root
                / "protocol/c14/c14_1_complex_checkpoint_registry.FROZEN_20260728.json"
            ).read_text(encoding="utf-8")
        )
        matched = [
            entry
            for entry in registry["entries"]
            if entry["method_id"] == case.method_id
            and entry["train_seed"] == case.train_seed
        ]
        if len(matched) != 1 or any(
            matched[0].get(field) != value
            for field, value in mapping_entry.items()
            if field in matched[0]
        ):
            raise C14ExecutionBlocked("frozen RL registry no longer matches the topology")
        return self.controller_factory.build_rl(case.method_id, case.train_seed, matched[0])

    def _checkpoint(self, run_id: str, delta: C14BudgetUsage) -> None:
        row = self.ledger.checkpoint_running(run_id, delta)
        _write_checkpoint_journal(self.checkpoint_root, row)


class _MeteredController:
    def __init__(
        self,
        controller,
        *,
        transitions_per_opportunity: int,
        accountant,
        checkpoint=None,
        stop_event: Event | None = None,
    ) -> None:
        self._controller = controller
        self._transitions_per_opportunity = transitions_per_opportunity
        self._accountant = accountant
        self._checkpoint = checkpoint
        self._stop_event = stop_event
        self._environment_steps = 0
        self._model_transitions = 0

    def reset(self, context) -> None:
        self._controller.reset(context)

    def decide(self, frame, opportunity):
        if self._stop_event is not None and self._stop_event.is_set():
            raise C14ExecutionBlocked("parallel C14.1 stopped after a peer failure")
        delta = C14BudgetUsage(
            environment_steps=1,
            model_transitions=self._transitions_per_opportunity,
        )
        if self._checkpoint is None:
            self._accountant.ensure_can_charge(delta)
        else:
            self._checkpoint(delta)
        self._environment_steps += 1
        self._model_transitions += self._transitions_per_opportunity
        return self._controller.decide(frame, opportunity)

    def usage(
        self,
        *,
        method_cases: int,
        cpu_core_seconds: int,
        wall_seconds: int,
        storage_bytes: int = 0,
    ) -> C14BudgetUsage:
        return C14BudgetUsage(
            method_cases=method_cases,
            environment_steps=self._environment_steps,
            model_transitions=self._model_transitions,
            cpu_core_seconds=cpu_core_seconds,
            wall_seconds=wall_seconds,
            storage_bytes=storage_bytes,
        )


def _directory_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    for file_path in sorted(item for item in path.rglob("*") if item.is_file()):
        digest.update(file_path.relative_to(path).as_posix().encode("utf-8"))
        digest.update(b"\0")
        digest.update(file_path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest().upper()


def _timestamp() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="microseconds")


def _cpu_time() -> float:
    return time.thread_time() if hasattr(time, "thread_time") else time.process_time()


def recover_running_checkpoint(
    ledger: C14RunLedger, checkpoint_root: Path, run_id: str
) -> None:
    """Replay a persisted per-step prefix not yet represented in the main ledger."""

    path = Path(checkpoint_root) / f"{run_id}.json"
    if not path.exists():
        return
    document = json.loads(path.read_text(encoding="utf-8"))
    checkpoint = document.get("checkpoint")
    if (
        document.get("schema_version") != FORMAL_CHECKPOINT_SCHEMA_VERSION
        or not isinstance(checkpoint, dict)
        or document.get("checkpoint_sha256") != _canonical_sha(checkpoint)
        or checkpoint.get("run_id") != run_id
    ):
        raise ValueError("formal checkpoint journal integrity mismatch")
    current = next((row for row in ledger.rows if row.run_id == run_id), None)
    if current is None or current.status != "RUNNING":
        raise ValueError("formal checkpoint journal is not bound to a running row")
    if (
        checkpoint.get("case_id") != current.case_id
        or checkpoint.get("attempt_ordinal") != current.attempt_ordinal
        or checkpoint.get("api_calls") != 0
        or checkpoint.get("provider_calls") != 0
        or checkpoint.get("llm_tokens") != 0
    ):
        raise ValueError("formal checkpoint journal binding mismatch")
    environment_steps = checkpoint.get("environment_steps")
    model_transitions = checkpoint.get("model_transitions")
    if (
        type(environment_steps) is not int
        or type(model_transitions) is not int
        or environment_steps < current.environment_steps
        or model_transitions < current.model_transitions
    ):
        raise ValueError("formal checkpoint journal regressed budget usage")
    delta = C14BudgetUsage(
        environment_steps=environment_steps - current.environment_steps,
        model_transitions=model_transitions - current.model_transitions,
    )
    if delta.environment_steps or delta.model_transitions:
        ledger.checkpoint_running(run_id, delta)


def _write_checkpoint_journal(root: Path, row: C14LedgerRow) -> None:
    checkpoint = {
        "run_id": row.run_id,
        "case_id": row.case_id,
        "attempt_ordinal": row.attempt_ordinal,
        "environment_steps": row.environment_steps,
        "model_transitions": row.model_transitions,
        "api_calls": row.api_calls,
        "provider_calls": row.provider_calls,
        "llm_tokens": row.llm_tokens,
    }
    payload = json.dumps(
        {
            "schema_version": FORMAL_CHECKPOINT_SCHEMA_VERSION,
            "checkpoint_sha256": _canonical_sha(checkpoint),
            "checkpoint": checkpoint,
        },
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    root.mkdir(parents=True, exist_ok=True)
    path = root / f"{row.run_id}.json"
    for attempt in range(CHECKPOINT_WRITE_ATTEMPTS):
        temporary = path.with_name(f"{path.name}.tmp-{uuid4().hex}")
        try:
            with temporary.open("xb") as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
            return
        except PermissionError:
            if attempt + 1 == CHECKPOINT_WRITE_ATTEMPTS:
                raise
            time.sleep(CHECKPOINT_WRITE_BASE_DELAY_SECONDS * (attempt + 1))
        finally:
            temporary.unlink(missing_ok=True)
    raise AssertionError("formal checkpoint write retry loop exited unexpectedly")


def _canonical_sha(value) -> str:
    return hashlib.sha256(
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    ).hexdigest().upper()
