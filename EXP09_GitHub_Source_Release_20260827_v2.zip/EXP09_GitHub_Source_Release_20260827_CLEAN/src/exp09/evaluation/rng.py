"""Deterministic typed-key pseudo-random draws without global RNG state."""

from typing import Any

from exp09.contracts.determinism import stable_digest_hex, stable_event_id



class KeyedRng:
    def __init__(self, *root_parts: Any) -> None:
        if not root_parts:
            raise ValueError("root_parts must not be empty")
        self._root_parts = root_parts

    def draw_uint(self, namespace: str, index: int, modulo: int) -> int:
        if not namespace:
            raise ValueError("namespace must not be empty")
        if index < 0:
            raise ValueError("index must be non-negative")
        if modulo <= 0:
            raise ValueError("modulo must be positive")
        digest = stable_digest_hex(*self._root_parts, namespace, index)
        return int(digest[:16], 16) % modulo

    def choice(self, namespace: str, index: int, values: tuple[int, ...]) -> int:
        if not values:
            raise ValueError("values must not be empty")
        return values[self.draw_uint(namespace, index, len(values))]

__all__ = ["KeyedRng", "stable_digest_hex", "stable_event_id"]
