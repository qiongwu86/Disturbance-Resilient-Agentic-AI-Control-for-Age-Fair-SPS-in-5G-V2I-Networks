"""Frozen C14.1 method-case topology construction and validation."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
from typing import Any

from exp09.contracts.ids import require_identifier, require_sha256

from .c14_controllers import METHODS, RL_METHODS

TOPOLOGY_SCHEMA_VERSION = "exp09-c14-1-method-case-topology-v1"
PROTOCOL_GENERATION = "EXP09_G0_AD12A_20260726_V2"
ROOT_NAMESPACE = "exp09-c14-1-design-root-v1"
ARMS = ("REFERENCE", "EVENT")
SCENARIO_BY_ARM = {"REFERENCE": "nominal_fixed", "EVENT": "influx_event"}
RL_SEEDS = (101, 202, 303, 404, 505)
MODEL_TRANSITION_METHODS = frozenset(
    {
        "Full",
        "RMPC_SameEvaluator",
        "Rule_SameStack",
        "TunedNonLLM_SameStack",
        "Greedy_1",
        "Nominal_MPC",
    }
)
TRANSITIONS_PER_MODEL_DECISION = 72_000


class C14TopologyError(ValueError):
    """Raised when the frozen C14.1 topology is incomplete or has drifted."""


@dataclass(frozen=True, slots=True)
class C14MethodCase:
    ordinal: int
    case_id: str
    root_case_id: str
    root_namespace: str
    arm: str
    scenario: str
    method_id: str
    variant_id: str
    train_seed: int | None
    checkpoint_sha256: str | None
    checkpoint_locator: str | None
    transitions_per_opportunity: int

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> C14MethodCase:
        expected = {
            "ordinal",
            "case_id",
            "root_case_id",
            "root_namespace",
            "arm",
            "scenario",
            "method_id",
            "variant_id",
            "train_seed",
            "checkpoint_sha256",
            "checkpoint_locator",
            "transitions_per_opportunity",
        }
        if set(value) != expected:
            raise C14TopologyError("method-case fields do not match the frozen schema")
        case = cls(**value)
        case.validate()
        return case

    def validate(self) -> None:
        if isinstance(self.ordinal, bool) or not isinstance(self.ordinal, int) or self.ordinal < 0:
            raise C14TopologyError("method-case ordinal must be a non-negative integer")
        for field_name in ("case_id", "root_case_id", "root_namespace", "variant_id"):
            require_identifier(getattr(self, field_name), field_name)
        if self.root_namespace != ROOT_NAMESPACE:
            raise C14TopologyError("method-case root namespace mismatch")
        if self.arm not in ARMS or self.scenario != SCENARIO_BY_ARM.get(self.arm):
            raise C14TopologyError("method-case arm/scenario binding mismatch")
        if self.method_id not in METHODS:
            raise C14TopologyError("method-case contains an unknown method")
        expected_transitions = (
            TRANSITIONS_PER_MODEL_DECISION if self.method_id in MODEL_TRANSITION_METHODS else 0
        )
        if self.transitions_per_opportunity != expected_transitions:
            raise C14TopologyError("method-case model-transition charge mismatch")
        if self.method_id in RL_METHODS:
            if self.train_seed not in RL_SEEDS:
                raise C14TopologyError("RL method-case train seed mismatch")
            if self.variant_id != f"complex_seed{self.train_seed}":
                raise C14TopologyError("RL method-case variant mismatch")
            if not isinstance(self.checkpoint_locator, str):
                raise C14TopologyError("RL method-case checkpoint locator is missing")
            require_sha256(self.checkpoint_sha256, "checkpoint_sha256")
        elif any(
            value is not None
            for value in (self.train_seed, self.checkpoint_sha256, self.checkpoint_locator)
        ):
            raise C14TopologyError("non-RL method-case cannot bind an RL checkpoint")


@dataclass(frozen=True, slots=True)
class C14MethodCaseTopology:
    source_path: Path
    method_config_locator: str
    method_config_sha256: str
    entries_sha256: str
    cases: tuple[C14MethodCase, ...]

    @property
    def by_case_id(self) -> dict[str, C14MethodCase]:
        return {case.case_id: case for case in self.cases}


def build_method_cases(
    roots: tuple[str, ...],
    checkpoint_entries: tuple[dict[str, Any], ...],
) -> tuple[C14MethodCase, ...]:
    """Expand the frozen 48-root design into exactly 2,304 method cases."""

    if len(roots) != 48 or len(set(roots)) != 48:
        raise C14TopologyError("C14.1 requires exactly 48 unique roots")
    checkpoint_by_identity: dict[tuple[str, int], dict[str, Any]] = {}
    for entry in checkpoint_entries:
        identity = (entry.get("method_id"), entry.get("train_seed"))
        if identity in checkpoint_by_identity:
            raise C14TopologyError("duplicate RL checkpoint identity")
        if entry.get("scenario") != "complex" or entry.get("arms") != list(ARMS):
            raise C14TopologyError("RL checkpoint mapping is not complex-only and arm-independent")
        checkpoint_by_identity[identity] = entry
    expected_identities = {(method, seed) for method in RL_METHODS for seed in RL_SEEDS}
    if set(checkpoint_by_identity) != expected_identities:
        raise C14TopologyError("RL checkpoint mapping does not contain exactly 15 identities")

    cases: list[C14MethodCase] = []
    for root in roots:
        require_identifier(root, "root_case_id")
        for arm in ARMS:
            for method_id in METHODS:
                variants = RL_SEEDS if method_id in RL_METHODS else (None,)
                for train_seed in variants:
                    checkpoint = (
                        checkpoint_by_identity[(method_id, train_seed)]
                        if train_seed is not None
                        else None
                    )
                    variant_id = (
                        f"complex_seed{train_seed}" if train_seed is not None else "fixed"
                    )
                    case_id = f"{root}__{arm}__{method_id}__{variant_id}"
                    case = C14MethodCase(
                        ordinal=len(cases),
                        case_id=case_id,
                        root_case_id=root,
                        root_namespace=ROOT_NAMESPACE,
                        arm=arm,
                        scenario=SCENARIO_BY_ARM[arm],
                        method_id=method_id,
                        variant_id=variant_id,
                        train_seed=train_seed,
                        checkpoint_sha256=(None if checkpoint is None else checkpoint["sha256"]),
                        checkpoint_locator=(
                            None if checkpoint is None else checkpoint["relative_path"]
                        ),
                        transitions_per_opportunity=(
                            TRANSITIONS_PER_MODEL_DECISION
                            if method_id in MODEL_TRANSITION_METHODS
                            else 0
                        ),
                    )
                    case.validate()
                    cases.append(case)
    _validate_expanded_cases(tuple(cases))
    return tuple(cases)


def load_frozen_topology(project_root: Path, locator: str) -> C14MethodCaseTopology:
    root = project_root.resolve()
    path = _resolve_project_file(root, locator)
    value = _strict_json(path)
    expected_fields = {
        "schema_version",
        "artifact_status",
        "execution_authorized",
        "protocol_generation",
        "root_namespace",
        "root_count",
        "arms",
        "methods",
        "rl_train_seeds",
        "method_case_count",
        "non_rl_method_case_count",
        "rl_method_case_count",
        "model_transition_methods",
        "transitions_per_model_decision",
        "method_config_binding",
        "design_roots_binding",
        "checkpoint_registry_binding",
        "expansion_order",
        "entries_sha256",
    }
    if not isinstance(value, dict) or set(value) != expected_fields:
        raise C14TopologyError("topology document fields do not match the frozen schema")
    if value["schema_version"] != TOPOLOGY_SCHEMA_VERSION:
        raise C14TopologyError("unsupported C14.1 topology schema")
    if value["artifact_status"] != "FROZEN_TOPOLOGY_EXECUTION_NOT_AUTHORIZED":
        raise C14TopologyError("topology artifact status mismatch")
    if value["execution_authorized"] is not False:
        raise C14TopologyError("topology document cannot authorize execution")
    if value["protocol_generation"] != PROTOCOL_GENERATION:
        raise C14TopologyError("topology protocol generation mismatch")
    if value["root_namespace"] != ROOT_NAMESPACE:
        raise C14TopologyError("topology root namespace mismatch")
    if value["arms"] != list(ARMS) or value["methods"] != list(METHODS):
        raise C14TopologyError("topology arm or method ordering mismatch")
    if value["rl_train_seeds"] != list(RL_SEEDS):
        raise C14TopologyError("topology RL seed ordering mismatch")
    if value["model_transition_methods"] != sorted(MODEL_TRANSITION_METHODS):
        raise C14TopologyError("topology model-transition method set mismatch")
    if value["transitions_per_model_decision"] != TRANSITIONS_PER_MODEL_DECISION:
        raise C14TopologyError("topology transition charge mismatch")
    binding = value["method_config_binding"]
    if not isinstance(binding, dict) or set(binding) != {"locator", "sha256"}:
        raise C14TopologyError("topology method-config binding is malformed")
    require_sha256(binding["sha256"], "method_config_sha256")
    config_path = _resolve_project_file(root, binding["locator"])
    if _sha256(config_path) != binding["sha256"]:
        raise C14TopologyError("topology method-config binding mismatch")
    if value["expansion_order"] != [
        "root_order",
        "arm_order",
        "method_order",
        "rl_seed_order_or_fixed",
    ]:
        raise C14TopologyError("topology expansion order mismatch")
    roots_document = _load_bound_json(root, value["design_roots_binding"])
    checkpoints_document = _load_bound_json(root, value["checkpoint_registry_binding"])
    cases = build_method_cases(
        tuple(roots_document.get("roots", ())),
        tuple(checkpoints_document.get("entries", ())),
    )
    raw_entries = [asdict(case) for case in cases]
    entries_sha256 = _canonical_sha256(raw_entries)
    if entries_sha256 != value["entries_sha256"]:
        raise C14TopologyError("topology entries SHA-256 mismatch")
    counts = (
        value["root_count"],
        value["method_case_count"],
        value["non_rl_method_case_count"],
        value["rl_method_case_count"],
    )
    if counts != (48, 2304, 864, 1440):
        raise C14TopologyError("topology summary counts mismatch")
    return C14MethodCaseTopology(
        source_path=path,
        method_config_locator=binding["locator"],
        method_config_sha256=binding["sha256"],
        entries_sha256=entries_sha256,
        cases=cases,
    )


def _validate_expanded_cases(cases: tuple[C14MethodCase, ...]) -> None:
    if len(cases) != 2304:
        raise C14TopologyError("expanded C14.1 topology must contain 2,304 cases")
    if tuple(case.ordinal for case in cases) != tuple(range(2304)):
        raise C14TopologyError("method-case ordinals are not contiguous")
    if len({case.case_id for case in cases}) != 2304:
        raise C14TopologyError("method-case identifiers are not unique")
    non_rl = sum(case.method_id not in RL_METHODS for case in cases)
    rl = sum(case.method_id in RL_METHODS for case in cases)
    if (non_rl, rl) != (864, 1440):
        raise C14TopologyError("non-RL/RL method-case counts mismatch")
    paired: dict[tuple[str, str, str], dict[str, str | None]] = {}
    for case in cases:
        key = (case.root_case_id, case.method_id, case.variant_id)
        arms = paired.setdefault(key, {})
        if case.arm in arms:
            raise C14TopologyError("duplicate arm in a paired method-case identity")
        arms[case.arm] = case.checkpoint_sha256
    if any(set(arms) != set(ARMS) or len(set(arms.values())) != 1 for arms in paired.values()):
        raise C14TopologyError("paired arms do not share one method/checkpoint identity")


def _load_bound_json(root: Path, binding: Any) -> dict[str, Any]:
    if not isinstance(binding, dict) or set(binding) != {"locator", "sha256"}:
        raise C14TopologyError("topology source binding is malformed")
    require_sha256(binding["sha256"], "source_binding_sha256")
    path = _resolve_project_file(root, binding["locator"])
    if _sha256(path) != binding["sha256"]:
        raise C14TopologyError(f"topology source binding mismatch: {binding['locator']}")
    value = _strict_json(path)
    if not isinstance(value, dict):
        raise C14TopologyError("topology bound source must be a JSON object")
    return value


def _resolve_project_file(root: Path, locator: str) -> Path:
    if not isinstance(locator, str) or not locator or "\\" in locator:
        raise C14TopologyError("topology locator must be a POSIX relative path")
    path = (root / locator).resolve()
    try:
        path.relative_to(root)
    except ValueError as exc:
        raise C14TopologyError("topology locator escapes the project root") from exc
    if not path.is_file():
        raise C14TopologyError(f"topology artifact is missing: {locator}")
    return path


def _strict_json(path: Path) -> Any:
    def reject_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise C14TopologyError(f"duplicate JSON key is forbidden: {key}")
            result[key] = value
        return result

    try:
        return json.loads(
            path.read_text(encoding="utf-8"),
            object_pairs_hook=reject_duplicates,
            parse_constant=lambda value: (_ for _ in ()).throw(
                C14TopologyError(f"non-finite JSON value is forbidden: {value}")
            ),
        )
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise C14TopologyError("topology is not strict UTF-8 JSON") from exc


def _canonical_sha256(value: Any) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest().upper()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()
