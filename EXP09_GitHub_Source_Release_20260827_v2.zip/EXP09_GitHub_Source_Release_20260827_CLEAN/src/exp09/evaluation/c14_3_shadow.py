"""Append-only C14.3 cache remediation and offline shadow execution."""

from __future__ import annotations

from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from contextlib import contextmanager
from dataclasses import asdict, dataclass, replace
from datetime import datetime, timezone
import gzip
import hashlib
from http.client import RemoteDisconnected
import json
import math
import os
from pathlib import Path
import socket
from threading import Event, RLock
import time
from typing import Any, Iterator
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import HTTPRedirectHandler, HTTPSHandler, ProxyHandler, Request, build_opener
from uuid import uuid4

from exp09.contracts.supervisor import (
    PROGRAM_PROPOSAL_SCHEMA_VERSION,
    ProgramProposal,
    RationaleCode,
    TransitionId,
)
from exp09.contracts.ids import ProgramId
from exp09.contracts.tape import TapeArm
from exp09.measurement.receiver_ledger import MEASUREMENT_DELAY_US, SUMMARY_PERIOD_US
from exp09.supervisor.providers import provider_response_hash

from .c14_controllers import C14ControllerFactory
from .c14_network_guard import NoNetworkGuard
from .c14_protocol_generation import (
    CorrectedFullController,
    ProtocolGenerationRequestMaterializer,
    build_protocol_generation_controller,
)
from .c14_topology import C14MethodCase
from .c14_v2_closure import (
    FULL_TAPE_MAX_CONTROL_OPPORTUNITIES_PER_CASE,
    INPUT_TOKEN_CAP,
    OUTPUT_TOKEN_CAP,
    ProviderCredentials,
    ProviderResult,
    ProviderUsage,
    V3RequestMaterializer,
    _DecisionMeter,
    _FormalOnlyProviderSession,
    _phase_a_row_is_complete,
    audit_provider_response,
    build_provider_request_body,
    load_provider_credentials,
    run_causal_case_without_statistics,
)
from .disturbance_tape import build_primary_influx_tape
from .runner import RunResult, run_case


PROTOCOL_GENERATION = "EXP09_C14_3_SHADOW_REMEDIATION_20260801_ATTEMPT0002"
ROOT_NAMESPACE = "exp09-c14-3-shadow-root-v1"
ROOT_ID_PREFIX = "c14_3_shadow_"
METHODS = (
    "Full",
    "RMPC_SameEvaluator",
    "Rule_SameStack",
    "TunedNonLLM_SameStack",
    "Plain_LLM",
    "DQN",
    "GNN_DDQN",
    "AoI_aware_heuristic",
    "Greedy_1",
    "Nominal_MPC",
)
LLM_METHODS = ("Full", "Plain_LLM")
SAME_STACK_METHODS = ("Full", "Rule_SameStack", "TunedNonLLM_SameStack")
ARMS = ("REFERENCE", "EVENT")
RL_METHODS = frozenset({"DQN", "GNN_DDQN"})
RL_SEEDS = (101, 202, 303, 404, 505)
MODEL_TRANSITION_METHODS = frozenset(
    {
        "Full",
        "RMPC_SameEvaluator",
        "Rule_SameStack",
        "TunedNonLLM_SameStack",
        "Greedy_1",
        "Nominal_MPC",
    }
)
TRANSITIONS_PER_MODEL_DECISION = 72_000
CASE_COUNT = 2_304
FRONTIER_CASE_COUNT = 256
PROVIDER_CONFIG_LOCATOR = "protocol/c14/provider_config.C14_3_CACHE_REMEDIATION_20260801.json"
METHOD_CONFIG_LOCATOR = "protocol/c14/method_config.C14_3_CACHE_REMEDIATION_20260801.json"
PROFILE_PROTOCOL_LOCATOR = "protocol/c14/c14_3_profile_injection_protocol.FROZEN_20260801.json"
CONTROLLER_CONFIG_LOCATOR = "protocol/c14/c14_1_method_configs.FROZEN_REMEDIATION_20260728.json"
CHECKPOINT_REGISTRY_LOCATOR = "protocol/c14/c14_1_complex_checkpoint_registry.FROZEN_20260728.json"
PROFILE_CLOSEOUT_LOCATOR = (
    "artifacts/c14_2_provider_profiling_20260801_closeout_attempt0001/c14_2_closeout.json"
)
CACHE_OUTPUT_LOCATOR = "artifacts/c14_3_cache_remediation_20260802_attempt0004"
SHADOW_OUTPUT_LOCATOR = "artifacts/c14_3_shadow_20260802_attempt0004"
MANIFEST_LOCATOR = "protocol/c14/c14_3_shadow_manifest.FROZEN_REMEDIATION_20260802_attempt0004.json"
PRIOR_CACHE_OUTPUT_LOCATOR = "artifacts/c14_3_cache_remediation_20260801_attempt0003"
PRIOR_STDERR_LOCATOR = "artifacts/c14_3_cache_remediation_attempt0003.stderr.log"
RECOVERY_REQUEST_HASH = "7603BE4FECE89FE962A7D168ECB66930CEBABE9491C0C1D8ABD82688DEC2EFF3"
RECOVERY_PRIOR_CALL_ID = "c14-3-provider-call-00659"
RECOVERY_REQUEST_BODY_SHA256 = (
    "DF098D978346EC4ECD961BCD0FA5A536D690FFF11BFA493288643F724BA437BA"
)
EXPECTED_PRIOR_FAIL_CLOSE_SHA256 = (
    "96C771AF1375E90C15D897AA1B56A71D734F6713921143090519767378091416"
)
EXPECTED_PRIOR_PROVIDER_LEDGER_SHA256 = (
    "357996FCA4B04A3515A80C018A5AA37BD58D109249203B5DC7C46FA99CD41F73"
)
EXPECTED_PRIOR_PROVIDER_EVENTS_SHA256 = (
    "D245DE3C2DEE618921549BBCA58E0014EFCD09D0486363AD84901A99025B3CB2"
)
EXPECTED_PRIOR_CASE_LEDGER_SHA256 = (
    "81BFB8FA8069D7B12769EB84A7D6D9D0F35CD9231FB7791B43C51DEAA67533AA"
)
EXPECTED_PRIOR_CASE_EVENTS_SHA256 = (
    "5E042C0B8D9D7BC9638DFAF04103B77CA2882066B7B52F0B07ED0BC1292B456A"
)
EXPECTED_PRIOR_STDERR_SHA256 = (
    "06F4C2FF33CFB426ACBA7A6F80E1F6B3FE11A1197EA343329FD62A970FD7E854"
)
EXPECTED_PRIOR_CONTINUATION_SHA256 = (
    "E8B0B65FB3D2096BCF4244613036442E71F5C1A4A724C0DF579EB1978B5BA75F"
)
EXPECTED_PRIOR_NAMESPACE_SHA256 = {
    "Full__REFERENCE": {
        "request_inventory.json": "060C73BAAD3FB10943466D51495927A3EF33BFD2CF8B4B46C4AA66A4FBFB5732",
        "frontier_ledger.json": "0973342143C9E0027B9D7E400420FE9E9242F90F9F240EDCE4853DEA89F54576",
        "response_source.json": "D6CC8777742D355926C50F7BC8B84136641B70FEF46F494528FDF67EDCA348A9",
        "cache_bundle.json": "3C1A16751F888F16043654834294003DDD44853451BF40CE7262DB305C3C02AE",
        "cache_events.ndjson": "2A01B3D2FDCFAFF1EE63C97B7B63DDCCA73A64883F156763556F8A147340D35A",
    },
    "Full__EVENT": {
        "request_inventory.json": "A415E9B327F28975178EC497A6C5B9647EC217844DF9A64D9F63B72A91C04350",
        "frontier_ledger.json": "F3F04EABB6EAFAFFC5CA991925129680CAF78E8F23C27EDACF5E8E707FCF3D31",
        "response_source.json": "CF2813AAC5FA5744C382C65F202F32EF5C0432D710C1722199A0C66DE90B6BD0",
        "cache_bundle.json": "57ED402F56FEB9E5A9CC8F1421C61A04D0A8A4ACF1E9B98EDEE0783303511827",
        "cache_events.ndjson": "CC89317FEE7F241C2AF3C8B536F1A78B0BD80EF763CCF5DAC7A96060DE481ECA",
    },
    "Plain_LLM__REFERENCE": {
        "request_inventory.json": "623F314BA36E14F5FBF8B2D0DBB8199F8D50FE729F3B38A0A1A96403FBBF54DB",
        "frontier_ledger.json": "642C43C4E3DCABD24E49420CAA16F691FD5461CA725054FB567FF85A76A4DD3E",
        "response_source.json": "2C5E1CD0B0022315D6B4A8E683F0B3EE17484440BA71C97B4D69F3637ED6EBBE",
        "cache_bundle.json": "549C8673F6730656C0E72CB0F10E54E1AA2234E8AA68D6FCBA2D111CC94BD51B",
        "cache_events.ndjson": "B9524CCF29738A7A4B5A7EAAE08B9FE11DF348254B30DBACF3A21D29C23995DF",
    },
    "Plain_LLM__EVENT": {
        "request_inventory.json": "03C1072A6F79A058C4BFD2ADF50B9BE74E37815B7977ABC2B8B92FCACF16D733",
        "frontier_ledger.json": "D633321FF3950CED7BA3BED056CE9D78C1635844BA6A7D0C588CB92A7F352D05",
        "response_source.json": "CCCD87CF879AEB79467974656B7562B5129301888C9A02E15808E6F13508B4F1",
        "cache_bundle.json": "C1AA9C4F77A5C0A81A3E20B41F400A470BB60ECFBA086DA7979EB2F055E5AB47",
        "cache_events.ndjson": "76BF547A6D9B0E758209B37E183850AA6A011F32686A6F1C4F6423E684DD0225",
    },
}
ORIGINAL_MANIFEST_LOCATOR = "protocol/c14/c14_3_shadow_manifest.FROZEN_20260801.json"
ORIGINAL_FAIL_CLOSE_LOCATOR = "artifacts/c14_3_shadow_20260801_attempt0001/c14_3_closeout.json"
EXPECTED_ORIGINAL_MANIFEST_SHA256 = (
    "ADC3B5CE7C0585FF6BFF0E6B1E831F8D3F3A6ED45CD91BAD98AF6A03FC970065"
)
EXPECTED_ORIGINAL_FAIL_CLOSE_SHA256 = (
    "F2E1B9513ABAF0D32C3494C371807EDEC0F0EA3B7575C37FD93C9A23FFEECC8D"
)
EXPECTED_LATENCY_DISTRIBUTION_SHA256 = (
    "2B3C1CE30967420DC544683F78FB6B694C023D86F5A46BF7D9274188F498B623"
)
EXPECTED_FAILURE_DISTRIBUTION_SHA256 = (
    "D02AD52D24C730A51F0A084B4D936C46124EADD7F6FD194F5FC4E9E30B4EF5F5"
)
ENDPOINT = "https://relay.nf.video/v1"
ENDPOINT_HOST = "relay.nf.video"
MODEL_IDENTIFIER = "gpt-5.4-mini"
MODEL_REVISION = "gpt-5.4-mini-2026-03-17"
TIMEOUT_SECONDS = 30
PROVIDER_CALL_CAP = 6_144
COST_CAP_USD = 500.0
INPUT_USD_PER_MILLION = 0.75
OUTPUT_USD_PER_MILLION = 4.5
WORST_CASE_COST_PER_CALL_USD = (
    INPUT_TOKEN_CAP * INPUT_USD_PER_MILLION / 1_000_000
    + OUTPUT_TOKEN_CAP * OUTPUT_USD_PER_MILLION / 1_000_000
)
CACHE_CONCURRENCY = 1
SHADOW_CONCURRENCY = 8
SHADOW_STORAGE_CAP = 21_474_836_480
SHADOW_CPU_SECONDS_CAP = 691_200
SHADOW_WALL_SECONDS_CAP = 345_600
SHADOW_ENVIRONMENT_STEPS_CAP = 7_680_000
SHADOW_MODEL_TRANSITIONS_CAP = 138_240_000_000


class C143Error(RuntimeError):
    """Raised when the hash-bound C14.3 stage must fail closed."""


class C143UnknownResponseError(C143Error):
    """Raised when a provider attempt may have produced an unknown response."""


def timestamp() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def canonical_sha(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest().upper()


def file_sha(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def relative(project_root: Path, path: Path) -> str:
    return path.resolve().relative_to(project_root.resolve()).as_posix()


def strict_json(path: Path) -> dict[str, Any]:
    def reject_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise C143Error(f"duplicate JSON key: {key}")
            result[key] = value
        return result

    try:
        value = json.loads(
            Path(path).read_text(encoding="utf-8"),
            object_pairs_hook=reject_duplicates,
            parse_constant=lambda item: (_ for _ in ()).throw(
                C143Error(f"non-finite JSON value: {item}")
            ),
        )
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise C143Error(f"strict JSON read failed: {path}") from exc
    if not isinstance(value, dict):
        raise C143Error(f"JSON object required: {path}")
    return value


def atomic_write_json(path: Path, value: dict[str, Any], *, replace_existing: bool) -> str:
    payload = canonical_bytes(value)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not replace_existing:
        raise C143Error(f"append-only target already exists: {path}")
    temporary = path.with_name(f".{path.name}.tmp-{uuid4().hex}")
    try:
        with temporary.open("xb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        # Windows scanners can briefly hold the destination without delete sharing.
        # Retrying only the local atomic replace never retries a provider request.
        for attempt in range(20):
            try:
                os.replace(temporary, path)
                break
            except PermissionError:
                if attempt == 19:
                    raise
                time.sleep(0.05 * (attempt + 1))
    finally:
        temporary.unlink(missing_ok=True)
    return hashlib.sha256(payload).hexdigest().upper()


def append_ndjson(path: Path, value: dict[str, Any]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(canonical_bytes(value).decode("utf-8") + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def _read_ndjson(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    try:
        for line in Path(path).read_text(encoding="utf-8").splitlines():
            value = json.loads(line)
            if not isinstance(value, dict):
                raise C143Error(f"NDJSON object required: {path}")
            rows.append(value)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise C143Error(f"strict NDJSON read failed: {path}") from exc
    return rows


def _estimated_cost(input_tokens: int, output_tokens: int) -> float:
    return round(
        input_tokens * INPUT_USD_PER_MILLION / 1_000_000
        + output_tokens * OUTPUT_USD_PER_MILLION / 1_000_000,
        9,
    )


def _reject_identity_fields(value: Any) -> None:
    forbidden = {
        "truth",
        "future",
        "shock_label",
        "locked_test_identity",
        "test_identity",
        "method_ranking",
        "api_key",
    }
    if isinstance(value, dict):
        overlap = forbidden & {str(key).lower() for key in value}
        if overlap:
            raise C143Error(f"provider payload exposes forbidden identity fields: {sorted(overlap)}")
        for child in value.values():
            _reject_identity_fields(child)
    elif isinstance(value, (list, tuple)):
        for child in value:
            _reject_identity_fields(child)


@dataclass(frozen=True, slots=True)
class C143Topology:
    source_path: Path
    method_config_locator: str
    method_config_sha256: str
    entries_sha256: str
    cases: tuple[C14MethodCase, ...]

    @property
    def by_case_id(self) -> dict[str, C14MethodCase]:
        return {case.case_id: case for case in self.cases}


def load_manifest_topology(project_root: Path, manifest_path: Path) -> C143Topology:
    manifest = strict_json(manifest_path)
    scope = manifest.get("scope")
    if not isinstance(scope, dict):
        raise C143Error("C14.3 manifest scope is missing")
    if (
        scope.get("root_family_count") != 64
        or scope.get("root_namespace") != ROOT_NAMESPACE
        or tuple(scope.get("methods", ())) != METHODS
        or tuple(scope.get("rl_train_seeds", ())) != RL_SEEDS
        or scope.get("case_count") != CASE_COUNT
    ):
        raise C143Error("C14.3 manifest topology summary drift")
    raw_cases = scope.get("cases")
    if not isinstance(raw_cases, list) or canonical_sha(raw_cases) != scope.get("cases_sha256"):
        raise C143Error("C14.3 manifest cases hash drift")
    cases: list[C14MethodCase] = []
    expected_case_fields = {
        "ordinal",
        "case_id",
        "root_case_id",
        "root_namespace",
        "cell",
        "arm",
        "scenario",
        "method_id",
        "variant_id",
        "train_seed",
        "checkpoint_locator",
        "checkpoint_sha256",
        "transitions_per_opportunity",
    }
    for raw in raw_cases:
        if not isinstance(raw, dict) or set(raw) != expected_case_fields:
            raise C143Error("C14.3 method-case fields drift")
        if raw["cell"] != ("NOMINAL" if raw["arm"] == "REFERENCE" else "HARM"):
            raise C143Error("C14.3 cell/arm binding drift")
        case = C14MethodCase(
            ordinal=raw["ordinal"],
            case_id=raw["case_id"],
            root_case_id=raw["root_case_id"],
            root_namespace=raw["root_namespace"],
            arm=raw["arm"],
            scenario=raw["scenario"],
            method_id=raw["method_id"],
            variant_id=raw["variant_id"],
            train_seed=raw["train_seed"],
            checkpoint_sha256=raw["checkpoint_sha256"],
            checkpoint_locator=raw["checkpoint_locator"],
            transitions_per_opportunity=raw["transitions_per_opportunity"],
        )
        validate_shadow_case(case)
        cases.append(case)
    if tuple(case.ordinal for case in cases) != tuple(range(CASE_COUNT)):
        raise C143Error("C14.3 method-case ordinals are not contiguous")
    if len({case.case_id for case in cases}) != CASE_COUNT:
        raise C143Error("C14.3 method-case identifiers are not unique")
    roots = tuple(scope.get("roots", ()))
    if (
        len(roots) != 64
        or len(set(roots)) != 64
        or canonical_sha(list(roots)) != scope.get("roots_sha256")
        or {case.root_case_id for case in cases} != set(roots)
    ):
        raise C143Error("C14.3 root-family scope drift")
    source_bindings = manifest.get("source_bindings", {})
    controller = source_bindings.get("controller_config")
    if not isinstance(controller, dict):
        raise C143Error("C14.3 controller-config binding is missing")
    config_path = project_root / controller["locator"]
    if file_sha(config_path) != controller["sha256"]:
        raise C143Error("C14.3 controller-config binding drift")
    return C143Topology(
        source_path=manifest_path,
        method_config_locator=controller["locator"],
        method_config_sha256=controller["sha256"],
        entries_sha256=scope["cases_sha256"],
        cases=tuple(cases),
    )


def validate_shadow_case(case: C14MethodCase) -> None:
    if case.root_namespace != ROOT_NAMESPACE or case.method_id not in METHODS:
        raise C143Error("C14.3 method-case identity drift")
    if case.arm not in ARMS or case.scenario != (
        "nominal_fixed" if case.arm == "REFERENCE" else "influx_event"
    ):
        raise C143Error("C14.3 method-case arm/scenario drift")
    expected_transitions = (
        TRANSITIONS_PER_MODEL_DECISION if case.method_id in MODEL_TRANSITION_METHODS else 0
    )
    if case.transitions_per_opportunity != expected_transitions:
        raise C143Error("C14.3 model-transition charge drift")
    if case.method_id in RL_METHODS:
        if (
            case.train_seed not in RL_SEEDS
            or case.variant_id != f"complex_seed{case.train_seed}"
            or not isinstance(case.checkpoint_locator, str)
            or not isinstance(case.checkpoint_sha256, str)
        ):
            raise C143Error("C14.3 RL method-case binding drift")
    elif any(
        value is not None
        for value in (case.train_seed, case.checkpoint_locator, case.checkpoint_sha256)
    ) or case.variant_id != "fixed":
        raise C143Error("C14.3 non-RL method-case binding drift")


class C143RequestMaterializer(V3RequestMaterializer):
    """Use the C14.3 protocol generation while retaining the audited payload builder."""

    def inventory_document(self, *, synthetic_fixture: bool) -> dict[str, Any]:
        document = ProtocolGenerationRequestMaterializer.inventory_document(
            self, synthetic_fixture=synthetic_fixture
        )
        document.update(
            {
                "schema_version": "exp09-c14-3-request-inventory-v1",
                "artifact_status": "AUTHORIZED_COMPLETE_C14_3_CAUSAL_REQUEST_INVENTORY",
                "protocol_generation": PROTOCOL_GENERATION,
                "execution_authorized": False,
            }
        )
        return document

    def _envelope(
        self, model_payload: dict[str, Any], *, extra_bindings: dict[str, str]
    ) -> dict[str, Any]:
        envelope = ProtocolGenerationRequestMaterializer._envelope(
            self, model_payload, extra_bindings=extra_bindings
        )
        envelope.update(
            {
                "schema_version": "exp09-c14-3-cache-request-envelope-v1",
                "protocol_generation": PROTOCOL_GENERATION,
            }
        )
        return envelope


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers):  # type: ignore[no-untyped-def]
        del req, fp, code, msg, headers
        raise C143Error("provider redirect is forbidden")


class C143ProviderLedger:
    """Persist a new C14.3 cost ledger before and after every provider attempt."""

    def __init__(
        self,
        path: Path,
        *,
        provider_config_sha256: str,
        imported_rows: list[dict[str, Any]] | None = None,
        continuation_provenance_sha256: str | None = None,
        reserved_prior_calls: int = 0,
        historical_failed_calls: int = 0,
        historical_unknown_responses: int = 0,
        recovery_request_hash: str | None = None,
    ) -> None:
        self.path = Path(path)
        self.provider_config_sha256 = provider_config_sha256
        self.events_path = self.path.with_name("provider_events.ndjson")
        self.rows: list[dict[str, Any]] = []
        self.continuation_provenance_sha256 = continuation_provenance_sha256
        self.reserved_prior_calls = reserved_prior_calls
        self.historical_failed_calls = historical_failed_calls
        self.historical_unknown_responses = historical_unknown_responses
        self.recovery_request_hash = recovery_request_hash
        self._lock = RLock()
        if self.path.exists():
            document = strict_json(self.path)
            if (
                document.get("schema_version") != "exp09-c14-3-provider-cost-ledger-v1"
                or document.get("protocol_generation") != PROTOCOL_GENERATION
                or document.get("provider_config_sha256") != provider_config_sha256
                or document.get("endpoint_host") != ENDPOINT_HOST
                or document.get("continuation_provenance_sha256")
                != continuation_provenance_sha256
                or document.get("reserved_prior_calls") != reserved_prior_calls
                or document.get("historical_failed_calls") != historical_failed_calls
                or document.get("historical_unknown_responses")
                != historical_unknown_responses
                or document.get("recovery_request_hash") != recovery_request_hash
            ):
                raise C143Error("existing C14.3 provider ledger binding drift")
            rows = document.get("rows")
            if not isinstance(rows, list) or document.get("rows_sha256") != canonical_sha(rows):
                raise C143Error("existing C14.3 provider ledger integrity drift")
            self.rows = rows
            if not self.events_path.is_file():
                raise C143Error("retained C14.3 provider event stream is missing")
        elif imported_rows is not None:
            if any(row.get("status") != "COMPLETED_AUDITED" for row in imported_rows):
                raise C143Error("only audited provider rows may be imported")
            if len({row.get("request_hash") for row in imported_rows}) != len(imported_rows):
                raise C143Error("imported provider request hashes are not unique")
            self.rows = json.loads(json.dumps(imported_rows))
        if any(row.get("status") == "STARTED_NO_RESPONSE" for row in self.rows):
            raise C143UnknownResponseError(
                "retained C14.3 provider call has an unknown response outcome"
            )

    def begin(self, *, method_id: str, arm: str, request_hash: str) -> str:
        with self._lock:
            if self.usage()["calls_started"] >= PROVIDER_CALL_CAP:
                raise C143Error("C14.3 provider call hard cap reached")
            if (
                self.usage()["cost_hard_cap_accounted_usd"]
                + WORST_CASE_COST_PER_CALL_USD
                > COST_CAP_USD
            ):
                raise C143Error("C14.3 cost hard cap reached")
            if any(row.get("request_hash") == request_hash for row in self.rows):
                raise C143Error("C14.3 provider request cannot be automatically retried")
            recovery_completed = any(
                row.get("request_hash") == self.recovery_request_hash
                for row in self.rows
            )
            if self.recovery_request_hash is not None and not recovery_completed:
                if request_hash != self.recovery_request_hash:
                    raise C143Error("authorized C14.3 recovery hash was not the first new request")
                attempt_kind = "USER_AUTHORIZED_SINGLE_RECOVERY_REPLAY"
            else:
                attempt_kind = "FROZEN_NEW_REQUEST_RETRY_ZERO"
            call_id = f"c14-3-provider-call-{self.usage()['calls_started']:05d}"
            self.rows.append(
                {
                    "call_id": call_id,
                    "method_id": method_id,
                    "arm": arm,
                    "request_hash": request_hash,
                    "attempt_kind": attempt_kind,
                    "request_body_sha256": None,
                    "status": "STARTED_NO_RESPONSE",
                    "started_at": timestamp(),
                    "completed_at": None,
                    "http_status": None,
                    "response_body_sha256": None,
                    "parsed_response_sha256": None,
                    "finish_reason": None,
                    "model_returned": None,
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "total_tokens": 0,
                    "latency_ms": 0,
                    "estimated_cost_usd": 0.0,
                    "error_category": None,
                    "response_outcome_unknown": False,
                }
            )
            append_ndjson(
                self.events_path,
                {
                    "schema_version": "exp09-c14-3-provider-event-v1",
                    "event": "REQUEST_STARTED_BEFORE_NETWORK",
                    **self.rows[-1],
                },
            )
            self.write()
            return call_id

    def bind_request_body(self, call_id: str, request_body_sha256: str) -> None:
        with self._lock:
            row = self._running(call_id)
            if (
                row.get("attempt_kind") == "USER_AUTHORIZED_SINGLE_RECOVERY_REPLAY"
                and request_body_sha256 != RECOVERY_REQUEST_BODY_SHA256
            ):
                raise C143Error("authorized C14.3 recovery request body binding drift")
            row["request_body_sha256"] = request_body_sha256
            append_ndjson(
                self.events_path,
                {
                    "schema_version": "exp09-c14-3-provider-event-v1",
                    "event": "REQUEST_BODY_HASH_BOUND_BEFORE_NETWORK",
                    "call_id": call_id,
                    "request_body_sha256": request_body_sha256,
                    "recorded_at": timestamp(),
                },
            )
            self.write()

    def complete(
        self,
        call_id: str,
        result: ProviderResult,
        *,
        response_body_sha256: str,
        model_returned: str,
    ) -> None:
        with self._lock:
            row = self._running(call_id)
            if result.usage.input_tokens > INPUT_TOKEN_CAP or result.usage.output_tokens > OUTPUT_TOKEN_CAP:
                raise C143Error("C14.3 token hard cap exceeded")
            new_cost = _estimated_cost(result.usage.input_tokens, result.usage.output_tokens)
            if self.usage()["cost_hard_cap_accounted_usd"] + new_cost > COST_CAP_USD:
                raise C143Error("C14.3 cost hard cap would be exceeded")
            row.update(
                {
                    "status": "COMPLETED_AUDITED",
                    "completed_at": timestamp(),
                    "http_status": 200,
                    "response_body_sha256": response_body_sha256,
                    "parsed_response_sha256": canonical_sha(result.parsed_response),
                    "finish_reason": result.finish_reason,
                    "model_returned": model_returned,
                    "input_tokens": result.usage.input_tokens,
                    "output_tokens": result.usage.output_tokens,
                    "total_tokens": result.usage.total_tokens,
                    "latency_ms": result.wall_ms,
                    "estimated_cost_usd": new_cost,
                }
            )
            append_ndjson(
                self.events_path,
                {
                    "schema_version": "exp09-c14-3-provider-event-v1",
                    "event": "RESPONSE_COMPLETED_AUDITED",
                    **row,
                },
            )
            self.write()

    def fail(
        self,
        call_id: str,
        exc: BaseException,
        *,
        latency_ms: int,
        response_outcome_unknown: bool,
        response_body_sha256: str | None = None,
        http_status: int | None = None,
    ) -> None:
        with self._lock:
            row = self._running(call_id)
            row.update(
                {
                    "status": "FAILED_RETAINED",
                    "completed_at": timestamp(),
                    "http_status": http_status,
                    "response_body_sha256": response_body_sha256,
                    "latency_ms": max(0, latency_ms),
                    "error_category": type(exc).__name__,
                    "response_outcome_unknown": response_outcome_unknown,
                }
            )
            append_ndjson(
                self.events_path,
                {
                    "schema_version": "exp09-c14-3-provider-event-v1",
                    "event": "RESPONSE_FAILED_RETAINED",
                    **row,
                },
            )
            self.write()

    def usage(self) -> dict[str, Any]:
        completed = [row for row in self.rows if row["status"] == "COMPLETED_AUDITED"]
        failed = [row for row in self.rows if row["status"] == "FAILED_RETAINED"]
        estimated_cost = round(sum(row["estimated_cost_usd"] for row in completed), 9)
        unknown_reserve = round(
            self.historical_unknown_responses * WORST_CASE_COST_PER_CALL_USD
            + sum(
                WORST_CASE_COST_PER_CALL_USD
                for row in failed
                if row["response_outcome_unknown"]
            ),
            9,
        )
        return {
            "calls_started": len(self.rows) + self.reserved_prior_calls,
            "calls_completed": len(completed),
            "calls_failed": len(failed) + self.historical_failed_calls,
            "response_unknown": (
                sum(bool(row["response_outcome_unknown"]) for row in failed)
                + self.historical_unknown_responses
            ),
            "input_tokens": sum(row["input_tokens"] for row in completed),
            "output_tokens": sum(row["output_tokens"] for row in completed),
            "total_tokens": sum(row["total_tokens"] for row in completed),
            "estimated_cost_usd": estimated_cost,
            "unknown_cost_reserve_usd": unknown_reserve,
            "cost_hard_cap_accounted_usd": round(estimated_cost + unknown_reserve, 9),
            "latency_ms": sum(row["latency_ms"] for row in self.rows),
        }

    def document(self) -> dict[str, Any]:
        return {
            "schema_version": "exp09-c14-3-provider-cost-ledger-v1",
            "artifact_status": "C14_3_CACHE_REMEDIATION_PROVIDER_EVIDENCE",
            "protocol_generation": PROTOCOL_GENERATION,
            "provider": "openai",
            "endpoint_host": ENDPOINT_HOST,
            "model_identifier": MODEL_IDENTIFIER,
            "model_revision": MODEL_REVISION,
            "provider_config_sha256": self.provider_config_sha256,
            "continuation_provenance_sha256": self.continuation_provenance_sha256,
            "reserved_prior_calls": self.reserved_prior_calls,
            "historical_failed_calls": self.historical_failed_calls,
            "historical_unknown_responses": self.historical_unknown_responses,
            "recovery_request_hash": self.recovery_request_hash,
            "recovery_replay_hard_cap": 1 if self.recovery_request_hash is not None else 0,
            "hard_caps": {
                "calls": PROVIDER_CALL_CAP,
                "cost_usd": COST_CAP_USD,
                "input_tokens_per_call": INPUT_TOKEN_CAP,
                "output_tokens_per_call": OUTPUT_TOKEN_CAP,
                "timeout_ms": TIMEOUT_SECONDS * 1000,
                "retry": 0,
                "concurrency": CACHE_CONCURRENCY,
            },
            "usage": self.usage(),
            "api_key_recorded": False,
            "append_only_events_locator": self.events_path.name,
            "append_only_events_sha256": (
                file_sha(self.events_path) if self.events_path.is_file() else None
            ),
            "rows_sha256": canonical_sha(self.rows),
            "rows": self.rows,
        }

    def write(self) -> str:
        return atomic_write_json(self.path, self.document(), replace_existing=True)

    def initialize(self) -> str:
        if not self.events_path.exists():
            append_ndjson(
                self.events_path,
                {
                    "schema_version": "exp09-c14-3-provider-event-v1",
                    "event": (
                        "LEDGER_INITIALIZED_WITH_PRIOR_AUDITED_USAGE"
                        if self.rows
                        else "LEDGER_INITIALIZED_ZERO_USE"
                    ),
                    "protocol_generation": PROTOCOL_GENERATION,
                    "provider_config_sha256": self.provider_config_sha256,
                    "continuation_provenance_sha256": self.continuation_provenance_sha256,
                    "endpoint_host": ENDPOINT_HOST,
                    "imported_completed_calls": len(self.rows),
                    "reserved_prior_calls": self.reserved_prior_calls,
                    "historical_failed_calls": self.historical_failed_calls,
                    "historical_unknown_responses": self.historical_unknown_responses,
                    "recovery_request_hash": self.recovery_request_hash,
                    "imported_estimated_cost_usd": self.usage()["estimated_cost_usd"],
                    "recorded_at": timestamp(),
                    "api_key_recorded": False,
                },
            )
        return self.write()

    def _running(self, call_id: str) -> dict[str, Any]:
        matches = [row for row in self.rows if row["call_id"] == call_id]
        if len(matches) != 1 or matches[0]["status"] != "STARTED_NO_RESPONSE":
            raise C143Error("C14.3 provider call is not in a running state")
        return matches[0]


class C143ProviderSession:
    """Call only the frozen relay host with no redirects, proxy, retry, or fallback."""

    def __init__(
        self,
        *,
        method_id: str,
        arm: str,
        credentials: ProviderCredentials,
        protocol: dict[str, Any],
        ledger: C143ProviderLedger,
    ) -> None:
        if method_id not in LLM_METHODS or arm not in ARMS:
            raise C143Error("C14.3 provider session scope drift")
        if credentials.base_url != ENDPOINT:
            raise C143Error("C14.3 provider endpoint drift")
        self.method_id = method_id
        self.arm = arm
        self.credentials = credentials
        self.protocol = protocol
        self.ledger = ledger

    def generate(self, *, request_hash: str, model_payload: dict[str, Any]) -> ProviderResult:
        _reject_identity_fields(model_payload)
        body = build_provider_request_body(
            method_id=self.method_id,
            protocol=self.protocol,
            model_payload=model_payload,
        )
        call_id = self.ledger.begin(
            method_id=self.method_id, arm=self.arm, request_hash=request_hash
        )
        request_bytes = canonical_bytes(body)
        self.ledger.bind_request_body(call_id, hashlib.sha256(request_bytes).hexdigest().upper())
        request = Request(
            f"{ENDPOINT}/chat/completions",
            data=request_bytes,
            headers={
                "Authorization": f"Bearer {self.credentials.api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "exp09-c14-3-cache-remediation/1.0",
            },
            method="POST",
        )
        started = time.monotonic()
        try:
            opener = build_opener(ProxyHandler({}), _NoRedirect(), HTTPSHandler())
            with opener.open(request, timeout=TIMEOUT_SECONDS) as response:
                if urlparse(response.geturl()).hostname != ENDPOINT_HOST:
                    raise C143Error("C14.3 response host violated the frozen host gate")
                raw_bytes = response.read()
                http_status = int(response.status)
        except HTTPError as exc:
            body_bytes = exc.read()
            latency_ms = max(0, round((time.monotonic() - started) * 1000))
            self.ledger.fail(
                call_id,
                exc,
                latency_ms=latency_ms,
                response_outcome_unknown=False,
                response_body_sha256=hashlib.sha256(body_bytes).hexdigest().upper(),
                http_status=exc.code,
            )
            raise C143Error("C14.3 provider HTTP failure retained without retry") from exc
        except (TimeoutError, socket.timeout, RemoteDisconnected) as exc:
            latency_ms = max(0, round((time.monotonic() - started) * 1000))
            self.ledger.fail(
                call_id,
                exc,
                latency_ms=latency_ms,
                response_outcome_unknown=True,
            )
            raise C143UnknownResponseError(
                "C14.3 provider response outcome is unknown; fail closed"
            ) from exc
        except (URLError, OSError) as exc:
            latency_ms = max(0, round((time.monotonic() - started) * 1000))
            self.ledger.fail(
                call_id,
                exc,
                latency_ms=latency_ms,
                response_outcome_unknown=False,
            )
            raise C143Error("C14.3 provider transport failure retained without retry") from exc
        latency_ms = max(0, round((time.monotonic() - started) * 1000))
        response_hash = hashlib.sha256(raw_bytes).hexdigest().upper()
        try:
            raw = json.loads(raw_bytes.decode("utf-8"))
            choices = raw["choices"]
            if not isinstance(choices, list) or len(choices) != 1:
                raise ValueError("provider choice count")
            choice = choices[0]
            parsed = json.loads(choice["message"]["content"])
            usage_raw = raw["usage"]
            usage = ProviderUsage(
                input_tokens=int(usage_raw["prompt_tokens"]),
                output_tokens=int(usage_raw["completion_tokens"]),
                total_tokens=int(usage_raw["total_tokens"]),
            )
            finish_reason = choice["finish_reason"]
            model_returned = raw["model"]
            if (
                finish_reason != "stop"
                or model_returned != MODEL_IDENTIFIER
                or usage.total_tokens != usage.input_tokens + usage.output_tokens
                or min(usage.input_tokens, usage.output_tokens, usage.total_tokens) < 0
            ):
                raise ValueError("provider finish/model/usage audit")
            audited = audit_provider_response(
                self.method_id,
                request_hash=request_hash,
                model_payload=model_payload,
                response=parsed,
            )
        except (KeyError, TypeError, ValueError, UnicodeError, json.JSONDecodeError) as exc:
            self.ledger.fail(
                call_id,
                exc,
                latency_ms=latency_ms,
                response_outcome_unknown=False,
                response_body_sha256=response_hash,
                http_status=http_status,
            )
            raise C143Error("C14.3 provider response envelope/schema drift") from exc
        result = ProviderResult(
            raw_response=raw,
            parsed_response=audited,
            finish_reason=finish_reason,
            usage=usage,
            wall_ms=latency_ms,
        )
        try:
            self.ledger.complete(
                call_id,
                result,
                response_body_sha256=response_hash,
                model_returned=model_returned,
            )
        except BaseException as exc:
            self.ledger.fail(
                call_id,
                exc,
                latency_ms=latency_ms,
                response_outcome_unknown=False,
                response_body_sha256=response_hash,
                http_status=http_status,
            )
            raise
        return result


class C143ClosureCache:
    """Generate and persist one C14.3 causal namespace in exact request order."""

    def __init__(
        self,
        *,
        project_root: Path,
        output_root: Path,
        method_id: str,
        arm: str,
        materializer: C143RequestMaterializer,
        provider_session: Any,
        method_config_sha256: str,
        prompt_protocol_sha256: str,
        provider_config_sha256: str,
    ) -> None:
        self.project_root = project_root
        self.output_root = output_root
        self.method_id = method_id
        self.arm = arm
        self.namespace = materializer.namespace
        self.materializer = materializer
        self.provider_session = provider_session
        self.method_config_sha256 = method_config_sha256
        self.prompt_protocol_sha256 = prompt_protocol_sha256
        self.provider_config_sha256 = provider_config_sha256
        self.case_id: str | None = None
        self.responses: dict[str, dict[str, Any]] = {}
        self.source_records: list[dict[str, Any]] = []
        self.miss_rows: list[dict[str, Any]] = []
        self.lookup_attempts = 0
        self.events_path = self._directory() / "cache_events.ndjson"
        if self._directory().exists():
            self._load_existing()
        else:
            append_ndjson(
                self.events_path,
                {
                    "schema_version": "exp09-c14-3-cache-event-v1",
                    "event": "NAMESPACE_INITIALIZED_ZERO_USE",
                    "protocol_generation": PROTOCOL_GENERATION,
                    "method_id": self.method_id,
                    "arm": self.arm,
                    "namespace": self.namespace,
                    "recorded_at": timestamp(),
                },
            )
            self._persist_all()

    @contextmanager
    def bind_case(self, case_id: str) -> Iterator[None]:
        if self.case_id is not None:
            raise C143Error("C14.3 cache case binding is already active")
        self.case_id = case_id
        try:
            yield
        finally:
            self.case_id = None

    def response_for(self, request_hash: str) -> dict[str, Any]:
        self.lookup_attempts += 1
        response = self.responses.get(request_hash)
        if response is not None:
            return response
        if self.case_id is None:
            raise C143Error("C14.3 cache miss occurred outside a bound causal case")
        matches = [
            record for record in self.materializer.records if record.request_hash == request_hash
        ]
        if len(matches) != 1:
            raise C143Error("C14.3 cache miss is not bound to one materialized request")
        record = matches[0]
        miss = {
            "ordinal": len(self.miss_rows),
            "case_id": self.case_id,
            "method_id": self.method_id,
            "arm": self.arm,
            "namespace": self.namespace,
            "request_hash": request_hash,
            "model_payload_sha256": canonical_sha(record.model_payload),
            "status": "CACHE_MISS_PERSISTED_RESPONSE_PENDING",
            "persisted_at": timestamp(),
            "audited_at": None,
            "response_binding_sha256": None,
        }
        self.miss_rows.append(miss)
        append_ndjson(
            self.events_path,
            {
                "schema_version": "exp09-c14-3-cache-event-v1",
                "event": "CACHE_MISS_PERSISTED_RESPONSE_PENDING",
                **miss,
            },
        )
        self._persist_all()
        result = self.provider_session.generate(
            request_hash=request_hash, model_payload=record.model_payload
        )
        response = result.parsed_response
        binding_sha = canonical_sha({"request_hash": request_hash, "response": response})
        self.source_records.append(
            {
                "request_hash": request_hash,
                "request_payload_sha256": canonical_sha(record.model_payload),
                "raw_response_sha256": canonical_sha(result.raw_response),
                "parsed_response": response,
                "parsed_response_sha256": canonical_sha(response),
                "finish_reason": result.finish_reason,
                "input_tokens": result.usage.input_tokens,
                "output_tokens": result.usage.output_tokens,
                "total_tokens": result.usage.total_tokens,
                "latency_ms": result.wall_ms,
                "response_binding_sha256": binding_sha,
            }
        )
        self.responses[request_hash] = response
        miss.update(
            {
                "status": "RESPONSE_AUDITED_CACHE_BOUND",
                "audited_at": timestamp(),
                "response_binding_sha256": binding_sha,
            }
        )
        append_ndjson(
            self.events_path,
            {
                "schema_version": "exp09-c14-3-cache-event-v1",
                "event": "RESPONSE_AUDITED_CACHE_BOUND",
                **miss,
                "parsed_response_sha256": canonical_sha(response),
            },
        )
        self._persist_all()
        return response

    def import_audited_response(self, prior_record: dict[str, Any]) -> None:
        if self.materializer.records or self.miss_rows:
            raise C143Error("prior cache responses must be imported into a new namespace")
        request_hash = prior_record.get("request_hash")
        parsed_response = prior_record.get("parsed_response")
        if (
            not isinstance(request_hash, str)
            or not isinstance(parsed_response, dict)
            or prior_record.get("parsed_response_sha256") != canonical_sha(parsed_response)
            or prior_record.get("response_binding_sha256")
            != canonical_sha({"request_hash": request_hash, "response": parsed_response})
        ):
            raise C143Error("prior audited cache response binding drift")
        if request_hash in self.responses:
            raise C143Error("prior audited cache response is duplicated")
        imported = json.loads(json.dumps(prior_record))
        imported["continuation_imported_from"] = PRIOR_CACHE_OUTPUT_LOCATOR
        self.source_records.append(imported)
        self.responses[request_hash] = parsed_response
        append_ndjson(
            self.events_path,
            {
                "schema_version": "exp09-c14-3-cache-event-v1",
                "event": "PRIOR_AUDITED_RESPONSE_IMPORTED_HASH_BOUND",
                "protocol_generation": PROTOCOL_GENERATION,
                "method_id": self.method_id,
                "arm": self.arm,
                "namespace": self.namespace,
                "request_hash": request_hash,
                "parsed_response_sha256": canonical_sha(parsed_response),
                "prior_source_locator": PRIOR_CACHE_OUTPUT_LOCATOR,
                "recorded_at": timestamp(),
            },
        )
        self._persist_all()

    def inventory_document(self) -> dict[str, Any]:
        return self.materializer.inventory_document(synthetic_fixture=False)

    def source_document(self) -> dict[str, Any]:
        return {
            "schema_version": "exp09-c14-3-external-response-source-v1",
            "artifact_status": "C14_3_COMPANY_CHANNEL_SOURCE_RETAINED_AUDITED",
            "protocol_generation": PROTOCOL_GENERATION,
            "method_id": self.method_id,
            "arm": self.arm,
            "namespace": self.namespace,
            "provider": "openai",
            "endpoint_host": ENDPOINT_HOST,
            "model_identifier": MODEL_IDENTIFIER,
            "model_revision": MODEL_REVISION,
            "provider_config_sha256": self.provider_config_sha256,
            "retry_count": 0,
            "tool_call_count": 0,
            "provider_memory": False,
            "api_key_recorded": False,
            "records_sha256": canonical_sha(self.source_records),
            "records": self.source_records,
        }

    def bundle_document(self) -> dict[str, Any]:
        inventory = self.inventory_document()
        required = inventory["request_hashes"]
        entries = [
            {
                "request_hash": request_hash,
                "response": self.responses[request_hash],
                "response_binding_sha256": canonical_sha(
                    {"request_hash": request_hash, "response": self.responses[request_hash]}
                ),
            }
            for request_hash in required
            if request_hash in self.responses
        ]
        missing = [request_hash for request_hash in required if request_hash not in self.responses]
        return {
            "schema_version": "exp09-c14-3-offline-cache-bundle-v1",
            "artifact_status": "C14_3_EXACT_COVERAGE_QUALIFIED" if not missing else "PARTIAL",
            "protocol_generation": PROTOCOL_GENERATION,
            "method_id": self.method_id,
            "arm": self.arm,
            "namespace": self.namespace,
            "network_fallback": False,
            "api_calls_during_replay": 0,
            "provider_calls_during_replay": 0,
            "llm_tokens_during_replay": 0,
            "bindings": {
                "method_config_sha256": self.method_config_sha256,
                "prompt_protocol_sha256": self.prompt_protocol_sha256,
                "provider_config_sha256": self.provider_config_sha256,
            },
            "provenance": {
                "source_artifact_locator": relative(
                    self.project_root, self._path("response_source.json")
                ),
                "source_artifact_sha256": (
                    file_sha(self._path("response_source.json"))
                    if self._path("response_source.json").is_file()
                    else None
                ),
            },
            "coverage": {
                "status": "COMPLETE" if not missing else "PARTIAL",
                "required_request_hashes": required,
                "missing": len(missing),
                "unexpected": 0,
                "duplicate": 0,
            },
            "entries_sha256": canonical_sha(entries),
            "entries": entries,
        }

    def audit_complete(self) -> None:
        inventory = self.inventory_document()
        bundle = self.bundle_document()
        records = inventory["records"]
        entries = bundle["entries"]
        if (
            inventory.get("schema_version") != "exp09-c14-3-request-inventory-v1"
            or inventory.get("protocol_generation") != PROTOCOL_GENERATION
            or bundle.get("schema_version") != "exp09-c14-3-offline-cache-bundle-v1"
            or bundle.get("protocol_generation") != PROTOCOL_GENERATION
            or inventory.get("records_sha256") != canonical_sha(records)
            or inventory.get("request_hashes") != [record["request_hash"] for record in records]
            or len(inventory["request_hashes"]) != len(set(inventory["request_hashes"]))
            or bundle.get("entries_sha256") != canonical_sha(entries)
            or [entry["request_hash"] for entry in entries] != inventory["request_hashes"]
            or bundle.get("coverage")
            != {
                "status": "COMPLETE",
                "required_request_hashes": inventory["request_hashes"],
                "missing": 0,
                "unexpected": 0,
                "duplicate": 0,
            }
            or bundle.get("provenance", {}).get("source_artifact_sha256")
            != file_sha(self._path("response_source.json"))
        ):
            raise C143Error("C14.3 exact ordered cache coverage audit failed")
        record_by_hash = {record["request_hash"]: record for record in records}
        for entry in entries:
            request_hash = entry["request_hash"]
            if entry["response_binding_sha256"] != canonical_sha(
                {"request_hash": request_hash, "response": entry["response"]}
            ):
                raise C143Error("C14.3 cache response binding drift")
            audit_provider_response(
                self.method_id,
                request_hash=request_hash,
                model_payload=record_by_hash[request_hash]["model_payload"],
                response=(
                    entry["response"]["proposal"]
                    if self.method_id == "Full"
                    else entry["response"]
                ),
            )

    def _persist_all(self) -> None:
        self._directory().mkdir(parents=True, exist_ok=True)
        atomic_write_json(
            self._path("request_inventory.json"),
            self.inventory_document(),
            replace_existing=True,
        )
        atomic_write_json(
            self._path("frontier_ledger.json"),
            {
                "schema_version": "exp09-c14-3-frontier-ledger-v1",
                "protocol_generation": PROTOCOL_GENERATION,
                "method_id": self.method_id,
                "arm": self.arm,
                "namespace": self.namespace,
                "lookup_attempts": self.lookup_attempts,
                "rows_sha256": canonical_sha(self.miss_rows),
                "rows": self.miss_rows,
            },
            replace_existing=True,
        )
        atomic_write_json(
            self._path("response_source.json"),
            self.source_document(),
            replace_existing=True,
        )
        atomic_write_json(
            self._path("cache_bundle.json"),
            self.bundle_document(),
            replace_existing=True,
        )

    def _load_existing(self) -> None:
        required = (
            "request_inventory.json",
            "frontier_ledger.json",
            "response_source.json",
            "cache_bundle.json",
        )
        if not all(self._path(name).is_file() for name in required):
            raise C143Error("partial C14.3 cache namespace cannot resume")
        if not self.events_path.is_file():
            raise C143Error("C14.3 cache append-only event stream is missing")
        inventory = strict_json(self._path("request_inventory.json"))
        ledger = strict_json(self._path("frontier_ledger.json"))
        source = strict_json(self._path("response_source.json"))
        bundle = strict_json(self._path("cache_bundle.json"))
        if (
            inventory.get("protocol_generation") != PROTOCOL_GENERATION
            or ledger.get("protocol_generation") != PROTOCOL_GENERATION
            or source.get("protocol_generation") != PROTOCOL_GENERATION
            or bundle.get("protocol_generation") != PROTOCOL_GENERATION
            or ledger.get("rows_sha256") != canonical_sha(ledger.get("rows"))
            or source.get("records_sha256") != canonical_sha(source.get("records"))
        ):
            raise C143Error("existing C14.3 cache namespace binding drift")
        if any(row.get("status") != "RESPONSE_AUDITED_CACHE_BOUND" for row in ledger["rows"]):
            raise C143UnknownResponseError(
                "C14.3 cache contains an interrupted response-pending frontier"
            )
        for record in inventory.get("records", []):
            restored = self.materializer._record(
                record["cache_envelope"],
                record["model_payload"],
                opportunity_id=record["opportunity_id"],
                causal_cutoff_us=record["causal_cutoff_us"],
            )
            if restored.request_hash != record["request_hash"]:
                raise C143Error("existing C14.3 request inventory cannot be reproduced")
        self.source_records = source["records"]
        self.miss_rows = ledger["rows"]
        self.lookup_attempts = int(ledger["lookup_attempts"])
        self.responses = {entry["request_hash"]: entry["response"] for entry in bundle["entries"]}

    def _directory(self) -> Path:
        return self.output_root / f"{self.method_id}__{self.arm}"

    def _path(self, name: str) -> Path:
        return self._directory() / name


class C143QualifiedReplayCache:
    def __init__(self, cache: C143ClosureCache) -> None:
        cache.audit_complete()
        self.method_id = cache.method_id
        self.namespace = cache.namespace
        self.bundle_sha256 = file_sha(cache._path("cache_bundle.json"))
        self._responses = dict(cache.responses)

    def response_for(self, request_hash: str) -> dict[str, Any]:
        response = self._responses.get(request_hash)
        if response is None:
            raise C143Error("C14.3 offline cache miss; provider fallback is forbidden")
        return response


def _verify_cache_inputs(project_root: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    provider_path = project_root / PROVIDER_CONFIG_LOCATOR
    method_path = project_root / METHOD_CONFIG_LOCATOR
    provider = strict_json(provider_path)
    method = strict_json(method_path)
    if (
        provider.get("protocol_generation") != PROTOCOL_GENERATION
        or provider.get("provider") != "openai"
        or provider.get("endpoint") != ENDPOINT
        or provider.get("endpoint_host") != ENDPOINT_HOST
        or provider.get("model_identifier") != MODEL_IDENTIFIER
        or provider.get("model_revision") != MODEL_REVISION
        or provider.get("input_token_cap") != INPUT_TOKEN_CAP
        or provider.get("output_token_cap") != OUTPUT_TOKEN_CAP
        or provider.get("timeout_ms") != TIMEOUT_SECONDS * 1000
        or provider.get("retry") != 0
        or provider.get("temperature") != 0
        or provider.get("concurrency") != CACHE_CONCURRENCY
        or provider.get("api_attempt_hard_cap") != PROVIDER_CALL_CAP
        or provider.get("cost_hard_cap_usd") != COST_CAP_USD
        or provider.get("network_fallback") is not False
        or provider.get("redirects") is not False
        or provider.get("environment_proxy") is not False
    ):
        raise C143Error("C14.3 provider config drift")
    if (
        method.get("protocol_generation") != PROTOCOL_GENERATION
        or tuple(method.get("methods", {})) != LLM_METHODS
        or method.get("provider_config_locator") != PROVIDER_CONFIG_LOCATOR
        or method.get("controller_config_locator") != CONTROLLER_CONFIG_LOCATOR
        or method.get("profile_injection_protocol_locator") != PROFILE_PROTOCOL_LOCATOR
    ):
        raise C143Error("C14.3 cache method config drift")
    return provider, method


def _cache_case_plan() -> list[dict[str, str]]:
    return [
        {
            "case_id": f"{ROOT_ID_PREFIX}{root_index:02d}__{arm}__{method_id}__fixed",
            "root_case_id": f"{ROOT_ID_PREFIX}{root_index:02d}",
            "arm": arm,
            "method_id": method_id,
        }
        for root_index in range(64)
        for arm in ARMS
        for method_id in LLM_METHODS
    ]


def _prepare_continuation(project_root: Path, output_root: Path) -> dict[str, Any]:
    prior_root = project_root / PRIOR_CACHE_OUTPUT_LOCATOR
    fixed_bindings = {
        "fail_close": (prior_root / "FAIL_CLOSED.json", EXPECTED_PRIOR_FAIL_CLOSE_SHA256),
        "provider_ledger": (
            prior_root / "provider_cost_ledger.json",
            EXPECTED_PRIOR_PROVIDER_LEDGER_SHA256,
        ),
        "provider_events": (
            prior_root / "provider_events.ndjson",
            EXPECTED_PRIOR_PROVIDER_EVENTS_SHA256,
        ),
        "causal_case_ledger": (
            prior_root / "causal_case_ledger.json",
            EXPECTED_PRIOR_CASE_LEDGER_SHA256,
        ),
        "causal_case_events": (
            prior_root / "causal_case_events.ndjson",
            EXPECTED_PRIOR_CASE_EVENTS_SHA256,
        ),
        "prior_continuation": (
            prior_root / "continuation_provenance.json",
            EXPECTED_PRIOR_CONTINUATION_SHA256,
        ),
        "stderr": (project_root / PRIOR_STDERR_LOCATOR, EXPECTED_PRIOR_STDERR_SHA256),
    }
    for name, (path, expected_sha) in fixed_bindings.items():
        if not path.is_file() or file_sha(path) != expected_sha:
            raise C143Error(f"prior C14.3 fail-close binding drift: {name}")
    namespace_bindings = []
    for directory, expected_files in EXPECTED_PRIOR_NAMESPACE_SHA256.items():
        for filename, expected_sha in expected_files.items():
            path = prior_root / directory / filename
            if not path.is_file() or file_sha(path) != expected_sha:
                raise C143Error(f"prior C14.3 namespace binding drift: {directory}/{filename}")
            namespace_bindings.append(
                {
                    "locator": relative(project_root, path),
                    "sha256": expected_sha,
                }
            )
    prior_ledger = strict_json(prior_root / "provider_cost_ledger.json")
    prior_rows = prior_ledger.get("rows")
    if not isinstance(prior_rows, list) or prior_ledger.get("rows_sha256") != canonical_sha(
        prior_rows
    ):
        raise C143Error("prior C14.3 provider ledger integrity drift")
    completed_rows = [row for row in prior_rows if row.get("status") == "COMPLETED_AUDITED"]
    failed_rows = [row for row in prior_rows if row.get("status") == "FAILED_RETAINED"]
    if (
        len(prior_rows) != 659
        or prior_ledger.get("reserved_prior_calls") != 1
        or len(completed_rows) != 658
        or len(failed_rows) != 1
    ):
        raise C143Error("prior C14.3 provider stop boundary drift")
    failed = failed_rows[0]
    provider_events = _read_ndjson(prior_root / "provider_events.ndjson")
    failed_events = [row for row in provider_events if row.get("call_id") == failed["call_id"]]
    if (
        failed.get("call_id") != RECOVERY_PRIOR_CALL_ID
        or failed.get("request_hash") != RECOVERY_REQUEST_HASH
        or failed.get("status") != "FAILED_RETAINED"
        or failed.get("error_category") != "RemoteDisconnected"
        or failed.get("response_outcome_unknown") is not True
        or failed.get("request_body_sha256")
        != RECOVERY_REQUEST_BODY_SHA256
        or failed.get("http_status") is not None
        or failed.get("response_body_sha256") is not None
        or [row.get("event") for row in failed_events]
        != [
            "REQUEST_STARTED_BEFORE_NETWORK",
            "REQUEST_BODY_HASH_BOUND_BEFORE_NETWORK",
            "RESPONSE_FAILED_RETAINED",
        ]
    ):
        raise C143Error("prior authorized recovery target binding drift")
    stderr_bytes = (project_root / PRIOR_STDERR_LOCATOR).read_bytes()
    if b"RemoteDisconnected" not in stderr_bytes or b"C143UnknownResponseError" not in stderr_bytes:
        raise C143Error("prior unknown-response traceback drift")

    prior_responses: dict[tuple[str, str], dict[str, dict[str, Any]]] = {}
    for method_id in LLM_METHODS:
        for arm in ARMS:
            prior_source = strict_json(prior_root / f"{method_id}__{arm}" / "response_source.json")
            responses = {
                record["request_hash"]: record for record in prior_source.get("records", [])
            }
            if len(responses) != len(prior_source.get("records", [])):
                raise C143Error("prior C14.3 response source contains duplicates")
            prior_responses[(method_id, arm)] = responses
    if sum(len(rows) for rows in prior_responses.values()) != 658:
        raise C143Error("prior C14.3 audited cache response count drift")

    provenance = {
        "schema_version": "exp09-c14-3-cache-continuation-provenance-v1",
        "artifact_status": "USER_AUTHORIZED_SINGLE_HASH_BOUND_UNKNOWN_RESPONSE_RECOVERY",
        "protocol_generation": PROTOCOL_GENERATION,
        "prior_protocol_generation": PROTOCOL_GENERATION,
        "prior_artifact_locator": PRIOR_CACHE_OUTPUT_LOCATOR,
        "prior_bindings": {
            name: {"locator": relative(project_root, path), "sha256": expected_sha}
            for name, (path, expected_sha) in fixed_bindings.items()
        },
        "prior_namespace_bindings_sha256": canonical_sha(namespace_bindings),
        "prior_namespace_bindings": namespace_bindings,
        "prior_usage": prior_ledger["usage"],
        "imported_completed_calls": len(completed_rows),
        "reserved_pre_network_local_failure_calls": prior_ledger["reserved_prior_calls"],
        "historical_failed_calls": len(failed_rows),
        "historical_unknown_responses": 1,
        "provider_request_retried": True,
        "provider_retry": 0,
        "recovery_replay": {
            "authorized": True,
            "request_hash": RECOVERY_REQUEST_HASH,
            "prior_call_id": RECOVERY_PRIOR_CALL_ID,
            "hard_cap": 1,
            "all_other_requests_retry": 0,
            "unknown_response_fail_closed": True,
        },
        "cumulative_call_cap": PROVIDER_CALL_CAP,
        "cumulative_cost_cap_usd": COST_CAP_USD,
        "api_key_recorded": False,
    }
    provenance_path = output_root / "continuation_provenance.json"
    provenance_sha = canonical_sha(provenance)
    if provenance_path.exists():
        if strict_json(provenance_path) != provenance or file_sha(provenance_path) != provenance_sha:
            raise C143Error("C14.3 continuation provenance drift")
    else:
        atomic_write_json(provenance_path, provenance, replace_existing=False)
    return {
        "provenance_sha256": provenance_sha,
        "completed_rows": completed_rows,
        "reserved_prior_calls": prior_ledger["reserved_prior_calls"] + len(failed_rows),
        "historical_failed_calls": len(failed_rows),
        "historical_unknown_responses": 1,
        "recovery_request_hash": RECOVERY_REQUEST_HASH,
        "responses": prior_responses,
    }


class C143CacheOrchestrator:
    def __init__(self, project_root: Path, credential_path: Path) -> None:
        self.project_root = Path(project_root).resolve()
        self.output_root = self.project_root / CACHE_OUTPUT_LOCATOR
        if not self.output_root.exists():
            self.output_root.mkdir(parents=True, exist_ok=False)
        continuation = _prepare_continuation(self.project_root, self.output_root)
        _provider, self.method_config = _verify_cache_inputs(self.project_root)
        credentials = load_provider_credentials(credential_path, profile="primary")
        if credentials.base_url != ENDPOINT or urlparse(credentials.base_url).hostname != ENDPOINT_HOST:
            raise C143Error("credential endpoint is not the authorized relay host")
        self.provider_config_sha = file_sha(self.project_root / PROVIDER_CONFIG_LOCATOR)
        self.method_config_sha = file_sha(self.project_root / METHOD_CONFIG_LOCATOR)
        self.controller_config_sha = file_sha(self.project_root / CONTROLLER_CONFIG_LOCATOR)
        self.factory = C14ControllerFactory(
            self.project_root,
            CONTROLLER_CONFIG_LOCATOR,
            expected_config_sha256=self.controller_config_sha,
        )
        self.profile = EmpiricalProfile(
            self.project_root,
            {
                "profile_binding": {
                    "latency_distribution_hash": EXPECTED_LATENCY_DISTRIBUTION_SHA256,
                    "failure_distribution_hash": EXPECTED_FAILURE_DISTRIBUTION_SHA256,
                }
            },
        )
        self.ledger = C143ProviderLedger(
            self.output_root / "provider_cost_ledger.json",
            provider_config_sha256=self.provider_config_sha,
            imported_rows=continuation["completed_rows"],
            continuation_provenance_sha256=continuation["provenance_sha256"],
            reserved_prior_calls=continuation["reserved_prior_calls"],
            historical_failed_calls=continuation["historical_failed_calls"],
            historical_unknown_responses=continuation["historical_unknown_responses"],
            recovery_request_hash=continuation["recovery_request_hash"],
        )
        self.ledger.initialize()
        self.materializers: dict[tuple[str, str], C143RequestMaterializer] = {}
        self.caches: dict[tuple[str, str], C143ClosureCache] = {}
        for method_id in LLM_METHODS:
            config = self.method_config["methods"][method_id]
            prompt_path = self.project_root / config["prompt_protocol_locator"]
            prompt = strict_json(prompt_path)
            prompt_sha = file_sha(prompt_path)
            for arm in ARMS:
                materializer = C143RequestMaterializer(
                    method_id=method_id,
                    arm=arm,
                    base_namespace=config["base_cache_namespace"],
                    method_config_sha256=self.method_config_sha,
                    prompt_protocol_sha256=prompt_sha,
                    provider_config_sha256=self.provider_config_sha,
                )
                session = C143ProviderSession(
                    method_id=method_id,
                    arm=arm,
                    credentials=credentials,
                    protocol=prompt,
                    ledger=self.ledger,
                )
                key = (method_id, arm)
                self.materializers[key] = materializer
                cache = C143ClosureCache(
                    project_root=self.project_root,
                    output_root=self.output_root,
                    method_id=method_id,
                    arm=arm,
                    materializer=materializer,
                    provider_session=session,
                    method_config_sha256=self.method_config_sha,
                    prompt_protocol_sha256=prompt_sha,
                    provider_config_sha256=self.provider_config_sha,
                )
                self.caches[key] = cache
                for prior_record in continuation["responses"][key].values():
                    request_hash = prior_record["request_hash"]
                    retained = cache.responses.get(request_hash)
                    if retained is not None:
                        if retained != prior_record["parsed_response"]:
                            raise C143Error("retained imported cache response drift")
                        continue
                    cache.import_audited_response(prior_record)

    def run(self) -> dict[str, Any]:
        plan = _cache_case_plan()
        progress_path = self.output_root / "causal_case_ledger.json"
        progress_events_path = self.output_root / "causal_case_events.ndjson"
        retained_rows: list[dict[str, Any]] = []
        if progress_path.exists():
            retained = strict_json(progress_path)
            if (
                retained.get("protocol_generation") != PROTOCOL_GENERATION
                or retained.get("rows_sha256") != canonical_sha(retained.get("rows"))
            ):
                raise C143Error("retained C14.3 cache case ledger drift")
            retained_rows = retained["rows"]
        latest = {row["case_id"]: row for row in retained_rows}
        if any(row.get("status") not in {"PASSED", "NO_FRONTIER_COMPLETE"} for row in latest.values()):
            raise C143Error("failed C14.3 cache case cannot be automatically retried")
        rows = list(retained_rows)
        for planned in plan:
            previous = latest.get(planned["case_id"])
            if previous is not None and _phase_a_row_is_complete(previous):
                continue
            key = (planned["method_id"], planned["arm"])
            cache = self.caches[key]
            samples: list[dict[str, Any]] = []
            if planned["method_id"] == "Full":
                lifecycle = strict_json(
                    self.project_root
                    / "protocol/c14/supervisor_lifecycle.C14_1_OFFLINE_CACHE_V2_20260729.json"
                )
                controller = C143DelayedFullController(
                    self.factory.config_sha256,
                    self.factory.config,
                    cache,
                    self.materializers[key],
                    lifecycle,
                    root_case_id=planned["root_case_id"],
                    arm=planned["arm"],
                    profile=self.profile,
                    samples=samples,
                )
            else:
                controller = build_protocol_generation_controller(
                    self.factory,
                    planned["method_id"],
                    cache=cache,
                    materializer=self.materializers[key],
                )
            case = C14MethodCase(
                ordinal=0,
                case_id=planned["case_id"],
                root_case_id=planned["root_case_id"],
                root_namespace=ROOT_NAMESPACE,
                arm=planned["arm"],
                scenario=(
                    "nominal_fixed" if planned["arm"] == "REFERENCE" else "influx_event"
                ),
                method_id=planned["method_id"],
                variant_id="fixed",
                train_seed=None,
                checkpoint_sha256=None,
                checkpoint_locator=None,
                transitions_per_opportunity=(
                    TRANSITIONS_PER_MODEL_DECISION if planned["method_id"] == "Full" else 0
                ),
            )
            meter = _DecisionMeter(controller, case)
            started_at = timestamp()
            misses_before = len(cache.miss_rows)
            lookups_before = cache.lookup_attempts
            source_before = len(cache.source_records)
            tokens_before = sum(record["total_tokens"] for record in cache.source_records)
            try:
                with cache.bind_case(case.case_id):
                    decisions = run_causal_case_without_statistics(
                        build_primary_influx_tape(case.root_case_id, TapeArm(case.arm)), meter
                    )
                misses = len(cache.miss_rows) - misses_before
                provider_calls = len(cache.source_records) - source_before
                lookups = cache.lookup_attempts - lookups_before
                if decisions != meter.decisions or decisions != meter.commitments:
                    raise C143Error("C14.3 causal cache case did not close exactly")
                if decisions > FULL_TAPE_MAX_CONTROL_OPPORTUNITIES_PER_CASE:
                    raise C143Error("C14.3 causal cache opportunity cap exceeded")
                if misses != provider_calls:
                    raise C143Error("C14.3 cache miss/provider accounting drift")
                row = {
                    "schema_version": "exp09-c14-3-cache-causal-case-row-v1",
                    "run_id": f"c14-3-cache__{case.case_id}",
                    "case_id": case.case_id,
                    "root_case_id": case.root_case_id,
                    "method_id": case.method_id,
                    "arm": case.arm,
                    "attempt_ordinal": 0,
                    "status": "PASSED" if lookups else "NO_FRONTIER_COMPLETE",
                    "causal_scope": "FULL_FROZEN_50_SECOND_TAPE",
                    "started_at": started_at,
                    "ended_at": timestamp(),
                    "decision_attempts": decisions,
                    "model_transitions": decisions * case.transitions_per_opportunity,
                    "pre_miss_controller_commitments": meter.commitments,
                    "cache_lookup_attempts": lookups,
                    "cache_misses": misses,
                    "post_miss_controller_commitments": 0,
                    "post_miss_plant_actions": 0,
                    "api_calls": provider_calls,
                    "provider_calls": provider_calls,
                    "llm_tokens": sum(record["total_tokens"] for record in cache.source_records)
                    - tokens_before,
                    "network_attempts": provider_calls,
                    "profile_samples_sha256": canonical_sha(samples),
                    "profile_samples": samples,
                    "error_code": None,
                }
            except BaseException as exc:
                row = {
                    "schema_version": "exp09-c14-3-cache-causal-case-row-v1",
                    "run_id": f"c14-3-cache__{case.case_id}",
                    "case_id": case.case_id,
                    "root_case_id": case.root_case_id,
                    "method_id": case.method_id,
                    "arm": case.arm,
                    "attempt_ordinal": 0,
                    "status": "FAIL_CLOSED",
                    "causal_scope": "FULL_FROZEN_50_SECOND_TAPE",
                    "started_at": started_at,
                    "ended_at": timestamp(),
                    "decision_attempts": meter.decisions,
                    "model_transitions": meter.decisions * case.transitions_per_opportunity,
                    "pre_miss_controller_commitments": meter.commitments,
                    "cache_lookup_attempts": cache.lookup_attempts - lookups_before,
                    "cache_misses": len(cache.miss_rows) - misses_before,
                    "post_miss_controller_commitments": 0,
                    "post_miss_plant_actions": 0,
                    "api_calls": max(
                        len(cache.miss_rows) - misses_before,
                        len(cache.source_records) - source_before,
                    ),
                    "provider_calls": max(
                        len(cache.miss_rows) - misses_before,
                        len(cache.source_records) - source_before,
                    ),
                    "llm_tokens": sum(record["total_tokens"] for record in cache.source_records)
                    - tokens_before,
                    "network_attempts": max(
                        len(cache.miss_rows) - misses_before,
                        len(cache.source_records) - source_before,
                    ),
                    "profile_samples_sha256": canonical_sha(samples),
                    "profile_samples": samples,
                    "error_code": type(exc).__name__,
                }
                rows.append(row)
                append_ndjson(progress_events_path, row)
                self._write_progress(progress_path, rows)
                self._write_fail_close(exc, row)
                raise
            rows.append(row)
            append_ndjson(progress_events_path, row)
            latest[case.case_id] = row
            self._write_progress(progress_path, rows)
        if len(latest) != FRONTIER_CASE_COUNT or any(
            not _phase_a_row_is_complete(row) for row in latest.values()
        ):
            raise C143Error("C14.3 causal cache case coverage is incomplete")
        qualification = self._qualify()
        atomic_write_json(
            self.output_root / "cache_qualification.json",
            qualification,
            replace_existing=False,
        )
        return qualification

    def _write_progress(self, path: Path, rows: list[dict[str, Any]]) -> None:
        usage = self.ledger.usage()
        document = {
            "schema_version": "exp09-c14-3-cache-causal-case-ledger-v1",
            "artifact_status": "C14_3_CACHE_REMEDIATION_RUNTIME_LEDGER",
            "protocol_generation": PROTOCOL_GENERATION,
            "planned_cases": FRONTIER_CASE_COUNT,
            "hard_caps": {
                "provider_calls": PROVIDER_CALL_CAP,
                "api_calls": PROVIDER_CALL_CAP,
                "cost_usd": COST_CAP_USD,
                "concurrency": CACHE_CONCURRENCY,
                "retry": 0,
            },
            "provider_usage": usage,
            "rows_sha256": canonical_sha(rows),
            "rows": rows,
        }
        atomic_write_json(path, document, replace_existing=True)

    def _qualify(self) -> dict[str, Any]:
        if any(row["status"] != "COMPLETED_AUDITED" for row in self.ledger.rows):
            raise C143Error("C14.3 cache qualification requires all provider attempts audited")
        recovery_rows = [
            row
            for row in self.ledger.rows
            if row.get("attempt_kind") == "USER_AUTHORIZED_SINGLE_RECOVERY_REPLAY"
        ]
        if (
            len(recovery_rows) != 1
            or recovery_rows[0].get("request_hash") != RECOVERY_REQUEST_HASH
            or recovery_rows[0].get("status") != "COMPLETED_AUDITED"
        ):
            raise C143Error("C14.3 authorized recovery replay is not uniquely audited")
        namespaces = []
        for method_id in LLM_METHODS:
            for arm in ARMS:
                cache = self.caches[(method_id, arm)]
                cache.audit_complete()
                namespaces.append(
                    {
                        "method_id": method_id,
                        "arm": arm,
                        "namespace": cache.namespace,
                        "request_count": len(cache.materializer.records),
                        "request_inventory_locator": relative(
                            self.project_root, cache._path("request_inventory.json")
                        ),
                        "request_inventory_sha256": file_sha(
                            cache._path("request_inventory.json")
                        ),
                        "response_source_locator": relative(
                            self.project_root, cache._path("response_source.json")
                        ),
                        "response_source_sha256": file_sha(cache._path("response_source.json")),
                        "cache_bundle_locator": relative(
                            self.project_root, cache._path("cache_bundle.json")
                        ),
                        "cache_bundle_sha256": file_sha(cache._path("cache_bundle.json")),
                        "missing": 0,
                        "unexpected": 0,
                        "duplicate": 0,
                        "passed": True,
                    }
                )
        return {
            "schema_version": "exp09-c14-3-cache-qualification-v1",
            "artifact_status": "CACHE_QUALIFIED_FOR_OFFLINE_C14_3_ONLY",
            "protocol_generation": PROTOCOL_GENERATION,
            "passed": True,
            "namespace_count": 4,
            "namespaces_sha256": canonical_sha(namespaces),
            "namespaces": namespaces,
            "provider_cost_ledger_locator": relative(self.project_root, self.ledger.path),
            "provider_cost_ledger_sha256": file_sha(self.ledger.path),
            "provider_events_locator": relative(self.project_root, self.ledger.events_path),
            "provider_events_sha256": file_sha(self.ledger.events_path),
            "continuation_provenance_locator": relative(
                self.project_root, self.output_root / "continuation_provenance.json"
            ),
            "continuation_provenance_sha256": file_sha(
                self.output_root / "continuation_provenance.json"
            ),
            "provider_usage": self.ledger.usage(),
            "recovery_replay": {
                "request_hash": RECOVERY_REQUEST_HASH,
                "prior_unknown_call_id": RECOVERY_PRIOR_CALL_ID,
                "recovery_call_id": recovery_rows[0]["call_id"],
                "attempt_count": 1,
                "status": "COMPLETED_AUDITED",
                "all_other_requests_retry": 0,
            },
            "network_fallback": False,
            "formal_replay_api_calls": 0,
            "api_key_recorded": False,
        }

    def _write_fail_close(self, exc: BaseException, row: dict[str, Any]) -> None:
        path = self.output_root / "FAIL_CLOSED.json"
        if path.exists():
            return
        atomic_write_json(
            path,
            {
                "schema_version": "exp09-c14-3-cache-fail-closed-v1",
                "artifact_status": "C14_3_CACHE_REMEDIATION_FAIL_CLOSED_STOP",
                "protocol_generation": PROTOCOL_GENERATION,
                "recorded_at": timestamp(),
                "error_type": type(exc).__name__,
                "failed_row": row,
                "provider_cost_ledger_sha256": file_sha(self.ledger.path),
                "provider_usage": self.ledger.usage(),
                "response_unknown": isinstance(exc, C143UnknownResponseError),
                "api_key_recorded": False,
                "training": False,
                "shadow_started": False,
                "later_stages": False,
            },
            replace_existing=False,
        )


def generate_remediated_manifest(project_root: Path) -> tuple[Path, str]:
    project_root = Path(project_root).resolve()
    manifest_path = project_root / MANIFEST_LOCATOR
    if manifest_path.exists():
        raise C143Error("append-only remediated C14.3 manifest already exists")
    if file_sha(project_root / ORIGINAL_MANIFEST_LOCATOR) != EXPECTED_ORIGINAL_MANIFEST_SHA256:
        raise C143Error("original C14.3 manifest binding drift")
    if file_sha(project_root / ORIGINAL_FAIL_CLOSE_LOCATOR) != EXPECTED_ORIGINAL_FAIL_CLOSE_SHA256:
        raise C143Error("original C14.3 fail-close binding drift")
    qualification_path = project_root / CACHE_OUTPUT_LOCATOR / "cache_qualification.json"
    qualification = strict_json(qualification_path)
    if qualification.get("passed") is not True:
        raise C143Error("C14.3 cache qualification is not complete")
    profile = strict_json(project_root / PROFILE_CLOSEOUT_LOCATOR)
    latency = profile["distribution"]["latency_ms_sorted"]
    failure = profile["distribution"]["failure_counts"]
    if (
        canonical_sha(latency) != EXPECTED_LATENCY_DISTRIBUTION_SHA256
        or canonical_sha(failure) != EXPECTED_FAILURE_DISTRIBUTION_SHA256
    ):
        raise C143Error("C14.2 empirical distribution binding drift")
    method_config = strict_json(project_root / CONTROLLER_CONFIG_LOCATOR)
    if tuple(item for item in method_config["methods"] if item not in {"DQN_Strong", "KEEP_sanity"}) != METHODS:
        raise C143Error("C14.3 exact method set drift")
    registry = strict_json(project_root / CHECKPOINT_REGISTRY_LOCATOR)
    checkpoint_by_key = {
        (entry["method_id"], entry["train_seed"]): entry
        for entry in registry["entries"]
        if entry["method_id"] in RL_METHODS
    }
    roots = [f"{ROOT_ID_PREFIX}{index:02d}" for index in range(64)]
    cases: list[dict[str, Any]] = []
    for root in roots:
        for arm in ARMS:
            for method_id in METHODS:
                for train_seed in RL_SEEDS if method_id in RL_METHODS else (None,):
                    checkpoint = (
                        checkpoint_by_key[(method_id, train_seed)]
                        if train_seed is not None
                        else None
                    )
                    cases.append(
                        {
                            "ordinal": len(cases),
                            "case_id": (
                                f"{root}__{arm}__{method_id}__"
                                f"{'fixed' if train_seed is None else f'complex_seed{train_seed}'}"
                            ),
                            "root_case_id": root,
                            "root_namespace": ROOT_NAMESPACE,
                            "cell": "NOMINAL" if arm == "REFERENCE" else "HARM",
                            "arm": arm,
                            "scenario": "nominal_fixed" if arm == "REFERENCE" else "influx_event",
                            "method_id": method_id,
                            "variant_id": (
                                "fixed" if train_seed is None else f"complex_seed{train_seed}"
                            ),
                            "train_seed": train_seed,
                            "checkpoint_locator": (
                                None if checkpoint is None else checkpoint["relative_path"]
                            ),
                            "checkpoint_sha256": (
                                None if checkpoint is None else checkpoint["sha256"]
                            ),
                            "transitions_per_opportunity": (
                                TRANSITIONS_PER_MODEL_DECISION
                                if method_id in MODEL_TRANSITION_METHODS
                                else 0
                            ),
                        }
                    )
    if len(cases) != CASE_COUNT:
        raise C143Error("C14.3 case expansion count drift")
    source_bindings = {
        "original_manifest": _binding(project_root, ORIGINAL_MANIFEST_LOCATOR),
        "original_fail_close": _binding(project_root, ORIGINAL_FAIL_CLOSE_LOCATOR),
        "cache_qualification": _binding(
            project_root, relative(project_root, qualification_path)
        ),
        "provider_cost_ledger": _binding(
            project_root, qualification["provider_cost_ledger_locator"]
        ),
        "continuation_provenance": _binding(
            project_root, qualification["continuation_provenance_locator"]
        ),
        "provider_config": _binding(project_root, PROVIDER_CONFIG_LOCATOR),
        "cache_method_config": _binding(project_root, METHOD_CONFIG_LOCATOR),
        "controller_config": _binding(project_root, CONTROLLER_CONFIG_LOCATOR),
        "checkpoint_registry": _binding(project_root, CHECKPOINT_REGISTRY_LOCATOR),
        "profile_injection_protocol": _binding(project_root, PROFILE_PROTOCOL_LOCATOR),
        "c14_2_closeout": _binding(project_root, PROFILE_CLOSEOUT_LOCATOR),
        "full_prompt_protocol": _binding(
            project_root, "protocol/c14/full_protocol.C14_1_OFFLINE_CACHE_V2_20260729.json"
        ),
        "plain_prompt_protocol": _binding(
            project_root,
            "protocol/c14/plain_llm_protocol.C14_1_OFFLINE_CACHE_V2_20260729.json",
        ),
        "supervisor_lifecycle": _binding(
            project_root,
            "protocol/c14/supervisor_lifecycle.C14_1_OFFLINE_CACHE_V2_20260729.json",
        ),
        "shadow_implementation": _binding(
            project_root, "src/exp09/evaluation/c14_3_shadow.py"
        ),
        "network_guard": _binding(project_root, "src/exp09/evaluation/c14_network_guard.py"),
        "controller_implementation": _binding(
            project_root, "src/exp09/evaluation/c14_controllers.py"
        ),
        "protocol_controller_implementation": _binding(
            project_root, "src/exp09/evaluation/c14_protocol_generation.py"
        ),
        "plant_implementation": _binding(project_root, "src/exp09/plant/plant.py"),
        "tape_implementation": _binding(
            project_root, "src/exp09/evaluation/disturbance_tape.py"
        ),
        "metrics_implementation": _binding(
            project_root, "src/exp09/evaluation/metrics_accumulator.py"
        ),
    }
    namespace_bindings = {}
    for namespace in qualification["namespaces"]:
        stem = f"{namespace['method_id'].lower()}_{namespace['arm'].lower()}"
        namespace_bindings[f"{stem}_request_inventory"] = _binding(
            project_root, namespace["request_inventory_locator"]
        )
        namespace_bindings[f"{stem}_response_source"] = _binding(
            project_root, namespace["response_source_locator"]
        )
        namespace_bindings[f"{stem}_cache_bundle"] = _binding(
            project_root, namespace["cache_bundle_locator"]
        )
    source_bindings.update(namespace_bindings)
    document = {
        "schema_version": "exp09-c14-3-shadow-manifest-v2",
        "artifact_status": "FROZEN_HASH_BOUND_ONE_SHOT_EXECUTABLE_REMEDIATION",
        "stage": "C14.3_SHADOW",
        "protocol_generation": PROTOCOL_GENERATION,
        "authorization": {
            "execution": True,
            "closeout": True,
            "api_provider_llm_calls_during_shadow": False,
            "training": False,
            "automatic_c14_4_or_c15": False,
            "git_operations": False,
        },
        "scope": {
            "root_family_count": 64,
            "root_namespace": ROOT_NAMESPACE,
            "roots": roots,
            "roots_sha256": canonical_sha(roots),
            "cells": {"NOMINAL": "ENABLED", "HARM": "ENABLED", "DEPLOYMENT": "DISABLED"},
            "deployment_claim": False,
            "g6_assessment": False,
            "dqn_strong_stretch": False,
            "methods": list(METHODS),
            "method_set_sha256": canonical_sha(list(METHODS)),
            "excluded_methods": {
                "DQN_Strong": "G6_STRETCH_DISABLED",
                "KEEP_sanity": "DEVELOPMENT_SANITY_NOT_MINIMUM_SHADOW_REGISTRY",
            },
            "rl_train_seeds": list(RL_SEEDS),
            "case_count": CASE_COUNT,
            "cases_sha256": canonical_sha(cases),
            "cases": cases,
        },
        "profile_binding": {
            "latency_distribution_hash": EXPECTED_LATENCY_DISTRIBUTION_SHA256,
            "failure_distribution_hash": EXPECTED_FAILURE_DISTRIBUTION_SHA256,
            "latency_sample_count": {task: len(values) for task, values in latency.items()},
            "failure_counts": failure,
            "content_isolation_methods": list(SAME_STACK_METHODS),
            "content_isolation_task": "ProgramProposal",
            "plain_llm_profile_mode": "DIAGNOSTIC_REQUEST_LATENCY_ATTACHMENT_ONLY",
            "deployment_cell_disabled": True,
        },
        "success_failure_rule": {
            "success": "all 2304 cases pass; all 128 root/cell groups are complete; no drift, forbidden activity, timeout, integrity error, or budget breach",
            "failure": "any case failure, timeout, missing/duplicate/unexpected row, non-finite value, leakage, hash/config/schema/provenance drift, budget breach, or forbidden API/network/training activity",
            "abort_threshold_failures": 1,
            "abort_threshold_timeouts": 1,
            "performance_gate": "NOT_ASSESSABLE_UNDER_AD06B_NO_MARGIN",
        },
        "timeouts_and_abort": {
            "per_case_timeout_seconds": 900,
            "global_wall_seconds": SHADOW_WALL_SECONDS_CAP,
            "retry": 0,
            "resume_after_process_interruption": False,
        },
        "budget": {
            "global": {
                "method_cases": CASE_COUNT,
                "environment_steps": SHADOW_ENVIRONMENT_STEPS_CAP,
                "model_transitions": SHADOW_MODEL_TRANSITIONS_CAP,
                "cpu_core_seconds": SHADOW_CPU_SECONDS_CAP,
                "wall_seconds": SHADOW_WALL_SECONDS_CAP,
                "storage_bytes": SHADOW_STORAGE_CAP,
                "concurrency": SHADOW_CONCURRENCY,
                "gpu_seconds": 0,
                "api_calls": 0,
                "provider_calls": 0,
                "llm_tokens": 0,
                "cost_usd": 0,
            },
            "phase": {
                "C14.3_SHADOW": "100_PERCENT_OF_GLOBAL_CAPS",
                "C14.4_AND_C15": "ZERO_NOT_AUTHORIZED",
            },
        },
        "rules": {
            "append_only": True,
            "one_shot": True,
            "no_retune": True,
            "no_result_driven_expansion": True,
            "no_method_or_root_filtering": True,
            "no_margin_selection_or_inference": True,
            "no_api_network_provider_fallback": True,
            "no_training": True,
            "exposed_roots_never_reused": True,
        },
        "claim_boundary": {
            "o08_route": "AD-06B:EFFECT_AND_CI_DOWNGRADE",
            "allowed": [
                "absolute effect estimate",
                "adjusted/simultaneous CI",
                "adjusted p-value",
                "descriptive endpoint report",
            ],
            "forbidden": [
                "numerical practical margin",
                "superiority",
                "non-inferiority",
                "non-harm",
                "fairness improvement",
                "all-baseline-best",
                "adds-value",
                "comparable/equivalent",
                "Locked Test conclusion",
                "deployment claim",
            ],
            "shadow_is_internal_cost_direction_gate_only": True,
            "paper_performance_claim_allowed": False,
        },
        "source_bindings": source_bindings,
    }
    sha = atomic_write_json(manifest_path, document, replace_existing=False)
    return manifest_path, sha


def _binding(project_root: Path, locator: str) -> dict[str, str]:
    path = (project_root / locator).resolve()
    if not path.is_relative_to(project_root) or not path.is_file():
        raise C143Error(f"source binding is missing or escapes the project: {locator}")
    return {"locator": locator, "sha256": file_sha(path)}


class EmpiricalProfile:
    def __init__(self, project_root: Path, manifest: dict[str, Any]) -> None:
        closeout = strict_json(project_root / PROFILE_CLOSEOUT_LOCATOR)
        self.latency = closeout["distribution"]["latency_ms_sorted"]
        self.failure = closeout["distribution"]["failure_counts"]
        profile = manifest["profile_binding"]
        if (
            canonical_sha(self.latency) != profile["latency_distribution_hash"]
            or canonical_sha(self.failure) != profile["failure_distribution_hash"]
            or profile["latency_distribution_hash"] != EXPECTED_LATENCY_DISTRIBUTION_SHA256
            or profile["failure_distribution_hash"] != EXPECTED_FAILURE_DISTRIBUTION_SHA256
        ):
            raise C143Error("C14.3 empirical profile binding drift")

    def sample(self, *, task: str, root_case_id: str, arm: str, trigger_slot_id: int) -> dict[str, Any]:
        values = self.latency.get(task)
        failures = self.failure.get(task)
        if not isinstance(values, list) or not values or not isinstance(failures, dict):
            raise C143Error("C14.3 empirical profile task is unavailable")
        key = {
            "protocol_generation": PROTOCOL_GENERATION,
            "root_case_id": root_case_id,
            "arm": arm,
            "trigger_slot_id": trigger_slot_id,
            "task": task,
        }
        digest = hashlib.sha256(canonical_bytes(key)).digest()
        latency_index = int.from_bytes(digest[:8], "big") % len(values)
        total = sum(int(count) for count in failures.values())
        failure_index = int.from_bytes(digest[8:16], "big") % total
        category = None
        cursor = 0
        for name, count in sorted(failures.items()):
            cursor += int(count)
            if failure_index < cursor:
                category = name
                break
        if category is None:
            raise C143Error("C14.3 empirical failure sample selection drift")
        return {
            "task": task,
            "key_sha256": canonical_sha(key),
            "trigger_slot_id": trigger_slot_id,
            "latency_index": latency_index,
            "latency_ms": int(values[latency_index]),
            "failure_index": failure_index,
            "failure_category": category,
            "success": category == "NONE",
        }


class C143DelayedFullController(CorrectedFullController):
    def __init__(
        self,
        *args: Any,
        root_case_id: str,
        arm: str,
        profile: EmpiricalProfile,
        samples: list[dict[str, Any]],
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        self._shadow_root_case_id = root_case_id
        self._shadow_arm = arm
        self._shadow_profile = profile
        self._shadow_samples = samples
        self._shadow_next_receipt: tuple[int, bool] | None = None

    def reset(self, context: Any) -> None:
        super().reset(context)
        self._shadow_next_receipt = None

    def _response_receipt(self, frame: Any, opportunity: Any) -> tuple[int, int, bool]:
        if self._shadow_next_receipt is None:
            raise C143Error("profiled response receipt was not sampled")
        latency_ms, success = self._shadow_next_receipt
        self._shadow_next_receipt = None
        received_at_us = int(opportunity.time_us) + latency_ms * 1000
        received_source_sequence = max(
            int(frame.source_sequence),
            max(0, received_at_us - MEASUREMENT_DELAY_US) // SUMMARY_PERIOD_US,
        )
        return (
            received_at_us,
            received_source_sequence,
            success,
        )

    def _provider_triggered(self, evidence: Any, eligible: Any, opportunity: Any) -> bool:
        triggered = super()._provider_triggered(evidence, eligible, opportunity)
        if triggered:
            trigger_slot_id = int(opportunity.time_us)
            sample = self._shadow_profile.sample(
                task="ProgramProposal",
                root_case_id=self._shadow_root_case_id,
                arm=self._shadow_arm,
                trigger_slot_id=trigger_slot_id,
            )
            self._shadow_samples.append(sample)
            self._shadow_next_receipt = (
                int(sample["latency_ms"]),
                bool(sample["success"]),
            )
        return triggered


class C143DeterministicProposalCache:
    """Map the same Full request payload to Rule/Tuned proposal content offline."""

    method_id = "Full"

    def __init__(self, materializer: C143RequestMaterializer, method_id: str) -> None:
        if method_id not in {"Rule_SameStack", "TunedNonLLM_SameStack"}:
            raise C143Error("deterministic proposal cache method drift")
        self.materializer = materializer
        self.deterministic_method_id = method_id
        self.namespace = materializer.namespace
        self.bundle_sha256 = canonical_sha(
            {"protocol_generation": PROTOCOL_GENERATION, "method_id": method_id}
        )

    def response_for(self, request_hash: str) -> dict[str, Any]:
        matches = [
            record for record in self.materializer.records if record.request_hash == request_hash
        ]
        if len(matches) != 1:
            raise C143Error("deterministic proposal cache request binding drift")
        payload = matches[0].model_payload
        evidence = payload["evidence"]
        active = (
            bool(evidence["detector_active"])
            if self.deterministic_method_id == "Rule_SameStack"
            else int(evidence["risk_ppm"]) >= 500_000
        )
        eligible = payload["eligible_proposals"]
        selected = next(
            (
                item
                for item in eligible
                if active and item["transition_id"] != TransitionId.HOLD.value
            ),
            next(
                (item for item in eligible if item["transition_id"] == TransitionId.HOLD.value),
                None,
            ),
        )
        if selected is None:
            raise C143Error("deterministic proposal cache has no eligible proposal")
        proposal = ProgramProposal(
            schema_version=PROGRAM_PROPOSAL_SCHEMA_VERSION,
            transition_id=TransitionId(selected["transition_id"]),
            target_program_id=(
                None
                if selected["target_program_id"] is None
                else ProgramId(selected["target_program_id"])
            ),
            rationale_code=(
                RationaleCode.EVIDENCE_SUPPORTED_TRANSITION
                if selected["transition_id"] != TransitionId.HOLD.value
                else RationaleCode.HOLD_UNCERTAIN_EVIDENCE
            ),
        )
        return {
            "proposal": {
                "transition_id": proposal.transition_id.value,
                "target_program_id": (
                    None if proposal.target_program_id is None else str(proposal.target_program_id)
                ),
                "rationale_code": proposal.rationale_code.value,
            },
            "response_hash": provider_response_hash(request_hash, proposal),
        }


@dataclass(frozen=True, slots=True)
class ShadowBudgetUsage:
    method_cases: int = 0
    environment_steps: int = 0
    model_transitions: int = 0
    cpu_core_seconds: int = 0
    wall_seconds: int = 0
    storage_bytes: int = 0
    concurrency: int = 0
    gpu_seconds: int = 0
    api_calls: int = 0
    provider_calls: int = 0
    llm_tokens: int = 0

    def plus(self, other: ShadowBudgetUsage) -> ShadowBudgetUsage:
        return ShadowBudgetUsage(
            **{
                field: getattr(self, field) + getattr(other, field)
                for field in self.__dataclass_fields__
            }
        )


class ShadowBudget:
    def __init__(self) -> None:
        self.caps = ShadowBudgetUsage(
            method_cases=CASE_COUNT,
            environment_steps=SHADOW_ENVIRONMENT_STEPS_CAP,
            model_transitions=SHADOW_MODEL_TRANSITIONS_CAP,
            cpu_core_seconds=SHADOW_CPU_SECONDS_CAP,
            wall_seconds=SHADOW_WALL_SECONDS_CAP,
            storage_bytes=SHADOW_STORAGE_CAP,
            concurrency=SHADOW_CONCURRENCY,
        )
        self.usage = ShadowBudgetUsage()
        self._lock = RLock()

    def charge(self, delta: ShadowBudgetUsage) -> None:
        with self._lock:
            candidate = self.usage.plus(delta)
            for field in candidate.__dataclass_fields__:
                if getattr(candidate, field) > getattr(self.caps, field):
                    raise C143Error(f"C14.3 shadow hard budget exceeded: {field}")
            self.usage = candidate

    def set_elapsed_wall_seconds(self, elapsed_seconds: int) -> None:
        """Record elapsed attempt wall time without summing concurrent case time.

        Case rows retain their individual wall_seconds for diagnostics, while the
        global hard cap is charged from the single elapsed attempt clock.  This
        mode is enabled only by an explicit hash-bound continuation manifest.
        """
        value = max(0, int(elapsed_seconds))
        with self._lock:
            if value > self.caps.wall_seconds:
                raise C143Error("C14.3 shadow hard budget exceeded: wall_seconds")
            if value < self.usage.wall_seconds:
                return
            self.usage = replace(self.usage, wall_seconds=value)

    def enter(self) -> None:
        self.charge(ShadowBudgetUsage(concurrency=1))

    def exit(self) -> None:
        with self._lock:
            if self.usage.concurrency <= 0:
                raise C143Error("C14.3 concurrency accounting drift")
            self.usage = replace(self.usage, concurrency=self.usage.concurrency - 1)


class DecisionMeter:
    def __init__(self, controller: Any, transitions_per_opportunity: int) -> None:
        self.controller = controller
        self.transitions_per_opportunity = transitions_per_opportunity
        self.environment_steps = 0
        self.model_transitions = 0

    def reset(self, context: Any) -> None:
        self.controller.reset(context)

    def decide(self, frame: Any, opportunity: Any) -> Any:
        self.environment_steps += 1
        self.model_transitions += self.transitions_per_opportunity
        return self.controller.decide(frame, opportunity)


class C143ShadowExecutor:
    def __init__(self, project_root: Path, *, expected_manifest_sha256: str) -> None:
        self.project_root = Path(project_root).resolve()
        self.manifest_path = self.project_root / MANIFEST_LOCATOR
        if file_sha(self.manifest_path) != expected_manifest_sha256:
            raise C143Error("C14.3 remediated manifest hash drift")
        self.manifest = strict_json(self.manifest_path)
        if (
            self.manifest.get("artifact_status")
            != "FROZEN_HASH_BOUND_ONE_SHOT_EXECUTABLE_REMEDIATION"
            or self.manifest.get("authorization", {}).get("execution") is not True
            or self.manifest.get("authorization", {}).get("api_provider_llm_calls_during_shadow")
            is not False
        ):
            raise C143Error("C14.3 remediated manifest is not executable offline")
        self._verify_bindings()
        self.topology = load_manifest_topology(self.project_root, self.manifest_path)
        self.output_root = self.project_root / SHADOW_OUTPUT_LOCATOR
        if self.output_root.exists():
            raise C143Error("append-only C14.3 shadow attempt already exists")
        self.output_root.mkdir(parents=True, exist_ok=False)
        self.runs_root = self.output_root / "runs"
        self.cas_root = self.output_root / "cas"
        self.runs_root.mkdir()
        self.cas_root.mkdir()
        self.cas_lock = RLock()
        self.factory = C14ControllerFactory(
            self.project_root,
            self.topology.method_config_locator,
            expected_config_sha256=self.topology.method_config_sha256,
        )
        self.profile = EmpiricalProfile(self.project_root, self.manifest)
        self.budget = ShadowBudget()
        self._elapsed_wall_mode = (
            self.manifest.get("budget", {}).get("global", {}).get("wall_accounting")
            == "ELAPSED_ATTEMPT"
        )
        self._initial_elapsed_wall_seconds = 0
        self._attempt_wall_started: float | None = None
        self.stop = Event()
        self.rows: list[dict[str, Any]] = []
        self.case_events_path = self.output_root / "case_events.ndjson"
        self.rows_lock = RLock()
        self.replay_caches: dict[tuple[str, str], C143QualifiedReplayCache] = {}
        self.materializer_templates: dict[tuple[str, str], C143RequestMaterializer] = {}
        self._load_replay_caches()
        self.registry = strict_json(self.project_root / CHECKPOINT_REGISTRY_LOCATOR)

    def _verify_bindings(self) -> None:
        bindings = self.manifest.get("source_bindings")
        if not isinstance(bindings, dict) or not bindings:
            raise C143Error("C14.3 source bindings are missing")
        for name, binding in bindings.items():
            if not isinstance(binding, dict) or set(binding) != {"locator", "sha256"}:
                raise C143Error(f"C14.3 malformed source binding: {name}")
            path = (self.project_root / binding["locator"]).resolve()
            if not path.is_relative_to(self.project_root) or file_sha(path) != binding["sha256"]:
                raise C143Error(f"C14.3 source binding drift: {name}")

    def _load_replay_caches(self) -> None:
        cache_method = strict_json(self.project_root / METHOD_CONFIG_LOCATOR)
        method_sha = file_sha(self.project_root / METHOD_CONFIG_LOCATOR)
        provider_sha = file_sha(self.project_root / PROVIDER_CONFIG_LOCATOR)
        for method_id in LLM_METHODS:
            config = cache_method["methods"][method_id]
            prompt_sha = file_sha(self.project_root / config["prompt_protocol_locator"])
            for arm in ARMS:
                materializer = C143RequestMaterializer(
                    method_id=method_id,
                    arm=arm,
                    base_namespace=config["base_cache_namespace"],
                    method_config_sha256=method_sha,
                    prompt_protocol_sha256=prompt_sha,
                    provider_config_sha256=provider_sha,
                )
                cache = C143ClosureCache(
                    project_root=self.project_root,
                    output_root=self.project_root / CACHE_OUTPUT_LOCATOR,
                    method_id=method_id,
                    arm=arm,
                    materializer=materializer,
                    provider_session=_FormalOnlyProviderSession(None),
                    method_config_sha256=method_sha,
                    prompt_protocol_sha256=prompt_sha,
                    provider_config_sha256=provider_sha,
                )
                self.replay_caches[(method_id, arm)] = C143QualifiedReplayCache(cache)
                self.materializer_templates[(method_id, arm)] = materializer

    def run(self) -> dict[str, Any]:
        self._attempt_wall_started = time.monotonic()
        self._write_runtime_ledger()

        def execute(case: C14MethodCase) -> None:
            if self.stop.is_set():
                return
            self.budget.enter()
            started_at = timestamp()
            wall_started = time.monotonic()
            # Each case runs in a worker thread. Process CPU time is shared by all
            # workers and would therefore be counted once per concurrent case.
            cpu_started = time.thread_time()
            meter: DecisionMeter | None = None
            try:
                with NoNetworkGuard():
                    controller, samples = self._controller_for(case)
                    meter = DecisionMeter(controller, case.transitions_per_opportunity)
                    result = run_case(
                        build_primary_influx_tape(case.root_case_id, TapeArm(case.arm)),
                        controller=meter,
                    )
                wall_seconds = math.ceil(time.monotonic() - wall_started)
                cpu_seconds = math.ceil(time.thread_time() - cpu_started)
                artifact = self._write_case_artifact(
                    case,
                    result,
                    samples,
                    mechanism=(
                        controller.mechanism_snapshot()
                        if isinstance(controller, CorrectedFullController)
                        else None
                    ),
                )
                usage = ShadowBudgetUsage(
                    method_cases=1,
                    environment_steps=meter.environment_steps,
                    model_transitions=meter.model_transitions,
                    cpu_core_seconds=cpu_seconds,
                    wall_seconds=0 if self._elapsed_wall_mode else wall_seconds,
                    storage_bytes=artifact["storage_bytes"],
                )
                self.budget.charge(usage)
                if self._elapsed_wall_mode and self._attempt_wall_started is not None:
                    self.budget.set_elapsed_wall_seconds(
                        self._initial_elapsed_wall_seconds
                        + math.ceil(time.monotonic() - self._attempt_wall_started)
                    )
                row = self._row(
                    case,
                    status="PASSED",
                    started_at=started_at,
                    ended_at=timestamp(),
                    meter=meter,
                    cpu_seconds=cpu_seconds,
                    wall_seconds=wall_seconds,
                    artifact=artifact,
                    error_code=None,
                    abort_reason=None,
                )
            except BaseException as exc:
                self.stop.set()
                row = self._row(
                    case,
                    status="FAIL_CLOSED",
                    started_at=started_at,
                    ended_at=timestamp(),
                    meter=meter,
                    cpu_seconds=math.ceil(time.thread_time() - cpu_started),
                    wall_seconds=math.ceil(time.monotonic() - wall_started),
                    artifact=None,
                    error_code=type(exc).__name__,
                    abort_reason=str(exc),
                )
                with self.rows_lock:
                    self.rows.append(row)
                    append_ndjson(self.case_events_path, row)
                    self._write_runtime_ledger()
                raise
            finally:
                self.budget.exit()
            with self.rows_lock:
                if self._elapsed_wall_mode and self._attempt_wall_started is not None:
                    self.budget.set_elapsed_wall_seconds(
                        self._initial_elapsed_wall_seconds
                        + math.ceil(time.monotonic() - self._attempt_wall_started)
                    )
                self.rows.append(row)
                append_ndjson(self.case_events_path, row)
                self._write_runtime_ledger()

        with ThreadPoolExecutor(
            max_workers=SHADOW_CONCURRENCY, thread_name_prefix="c14-3-shadow-case"
        ) as executor:
            iterator = iter(self.topology.cases)
            futures = {
                executor.submit(execute, case)
                for case in (next(iterator, None) for _ in range(SHADOW_CONCURRENCY))
                if case is not None
            }
            while futures:
                done, futures = wait(futures, return_when=FIRST_COMPLETED)
                for future in done:
                    future.result()
                    if not self.stop.is_set():
                        case = next(iterator, None)
                        if case is not None:
                            futures.add(executor.submit(execute, case))
        if self._elapsed_wall_mode and self._attempt_wall_started is not None:
            self.budget.set_elapsed_wall_seconds(
                self._initial_elapsed_wall_seconds
                + math.ceil(time.monotonic() - self._attempt_wall_started)
            )
        return self.closeout()

    def _controller_for(self, case: C14MethodCase) -> tuple[Any, list[dict[str, Any]]]:
        samples: list[dict[str, Any]] = []
        if case.method_id == "Full":
            key = (case.method_id, case.arm)
            template = self.materializer_templates[key]
            materializer = C143RequestMaterializer(
                method_id="Full",
                arm=case.arm,
                base_namespace=template.namespace.rsplit("--", 1)[0],
                method_config_sha256=template.method_config_sha256,
                prompt_protocol_sha256=template.prompt_protocol_sha256,
                provider_config_sha256=template.provider_config_sha256,
            )
            lifecycle = strict_json(
                self.project_root
                / "protocol/c14/supervisor_lifecycle.C14_1_OFFLINE_CACHE_V2_20260729.json"
            )
            controller = C143DelayedFullController(
                self.factory.config_sha256,
                self.factory.config,
                self.replay_caches[key],
                materializer,
                lifecycle,
                root_case_id=case.root_case_id,
                arm=case.arm,
                profile=self.profile,
                samples=samples,
            )
            return controller, samples
        if case.method_id == "Plain_LLM":
            key = (case.method_id, case.arm)
            template = self.materializer_templates[key]
            materializer = C143RequestMaterializer(
                method_id="Plain_LLM",
                arm=case.arm,
                base_namespace=template.namespace.rsplit("--", 1)[0],
                method_config_sha256=template.method_config_sha256,
                prompt_protocol_sha256=template.prompt_protocol_sha256,
                provider_config_sha256=template.provider_config_sha256,
            )
            controller = build_protocol_generation_controller(
                self.factory,
                "Plain_LLM",
                cache=self.replay_caches[key],
                materializer=materializer,
            )
            return C143PlainDiagnosticController(
                controller,
                root_case_id=case.root_case_id,
                arm=case.arm,
                profile=self.profile,
                samples=samples,
            ), samples
        if case.method_id in {"Rule_SameStack", "TunedNonLLM_SameStack"}:
            template = self.materializer_templates[("Full", case.arm)]
            materializer = C143RequestMaterializer(
                method_id="Full",
                arm=case.arm,
                base_namespace=(
                    f"exp09-c14-3-{case.method_id.lower()}-content-isolation-v1"
                ),
                method_config_sha256=template.method_config_sha256,
                prompt_protocol_sha256=template.prompt_protocol_sha256,
                provider_config_sha256=template.provider_config_sha256,
            )
            lifecycle = strict_json(
                self.project_root
                / "protocol/c14/supervisor_lifecycle.C14_1_OFFLINE_CACHE_V2_20260729.json"
            )
            deterministic_cache = C143DeterministicProposalCache(
                materializer, case.method_id
            )
            controller = C143DelayedFullController(
                self.factory.config_sha256,
                self.factory.config,
                deterministic_cache,
                materializer,
                lifecycle,
                root_case_id=case.root_case_id,
                arm=case.arm,
                profile=self.profile,
                samples=samples,
            )
            return controller, samples
        if case.train_seed is None:
            return self.factory.build_non_rl(case.method_id), samples
        matched = [
            entry
            for entry in self.registry["entries"]
            if entry["method_id"] == case.method_id
            and entry["train_seed"] == case.train_seed
        ]
        if len(matched) != 1 or matched[0]["sha256"] != case.checkpoint_sha256:
            raise C143Error("C14.3 RL checkpoint registry binding drift")
        return self.factory.build_rl(case.method_id, case.train_seed, matched[0]), samples

    def _write_case_artifact(
        self,
        case: C14MethodCase,
        result: RunResult,
        samples: list[dict[str, Any]],
        *,
        mechanism: dict[str, Any] | None,
    ) -> dict[str, Any]:
        raw_bytes = canonical_bytes(asdict(result.raw_trace))
        metrics_bytes = canonical_bytes(asdict(result.metrics))
        action_sequence = [
            {
                "time_us": int(item.time_us),
                "opportunity_id": str(item.opportunity_id),
                "kind": item.kind,
                "target_rri_us": item.target_rri_us,
            }
            for item in result.raw_trace.actions
        ]
        blob_records = {}
        storage_bytes = 0
        for name, payload in (("raw_run.json", raw_bytes), ("metrics_case.json", metrics_bytes)):
            digest = hashlib.sha256(payload).hexdigest().upper()
            compressed = gzip.compress(payload, compresslevel=9, mtime=0)
            path = self.cas_root / digest[:2] / f"{digest}.json.gz"
            # Multiple cases can legitimately produce the same content-addressed
            # blob. Serialize create-or-verify so identical writers reuse it and
            # a real byte mismatch still fails closed as a collision.
            with self.cas_lock:
                if not path.exists():
                    path.parent.mkdir(parents=True, exist_ok=True)
                    with path.open("xb") as stream:
                        stream.write(compressed)
                    storage_bytes += len(compressed)
                elif path.read_bytes() != compressed:
                    raise C143Error("C14.3 CAS blob collision")
            blob_records[name] = {
                "canonical_sha256": digest,
                "canonical_size_bytes": len(payload),
                "compressed_sha256": hashlib.sha256(compressed).hexdigest().upper(),
                "compressed_size_bytes": len(compressed),
                "locator": relative(self.project_root, path),
            }
        case_root = self.runs_root / case.case_id
        if case_root.exists():
            raise C143Error("C14.3 one-shot case artifact already exists")
        case_root.mkdir(parents=True)
        document = {
            "schema_version": "exp09-c14-3-shadow-case-artifact-v1",
            "protocol_generation": PROTOCOL_GENERATION,
            "case_id": case.case_id,
            "root_case_id": case.root_case_id,
            "arm": case.arm,
            "method_id": case.method_id,
            "variant_id": case.variant_id,
            "train_seed": case.train_seed,
            "checkpoint_sha256": case.checkpoint_sha256,
            "result_integrity_hash": result.integrity_hash,
            "metrics_sha256": hashlib.sha256(metrics_bytes).hexdigest().upper(),
            "action_count": len(action_sequence),
            "action_sequence_sha256": canonical_sha(action_sequence),
            "profile_samples_sha256": canonical_sha(samples),
            "profile_samples": samples,
            "mechanism_evidence_sha256": (
                None if mechanism is None else canonical_sha(mechanism)
            ),
            "mechanism_evidence": mechanism,
            "profile_control_application": (
                "CONTENT_ISOLATION_DELAY_FAILURE"
                if case.method_id in SAME_STACK_METHODS
                else (
                    "DIAGNOSTIC_ONLY" if case.method_id == "Plain_LLM" else "NOT_APPLICABLE"
                )
            ),
            "blobs": blob_records,
            "api_calls": 0,
            "provider_calls": 0,
            "llm_tokens": 0,
            "network_fallback": False,
        }
        artifact_path = case_root / "case_artifact.json"
        sha = atomic_write_json(artifact_path, document, replace_existing=False)
        storage_bytes += artifact_path.stat().st_size
        return {
            "locator": relative(self.project_root, artifact_path),
            "sha256": sha,
            "storage_bytes": storage_bytes,
            "result_integrity_hash": result.integrity_hash,
        }

    def _row(
        self,
        case: C14MethodCase,
        *,
        status: str,
        started_at: str,
        ended_at: str,
        meter: DecisionMeter | None,
        cpu_seconds: int,
        wall_seconds: int,
        artifact: dict[str, Any] | None,
        error_code: str | None,
        abort_reason: str | None,
    ) -> dict[str, Any]:
        return {
            "schema_version": "exp09-c14-3-shadow-case-ledger-row-v1",
            "ordinal": case.ordinal,
            "case_id": case.case_id,
            "root_case_id": case.root_case_id,
            "root_namespace": case.root_namespace,
            "cell": "NOMINAL" if case.arm == "REFERENCE" else "HARM",
            "arm": case.arm,
            "scenario": case.scenario,
            "method_id": case.method_id,
            "variant_id": case.variant_id,
            "train_seed": case.train_seed,
            "checkpoint_sha256": case.checkpoint_sha256,
            "status": status,
            "started_at": started_at,
            "ended_at": ended_at,
            "environment_steps": 0 if meter is None else meter.environment_steps,
            "model_transitions": 0 if meter is None else meter.model_transitions,
            "api_calls": 0,
            "provider_calls": 0,
            "llm_tokens": 0,
            "gpu_seconds": 0,
            "cpu_core_seconds": cpu_seconds,
            "wall_seconds": wall_seconds,
            "storage_bytes": 0 if artifact is None else artifact["storage_bytes"],
            "artifact_locator": None if artifact is None else artifact["locator"],
            "artifact_sha256": None if artifact is None else artifact["sha256"],
            "result_integrity_hash": (
                None if artifact is None else artifact["result_integrity_hash"]
            ),
            "error_code": error_code,
            "abort_reason": abort_reason,
        }

    def _write_runtime_ledger(self) -> None:
        rows = sorted(self.rows, key=lambda row: row["ordinal"])
        document = {
            "schema_version": "exp09-c14-3-shadow-case-ledger-v1",
            "artifact_status": "C14_3_SHADOW_RUNTIME_APPEND_PRESERVING",
            "protocol_generation": PROTOCOL_GENERATION,
            "manifest_sha256": file_sha(self.manifest_path),
            "planned_method_cases": CASE_COUNT,
            "budget_caps": asdict(self.budget.caps),
            "budget_usage": asdict(self.budget.usage),
            "rows_sha256": canonical_sha(rows),
            "rows": rows,
        }
        atomic_write_json(
            self.output_root / "case_ledger.json", document, replace_existing=True
        )

    def closeout(self) -> dict[str, Any]:
        rows = sorted(self.rows, key=lambda row: row["ordinal"])
        if len(rows) != CASE_COUNT or tuple(row["ordinal"] for row in rows) != tuple(
            range(CASE_COUNT)
        ):
            raise C143Error("C14.3 closeout case coverage is incomplete")
        if any(row["status"] != "PASSED" for row in rows):
            raise C143Error("C14.3 closeout contains failed method cases")
        groups = []
        for root in self.manifest["scope"]["roots"]:
            for arm in ARMS:
                group_rows = [
                    row for row in rows if row["root_case_id"] == root and row["arm"] == arm
                ]
                if len(group_rows) != 18:
                    raise C143Error("C14.3 root/cell group coverage drift")
                groups.append(
                    {
                        "root_case_id": root,
                        "cell": "NOMINAL" if arm == "REFERENCE" else "HARM",
                        "arm": arm,
                        "case_count": len(group_rows),
                        "status": "COMPLETE",
                        "case_rows_sha256": canonical_sha(group_rows),
                    }
                )
        root_ledger = {
            "schema_version": "exp09-c14-3-root-cell-ledger-v1",
            "artifact_status": "ALL_ROOT_CELL_GROUPS_COMPLETE",
            "group_count": len(groups),
            "rows_sha256": canonical_sha(groups),
            "rows": groups,
        }
        atomic_write_json(
            self.output_root / "root_cell_ledger.json",
            root_ledger,
            replace_existing=False,
        )
        endpoints = self._descriptive_endpoints(rows)
        atomic_write_json(
            self.output_root / "descriptive_endpoints.json",
            endpoints,
            replace_existing=False,
        )
        closeout = {
            "schema_version": "exp09-c14-3-shadow-closeout-v2",
            "artifact_status": "C14_3_SHADOW_COMPLETE_EVIDENCE_FROZEN_STOP",
            "recorded_at": timestamp(),
            "stage": "C14.3_SHADOW",
            "protocol_generation": PROTOCOL_GENERATION,
            "manifest_binding": {
                "locator": MANIFEST_LOCATOR,
                "sha256": file_sha(self.manifest_path),
            },
            "scope": {
                "root_family_count": 64,
                "root_cell_group_count": 128,
                "method_cases_planned": CASE_COUNT,
                "method_cases_passed": CASE_COUNT,
                "method_cases_failed": 0,
                "methods": list(METHODS),
                "cells": {"NOMINAL": "ENABLED", "HARM": "ENABLED", "DEPLOYMENT": "DISABLED"},
            },
            "profile_binding": {
                "latency_distribution_hash": EXPECTED_LATENCY_DISTRIBUTION_SHA256,
                "failure_distribution_hash": EXPECTED_FAILURE_DISTRIBUTION_SHA256,
                "content_isolation_applied_to": list(SAME_STACK_METHODS),
                "plain_llm_profile_mode": "DIAGNOSTIC_REQUEST_LATENCY_ATTACHMENT_ONLY",
                "deployment_cell_executed": False,
                "deployment_claim_allowed": False,
            },
            "budget": {
                "caps": asdict(self.budget.caps),
                "usage": asdict(self.budget.usage),
                "within_caps": True,
                "api_calls": 0,
                "provider_calls": 0,
                "llm_tokens": 0,
                "gpu_seconds": 0,
                "training": False,
            },
            "success_failure": {
                "shadow_success": True,
                "shadow_failure": False,
                "performance_gate": "NOT_ASSESSABLE_UNDER_AD06B_NO_MARGIN",
                "performance_claim_generated": False,
                "locked_test_conclusion_generated": False,
            },
            "bindings": {
                "case_ledger_sha256": file_sha(self.output_root / "case_ledger.json"),
                "root_cell_ledger_sha256": file_sha(
                    self.output_root / "root_cell_ledger.json"
                ),
                "descriptive_endpoints_sha256": file_sha(
                    self.output_root / "descriptive_endpoints.json"
                ),
                "cache_qualification_sha256": file_sha(
                    self.project_root / CACHE_OUTPUT_LOCATOR / "cache_qualification.json"
                ),
            },
            "c14_4_readiness": {
                "technical_prerequisites_satisfied": True,
                "execution_authorized": False,
                "next_stage_automatically_started": False,
            },
            "claim_boundary": self.manifest["claim_boundary"],
            "stop_boundary": {
                "c14_4_executed": False,
                "c15_executed": False,
                "training_executed": False,
                "api_called_during_shadow": False,
                "provider_called_during_shadow": False,
                "git_operation_executed": False,
                "automatic_follow_on": False,
            },
        }
        closeout_path = self.output_root / "c14_3_closeout.json"
        atomic_write_json(closeout_path, closeout, replace_existing=False)
        index = {
            path.name: file_sha(path)
            for path in sorted(self.output_root.iterdir())
            if path.is_file() and path.name != "sha256_index.json"
        }
        index["manifest_sha256"] = file_sha(self.manifest_path)
        index["latency_distribution_hash"] = EXPECTED_LATENCY_DISTRIBUTION_SHA256
        index["failure_distribution_hash"] = EXPECTED_FAILURE_DISTRIBUTION_SHA256
        index["integrity_index_sha256"] = canonical_sha(index)
        atomic_write_json(
            self.output_root / "sha256_index.json", index, replace_existing=False
        )
        return closeout

    def _descriptive_endpoints(self, rows: list[dict[str, Any]]) -> dict[str, Any]:
        endpoint_names = (
            "mean_aoi_ms",
            "q95_aoi_ms",
            "worst_user_time_average_aoi_ms",
            "collision_event_rate",
            "jain_freshness",
            "event_paoi_ms",
            "zero_success_fraction",
            "never_observed_fraction",
        )
        values: dict[tuple[str, str], dict[str, list[float]]] = {}
        for row in rows:
            artifact = strict_json(self.project_root / row["artifact_locator"])
            metrics_blob = artifact["blobs"]["metrics_case.json"]
            compressed = (self.project_root / metrics_blob["locator"]).read_bytes()
            payload = gzip.decompress(compressed)
            if hashlib.sha256(payload).hexdigest().upper() != metrics_blob["canonical_sha256"]:
                raise C143Error("C14.3 metrics CAS binding drift")
            metrics = json.loads(payload.decode("utf-8"))
            group = values.setdefault(
                (row["method_id"], row["cell"]), {name: [] for name in endpoint_names}
            )
            for name in endpoint_names:
                value = float(metrics[name])
                if not math.isfinite(value):
                    raise C143Error("C14.3 descriptive endpoint is non-finite")
                group[name].append(value)
        summaries = []
        for (method_id, cell), endpoints in sorted(values.items()):
            summaries.append(
                {
                    "method_id": method_id,
                    "cell": cell,
                    "endpoint_count": len(endpoint_names),
                    "root_measurement_count_by_endpoint": {
                        name: len(items) for name, items in endpoints.items()
                    },
                    "descriptive_means": {
                        name: format(sum(items) / len(items), ".12g")
                        for name, items in endpoints.items()
                    },
                }
            )
        return {
            "schema_version": "exp09-c14-3-descriptive-endpoints-v1",
            "artifact_status": "DESCRIPTIVE_ONLY_AD06B_NO_MARGIN_NO_RANKING",
            "protocol_generation": PROTOCOL_GENERATION,
            "endpoint_names": list(endpoint_names),
            "summaries_sha256": canonical_sha(summaries),
            "summaries": summaries,
            "adjusted_effects_or_ci_generated": False,
            "reason": "C14.3 is an internal shadow cost/direction gate and AD-06B has no practical margin",
            "superiority_or_non_harm_claim": False,
            "locked_test_conclusion": False,
        }


class C143PlainDiagnosticController:
    def __init__(
        self,
        controller: Any,
        *,
        root_case_id: str,
        arm: str,
        profile: EmpiricalProfile,
        samples: list[dict[str, Any]],
    ) -> None:
        self._controller = controller
        self._root_case_id = root_case_id
        self._arm = arm
        self._profile = profile
        self._samples = samples
        self._request_ordinal = 0

    def reset(self, context: Any) -> None:
        self._controller.reset(context)
        self._request_ordinal = 0

    def decide(self, frame: Any, opportunity: Any) -> Any:
        self._samples.append(
            self._profile.sample(
                task="Plain_LLM",
                root_case_id=self._root_case_id,
                arm=self._arm,
                trigger_slot_id=int(opportunity.time_us),
            )
        )
        self._request_ordinal += 1
        return self._controller.decide(frame, opportunity)


def run_cache_remediation(project_root: Path, credential_path: Path) -> dict[str, Any]:
    return C143CacheOrchestrator(project_root, credential_path).run()


def run_shadow(project_root: Path, *, expected_manifest_sha256: str) -> dict[str, Any]:
    return C143ShadowExecutor(
        project_root, expected_manifest_sha256=expected_manifest_sha256
    ).run()
