"""Causal offline-request inventory materialization for C14.1."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from typing import Any, Callable

from exp09.artifacts.canonical import canonical_sha256
from exp09.contracts.actions import ControlOpportunity, control_action_fingerprint
from exp09.contracts.determinism import stable_digest_hex
from exp09.contracts.ids import RequestId
from exp09.contracts.observable import ObservableFrame
from exp09.contracts.observable import ObservableCounterKind
from exp09.contracts.supervisor import ProgramProposal
from exp09.supervisor.providers import (
    EVIDENCE_BUNDLE_SCHEMA_VERSION,
    PROGRAM_PROPOSAL_SCHEMA_VERSION,
    PROVIDER_CONFIG_SCHEMA_VERSION,
    PROVIDER_RESPONSE_SCHEMA_VERSION,
    EvidenceBundle,
    ProviderConfig,
    ProviderKind,
    ProviderResponse,
    RationaleCode,
    TransitionId,
    canonical_provider_request,
    provider_response_hash,
)

from .c14_controllers import (
    PLAIN_INPUT_SCHEMA_VERSION,
    PLAIN_REQUEST_HASH_DOMAIN,
    _plain_input,
)

REQUEST_INVENTORY_SCHEMA_VERSION = "exp09-c14-1-request-inventory-v1"
REQUEST_RECORD_SCHEMA_VERSION = "exp09-c14-1-request-record-v1"
REQUEST_METHODS = ("Full", "Plain_LLM")
_FORBIDDEN_REQUEST_KEYS = frozenset(
    {
        "root_case_id",
        "run_id",
        "scenario",
        "arm",
        "shock_flag",
        "shock_label",
        "plant_truth",
        "future_tape",
        "method_ranking",
        "test_identity",
    }
)


class C14RequestMaterializationError(ValueError):
    """Raised when a request inventory is non-causal, incomplete, or inconsistent."""


@dataclass(frozen=True, slots=True)
class MaterializedRequest:
    method_id: str
    namespace: str
    request_hash: str
    request_payload: dict[str, Any]
    opportunity_id: str
    causal_cutoff_us: int


class RequestInventoryMaterializer:
    """Record exact offline requests without retaining method-case identity."""

    def __init__(
        self,
        *,
        method_id: str,
        namespace: str,
        method_config_sha256: str,
        protocol_sha256: str,
    ) -> None:
        if method_id not in REQUEST_METHODS:
            raise C14RequestMaterializationError("unsupported offline request method")
        self.method_id = method_id
        self.namespace = namespace
        self.method_config_sha256 = method_config_sha256
        self.protocol_sha256 = protocol_sha256
        self._records: list[MaterializedRequest] = []
        self._by_hash: dict[str, bytes] = {}

    @property
    def records(self) -> tuple[MaterializedRequest, ...]:
        return tuple(self._records)

    @property
    def request_hashes(self) -> tuple[str, ...]:
        return tuple(record.request_hash for record in self._records)

    def materialize_plain(
        self, frame: ObservableFrame, opportunity: ControlOpportunity
    ) -> MaterializedRequest:
        if self.method_id != "Plain_LLM":
            raise C14RequestMaterializationError("materializer method mismatch")
        from exp09.control.candidate_generator import ExpiryCandidateGenerator

        action_ids = tuple(
            control_action_fingerprint(action)
            for action in ExpiryCandidateGenerator().generate(frame, opportunity).actions
        )
        input_payload = _plain_input(frame, opportunity, action_ids)
        input_sha = canonical_sha256(
            input_payload, expected_schema_version=PLAIN_INPUT_SCHEMA_VERSION
        )
        eligible_sha = stable_digest_hex(
            "exp09-c14-1-eligible-action-set-v1", len(action_ids), *action_ids
        )
        request_hash = stable_digest_hex(
            PLAIN_REQUEST_HASH_DOMAIN,
            self.protocol_sha256,
            input_sha,
            eligible_sha,
            self.namespace,
            0,
        )
        request_payload = {
            "schema_version": "exp09-c14-1-plain-llm-request-materialized-v1",
            "namespace": self.namespace,
            "attempt_ordinal": 0,
            "protocol_sha256": self.protocol_sha256,
            "input_sha256": input_sha,
            "eligible_action_set_sha256": eligible_sha,
            "input": input_payload,
        }
        return self._record(request_hash, request_payload, frame, opportunity)

    def materialize_full(
        self,
        frame: ObservableFrame,
        opportunity: ControlOpportunity,
        *,
        selected_risk_ppm: int,
        detector_threshold_ppm: int,
        program_library_hash: str,
    ) -> MaterializedRequest:
        if self.method_id != "Full":
            raise C14RequestMaterializationError("materializer method mismatch")
        counters = {item.kind: item.value for item in frame.counters}
        busy = counters.get(ObservableCounterKind.BUSY_SENSING_UNIT, 0)
        total = counters.get(ObservableCounterKind.TOTAL_SENSING_UNIT, 0)
        observed_busy_ppm = busy * 1_000_000 // total if total else 0
        evidence = EvidenceBundle(
            schema_version=EVIDENCE_BUNDLE_SCHEMA_VERSION,
            evidence_id=stable_digest_hex(
                "exp09-c14-1-supervisor-evidence-id-v1",
                frame.summary_payload_hash,
                str(opportunity.opportunity_id),
            )[:32],
            causal_cutoff_us=frame.causal_cutoff_us,
            detector_active=selected_risk_ppm >= detector_threshold_ppm,
            risk_ppm=selected_risk_ppm,
            memory_interval_low_ppm=min(observed_busy_ppm, selected_risk_ppm),
            memory_interval_high_ppm=max(observed_busy_ppm, selected_risk_ppm),
        )
        return self.materialize_full_evidence(
            evidence,
            program_library_hash=program_library_hash,
            opportunity_id=str(opportunity.opportunity_id),
        )

    def materialize_full_evidence(
        self,
        evidence: EvidenceBundle,
        *,
        program_library_hash: str,
        opportunity_id: str,
    ) -> MaterializedRequest:
        if self.method_id != "Full":
            raise C14RequestMaterializationError("materializer method mismatch")
        config = ProviderConfig(
            schema_version=PROVIDER_CONFIG_SCHEMA_VERSION,
            provider_id="c14-1-full",
            provider_kind=ProviderKind.OFFLINE_LLM_REPLAY,
            program_library_hash=program_library_hash,
            request_budget_units=1,
            retry_budget=0,
            prompt_schema_hash=self.protocol_sha256,
        )
        request = canonical_provider_request(
            request_id=RequestId(
                stable_digest_hex(
                    "exp09-c14-1-provider-request-id-v1",
                    evidence.evidence_hash,
                    program_library_hash,
                )[:32]
            ),
            config=config,
            evidence=evidence,
            namespace=self.namespace,
            attempt_ordinal=0,
        )
        request_payload = {
            "schema_version": request.schema_version,
            "request_id": str(request.request_id),
            "config_hash": request.config_hash,
            "evidence_hash": request.evidence_hash,
            "namespace": request.namespace,
            "attempt_ordinal": request.attempt_ordinal,
            "evidence": {
                "schema_version": evidence.schema_version,
                "evidence_id": evidence.evidence_id,
                "causal_cutoff_us": int(evidence.causal_cutoff_us),
                "detector_active": evidence.detector_active,
                "risk_ppm": evidence.risk_ppm,
                "memory_interval_low_ppm": evidence.memory_interval_low_ppm,
                "memory_interval_high_ppm": evidence.memory_interval_high_ppm,
            },
        }
        return self._record_values(
            request.request_hash,
            request_payload,
            opportunity_id=opportunity_id,
            causal_cutoff_us=int(evidence.causal_cutoff_us),
        )

    def inventory_document(self, *, synthetic_fixture: bool) -> dict[str, Any]:
        records = [
            {
                "schema_version": REQUEST_RECORD_SCHEMA_VERSION,
                "method_id": record.method_id,
                "namespace": record.namespace,
                "request_hash": record.request_hash,
                "request_payload": record.request_payload,
                "opportunity_id": record.opportunity_id,
                "causal_cutoff_us": record.causal_cutoff_us,
            }
            for record in self._records
        ]
        return {
            "schema_version": REQUEST_INVENTORY_SCHEMA_VERSION,
            "artifact_status": (
                "SYNTHETIC_FIXTURE_ONLY_NOT_REAL_C14_1_COVERAGE"
                if synthetic_fixture
                else "MATERIALIZED_FROM_AUTHORIZED_C14_1_CASES"
            ),
            "method_id": self.method_id,
            "namespace": self.namespace,
            "method_config_sha256": self.method_config_sha256,
            "protocol_sha256": self.protocol_sha256,
            "request_count": len(records),
            "request_hashes": [record["request_hash"] for record in records],
            "records_sha256": _canonical_sha256(records),
            "records": records,
            "network_fallback": False,
            "api_calls": 0,
            "provider_calls": 0,
            "llm_tokens": 0,
            "cache_coverage_qualified": False,
            "execution_authorized": False,
        }

    def write_inventory(self, path: Path, *, synthetic_fixture: bool) -> str:
        payload = _canonical_json_bytes(
            self.inventory_document(synthetic_fixture=synthetic_fixture)
        )
        path.write_bytes(payload)
        return hashlib.sha256(payload).hexdigest().upper()

    def _record(
        self,
        request_hash: str,
        request_payload: dict[str, Any],
        frame: ObservableFrame,
        opportunity: ControlOpportunity,
    ) -> MaterializedRequest:
        return self._record_values(
            request_hash,
            request_payload,
            opportunity_id=str(opportunity.opportunity_id),
            causal_cutoff_us=int(frame.causal_cutoff_us),
        )

    def _record_values(
        self,
        request_hash: str,
        request_payload: dict[str, Any],
        *,
        opportunity_id: str,
        causal_cutoff_us: int,
    ) -> MaterializedRequest:
        _reject_forbidden_keys(request_payload)
        payload_bytes = _canonical_json_bytes(request_payload)
        existing = self._by_hash.get(request_hash)
        if existing is not None:
            if existing != payload_bytes:
                raise C14RequestMaterializationError(
                    "one request hash maps to different request payloads"
                )
            return next(
                record for record in self._records if record.request_hash == request_hash
            )
        record = MaterializedRequest(
            method_id=self.method_id,
            namespace=self.namespace,
            request_hash=request_hash,
            request_payload=request_payload,
            opportunity_id=opportunity_id,
            causal_cutoff_us=causal_cutoff_us,
        )
        self._by_hash[request_hash] = payload_bytes
        self._records.append(record)
        return record


class InventoryOnlyOfflineCache:
    """Materialize a request and abort before any response or online fallback."""

    def __init__(
        self,
        method_id: str,
        materialize_request: Callable[[str], None],
    ) -> None:
        self.method_id = method_id
        self._materialize_request = materialize_request

    def response_for(self, request_hash: str) -> dict[str, Any]:
        self._materialize_request(request_hash)
        raise C14RequestMaterializationError(
            "request inventory materialized; response lookup and network fallback are forbidden"
        )


def synthetic_full_response(request_hash: str) -> dict[str, Any]:
    """Build a schema-valid HOLD response for synthetic fixture tests only."""

    proposal = ProgramProposal(
        schema_version=PROGRAM_PROPOSAL_SCHEMA_VERSION,
        transition_id=TransitionId.HOLD,
        target_program_id=None,
        rationale_code=RationaleCode.HOLD_UNCERTAIN_EVIDENCE,
    )
    response = ProviderResponse(
        schema_version=PROVIDER_RESPONSE_SCHEMA_VERSION,
        request_hash=request_hash,
        proposal=proposal,
        response_hash=provider_response_hash(request_hash, proposal),
    )
    return {
        "proposal": {
            "transition_id": response.proposal.transition_id.value,
            "target_program_id": None,
            "rationale_code": response.proposal.rationale_code.value,
        },
        "response_hash": response.response_hash,
    }


def _reject_forbidden_keys(value: Any) -> None:
    if isinstance(value, dict):
        overlap = set(value) & _FORBIDDEN_REQUEST_KEYS
        if overlap:
            raise C14RequestMaterializationError(
                f"request payload exposes forbidden keys: {sorted(overlap)}"
            )
        for item in value.values():
            _reject_forbidden_keys(item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            _reject_forbidden_keys(item)


def _canonical_json_bytes(value: dict[str, Any] | list[Any]) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")


def _canonical_sha256(value: Any) -> str:
    return hashlib.sha256(_canonical_json_bytes(value)).hexdigest().upper()
