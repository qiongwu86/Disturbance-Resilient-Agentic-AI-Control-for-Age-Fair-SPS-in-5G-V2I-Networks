"""Fail-closed loading for externally supplied C14.1 offline caches."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from exp09.contracts.ids import require_identifier, require_sha256

OFFLINE_CACHE_BUNDLE_SCHEMA_VERSION = "exp09-c14-1-offline-cache-bundle-v1"


class C14OfflineCacheError(ValueError):
    """Raised when an offline cache is absent, unauditable, or incomplete."""


@dataclass(frozen=True, slots=True)
class AuditableOfflineCache:
    method_id: str
    namespace: str
    bundle_sha256: str
    responses_by_request_hash: dict[str, dict[str, Any]]

    def response_for(self, request_hash: str) -> dict[str, Any]:
        response = self.responses_by_request_hash.get(request_hash)
        if response is None:
            raise C14OfflineCacheError(
                "offline cache miss; API/provider/network fallback is forbidden"
            )
        return response


def load_auditable_offline_cache(
    project_root: Path,
    bundle_locator: str,
    *,
    expected_bundle_sha256: str,
    expected_method_id: str,
    expected_namespace: str,
    expected_method_config_sha256: str,
    expected_protocol_sha256: str,
    expected_request_hashes: tuple[str, ...],
) -> AuditableOfflineCache:
    """Load a complete cache only when all provenance and coverage bindings match."""

    require_sha256(expected_bundle_sha256, "expected_bundle_sha256")
    require_identifier(expected_method_id, "expected_method_id")
    require_identifier(expected_namespace, "expected_namespace")
    require_sha256(expected_method_config_sha256, "expected_method_config_sha256")
    require_sha256(expected_protocol_sha256, "expected_protocol_sha256")
    if not expected_request_hashes:
        raise C14OfflineCacheError("cache coverage cannot be verified against an empty request set")
    for digest in expected_request_hashes:
        require_sha256(digest, "expected_request_hash")
    if len(set(expected_request_hashes)) != len(expected_request_hashes):
        raise C14OfflineCacheError("expected request hashes contain duplicates")

    root = project_root.resolve()
    bundle_path = _resolve_project_file(root, bundle_locator)
    if _sha256(bundle_path) != expected_bundle_sha256:
        raise C14OfflineCacheError("offline cache bundle SHA-256 mismatch")
    bundle = _strict_json(bundle_path)
    if not isinstance(bundle, dict):
        raise C14OfflineCacheError("offline cache bundle must be a JSON object")
    if bundle.get("schema_version") != OFFLINE_CACHE_BUNDLE_SCHEMA_VERSION:
        raise C14OfflineCacheError("unsupported offline cache bundle schema")
    if bundle.get("method_id") != expected_method_id:
        raise C14OfflineCacheError("offline cache method identity mismatch")
    if bundle.get("namespace") != expected_namespace:
        raise C14OfflineCacheError("offline cache namespace mismatch")
    if bundle.get("network_fallback") is not False:
        raise C14OfflineCacheError("offline cache permits a network fallback")
    if any(bundle.get(field) != 0 for field in ("api_calls", "provider_calls", "llm_tokens")):
        raise C14OfflineCacheError("offline cache records forbidden online consumption")

    bindings = bundle.get("bindings", {})
    if bindings.get("method_config_sha256") != expected_method_config_sha256:
        raise C14OfflineCacheError("offline cache method-config binding mismatch")
    if bindings.get("protocol_sha256") != expected_protocol_sha256:
        raise C14OfflineCacheError("offline cache prompt/provider protocol binding mismatch")

    provenance = bundle.get("provenance", {})
    source_locator = provenance.get("source_artifact_locator")
    source_sha256 = provenance.get("source_artifact_sha256")
    if not isinstance(source_locator, str) or not isinstance(source_sha256, str):
        raise C14OfflineCacheError("offline cache provenance is incomplete")
    require_sha256(source_sha256, "source_artifact_sha256")
    source_path = _resolve_project_file(root, source_locator)
    if _sha256(source_path) != source_sha256:
        raise C14OfflineCacheError("offline cache source-artifact SHA-256 mismatch")

    coverage = bundle.get("coverage", {})
    required = coverage.get("required_request_hashes")
    if coverage.get("status") != "COMPLETE" or not isinstance(required, list):
        raise C14OfflineCacheError("offline cache coverage is not COMPLETE")
    if tuple(required) != expected_request_hashes:
        raise C14OfflineCacheError("offline cache required-request coverage mismatch")

    entries = bundle.get("entries")
    if not isinstance(entries, list):
        raise C14OfflineCacheError("offline cache entries must be a list")
    responses: dict[str, dict[str, Any]] = {}
    for entry in entries:
        if not isinstance(entry, dict):
            raise C14OfflineCacheError("offline cache entry must be an object")
        request_hash = entry.get("request_hash")
        response = entry.get("response")
        if not isinstance(request_hash, str) or not isinstance(response, dict):
            raise C14OfflineCacheError("offline cache entry is incomplete")
        require_sha256(request_hash, "request_hash")
        if request_hash in responses:
            raise C14OfflineCacheError("offline cache contains duplicate request hashes")
        responses[request_hash] = response
    if tuple(responses) != expected_request_hashes:
        raise C14OfflineCacheError("offline cache entries do not exactly cover required requests")
    return AuditableOfflineCache(
        method_id=expected_method_id,
        namespace=expected_namespace,
        bundle_sha256=expected_bundle_sha256,
        responses_by_request_hash=responses,
    )


def _resolve_project_file(root: Path, locator: str) -> Path:
    if not isinstance(locator, str) or not locator:
        raise C14OfflineCacheError("offline cache locator is missing")
    path = (root / locator).resolve()
    try:
        path.relative_to(root)
    except ValueError as exc:
        raise C14OfflineCacheError("offline cache locator escapes the project root") from exc
    if not path.is_file():
        raise C14OfflineCacheError(f"offline cache artifact is missing: {locator}")
    return path


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def _strict_json(path: Path) -> Any:
    def reject_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise C14OfflineCacheError(f"duplicate JSON key is forbidden: {key}")
            result[key] = value
        return result

    try:
        return json.loads(
            path.read_text(encoding="utf-8"),
            object_pairs_hook=reject_duplicates,
            parse_constant=lambda value: (_ for _ in ()).throw(
                C14OfflineCacheError(f"non-finite JSON value is forbidden: {value}")
            ),
        )
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise C14OfflineCacheError("offline cache is not strict UTF-8 JSON") from exc
