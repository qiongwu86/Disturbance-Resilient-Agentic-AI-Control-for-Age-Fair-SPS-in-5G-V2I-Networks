"""Process-local no-network guard for C14.1 offline execution."""

from __future__ import annotations

from contextlib import AbstractContextManager
import socket
from threading import RLock
from types import TracebackType


_GUARD_LOCK = RLock()
_GUARD_DEPTH = 0
_SOCKET_ORIGINALS: dict[str, object] = {}


class C14NetworkAttemptBlocked(RuntimeError):
    """Raised immediately when C14.1 code attempts to create or resolve a network path."""


class NoNetworkGuard(AbstractContextManager["NoNetworkGuard"]):
    """Temporarily replace common socket entry points with fail-closed sentinels."""

    def __init__(self) -> None:
        self._entered = False

    def __enter__(self) -> NoNetworkGuard:
        global _GUARD_DEPTH
        with _GUARD_LOCK:
            if self._entered:
                raise RuntimeError("no-network guard cannot be entered twice")
            if _GUARD_DEPTH == 0:
                for name in ("socket", "create_connection", "getaddrinfo"):
                    _SOCKET_ORIGINALS[name] = getattr(socket, name)
                    setattr(socket, name, _blocked_network_call)
            _GUARD_DEPTH += 1
            self._entered = True
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> bool | None:
        global _GUARD_DEPTH
        del exc_type, exc_value, traceback
        with _GUARD_LOCK:
            if not self._entered or _GUARD_DEPTH <= 0:
                raise RuntimeError("no-network guard exit is inconsistent")
            _GUARD_DEPTH -= 1
            self._entered = False
            if _GUARD_DEPTH == 0:
                for name, value in _SOCKET_ORIGINALS.items():
                    setattr(socket, name, value)
                _SOCKET_ORIGINALS.clear()
        return None


def _blocked_network_call(*args, **kwargs):
    del args, kwargs
    raise C14NetworkAttemptBlocked(
        "network/API/provider/LLM fallback is forbidden in C14.1"
    )
