"""Corrected C14.1 offline-cache protocol generation without provider access."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from typing import Any

from exp09.artifacts.canonical import canonical_sha256
from exp09.contracts.actions import ControlOpportunity, control_action_fingerprint
from exp09.contracts.determinism import stable_digest_hex
from exp09.contracts.ids import ProgramId
from exp09.contracts.observable import ObservableFrame
from exp09.contracts.supervisor import (
    PROGRAM_PROPOSAL_SCHEMA_VERSION,
    EligibleProposal,
    ProgramProposal,
    RationaleCode,
    TransitionId,
)
from exp09.control.candidate_generator import ExpiryCandidateGenerator
from exp09.supervisor.programs import ProgramOrchestrator, ProgramState, eligible_proposals
from exp09.supervisor.providers import (
    EvidenceBundle,
    PROVIDER_RESPONSE_SCHEMA_VERSION,
    ProviderResponse,
    provider_response_hash,
)

from .c14_controllers import (
    PLAIN_INPUT_SCHEMA_VERSION,
    PlainLlmControllerAdapter,
    SupervisorControllerAdapter,
    _supervisor_evidence,
    _validate_plain_response,
)
from .c14_offline_cache import C14OfflineCacheError

PROTOCOL_GENERATION = "EXP09_C14_1_OFFLINE_CACHE_V2_20260729"
PROTOCOL_GENERATION_MANIFEST_LOCATOR = (
    "protocol/c14/c14_1_protocol_generation_manifest.FROZEN_20260729.json"
)
PHASE_A_PLAN_SCHEMA_VERSION = "exp09-c14-1-phase-a-rematerialization-plan-v2"
PHASE_A_LEDGER_SCHEMA_VERSION = "exp09-c14-1-phase-a-rematerialization-ledger-v2"
PHASE_A_LEDGER_ROW_SCHEMA_VERSION = (
    "exp09-c14-1-phase-a-rematerialization-ledger-row-v2"
)
REQUEST_INVENTORY_SCHEMA_VERSION = "exp09-c14-1-request-inventory-v2"
REQUEST_RECORD_SCHEMA_VERSION = "exp09-c14-1-request-record-v2"
REQUEST_ENVELOPE_SCHEMA_VERSION = "exp09-c14-1-cache-request-envelope-v2"
FULL_INPUT_SCHEMA_VERSION = "exp09-c14-1-full-supervisor-input-v2"
PLAIN_MATERIALIZED_SCHEMA_VERSION = "exp09-c14-1-plain-llm-request-materialized-v2"
FULL_MATERIALIZED_SCHEMA_VERSION = "exp09-c14-1-full-request-materialized-v2"
ARMS = ("REFERENCE", "EVENT")
METHODS = ("Full", "Plain_LLM")
PHASE_A_ROOT_COUNT = 48
PHASE_A_CASE_COUNT = 192
PHASE_A_CASES_PER_METHOD = 96
PHASE_A_MAX_DECISION_ATTEMPTS_PER_CASE = 24
PHASE_A_MAX_PRE_MISS_COMMITMENTS_PER_CASE = 23
PHASE_A_TRANSITIONS_PER_FULL_DECISION = 72_000

_MODEL_FORBIDDEN_KEYS = frozenset(
    {
        "arm",
        "method_id",
        "root_case_id",
        "run_id",
        "scenario",
        "shock_flag",
        "shock_label",
        "plant_truth",
        "future_tape",
        "method_ranking",
        "test_identity",
    }
)


class C14ProtocolGenerationError(ValueError):
    """Raised when the corrected request or lifecycle contract is violated."""


def build_phase_a_rematerialization_plan(project_root: Path) -> dict[str, Any]:
    """Build a zero-use, non-authorizing v2 Phase A plan without running any case."""

    root = project_root.resolve()
    source_locator = (
        "protocol/c14/c14_1_method_case_topology.FROZEN_PREFLIGHT_20260729.json"
    )
    roots_locator = "protocol/c14/c14_1_design_roots.FROZEN_20260728.json"
    method_config_locator = "protocol/c14/method_config.C14_1_OFFLINE_CACHE_V2_20260729.json"
    provider_locator = "protocol/c14/provider_config.C14_1_OFFLINE_CACHE_V2_20260729.json"
    lifecycle_locator = (
        "protocol/c14/supervisor_lifecycle.C14_1_OFFLINE_CACHE_V2_20260729.json"
    )
    roots_document = _load_json(root / roots_locator)
    method_config = _load_json(root / method_config_locator)
    roots = roots_document.get("roots")
    if (
        not isinstance(roots, list)
        or len(roots) != PHASE_A_ROOT_COUNT
        or len(set(roots)) != PHASE_A_ROOT_COUNT
    ):
        raise C14ProtocolGenerationError("v2 Phase A requires exactly 48 unique roots")
    cases = [
        {
            "ordinal": ordinal,
            "case_id": f"{root_id}__{arm}__{method_id}__fixed",
            "root_case_id": root_id,
            "arm": arm,
            "scenario": "nominal_fixed" if arm == "REFERENCE" else "influx_event",
            "method_id": method_id,
            "variant_id": "fixed",
            "namespace": method_config["methods"][method_id]["arm_namespaces"][arm],
        }
        for ordinal, (root_id, arm, method_id) in enumerate(
            (root_id, arm, method_id)
            for root_id in roots
            for arm in ARMS
            for method_id in METHODS
        )
    ]
    _validate_phase_a_plan_cases(cases)
    budget_caps = phase_a_budget_caps()
    return {
        "schema_version": PHASE_A_PLAN_SCHEMA_VERSION,
        "artifact_status": "CANDIDATE_NOT_AUTHORIZED_NOT_EXECUTED",
        "protocol_generation": PROTOCOL_GENERATION,
        "execution_authorized": False,
        "automatic_continuation": False,
        "topology": {
            "source_topology_locator": source_locator,
            "source_topology_sha256": _file_sha(root / source_locator),
            "source_protocol_generation": "EXP09_G0_AD12A_20260726_V2",
            "design_roots_locator": roots_locator,
            "design_roots_sha256": _file_sha(root / roots_locator),
            "root_count": PHASE_A_ROOT_COUNT,
            "frontier_case_count": PHASE_A_CASE_COUNT,
            "arms": list(ARMS),
            "methods": list(METHODS),
            "other_method_count": 0,
            "cases_sha256": _canonical_sha(cases),
            "cases": cases,
        },
        "bindings": {
            "method_config": _binding(root, method_config_locator),
            "provider_config": _binding(root, provider_locator),
            "supervisor_lifecycle": _binding(root, lifecycle_locator),
            "full_protocol": _binding(
                root, method_config["methods"]["Full"]["prompt_protocol_locator"]
            ),
            "plain_llm_protocol": _binding(
                root, method_config["methods"]["Plain_LLM"]["prompt_protocol_locator"]
            ),
            "implementation": _binding(root, "src/exp09/evaluation/c14_protocol_generation.py"),
        },
        "causal_prefix_contract": {
            "full_debounce_requires_pre_miss_progress": True,
            "pre_miss_controller_commitments_allowed": True,
            "pre_miss_controller_commitments_hard_cap_per_case": (
                PHASE_A_MAX_PRE_MISS_COMMITMENTS_PER_CASE
            ),
            "cache_lookup_requires_prior_materialization": True,
            "stop_at_first_cache_miss": True,
            "post_miss_controller_commitments": 0,
            "post_miss_plant_actions": 0,
            "case_without_request_by_run_end": "FAIL_CLOSED_NO_FRONTIER",
        },
        "budget_caps": budget_caps,
        "budget_usage": {field: 0 for field in budget_caps},
        "ledger_locator": (
            "protocol/c14/c14_1_phase_a_rematerialization_ledger."
            "CANDIDATE_20260729.json"
        ),
        "v2_output_locator": "artifacts/c14_1_offline_cache_phase_a_frontier_v2",
        "old_phase_a_disposition": (
            "RETAIN_UNCHANGED_AS_SUPERSEDED_PROTOCOL_CAUSAL_FRONTIER_EVIDENCE"
        ),
        "forbidden": [
            "network",
            "api",
            "provider",
            "llm",
            "key_access",
            "training",
            "formal_c14_1_method_case",
            "performance_statistics",
            "c14_2",
            "shadow",
            "precision",
            "locked_test",
        ],
        "self_authorization_forbidden": True,
    }


def build_phase_a_zero_use_ledger(plan: dict[str, Any]) -> dict[str, Any]:
    """Create the immutable planned ledger; it deliberately contains no runtime evidence."""

    validate_phase_a_rematerialization_plan(plan)
    rows = [
        {
            "schema_version": PHASE_A_LEDGER_ROW_SCHEMA_VERSION,
            "run_id": f"phase-a-v2__{case['case_id']}__attempt000",
            "case_id": case["case_id"],
            "source_ordinal": case["ordinal"],
            "root_case_id": case["root_case_id"],
            "arm": case["arm"],
            "scenario": case["scenario"],
            "method_id": case["method_id"],
            "variant_id": case["variant_id"],
            "namespace": case["namespace"],
            "attempt_ordinal": 0,
            "resume_of": None,
            "status": "PLANNED",
            "started_at": None,
            "ended_at": None,
            "decision_attempts": 0,
            "model_transitions": 0,
            "pre_miss_controller_commitments": 0,
            "cache_lookup_attempts": 0,
            "cache_misses": 0,
            "post_miss_controller_commitments": 0,
            "post_miss_plant_actions": 0,
            "api_calls": 0,
            "provider_calls": 0,
            "llm_tokens": 0,
            "network_attempts": 0,
            "request_hash": None,
            "inventory_sha256_at_miss": None,
            "error_code": None,
            "retained_reason": None,
        }
        for case in plan["topology"]["cases"]
    ]
    usage = {field: 0 for field in plan["budget_caps"]}
    return {
        "schema_version": PHASE_A_LEDGER_SCHEMA_VERSION,
        "artifact_status": "CANDIDATE_PLAN_ONLY_NOT_AUTHORIZED_NOT_EXECUTED",
        "protocol_generation": PROTOCOL_GENERATION,
        "execution_authorized": False,
        "plan_sha256": _canonical_sha(plan),
        "planned_frontier_cases": PHASE_A_CASE_COUNT,
        "row_count": len(rows),
        "budget_caps": plan["budget_caps"],
        "budget_usage": usage,
        "rows_sha256": _canonical_sha(rows),
        "rows": rows,
        "resume_rule": (
            "append attempt only after FAILED_RETAINED or ABORTED_RETAINED; "
            "preserve prior row and bind resume_of"
        ),
        "abort_rule": (
            "retain failure, causal-prefix counters, hashes, and reason; never skip a case"
        ),
        "self_authorization_forbidden": True,
    }


def phase_a_candidate_document(plan: dict[str, Any]) -> dict[str, Any]:
    """Compactly freeze a fully reproducible plan without duplicating 192 identities."""

    validate_phase_a_rematerialization_plan(plan)
    document = json.loads(json.dumps(plan))
    document["topology"].pop("cases")
    document["topology"]["case_materialization"] = (
        "design_roots order x REFERENCE/EVENT x Full/Plain_LLM; contiguous ordinals"
    )
    return document


def phase_a_zero_use_ledger_candidate_document(
    plan: dict[str, Any], ledger: dict[str, Any]
) -> dict[str, Any]:
    """Compactly freeze exact zero-use ledger rows through their canonical hash."""

    validate_phase_a_rematerialization_plan(plan)
    if (
        ledger.get("schema_version") != PHASE_A_LEDGER_SCHEMA_VERSION
        or ledger.get("row_count") != PHASE_A_CASE_COUNT
        or ledger.get("budget_usage") != {field: 0 for field in phase_a_budget_caps()}
    ):
        raise C14ProtocolGenerationError("v2 Phase A zero-use ledger mismatch")
    document = json.loads(json.dumps(ledger))
    document.pop("rows")
    document["row_materialization"] = (
        "derive 192 PLANNED attempt000 rows from the bound Phase A plan before execution"
    )
    return document


def phase_a_budget_caps() -> dict[str, int]:
    full_decisions = PHASE_A_CASES_PER_METHOD * PHASE_A_MAX_DECISION_ATTEMPTS_PER_CASE
    return {
        "frontier_cases": PHASE_A_CASE_COUNT,
        "decision_attempts": PHASE_A_CASE_COUNT * PHASE_A_MAX_DECISION_ATTEMPTS_PER_CASE,
        "model_transitions": full_decisions * PHASE_A_TRANSITIONS_PER_FULL_DECISION,
        "pre_miss_controller_commitments": (
            PHASE_A_CASE_COUNT * PHASE_A_MAX_PRE_MISS_COMMITMENTS_PER_CASE
        ),
        "cache_lookup_attempts": PHASE_A_CASE_COUNT,
        "cache_misses": PHASE_A_CASE_COUNT,
        "post_miss_controller_commitments": 0,
        "post_miss_plant_actions": 0,
        "concurrency": 1,
        "api_calls": 0,
        "provider_calls": 0,
        "llm_tokens": 0,
        "network_attempts": 0,
    }


def validate_phase_a_rematerialization_plan(plan: dict[str, Any]) -> None:
    if plan.get("schema_version") != PHASE_A_PLAN_SCHEMA_VERSION:
        raise C14ProtocolGenerationError("v2 Phase A plan schema mismatch")
    if (
        plan.get("artifact_status") != "CANDIDATE_NOT_AUTHORIZED_NOT_EXECUTED"
        or plan.get("protocol_generation") != PROTOCOL_GENERATION
        or plan.get("execution_authorized") is not False
        or plan.get("automatic_continuation") is not False
        or plan.get("self_authorization_forbidden") is not True
    ):
        raise C14ProtocolGenerationError("v2 Phase A plan authority mismatch")
    topology = plan.get("topology", {})
    cases = topology.get("cases")
    if not isinstance(cases, list):
        raise C14ProtocolGenerationError("v2 Phase A plan cases are missing")
    _validate_phase_a_plan_cases(cases)
    if (
        topology.get("root_count") != PHASE_A_ROOT_COUNT
        or topology.get("frontier_case_count") != PHASE_A_CASE_COUNT
        or topology.get("arms") != list(ARMS)
        or topology.get("methods") != list(METHODS)
        or topology.get("other_method_count") != 0
        or topology.get("cases_sha256") != _canonical_sha(cases)
    ):
        raise C14ProtocolGenerationError("v2 Phase A topology summary mismatch")
    if plan.get("budget_caps") != phase_a_budget_caps() or plan.get("budget_usage") != {
        field: 0 for field in phase_a_budget_caps()
    }:
        raise C14ProtocolGenerationError("v2 Phase A budget is not frozen at zero use")
    causal = plan.get("causal_prefix_contract", {})
    if causal != {
        "full_debounce_requires_pre_miss_progress": True,
        "pre_miss_controller_commitments_allowed": True,
        "pre_miss_controller_commitments_hard_cap_per_case": 23,
        "cache_lookup_requires_prior_materialization": True,
        "stop_at_first_cache_miss": True,
        "post_miss_controller_commitments": 0,
        "post_miss_plant_actions": 0,
        "case_without_request_by_run_end": "FAIL_CLOSED_NO_FRONTIER",
    }:
        raise C14ProtocolGenerationError("v2 Phase A causal-prefix contract mismatch")


def _validate_phase_a_plan_cases(cases: list[dict[str, Any]]) -> None:
    if len(cases) != PHASE_A_CASE_COUNT or len({case.get("case_id") for case in cases}) != len(
        cases
    ):
        raise C14ProtocolGenerationError("v2 Phase A requires 192 unique cases")
    if [case.get("ordinal") for case in cases] != list(range(PHASE_A_CASE_COUNT)):
        raise C14ProtocolGenerationError("v2 Phase A case ordinals are not contiguous")
    roots = {case.get("root_case_id") for case in cases}
    actual = {
        (case.get("root_case_id"), case.get("arm"), case.get("method_id"))
        for case in cases
    }
    expected = {(root, arm, method) for root in roots for arm in ARMS for method in METHODS}
    if len(roots) != PHASE_A_ROOT_COUNT or actual != expected:
        raise C14ProtocolGenerationError("v2 Phase A root/arm/method cross-product drifted")
    if any(
        case.get("variant_id") != "fixed"
        or case.get("scenario")
        != ("nominal_fixed" if case.get("arm") == "REFERENCE" else "influx_event")
        or not case.get("namespace", "").endswith(
            "--reference" if case.get("arm") == "REFERENCE" else "--event"
        )
        for case in cases
    ):
        raise C14ProtocolGenerationError("v2 Phase A case binding drifted")


@dataclass(frozen=True, slots=True)
class MaterializedRequestV2:
    method_id: str
    arm: str
    namespace: str
    request_hash: str
    cache_envelope: dict[str, Any]
    model_payload: dict[str, Any]
    opportunity_id: str
    causal_cutoff_us: int


@dataclass(frozen=True, slots=True)
class _VerifiedProgramDecision:
    proposal: ProgramProposal
    based_on_sequence: int
    requested_at_us: int
    received_at_us: int
    received_source_sequence: int
    request_hash: str


def arm_cache_namespace(base_namespace: str, arm: str) -> str:
    if arm not in ARMS:
        raise C14ProtocolGenerationError("unsupported C14.1 arm")
    if not base_namespace or base_namespace.endswith(("--reference", "--event")):
        raise C14ProtocolGenerationError("cache namespace must be an unqualified base")
    return f"{base_namespace}--{arm.lower()}"


class ProtocolGenerationRequestMaterializer:
    """Materialize an arm-isolated envelope around an arm-blind model payload."""

    def __init__(
        self,
        *,
        method_id: str,
        arm: str,
        base_namespace: str,
        method_config_sha256: str,
        prompt_protocol_sha256: str,
        provider_config_sha256: str,
    ) -> None:
        if method_id not in METHODS:
            raise C14ProtocolGenerationError("unsupported corrected request method")
        for value, name in (
            (method_config_sha256, "method_config_sha256"),
            (prompt_protocol_sha256, "prompt_protocol_sha256"),
            (provider_config_sha256, "provider_config_sha256"),
        ):
            _require_sha(value, name)
        self.method_id = method_id
        self.arm = arm
        self.namespace = arm_cache_namespace(base_namespace, arm)
        self.method_config_sha256 = method_config_sha256
        self.prompt_protocol_sha256 = prompt_protocol_sha256
        self.provider_config_sha256 = provider_config_sha256
        self._records: list[MaterializedRequestV2] = []
        self._by_hash: dict[str, bytes] = {}

    @property
    def records(self) -> tuple[MaterializedRequestV2, ...]:
        return tuple(self._records)

    @property
    def request_hashes(self) -> tuple[str, ...]:
        return tuple(record.request_hash for record in self._records)

    def materialize_plain(
        self, frame: ObservableFrame, opportunity: ControlOpportunity
    ) -> MaterializedRequestV2:
        if self.method_id != "Plain_LLM":
            raise C14ProtocolGenerationError("materializer method mismatch")
        action_ids = tuple(
            control_action_fingerprint(action)
            for action in ExpiryCandidateGenerator().generate(frame, opportunity).actions
        )
        model_payload = _plain_model_payload(frame, opportunity, action_ids)
        eligible_sha = stable_digest_hex(
            "exp09-c14-1-eligible-action-set-v2", len(action_ids), *action_ids
        )
        envelope = self._envelope(
            model_payload,
            extra_bindings={"eligible_action_set_sha256": eligible_sha},
        )
        return self._record(
            envelope,
            model_payload,
            opportunity_id=str(opportunity.opportunity_id),
            causal_cutoff_us=int(frame.causal_cutoff_us),
        )

    def materialize_full(
        self,
        *,
        evidence: EvidenceBundle,
        program_state: ProgramState,
        eligible: tuple[EligibleProposal, ...],
        based_on_sequence: int,
        opportunity_id: str,
        program_library_hash: str,
    ) -> MaterializedRequestV2:
        if self.method_id != "Full":
            raise C14ProtocolGenerationError("materializer method mismatch")
        _require_sha(program_library_hash, "program_library_hash")
        model_payload = _full_model_payload(
            evidence=evidence,
            program_state=program_state,
            eligible=eligible,
            based_on_sequence=based_on_sequence,
        )
        envelope = self._envelope(
            model_payload,
            extra_bindings={"program_library_sha256": program_library_hash},
        )
        return self._record(
            envelope,
            model_payload,
            opportunity_id=opportunity_id,
            causal_cutoff_us=int(evidence.causal_cutoff_us),
        )

    def inventory_document(self, *, synthetic_fixture: bool) -> dict[str, Any]:
        records = [
            {
                "schema_version": REQUEST_RECORD_SCHEMA_VERSION,
                "method_id": record.method_id,
                "arm": record.arm,
                "namespace": record.namespace,
                "request_hash": record.request_hash,
                "cache_envelope": record.cache_envelope,
                "model_payload": record.model_payload,
                "opportunity_id": record.opportunity_id,
                "causal_cutoff_us": record.causal_cutoff_us,
            }
            for record in self._records
        ]
        return {
            "schema_version": REQUEST_INVENTORY_SCHEMA_VERSION,
            "artifact_status": (
                "SYNTHETIC_FIXTURE_ONLY_NOT_REAL_C14_1_COVERAGE"
                if synthetic_fixture
                else "CANDIDATE_PROTOCOL_GENERATION_NOT_AUTHORIZED"
            ),
            "protocol_generation": PROTOCOL_GENERATION,
            "method_id": self.method_id,
            "arm": self.arm,
            "namespace": self.namespace,
            "method_config_sha256": self.method_config_sha256,
            "prompt_protocol_sha256": self.prompt_protocol_sha256,
            "provider_config_sha256": self.provider_config_sha256,
            "request_count": len(records),
            "request_hashes": [record["request_hash"] for record in records],
            "records_sha256": _canonical_sha(records),
            "records": records,
            "network_fallback": False,
            "api_calls": 0,
            "provider_calls": 0,
            "llm_tokens": 0,
            "cache_coverage_qualified": False,
            "execution_authorized": False,
        }

    def _envelope(
        self,
        model_payload: dict[str, Any],
        *,
        extra_bindings: dict[str, str],
    ) -> dict[str, Any]:
        _reject_model_forbidden_keys(model_payload)
        return {
            "schema_version": REQUEST_ENVELOPE_SCHEMA_VERSION,
            "protocol_generation": PROTOCOL_GENERATION,
            "method_id": self.method_id,
            "arm": self.arm,
            "namespace": self.namespace,
            "attempt_ordinal": 0,
            "method_config_sha256": self.method_config_sha256,
            "prompt_protocol_sha256": self.prompt_protocol_sha256,
            "provider_config_sha256": self.provider_config_sha256,
            "model_payload_sha256": _canonical_sha(model_payload),
            **extra_bindings,
        }

    def _record(
        self,
        envelope: dict[str, Any],
        model_payload: dict[str, Any],
        *,
        opportunity_id: str,
        causal_cutoff_us: int,
    ) -> MaterializedRequestV2:
        materialized = {
            "schema_version": (
                FULL_MATERIALIZED_SCHEMA_VERSION
                if self.method_id == "Full"
                else PLAIN_MATERIALIZED_SCHEMA_VERSION
            ),
            "cache_envelope": envelope,
            "model_payload": model_payload,
        }
        request_hash = _canonical_sha(materialized)
        payload_bytes = _canonical_bytes(materialized)
        existing = self._by_hash.get(request_hash)
        if existing is not None:
            if existing != payload_bytes:
                raise C14ProtocolGenerationError(
                    "one corrected request hash maps to different payloads"
                )
            return next(
                record for record in self._records if record.request_hash == request_hash
            )
        record = MaterializedRequestV2(
            method_id=self.method_id,
            arm=self.arm,
            namespace=self.namespace,
            request_hash=request_hash,
            cache_envelope=envelope,
            model_payload=model_payload,
            opportunity_id=opportunity_id,
            causal_cutoff_us=causal_cutoff_us,
        )
        self._by_hash[request_hash] = payload_bytes
        self._records.append(record)
        return record


class CorrectedPlainLlmController(PlainLlmControllerAdapter):
    def __init__(self, method_config_hash, config, cache, materializer) -> None:
        super().__init__(method_config_hash, config, cache)
        if materializer.method_id != "Plain_LLM":
            raise C14ProtocolGenerationError("Plain_LLM materializer mismatch")
        self._corrected_cache = cache
        self._materializer = materializer

    def decide(self, frame, opportunity):
        action = self._select_audited_action(frame, opportunity)
        return self._commit(frame, action)

    def audit_frontier_without_commitment(self, frame, opportunity) -> None:
        self._select_audited_action(frame, opportunity)

    def _select_audited_action(self, frame, opportunity):
        candidates = ExpiryCandidateGenerator().generate(frame, opportunity)
        action_by_id = {
            control_action_fingerprint(action): action for action in candidates.actions
        }
        request = self._materializer.materialize_plain(frame, opportunity)
        response = self._corrected_cache.response_for(request.request_hash)
        selected_id = _validate_plain_response(response, tuple(action_by_id))
        return action_by_id[selected_id]


class CorrectedFullController(SupervisorControllerAdapter):
    """Apply provider proposals on the next opportunity under real trigger semantics."""

    def __init__(self, method_config_hash, config, cache, materializer, lifecycle) -> None:
        super().__init__("Full", method_config_hash, config, full_cache=cache)
        if materializer.method_id != "Full":
            raise C14ProtocolGenerationError("Full materializer mismatch")
        self._corrected_cache = cache
        self._materializer = materializer
        self._debounce_us = int(lifecycle["debounce_us"])
        self._rate_limit_us = int(lifecycle["rate_limit_us"])
        self._request_expiry_us = int(lifecycle["request_expiry_us"])
        self._response_age_limit_us = int(lifecycle["response_age_limit_us"])
        self._max_source_sequence_advance = int(
            lifecycle["context_drift"]["max_source_sequence_advance"]
        )
        self._last_request_us: int | None = None
        self._active_since_us: int | None = None
        self._pending_processed_at_us: int | None = None
        self._verified_pending: _VerifiedProgramDecision | None = None
        self.mechanism_events: list[dict[str, Any]] = []

    def reset(self, context) -> None:
        super().reset(context)
        self._last_request_us = None
        self._active_since_us = None
        self._pending_processed_at_us = None
        self._verified_pending = None
        self.mechanism_events = []

    def decide(self, frame, opportunity):
        action = self._select_audited_action(frame, opportunity)
        return self._commit(frame, action)

    def audit_frontier_without_commitment(self, frame, opportunity) -> None:
        self._select_audited_action(frame, opportunity)

    def _select_audited_action(self, frame, opportunity):
        evidence = self._model_stack.evaluate(frame, opportunity)
        bundle = _supervisor_evidence(
            frame,
            opportunity,
            selected_risk_ppm=evidence.selected_risk_ppm,
            detector_threshold_ppm=self._detector_threshold_ppm,
        )
        self._activate_pending(frame, opportunity, trigger_active=bundle.detector_active)
        self._return_balanced_if_expired(opportunity)

        eligible = eligible_proposals(
            library=self._library,
            state=self._program_state,
            now_us=opportunity.time_us,
            trigger_active=bundle.detector_active,
        )
        if self._provider_triggered(bundle, eligible, opportunity):
            request = self._materializer.materialize_full(
                evidence=bundle,
                program_state=self._program_state,
                eligible=eligible,
                based_on_sequence=frame.source_sequence,
                opportunity_id=str(opportunity.opportunity_id),
                program_library_hash=self._library.library_hash,
            )
            raw = self._corrected_cache.response_for(request.request_hash)
            proposal = _parse_full_response(raw, request.request_hash)
            _require_proposal_eligible(proposal, eligible)
            received_at_us, received_source_sequence, completed = self._response_receipt(
                frame,
                opportunity,
            )
            self.mechanism_events.append(
                {
                    "event": "PROGRAM_PROPOSAL_RECEIVED",
                    "request_hash": request.request_hash,
                    "requested_at_us": int(opportunity.time_us),
                    "received_at_us": received_at_us,
                    "based_on_sequence": int(frame.source_sequence),
                    "received_source_sequence": received_source_sequence,
                    "transition_id": proposal.transition_id.value,
                    "target_program_id": (
                        None
                        if proposal.target_program_id is None
                        else str(proposal.target_program_id)
                    ),
                    "transport_completed": completed,
                }
            )
            candidate = _VerifiedProgramDecision(
                proposal=proposal,
                based_on_sequence=frame.source_sequence,
                requested_at_us=int(opportunity.time_us),
                received_at_us=received_at_us,
                received_source_sequence=received_source_sequence,
                request_hash=request.request_hash,
            )
            self._verified_pending = self._verify_at_receipt(candidate, completed=completed)
            self._last_request_us = int(opportunity.time_us)

        if self._program_state.current_program_id == self._balanced_id:
            action = evidence.gated_action
            ranking_rule = "ROBUST_GATED_ACTION"
        elif self._program_state.current_program_id == self._protect_id:
            action = min(
                (item for item in evidence.candidates.actions if item.target_rri_us is not None),
                key=lambda item: int(item.target_rri_us or 0),
            )
            ranking_rule = "PROTECT_FRESHNESS_MIN_TARGET_RRI"
        else:  # pragma: no cover
            raise RuntimeError("unknown corrected recovery program")
        gated_action_id = control_action_fingerprint(evidence.gated_action)
        selected_action_id = control_action_fingerprint(action)
        self.mechanism_events.append(
            {
                "event": "PROGRAM_ACTION_SELECTED",
                "opportunity_us": int(opportunity.time_us),
                "source_sequence": int(frame.source_sequence),
                "program_id": str(self._program_state.current_program_id),
                "ranking_rule": ranking_rule,
                "gated_action_id": gated_action_id,
                "selected_action_id": selected_action_id,
                "action_changed_from_gated": selected_action_id != gated_action_id,
            }
        )
        return action

    def mechanism_snapshot(self) -> dict[str, Any]:
        pending = self._verified_pending
        return {
            "schema_version": "exp09-c14-supervisor-mechanism-snapshot-v1",
            "current_program_id": str(self._program_state.current_program_id),
            "current_program_state_hash": self._program_state.state_hash,
            "verified_pending": (
                None
                if pending is None
                else {
                    "request_hash": pending.request_hash,
                    "transition_id": pending.proposal.transition_id.value,
                    "target_program_id": (
                        None
                        if pending.proposal.target_program_id is None
                        else str(pending.proposal.target_program_id)
                    ),
                    "requested_at_us": pending.requested_at_us,
                    "received_at_us": pending.received_at_us,
                    "based_on_sequence": int(pending.based_on_sequence),
                    "received_source_sequence": pending.received_source_sequence,
                }
            ),
            "events": list(self.mechanism_events),
        }

    def _provider_triggered(self, evidence, eligible, opportunity) -> bool:
        if self._pending_processed_at_us == int(opportunity.time_us):
            return False
        if self._verified_pending is not None:
            return False
        if not evidence.detector_active:
            self._active_since_us = None
            return False
        now_us = int(opportunity.time_us)
        if self._active_since_us is None:
            self._active_since_us = now_us
            return False
        if now_us - self._active_since_us < self._debounce_us:
            return False
        if not any(item.transition_id is not TransitionId.HOLD for item in eligible):
            return False
        return self._last_request_us is None or (
            now_us - self._last_request_us >= self._rate_limit_us
        )

    def _activate_pending(self, frame, opportunity, *, trigger_active: bool) -> None:
        pending = self._verified_pending
        if pending is None:
            return
        if int(opportunity.time_us) < pending.received_at_us:
            return
        self._verified_pending = None
        self._pending_processed_at_us = int(opportunity.time_us)
        eligible = eligible_proposals(
            library=self._library,
            state=self._program_state,
            now_us=opportunity.time_us,
            trigger_active=trigger_active,
        )
        if not _proposal_is_eligible(pending.proposal, eligible):
            self.mechanism_events.append(
                {
                    "event": "VERIFIED_DECISION_REJECTED_AT_ACTIVATION",
                    "request_hash": pending.request_hash,
                    "activation_opportunity_us": int(opportunity.time_us),
                    "reason": "ACTIVATION_ELIGIBILITY_CHANGED",
                }
            )
            return
        record = ProgramOrchestrator().apply_provider_proposal(
            library=self._library,
            state=self._program_state,
            proposal=pending.proposal,
            now_us=opportunity.time_us,
            trigger_active=trigger_active,
        )
        self._program_state = record.transition_record.next_state
        self.mechanism_events.append(
            {
                "event": "VERIFIED_DECISION_ACTIVATED",
                "request_hash": pending.request_hash,
                "received_at_us": pending.received_at_us,
                "activation_opportunity_us": int(opportunity.time_us),
                "activation_source_sequence": int(frame.source_sequence),
                "program_id": str(self._program_state.current_program_id),
            }
        )

    def _response_receipt(self, frame, opportunity) -> tuple[int, int, bool]:
        return int(opportunity.time_us), int(frame.source_sequence), True

    def _verify_at_receipt(
        self,
        candidate: _VerifiedProgramDecision,
        *,
        completed: bool,
    ) -> _VerifiedProgramDecision | None:
        request_age_us = candidate.received_at_us - candidate.requested_at_us
        sequence_advance = (
            candidate.received_source_sequence - candidate.based_on_sequence
        )
        reason = None
        if not completed:
            reason = "TRANSPORT_FAILURE"
        elif request_age_us < 0:
            reason = "NEGATIVE_RESPONSE_AGE"
        elif request_age_us > self._request_expiry_us:
            reason = "REQUEST_EXPIRED_AT_RECEIPT"
        elif request_age_us > self._response_age_limit_us:
            reason = "RESPONSE_TOO_OLD_AT_RECEIPT"
        elif sequence_advance < 0:
            reason = "NEGATIVE_SOURCE_SEQUENCE_ADVANCE"
        elif sequence_advance > self._max_source_sequence_advance:
            reason = "CONTEXT_DRIFT_AT_RECEIPT"
        self.mechanism_events.append(
            {
                "event": (
                    "RECEIPT_VERIFICATION_ACCEPTED"
                    if reason is None
                    else "RECEIPT_VERIFICATION_REJECTED"
                ),
                "request_hash": candidate.request_hash,
                "requested_at_us": candidate.requested_at_us,
                "received_at_us": candidate.received_at_us,
                "request_age_us": request_age_us,
                "based_on_sequence": candidate.based_on_sequence,
                "received_source_sequence": candidate.received_source_sequence,
                "source_sequence_advance": sequence_advance,
                "reason": reason,
            }
        )
        return candidate if reason is None else None

    def _return_balanced_if_expired(self, opportunity) -> None:
        current = self._library.require_program(self._program_state.current_program_id)
        if (
            self._program_state.current_program_id == self._balanced_id
            or int(opportunity.time_us) - int(self._program_state.current_started_us)
            < current.ttl_us
        ):
            return
        proposal = ProgramProposal(
            schema_version=PROGRAM_PROPOSAL_SCHEMA_VERSION,
            transition_id=TransitionId.RETURN_BALANCED,
            target_program_id=self._balanced_id,
            rationale_code=RationaleCode.RETURN_TO_BALANCED,
        )
        record = ProgramOrchestrator().apply_provider_proposal(
            library=self._library,
            state=self._program_state,
            proposal=proposal,
            now_us=opportunity.time_us,
            trigger_active=False,
        )
        self._program_state = record.transition_record.next_state


def build_protocol_generation_controller(
    factory,
    method_id: str,
    *,
    cache,
    materializer: ProtocolGenerationRequestMaterializer,
):
    if method_id == "Full":
        lifecycle = _load_json(
            factory.project_root
            / "protocol/c14/supervisor_lifecycle.C14_1_OFFLINE_CACHE_V2_20260729.json"
        )
        return CorrectedFullController(
            factory.config_sha256, factory.config, cache, materializer, lifecycle
        )
    if method_id == "Plain_LLM":
        return CorrectedPlainLlmController(
            factory.config_sha256, factory.config, cache, materializer
        )
    raise C14ProtocolGenerationError(
        "corrected protocol-generation controller supports Full/Plain_LLM only"
    )


def _plain_model_payload(frame, opportunity, action_ids) -> dict[str, Any]:
    from .c14_controllers import _plain_input

    payload = _plain_input(frame, opportunity, action_ids)
    canonical_sha256(payload, expected_schema_version=PLAIN_INPUT_SCHEMA_VERSION)
    return payload


def _full_model_payload(
    *,
    evidence: EvidenceBundle,
    program_state: ProgramState,
    eligible: tuple[EligibleProposal, ...],
    based_on_sequence: int,
) -> dict[str, Any]:
    if not eligible:
        raise C14ProtocolGenerationError("Full eligible proposals cannot be empty")
    return {
        "schema_version": FULL_INPUT_SCHEMA_VERSION,
        "causal_cutoff_us": int(evidence.causal_cutoff_us),
        "based_on_sequence": based_on_sequence,
        "program_state": {
            "schema_version": program_state.schema_version,
            "state_hash": program_state.state_hash,
            "current_program_id": str(program_state.current_program_id),
            "current_started_us": int(program_state.current_started_us),
            "last_transition_us": int(program_state.last_transition_us),
            "remaining_budget_units": program_state.remaining_budget_units,
        },
        "eligible_proposals": [
            {
                "transition_id": item.transition_id.value,
                "target_program_id": (
                    None if item.target_program_id is None else str(item.target_program_id)
                ),
            }
            for item in eligible
        ],
        "evidence": {
            "schema_version": evidence.schema_version,
            "evidence_id": evidence.evidence_id,
            "causal_cutoff_us": int(evidence.causal_cutoff_us),
            "detector_active": evidence.detector_active,
            "risk_ppm": evidence.risk_ppm,
            "memory_interval_low_ppm": evidence.memory_interval_low_ppm,
            "memory_interval_high_ppm": evidence.memory_interval_high_ppm,
        },
        "evidence_hash": evidence.evidence_hash,
        "remaining_budget": {
            "program_transition_units": program_state.remaining_budget_units,
            "provider_request_units": 1,
        },
    }


def _parse_full_response(raw: dict[str, Any], request_hash: str) -> ProgramProposal:
    proposal_raw = raw.get("proposal")
    if not isinstance(proposal_raw, dict):
        raise C14OfflineCacheError("Full cache response has no proposal")
    try:
        target = proposal_raw.get("target_program_id")
        proposal = ProgramProposal(
            schema_version=PROGRAM_PROPOSAL_SCHEMA_VERSION,
            transition_id=TransitionId(proposal_raw["transition_id"]),
            target_program_id=None if target is None else ProgramId(target),
            rationale_code=RationaleCode(proposal_raw["rationale_code"]),
        )
        ProviderResponse(
            schema_version=PROVIDER_RESPONSE_SCHEMA_VERSION,
            request_hash=request_hash,
            proposal=proposal,
            response_hash=raw["response_hash"],
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise C14OfflineCacheError("Full cache response schema is invalid") from exc
    if raw["response_hash"] != provider_response_hash(request_hash, proposal):
        raise C14OfflineCacheError("Full cache response hash mismatch")
    return proposal


def _proposal_is_eligible(
    proposal: ProgramProposal, eligible: tuple[EligibleProposal, ...]
) -> bool:
    return (proposal.transition_id, proposal.target_program_id) in {
        (item.transition_id, item.target_program_id) for item in eligible
    }


def _require_proposal_eligible(
    proposal: ProgramProposal, eligible: tuple[EligibleProposal, ...]
) -> None:
    if not _proposal_is_eligible(proposal, eligible):
        raise C14OfflineCacheError(
            "Full provider proposal is not in the exact eligible set; fallback is forbidden"
        )


def _reject_model_forbidden_keys(value: Any) -> None:
    if isinstance(value, dict):
        overlap = set(value) & _MODEL_FORBIDDEN_KEYS
        if overlap:
            raise C14ProtocolGenerationError(
                f"model payload exposes forbidden keys: {sorted(overlap)}"
            )
        for child in value.values():
            _reject_model_forbidden_keys(child)
    elif isinstance(value, (list, tuple)):
        for child in value:
            _reject_model_forbidden_keys(child)


def _canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")


def _canonical_sha(value: Any) -> str:
    return hashlib.sha256(_canonical_bytes(value)).hexdigest().upper()


def _require_sha(value: str, name: str) -> None:
    if not isinstance(value, str) or len(value) != 64:
        raise C14ProtocolGenerationError(f"{name} must be SHA-256")
    try:
        int(value, 16)
    except ValueError as exc:
        raise C14ProtocolGenerationError(f"{name} must be SHA-256") from exc


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _file_sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def _binding(root: Path, locator: str) -> dict[str, str]:
    path = (root / locator).resolve()
    try:
        path.relative_to(root)
    except ValueError as exc:
        raise C14ProtocolGenerationError("protocol-generation binding escapes project") from exc
    if not path.is_file():
        raise C14ProtocolGenerationError(f"protocol-generation binding is missing: {locator}")
    return {"locator": locator, "sha256": _file_sha(path)}
