"""Atomic C06 case-artifact writer and verifier."""

from dataclasses import dataclass, fields, is_dataclass
from enum import Enum
from functools import lru_cache
import hashlib
import json
import os
from pathlib import Path
from types import UnionType
from typing import Any, Union, get_args, get_origin, get_type_hints
from uuid import uuid4

from exp09.artifacts.canonical import canonical_json_bytes, to_primitive
from exp09.contracts.tape import TapeArm

from .disturbance_tape import tape_to_bytes, validate_primary_tape
from .metrics_accumulator import (
    CASE_METRICS_SCHEMA_VERSION,
    CaseMetrics,
)
from .runner import (
    RAW_RUN_TRACE_SCHEMA_VERSION,
    RUN_RESULT_SCHEMA_VERSION,
    RawRunTrace,
    RunResult,
    rebuild_metrics,
)

INTEGRITY_SCHEMA_VERSION = "exp09-run-integrity-v2"
COMPLETE_SCHEMA_VERSION = "exp09-run-complete-v1"
_ARTIFACT_NAMES = ("raw_run.json", "metrics_case.json")
_PUBLISHED_NAMES = frozenset((*_ARTIFACT_NAMES, "integrity.json", "COMPLETE"))
_COMPLETE_FIELDS = frozenset(
    {"schema_version", "integrity_sha256", "result_integrity_hash"}
)
_INTEGRITY_FIELDS = frozenset(
    {
        "schema_version",
        "result_schema_version",
        "raw_schema_version",
        "metrics_schema_version",
        "root_case_id",
        "arm",
        "protocol_generation",
        "tape_id",
        "config_hash",
        "tape_canonical_sha256",
        "result_integrity_hash",
        "files",
    }
)
_FILE_RECORD_FIELDS = frozenset({"sha256", "size_bytes"})


@dataclass(frozen=True, slots=True)
class CompletedRunArtifact:
    path: Path
    integrity_hash: str


def write_completed_run(result: RunResult, output_root: Path) -> CompletedRunArtifact:
    """Write a verified case into a temporary sibling and publish it atomically."""

    if result.schema_version != RUN_RESULT_SCHEMA_VERSION:
        raise ValueError("unsupported run-result schema")
    if result.raw_trace.schema_version != RAW_RUN_TRACE_SCHEMA_VERSION:
        raise ValueError("unsupported raw-run-trace schema")
    rebuilt_metrics = rebuild_metrics(result.raw_trace)
    if result.metrics != rebuilt_metrics:
        raise ValueError("run metrics do not agree with the raw trace")
    if (
        result.root_case_id != str(result.raw_trace.tape.root_case_id)
        or result.arm is not result.raw_trace.tape.arm
        or result.tx_attempts != rebuilt_metrics.tx_attempts
        or result.observable_frame_count != len(result.raw_trace.summary_deliveries)
        or result.integrity_hash
        != _canonical_raw_hash(result.raw_trace)
    ):
        raise ValueError("run result metadata do not agree with the raw trace")
    output_root = Path(output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    final_path = output_root / _safe_case_name(result)
    if final_path.exists():
        raise FileExistsError(f"completed run already exists: {final_path.name}")
    temporary_path = output_root / f".{final_path.name}.tmp-{uuid4().hex}"
    quarantine_root = output_root / "quarantine"
    try:
        temporary_path.mkdir()
        _write_bytes(
            temporary_path / "raw_run.json",
            canonical_json_bytes(
                result.raw_trace,
                expected_schema_version=RAW_RUN_TRACE_SCHEMA_VERSION,
            ),
        )
        _write_bytes(
            temporary_path / "metrics_case.json",
            canonical_json_bytes(
                result.metrics,
                expected_schema_version=CASE_METRICS_SCHEMA_VERSION,
            ),
        )
        integrity_bytes = _integrity_bytes(result, temporary_path)
        _write_bytes(temporary_path / "integrity.json", integrity_bytes)
        _verify_staged_files(result, temporary_path)
        _write_bytes(
            temporary_path / "COMPLETE",
            _canonical_mapping_bytes(
                {
                    "schema_version": COMPLETE_SCHEMA_VERSION,
                    "integrity_sha256": _sha256_bytes(integrity_bytes),
                    "result_integrity_hash": result.integrity_hash,
                }
            ),
        )
        os.replace(temporary_path, final_path)
    except Exception:
        if temporary_path.exists():
            quarantine_root.mkdir(exist_ok=True)
            os.replace(temporary_path, quarantine_root / temporary_path.name)
        raise
    verified = verify_completed_run(final_path)
    if verified.integrity_hash != result.integrity_hash:
        raise RuntimeError("published run integrity does not match the source result")
    return verified


def verify_completed_run(path: Path) -> CompletedRunArtifact:
    path = Path(path)
    if (
        not path.is_dir()
        or path.is_symlink()
        or path.name == "quarantine"
        or path.name.startswith(".")
    ):
        raise ValueError("run path is not a published case directory")
    complete_path = path / "COMPLETE"
    integrity_path = path / "integrity.json"
    if not complete_path.is_file() or not integrity_path.is_file():
        raise ValueError("run is incomplete")
    if {item.name for item in path.iterdir()} != _PUBLISHED_NAMES:
        raise ValueError("published run has an unexpected file set")
    if any(item.is_symlink() or not item.is_file() for item in path.iterdir()):
        raise ValueError("published run artifacts must be regular files")

    complete, _ = _load_canonical_json_object(complete_path)
    integrity, integrity_bytes = _load_canonical_json_object(integrity_path)
    _require_exact_fields(complete, _COMPLETE_FIELDS, "completion marker")
    _require_exact_fields(integrity, _INTEGRITY_FIELDS, "integrity manifest")
    if complete.get("schema_version") != COMPLETE_SCHEMA_VERSION:
        raise ValueError("unsupported completion-marker schema")
    if integrity.get("schema_version") != INTEGRITY_SCHEMA_VERSION:
        raise ValueError("unsupported integrity schema")
    if complete.get("integrity_sha256") != _sha256_bytes(integrity_bytes):
        raise ValueError("completion marker does not bind integrity.json")
    files = integrity.get("files")
    if not isinstance(files, dict) or set(files) != set(_ARTIFACT_NAMES):
        raise ValueError("integrity manifest has an unexpected artifact set")
    for name in _ARTIFACT_NAMES:
        record = files[name]
        if not isinstance(record, dict):
            raise ValueError("integrity file record must be an object")
        _require_exact_fields(record, _FILE_RECORD_FIELDS, f"integrity record {name}")
        file_path = path / name
        if not file_path.is_file():
            raise ValueError(f"run artifact is missing: {name}")
        payload = file_path.read_bytes()
        if record.get("size_bytes") != len(payload) or record.get("sha256") != _sha256_bytes(
            payload
        ):
            raise ValueError(f"run artifact integrity mismatch: {name}")
    result_hash = integrity.get("result_integrity_hash")
    if not isinstance(result_hash, str) or complete.get("result_integrity_hash") != result_hash:
        raise ValueError("completion marker and integrity result hash disagree")

    raw = _load_raw_run_trace(path / "raw_run.json")
    metrics = _load_case_metrics(path / "metrics_case.json")
    rebuilt_metrics = rebuild_metrics(raw)
    if metrics != rebuilt_metrics:
        raise ValueError("stored metrics do not agree with the raw trace")
    canonical_raw_hash = _canonical_raw_hash(raw)
    if result_hash != canonical_raw_hash:
        raise ValueError("result integrity hash does not bind the canonical raw trace")
    if (
        integrity.get("result_schema_version") != RUN_RESULT_SCHEMA_VERSION
        or integrity.get("raw_schema_version") != raw.schema_version
        or integrity.get("metrics_schema_version") != metrics.schema_version
    ):
        raise ValueError("integrity manifest schema metadata disagree with the artifacts")
    if (
        integrity.get("root_case_id") != str(raw.tape.root_case_id)
        or integrity.get("arm") != raw.tape.arm.value
        or integrity.get("protocol_generation") != raw.tape.protocol_generation
        or integrity.get("tape_id") != str(raw.tape.tape_id)
        or integrity.get("config_hash") != raw.tape.config_hash
        or integrity.get("tape_canonical_sha256")
        != _canonical_tape_hash(raw.tape)
    ):
        raise ValueError("integrity manifest case identity disagrees with the raw trace")
    expected_name = _case_name(str(raw.tape.root_case_id), raw.tape.arm, result_hash)
    if path.name != expected_name:
        raise ValueError("published run directory name disagrees with the case identity")

    return CompletedRunArtifact(path=path, integrity_hash=result_hash)


def _verify_staged_files(result: RunResult, path: Path) -> None:
    integrity = _load_json_object(path / "integrity.json")
    files = integrity.get("files")
    if not isinstance(files, dict):
        raise ValueError("staged integrity file map is invalid")
    for name in _ARTIFACT_NAMES:
        payload = (path / name).read_bytes()
        record = files.get(name)
        if not isinstance(record, dict) or record != {
            "sha256": _sha256_bytes(payload),
            "size_bytes": len(payload),
        }:
            raise ValueError(f"staged artifact integrity mismatch: {name}")
    raw = _load_raw_run_trace(path / "raw_run.json")
    metrics = _load_case_metrics(path / "metrics_case.json")
    if raw != result.raw_trace or metrics != result.metrics:
        raise ValueError("staged artifacts do not reproduce the source run result")
    if rebuild_metrics(raw) != metrics:
        raise ValueError("staged metrics do not agree with the raw trace")
    if integrity.get("result_integrity_hash") != result.integrity_hash:
        raise ValueError("staged integrity does not bind the run result")


def _integrity_bytes(result: RunResult, path: Path) -> bytes:
    files = {}
    for name in _ARTIFACT_NAMES:
        payload = (path / name).read_bytes()
        files[name] = {"sha256": _sha256_bytes(payload), "size_bytes": len(payload)}
    return _canonical_mapping_bytes(
        {
            "schema_version": INTEGRITY_SCHEMA_VERSION,
            "result_schema_version": result.schema_version,
            "raw_schema_version": result.raw_trace.schema_version,
            "metrics_schema_version": result.metrics.schema_version,
            "root_case_id": result.root_case_id,
            "arm": result.arm.value,
            "protocol_generation": result.raw_trace.tape.protocol_generation,
            "tape_id": str(result.raw_trace.tape.tape_id),
            "config_hash": result.raw_trace.tape.config_hash,
            "tape_canonical_sha256": _canonical_tape_hash(result.raw_trace.tape),
            "result_integrity_hash": result.integrity_hash,
            "files": files,
        }
    )


def _safe_case_name(result: RunResult) -> str:
    return _case_name(result.root_case_id, result.arm, result.integrity_hash)


def _case_name(root_case_id: str, arm: TapeArm, integrity_hash: str) -> str:
    digest = hashlib.sha256(
        f"{root_case_id}\0{arm.value}\0{integrity_hash}".encode("utf-8")
    ).hexdigest().upper()[:24]
    return f"run-{digest}"


def _canonical_mapping_bytes(value: dict) -> bytes:
    primitive = to_primitive(value)
    return json.dumps(
        primitive,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def _load_json_object(path: Path) -> dict:
    value = _load_json_bytes(path.read_bytes(), path.name)
    if not isinstance(value, dict):
        raise ValueError(f"artifact must contain a JSON object: {path.name}")
    return value


def _load_canonical_json_object(path: Path) -> tuple[dict, bytes]:
    payload = path.read_bytes()
    value = _load_json_bytes(payload, path.name)
    if not isinstance(value, dict):
        raise ValueError(f"artifact must contain a JSON object: {path.name}")
    if payload != _canonical_loaded_object_bytes(value):
        raise ValueError(f"artifact is not canonical JSON: {path.name}")
    return value, payload


def _load_raw_run_trace(path: Path) -> RawRunTrace:
    value, payload = _load_canonical_json_object(path)
    if value.get("schema_version") != RAW_RUN_TRACE_SCHEMA_VERSION:
        raise ValueError("raw artifact has an unsupported schema")
    raw = _decode_value(value, RawRunTrace, "raw_run")
    if raw.schema_version != RAW_RUN_TRACE_SCHEMA_VERSION:
        raise ValueError("raw artifact has an unsupported schema")
    validate_primary_tape(raw.tape)
    if payload != canonical_json_bytes(
        raw, expected_schema_version=RAW_RUN_TRACE_SCHEMA_VERSION
    ):
        raise ValueError("raw artifact does not canonically encode its DTO")
    return raw


def _load_case_metrics(path: Path) -> CaseMetrics:
    value, payload = _load_canonical_json_object(path)
    metrics = _decode_value(value, CaseMetrics, "metrics_case")
    if metrics.schema_version != CASE_METRICS_SCHEMA_VERSION:
        raise ValueError("metrics artifact has an unsupported schema")
    if payload != canonical_json_bytes(
        metrics, expected_schema_version=CASE_METRICS_SCHEMA_VERSION
    ):
        raise ValueError("metrics artifact does not canonically encode its DTO")
    return metrics


def _load_json_bytes(payload: bytes, name: str) -> Any:
    try:
        text = payload.decode("utf-8")
        return json.loads(
            text,
            object_pairs_hook=_closed_json_object,
            parse_float=_reject_json_number,
            parse_constant=_reject_json_number,
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        raise ValueError(f"artifact is not strict UTF-8 JSON: {name}") from exc


def _closed_json_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, item in pairs:
        if key in value:
            raise ValueError(f"duplicate JSON object key: {key}")
        value[key] = item
    return value


def _reject_json_number(value: str) -> Any:
    raise ValueError(f"non-integer JSON number is forbidden: {value}")


def _canonical_loaded_object_bytes(value: dict[str, Any]) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def _require_exact_fields(value: dict, expected: frozenset[str], label: str) -> None:
    if set(value) != expected:
        raise ValueError(f"{label} has an unexpected field set")


@lru_cache(maxsize=None)
def _dataclass_type_hints(dto_type: type) -> dict[str, Any]:
    return get_type_hints(dto_type)


def _decode_value(value: Any, expected_type: Any, location: str) -> Any:
    if expected_type is Any:
        raise ValueError(f"unbounded artifact type is forbidden at {location}")
    if expected_type is type(None):
        if value is not None:
            raise ValueError(f"expected null at {location}")
        return None
    if hasattr(expected_type, "__supertype__"):
        decoded = _decode_value(value, expected_type.__supertype__, location)
        return expected_type(decoded)
    if isinstance(expected_type, type) and issubclass(expected_type, Enum):
        if not isinstance(value, str):
            raise ValueError(f"expected string enum at {location}")
        try:
            return expected_type(value)
        except ValueError as exc:
            raise ValueError(f"unsupported enum value at {location}") from exc
    if isinstance(expected_type, type) and is_dataclass(expected_type):
        if not isinstance(value, dict):
            raise ValueError(f"expected object at {location}")
        expected_fields = frozenset(field.name for field in fields(expected_type))
        _require_exact_fields(value, expected_fields, location)
        hints = _dataclass_type_hints(expected_type)
        decoded_fields = {
            field.name: _decode_value(
                value[field.name], hints[field.name], f"{location}.{field.name}"
            )
            for field in fields(expected_type)
        }
        try:
            return expected_type(**decoded_fields)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"invalid artifact DTO at {location}: {exc}") from exc

    origin = get_origin(expected_type)
    args = get_args(expected_type)
    if origin is tuple:
        if not isinstance(value, list):
            raise ValueError(f"expected JSON array at {location}")
        if len(args) == 2 and args[1] is Ellipsis:
            return tuple(
                _decode_value(item, args[0], f"{location}[{index}]")
                for index, item in enumerate(value)
            )
        if len(value) != len(args):
            raise ValueError(f"tuple length mismatch at {location}")
        return tuple(
            _decode_value(item, item_type, f"{location}[{index}]")
            for index, (item, item_type) in enumerate(zip(value, args, strict=True))
        )
    if origin in (Union, UnionType):
        if value is None and type(None) in args:
            return None
        failures: list[ValueError] = []
        for item_type in args:
            if item_type is type(None):
                continue
            try:
                return _decode_value(value, item_type, location)
            except ValueError as exc:
                failures.append(exc)
        raise ValueError(f"value does not match the closed union at {location}") from (
            failures[-1] if failures else None
        )
    if expected_type is bool:
        if type(value) is not bool:
            raise ValueError(f"expected boolean at {location}")
        return value
    if expected_type is int:
        if type(value) is not int:
            raise ValueError(f"expected integer at {location}")
        return value
    if expected_type is str:
        if type(value) is not str:
            raise ValueError(f"expected string at {location}")
        return value
    raise ValueError(f"unsupported artifact type at {location}: {expected_type!r}")


def _write_bytes(path: Path, payload: bytes) -> None:
    with path.open("xb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())


def _sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest().upper()


def _canonical_raw_hash(raw_trace) -> str:
    return _sha256_bytes(
        canonical_json_bytes(
            raw_trace,
            expected_schema_version=RAW_RUN_TRACE_SCHEMA_VERSION,
        )
    )


def _canonical_tape_hash(tape) -> str:
    return _sha256_bytes(tape_to_bytes(tape))
