"""Request-aware C14.1 adapters used only by the unified offline runner."""

from __future__ import annotations

from .c14_controllers import (
    C14OfflineCacheError,
    PlainLlmControllerAdapter,
    SupervisorControllerAdapter,
)
from .c14_requests import RequestInventoryMaterializer


class _RecordingCache:
    def __init__(self, method_id: str, cache, materializer: RequestInventoryMaterializer) -> None:
        self.method_id = method_id
        self._cache = cache
        self._materializer = materializer
        self._pending_plain = None
        self._pending_full = None

    def set_plain(self, frame, opportunity) -> None:
        self._pending_plain = (frame, opportunity)

    def set_full(self, evidence, opportunity_id: str, program_library_hash: str) -> None:
        self._pending_full = (evidence, opportunity_id, program_library_hash)

    def response_for(self, request_hash: str):
        if self.method_id == "Plain_LLM":
            if self._pending_plain is None:
                raise C14OfflineCacheError("Plain_LLM request context was not materialized")
            frame, opportunity = self._pending_plain
            record = self._materializer.materialize_plain(frame, opportunity)
            self._pending_plain = None
        else:
            if self._pending_full is None:
                raise C14OfflineCacheError("Full request context was not materialized")
            evidence, opportunity_id, library_hash = self._pending_full
            record = self._materializer.materialize_full_evidence(
                evidence,
                program_library_hash=library_hash,
                opportunity_id=opportunity_id,
            )
            self._pending_full = None
        if record.request_hash != request_hash:
            raise C14OfflineCacheError("materialized request hash disagrees with controller")
        return self._cache.response_for(request_hash)


class RequestAwarePlainLlmController(PlainLlmControllerAdapter):
    def __init__(self, method_config_hash, config, cache, materializer) -> None:
        self._recording_cache = _RecordingCache("Plain_LLM", cache, materializer)
        super().__init__(method_config_hash, config, self._recording_cache)

    def decide(self, frame, opportunity):
        self._recording_cache.set_plain(frame, opportunity)
        return super().decide(frame, opportunity)


class RequestAwareFullController(SupervisorControllerAdapter):
    def __init__(self, method_config_hash, config, cache, materializer) -> None:
        self._recording_cache = _RecordingCache("Full", cache, materializer)
        super().__init__(
            "Full",
            method_config_hash,
            config,
            full_cache=self._recording_cache,
        )
        self._request_opportunity_id: str | None = None

    def decide(self, frame, opportunity):
        self._request_opportunity_id = str(opportunity.opportunity_id)
        return super().decide(frame, opportunity)

    def _provider_proposal(self, evidence):
        if self._request_opportunity_id is None:
            raise C14OfflineCacheError("Full request opportunity was not materialized")
        self._recording_cache.set_full(
            evidence,
            self._request_opportunity_id,
            self._library.library_hash,
        )
        self._request_opportunity_id = None
        return super()._provider_proposal(evidence)


def build_request_aware_controller(
    factory,
    method_id: str,
    *,
    cache,
    materializer: RequestInventoryMaterializer,
):
    if method_id == "Full":
        return RequestAwareFullController(
            factory.config_sha256,
            factory.config,
            cache,
            materializer,
        )
    if method_id == "Plain_LLM":
        return RequestAwarePlainLlmController(
            factory.config_sha256,
            factory.config,
            cache,
            materializer,
        )
    raise ValueError("request-aware adapter is only valid for Full and Plain_LLM")
