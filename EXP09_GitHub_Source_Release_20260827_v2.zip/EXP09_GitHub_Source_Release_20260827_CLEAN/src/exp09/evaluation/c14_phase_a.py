"""Fail-closed first-frontier materialization for C14.1 offline caches."""

from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
from typing import Any, Callable
from uuid import uuid4

from exp09.contracts.tape import TapeArm

from .c14_controllers import C14ControllerFactory
from .c14_network_guard import NoNetworkGuard
from .c14_request_adapters import build_request_aware_controller
from .c14_requests import RequestInventoryMaterializer
from .c14_topology import C14MethodCase, C14MethodCaseTopology
from .disturbance_tape import build_primary_influx_tape
from .runner import run_case

PHASE_A_METHODS = ("Full", "Plain_LLM")
PHASE_A_CASE_COUNT = 192
PHASE_A_CASES_PER_METHOD = 96
PHASE_A_FULL_MODEL_TRANSITIONS = 6_912_000
PHASE_A_OUTPUT_LOCATOR = "artifacts/c14_1_offline_cache_phase_a_frontier"
FORMAL_C14_1_OUTPUT_LOCATOR = "artifacts/c14_1_design_validation"

PHASE_A_LEDGER_SCHEMA_VERSION = "exp09-c14-1-offline-cache-phase-a-ledger-v1"
PHASE_A_LEDGER_ROW_SCHEMA_VERSION = "exp09-c14-1-offline-cache-phase-a-row-v1"
PHASE_A_PROVENANCE_SCHEMA_VERSION = "exp09-c14-1-offline-cache-phase-a-provenance-v1"
PHASE_A_AUDIT_SCHEMA_VERSION = "exp09-c14-1-offline-cache-phase-a-audit-v1"
PHASE_A_EXTERNAL_INPUT_SCHEMA_VERSION = (
    "exp09-c14-1-offline-cache-external-response-input-v1"
)
PHASE_A_COMPLETION_SCHEMA_VERSION = "exp09-c14-1-offline-cache-phase-a-completion-v1"

_TERMINAL = frozenset(
    {"CACHE_MISS_FRONTIER_RETAINED", "FAILED_RETAINED", "ABORTED_RETAINED"}
)
_ALLOWED_STATUS = frozenset({"PLANNED", "RUNNING", *_TERMINAL})
_METHOD_BINDINGS = {
    "Full": {
        "namespace": "exp09-c14-1-full-offline-v1",
        "protocol_locator": (
            "protocol/c14/full_offline_provider_protocol.FROZEN_REMEDIATION_20260728.json"
        ),
        "protocol_sha256": (
            "804E31244EFA05DE68AFBAB4A4B5372A0910B5D23AAE564C81553D1C6CCBEFB1"
        ),
    },
    "Plain_LLM": {
        "namespace": "exp09-c14-1-plain-llm-offline-v1",
        "protocol_locator": "protocol/c14/plain_llm_protocol.FROZEN_20260728.json",
        "protocol_sha256": (
            "7C88367EFC64EF29CBF1E7962991D1B5C074C869A3568D3CB65E21A318EDDDFE"
        ),
    },
}


class C14PhaseAError(RuntimeError):
    """Raised when the authorized Phase A boundary cannot be preserved."""


class C14PhaseAFrontierMiss(C14PhaseAError):
    """Expected sentinel raised after one request is durably materialized."""


@dataclass(frozen=True, slots=True)
class PhaseABudgetCaps:
    frontier_cases: int = PHASE_A_CASE_COUNT
    decision_attempts: int = PHASE_A_CASE_COUNT * 2
    model_transitions: int = PHASE_A_FULL_MODEL_TRANSITIONS * 2
    cache_lookup_attempts: int = PHASE_A_CASE_COUNT
    cache_misses: int = PHASE_A_CASE_COUNT
    concurrency: int = 1
    api_calls: int = 0
    provider_calls: int = 0
    llm_tokens: int = 0
    network_attempts: int = 0
    controller_commitments: int = 0
    post_miss_plant_actions: int = 0


@dataclass(frozen=True, slots=True)
class PhaseALedgerRow:
    schema_version: str
    run_id: str
    case_id: str
    source_ordinal: int
    root_case_id: str
    root_namespace: str
    arm: str
    scenario: str
    method_id: str
    variant_id: str
    attempt_ordinal: int
    resume_of: str | None
    status: str
    started_at: str | None
    ended_at: str | None
    decision_attempts: int
    model_transitions: int
    cache_lookup_attempts: int
    cache_misses: int
    request_hash: str | None
    inventory_sha256_at_miss: str | None
    api_calls: int
    provider_calls: int
    llm_tokens: int
    network_attempts: int
    controller_commitments: int
    post_miss_plant_actions: int
    error_code: str | None
    retained_reason: str | None

    def validate(self) -> None:
        if self.schema_version != PHASE_A_LEDGER_ROW_SCHEMA_VERSION:
            raise C14PhaseAError("Phase A ledger row schema mismatch")
        if self.status not in _ALLOWED_STATUS:
            raise C14PhaseAError("Phase A ledger row status is invalid")
        if self.method_id not in PHASE_A_METHODS or self.variant_id != "fixed":
            raise C14PhaseAError("Phase A ledger row escaped the two-method fixed scope")
        counters = (
            self.decision_attempts,
            self.model_transitions,
            self.cache_lookup_attempts,
            self.cache_misses,
            self.api_calls,
            self.provider_calls,
            self.llm_tokens,
            self.network_attempts,
            self.controller_commitments,
            self.post_miss_plant_actions,
        )
        if any(isinstance(value, bool) or not isinstance(value, int) or value < 0 for value in counters):
            raise C14PhaseAError("Phase A ledger counters must be non-negative integers")
        if any(
            value != 0
            for value in (
                self.api_calls,
                self.provider_calls,
                self.llm_tokens,
                self.network_attempts,
                self.controller_commitments,
                self.post_miss_plant_actions,
            )
        ):
            raise C14PhaseAError("Phase A ledger records a forbidden effect")
        if self.status == "PLANNED" and any(
            value is not None
            for value in (
                self.started_at,
                self.ended_at,
                self.request_hash,
                self.error_code,
                self.retained_reason,
            )
        ):
            raise C14PhaseAError("planned Phase A row contains runtime evidence")
        if self.status == "RUNNING" and (self.started_at is None or self.ended_at is not None):
            raise C14PhaseAError("running Phase A row timestamps are invalid")
        if self.status in _TERMINAL and (self.started_at is None or self.ended_at is None):
            raise C14PhaseAError("terminal Phase A row timestamps are incomplete")
        if self.status == "CACHE_MISS_FRONTIER_RETAINED":
            expected_transitions = 72_000 if self.method_id == "Full" else 0
            if (
                self.decision_attempts,
                self.model_transitions,
                self.cache_lookup_attempts,
                self.cache_misses,
            ) != (1, expected_transitions, 1, 1):
                raise C14PhaseAError("retained frontier usage does not match the frozen budget")
            if not _is_sha256(self.request_hash) or not _is_sha256(
                self.inventory_sha256_at_miss
            ):
                raise C14PhaseAError("retained frontier lacks request/inventory hash evidence")
            if self.error_code != "EXPECTED_OFFLINE_CACHE_MISS":
                raise C14PhaseAError("retained frontier error code is not the expected miss")
        if self.status in {"FAILED_RETAINED", "ABORTED_RETAINED"} and not (
            self.error_code and self.retained_reason
        ):
            raise C14PhaseAError("failed Phase A row lacks retained evidence")


class PhaseALedger:
    """Atomic, append-preserving ledger for 192 first-frontier prefixes."""

    def __init__(
        self,
        cases: tuple[C14MethodCase, ...],
        *,
        source_topology_sha256: str,
        phase_a_topology_sha256: str,
        authorization_sha256: str,
    ) -> None:
        validate_phase_a_cases(cases)
        self.cases = cases
        self.source_topology_sha256 = source_topology_sha256
        self.phase_a_topology_sha256 = phase_a_topology_sha256
        self.authorization_sha256 = authorization_sha256
        self.rows = [self._planned_row(case, 0, None) for case in cases]

    def latest(self, case_id: str) -> PhaseALedgerRow:
        matched = [row for row in self.rows if row.case_id == case_id]
        if not matched:
            raise C14PhaseAError("unknown Phase A frontier case")
        return matched[-1]

    def start(self, case: C14MethodCase, *, started_at: str) -> PhaseALedgerRow:
        row = self.latest(case.case_id)
        if row.status != "PLANNED":
            raise C14PhaseAError("Phase A frontier case has no planned attempt")
        index = self.rows.index(row)
        running = replace(
            row,
            status="RUNNING",
            started_at=started_at,
            decision_attempts=1,
            model_transitions=case.transitions_per_opportunity,
        )
        running.validate()
        candidate = [*self.rows]
        candidate[index] = running
        _validate_budget(candidate)
        self.rows[index] = running
        return running

    def record_request(
        self,
        run_id: str,
        *,
        request_hash: str,
        inventory_sha256: str,
    ) -> PhaseALedgerRow:
        index, row = self._running(run_id)
        if row.request_hash is not None or not _is_sha256(request_hash):
            raise C14PhaseAError("Phase A case did not expose exactly one valid request")
        updated = replace(
            row,
            cache_lookup_attempts=1,
            request_hash=request_hash,
            inventory_sha256_at_miss=inventory_sha256,
        )
        updated.validate()
        self.rows[index] = updated
        return updated

    def retain_miss(self, run_id: str, *, ended_at: str) -> PhaseALedgerRow:
        index, row = self._running(run_id)
        retained = replace(
            row,
            status="CACHE_MISS_FRONTIER_RETAINED",
            ended_at=ended_at,
            cache_misses=1,
            error_code="EXPECTED_OFFLINE_CACHE_MISS",
            retained_reason=(
                "first causal request retained; response unavailable and all continuation forbidden"
            ),
        )
        retained.validate()
        self.rows[index] = retained
        return retained

    def retain_failure(
        self,
        run_id: str,
        *,
        ended_at: str,
        error_code: str,
        reason: str,
        aborted: bool = False,
    ) -> PhaseALedgerRow:
        index, row = self._running(run_id)
        retained = replace(
            row,
            status="ABORTED_RETAINED" if aborted else "FAILED_RETAINED",
            ended_at=ended_at,
            error_code=error_code,
            retained_reason=reason,
        )
        retained.validate()
        self.rows[index] = retained
        return retained

    def recover_or_resume(self, *, timestamp: str) -> None:
        for index, row in tuple(enumerate(self.rows)):
            if row.status != "RUNNING":
                continue
            if row.request_hash is not None and row.inventory_sha256_at_miss is not None:
                recovered = replace(
                    row,
                    status="CACHE_MISS_FRONTIER_RETAINED",
                    ended_at=timestamp,
                    cache_misses=1,
                    error_code="EXPECTED_OFFLINE_CACHE_MISS",
                    retained_reason="recovered after interruption following durable frontier write",
                )
                recovered.validate()
                self.rows[index] = recovered
                continue
            aborted = replace(
                row,
                status="ABORTED_RETAINED",
                ended_at=timestamp,
                error_code="INTERRUPTED_BEFORE_DURABLE_FRONTIER",
                retained_reason="interrupted attempt retained before request materialization",
            )
            aborted.validate()
            self.rows[index] = aborted
            self.rows.append(
                self._planned_row(
                    self._case(row.case_id),
                    row.attempt_ordinal + 1,
                    row.run_id,
                )
            )
        for case in self.cases:
            latest = self.latest(case.case_id)
            if latest.status not in {"FAILED_RETAINED", "ABORTED_RETAINED"}:
                continue
            if latest.attempt_ordinal >= 1:
                raise C14PhaseAError("Phase A one-retry hard cap is exhausted")
            self.rows.append(
                self._planned_row(case, latest.attempt_ordinal + 1, latest.run_id)
            )

    def document(self) -> dict[str, Any]:
        _validate_budget(self.rows)
        rows = [asdict(row) for row in self.rows]
        return {
            "schema_version": PHASE_A_LEDGER_SCHEMA_VERSION,
            "artifact_status": "PHASE_A_FRONTIER_LEDGER_EXECUTION_AUTHORITY_EXTERNAL",
            "phase": "C14_1_OFFLINE_CACHE_CLOSURE_PHASE_A_FIRST_FRONTIER",
            "frontier_materialization_authorized": False,
            "c14_1_method_case_execution_authorized": False,
            "source_topology_sha256": self.source_topology_sha256,
            "phase_a_topology_sha256": self.phase_a_topology_sha256,
            "authorization_sha256": self.authorization_sha256,
            "planned_frontier_cases": len(self.cases),
            "attempt_row_count": len(rows),
            "budget_caps": asdict(PhaseABudgetCaps()),
            "budget_usage": _budget_usage(self.rows),
            "rows_sha256": _canonical_sha256(rows),
            "rows": rows,
        }

    def write(self, path: Path) -> str:
        return _atomic_write_json(path, self.document())

    @classmethod
    def load(
        cls,
        path: Path,
        cases: tuple[C14MethodCase, ...],
        *,
        source_topology_sha256: str,
        phase_a_topology_sha256: str,
        authorization_sha256: str,
    ) -> PhaseALedger:
        document = _strict_json(path)
        if not isinstance(document, dict) or document.get("schema_version") != (
            PHASE_A_LEDGER_SCHEMA_VERSION
        ):
            raise C14PhaseAError("Phase A runtime ledger schema mismatch")
        expected_bindings = (
            document.get("source_topology_sha256"),
            document.get("phase_a_topology_sha256"),
            document.get("authorization_sha256"),
        )
        if expected_bindings != (
            source_topology_sha256,
            phase_a_topology_sha256,
            authorization_sha256,
        ):
            raise C14PhaseAError("Phase A runtime ledger binding mismatch")
        raw_rows = document.get("rows")
        if not isinstance(raw_rows, list) or document.get("rows_sha256") != (
            _canonical_sha256(raw_rows)
        ):
            raise C14PhaseAError("Phase A runtime ledger row hash mismatch")
        ledger = cls(
            cases,
            source_topology_sha256=source_topology_sha256,
            phase_a_topology_sha256=phase_a_topology_sha256,
            authorization_sha256=authorization_sha256,
        )
        ledger.rows = [PhaseALedgerRow(**value) for value in raw_rows]
        for row in ledger.rows:
            row.validate()
            case = ledger._case(row.case_id)
            if (
                row.source_ordinal,
                row.root_case_id,
                row.root_namespace,
                row.arm,
                row.scenario,
                row.method_id,
                row.variant_id,
            ) != (
                case.ordinal,
                case.root_case_id,
                case.root_namespace,
                case.arm,
                case.scenario,
                case.method_id,
                case.variant_id,
            ):
                raise C14PhaseAError("Phase A ledger row drifted from the frozen topology")
        _validate_attempt_history(ledger.rows, cases)
        if document.get("budget_caps") != asdict(PhaseABudgetCaps()) or document.get(
            "budget_usage"
        ) != _budget_usage(ledger.rows):
            raise C14PhaseAError("Phase A runtime ledger budget accounting mismatch")
        return ledger

    def _planned_row(
        self,
        case: C14MethodCase,
        attempt_ordinal: int,
        resume_of: str | None,
    ) -> PhaseALedgerRow:
        row = PhaseALedgerRow(
            schema_version=PHASE_A_LEDGER_ROW_SCHEMA_VERSION,
            run_id=f"phase-a__{case.case_id}__attempt{attempt_ordinal:03d}",
            case_id=case.case_id,
            source_ordinal=case.ordinal,
            root_case_id=case.root_case_id,
            root_namespace=case.root_namespace,
            arm=case.arm,
            scenario=case.scenario,
            method_id=case.method_id,
            variant_id=case.variant_id,
            attempt_ordinal=attempt_ordinal,
            resume_of=resume_of,
            status="PLANNED",
            started_at=None,
            ended_at=None,
            decision_attempts=0,
            model_transitions=0,
            cache_lookup_attempts=0,
            cache_misses=0,
            request_hash=None,
            inventory_sha256_at_miss=None,
            api_calls=0,
            provider_calls=0,
            llm_tokens=0,
            network_attempts=0,
            controller_commitments=0,
            post_miss_plant_actions=0,
            error_code=None,
            retained_reason=None,
        )
        row.validate()
        return row

    def _running(self, run_id: str) -> tuple[int, PhaseALedgerRow]:
        matches = [(index, row) for index, row in enumerate(self.rows) if row.run_id == run_id]
        if len(matches) != 1 or matches[0][1].status != "RUNNING":
            raise C14PhaseAError("run_id does not identify one running Phase A attempt")
        return matches[0]

    def _case(self, case_id: str) -> C14MethodCase:
        matches = [case for case in self.cases if case.case_id == case_id]
        if len(matches) != 1:
            raise C14PhaseAError("Phase A ledger case identity is invalid")
        return matches[0]


class _FirstMissCache:
    def __init__(self, method_id: str, on_lookup: Callable[[str], None]) -> None:
        self.method_id = method_id
        self._on_lookup = on_lookup
        self.lookup_count = 0

    def response_for(self, request_hash: str) -> dict[str, Any]:
        if self.lookup_count != 0:
            raise C14PhaseAError("Phase A case attempted more than one cache lookup")
        self.lookup_count = 1
        self._on_lookup(request_hash)
        raise C14PhaseAFrontierMiss(
            "expected first offline-cache miss retained; continuation is forbidden"
        )


class _NoCommitmentController:
    def __init__(self, controller: Any) -> None:
        self._controller = controller

    def reset(self, context: Any) -> None:
        self._controller.reset(context)

    def decide(self, frame: Any, opportunity: Any) -> Any:
        result = self._controller.decide(frame, opportunity)
        del result
        raise C14PhaseAError("controller returned a commitment past the first-miss boundary")


class PhaseAFirstFrontierRunner:
    """Run only the causal prefix needed to expose one miss per selected case."""

    def __init__(
        self,
        project_root: Path,
        topology: C14MethodCaseTopology,
        controller_factory: C14ControllerFactory,
        authorization: dict[str, Any],
        *,
        authorization_sha256: str,
        output_root: Path,
        frontier_executor: Callable[[C14MethodCase, Any], None] | None = None,
        controller_builder: Callable[..., Any] = build_request_aware_controller,
    ) -> None:
        self.project_root = project_root.resolve()
        self.topology = topology
        self.controller_factory = controller_factory
        self.authorization = authorization
        self.authorization_sha256 = authorization_sha256
        self.output_root = output_root.resolve()
        expected_output = (self.project_root / PHASE_A_OUTPUT_LOCATOR).resolve()
        if self.output_root != expected_output:
            raise C14PhaseAError("Phase A output must use its dedicated artifact directory")
        if self.output_root == (self.project_root / FORMAL_C14_1_OUTPUT_LOCATOR).resolve():
            raise C14PhaseAError("Phase A cannot write the formal C14.1 artifact directory")
        self.cases = phase_a_cases(topology)
        self.phase_a_topology_sha256 = phase_a_topology_sha256(self.cases)
        self.source_topology_sha256 = _sha256(topology.source_path)
        validate_authorization(
            authorization,
            source_topology_sha256=self.source_topology_sha256,
            phase_a_topology_sha256=self.phase_a_topology_sha256,
            method_config_sha256=topology.method_config_sha256,
        )
        self._validate_authorized_protocol_files()
        self.frontier_executor = frontier_executor or self._execute_real_prefix
        self.controller_builder = controller_builder
        self.ledger_path = self.output_root / "phase_a_frontier_ledger.json"
        self.inventory_paths = {
            method: self.output_root / f"{method}.first_frontier_request_inventory.json"
            for method in PHASE_A_METHODS
        }
        self.materializers = {
            "Full": RequestInventoryMaterializer(
                method_id="Full",
                namespace=authorization["methods"]["Full"]["namespace"],
                method_config_sha256=topology.method_config_sha256,
                protocol_sha256=authorization["methods"]["Full"]["protocol_sha256"],
            ),
            "Plain_LLM": RequestInventoryMaterializer(
                method_id="Plain_LLM",
                namespace=authorization["methods"]["Plain_LLM"]["namespace"],
                method_config_sha256=topology.method_config_sha256,
                protocol_sha256=authorization["methods"]["Plain_LLM"]["protocol_sha256"],
            ),
        }
        self._existing_inventory_records = {
            method: self._load_existing_inventory(method) for method in PHASE_A_METHODS
        }
        self.ledger = self._load_or_create_ledger()

    def run(self) -> dict[str, Any]:
        self.output_root.mkdir(parents=True, exist_ok=True)
        self.ledger.recover_or_resume(timestamp=_timestamp())
        self.ledger.write(self.ledger_path)
        for case in self.cases:
            latest = self.ledger.latest(case.case_id)
            if latest.status == "CACHE_MISS_FRONTIER_RETAINED":
                continue
            if latest.status != "PLANNED":
                raise C14PhaseAError(
                    f"Phase A stopped on retained non-frontier status: {case.case_id}"
                )
            self._run_case(case)
        return self._finalize()

    def _run_case(self, case: C14MethodCase) -> None:
        running = self.ledger.start(case, started_at=_timestamp())
        self.ledger.write(self.ledger_path)
        cache = _FirstMissCache(
            case.method_id,
            lambda request_hash: self._persist_frontier(running.run_id, case, request_hash),
        )
        controller = self.controller_builder(
            self.controller_factory,
            case.method_id,
            cache=cache,
            materializer=self.materializers[case.method_id],
        )
        try:
            with NoNetworkGuard():
                self.frontier_executor(case, _NoCommitmentController(controller))
        except C14PhaseAFrontierMiss:
            if cache.lookup_count != 1:
                raise C14PhaseAError("expected miss occurred without exactly one lookup")
            self.ledger.retain_miss(running.run_id, ended_at=_timestamp())
            self.ledger.write(self.ledger_path)
            return
        except BaseException as exc:
            self.ledger.retain_failure(
                running.run_id,
                ended_at=_timestamp(),
                error_code=type(exc).__name__,
                reason=str(exc),
                aborted=isinstance(exc, (KeyboardInterrupt, SystemExit)),
            )
            self.ledger.write(self.ledger_path)
            raise
        raise C14PhaseAError("Phase A frontier executor returned without the expected miss")

    def _persist_frontier(
        self,
        run_id: str,
        case: C14MethodCase,
        request_hash: str,
    ) -> None:
        materializer = self.materializers[case.method_id]
        if request_hash not in materializer.request_hashes:
            raise C14PhaseAError("cache lookup occurred before causal request materialization")
        inventory = self._merged_inventory_document(case.method_id)
        inventory_sha = _atomic_write_json(self.inventory_paths[case.method_id], inventory)
        self.ledger.record_request(
            run_id,
            request_hash=request_hash,
            inventory_sha256=inventory_sha,
        )
        self.ledger.write(self.ledger_path)

    def _merged_inventory_document(self, method_id: str) -> dict[str, Any]:
        new_document = self.materializers[method_id].inventory_document(
            synthetic_fixture=False
        )
        merged: list[dict[str, Any]] = []
        by_hash: dict[str, bytes] = {}
        for record in (
            *self._existing_inventory_records[method_id],
            *new_document["records"],
        ):
            request_hash = record.get("request_hash")
            payload = _canonical_json_bytes(record.get("request_payload"))
            existing = by_hash.get(request_hash)
            if existing is not None:
                if existing != payload:
                    raise C14PhaseAError("one request hash maps to different frontier payloads")
                continue
            by_hash[request_hash] = payload
            merged.append(record)
        new_document["artifact_status"] = (
            "MATERIALIZED_FROM_AUTHORIZED_C14_1_FIRST_FRONTIER_ONLY"
        )
        new_document["request_count"] = len(merged)
        new_document["request_hashes"] = [record["request_hash"] for record in merged]
        new_document["records_sha256"] = _canonical_sha256(merged)
        new_document["records"] = merged
        return new_document

    def _load_existing_inventory(self, method_id: str) -> tuple[dict[str, Any], ...]:
        path = self.inventory_paths[method_id]
        if not path.exists():
            return ()
        document = _strict_json(path)
        expected = self.materializers[method_id].inventory_document(synthetic_fixture=False)
        expected["artifact_status"] = (
            "MATERIALIZED_FROM_AUTHORIZED_C14_1_FIRST_FRONTIER_ONLY"
        )
        for field in ("schema_version", "artifact_status", "method_id", "namespace"):
            if document.get(field) != expected[field]:
                raise C14PhaseAError("existing Phase A inventory identity mismatch")
        if document.get("method_config_sha256") != self.topology.method_config_sha256 or (
            document.get("protocol_sha256")
            != self.authorization["methods"][method_id]["protocol_sha256"]
        ):
            raise C14PhaseAError("existing Phase A inventory binding mismatch")
        records = document.get("records")
        if not isinstance(records, list) or document.get("records_sha256") != (
            _canonical_sha256(records)
        ):
            raise C14PhaseAError("existing Phase A inventory record hash mismatch")
        if document.get("request_hashes") != [record.get("request_hash") for record in records]:
            raise C14PhaseAError("existing Phase A inventory ordering mismatch")
        return tuple(records)

    def _validate_authorized_protocol_files(self) -> None:
        for method_id in PHASE_A_METHODS:
            binding = self.authorization["methods"][method_id]
            locator = binding["protocol_locator"]
            path = (self.project_root / locator).resolve()
            try:
                path.relative_to(self.project_root)
            except ValueError as exc:
                raise C14PhaseAError("Phase A protocol locator escapes the project") from exc
            if not path.is_file() or _sha256(path) != binding["protocol_sha256"]:
                raise C14PhaseAError("Phase A authorized protocol binding mismatch")

    def _load_or_create_ledger(self) -> PhaseALedger:
        if self.ledger_path.exists():
            return PhaseALedger.load(
                self.ledger_path,
                self.cases,
                source_topology_sha256=self.source_topology_sha256,
                phase_a_topology_sha256=self.phase_a_topology_sha256,
                authorization_sha256=self.authorization_sha256,
            )
        return PhaseALedger(
            self.cases,
            source_topology_sha256=self.source_topology_sha256,
            phase_a_topology_sha256=self.phase_a_topology_sha256,
            authorization_sha256=self.authorization_sha256,
        )

    def _execute_real_prefix(self, case: C14MethodCase, controller: Any) -> None:
        tape = build_primary_influx_tape(case.root_case_id, TapeArm(case.arm))
        run_case(tape, controller=controller)

    def _finalize(self) -> dict[str, Any]:
        audit = audit_phase_a_artifacts(
            self.project_root,
            self.output_root,
            self.cases,
            self.ledger,
            self.inventory_paths,
        )
        provenance = self._provenance_document()
        provenance_path = self.output_root / "phase_a_frontier_provenance.json"
        provenance_sha = _atomic_write_json(provenance_path, provenance)
        audit["provenance"] = {
            "locator": provenance_path.relative_to(self.project_root).as_posix(),
            "sha256": provenance_sha,
        }
        audit_path = self.output_root / "phase_a_frontier_audit.json"
        audit_sha = _atomic_write_json(audit_path, audit)
        external_input = self._external_input_document(audit_path, audit_sha)
        external_path = self.output_root / "external_response_generation_input.json"
        external_sha = _atomic_write_json(external_path, external_input)
        completion = {
            "schema_version": PHASE_A_COMPLETION_SCHEMA_VERSION,
            "artifact_status": (
                "PHASE_A_FIRST_FRONTIER_COMPLETE_STOPPED_AWAITING_EXTERNAL_RESPONSES"
            ),
            "completed_at": _timestamp(),
            "phase_a_first_frontier_complete": True,
            "frontier_case_count": PHASE_A_CASE_COUNT,
            "c14_1_method_cases_executed": 0,
            "cache_qualified": False,
            "c14_1_execution_authorized": False,
            "performance_statistics_generated": False,
            "training_capability": "DISABLED",
            "api_calls": 0,
            "provider_calls": 0,
            "llm_tokens": 0,
            "network_attempts": 0,
            "forbidden_stages_executed": [],
            "bindings": {
                "authorization_sha256": self.authorization_sha256,
                "ledger_sha256": _sha256(self.ledger_path),
                "provenance_sha256": provenance_sha,
                "audit_sha256": audit_sha,
                "external_response_generation_input_sha256": external_sha,
            },
            "next_action": "AUTHOR_GENERATES_FIRST_FRONTIER_RESPONSES_OUTSIDE_REPOSITORY",
            "automatic_continuation": False,
        }
        completion_path = self.output_root / "phase_a_first_frontier_completion.json"
        completion_sha = _atomic_write_json(completion_path, completion)
        return {
            "completion_locator": completion_path.relative_to(self.project_root).as_posix(),
            "completion_sha256": completion_sha,
            "external_input_locator": external_path.relative_to(self.project_root).as_posix(),
            "external_input_sha256": external_sha,
            "audit": audit,
        }

    def _provenance_document(self) -> dict[str, Any]:
        bindings = []
        for role, locator in (
            (
                "SOURCE_2304_TOPOLOGY",
                "protocol/c14/c14_1_method_case_topology.FROZEN_PREFLIGHT_20260729.json",
            ),
            (
                "DESIGN_ROOTS",
                "protocol/c14/c14_1_design_roots.FROZEN_20260728.json",
            ),
            ("METHOD_CONFIG", self.topology.method_config_locator),
            (
                "FULL_PROTOCOL",
                self.authorization["methods"]["Full"]["protocol_locator"],
            ),
            (
                "PLAIN_LLM_PROTOCOL",
                self.authorization["methods"]["Plain_LLM"]["protocol_locator"],
            ),
        ):
            path = self.project_root / locator
            bindings.append({"role": role, "locator": locator, "sha256": _sha256(path)})
        return {
            "schema_version": PHASE_A_PROVENANCE_SCHEMA_VERSION,
            "artifact_status": "FIRST_FRONTIER_CAUSAL_INPUT_PROVENANCE_RETAINED",
            "authorization_sha256": self.authorization_sha256,
            "source_topology_sha256": self.source_topology_sha256,
            "phase_a_topology_sha256": self.phase_a_topology_sha256,
            "bindings": bindings,
            "materialization": (
                "request-aware controller at the first offline response lookup under "
                "process-local NoNetworkGuard"
            ),
            "response_bytes_read": 0,
            "network_fallback": False,
            "c14_1_method_cases_executed": 0,
        }

    def _external_input_document(self, audit_path: Path, audit_sha: str) -> dict[str, Any]:
        methods = {}
        for method_id in PHASE_A_METHODS:
            inventory_path = self.inventory_paths[method_id]
            inventory = _strict_json(inventory_path)
            methods[method_id] = {
                "inventory_locator": inventory_path.relative_to(self.project_root).as_posix(),
                "inventory_sha256": _sha256(inventory_path),
                "frontier_case_count": PHASE_A_CASES_PER_METHOD,
                "unique_request_count": inventory["request_count"],
                "namespace": inventory["namespace"],
                "method_config_sha256": inventory["method_config_sha256"],
                "protocol_locator": self.authorization["methods"][method_id][
                    "protocol_locator"
                ],
                "protocol_sha256": inventory["protocol_sha256"],
                "required_request_hashes": inventory["request_hashes"],
            }
        return {
            "schema_version": PHASE_A_EXTERNAL_INPUT_SCHEMA_VERSION,
            "artifact_status": "READY_FOR_EXTERNAL_FIRST_FRONTIER_RESPONSE_GENERATION",
            "generation_scope": "FIRST_FRONTIER_ONLY_NOT_COMPLETE_C14_1_CACHE",
            "authorization_sha256": self.authorization_sha256,
            "audit": {
                "locator": audit_path.relative_to(self.project_root).as_posix(),
                "sha256": audit_sha,
            },
            "methods": methods,
            "generation_rules": {
                "request_payloads_are_immutable": True,
                "one_response_per_unique_request_in_inventory_order": True,
                "response_binding_serialization": (
                    "UTF8_JSON_SORT_KEYS_COMPACT_ALLOW_NAN_FALSE"
                ),
                "source_artifact_and_sha256_required": True,
                "bundle_and_sha256_required": True,
                "network_fallback": False,
                "repository_generation_forbidden": True,
                "full_response_schema": {
                    "proposal": {
                        "transition_id": (
                            "START|HOLD|ADVANCE|SWITCH|RETURN_BALANCED"
                        ),
                        "target_program_id": "balanced|protect-freshness|null",
                        "rationale_code": (
                            "NO_CHANGE|EVIDENCE_SUPPORTED_TRANSITION|"
                            "HOLD_UNCERTAIN_EVIDENCE|RETURN_TO_BALANCED"
                        ),
                    },
                    "response_hash": "provider_response_hash(request_hash, proposal)",
                },
                "plain_llm_response_schema": {
                    "schema_version": "exp09-c14-1-plain-llm-output-v1",
                    "candidate_order": "exact permutation of eligible_actions",
                    "chosen_action_id": "candidate_order[0]",
                    "confidence_ppm": "integer in [0,1000000]",
                    "rationale_code": (
                        "FRESHNESS_PRIORITY|COLLISION_RISK_PRIORITY|"
                        "BALANCED_OBSERVABLE_TRADEOFF|"
                        "INSUFFICIENT_OBSERVABLE_EVIDENCE"
                    ),
                },
            },
            "qualification_state": {
                "first_frontier_responses_provided": False,
                "complete_c14_1_request_inventory": False,
                "cache_qualified": False,
                "c14_1_execution_authorized": False,
            },
            "automatic_continuation": False,
        }


def phase_a_cases(topology: C14MethodCaseTopology) -> tuple[C14MethodCase, ...]:
    cases = tuple(case for case in topology.cases if case.method_id in PHASE_A_METHODS)
    validate_phase_a_cases(cases)
    return cases


def validate_phase_a_cases(cases: tuple[C14MethodCase, ...]) -> None:
    if len(cases) != PHASE_A_CASE_COUNT or len({case.case_id for case in cases}) != len(cases):
        raise C14PhaseAError("Phase A requires exactly 192 unique frontier cases")
    if any(
        case.method_id not in PHASE_A_METHODS
        or case.train_seed is not None
        or case.variant_id != "fixed"
        for case in cases
    ):
        raise C14PhaseAError("Phase A contains a forbidden method or train seed")
    counts = {method: sum(case.method_id == method for case in cases) for method in PHASE_A_METHODS}
    if counts != {method: PHASE_A_CASES_PER_METHOD for method in PHASE_A_METHODS}:
        raise C14PhaseAError("Phase A method counts are not 96/96")
    roots = {case.root_case_id for case in cases}
    if len(roots) != 48:
        raise C14PhaseAError("Phase A does not cover exactly 48 roots")
    expected = {
        (root, arm, method) for root in roots for arm in ("REFERENCE", "EVENT") for method in PHASE_A_METHODS
    }
    if {(case.root_case_id, case.arm, case.method_id) for case in cases} != expected:
        raise C14PhaseAError("Phase A root/arm/method cross-product is incomplete")


def phase_a_topology_sha256(cases: tuple[C14MethodCase, ...]) -> str:
    validate_phase_a_cases(cases)
    return _canonical_sha256([asdict(case) for case in cases])


def load_authorization(project_root: Path, locator: str) -> tuple[dict[str, Any], str]:
    root = project_root.resolve()
    path = (root / locator).resolve()
    try:
        path.relative_to(root)
    except ValueError as exc:
        raise C14PhaseAError("Phase A authorization locator escapes the project") from exc
    document = _strict_json(path)
    if not isinstance(document, dict):
        raise C14PhaseAError("Phase A authorization must be a JSON object")
    return document, _sha256(path)


def validate_authorization(
    document: dict[str, Any],
    *,
    source_topology_sha256: str,
    phase_a_topology_sha256: str,
    method_config_sha256: str,
) -> None:
    if document.get("schema_version") != "exp09-c14-1-offline-cache-phase-a-authorization-v1":
        raise C14PhaseAError("Phase A authorization schema mismatch")
    if document.get("artifact_status") != "FROZEN_USER_AUTHORIZED_FIRST_FRONTIER_ONLY":
        raise C14PhaseAError("Phase A authorization status mismatch")
    gates = document.get("gates", {})
    if gates != {
        "first_frontier_materialization_authorized": True,
        "cache_miss_continuation_authorized": False,
        "c14_1_method_case_execution_authorized": False,
        "api_provider_llm_authorized": False,
        "network_fallback_authorized": False,
        "training_authorized": False,
        "performance_statistics_authorized": False,
        "c14_2_authorized": False,
        "shadow_authorized": False,
        "precision_authorized": False,
        "locked_test_authorized": False,
    }:
        raise C14PhaseAError("Phase A authorization gates are not fail closed")
    topology = document.get("topology", {})
    if (
        topology.get("source_topology_sha256"),
        topology.get("phase_a_topology_sha256"),
        topology.get("frontier_case_count"),
        topology.get("root_count"),
        topology.get("arms"),
        topology.get("methods"),
    ) != (
        source_topology_sha256,
        phase_a_topology_sha256,
        PHASE_A_CASE_COUNT,
        48,
        ["REFERENCE", "EVENT"],
        list(PHASE_A_METHODS),
    ):
        raise C14PhaseAError("Phase A authorization topology binding mismatch")
    if document.get("method_config_sha256") != method_config_sha256:
        raise C14PhaseAError("Phase A authorization method-config binding mismatch")
    if document.get("budget_caps") != asdict(PhaseABudgetCaps()):
        raise C14PhaseAError("Phase A authorization budget mismatch")
    methods = document.get("methods")
    if not isinstance(methods, dict) or set(methods) != set(PHASE_A_METHODS):
        raise C14PhaseAError("Phase A authorization method bindings are incomplete")
    for method_id, binding in methods.items():
        if binding.get("case_count") != PHASE_A_CASES_PER_METHOD:
            raise C14PhaseAError("Phase A authorization per-method count mismatch")
        expected = _METHOD_BINDINGS[method_id]
        if {
            "namespace": binding.get("namespace"),
            "protocol_locator": binding.get("protocol_locator"),
            "protocol_sha256": binding.get("protocol_sha256"),
        } != expected:
            raise C14PhaseAError("Phase A protocol/namespace binding mismatch")


def audit_phase_a_artifacts(
    project_root: Path,
    output_root: Path,
    cases: tuple[C14MethodCase, ...],
    ledger: PhaseALedger,
    inventory_paths: dict[str, Path],
) -> dict[str, Any]:
    validate_phase_a_cases(cases)
    latest = [ledger.latest(case.case_id) for case in cases]
    if any(row.status != "CACHE_MISS_FRONTIER_RETAINED" for row in latest):
        raise C14PhaseAError("Phase A audit found an incomplete frontier case")
    if len({row.case_id for row in latest}) != PHASE_A_CASE_COUNT:
        raise C14PhaseAError("Phase A audit case coverage mismatch")
    usage = _budget_usage(ledger.rows)
    expected_usage = {
        "frontier_cases": PHASE_A_CASE_COUNT,
        "decision_attempts": PHASE_A_CASE_COUNT,
        "model_transitions": PHASE_A_FULL_MODEL_TRANSITIONS,
        "cache_lookup_attempts": PHASE_A_CASE_COUNT,
        "cache_misses": PHASE_A_CASE_COUNT,
        "concurrency": 0,
        "api_calls": 0,
        "provider_calls": 0,
        "llm_tokens": 0,
        "network_attempts": 0,
        "controller_commitments": 0,
        "post_miss_plant_actions": 0,
    }
    if usage != expected_usage:
        raise C14PhaseAError("Phase A aggregate budget evidence mismatch")
    inventories: dict[str, Any] = {}
    for method_id, path in inventory_paths.items():
        document = _strict_json(path)
        records = document.get("records")
        hashes = document.get("request_hashes")
        if (
            not isinstance(records, list)
            or not isinstance(hashes, list)
            or document.get("records_sha256") != _canonical_sha256(records)
            or hashes != [record.get("request_hash") for record in records]
            or len(hashes) != len(set(hashes))
        ):
            raise C14PhaseAError("Phase A inventory failed hash/uniqueness audit")
        case_hashes = [row.request_hash for row in latest if row.method_id == method_id]
        if set(case_hashes) != set(hashes):
            raise C14PhaseAError("Phase A ledger requests do not match the inventory")
        inventories[method_id] = {
            "frontier_case_count": len(case_hashes),
            "unique_request_count": len(hashes),
            "duplicate_case_request_count": len(case_hashes) - len(set(case_hashes)),
            "hash_collision_count": 0,
            "locator": path.relative_to(project_root).as_posix(),
            "sha256": _sha256(path),
            "records_sha256": document["records_sha256"],
        }
    if (project_root / FORMAL_C14_1_OUTPUT_LOCATOR).exists():
        raise C14PhaseAError("formal C14.1 artifact directory exists during Phase A audit")
    return {
        "schema_version": PHASE_A_AUDIT_SCHEMA_VERSION,
        "artifact_status": "PHASE_A_FIRST_FRONTIER_AUDIT_PASS",
        "passed": True,
        "frontier_case_count": PHASE_A_CASE_COUNT,
        "root_count": 48,
        "arms": ["REFERENCE", "EVENT"],
        "methods": list(PHASE_A_METHODS),
        "inventories": inventories,
        "budget_usage": usage,
        "ledger": {
            "locator": (output_root / "phase_a_frontier_ledger.json")
            .relative_to(project_root)
            .as_posix(),
            "sha256": _sha256(output_root / "phase_a_frontier_ledger.json"),
        },
        "c14_1_method_cases_executed": 0,
        "performance_statistics_generated": False,
        "response_bytes_read": 0,
        "cache_miss_continuations": 0,
        "api_calls": 0,
        "provider_calls": 0,
        "llm_tokens": 0,
        "network_attempts": 0,
        "training_capability": "DISABLED",
        "forbidden_stages_executed": [],
        "formal_c14_1_artifact_created": False,
    }


def _validate_budget(rows: list[PhaseALedgerRow]) -> None:
    usage = _budget_usage(rows)
    caps = asdict(PhaseABudgetCaps())
    for field, value in usage.items():
        if value > caps[field]:
            raise C14PhaseAError(f"Phase A hard budget exceeded: {field}")


def _budget_usage(rows: list[PhaseALedgerRow]) -> dict[str, int]:
    return {
        "frontier_cases": sum(
            row.attempt_ordinal == 0 and row.status != "PLANNED" for row in rows
        ),
        "decision_attempts": sum(row.decision_attempts for row in rows),
        "model_transitions": sum(row.model_transitions for row in rows),
        "cache_lookup_attempts": sum(row.cache_lookup_attempts for row in rows),
        "cache_misses": sum(row.cache_misses for row in rows),
        "concurrency": sum(row.status == "RUNNING" for row in rows),
        "api_calls": sum(row.api_calls for row in rows),
        "provider_calls": sum(row.provider_calls for row in rows),
        "llm_tokens": sum(row.llm_tokens for row in rows),
        "network_attempts": sum(row.network_attempts for row in rows),
        "controller_commitments": sum(row.controller_commitments for row in rows),
        "post_miss_plant_actions": sum(row.post_miss_plant_actions for row in rows),
    }


def _validate_attempt_history(
    rows: list[PhaseALedgerRow], cases: tuple[C14MethodCase, ...]
) -> None:
    by_case: dict[str, list[PhaseALedgerRow]] = {case.case_id: [] for case in cases}
    for row in rows:
        if row.case_id not in by_case:
            raise C14PhaseAError("Phase A ledger contains an out-of-scope case")
        by_case[row.case_id].append(row)
    for case_id, attempts in by_case.items():
        if not attempts or [row.attempt_ordinal for row in attempts] != list(
            range(len(attempts))
        ):
            raise C14PhaseAError("Phase A attempt history is not contiguous")
        for index, row in enumerate(attempts):
            expected_id = f"phase-a__{case_id}__attempt{index:03d}"
            if row.run_id != expected_id:
                raise C14PhaseAError("Phase A run identifier mismatch")
            if index == 0 and row.resume_of is not None:
                raise C14PhaseAError("initial Phase A attempt cannot be a resume")
            if index > 0 and row.resume_of != attempts[index - 1].run_id:
                raise C14PhaseAError("Phase A resume binding mismatch")
            if index > 0 and attempts[index - 1].status not in {
                "FAILED_RETAINED",
                "ABORTED_RETAINED",
            }:
                raise C14PhaseAError("Phase A resume does not follow a retained abort")


def _atomic_write_json(path: Path, document: dict[str, Any]) -> str:
    payload = _canonical_json_bytes(document)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{uuid4().hex}")
    try:
        with temporary.open("xb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        if temporary.exists():
            temporary.unlink()
        raise
    return hashlib.sha256(payload).hexdigest().upper()


def _strict_json(path: Path) -> Any:
    def reject_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise C14PhaseAError(f"duplicate JSON key is forbidden: {key}")
            result[key] = value
        return result

    try:
        return json.loads(
            Path(path).read_text(encoding="utf-8"),
            object_pairs_hook=reject_duplicates,
            parse_constant=lambda value: (_ for _ in ()).throw(
                C14PhaseAError(f"non-finite JSON value is forbidden: {value}")
            ),
        )
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise C14PhaseAError(f"strict JSON read failed: {path}") from exc


def _canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def _canonical_sha256(value: Any) -> str:
    return hashlib.sha256(_canonical_json_bytes(value)).hexdigest().upper()


def _sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest().upper()


def _is_sha256(value: Any) -> bool:
    if not isinstance(value, str) or len(value) != 64:
        return False
    return all(character in "0123456789ABCDEFabcdef" for character in value)


def _timestamp() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="microseconds")
