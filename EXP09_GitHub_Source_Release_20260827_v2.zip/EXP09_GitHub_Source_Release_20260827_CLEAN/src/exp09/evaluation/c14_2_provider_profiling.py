"""Fail-closed C14.2 provider profiling for the two frozen provider tasks."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import socket
import time
from http.client import RemoteDisconnected
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import (
    HTTPRedirectHandler,
    HTTPSHandler,
    ProxyHandler,
    Request,
    build_opener,
)

from .c14_v2_closure import load_provider_credentials


PROTOCOL_GENERATION = "EXP09_C14_2_PROVIDER_PROFILE_20260801"
MODEL_IDENTIFIER = "gpt-5.4-mini"
MODEL_REVISION = "gpt-5.4-mini-2026-03-17"
ENDPOINT = "https://relay.nf.video/v1"
ENDPOINT_HOST = "relay.nf.video"
INPUT_TOKEN_CAP = 8_192
OUTPUT_TOKEN_CAP = 512
TIMEOUT_SECONDS = 30
RETRY_BUDGET = 0
ATTEMPTS_PER_TASK = 300
API_ATTEMPT_CAP = 600
COST_CAP_USD = 500.0
TASKS = ("ProgramProposal", "Plain_LLM")
PROMPT_LOCATORS = {
    "ProgramProposal": "protocol/c14/full_protocol.C14_1_OFFLINE_CACHE_V2_20260729.json",
    "Plain_LLM": "protocol/c14/plain_llm_protocol.C14_1_OFFLINE_CACHE_V2_20260729.json",
}
CONFIG_LOCATOR = "protocol/c14/provider_config.C14_1_OFFLINE_CACHE_V3_GPT54MINI_20260730.json"
METHOD_CONFIG_LOCATOR = "protocol/c14/method_config.C14_1_OFFLINE_CACHE_V3_GPT54MINI_20260730.json"


class ProfilingError(RuntimeError):
    """Raised when the profiling run must stop without fallback."""


class UnknownResponseError(ProfilingError):
    """Raised when the server response outcome cannot be established."""


@dataclass(frozen=True, slots=True)
class CallResult:
    status: str
    wall_ms: int
    response_body_sha256: str | None
    parsed_response_sha256: str | None
    model_returned: str | None
    input_tokens: int
    output_tokens: int
    total_tokens: int
    error_category: str | None
    error_code: str | None
    http_status: int | None


def canonical_bytes(value: object) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")


def canonical_sha(value: object) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest().upper()


def file_sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def timestamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def percentile(values: list[int], fraction: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    index = max(0, min(len(ordered) - 1, int((len(ordered) * fraction + 0.999999999) - 1)))
    return ordered[index]


def estimate_cost(input_tokens: int, output_tokens: int) -> float:
    return round(input_tokens * 0.75 / 1_000_000 + output_tokens * 4.5 / 1_000_000, 9)


def _strict_json(path: Path) -> dict:
    def pairs(items: list[tuple[str, object]]) -> dict:
        result: dict[str, object] = {}
        for key, value in items:
            if key in result:
                raise ProfilingError(f"duplicate JSON key in {path.name}")
            result[key] = value
        return result

    try:
        value = json.loads(
            path.read_text(encoding="utf-8"),
            object_pairs_hook=pairs,
            parse_constant=lambda item: (_ for _ in ()).throw(
                ProfilingError(f"non-finite JSON value: {item}")
            ),
        )
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ProfilingError(f"strict JSON read failed: {path.name}") from exc
    if not isinstance(value, dict):
        raise ProfilingError(f"JSON object required: {path.name}")
    return value


def _credential_path(project_root: Path) -> Path:
    return project_root.parent / "env-api.md"


def validate_binding(project_root: Path) -> dict[str, object]:
    """Validate all non-secret bindings before the first network request."""

    credentials = load_provider_credentials(_credential_path(project_root), profile="primary")
    parsed = urlparse(credentials.base_url)
    if credentials.base_url != ENDPOINT or parsed.scheme != "https" or parsed.hostname != ENDPOINT_HOST:
        raise ProfilingError("provider endpoint is not the authorized relay.nf.video HTTPS endpoint")
    config_path = project_root / CONFIG_LOCATOR
    config = _strict_json(config_path)
    if config.get("model_identifier") != MODEL_IDENTIFIER or config.get("model_revision") != MODEL_REVISION:
        raise ProfilingError("provider model/revision binding mismatch")
    if config.get("timeout_ms") != 30_000 or config.get("retry_budget") != 0:
        raise ProfilingError("provider timeout/retry binding mismatch")
    if config.get("max_input_tokens") != INPUT_TOKEN_CAP or config.get("max_output_tokens") != OUTPUT_TOKEN_CAP:
        raise ProfilingError("provider token-cap binding mismatch")
    method_config = _strict_json(project_root / METHOD_CONFIG_LOCATOR)
    prompt_hashes = {}
    for task, locator in PROMPT_LOCATORS.items():
        prompt_path = project_root / locator
        prompt = _strict_json(prompt_path)
        if not isinstance(prompt.get("system_prompt"), str) or not isinstance(
            prompt.get("user_prompt_template"), dict
        ):
            raise ProfilingError(f"frozen prompt binding invalid: {task}")
        prompt_hashes[task] = file_sha(prompt_path)
    return {
        "provider": "openai",
        "endpoint": ENDPOINT,
        "endpoint_host": ENDPOINT_HOST,
        "model_identifier": MODEL_IDENTIFIER,
        "model_revision": MODEL_REVISION,
        "provider_config_sha256": file_sha(config_path),
        "method_config_sha256": file_sha(project_root / METHOD_CONFIG_LOCATOR),
        "prompt_protocol_sha256": prompt_hashes,
        "credential_file_read": True,
        "api_key_recorded": False,
        "api_key_persisted": False,
        "method_config_methods": sorted(method_config.get("methods", {}).keys()),
    }


def _no_redirect(_request: Request, _fp: object, _code: int, _msg: str, _headers: object) -> None:
    raise ProfilingError("redirect is forbidden by the C14.2 host gate")


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers):  # type: ignore[no-untyped-def]
        raise ProfilingError("redirect is forbidden by the C14.2 host gate")


def _opener():
    return build_opener(ProxyHandler({}), _NoRedirect(), HTTPSHandler())


def _task_prompt(project_root: Path, task: str) -> dict:
    return _strict_json(project_root / PROMPT_LOCATORS[task])


def _full_payload(index: int) -> dict:
    return {
        "schema_version": "exp09-c14-1-full-supervisor-input-v2",
        "causal_cutoff_us": 10_000_000 + index * 100_000,
        "based_on_sequence": index + 1,
        "program_state": {
            "schema_version": "exp09-program-state-v1",
            "state_hash": hashlib.sha256(f"profile-state-{index}".encode()).hexdigest().upper(),
            "current_program_id": "balanced",
            "current_started_us": 0,
            "last_transition_us": 0,
            "remaining_budget_units": 1,
        },
        "eligible_proposals": [
            {"transition_id": "HOLD", "target_program_id": "balanced"},
            {"transition_id": "SWITCH", "target_program_id": "protect-freshness"},
        ],
        "evidence": {
            "schema_version": "exp09-evidence-bundle-v1",
            "evidence_id": f"profiling-evidence-{index:04d}",
            "causal_cutoff_us": 10_000_000 + index * 100_000,
            "detector_active": True,
            "risk_ppm": 250_000 + (index % 10) * 1_000,
            "memory_interval_low_ppm": 100_000,
            "memory_interval_high_ppm": 400_000,
        },
        "evidence_hash": hashlib.sha256(f"profile-evidence-hash-{index}".encode()).hexdigest().upper(),
        "remaining_budget": {"program_transition_units": 1, "provider_request_units": 1},
    }


def _plain_payload(index: int) -> dict:
    return {
        "schema_version": "exp09-c14-1-plain-llm-input-v1",
        "instruction": "Rank all eligible_actions from most to least appropriate for observable freshness and collision-risk control; chosen_action_id must equal candidate_order[0].",
        "observation": {
            "causal_cutoff_us": 20_000_000 + index * 100_000,
            "counters": [{"kind": "collision_events", "value": index % 3}],
            "current_rri_us": 100_000,
            "missing_reasons": [],
            "observed_user_ages": [[0, 100_000 + index], [1, 200_000 + index]],
            "observed_users": [],
            "removals": [],
            "source_sequence": index + 1,
        },
        "eligible_actions": [
            "RETAIN_AT_EXPIRY__100000",
            "RESELECT__20000",
            "RESELECT__50000",
            "RESELECT__100000",
        ],
    }


def build_request(project_root: Path, task: str, index: int) -> tuple[dict, dict]:
    prompt = _task_prompt(project_root, task)
    payload = _full_payload(index) if task == "ProgramProposal" else _plain_payload(index)
    schema = {
        "type": "object",
        "additionalProperties": False,
        "required": ["transition_id", "target_program_id", "rationale_code"]
        if task == "ProgramProposal"
        else ["schema_version", "candidate_order", "chosen_action_id", "confidence_ppm", "rationale_code"],
        "properties": {},
    }
    if task == "ProgramProposal":
        schema["properties"] = {
            "transition_id": {"type": "string", "enum": ["HOLD", "SWITCH", "RETURN_BALANCED"]},
            "target_program_id": {"anyOf": [{"type": "string"}, {"type": "null"}]},
            "rationale_code": {"type": "string", "enum": ["NO_CHANGE", "EVIDENCE_SUPPORTED_TRANSITION", "HOLD_UNCERTAIN_EVIDENCE", "RETURN_TO_BALANCED"]},
        }
    else:
        actions = payload["eligible_actions"]
        schema["properties"] = {
            "schema_version": {"type": "string", "const": "exp09-c14-1-plain-llm-output-v1"},
            "candidate_order": {"type": "array", "items": {"type": "string", "enum": actions}, "minItems": len(actions), "maxItems": len(actions)},
            "chosen_action_id": {"type": "string", "enum": actions},
            "confidence_ppm": {"type": "integer", "minimum": 0, "maximum": 1_000_000},
            "rationale_code": {"type": "string", "enum": ["FRESHNESS_PRIORITY", "COLLISION_RISK_PRIORITY", "BALANCED_OBSERVABLE_TRADEOFF", "INSUFFICIENT_OBSERVABLE_EVIDENCE"]},
        }
    body = {
        "model": MODEL_IDENTIFIER,
        "messages": [
            {"role": "system", "content": prompt["system_prompt"]},
            {"role": "user", "content": json.dumps({"instruction": prompt["user_prompt_template"]["instruction"], "input": payload}, ensure_ascii=False, sort_keys=True, separators=(",", ":"))},
        ],
        "temperature": 0,
        "reasoning_effort": "none",
        "max_tokens": OUTPUT_TOKEN_CAP,
        "response_format": {"type": "json_schema", "json_schema": {"name": "exp09_c14_2_profile", "strict": True, "schema": schema}},
    }
    return body, payload


def _validate_response(task: str, payload: dict, response: dict) -> None:
    if task == "ProgramProposal":
        if set(response) != {"transition_id", "target_program_id", "rationale_code"}:
            raise ProfilingError("ProgramProposal response schema drift")
        selected = (response["transition_id"], response["target_program_id"])
        eligible = {(item["transition_id"], item["target_program_id"]) for item in payload["eligible_proposals"]}
        if selected not in eligible:
            raise ProfilingError("ProgramProposal response is outside eligible set")
        return
    if set(response) != {"schema_version", "candidate_order", "chosen_action_id", "confidence_ppm", "rationale_code"}:
        raise ProfilingError("Plain_LLM response schema drift")
    order = response["candidate_order"]
    actions = payload["eligible_actions"]
    if response["schema_version"] != "exp09-c14-1-plain-llm-output-v1" or order != list(dict.fromkeys(order)) or set(order) != set(actions) or response["chosen_action_id"] != order[0] or type(response["confidence_ppm"]) is not int or not 0 <= response["confidence_ppm"] <= 1_000_000:
        raise ProfilingError("Plain_LLM response audit failed")


def call_provider(credentials, body: dict, task: str, payload: dict) -> CallResult:
    request_bytes = canonical_bytes(body)
    request = Request(
        f"{ENDPOINT}/chat/completions",
        data=request_bytes,
        headers={"Authorization": f"Bearer {credentials.api_key}", "Content-Type": "application/json", "Accept": "application/json", "User-Agent": "exp09-c14-2-provider-profile/1.0"},
        method="POST",
    )
    started = time.monotonic()
    try:
        with _opener().open(request, timeout=TIMEOUT_SECONDS) as response:
            if urlparse(response.geturl()).hostname != ENDPOINT_HOST:
                raise ProfilingError("response host violated C14.2 host gate")
            raw_bytes = response.read()
            http_status = int(response.status)
    except HTTPError as exc:
        body_bytes = exc.read()
        return CallResult("FAILED_RETAINED", max(0, round((time.monotonic() - started) * 1000)), hashlib.sha256(body_bytes).hexdigest().upper(), None, None, 0, 0, 0, "HTTP_ERROR", type(exc).__name__, exc.code)
    except (TimeoutError, socket.timeout, RemoteDisconnected) as exc:
        raise UnknownResponseError(type(exc).__name__) from exc
    except (URLError, OSError) as exc:
        raise ProfilingError(type(exc).__name__) from exc
    wall_ms = max(0, round((time.monotonic() - started) * 1000))
    response_hash = hashlib.sha256(raw_bytes).hexdigest().upper()
    try:
        raw = json.loads(raw_bytes.decode("utf-8"))
        choice = raw["choices"][0]
        content = choice["message"]["content"]
        parsed = json.loads(content)
        usage = raw["usage"]
        input_tokens = int(usage["prompt_tokens"])
        output_tokens = int(usage["completion_tokens"])
        total_tokens = int(usage["total_tokens"])
        if choice.get("finish_reason") != "stop" or total_tokens != input_tokens + output_tokens or input_tokens < 0 or output_tokens < 0 or input_tokens > INPUT_TOKEN_CAP or output_tokens > OUTPUT_TOKEN_CAP:
            raise ProfilingError("provider response usage/finish audit failed")
        if not isinstance(parsed, dict):
            raise ProfilingError("provider response is not a JSON object")
        _validate_response(task, payload, parsed)
    except (KeyError, TypeError, ValueError, UnicodeError, json.JSONDecodeError) as exc:
        raise ProfilingError("provider response envelope/schema is invalid") from exc
    return CallResult("COMPLETED_AUDITED", wall_ms, response_hash, canonical_sha(parsed), raw.get("model"), input_tokens, output_tokens, total_tokens, None, None, http_status)


def append_event(path: Path, event: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(event, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
        stream.flush()


def run(project_root: Path, output_root: Path) -> dict:
    binding = validate_binding(project_root)
    output_root.mkdir(parents=True, exist_ok=False)
    (output_root / "profiling_manifest.json").write_text(json.dumps({"schema_version": "exp09-c14-2-provider-profile-manifest-v1", "artifact_status": "AUTHORIZED_EXECUTION_STARTED", "protocol_generation": PROTOCOL_GENERATION, "binding": binding, "tasks": list(TASKS), "attempts_per_task": ATTEMPTS_PER_TASK, "api_attempt_cap": API_ATTEMPT_CAP, "cost_cap_usd": COST_CAP_USD, "concurrency": 1, "timeout_ms": TIMEOUT_SECONDS * 1000, "retry": RETRY_BUDGET, "network_fallback": False, "api_key_recorded": False}, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    ledger_path = output_root / "provider_profile_events.ndjson"
    credentials = load_provider_credentials(_credential_path(project_root), profile="primary")
    summary = {task: {"attempts": 0, "completed": 0, "failed": 0, "latencies_ms": [], "successful_latencies_ms": [], "input_tokens": 0, "output_tokens": 0, "total_tokens": 0, "estimated_cost_usd": 0.0} for task in TASKS}
    total_attempts = 0
    total_cost = 0.0
    try:
        for task in TASKS:
            for index in range(ATTEMPTS_PER_TASK):
                if total_attempts >= API_ATTEMPT_CAP or total_cost >= COST_CAP_USD:
                    raise ProfilingError("C14.2 hard budget cap reached")
                body, payload = build_request(project_root, task, index)
                request_hash = hashlib.sha256(canonical_bytes(body)).hexdigest().upper()
                call_id = f"c14-2-{total_attempts:04d}"
                append_event(ledger_path, {"event": "STARTED", "call_id": call_id, "task": task, "attempt_index": index, "request_hash": request_hash, "started_at": timestamp(), "api_key_recorded": False})
                try:
                    result = call_provider(credentials, body, task, payload)
                except UnknownResponseError as exc:
                    append_event(ledger_path, {"event": "TERMINAL", "call_id": call_id, "task": task, "attempt_index": index, "request_hash": request_hash, "status": "FAILED_RETAINED", "error_category": "RESPONSE_UNKNOWN", "error_code": type(exc).__name__, "api_key_recorded": False, "completed_at": timestamp()})
                    raise
                except ProfilingError as exc:
                    append_event(ledger_path, {"event": "TERMINAL", "call_id": call_id, "task": task, "attempt_index": index, "request_hash": request_hash, "status": "FAILED_RETAINED", "error_category": "SCHEMA_OR_PROTOCOL", "error_code": type(exc).__name__, "api_key_recorded": False, "completed_at": timestamp()})
                    raise
                row = {"event": "TERMINAL", "call_id": call_id, "task": task, "attempt_index": index, "request_hash": request_hash, "status": result.status, "response_body_sha256": result.response_body_sha256, "parsed_response_sha256": result.parsed_response_sha256, "model_returned": result.model_returned, "wall_ms": result.wall_ms, "input_tokens": result.input_tokens, "output_tokens": result.output_tokens, "total_tokens": result.total_tokens, "estimated_cost_usd": estimate_cost(result.input_tokens, result.output_tokens), "error_category": result.error_category, "error_code": result.error_code, "http_status": result.http_status, "api_key_recorded": False, "completed_at": timestamp()}
                append_event(ledger_path, row)
                total_attempts += 1
                task_summary = summary[task]
                task_summary["attempts"] += 1
                task_summary["latencies_ms"].append(result.wall_ms)
                total_cost += row["estimated_cost_usd"]
                task_summary["estimated_cost_usd"] += row["estimated_cost_usd"]
                if result.status == "COMPLETED_AUDITED":
                    task_summary["completed"] += 1
                    task_summary["successful_latencies_ms"].append(result.wall_ms)
                    task_summary["input_tokens"] += result.input_tokens
                    task_summary["output_tokens"] += result.output_tokens
                    task_summary["total_tokens"] += result.total_tokens
                else:
                    task_summary["failed"] += 1
    except BaseException as exc:
        status = {"schema_version": "exp09-c14-2-provider-profile-summary-v1", "artifact_status": "C14_2_FAIL_CLOSED", "passed": False, "protocol_generation": PROTOCOL_GENERATION, "failure": type(exc).__name__, "failure_message": str(exc), "api_attempts_started": total_attempts + 1 if total_attempts < API_ATTEMPT_CAP else total_attempts, "api_attempts_terminal": total_attempts, "estimated_cost_usd": round(total_cost, 9), "api_key_recorded": False, "later_stages": False}
        (output_root / "profiling_summary.json").write_text(json.dumps(status, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        raise
    for task, item in summary.items():
        item["p95_latency_ms_all_attempts"] = percentile(item.pop("latencies_ms"), 0.95)
        item["p95_latency_ms_successful"] = percentile(item.pop("successful_latencies_ms"), 0.95)
    result = {"schema_version": "exp09-c14-2-provider-profile-summary-v1", "artifact_status": "C14_2_COMPLETE_STOP_BEFORE_LATER_STAGES", "passed": True, "protocol_generation": PROTOCOL_GENERATION, "tasks": summary, "api_attempts": total_attempts, "api_attempt_hard_cap": API_ATTEMPT_CAP, "estimated_cost_usd": round(total_cost, 9), "cost_cap_usd": COST_CAP_USD, "api_key_recorded": False, "network_fallback": False, "later_stages": False}
    result["ledger_sha256"] = file_sha(ledger_path)
    (output_root / "profiling_summary.json").write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return result
