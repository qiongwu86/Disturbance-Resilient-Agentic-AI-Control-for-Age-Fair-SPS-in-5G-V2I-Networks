"""Exact C06 freshness, access, fairness, and reliability accumulators."""

from collections.abc import Iterable
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP, localcontext
from fractions import Fraction
import math

from exp09.contracts.observable import (
    ReceiverIdentityEvent,
    ReceiverObservableKind,
    ReceiverPacketObservation,
)
from exp09.contracts.tape import DisturbanceTape
from exp09.plant.state import PlantTrace, TerminalOutcome, TruthEventKind

ACCESS_DELAY_SCHEMA_VERSION = "exp09-access-delay-record-v1"
ACCESS_SURVIVAL_SCHEMA_VERSION = "exp09-access-survival-point-v1"
PER_USER_METRIC_SCHEMA_VERSION = "exp09-per-user-metric-v1"
CASE_METRICS_SCHEMA_VERSION = "exp09-case-metrics-v5"


@dataclass(frozen=True, slots=True)
class AccessDelayRecord:
    schema_version: str
    vehicle_id: str
    duration_us: int
    event_observed: bool

    def __post_init__(self) -> None:
        if self.schema_version != ACCESS_DELAY_SCHEMA_VERSION:
            raise ValueError("unsupported access-delay schema")


@dataclass(frozen=True, slots=True)
class AccessSurvivalPoint:
    schema_version: str
    duration_us: int
    at_risk: int
    event_count: int
    censor_count: int
    survival_numerator: int
    survival_denominator: int

    def __post_init__(self) -> None:
        if self.schema_version != ACCESS_SURVIVAL_SCHEMA_VERSION:
            raise ValueError("unsupported access-survival schema")


@dataclass(frozen=True, slots=True)
class PerUserMetric:
    schema_version: str
    vehicle_id: str
    eligible_duration_us: int
    twice_aoi_area_us2: int
    success_count: int
    paoi_event_count: int
    mean_paoi_us: str
    observed_ever: bool

    def __post_init__(self) -> None:
        if self.schema_version != PER_USER_METRIC_SCHEMA_VERSION:
            raise ValueError("unsupported per-user-metric schema")


@dataclass(frozen=True, slots=True)
class CaseMetrics:
    schema_version: str
    mean_aoi_ms: str
    q95_aoi_ms: str
    pooled_occupation_q95_ms: str
    worst_user_time_average_aoi_ms: str
    age_cv: str
    age_max_min_gap_ms: str
    jain_freshness: str
    jain_loss: str
    event_paoi_ms: str
    collision_event_rate: str
    decode_failure_rate: str
    zero_success_fraction: str
    never_observed_fraction: str
    zero_tx_indicator: int
    event_paoi_user_denominator: int
    event_paoi_event_count: int
    access_event_count: int
    access_risk_set_count: int
    access_rmst_ms: str
    access_survival: tuple[AccessSurvivalPoint, ...]
    reselection_count: int
    reselection_rate_per_vehicle_second: str
    containment_onset_analysis_tau_us: int | None
    containment_mean_aoi_ms: str
    containment_q95_aoi_ms: str
    containment_collision_event_rate: str
    adaptation_entrant_access_event_fraction: str
    adaptation_entrant_access_rmst_ms: str
    tx_attempts: int
    success_count: int
    collision_count: int
    per_user: tuple[PerUserMetric, ...]
    access_delay: tuple[AccessDelayRecord, ...]

    def __post_init__(self) -> None:
        if self.schema_version != CASE_METRICS_SCHEMA_VERSION:
            raise ValueError("unsupported case-metrics schema")


ObservableIdentityHistory = Iterable[ReceiverPacketObservation | ReceiverIdentityEvent]


def compute_case_metrics(
    tape: DisturbanceTape,
    trace: PlantTrace,
    *,
    observable_history: ObservableIdentityHistory | None = None,
) -> CaseMetrics:
    """Compute one case without treating online visibility as offline eligibility.

    When an explicit receiver history is supplied, it is the sole identity-visibility
    source. The compatibility path uses successful terminal receiver outcomes, which
    are themselves receiver-observable events, but cannot represent authenticated
    zero-success handovers.
    """

    start = int(tape.analysis_origin_simulation_time_us)
    end = int(tape.simulation_end_us)
    if end <= start:
        raise ValueError("analysis window must be non-empty")
    vehicles = {str(vehicle.vehicle_id): vehicle for vehicle in tape.vehicles}
    all_attempts = tuple(
        sorted(
            trace.tx_attempts,
            key=lambda item: (item.time_us, item.vehicle_id, item.attempt_id),
        )
    )
    _validate_trace(vehicles, all_attempts, trace.truth_events)
    attempts = tuple(
        record for record in all_attempts if start <= record.time_us < end
    )
    successes_by_time: dict[int, list] = {}
    for record in attempts:
        if record.success:
            successes_by_time.setdefault(record.time_us, []).append(record)

    last_success = {}
    for vehicle_id, vehicle in vehicles.items():
        burn_in_successes = tuple(
            record.packet_generation_us
            for record in all_attempts
            if record.vehicle_id == vehicle_id
            and record.success
            and record.time_us < start
        )
        last_success[vehicle_id] = max(
            (int(vehicle.last_success_generation_us_at_entry),)
            + burn_in_successes
        )
    per_user_twice_area = {vehicle_id: 0 for vehicle_id in vehicles}
    per_user_duration = {vehicle_id: 0 for vehicle_id in vehicles}
    per_user_success_count = {vehicle_id: 0 for vehicle_id in vehicles}
    per_user_paoi: dict[str, list[int]] = {vehicle_id: [] for vehicle_id in vehicles}
    first_success: dict[str, int] = {}
    boundaries = sorted(
        {start, end}
        | {
            max(start, int(vehicle.arrival_simulation_time_us))
            for vehicle in vehicles.values()
            if int(vehicle.arrival_simulation_time_us) < end
        }
        | {
            min(end, int(vehicle.departure_simulation_time_us))
            for vehicle in vehicles.values()
            if int(vehicle.departure_simulation_time_us) > start
        }
        | set(successes_by_time)
    )
    total_mean_twice_area = Fraction(0, 1)
    total_q95_twice_area = 0
    occupation_segments: list[tuple[int, int]] = []
    onset_simulation_time_us = int(tape.paired_anchor_simulation_time_us)
    containment_mean_twice_area = Fraction(0, 1)
    containment_q95_twice_area = 0

    for index, left in enumerate(boundaries[:-1]):
        for record in successes_by_time.get(left, ()):
            vehicle_id = record.vehicle_id
            per_user_paoi[vehicle_id].append(left - last_success[vehicle_id])
            last_success[vehicle_id] = record.packet_generation_us
            per_user_success_count[vehicle_id] += 1
            first_success.setdefault(vehicle_id, left)
        right = boundaries[index + 1]
        if right <= left:
            continue
        eligible = _eligible_vehicle_ids(tape, left)
        if not eligible:
            raise ValueError("eligible set must not be empty")
        duration = right - left
        ages = [left - last_success[vehicle_id] for vehicle_id in eligible]
        if any(age < 0 for age in ages):
            raise ValueError("AoI cannot be negative")
        interval_mean_twice = Fraction(
            sum(2 * age * duration + duration * duration for age in ages),
            len(ages),
        )
        total_mean_twice_area += interval_mean_twice
        q95_start = sorted(ages)[math.ceil(95 * len(ages) / 100) - 1]
        total_q95_twice_area += 2 * q95_start * duration + duration * duration
        occupation_segments.extend((age, duration) for age in ages)
        for vehicle_id in eligible:
            start_age = left - last_success[vehicle_id]
            per_user_twice_area[vehicle_id] += (
                2 * start_age * duration + duration * duration
            )
            per_user_duration[vehicle_id] += duration

        if right > onset_simulation_time_us:
            contained_left = max(left, onset_simulation_time_us)
            contained_duration = right - contained_left
            contained_ages = [
                contained_left - last_success[vehicle_id] for vehicle_id in eligible
            ]
            containment_mean_twice_area += Fraction(
                sum(
                    2 * age * contained_duration
                    + contained_duration * contained_duration
                    for age in contained_ages
                ),
                len(contained_ages),
            )
            contained_q95 = sorted(contained_ages)[
                math.ceil(95 * len(contained_ages) / 100) - 1
            ]
            containment_q95_twice_area += (
                2 * contained_q95 * contained_duration
                + contained_duration * contained_duration
            )

    collisions = tuple(
        record for record in attempts if record.outcome is TerminalOutcome.COLLISION
    )
    successes = tuple(record for record in attempts if record.success)
    eligible_all = tuple(
        vehicle_id for vehicle_id in vehicles if per_user_duration[vehicle_id] > 0
    )
    if not eligible_all:
        raise ValueError("complete eligible population must not be empty")
    zero_success = tuple(
        vehicle_id for vehicle_id in eligible_all if per_user_success_count[vehicle_id] == 0
    )
    observed_ids = _observed_vehicle_ids(
        observable_history, successes, vehicles, start=start, end=end
    )
    never_observed = tuple(
        vehicle_id for vehicle_id in eligible_all if vehicle_id not in observed_ids
    )
    user_averages_us = [
        Fraction(per_user_twice_area[vehicle_id], 2 * per_user_duration[vehicle_id])
        for vehicle_id in eligible_all
    ]
    freshness = [Fraction(1_000, 1_000 + value) for value in user_averages_us]
    jain = sum(freshness) ** 2 / (
        len(freshness) * sum(value * value for value in freshness)
    )
    user_mean_paoi = [
        Fraction(sum(values), len(values))
        for values in per_user_paoi.values()
        if values
    ]
    access_delay = tuple(
        _access_record(
            vehicle_id,
            vehicles[vehicle_id],
            first_success.get(vehicle_id),
            start,
            end,
        )
        for vehicle_id in eligible_all
    )
    window = end - start
    access_survival, access_rmst = _kaplan_meier_rmst(access_delay, window)
    per_user = tuple(
        PerUserMetric(
            schema_version=PER_USER_METRIC_SCHEMA_VERSION,
            vehicle_id=vehicle_id,
            eligible_duration_us=per_user_duration[vehicle_id],
            twice_aoi_area_us2=per_user_twice_area[vehicle_id],
            success_count=per_user_success_count[vehicle_id],
            paoi_event_count=len(per_user_paoi[vehicle_id]),
            mean_paoi_us=(
                _decimal(
                    Fraction(
                        sum(per_user_paoi[vehicle_id]),
                        len(per_user_paoi[vehicle_id]),
                    )
                )
                if per_user_paoi[vehicle_id]
                else "MISSING_NO_SUCCESS"
            ),
            observed_ever=vehicle_id in observed_ids,
        )
        for vehicle_id in sorted(eligible_all)
    )
    mean_aoi_us = total_mean_twice_area / (2 * window)
    q95_aoi_us = Fraction(total_q95_twice_area, 2 * window)
    age_mean = sum(user_averages_us, Fraction()) / len(user_averages_us)
    age_variance = sum(
        (value - age_mean) ** 2 for value in user_averages_us
    ) / len(user_averages_us)
    age_cv = (
        _sqrt_decimal(age_variance / (age_mean**2))
        if age_mean
        else "MISSING_ZERO_MEAN_AGE"
    )
    reselections = tuple(
        record
        for record in trace.truth_events
        if start <= record.time_us < end
        and record.kind is TruthEventKind.RESERVATION_RESELECT
        and record.vehicle_id == str(tape.controlled_vehicle_id)
    )
    controlled_vehicle_time_us = per_user_duration.get(
        str(tape.controlled_vehicle_id), 0
    )
    if controlled_vehicle_time_us <= 0:
        raise ValueError("controlled vehicle must have positive eligible duration")
    containment_attempts = tuple(
        record for record in attempts if record.time_us > onset_simulation_time_us
    )
    containment_collisions = tuple(
        record
        for record in containment_attempts
        if record.outcome is TerminalOutcome.COLLISION
    )
    entrants = tuple(
        vehicle_id
        for vehicle_id in eligible_all
        if int(vehicles[vehicle_id].arrival_simulation_time_us) > start
    )
    entrant_access = tuple(
        item for item in access_delay if item.vehicle_id in set(entrants)
    )
    if entrant_access:
        _, entrant_rmst = _kaplan_meier_rmst(
            entrant_access, end - onset_simulation_time_us
        )
        entrant_fraction = _decimal(
            Fraction(sum(item.event_observed for item in entrant_access), len(entrant_access))
        )
        entrant_rmst_text = _decimal_ms(entrant_rmst)
    else:
        entrant_fraction = "NOT_APPLICABLE_NO_ENTRANTS"
        entrant_rmst_text = "NOT_APPLICABLE_NO_ENTRANTS"
    containment_duration = end - onset_simulation_time_us
    containment_mean = _decimal_ms(
        containment_mean_twice_area / (2 * containment_duration)
    )
    containment_q95 = _decimal_ms(
        Fraction(containment_q95_twice_area, 2 * containment_duration)
    )
    containment_collision_rate = (
        _decimal(Fraction(len(containment_collisions), len(containment_attempts)))
        if containment_attempts
        else "MISSING_ZERO_TX"
    )
    return CaseMetrics(
        schema_version=CASE_METRICS_SCHEMA_VERSION,
        mean_aoi_ms=_decimal_ms(mean_aoi_us),
        q95_aoi_ms=_decimal_ms(q95_aoi_us),
        pooled_occupation_q95_ms=_decimal_ms(
            _pooled_occupation_quantile(occupation_segments, 95, 100)
        ),
        worst_user_time_average_aoi_ms=_decimal_ms(max(user_averages_us)),
        age_cv=age_cv,
        age_max_min_gap_ms=_decimal_ms(
            max(user_averages_us) - min(user_averages_us)
        ),
        jain_freshness=_decimal(jain),
        jain_loss=_decimal(1 - jain),
        event_paoi_ms=(
            _decimal_ms(sum(user_mean_paoi, Fraction()) / len(user_mean_paoi))
            if user_mean_paoi
            else "MISSING_NO_SUCCESS"
        ),
        collision_event_rate=(
            _decimal(Fraction(len(collisions), len(attempts)))
            if attempts
            else "MISSING_ZERO_TX"
        ),
        decode_failure_rate=(
            _decimal(Fraction(len(attempts) - len(successes), len(attempts)))
            if attempts
            else "MISSING_ZERO_DECODE_TRIAL"
        ),
        zero_success_fraction=_decimal(Fraction(len(zero_success), len(eligible_all))),
        never_observed_fraction=_decimal(
            Fraction(len(never_observed), len(eligible_all))
        ),
        zero_tx_indicator=int(not attempts),
        event_paoi_user_denominator=len(user_mean_paoi),
        event_paoi_event_count=sum(len(values) for values in per_user_paoi.values()),
        access_event_count=sum(item.event_observed for item in access_delay),
        access_risk_set_count=len(access_delay),
        access_rmst_ms=_decimal_ms(access_rmst),
        access_survival=access_survival,
        reselection_count=len(reselections),
        reselection_rate_per_vehicle_second=_decimal(
            Fraction(len(reselections) * 1_000_000, controlled_vehicle_time_us)
        ),
        containment_onset_analysis_tau_us=int(tape.paired_anchor_analysis_tau_us),
        containment_mean_aoi_ms=containment_mean,
        containment_q95_aoi_ms=containment_q95,
        containment_collision_event_rate=containment_collision_rate,
        adaptation_entrant_access_event_fraction=entrant_fraction,
        adaptation_entrant_access_rmst_ms=entrant_rmst_text,
        tx_attempts=len(attempts),
        success_count=len(successes),
        collision_count=len(collisions),
        per_user=per_user,
        access_delay=access_delay,
    )


def _validate_trace(vehicles: dict[str, object], attempts: tuple, truth_events: tuple) -> None:
    seen: set[str] = set()
    for record in attempts:
        if record.attempt_id in seen:
            raise ValueError("duplicate terminal TX attempt")
        seen.add(record.attempt_id)
        if record.vehicle_id not in vehicles:
            raise ValueError("TX attempt references an unknown vehicle")
        vehicle = vehicles[record.vehicle_id]
        # Phase-10 TX is committed before a same-timestamp phase-20 departure.
        if not int(vehicle.arrival_simulation_time_us) <= record.time_us <= int(
            vehicle.departure_simulation_time_us
        ):
            raise ValueError("TX attempt occurred outside physical eligibility")
        if record.packet_generation_us > record.time_us:
            raise ValueError("TX attempt precedes packet generation")
        if record.success != (record.outcome is TerminalOutcome.RX_SUCCESS):
            raise ValueError("success flag conflicts with terminal outcome")
        if record.collided != (record.outcome is TerminalOutcome.COLLISION):
            raise ValueError("collision flag conflicts with terminal outcome")

    truth_ids: set[str] = set()
    last_reservation_version: dict[str, int] = {}
    for record in truth_events:
        if record.event_id in truth_ids:
            raise ValueError("duplicate truth event")
        truth_ids.add(record.event_id)
        if record.vehicle_id not in vehicles:
            raise ValueError("truth event references an unknown vehicle")
        vehicle = vehicles[record.vehicle_id]
        arrival = int(vehicle.arrival_simulation_time_us)
        departure = int(vehicle.departure_simulation_time_us)
        if record.kind is TruthEventKind.VEHICLE_ARRIVAL:
            if record.time_us != arrival:
                raise ValueError("vehicle-arrival truth event must occur at physical arrival")
        elif record.kind is TruthEventKind.VEHICLE_DEPARTURE:
            if record.time_us != departure:
                raise ValueError("vehicle-departure truth event must occur at physical departure")
        elif not arrival <= record.time_us < departure:
            raise ValueError("truth event occurred outside physical presence")
        version = record.reservation_version
        if isinstance(version, bool) or not isinstance(version, int) or version < 0:
            raise ValueError("truth reservation version must be a non-negative integer")
        previous = last_reservation_version.get(record.vehicle_id)
        if previous is not None and version < previous:
            raise ValueError("truth reservation version regressed for one vehicle")
        last_reservation_version[record.vehicle_id] = version


def _observed_vehicle_ids(
    history: ObservableIdentityHistory | None,
    successes: tuple,
    vehicles: dict[str, object],
    *,
    start: int,
    end: int,
) -> frozenset[str]:
    if history is None:
        return frozenset(record.vehicle_id for record in successes)
    observed: set[str] = set()
    for event in history:
        if not isinstance(event, (ReceiverPacketObservation, ReceiverIdentityEvent)):
            raise ValueError("observable history contains a non-identity observation")
        observed_at = int(event.observed_at_us)
        if observed_at >= end:
            continue
        vehicle_id = str(event.vehicle_id)
        if vehicle_id not in vehicles:
            raise ValueError("observable history references an unknown vehicle")
        if isinstance(event, ReceiverPacketObservation) or (
            event.kind is ReceiverObservableKind.AUTHENTICATED_HANDOVER
        ):
            observed.add(vehicle_id)
    return frozenset(observed)


def _access_record(
    vehicle_id: str,
    vehicle,
    success_time: int | None,
    start: int,
    end: int,
) -> AccessDelayRecord:
    entry = max(start, int(vehicle.arrival_simulation_time_us))
    censor = min(end, int(vehicle.departure_simulation_time_us))
    if censor <= entry:
        raise ValueError("access risk interval must have positive duration")
    if success_time is not None:
        if not entry <= success_time < censor:
            raise ValueError("access success must occur inside the risk interval")
        return AccessDelayRecord(
            ACCESS_DELAY_SCHEMA_VERSION, vehicle_id, success_time - entry, True
        )
    return AccessDelayRecord(
        ACCESS_DELAY_SCHEMA_VERSION, vehicle_id, censor - entry, False
    )


def _kaplan_meier_rmst(
    records: tuple[AccessDelayRecord, ...], horizon_us: int
) -> tuple[tuple[AccessSurvivalPoint, ...], Fraction]:
    if not records:
        raise ValueError("survival risk set must not be empty")
    if horizon_us <= 0:
        raise ValueError("RMST horizon must be positive")
    if any(item.duration_us < 0 or item.duration_us > horizon_us for item in records):
        raise ValueError("access duration must lie inside the RMST horizon")
    grouped: dict[int, list[AccessDelayRecord]] = {}
    for item in records:
        grouped.setdefault(item.duration_us, []).append(item)
    survival = Fraction(1, 1)
    rmst = Fraction(0, 1)
    at_risk = len(records)
    previous = 0
    points: list[AccessSurvivalPoint] = []
    for duration in sorted(grouped):
        rmst += survival * (duration - previous)
        items = grouped[duration]
        event_count = sum(item.event_observed for item in items)
        censor_count = len(items) - event_count
        before = at_risk
        if event_count:
            survival *= Fraction(before - event_count, before)
        points.append(
            AccessSurvivalPoint(
                schema_version=ACCESS_SURVIVAL_SCHEMA_VERSION,
                duration_us=duration,
                at_risk=before,
                event_count=event_count,
                censor_count=censor_count,
                survival_numerator=survival.numerator,
                survival_denominator=survival.denominator,
            )
        )
        at_risk -= len(items)
        previous = duration
    rmst += survival * (horizon_us - previous)
    return tuple(points), rmst


def _pooled_occupation_quantile(
    segments: list[tuple[int, int]], numerator: int, denominator: int
) -> Fraction:
    if not segments or not 0 < numerator < denominator:
        raise ValueError("pooled occupation quantile inputs are invalid")
    if any(age < 0 or duration <= 0 for age, duration in segments):
        raise ValueError("occupation segments require non-negative age and positive duration")

    endpoint_delta: dict[int, int] = {}
    total_duration = 0
    for age, duration in segments:
        endpoint_delta[age] = endpoint_delta.get(age, 0) + 1
        endpoint = age + duration
        endpoint_delta[endpoint] = endpoint_delta.get(endpoint, 0) - 1
        total_duration += duration

    target = Fraction(total_duration * numerator, denominator)
    cumulative = Fraction()
    density = 0
    previous: int | None = None
    quantile: Fraction | None = None

    for endpoint in sorted(endpoint_delta):
        if previous is not None:
            interval_mass = Fraction(density * (endpoint - previous))
            if quantile is None:
                if target <= cumulative:
                    quantile = Fraction(previous)
                elif density > 0 and target <= cumulative + interval_mass:
                    quantile = Fraction(previous) + (target - cumulative) / density
            cumulative += interval_mass
        density += endpoint_delta[endpoint]
        if density < 0:
            raise ValueError("occupation endpoint sweep produced negative density")
        previous = endpoint

    if density != 0 or cumulative != total_duration:
        raise ValueError("occupation endpoint sweep violates mass conservation")
    if quantile is None:
        raise ValueError("occupation quantile target was not reached")
    return quantile


def _eligible_vehicle_ids(tape: DisturbanceTape, time_us: int) -> tuple[str, ...]:
    return tuple(
        str(vehicle.vehicle_id)
        for vehicle in tape.vehicles
        if int(vehicle.arrival_simulation_time_us) <= time_us < int(vehicle.departure_simulation_time_us)
    )


def _decimal_ms(value_us: Fraction) -> str:
    return _decimal(value_us / 1_000)


def _decimal(value: Fraction | int) -> str:
    fraction = Fraction(value)
    scaled = fraction * 1_000_000
    quotient, remainder = divmod(scaled.numerator, scaled.denominator)
    if remainder * 2 >= scaled.denominator:
        quotient += 1
    return f"{quotient // 1_000_000}.{quotient % 1_000_000:06d}"


def _sqrt_decimal(value: Fraction) -> str:
    if value < 0:
        raise ValueError("cannot take the square root of a negative metric")
    with localcontext() as context:
        context.prec = 50
        result = (Decimal(value.numerator) / Decimal(value.denominator)).sqrt()
        quantized = result.quantize(Decimal("0.000001"), rounding=ROUND_HALF_UP)
    return format(quantized, "f")
