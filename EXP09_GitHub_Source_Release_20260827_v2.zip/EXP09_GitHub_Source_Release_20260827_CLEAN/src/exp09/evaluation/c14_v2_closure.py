"""Authorized C14.1 v2 cache closure and offline design-validation orchestration."""

from __future__ import annotations

from contextlib import contextmanager
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
from http.client import RemoteDisconnected
import json
import os
from pathlib import Path
import re
from threading import Event, RLock
import time
from typing import Any, Iterator
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from uuid import uuid4

from exp09.contracts.supervisor import (
    PROGRAM_PROPOSAL_SCHEMA_VERSION,
    ProgramProposal,
    RationaleCode,
    TransitionId,
)
from exp09.contracts.ids import ProgramId
from exp09.contracts.tape import TapeArm
from exp09.measurement.receiver_ledger import (
    MEASUREMENT_DELAY_US,
    SUMMARY_PERIOD_US,
    ObservationAdapter,
    ReceiverMeasurementLedger,
)
from exp09.plant.plant import DiscreteEventSPSPlant
from exp09.supervisor.providers import provider_response_hash

from .c14_controllers import C14ControllerFactory
from .c14_ledger import C14BudgetCaps, C14RunLedger
from .c14_offline_cache import AuditableOfflineCache
from .c14_protocol_generation import (
    PHASE_A_CASE_COUNT,
    ProtocolGenerationRequestMaterializer,
    build_phase_a_rematerialization_plan,
    build_protocol_generation_controller,
)
from .c14_runner import (
    C14ExecutionContext,
    C14UnifiedRunner,
    recover_running_checkpoint,
)
from .c14_topology import C14MethodCase, load_frozen_topology
from .disturbance_tape import build_primary_influx_tape, validate_primary_tape
from .runner import _latest_frame_or_unavailable, _reset_context

METHODS = ("Full", "Plain_LLM")
ARMS = ("REFERENCE", "EVENT")
PROTOCOL_GENERATION = "EXP09_C14_1_OFFLINE_CACHE_V3_GPT54MINI_20260730"
PROVIDER_MODEL_IDENTIFIER = "gpt-5.4-mini"
PROVIDER_MODEL_REVISION = "gpt-5.4-mini-2026-03-17"
PROVIDER_CALL_CAP = 4_608
CACHE_REMEDIATION_CONCURRENCY = 4
FORMAL_REMEDIATION_CONCURRENCY = 8
FORMAL_ENVIRONMENT_STEPS_CAP = 5_760_000
FORMAL_MODEL_TRANSITIONS_CAP = 103_680_000_000
FULL_TAPE_MAX_CONTROL_OPPORTUNITIES_PER_CASE = 2_500
FULL_TAPE_CAUSAL_SCOPE = "FULL_FROZEN_50_SECOND_TAPE"
INPUT_TOKEN_CAP = 8_192
OUTPUT_TOKEN_CAP = 512
TIMEOUT_SECONDS = 30
ATOMIC_REPLACE_ATTEMPTS = 20
ATOMIC_REPLACE_BASE_DELAY_SECONDS = 0.025
LEGACY_OUTPUT_LOCATOR = "artifacts/c14_1_offline_cache_v2_20260730"
SOURCE_OUTPUT_LOCATOR = "artifacts/c14_1_offline_cache_v3_gpt54mini_20260730"
OUTPUT_LOCATOR = (
    "artifacts/c14_1_offline_cache_v3_gpt54mini_full_tape_20260731"
)
FORMAL_OUTPUT_LOCATOR = "artifacts/c14_1_design_validation_v3_gpt54mini_20260730"
TOPOLOGY_LOCATOR = (
    "protocol/c14/c14_1_method_case_topology.FROZEN_PREFLIGHT_20260729.json"
)
METHOD_CONFIG_LOCATOR = "protocol/c14/method_config.C14_1_OFFLINE_CACHE_V3_GPT54MINI_20260730.json"
PROVIDER_CONFIG_LOCATOR = "protocol/c14/provider_config.C14_1_OFFLINE_CACHE_V3_GPT54MINI_20260730.json"
AUTHORIZATION_LOCATOR = "protocol/c14/c14_1_v3_gpt54mini_authorization_20260730.json"

_FULL_RESPONSE_SCHEMA = {
    "name": "exp09_c14_full_response",
    "strict": True,
    "schema": {
        "type": "object",
        "additionalProperties": False,
        "required": ["transition_id", "target_program_id", "rationale_code"],
        "properties": {
            "transition_id": {
                "type": "string",
                "enum": ["HOLD", "SWITCH", "RETURN_BALANCED"],
            },
            "target_program_id": {
                "anyOf": [{"type": "string"}, {"type": "null"}],
            },
            "rationale_code": {
                "type": "string",
                "enum": [
                    "NO_CHANGE",
                    "EVIDENCE_SUPPORTED_TRANSITION",
                    "HOLD_UNCERTAIN_EVIDENCE",
                    "RETURN_TO_BALANCED",
                ],
            },
        },
    },
}

_PLAIN_RESPONSE_SCHEMA = {
    "name": "exp09_c14_plain_llm_response",
    "strict": True,
    "schema": {
        "type": "object",
        "additionalProperties": False,
        "required": [
            "schema_version",
            "candidate_order",
            "chosen_action_id",
            "confidence_ppm",
            "rationale_code",
        ],
        "properties": {
            "schema_version": {
                "type": "string",
                "const": "exp09-c14-1-plain-llm-output-v1",
            },
            "candidate_order": {
                "type": "array",
                "items": {"type": "string"},
                "minItems": 1,
                "uniqueItems": True,
            },
            "chosen_action_id": {"type": "string"},
            "confidence_ppm": {
                "type": "integer",
                "minimum": 0,
                "maximum": 1_000_000,
            },
            "rationale_code": {
                "type": "string",
                "enum": [
                    "FRESHNESS_PRIORITY",
                    "COLLISION_RISK_PRIORITY",
                    "BALANCED_OBSERVABLE_TRADEOFF",
                    "INSUFFICIENT_OBSERVABLE_EVIDENCE",
                ],
            },
        },
    },
}


class C14V2ClosureError(RuntimeError):
    """Raised whenever the authorized closure cannot continue safely."""


def _remediate_formal_budget_caps(ledger: C14RunLedger) -> None:
    """Accept only authorized retained cap generations for formal resume."""

    expected = C14BudgetCaps()
    if ledger.accountant.caps == expected:
        return
    expected_document = asdict(expected)
    retained_document = asdict(ledger.accountant.caps)
    allowed_retained_caps = (
        {**expected_document, "concurrency": 16},
        {**expected_document, "concurrency": 4},
        {
            **expected_document,
            "environment_steps": 55_296,
            "model_transitions": 995_328_000,
            "concurrency": 1,
        },
    )
    if retained_document not in allowed_retained_caps:
        raise C14V2ClosureError("formal budget cap remediation mismatch")
    ledger.accountant.caps = expected


class ProviderTransportError(C14V2ClosureError):
    """Retain non-sensitive transport diagnostics for fail-closed evidence."""

    def __init__(
        self,
        message: str,
        *,
        wall_ms: int,
        http_status: int | None = None,
        response_body_sha256: str | None = None,
        provider_error_code: str | None = None,
        response_outcome_unknown: bool = False,
    ) -> None:
        super().__init__(message)
        self.wall_ms = wall_ms
        self.http_status = http_status
        self.response_body_sha256 = response_body_sha256
        self.provider_error_code = provider_error_code
        self.response_outcome_unknown = response_outcome_unknown


class V3RequestMaterializer(ProtocolGenerationRequestMaterializer):
    """Bind V3 generation metadata without mutating the frozen V2 materializer."""

    def inventory_document(self, *, synthetic_fixture: bool) -> dict[str, Any]:
        document = super().inventory_document(synthetic_fixture=synthetic_fixture)
        document["protocol_generation"] = PROTOCOL_GENERATION
        return document

    def _envelope(
        self, model_payload: dict[str, Any], *, extra_bindings: dict[str, str]
    ) -> dict[str, Any]:
        envelope = super()._envelope(model_payload, extra_bindings=extra_bindings)
        envelope["protocol_generation"] = PROTOCOL_GENERATION
        return envelope


@dataclass(frozen=True, slots=True)
class ProviderCredentials:
    api_key: str
    base_url: str


@dataclass(frozen=True, slots=True)
class ProviderUsage:
    input_tokens: int
    output_tokens: int
    total_tokens: int


@dataclass(frozen=True, slots=True)
class ProviderResult:
    raw_response: dict[str, Any]
    parsed_response: dict[str, Any]
    finish_reason: str
    usage: ProviderUsage
    wall_ms: int


def load_provider_credentials(path: Path, *, profile: str = "primary") -> ProviderCredentials:
    """Read the local company-channel file without logging or retaining its secret."""

    try:
        text = Path(path).read_text(encoding="utf-8")
    except (OSError, UnicodeError) as exc:
        raise C14V2ClosureError("provider credential file is unavailable") from exc
    if profile == "backup":
        marker = re.search(r"(?im)^\s*备用配置\s*$", text)
        if marker is None:
            raise C14V2ClosureError("backup provider credential profile is unavailable")
        text = text[marker.end() :]
        key_match = re.search(r"(?im)^\s*API\s*Key\s*[：:]\s*([^\s]+)", text)
        url_match = re.search(r"(?im)^\s*Base\s*URL\s*[：:]\s*(https://[^\s]+)", text)
    elif profile == "primary":
        key_match = re.search(
            r"(?im)^\s*[\"']?OPENAI_API_KEY[\"']?\s*[:=]\s*[\"']?([^\"'\r\n]+)",
            text,
        )
        url_match = re.search(r"(?im)^\s*base_url\s*[:=]\s*[\"']?(https://[^\"'\s]+)", text)
    else:
        raise C14V2ClosureError("unknown provider credential profile")
    if key_match is None or url_match is None:
        raise C14V2ClosureError("provider credential fields are incomplete")
    api_key = key_match.group(1).strip()
    base_url = url_match.group(1).strip().rstrip("/")
    if not api_key or not base_url.startswith("https://"):
        raise C14V2ClosureError("provider credentials fail the non-empty HTTPS gate")
    return ProviderCredentials(api_key=api_key, base_url=base_url)


class ProviderLedger:
    """Append-preserving provider/cost ledger written before and after every call."""

    def __init__(self, path: Path, *, provider_config_sha256: str, endpoint_host: str) -> None:
        self.path = Path(path)
        self.provider_config_sha256 = provider_config_sha256
        self.endpoint_host = endpoint_host
        self.rows: list[dict[str, Any]] = []
        self._lock = RLock()
        if self.path.exists():
            document = _strict_json(self.path)
            if (
                document.get("schema_version") != "exp09-c14-1-provider-cost-ledger-v2"
                or document.get("provider_config_sha256") != provider_config_sha256
                or document.get("endpoint_host") != endpoint_host
            ):
                raise C14V2ClosureError("existing provider ledger binding mismatch")
            rows = document.get("rows")
            if not isinstance(rows, list) or document.get("rows_sha256") != _canonical_sha(rows):
                raise C14V2ClosureError("existing provider ledger integrity mismatch")
            self.rows = rows

    @property
    def completed_calls(self) -> int:
        with self._lock:
            return sum(row.get("status") == "COMPLETED_AUDITED" for row in self.rows)

    def begin(
        self,
        *,
        session_id: str,
        request_hash: str,
        method_id: str,
        arm: str,
        purpose: str = "CAUSAL_FRONTIER",
    ) -> str:
        with self._lock:
            if len(self.rows) >= PROVIDER_CALL_CAP:
                raise C14V2ClosureError("provider call hard cap reached")
            prior = [row for row in self.rows if row["request_hash"] == request_hash]
            if prior and prior[-1].get("status") != "FAILED_RETAINED":
                raise C14V2ClosureError(
                    "provider ledger request hash is not in a resumable failed state"
                )
            if purpose not in {"CAUSAL_FRONTIER", "STRUCTURED_PREFLIGHT"}:
                raise C14V2ClosureError("provider call purpose is invalid")
            call_id = f"provider-call-{len(self.rows):04d}"
            self.rows.append({
                "call_id": call_id,
                "session_id": session_id,
                "method_id": method_id,
                "arm": arm,
                "request_hash": request_hash,
                "purpose": purpose,
                "resume_of_call_id": prior[-1]["call_id"] if prior else None,
                "status": "STARTED_NO_RESPONSE",
                "started_at": _timestamp(),
                "completed_at": None,
                "input_tokens": 0,
                "output_tokens": 0,
                "total_tokens": 0,
                "wall_ms": 0,
                "estimated_cost_usd": 0,
                "error_code": None,
                "http_status": None,
                "response_body_sha256": None,
                "provider_error_code": None,
            })
            self.write()
            return call_id

    def complete(self, call_id: str, result: ProviderResult) -> None:
        with self._lock:
            row = self._running(call_id)
            if result.usage.input_tokens > INPUT_TOKEN_CAP:
                raise C14V2ClosureError("provider input-token hard cap exceeded")
            if result.usage.output_tokens > OUTPUT_TOKEN_CAP:
                raise C14V2ClosureError("provider output-token hard cap exceeded")
            row.update({
                "status": "COMPLETED_AUDITED",
                "completed_at": _timestamp(),
                "input_tokens": result.usage.input_tokens,
                "output_tokens": result.usage.output_tokens,
                "total_tokens": result.usage.total_tokens,
                "wall_ms": result.wall_ms,
                "estimated_cost_usd": _estimated_cost(
                    result.usage.input_tokens, result.usage.output_tokens
                ),
            })
            self.write()

    def fail(self, call_id: str, exc: BaseException) -> None:
        with self._lock:
            row = self._running(call_id)
            row.update({
                "status": "FAILED_RETAINED",
                "completed_at": _timestamp(),
                "error_code": type(exc).__name__,
                "wall_ms": max(0, int(getattr(exc, "wall_ms", 0))),
                "http_status": getattr(exc, "http_status", None),
                "response_body_sha256": getattr(exc, "response_body_sha256", None),
                "provider_error_code": getattr(exc, "provider_error_code", None),
                "response_outcome_unknown": bool(
                    getattr(exc, "response_outcome_unknown", False)
                ),
            })
            self.write()

    def mark_failed_response_unknown(self, call_id: str, *, reason: str) -> None:
        """Conservatively enrich a retained transport failure after evidence audit."""

        with self._lock:
            matches = [row for row in self.rows if row.get("call_id") == call_id]
            if (
                len(matches) != 1
                or matches[0].get("status") != "FAILED_RETAINED"
                or matches[0].get("response_outcome_unknown") is True
                or not reason
            ):
                raise C14V2ClosureError(
                    "provider failure is not eligible for unknown-response marking"
                )
            matches[0]["response_outcome_unknown"] = True
            matches[0]["response_unknown_reason"] = reason
            self.write()

    def recover_interrupted(self, call_id: str) -> None:
        """Close an externally interrupted, response-unknown call without inventing usage."""

        with self._lock:
            row = self._running(call_id)
            row.update({
                "status": "FAILED_RETAINED",
                "completed_at": _timestamp(),
                "error_code": "OPERATOR_FAIL_CLOSED_INTERRUPTION_RESPONSE_UNKNOWN",
                "response_outcome_unknown": True,
            })
            self.write()

    def document(self) -> dict[str, Any]:
        with self._lock:
            completed = [
                row for row in self.rows if row["status"] == "COMPLETED_AUDITED"
            ]
            failed = [row for row in self.rows if row["status"] == "FAILED_RETAINED"]
            return {
            "schema_version": "exp09-c14-1-provider-cost-ledger-v2",
            "artifact_status": "AUTHORIZED_COMPANY_CHANNEL_LEDGER",
            "protocol_generation": PROTOCOL_GENERATION,
            "provider": "openai",
            "model_identifier": PROVIDER_MODEL_IDENTIFIER,
            "model_revision": PROVIDER_MODEL_REVISION,
            "endpoint_host": self.endpoint_host,
            "provider_config_sha256": self.provider_config_sha256,
            "pricing_basis": {
                "source": "https://platform.openai.com/docs/pricing",
                "input_usd_per_million": 0.75,
                "output_usd_per_million": 4.50,
                "company_channel_actual_billing_auditable": False,
                "cost_stop_disabled_by_user_at": "2026-07-30",
            },
            "hard_caps": {
                "calls": PROVIDER_CALL_CAP,
                "input_tokens_per_call": INPUT_TOKEN_CAP,
                "output_tokens_per_call": OUTPUT_TOKEN_CAP,
                "retry": 0,
                "concurrency": CACHE_REMEDIATION_CONCURRENCY,
            },
            "worst_case": {
                "input_tokens": PROVIDER_CALL_CAP * INPUT_TOKEN_CAP,
                "output_tokens": PROVIDER_CALL_CAP * OUTPUT_TOKEN_CAP,
                "estimated_standard_price_usd": 38.928384,
            },
            "usage": {
                "calls_started": len(self.rows),
                "calls_completed": len(completed),
                "calls_failed": len(failed),
                "input_tokens": sum(row["input_tokens"] for row in completed),
                "output_tokens": sum(row["output_tokens"] for row in completed),
                "total_tokens": sum(row["total_tokens"] for row in completed),
                "estimated_cost_usd": round(
                    sum(row["estimated_cost_usd"] for row in completed), 9
                ),
                "wall_ms": sum(row.get("wall_ms", 0) for row in self.rows),
            },
            "api_key_recorded": False,
            "rows_sha256": _canonical_sha(self.rows),
            "rows": self.rows,
            }

    def write(self) -> str:
        with self._lock:
            return _atomic_write_json(self.path, self.document())

    def _running(self, call_id: str) -> dict[str, Any]:
        matches = [row for row in self.rows if row["call_id"] == call_id]
        if len(matches) != 1 or matches[0]["status"] != "STARTED_NO_RESPONSE":
            raise C14V2ClosureError("provider call is not in a resumable running state")
        return matches[0]


class ProviderSession:
    """One stateless, non-retrying provider session for one method/arm namespace."""

    def __init__(
        self,
        *,
        method_id: str,
        arm: str,
        credentials: ProviderCredentials,
        protocol: dict[str, Any],
        ledger: ProviderLedger,
        purpose: str = "CAUSAL_FRONTIER",
    ) -> None:
        if method_id not in METHODS or arm not in ARMS:
            raise C14V2ClosureError("provider session scope is invalid")
        self.method_id = method_id
        self.arm = arm
        self.credentials = credentials
        self.protocol = protocol
        self.ledger = ledger
        self.purpose = purpose
        suffix = "-structured-preflight" if purpose == "STRUCTURED_PREFLIGHT" else ""
        self.session_id = f"c14-v2-{method_id.lower()}-{arm.lower()}{suffix}"

    def generate(self, *, request_hash: str, model_payload: dict[str, Any]) -> ProviderResult:
        _reject_identity_fields(model_payload)
        body = build_provider_request_body(
            method_id=self.method_id,
            protocol=self.protocol,
            model_payload=model_payload,
        )
        call_id = self.ledger.begin(
            session_id=self.session_id,
            request_hash=request_hash,
            method_id=self.method_id,
            arm=self.arm,
            purpose=self.purpose,
        )
        try:
            result = self._call(body)
            parsed = audit_provider_response(
                self.method_id,
                request_hash=request_hash,
                model_payload=model_payload,
                response=result.parsed_response,
            )
            audited = ProviderResult(
                raw_response=result.raw_response,
                parsed_response=parsed,
                finish_reason=result.finish_reason,
                usage=result.usage,
                wall_ms=result.wall_ms,
            )
            self.ledger.complete(call_id, audited)
            return audited
        except BaseException as exc:
            self.ledger.fail(call_id, exc)
            raise

    def _call(self, body: dict[str, Any]) -> ProviderResult:
        payload = _canonical_bytes(body)
        request = Request(
            f"{self.credentials.base_url}/chat/completions",
            data=payload,
            headers={
                "Authorization": f"Bearer {self.credentials.api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "exp09-c14-offline-cache/3.0",
            },
            method="POST",
        )
        started = time.monotonic()
        try:
            with urlopen(request, timeout=TIMEOUT_SECONDS) as response:
                raw_bytes = response.read()
        except HTTPError as exc:
            wall_ms = max(0, round((time.monotonic() - started) * 1000))
            try:
                error_body = exc.read()
            except OSError:
                error_body = b""
            provider_error_code = None
            try:
                error_document = json.loads(error_body.decode("utf-8"))
                error_value = error_document.get("error", {})
                if isinstance(error_value, dict) and isinstance(error_value.get("code"), str):
                    provider_error_code = error_value["code"]
            except (UnicodeError, ValueError, AttributeError):
                pass
            raise ProviderTransportError(
                "provider transport failed without retry: HTTPError",
                wall_ms=wall_ms,
                http_status=exc.code,
                response_body_sha256=hashlib.sha256(error_body).hexdigest().upper(),
                provider_error_code=provider_error_code,
            ) from exc
        except TimeoutError as exc:
            raise ProviderTransportError(
                "provider transport failed without retry: TimeoutError",
                wall_ms=max(0, round((time.monotonic() - started) * 1000)),
                response_outcome_unknown=True,
            ) from exc
        except RemoteDisconnected as exc:
            raise ProviderTransportError(
                "provider transport failed without retry: RemoteDisconnected",
                wall_ms=max(0, round((time.monotonic() - started) * 1000)),
                response_outcome_unknown=True,
            ) from exc
        except (URLError, OSError) as exc:
            raise ProviderTransportError(
                f"provider transport failed without retry: {type(exc).__name__}",
                wall_ms=max(0, round((time.monotonic() - started) * 1000)),
            ) from exc
        wall_ms = max(0, round((time.monotonic() - started) * 1000))
        try:
            raw = json.loads(raw_bytes.decode("utf-8"))
            choices = raw["choices"]
            if not isinstance(choices, list) or len(choices) != 1:
                raise ValueError("choice count")
            choice = choices[0]
            content = choice["message"]["content"]
            parsed = json.loads(content)
            usage_raw = raw["usage"]
            usage = ProviderUsage(
                input_tokens=_strict_nonnegative_int(usage_raw["prompt_tokens"]),
                output_tokens=_strict_nonnegative_int(usage_raw["completion_tokens"]),
                total_tokens=_strict_nonnegative_int(usage_raw["total_tokens"]),
            )
            finish_reason = choice["finish_reason"]
        except (KeyError, TypeError, ValueError, UnicodeError, json.JSONDecodeError) as exc:
            raise C14V2ClosureError("provider response envelope is invalid") from exc
        if finish_reason != "stop" or usage.total_tokens != (
            usage.input_tokens + usage.output_tokens
        ):
            raise C14V2ClosureError("provider response finish/usage audit failed")
        return ProviderResult(
            raw_response=raw,
            parsed_response=parsed,
            finish_reason=finish_reason,
            usage=usage,
            wall_ms=wall_ms,
        )


def build_provider_request_body(
    *, method_id: str, protocol: dict[str, Any], model_payload: dict[str, Any]
) -> dict[str, Any]:
    """Build the relay request with the API model identifier, not its revision metadata."""

    if method_id not in METHODS:
        raise C14V2ClosureError("provider request method is invalid")
    _reject_identity_fields(model_payload)
    return {
        "model": PROVIDER_MODEL_IDENTIFIER,
        "messages": [
            {"role": "system", "content": protocol["system_prompt"]},
            {
                "role": "user",
                "content": _canonical_text(
                    {
                        "instruction": protocol["user_prompt_template"]["instruction"],
                        "input": model_payload,
                    }
                ),
            },
        ],
        "temperature": 0,
        "reasoning_effort": "none",
        "max_tokens": OUTPUT_TOKEN_CAP,
        "response_format": {
            "type": "json_schema",
            "json_schema": _provider_response_schema(method_id, model_payload),
        },
    }


def _provider_response_schema(method_id: str, model_payload: dict[str, Any]) -> dict[str, Any]:
    schema = json.loads(
        json.dumps(_FULL_RESPONSE_SCHEMA if method_id == "Full" else _PLAIN_RESPONSE_SCHEMA)
    )
    if method_id == "Full":
        return schema
    eligible_value = model_payload.get("eligible_actions")
    if (
        not isinstance(eligible_value, (list, tuple))
        or not eligible_value
        or any(not isinstance(item, str) for item in eligible_value)
        or len(eligible_value) != len(set(eligible_value))
    ):
        raise C14V2ClosureError("Plain_LLM provider schema requires unique eligible actions")
    eligible = list(eligible_value)
    properties = schema["schema"]["properties"]
    properties["schema_version"] = {
        "type": "string",
        "enum": ["exp09-c14-1-plain-llm-output-v1"],
    }
    properties["candidate_order"] = {
        "type": "array",
        "items": {"type": "string", "enum": eligible},
        "minItems": len(eligible),
        "maxItems": len(eligible),
    }
    properties["chosen_action_id"] = {"type": "string", "enum": eligible}
    return schema


def audit_provider_response(
    method_id: str,
    *,
    request_hash: str,
    model_payload: dict[str, Any],
    response: Any,
) -> dict[str, Any]:
    """Return the exact cache payload only after the frozen method audit passes."""

    if not isinstance(response, dict):
        raise C14V2ClosureError("provider response is not a JSON object")
    if method_id == "Plain_LLM":
        expected_fields = {
            "schema_version",
            "candidate_order",
            "chosen_action_id",
            "confidence_ppm",
            "rationale_code",
        }
        if set(response) != expected_fields:
            raise C14V2ClosureError("Plain_LLM response field set mismatch")
        eligible = model_payload.get("eligible_actions")
        order = response.get("candidate_order")
        if (
            response.get("schema_version") != "exp09-c14-1-plain-llm-output-v1"
            or not isinstance(eligible, (list, tuple))
            or not isinstance(order, list)
            or len(order) != len(eligible)
            or len(set(order)) != len(order)
            or set(order) != set(eligible)
            or not order
            or response.get("chosen_action_id") != order[0]
            or type(response.get("confidence_ppm")) is not int
            or not 0 <= response["confidence_ppm"] <= 1_000_000
            or response.get("rationale_code")
            not in {
                "FRESHNESS_PRIORITY",
                "COLLISION_RISK_PRIORITY",
                "BALANCED_OBSERVABLE_TRADEOFF",
                "INSUFFICIENT_OBSERVABLE_EVIDENCE",
            }
        ):
            raise C14V2ClosureError("Plain_LLM full-candidate response audit failed")
        return response
    if method_id != "Full" or set(response) != {
        "transition_id",
        "target_program_id",
        "rationale_code",
    }:
        raise C14V2ClosureError("Full response field set mismatch")
    eligible = model_payload.get("eligible_proposals")
    selected = (response.get("transition_id"), response.get("target_program_id"))
    if not isinstance(eligible, list) or selected not in {
        (item.get("transition_id"), item.get("target_program_id"))
        for item in eligible
        if isinstance(item, dict)
    }:
        raise C14V2ClosureError("Full response is not in the exact eligible set")
    try:
        target = response["target_program_id"]
        proposal = ProgramProposal(
            schema_version=PROGRAM_PROPOSAL_SCHEMA_VERSION,
            transition_id=TransitionId(response["transition_id"]),
            target_program_id=None if target is None else ProgramId(target),
            rationale_code=RationaleCode(response["rationale_code"]),
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise C14V2ClosureError("Full response schema audit failed") from exc
    return {
        "proposal": response,
        "response_hash": provider_response_hash(request_hash, proposal),
    }


class ClosureCache:
    """Persist, generate, audit and bind a miss before returning any response."""

    def __init__(
        self,
        *,
        project_root: Path,
        output_root: Path,
        method_id: str,
        arm: str,
        materializer: ProtocolGenerationRequestMaterializer,
        provider_session: ProviderSession,
        method_config_sha256: str,
        prompt_protocol_sha256: str,
        provider_config_sha256: str,
    ) -> None:
        self.project_root = project_root
        self.output_root = output_root
        self.method_id = method_id
        self.arm = arm
        self.namespace = materializer.namespace
        self.materializer = materializer
        self.provider_session = provider_session
        self.method_config_sha256 = method_config_sha256
        self.prompt_protocol_sha256 = prompt_protocol_sha256
        self.provider_config_sha256 = provider_config_sha256
        self.case_id: str | None = None
        self.responses: dict[str, dict[str, Any]] = {}
        self.source_records: list[dict[str, Any]] = []
        self.miss_rows: list[dict[str, Any]] = []
        self.lookup_attempts = 0
        had_directory = self._directory().exists()
        self._load_existing()
        if not had_directory:
            # Keep an auditable empty namespace for valid no-frontier cases.
            self._persist_all()

    @contextmanager
    def bind_case(self, case_id: str) -> Iterator[None]:
        if self.case_id is not None:
            raise C14V2ClosureError("closure cache case binding is already active")
        self.case_id = case_id
        try:
            yield
        finally:
            self.case_id = None

    def response_for(self, request_hash: str) -> dict[str, Any]:
        self.lookup_attempts += 1
        response = self.responses.get(request_hash)
        if response is not None:
            return response
        if self.case_id is None:
            raise C14V2ClosureError("cache miss occurred without a bound frontier case")
        matches = [record for record in self.materializer.records if record.request_hash == request_hash]
        if len(matches) != 1:
            raise C14V2ClosureError("cache lookup is not bound to one materialized request")
        record = matches[0]
        pending = [
            row
            for row in self.miss_rows
            if row["request_hash"] == request_hash
            and row["status"] in {
                "CACHE_MISS_PERSISTED_RESPONSE_PENDING",
                "CACHE_MISS_RESUME_PERSISTED_RESPONSE_PENDING",
            }
        ]
        miss = {
            "ordinal": len(self.miss_rows),
            "case_id": self.case_id,
            "method_id": self.method_id,
            "arm": self.arm,
            "namespace": self.namespace,
            "request_hash": request_hash,
            "model_payload_sha256": _canonical_sha(record.model_payload),
            "status": (
                "CACHE_MISS_RESUME_PERSISTED_RESPONSE_PENDING"
                if pending
                else "CACHE_MISS_PERSISTED_RESPONSE_PENDING"
            ),
            "resume_of_ordinal": pending[-1]["ordinal"] if pending else None,
            "persisted_at": _timestamp(),
            "audited_at": None,
            "response_binding_sha256": None,
        }
        self.miss_rows.append(miss)
        self._persist_all()
        result = self.provider_session.generate(
            request_hash=request_hash,
            model_payload=record.model_payload,
        )
        response = result.parsed_response
        binding_sha = _canonical_sha({"request_hash": request_hash, "response": response})
        self.source_records.append(
            {
                "request_hash": request_hash,
                "request_payload_sha256": _canonical_sha(record.model_payload),
                "raw_response": result.raw_response,
                "parsed_response": response,
                "finish_reason": result.finish_reason,
                "input_tokens": result.usage.input_tokens,
                "output_tokens": result.usage.output_tokens,
                "total_tokens": result.usage.total_tokens,
                "wall_ms": result.wall_ms,
                "response_binding_sha256": binding_sha,
            }
        )
        self.responses[request_hash] = response
        miss.update(
            {
                "status": "RESPONSE_AUDITED_CACHE_BOUND",
                "audited_at": _timestamp(),
                "response_binding_sha256": binding_sha,
            }
        )
        self._persist_all()
        return response

    def qualification_cache(self) -> AuditableOfflineCache:
        inventory = self.inventory_document()
        bundle = self.bundle_document(inventory)
        audit_cache_documents(inventory, bundle)
        bundle_path = self._path("cache_bundle.json")
        return AuditableOfflineCache(
            method_id=self.method_id,
            namespace=self.namespace,
            bundle_sha256=_sha(bundle_path),
            responses_by_request_hash=dict(self.responses),
        )

    def inventory_document(self) -> dict[str, Any]:
        document = self.materializer.inventory_document(synthetic_fixture=False)
        document["artifact_status"] = "AUTHORIZED_COMPLETE_CAUSAL_REQUEST_INVENTORY"
        return document

    def source_document(self) -> dict[str, Any]:
        return {
            "schema_version": "exp09-c14-1-external-response-source-v2",
            "artifact_status": "COMPANY_CHANNEL_SOURCE_RETAINED_AUDITED",
            "protocol_generation": PROTOCOL_GENERATION,
            "method_id": self.method_id,
            "arm": self.arm,
            "namespace": self.namespace,
            "provider": "openai",
            "model_identifier": PROVIDER_MODEL_IDENTIFIER,
            "model_revision": PROVIDER_MODEL_REVISION,
            "provider_config_sha256": self.provider_config_sha256,
            "retry_count": 0,
            "tool_call_count": 0,
            "provider_memory": False,
            "records_sha256": _canonical_sha(self.source_records),
            "records": self.source_records,
        }

    def bundle_document(self, inventory: dict[str, Any] | None = None) -> dict[str, Any]:
        inventory = inventory or self.inventory_document()
        source_path = self._path("response_source.json")
        entries = [
            {
                "request_hash": request_hash,
                "response": self.responses[request_hash],
                "response_binding_sha256": _canonical_sha(
                    {"request_hash": request_hash, "response": self.responses[request_hash]}
                ),
            }
            for request_hash in inventory["request_hashes"]
            if request_hash in self.responses
        ]
        required = inventory["request_hashes"]
        entry_hashes = [entry["request_hash"] for entry in entries]
        missing = [request_hash for request_hash in required if request_hash not in self.responses]
        unexpected = [request_hash for request_hash in entry_hashes if request_hash not in required]
        duplicate = len(entry_hashes) - len(set(entry_hashes))
        return {
            "schema_version": "exp09-c14-1-offline-cache-bundle-v2",
            "artifact_status": "EXACT_COVERAGE_CANDIDATE",
            "protocol_generation": PROTOCOL_GENERATION,
            "method_id": self.method_id,
            "arm": self.arm,
            "namespace": self.namespace,
            "network_fallback": False,
            "api_calls_during_replay": 0,
            "provider_calls_during_replay": 0,
            "llm_tokens_during_replay": 0,
            "bindings": {
                "method_config_sha256": self.method_config_sha256,
                "prompt_protocol_sha256": self.prompt_protocol_sha256,
                "provider_config_sha256": self.provider_config_sha256,
            },
            "provenance": {
                "source_artifact_locator": source_path.relative_to(self.project_root).as_posix(),
                "source_artifact_sha256": _sha(source_path),
            },
            "coverage": {
                "status": "COMPLETE" if not missing and not unexpected and not duplicate else "PARTIAL",
                "required_request_hashes": required,
                "missing": len(missing),
                "unexpected": len(unexpected),
                "duplicate": duplicate,
            },
            "entries_sha256": _canonical_sha(entries),
            "entries": entries,
        }

    def _persist_all(self) -> None:
        directory = self._directory()
        directory.mkdir(parents=True, exist_ok=True)
        inventory = self.inventory_document()
        _atomic_write_json(self._path("request_inventory.json"), inventory)
        _atomic_write_json(self._path("frontier_ledger.json"), {
            "schema_version": "exp09-c14-1-frontier-ledger-v2",
            "protocol_generation": PROTOCOL_GENERATION,
            "method_id": self.method_id,
            "arm": self.arm,
            "namespace": self.namespace,
            "lookup_attempts": self.lookup_attempts,
            "rows_sha256": _canonical_sha(self.miss_rows),
            "rows": self.miss_rows,
        })
        _atomic_write_json(self._path("response_source.json"), self.source_document())
        _atomic_write_json(self._path("cache_bundle.json"), self.bundle_document(inventory))

    def _load_existing(self) -> None:
        directory = self._directory()
        if not directory.exists():
            return
        required = (
            "request_inventory.json",
            "frontier_ledger.json",
            "response_source.json",
            "cache_bundle.json",
        )
        if not all(self._path(name).is_file() for name in required):
            raise C14V2ClosureError("partial closure namespace cannot be resumed safely")
        inventory = _strict_json(self._path("request_inventory.json"))
        source = _strict_json(self._path("response_source.json"))
        bundle = _strict_json(self._path("cache_bundle.json"))
        ledger = _strict_json(self._path("frontier_ledger.json"))
        interrupted_recovery = None
        try:
            audit_cache_documents(inventory, bundle, require_complete=False)
        except C14V2ClosureError:
            interrupted_recovery = _audit_interrupted_namespace_prefix(
                inventory=inventory,
                bundle=bundle,
                source=source,
                frontier_ledger=ledger,
                provider_rows=self.provider_session.ledger.rows,
            )
        if (
            source.get("records_sha256") != _canonical_sha(source.get("records"))
            or ledger.get("rows_sha256") != _canonical_sha(ledger.get("rows"))
            or ledger.get("method_id") != self.method_id
            or ledger.get("arm") != self.arm
            or ledger.get("namespace") != self.namespace
        ):
            raise C14V2ClosureError("existing closure provenance or ledger integrity mismatch")
        records = inventory.get("records")
        if not isinstance(records, list):
            raise C14V2ClosureError("existing inventory records are invalid")
        for record in records:
            restored = self.materializer._record(
                record["cache_envelope"],
                record["model_payload"],
                opportunity_id=record["opportunity_id"],
                causal_cutoff_us=record["causal_cutoff_us"],
            )
            if restored.request_hash != record["request_hash"]:
                raise C14V2ClosureError("existing inventory cannot be reproduced")
        self.source_records = source["records"]
        self.miss_rows = ledger["rows"]
        self.lookup_attempts = int(ledger.get("lookup_attempts", len(self.miss_rows)))
        self.responses = {entry["request_hash"]: entry["response"] for entry in bundle["entries"]}
        if interrupted_recovery is not None:
            self._write_interrupted_recovery_evidence(interrupted_recovery)

    def _write_interrupted_recovery_evidence(self, recovery: dict[str, Any]) -> None:
        evidence_root = self.output_root / "interrupted_persist_recovery"
        pending_hash = recovery["pending_request_hash"]
        path = evidence_root / f"{self.method_id}__{self.arm}__{pending_hash}.json"
        document = {
            "schema_version": "exp09-c14-1-interrupted-persist-recovery-v1",
            "artifact_status": "QUALIFIED_SAFE_TO_REMATERIALIZE_PENDING_REQUEST",
            "protocol_generation": PROTOCOL_GENERATION,
            "method_id": self.method_id,
            "arm": self.arm,
            "namespace": self.namespace,
            "recorded_at": _timestamp(),
            **recovery,
            "api_key_recorded": False,
            "network_calls_during_recovery": 0,
            "training": False,
            "later_stages": False,
        }
        if path.exists():
            existing = _strict_json(path)
            provider_rows = self.provider_session.ledger.rows
            prefix_count = existing.get("provider_rows_count_at_recovery")
            if (
                not isinstance(prefix_count, int)
                or prefix_count < 0
                or prefix_count > len(provider_rows)
                or existing.get("provider_rows_prefix_sha256")
                != _canonical_sha(provider_rows[:prefix_count])
            ):
                raise C14V2ClosureError(
                    "interrupted-persist recovery provider-ledger prefix drift"
                )
            comparable = dict(existing)
            comparable.pop("recorded_at", None)
            comparable.pop("provider_rows_count_at_recovery", None)
            comparable.pop("provider_rows_prefix_sha256", None)
            expected = dict(document)
            expected.pop("recorded_at", None)
            expected.pop("provider_rows_count_at_recovery", None)
            expected.pop("provider_rows_prefix_sha256", None)
            if comparable != expected:
                raise C14V2ClosureError("interrupted-persist recovery evidence drift")
            return
        _atomic_write_json(path, document)

    def _directory(self) -> Path:
        return self.output_root / f"{self.method_id}__{self.arm}"

    def _path(self, name: str) -> Path:
        return self._directory() / name


class QualifiedReplayCache:
    """Immutable formal replay view; a miss cannot invoke the provider generator."""

    def __init__(self, cache: ClosureCache) -> None:
        qualified = cache.qualification_cache()
        self.method_id = qualified.method_id
        self.namespace = qualified.namespace
        self.bundle_sha256 = qualified.bundle_sha256
        self._responses = dict(qualified.responses_by_request_hash)

    def response_for(self, request_hash: str) -> dict[str, Any]:
        response = self._responses.get(request_hash)
        if response is None:
            raise C14V2ClosureError(
                "qualified formal cache miss; provider/network fallback is forbidden"
            )
        return response


def audit_cache_documents(
    inventory: dict[str, Any], bundle: dict[str, Any], *, require_complete: bool = True
) -> None:
    """Independent exact ordered-coverage and response-binding audit."""

    records = inventory.get("records")
    request_hashes = inventory.get("request_hashes")
    entries = bundle.get("entries")
    coverage = bundle.get("coverage")
    entry_hashes = [entry.get("request_hash") for entry in entries]
    ordered_subset = (
        len(entry_hashes) == len(set(entry_hashes))
        and all(request_hash in request_hashes for request_hash in entry_hashes)
        and entry_hashes
        == [request_hash for request_hash in request_hashes if request_hash in entry_hashes]
    )
    if (
        inventory.get("schema_version") != "exp09-c14-1-request-inventory-v2"
        or (
            inventory.get("protocol_generation") is not None
            and inventory.get("protocol_generation") != PROTOCOL_GENERATION
        )
        or (
            bundle.get("protocol_generation") is not None
            and bundle.get("protocol_generation") != PROTOCOL_GENERATION
        )
        or bundle.get("schema_version") != "exp09-c14-1-offline-cache-bundle-v2"
        or not isinstance(records, list)
        or not isinstance(request_hashes, list)
        or not isinstance(entries, list)
        or inventory.get("records_sha256") != _canonical_sha(records)
        or request_hashes != [record.get("request_hash") for record in records]
        or len(request_hashes) != len(set(request_hashes))
        or any(
            isinstance(record.get("cache_envelope"), dict)
            and record["cache_envelope"].get("protocol_generation")
            != PROTOCOL_GENERATION
            for record in records
        )
        or bundle.get("entries_sha256") != _canonical_sha(entries)
        or not ordered_subset
        or not isinstance(coverage, dict)
        or coverage.get("required_request_hashes") != request_hashes
    ):
        raise C14V2ClosureError("exact ordered cache coverage audit failed")
    expected_missing = len(request_hashes) - len(entries)
    expected_unexpected = len(
        [request_hash for request_hash in entry_hashes if request_hash not in request_hashes]
    )
    if require_complete and coverage != {
        "status": "COMPLETE",
        "required_request_hashes": request_hashes,
        "missing": 0,
        "unexpected": 0,
        "duplicate": 0,
    }:
        raise C14V2ClosureError("exact ordered cache coverage audit failed")
    if not require_complete and (
        coverage.get("missing") != expected_missing
        or coverage.get("unexpected") != expected_unexpected
        or coverage.get("duplicate") != 0
        or coverage.get("status") not in {"PARTIAL", "COMPLETE"}
    ):
        raise C14V2ClosureError("partial cache coverage audit failed")
    record_by_hash = {record["request_hash"]: record for record in records}
    for entry in entries:
        expected_binding = _canonical_sha(
            {"request_hash": entry["request_hash"], "response": entry["response"]}
        )
        if entry.get("response_binding_sha256") != expected_binding:
            raise C14V2ClosureError("cache response binding audit failed")
        audit_provider_response(
            inventory["method_id"],
            request_hash=entry["request_hash"],
            model_payload=record_by_hash[entry["request_hash"]]["model_payload"],
            response=(
                entry["response"]["proposal"]
                if inventory["method_id"] == "Full"
                else entry["response"]
            ),
        )


def _audit_interrupted_namespace_prefix(
    *,
    inventory: dict[str, Any],
    bundle: dict[str, Any],
    source: dict[str, Any],
    frontier_ledger: dict[str, Any],
    provider_rows: list[dict[str, Any]],
) -> dict[str, Any]:
    """Qualify only the exact one-record interruption caused by persist ordering."""

    records = inventory.get("records")
    request_hashes = inventory.get("request_hashes")
    entries = bundle.get("entries")
    source_records = source.get("records")
    frontier_rows = frontier_ledger.get("rows")
    if not all(
        isinstance(value, list)
        for value in (records, request_hashes, entries, source_records, frontier_rows)
    ):
        raise C14V2ClosureError("interrupted namespace documents are not list-backed")
    if (
        inventory.get("schema_version") != "exp09-c14-1-request-inventory-v2"
        or bundle.get("schema_version") != "exp09-c14-1-offline-cache-bundle-v2"
        or source.get("schema_version") != "exp09-c14-1-external-response-source-v2"
        or frontier_ledger.get("schema_version") != "exp09-c14-1-frontier-ledger-v2"
        or inventory.get("records_sha256") != _canonical_sha(records)
        or source.get("records_sha256") != _canonical_sha(source_records)
        or frontier_ledger.get("rows_sha256") != _canonical_sha(frontier_rows)
        or bundle.get("entries_sha256") != _canonical_sha(entries)
        or request_hashes != [record.get("request_hash") for record in records]
        or len(records) != len(entries) + 1
        or len(entries) != len(source_records)
        or len(entries) != len(frontier_rows)
        or [entry.get("request_hash") for entry in entries] != request_hashes[:-1]
        or [record.get("request_hash") for record in source_records] != request_hashes[:-1]
        or [row.get("request_hash") for row in frontier_rows] != request_hashes[:-1]
        or any(row.get("status") != "RESPONSE_AUDITED_CACHE_BOUND" for row in frontier_rows)
        or bundle.get("coverage")
        != {
            "status": "COMPLETE",
            "required_request_hashes": request_hashes[:-1],
            "missing": 0,
            "unexpected": 0,
            "duplicate": 0,
        }
    ):
        raise C14V2ClosureError("interrupted namespace is not one complete auditable prefix")
    prefix_inventory = dict(inventory)
    prefix_inventory["request_count"] = len(records) - 1
    prefix_inventory["request_hashes"] = request_hashes[:-1]
    prefix_inventory["records"] = records[:-1]
    prefix_inventory["records_sha256"] = _canonical_sha(records[:-1])
    audit_cache_documents(prefix_inventory, bundle, require_complete=True)
    pending_hash = request_hashes[-1]
    provider_matches = [
        row for row in provider_rows if row.get("request_hash") == pending_hash
    ]
    if provider_matches and not (
        len(provider_matches) == 1
        and provider_matches[0].get("status") == "FAILED_RETAINED"
        and provider_matches[0].get("response_outcome_unknown") is True
        and provider_matches[0].get("method_id") == inventory.get("method_id")
        and provider_matches[0].get("arm") == inventory.get("arm")
        and provider_matches[0].get("input_tokens") == 0
        and provider_matches[0].get("output_tokens") == 0
        and provider_matches[0].get("total_tokens") == 0
    ):
        raise C14V2ClosureError(
            "interrupted pending request has an unsafe provider-ledger state"
        )
    return {
        "pending_request_hash": pending_hash,
        "pending_model_payload_sha256": _canonical_sha(records[-1]["model_payload"]),
        "audited_prefix_request_count": len(entries),
        "inventory_sha256": _canonical_sha(inventory),
        "frontier_ledger_sha256": _canonical_sha(frontier_ledger),
        "response_source_sha256": _canonical_sha(source),
        "cache_bundle_sha256": _canonical_sha(bundle),
        "provider_rows_count_at_recovery": len(provider_rows),
        "provider_rows_prefix_sha256": _canonical_sha(provider_rows),
        "pending_request_provider_match_count": len(provider_matches),
        "pending_request_provider_call_id": (
            provider_matches[0]["call_id"] if provider_matches else None
        ),
    }


class _DecisionMeter:
    def __init__(
        self,
        controller: Any,
        case: C14MethodCase,
        *,
        stop_event: Event | None = None,
    ) -> None:
        self.controller = controller
        self.case = case
        self.stop_event = stop_event
        self.decisions = 0
        self.commitments = 0
        self.causal_closure_complete = False

    def reset(self, context: Any) -> None:
        self.controller.reset(context)

    def decide(self, frame: Any, opportunity: Any) -> Any:
        if self.stop_event is not None and self.stop_event.is_set():
            raise C14V2ClosureError("parallel cache closure stopped after peer failure")
        if self.decisions >= FULL_TAPE_MAX_CONTROL_OPPORTUNITIES_PER_CASE:
            raise C14V2ClosureError("full-tape case opportunity hard cap exceeded")
        self.decisions += 1
        commitment = self.controller.decide(frame, opportunity)
        self.commitments += 1
        return commitment


def run_causal_case_without_statistics(tape: Any, controller: Any) -> int:
    """Drive only causal controller/plant state; do not construct metrics or raw outputs."""

    validate_primary_tape(tape)
    plant = DiscreteEventSPSPlant()
    plant.reset(tape)
    receiver = ReceiverMeasurementLedger()
    adapter = ObservationAdapter()
    summaries: list[Any] = []
    deliveries: list[Any] = []
    next_summary_us = int(tape.simulation_start_us)
    next_delivery_sequence = 0
    controller_reset = False
    latest = plant.snapshot()
    decision_count = 0
    while latest.time_us < int(tape.simulation_end_us):
        previous_time_us = latest.time_us
        result = plant.advance_until(int(tape.simulation_end_us))
        latest = result.snapshot
        boundary_us = latest.time_us
        if not result.opportunities and boundary_us < int(tape.simulation_end_us) and boundary_us <= previous_time_us:
            raise C14V2ClosureError("causal Phase A plant made no forward progress")
        for event in result.measurement_delivery_delta:
            receiver.ingest_delivery(event)
        while next_summary_us <= boundary_us and next_summary_us < int(tape.simulation_end_us):
            summaries.append(
                receiver.summarize(next_summary_us, window_start_us=int(tape.simulation_start_us))
            )
            next_summary_us += SUMMARY_PERIOD_US
        while next_delivery_sequence < len(summaries):
            summary = summaries[next_delivery_sequence]
            received_at = int(summary.header.causal_cutoff_us) + MEASUREMENT_DELAY_US
            if received_at > boundary_us:
                break
            frame = adapter.build(summary, received_at)
            from .runner import SummaryDeliveryRecord, SUMMARY_DELIVERY_RECORD_SCHEMA_VERSION

            deliveries.append(
                SummaryDeliveryRecord(
                    schema_version=SUMMARY_DELIVERY_RECORD_SCHEMA_VERSION,
                    sequence=summary.header.sequence,
                    generated_at_us=int(summary.header.causal_cutoff_us),
                    received_at_us=received_at,
                    payload_hash=frame.summary_payload_hash,
                    frame=frame,
                )
            )
            next_delivery_sequence += 1
        if result.opportunities:
            opportunity = result.opportunities[0]
            frame = _latest_frame_or_unavailable(
                deliveries, summaries, adapter, int(opportunity.time_us)
            )
            if not controller_reset:
                controller.reset(_reset_context(tape))
                controller_reset = True
            commitment = controller.decide(frame, opportunity)
            decision_count += 1
            if getattr(controller, "causal_closure_complete", False):
                break
            if commitment is None:
                raise C14V2ClosureError("controller returned no causal commitment")
            latest = plant.apply(opportunity, commitment.action)
        elif boundary_us >= int(tape.simulation_end_us):
            break
    return decision_count


class _FormalOnlyProviderSession:
    """Expose retained ledger evidence while making provider generation impossible."""

    def __init__(self, ledger: ProviderLedger) -> None:
        self.ledger = ledger

    def generate(self, **kwargs: Any) -> ProviderResult:
        del kwargs
        raise C14V2ClosureError("formal-only mode forbids provider generation")


class C14V2ClosureOrchestrator:
    def __init__(
        self,
        project_root: Path,
        credential_path: Path | None,
        *,
        formal_only: bool = False,
    ) -> None:
        self.project_root = Path(project_root).resolve()
        self.output_root = self.project_root / OUTPUT_LOCATOR
        self.output_root.mkdir(parents=True, exist_ok=True)
        self.formal_only = formal_only
        self.credentials = (
            None
            if formal_only
            else load_provider_credentials(Path(credential_path), profile="primary")
        )
        provider_config_path = self.project_root / PROVIDER_CONFIG_LOCATOR
        self.provider_config_sha = _sha(provider_config_path)
        self.provider_config = _strict_json(provider_config_path)
        if (
            self.provider_config.get("model_identifier") != PROVIDER_MODEL_IDENTIFIER
            or self.provider_config.get("model_revision") != PROVIDER_MODEL_REVISION
        ):
            raise C14V2ClosureError("provider model identifier/revision binding mismatch")
        self.method_config_sha = _sha(self.project_root / METHOD_CONFIG_LOCATOR)
        self.method_config = _strict_json(self.project_root / METHOD_CONFIG_LOCATOR)
        self.topology = load_frozen_topology(self.project_root, TOPOLOGY_LOCATOR)
        self.factory = C14ControllerFactory(
            self.project_root,
            self.topology.method_config_locator,
            expected_config_sha256=self.topology.method_config_sha256,
        )
        provider_ledger_path = self.output_root / "provider_cost_ledger.json"
        if formal_only:
            retained_provider = _strict_json(provider_ledger_path)
            host = retained_provider.get("endpoint_host")
            if not isinstance(host, str) or not host:
                raise C14V2ClosureError("retained provider endpoint host is unavailable")
        else:
            from urllib.parse import urlparse

            assert self.credentials is not None
            host = urlparse(self.credentials.base_url).hostname
            if not host:
                raise C14V2ClosureError("provider endpoint host is unavailable")
        self.provider_ledger = ProviderLedger(
            provider_ledger_path,
            provider_config_sha256=self.provider_config_sha,
            endpoint_host=host,
        )
        if not formal_only:
            # Freeze the zero-use cost ledger before the first causal provider request.
            self.provider_ledger.write()
        self.materializers: dict[tuple[str, str], ProtocolGenerationRequestMaterializer] = {}
        self.caches: dict[tuple[str, str], ClosureCache] = {}
        for method_id in METHODS:
            method = self.method_config["methods"][method_id]
            protocol = _strict_json(self.project_root / method["prompt_protocol_locator"])
            for arm in ARMS:
                materializer = V3RequestMaterializer(
                    method_id=method_id,
                    arm=arm,
                    base_namespace=method["base_cache_namespace"],
                    method_config_sha256=self.method_config_sha,
                    prompt_protocol_sha256=method["prompt_protocol_sha256"],
                    provider_config_sha256=self.provider_config_sha,
                )
                session = (
                    _FormalOnlyProviderSession(self.provider_ledger)
                    if formal_only
                    else ProviderSession(
                        method_id=method_id,
                        arm=arm,
                        credentials=self.credentials,
                        protocol=protocol,
                        ledger=self.provider_ledger,
                    )
                )
                self.materializers[(method_id, arm)] = materializer
                self.caches[(method_id, arm)] = ClosureCache(
                    project_root=self.project_root,
                    output_root=self.output_root,
                    method_id=method_id,
                    arm=arm,
                    materializer=materializer,
                    provider_session=session,
                    method_config_sha256=self.method_config_sha,
                    prompt_protocol_sha256=method["prompt_protocol_sha256"],
                    provider_config_sha256=self.provider_config_sha,
                )

    def run_cache_closure(self) -> dict[str, Any]:
        if self.formal_only:
            raise C14V2ClosureError("formal-only mode cannot execute cache closure")
        plan = build_phase_a_rematerialization_plan(self.project_root)
        cases = plan["topology"]["cases"]
        if len(cases) != PHASE_A_CASE_COUNT:
            raise C14V2ClosureError("v2 Phase A case count mismatch")
        prior_ledgers = self._load_phase_a_ledgers()
        latest: dict[str, dict[str, Any]] = {}
        for row in prior_ledgers:
            latest[row["case_id"]] = row
        attempt_ordinal = self._next_phase_a_attempt_ordinal()
        progress_path = self.output_root / f"phase_a_case_ledger_attempt_{attempt_ordinal:04d}.json"
        rows: list[dict[str, Any]] = []
        case_by_id = {case.case_id: case for case in self.topology.cases}
        progress_lock = RLock()
        stop = Event()
        runtime_caps = self._full_tape_phase_a_caps(prior_ledgers)

        def execute_planned(planned: dict[str, Any]) -> None:
            case_id = planned["case_id"]
            previous = latest.get(case_id)
            if previous is not None and _phase_a_row_is_complete(previous):
                return
            case = case_by_id.get(case_id)
            if case is None:
                raise C14V2ClosureError("Phase A case is absent from frozen topology")
            key = (case.method_id, case.arm)
            cache = self.caches[key]
            controller = build_protocol_generation_controller(
                self.factory,
                case.method_id,
                cache=cache,
                materializer=self.materializers[key],
            )
            meter = _DecisionMeter(controller, case, stop_event=stop)
            started = _timestamp()
            misses_before = len(cache.miss_rows)
            lookups_before = cache.lookup_attempts
            source_rows_before = len(cache.source_records)
            source_tokens_before = sum(
                int(record["total_tokens"]) for record in cache.source_records
            )
            try:
                with cache.bind_case(case_id):
                    decision_count = run_causal_case_without_statistics(
                        build_primary_influx_tape(case.root_case_id, TapeArm(case.arm)), meter
                    )
                if (
                    decision_count != meter.decisions
                    or decision_count > FULL_TAPE_MAX_CONTROL_OPPORTUNITIES_PER_CASE
                ):
                    raise C14V2ClosureError("INCOMPLETE_CAUSAL_CASE")
                miss_count = len(cache.miss_rows) - misses_before
                lookup_count = cache.lookup_attempts - lookups_before
                provider_calls = len(cache.source_records) - source_rows_before
                if provider_calls != miss_count:
                    raise C14V2ClosureError(
                        "successful full-tape cache miss/provider accounting mismatch"
                    )
                status = "PASSED" if lookup_count else "NO_FRONTIER_COMPLETE"
                row = {
                    "schema_version": "exp09-c14-1-phase-a-runtime-ledger-row-v3",
                    "run_id": f"phase-a-v2__{case_id}__attempt{attempt_ordinal:04d}",
                    "case_id": case_id,
                    "method_id": case.method_id,
                    "arm": case.arm,
                    "scenario": "nominal_fixed" if case.arm == "REFERENCE" else "influx_event",
                    "attempt_ordinal": attempt_ordinal,
                    "resume_of": previous.get("run_id") if previous else None,
                    "status": status,
                    "causal_scope": FULL_TAPE_CAUSAL_SCOPE,
                    "started_at": started,
                    "ended_at": _timestamp(),
                    "decision_attempts": meter.decisions,
                    "model_transitions": meter.decisions * case.transitions_per_opportunity,
                    "pre_miss_controller_commitments": meter.commitments,
                    "cache_lookup_attempts": lookup_count,
                    "cache_misses": miss_count,
                    "post_miss_controller_commitments": 0,
                    "post_miss_plant_actions": 0,
                    "api_calls": provider_calls,
                    "provider_calls": provider_calls,
                    "llm_tokens": sum(
                        int(record["total_tokens"])
                        for record in cache.source_records
                    )
                    - source_tokens_before,
                    "network_attempts": provider_calls,
                    "request_hash": cache.miss_rows[-1]["request_hash"] if miss_count else None,
                    "inventory_sha256_at_miss": _sha(cache._path("request_inventory.json")) if miss_count else None,
                    "error_code": None,
                }
                with progress_lock:
                    rows.append(row)
                    latest[case_id] = row
                    self._write_phase_a_progress(
                        progress_path, rows, runtime_caps, attempt_ordinal
                    )
            except BaseException as exc:
                miss_count = len(cache.miss_rows) - misses_before
                provider_calls = max(
                    miss_count, len(cache.source_records) - source_rows_before
                )
                row = {
                    "schema_version": "exp09-c14-1-phase-a-runtime-ledger-row-v3",
                    "run_id": f"phase-a-v2__{case_id}__attempt{attempt_ordinal:04d}",
                    "case_id": case_id,
                    "method_id": case.method_id,
                    "arm": case.arm,
                    "scenario": "nominal_fixed" if case.arm == "REFERENCE" else "influx_event",
                    "attempt_ordinal": attempt_ordinal,
                    "resume_of": previous.get("run_id") if previous else None,
                    "status": "FAIL_CLOSED",
                    "causal_scope": FULL_TAPE_CAUSAL_SCOPE,
                    "started_at": started,
                    "ended_at": _timestamp(),
                    "decision_attempts": meter.decisions,
                    "model_transitions": meter.decisions * case.transitions_per_opportunity,
                    "pre_miss_controller_commitments": meter.commitments,
                    "cache_lookup_attempts": cache.lookup_attempts - lookups_before,
                    "cache_misses": miss_count,
                    "post_miss_controller_commitments": 0,
                    "post_miss_plant_actions": 0,
                    "api_calls": provider_calls,
                    "provider_calls": provider_calls,
                    "llm_tokens": sum(
                        int(record["total_tokens"])
                        for record in cache.source_records
                    )
                    - source_tokens_before,
                    "network_attempts": provider_calls,
                    "request_hash": cache.miss_rows[-1]["request_hash"] if len(cache.miss_rows) > misses_before else None,
                    "inventory_sha256_at_miss": _sha(cache._path("request_inventory.json")) if len(cache.miss_rows) > misses_before else None,
                    "error_code": type(exc).__name__,
                }
                with progress_lock:
                    first_failure = not stop.is_set()
                    stop.set()
                    rows.append(row)
                    latest[case_id] = row
                    self._write_phase_a_progress(
                        progress_path, rows, runtime_caps, attempt_ordinal
                    )
                    if first_failure:
                        self._write_blocker(
                            "FULL_TAPE_CACHE_CLOSURE_FAIL_CLOSED",
                            exc,
                            phase_a_attempt_ordinal=attempt_ordinal,
                        )
                raise

        grouped = {
            key: [
                planned
                for planned in cases
                if (planned["method_id"], planned["arm"]) == key
            ]
            for key in ((method, arm) for method in METHODS for arm in ARMS)
        }

        def execute_namespace(planned_cases: list[dict[str, Any]]) -> None:
            for planned in planned_cases:
                if stop.is_set():
                    return
                execute_planned(planned)

        with ThreadPoolExecutor(
            max_workers=CACHE_REMEDIATION_CONCURRENCY,
            thread_name_prefix="c14-cache-namespace",
        ) as executor:
            futures = [
                executor.submit(execute_namespace, planned_cases)
                for planned_cases in grouped.values()
            ]
            for future in futures:
                future.result()
        qualification = self.qualify_caches(latest_rows=latest)
        _atomic_write_json(self.output_root / "cache_qualification.json", qualification)
        return qualification

    def _full_tape_phase_a_caps(
        self, historical_rows: list[dict[str, Any]]
    ) -> dict[str, int]:
        historical_decisions = sum(
            int(row.get("decision_attempts", 0)) for row in historical_rows
        )
        historical_transitions = sum(
            int(row.get("model_transitions", 0)) for row in historical_rows
        )
        historical_commitments = sum(
            int(row.get("pre_miss_controller_commitments", 0))
            for row in historical_rows
        )
        full_cases = PHASE_A_CASE_COUNT // len(METHODS)
        return {
            "frontier_cases": PHASE_A_CASE_COUNT,
            "decision_attempts": historical_decisions
            + PHASE_A_CASE_COUNT * FULL_TAPE_MAX_CONTROL_OPPORTUNITIES_PER_CASE,
            "model_transitions": historical_transitions
            + full_cases
            * FULL_TAPE_MAX_CONTROL_OPPORTUNITIES_PER_CASE
            * 72_000,
            "pre_miss_controller_commitments": historical_commitments
            + PHASE_A_CASE_COUNT * FULL_TAPE_MAX_CONTROL_OPPORTUNITIES_PER_CASE,
            "cache_lookup_attempts": historical_decisions
            + PHASE_A_CASE_COUNT * FULL_TAPE_MAX_CONTROL_OPPORTUNITIES_PER_CASE,
            "cache_misses": PROVIDER_CALL_CAP,
            "post_miss_controller_commitments": 0,
            "post_miss_plant_actions": 0,
            "concurrency": CACHE_REMEDIATION_CONCURRENCY,
            "api_calls": PROVIDER_CALL_CAP,
            "provider_calls": PROVIDER_CALL_CAP,
            "llm_tokens": PROVIDER_CALL_CAP * (INPUT_TOKEN_CAP + OUTPUT_TOKEN_CAP),
            "network_attempts": PROVIDER_CALL_CAP,
        }

    def qualify_caches(self, *, latest_rows: dict[str, dict[str, Any]] | None = None) -> dict[str, Any]:
        latest_rows = latest_rows or {}
        if len(latest_rows) != PHASE_A_CASE_COUNT or any(
            not _phase_a_row_is_complete(row)
            for row in latest_rows.values()
        ):
            raise C14V2ClosureError("Phase A requires all 192 cases to close before qualification")
        namespaces = []
        for key in ((m, a) for m in METHODS for a in ARMS):
            cache = self.caches[key]
            inventory = cache.inventory_document()
            bundle = cache.bundle_document(inventory)
            audit_cache_documents(inventory, bundle)
            namespaces.append(
                {
                    "method_id": key[0],
                    "arm": key[1],
                    "namespace": cache.namespace,
                    "request_count": len(inventory["request_hashes"]),
                    "inventory_sha256": _sha(cache._path("request_inventory.json")),
                    "source_sha256": _sha(cache._path("response_source.json")),
                    "bundle_sha256": _sha(cache._path("cache_bundle.json")),
                    "missing": 0,
                    "unexpected": 0,
                    "duplicate": 0,
                    "passed": True,
                }
            )
        return {
            "schema_version": "exp09-c14-1-cache-qualification-v2",
            "artifact_status": "CACHE_QUALIFIED_FOR_OFFLINE_C14_1",
            "protocol_generation": PROTOCOL_GENERATION,
            "passed": True,
            "namespace_count": 4,
            "namespaces_sha256": _canonical_sha(namespaces),
            "namespaces": namespaces,
            "network_fallback": False,
            "formal_execution_authorized_by_user": True,
        }

    def audit_formal_inputs(self) -> Path:
        """Audit the immutable offline qualification without starting a method-case."""

        qualification_path = self.output_root / "cache_qualification.json"
        qualification = _strict_json(qualification_path)
        if qualification.get("passed") is not True:
            raise C14V2ClosureError("formal C14.1 requires cache qualification")
        if any(
            row.get("status") == "STARTED_NO_RESPONSE"
            for row in self.provider_ledger.rows
        ):
            raise C14V2ClosureError("formal C14.1 requires an inactive provider ledger")
        qualified_namespaces = qualification.get("namespaces")
        if (
            not isinstance(qualified_namespaces, list)
            or qualification.get("namespaces_sha256")
            != _canonical_sha(qualified_namespaces)
            or qualification.get("network_fallback") is not False
        ):
            raise C14V2ClosureError("formal C14.1 qualification integrity mismatch")
        current = []
        for method_id in METHODS:
            for arm in ARMS:
                cache = self.caches[(method_id, arm)]
                cache.qualification_cache()
                current.append(
                    {
                        "method_id": method_id,
                        "arm": arm,
                        "namespace": cache.namespace,
                        "request_count": len(cache.materializer.records),
                        "inventory_sha256": _sha(cache._path("request_inventory.json")),
                        "source_sha256": _sha(cache._path("response_source.json")),
                        "bundle_sha256": _sha(cache._path("cache_bundle.json")),
                        "missing": 0,
                        "unexpected": 0,
                        "duplicate": 0,
                        "passed": True,
                    }
                )
        if current != qualified_namespaces:
            raise C14V2ClosureError("formal C14.1 qualification binding drift")
        return qualification_path

    def run_formal(self) -> dict[str, Any]:
        qualification_path = self.audit_formal_inputs()
        formal_root = self.project_root / FORMAL_OUTPUT_LOCATOR
        formal_root.mkdir(parents=True, exist_ok=True)
        topology_sha = _sha(self.topology.source_path)
        ledger_path = formal_root / "run_ledger.json"
        if ledger_path.exists():
            ledger = C14RunLedger.load(
                ledger_path, self.topology, topology_sha256=topology_sha
            )
            running = [row for row in ledger.rows if row.status == "RUNNING"]
            for row in running:
                recover_running_checkpoint(
                    ledger,
                    formal_root / "checkpoint_journals",
                    row.run_id,
                )
                ledger.recover_interrupted(
                    row.run_id,
                    ended_at=_timestamp(),
                    abort_reason="recovered by authorized C14.1 v2 orchestrator",
                )
                ledger.plan_resume(row.case_id)
            _remediate_formal_budget_caps(ledger)
            ledger.write(ledger_path, execution_authorized=False)
        else:
            ledger = C14RunLedger(self.topology, topology_sha256=topology_sha)
            ledger.write(ledger_path, execution_authorized=False)
        runner = _CorrectedUnifiedRunner(
            self.project_root,
            self.topology,
            ledger,
            self.factory,
            output_root=formal_root / "runs",
            ledger_path=ledger_path,
            stop_event=Event(),
        )
        context = C14ExecutionContext(
            execution_authorized=True,
            cache_qualified=True,
            training_capability="DISABLED",
            api_allowed=False,
            provider_calls_allowed=False,
            llm_calls_allowed=False,
            shadow_allowed=False,
            precision_allowed=False,
            locked_test_allowed=False,
        )
        pending: list[C14MethodCase] = []
        for case in self.topology.cases:
            latest = [row for row in ledger.rows if row.case_id == case.case_id][-1]
            if latest.status == "PASSED":
                continue
            if latest.status in {"FAILED_RETAINED", "ABORTED_RETAINED"}:
                ledger.plan_resume(case.case_id)
            pending.append(case)
        ledger.write(ledger_path, execution_authorized=False)

        def execute(case: C14MethodCase) -> None:
            try:
                runner.execute_case(
                    case.case_id,
                    context=context,
                    corrected_caches=self.caches,
                    corrected_materializers=self.materializers,
                    started_at=_timestamp(),
                    ended_at=_timestamp(),
                )
            except BaseException:
                assert runner.stop_event is not None
                runner.stop_event.set()
                raise

        with ThreadPoolExecutor(
            max_workers=FORMAL_REMEDIATION_CONCURRENCY,
            thread_name_prefix="c14-formal-case",
        ) as executor:
            pending_iterator = iter(pending)
            futures = {
                executor.submit(execute, case)
                for case in (
                    next(pending_iterator, None)
                    for _ in range(FORMAL_REMEDIATION_CONCURRENCY)
                )
                if case is not None
            }
            while futures:
                done, futures = wait(futures, return_when=FIRST_COMPLETED)
                for future in done:
                    future.result()
                    if runner.stop_event is None or not runner.stop_event.is_set():
                        case = next(pending_iterator, None)
                        if case is not None:
                            futures.add(executor.submit(execute, case))
        return self._finalize_formal(ledger_path, qualification_path)

    def _finalize_formal(self, ledger_path: Path, qualification_path: Path) -> dict[str, Any]:
        ledger = C14RunLedger.load(
            ledger_path,
            self.topology,
            topology_sha256=_sha(self.topology.source_path),
        )
        latest = {
            case.case_id: [row for row in ledger.rows if row.case_id == case.case_id][-1]
            for case in self.topology.cases
        }
        passed = sum(row.status == "PASSED" for row in latest.values())
        failures = [asdict(row) for row in latest.values() if row.status != "PASSED"]
        report = {
            "schema_version": "exp09-c14-1-design-validation-completion-v1",
            "artifact_status": "C14_1_COMPLETE_STOP_BEFORE_LATER_STAGES" if passed == 2_304 else "FAIL_CLOSED",
            "protocol_generation": PROTOCOL_GENERATION,
            "passed": passed == 2_304 and not failures,
            "method_cases_planned": 2_304,
            "method_cases_passed": passed,
            "failure_count": len(failures),
            "failures_sha256": _canonical_sha(failures),
            "failures": failures,
            "budget_usage": asdict(ledger.accountant.usage),
            "bindings": {
                "run_ledger_sha256": _sha(ledger_path),
                "cache_qualification_sha256": _sha(qualification_path),
                "provider_cost_ledger_sha256": _sha(self.provider_ledger.path),
            },
            "training": False,
            "c14_2": False,
            "shadow": False,
            "precision": False,
            "locked_test": False,
            "performance_claim_allowed": False,
        }
        _atomic_write_json(
            self.project_root / FORMAL_OUTPUT_LOCATOR / "completion_report.json", report
        )
        return report

    def _write_phase_a_progress(
        self, path: Path, rows: list[dict[str, Any]], caps: dict[str, Any], attempt_ordinal: int
    ) -> None:
        historical_rows: list[dict[str, Any]] = []
        for ledger_path in sorted(self.output_root.glob("phase_a_case_ledger*.json")):
            if ledger_path == path:
                continue
            document = _strict_json(ledger_path)
            retained = document.get("rows")
            if not isinstance(retained, list) or document.get("rows_sha256") != _canonical_sha(retained):
                raise C14V2ClosureError(
                    f"Phase A progress ledger integrity mismatch: {ledger_path.name}"
                )
            historical_rows.extend(retained)
        accounted_rows = historical_rows + rows
        usage = {
            "frontier_cases": len({row["case_id"] for row in accounted_rows}),
            "decision_attempts": sum(row.get("decision_attempts", 0) for row in accounted_rows),
            "model_transitions": sum(row.get("model_transitions", 0) for row in accounted_rows),
            "pre_miss_controller_commitments": sum(
                row.get("pre_miss_controller_commitments", 0) for row in accounted_rows
            ),
            "cache_lookup_attempts": sum(
                row.get("cache_lookup_attempts", 0) for row in accounted_rows
            ),
            "cache_misses": sum(row.get("cache_misses", 0) for row in accounted_rows),
            "post_miss_controller_commitments": sum(
                row.get("post_miss_controller_commitments", 0) for row in accounted_rows
            ),
            "post_miss_plant_actions": sum(
                row.get("post_miss_plant_actions", 0) for row in accounted_rows
            ),
            "concurrency": caps["concurrency"] if rows else (1 if accounted_rows else 0),
            "api_calls": len(self.provider_ledger.rows),
            "provider_calls": len(self.provider_ledger.rows),
            "llm_tokens": self.provider_ledger.document()["usage"]["total_tokens"],
            "network_attempts": len(self.provider_ledger.rows),
        }
        for field in (
            "frontier_cases",
            "decision_attempts",
            "model_transitions",
            "pre_miss_controller_commitments",
            "post_miss_controller_commitments",
            "post_miss_plant_actions",
        ):
            if usage[field] > caps[field]:
                raise C14V2ClosureError(f"Phase A hard cap exceeded: {field}")
        runtime_caps = {
            **caps,
            "cache_misses": PROVIDER_CALL_CAP,
            "provider_calls": PROVIDER_CALL_CAP,
            "api_calls": PROVIDER_CALL_CAP,
            "network_attempts": PROVIDER_CALL_CAP,
        }
        for field in (
            "cache_lookup_attempts",
            "cache_misses",
            "provider_calls",
            "api_calls",
            "llm_tokens",
            "network_attempts",
        ):
            if usage[field] > runtime_caps[field]:
                raise C14V2ClosureError(f"Phase A hard cap exceeded: {field}")
        _atomic_write_json(path, {
            "schema_version": "exp09-c14-1-phase-a-runtime-ledger-v3",
            "protocol_generation": PROTOCOL_GENERATION,
            "attempt_ordinal": attempt_ordinal,
            "append_only": True,
            "budget_caps": runtime_caps,
            "budget_usage": usage,
            "rows_sha256": _canonical_sha(rows),
            "rows": rows,
        })

    def _load_phase_a_ledgers(self) -> list[dict[str, Any]]:
        paths = sorted(self.output_root.glob("phase_a_case_ledger*.json"))
        ordered_rows: list[tuple[int, int, int, dict[str, Any]]] = []
        for path_ordinal, path in enumerate(paths):
            document = _strict_json(path)
            loaded = document.get("rows")
            if not isinstance(loaded, list) or document.get("rows_sha256") != _canonical_sha(loaded):
                raise C14V2ClosureError(f"Phase A progress ledger integrity mismatch: {path.name}")
            for row_ordinal, row in enumerate(loaded):
                attempt = row.get("attempt_ordinal")
                if type(attempt) is not int or attempt < 0:
                    raise C14V2ClosureError(
                        f"Phase A row attempt ordinal mismatch: {path.name}"
                    )
                ordered_rows.append((attempt, path_ordinal, row_ordinal, row))
        ordered_rows.sort(key=lambda item: item[:3])
        return [item[3] for item in ordered_rows]

    def _next_phase_a_attempt_ordinal(self) -> int:
        ordinals = []
        for path in self.output_root.glob("phase_a_case_ledger_attempt_*.json"):
            match = re.search(r"attempt_(\d+)\.json$", path.name)
            if match:
                ordinals.append(int(match.group(1)))
        return (max(ordinals) + 1) if ordinals else 1

    def _write_blocker(
        self,
        code: str,
        exc: BaseException,
        *,
        phase_a_attempt_ordinal: int | None = None,
    ) -> None:
        ordinals = []
        for path in self.output_root.glob("FAIL_CLOSED_attempt_*.json"):
            match = re.fullmatch(r"FAIL_CLOSED_attempt_(\d+)\.json", path.name)
            if match:
                ordinals.append(int(match.group(1)))
        ordinal = (max(ordinals) + 1) if ordinals else 1
        _atomic_write_json(self.output_root / f"FAIL_CLOSED_attempt_{ordinal:04d}.json", {
            "schema_version": "exp09-c14-1-fail-closed-v1",
            "status": "FAIL_CLOSED",
            "code": code,
            "attempt_ordinal": ordinal,
            "phase_a_attempt_ordinal": phase_a_attempt_ordinal,
            "error_type": type(exc).__name__,
            "recorded_at": _timestamp(),
            "provider_calls": len(self.provider_ledger.rows),
            "training": False,
            "later_stages": False,
        })


def _phase_a_row_is_complete(row: dict[str, Any]) -> bool:
    decisions = row.get("decision_attempts")
    commitments = row.get("pre_miss_controller_commitments")
    return (
        row.get("status") in {"PASSED", "NO_FRONTIER_COMPLETE"}
        and row.get("causal_scope") == FULL_TAPE_CAUSAL_SCOPE
        and type(decisions) is int
        and 0 <= decisions <= FULL_TAPE_MAX_CONTROL_OPPORTUNITIES_PER_CASE
        and commitments == decisions
        and row.get("post_miss_controller_commitments") == 0
        and row.get("post_miss_plant_actions") == 0
    )


class _CorrectedUnifiedRunner(C14UnifiedRunner):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._formal_bindings_lock = RLock()
        self._corrected_caches: dict[tuple[str, str], ClosureCache] = {}
        self._corrected_materializers: dict[
            tuple[str, str], ProtocolGenerationRequestMaterializer
        ] = {}

    def execute_case(
        self,
        case_id: str,
        *,
        context: C14ExecutionContext,
        corrected_caches: dict[tuple[str, str], ClosureCache],
        corrected_materializers: dict[tuple[str, str], ProtocolGenerationRequestMaterializer],
        started_at: str,
        ended_at: str,
    ) -> Any:
        with self._formal_bindings_lock:
            if self._corrected_caches and self._corrected_caches is not corrected_caches:
                raise C14V2ClosureError("formal cache binding changed during execution")
            if (
                self._corrected_materializers
                and self._corrected_materializers is not corrected_materializers
            ):
                raise C14V2ClosureError(
                    "formal materializer binding changed during execution"
                )
            self._corrected_caches = corrected_caches
            self._corrected_materializers = corrected_materializers
        return super().execute_case(
            case_id,
            context=context,
            started_at=started_at,
            ended_at=ended_at,
        )

    def _output_root_for_case(self, case_id: str) -> Path:
        return self.output_root / case_id

    def _controller_for(self, case: C14MethodCase, **kwargs: Any) -> Any:
        del kwargs
        if case.method_id in METHODS:
            key = (case.method_id, case.arm)
            closure = self._corrected_caches[key]
            inventory = closure.inventory_document()
            bundle = closure.bundle_document(inventory)
            audit_cache_documents(inventory, bundle)
            qualified = QualifiedReplayCache(closure)
            template = self._corrected_materializers[key]
            materializer = V3RequestMaterializer(
                method_id=template.method_id,
                arm=template.arm,
                base_namespace=template.namespace.rsplit("--", 1)[0],
                method_config_sha256=template.method_config_sha256,
                prompt_protocol_sha256=template.prompt_protocol_sha256,
                provider_config_sha256=template.provider_config_sha256,
            )
            return build_protocol_generation_controller(
                self.controller_factory,
                case.method_id,
                cache=qualified,
                materializer=materializer,
            )
        return super()._controller_for(
            case,
            full_cache=None,
            plain_cache=None,
            full_materializer=None,
            plain_materializer=None,
        )


def run_all(project_root: Path, credential_path: Path) -> dict[str, Any]:
    orchestrator = C14V2ClosureOrchestrator(project_root, credential_path)
    orchestrator.run_cache_closure()
    return orchestrator.run_formal()


def run_structured_provider_preflight(
    project_root: Path, credential_path: Path
) -> dict[str, Any]:
    """Exercise the production Plain_LLM request shape with synthetic payload only."""

    root = Path(project_root).resolve()
    output_root = root / OUTPUT_LOCATOR
    output_root.mkdir(parents=True, exist_ok=True)
    credentials = load_provider_credentials(credential_path, profile="primary")
    provider_config_path = root / PROVIDER_CONFIG_LOCATOR
    provider_config_sha = _sha(provider_config_path)
    provider_config = _strict_json(provider_config_path)
    if (
        provider_config.get("model_identifier") != PROVIDER_MODEL_IDENTIFIER
        or provider_config.get("model_revision") != PROVIDER_MODEL_REVISION
    ):
        raise C14V2ClosureError("structured preflight provider binding mismatch")
    from urllib.parse import urlparse

    host = urlparse(credentials.base_url).hostname
    if not host:
        raise C14V2ClosureError("structured preflight endpoint host is unavailable")
    ledger = ProviderLedger(
        output_root / "provider_cost_ledger.json",
        provider_config_sha256=provider_config_sha,
        endpoint_host=host,
    )
    method_config = _strict_json(root / METHOD_CONFIG_LOCATOR)
    method = method_config["methods"]["Plain_LLM"]
    protocol = _strict_json(root / method["prompt_protocol_locator"])
    model_payload = {
        "schema_version": "exp09-c14-1-plain-llm-input-v1",
        "instruction": (
            "Rank every eligible action once; chosen_action_id must equal "
            "candidate_order[0]."
        ),
        "observation": {
            "causal_cutoff_us": 0,
            "counters": [],
            "current_rri_us": 1000000,
            "missing_reasons": [],
            "observed_user_ages": [],
            "observed_users": [],
            "removals": [],
            "source_sequence": 0,
        },
        "eligible_actions": [f"SYNTHETIC_ACTION_{ordinal:02d}" for ordinal in range(8)],
    }
    request_hash = _canonical_sha(
        {
            "schema_version": "exp09-c14-1-structured-provider-preflight-request-v1",
            "provider_config_sha256": provider_config_sha,
            "prompt_protocol_sha256": method["prompt_protocol_sha256"],
            "model_payload": model_payload,
        }
    )
    ordinal = len(list(output_root.glob("structured_provider_preflight_attempt_*.json"))) + 1
    path = output_root / f"structured_provider_preflight_attempt_{ordinal:04d}.json"
    session = ProviderSession(
        method_id="Plain_LLM",
        arm="REFERENCE",
        credentials=credentials,
        protocol=protocol,
        ledger=ledger,
        purpose="STRUCTURED_PREFLIGHT",
    )
    try:
        result = session.generate(request_hash=request_hash, model_payload=model_payload)
    except BaseException as exc:
        row = ledger.rows[-1] if ledger.rows else {}
        document = {
            "schema_version": "exp09-c14-1-structured-provider-preflight-v1",
            "status": "FAIL_CLOSED",
            "passed": False,
            "protocol_generation": PROTOCOL_GENERATION,
            "attempt_ordinal": ordinal,
            "model_identifier": PROVIDER_MODEL_IDENTIFIER,
            "model_revision": PROVIDER_MODEL_REVISION,
            "provider_config_sha256": provider_config_sha,
            "prompt_protocol_sha256": method["prompt_protocol_sha256"],
            "request_hash": request_hash,
            "model_payload_sha256": _canonical_sha(model_payload),
            "provider_call_id": row.get("call_id"),
            "error_type": type(exc).__name__,
            "http_status": row.get("http_status"),
            "response_body_sha256": row.get("response_body_sha256"),
            "provider_error_code": row.get("provider_error_code"),
            "api_key_recorded": False,
            "real_method_case": False,
            "training": False,
            "later_stages": False,
        }
        _atomic_write_json(path, document)
        raise
    row = ledger.rows[-1]
    document = {
        "schema_version": "exp09-c14-1-structured-provider-preflight-v1",
        "status": "PASSED_AUDITED",
        "passed": True,
        "protocol_generation": PROTOCOL_GENERATION,
        "attempt_ordinal": ordinal,
        "model_identifier": PROVIDER_MODEL_IDENTIFIER,
        "model_revision": PROVIDER_MODEL_REVISION,
        "provider_model_returned": result.raw_response.get("model"),
        "provider_config_sha256": provider_config_sha,
        "prompt_protocol_sha256": method["prompt_protocol_sha256"],
        "request_hash": request_hash,
        "model_payload_sha256": _canonical_sha(model_payload),
        "provider_call_id": row["call_id"],
        "response_binding_sha256": _canonical_sha(
            {"request_hash": request_hash, "response": result.parsed_response}
        ),
        "input_tokens": result.usage.input_tokens,
        "output_tokens": result.usage.output_tokens,
        "total_tokens": result.usage.total_tokens,
        "estimated_cost_usd": row["estimated_cost_usd"],
        "wall_ms": result.wall_ms,
        "api_key_recorded": False,
        "real_method_case": False,
        "training": False,
        "later_stages": False,
    }
    document["artifact_sha256"] = _canonical_sha(document)
    _atomic_write_json(path, document)
    return document


def run_provider_preflight(credential_path: Path) -> dict[str, Any]:
    """Make one stateless model probe without project or experiment payloads."""

    credentials = load_provider_credentials(credential_path, profile="primary")
    body = {
        "model": PROVIDER_MODEL_IDENTIFIER,
        "messages": [{"role": "user", "content": "Reply exactly OK"}],
        "temperature": 0,
        "reasoning_effort": "none",
        "max_tokens": 8,
    }
    request = Request(
        f"{credentials.base_url}/chat/completions",
        data=_canonical_bytes(body),
        headers={
            "Authorization": f"Bearer {credentials.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "exp09-c14-offline-cache/3.0",
        },
        method="POST",
    )
    try:
        with urlopen(request, timeout=TIMEOUT_SECONDS) as response:
            raw = json.loads(response.read().decode("utf-8"))
        choice = raw["choices"][0]
        content = choice["message"]["content"].strip()
        usage = raw.get("usage", {})
    except (HTTPError, URLError, TimeoutError, OSError, KeyError, ValueError) as exc:
        raise C14V2ClosureError(
            f"gpt-5.4-mini provider preflight failed without retry: {type(exc).__name__}"
        ) from exc
    if content != "OK" or choice.get("finish_reason") != "stop":
        raise C14V2ClosureError("gpt-5.4-mini provider preflight response audit failed")
    return {
        "passed": True,
        "model_requested": PROVIDER_MODEL_IDENTIFIER,
        "model_returned": raw.get("model"),
        "input_tokens": usage.get("prompt_tokens", 0),
        "output_tokens": usage.get("completion_tokens", 0),
        "api_key_recorded": False,
    }


def _reject_identity_fields(value: Any) -> None:
    forbidden = {
        "root_case_id",
        "run_id",
        "arm",
        "scenario",
        "shock_flag",
        "shock_label",
        "plant_truth",
        "future_tape",
        "test_identity",
        "method_id",
        "method_ranking",
    }
    if isinstance(value, dict):
        overlap = forbidden & set(value)
        if overlap:
            raise C14V2ClosureError(f"model-visible payload contains forbidden identity fields: {sorted(overlap)}")
        for child in value.values():
            _reject_identity_fields(child)
    elif isinstance(value, list):
        for child in value:
            _reject_identity_fields(child)


def _estimated_cost(input_tokens: int, output_tokens: int) -> float:
    return round(input_tokens * 0.75 / 1_000_000 + output_tokens * 4.50 / 1_000_000, 9)


def _strict_nonnegative_int(value: Any) -> int:
    if type(value) is not int or value < 0:
        raise ValueError("expected a non-negative integer")
    return value


def _strict_json(path: Path) -> dict[str, Any]:
    def pairs(values: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in values:
            if key in result:
                raise C14V2ClosureError(f"duplicate JSON key: {key}")
            result[key] = value
        return result

    try:
        value = json.loads(
            Path(path).read_text(encoding="utf-8"),
            object_pairs_hook=pairs,
            parse_constant=lambda item: (_ for _ in ()).throw(
                C14V2ClosureError(f"non-finite JSON value: {item}")
            ),
        )
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise C14V2ClosureError(f"strict JSON read failed: {path.name}") from exc
    if not isinstance(value, dict):
        raise C14V2ClosureError("artifact must be a JSON object")
    return value


def _canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")


def _canonical_text(value: Any) -> str:
    return _canonical_bytes(value).decode("utf-8")


def _canonical_sha(value: Any) -> str:
    return hashlib.sha256(_canonical_bytes(value)).hexdigest().upper()


def _sha(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest().upper()


def _atomic_write_json(path: Path, value: dict[str, Any]) -> str:
    payload = _canonical_bytes(value)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    for attempt in range(ATOMIC_REPLACE_ATTEMPTS):
        temporary = path.with_name(f"{path.name}.tmp-{uuid4().hex}")
        try:
            with temporary.open("xb") as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
            return hashlib.sha256(payload).hexdigest().upper()
        except PermissionError:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass
            if attempt + 1 == ATOMIC_REPLACE_ATTEMPTS:
                raise
            time.sleep(ATOMIC_REPLACE_BASE_DELAY_SECONDS * (attempt + 1))
        except BaseException:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass
            raise
    raise AssertionError("atomic JSON write retry loop exited unexpectedly")


def _timestamp() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="microseconds")
