"""Lossless content-addressed artifacts for C14.1 formal runs."""

from __future__ import annotations

from dataclasses import dataclass
import gzip
import json
import os
from pathlib import Path
from threading import RLock
from typing import Callable
from uuid import uuid4

from exp09.artifacts.canonical import canonical_json_bytes

from .disturbance_tape import validate_primary_tape
from .metrics_accumulator import CASE_METRICS_SCHEMA_VERSION, CaseMetrics
from .raw_writer import (
    _canonical_mapping_bytes,
    _canonical_raw_hash,
    _canonical_tape_hash,
    _case_name,
    _decode_value,
    _load_json_bytes,
    _sha256_bytes,
)
from .runner import (
    RAW_RUN_TRACE_SCHEMA_VERSION,
    RUN_RESULT_SCHEMA_VERSION,
    RawRunTrace,
    RunResult,
    rebuild_metrics,
)

CAS_MANIFEST_SCHEMA_VERSION = "exp09-c14-1-cas-manifest-v1"
CAS_COMPLETE_SCHEMA_VERSION = "exp09-c14-1-cas-complete-v1"
CAS_COMPRESSION = "gzip-level-9-mtime-0"
_CASE_FILES = frozenset({"cas_manifest.json", "COMPLETE"})
_BLOB_NAMES = ("raw_run.json", "metrics_case.json")
_MANIFEST_FIELDS = frozenset(
    {
        "schema_version",
        "result_schema_version",
        "raw_schema_version",
        "metrics_schema_version",
        "root_case_id",
        "arm",
        "protocol_generation",
        "tape_id",
        "config_hash",
        "tape_canonical_sha256",
        "result_integrity_hash",
        "blobs",
    }
)
_COMPLETE_FIELDS = frozenset(
    {"schema_version", "manifest_sha256", "result_integrity_hash"}
)
_BLOB_FIELDS = frozenset(
    {
        "logical_name",
        "compression",
        "canonical_sha256",
        "canonical_size_bytes",
        "compressed_sha256",
        "compressed_size_bytes",
        "locator",
    }
)
_CAS_WRITE_LOCK = RLock()


@dataclass(frozen=True, slots=True)
class C14CasRunArtifact:
    path: Path
    integrity_hash: str
    storage_bytes_added: int


class C14CasWriteError(RuntimeError):
    def __init__(self, message: str, *, storage_bytes_added: int) -> None:
        super().__init__(message)
        self.storage_bytes_added = storage_bytes_added


def persisted_c14_storage_bytes(runs_root: Path, cas_root: Path) -> int:
    """Count regular persisted artifact bytes in the frozen C14.1 storage scope."""

    total = 0
    for root in (Path(runs_root), Path(cas_root)):
        if not root.exists():
            continue
        for path in root.rglob("*"):
            if path.is_file() and not path.is_symlink():
                total += path.stat().st_size
    return total


def write_c14_cas_run(
    result: RunResult,
    output_root: Path,
    *,
    runs_root: Path,
    cas_root: Path,
    expected_existing_storage_bytes: int,
    ensure_storage_budget: Callable[[int], None],
) -> C14CasRunArtifact:
    """Publish one verified run using deterministic gzip blobs and CAS references."""

    with _CAS_WRITE_LOCK:
        existing = persisted_c14_storage_bytes(runs_root, cas_root)
        if existing != expected_existing_storage_bytes:
            raise C14CasWriteError(
                "persisted C14.1 storage and formal ledger disagree",
                storage_bytes_added=0,
            )
        prepared = prepare_c14_cas_run(
            result,
            output_root,
            runs_root=runs_root,
            cas_root=cas_root,
        )
        return publish_prepared_c14_cas_run(
            prepared,
            runs_root=runs_root,
            cas_root=cas_root,
            expected_existing_storage_bytes=expected_existing_storage_bytes,
            ensure_storage_budget=ensure_storage_budget,
        )


@dataclass(frozen=True, slots=True)
class PreparedC14CasRun:
    result: RunResult
    output_root: Path
    payloads: dict[str, bytes]
    blobs: dict[str, dict[str, object]]
    manifest_bytes: bytes
    complete_bytes: bytes
    final_path: Path


def prepare_c14_cas_run(
    result: RunResult,
    output_root: Path,
    *,
    runs_root: Path,
    cas_root: Path,
 ) -> PreparedC14CasRun:
    """Build and validate compressed CAS payloads without publishing shared state."""

    _validate_result(result)
    output_root = Path(output_root)
    runs_root = Path(runs_root)
    cas_root = Path(cas_root)
    raw_payload = canonical_json_bytes(
        result.raw_trace,
        expected_schema_version=RAW_RUN_TRACE_SCHEMA_VERSION,
    )
    metrics_payload = canonical_json_bytes(
        result.metrics,
        expected_schema_version=CASE_METRICS_SCHEMA_VERSION,
    )
    payloads = {
        "raw_run.json": raw_payload,
        "metrics_case.json": metrics_payload,
    }
    blobs = {
        name: _blob_record(name, payload, cas_root=cas_root, runs_root=runs_root)
        for name, payload in payloads.items()
    }
    manifest_bytes = _manifest_bytes(result, blobs)
    complete_bytes = _complete_bytes(result.integrity_hash, manifest_bytes)
    final_path = output_root / _case_name(
        result.root_case_id, result.arm, result.integrity_hash
    )
    return PreparedC14CasRun(
        result=result,
        output_root=output_root,
        payloads=payloads,
        blobs=blobs,
        manifest_bytes=manifest_bytes,
        complete_bytes=complete_bytes,
        final_path=final_path,
    )


def publish_prepared_c14_cas_run(
    prepared: PreparedC14CasRun,
    *,
    runs_root: Path,
    cas_root: Path,
    expected_existing_storage_bytes: int,
    ensure_storage_budget: Callable[[int], None],
) -> C14CasRunArtifact:
    """Publish one prepared run while holding the process-wide CAS lock."""

    with _CAS_WRITE_LOCK:
        runs_root = Path(runs_root)
        cas_root = Path(cas_root)
        existing = persisted_c14_storage_bytes(runs_root, cas_root)
        if existing != expected_existing_storage_bytes:
            raise C14CasWriteError(
                "persisted C14.1 storage and formal ledger disagree",
                storage_bytes_added=0,
            )
        if prepared.final_path.exists():
            verified = verify_c14_cas_run(
                prepared.final_path,
                runs_root=runs_root,
                cas_root=cas_root,
            )
            if verified.integrity_hash != prepared.result.integrity_hash:
                raise C14CasWriteError(
                    "existing C14.1 CAS artifact has a different result hash",
                    storage_bytes_added=0,
                )
            return C14CasRunArtifact(
                prepared.final_path, prepared.result.integrity_hash, 0
            )
        return _publish_prepared_locked(
            prepared,
            runs_root=runs_root,
            cas_root=cas_root,
            existing=existing,
            ensure_storage_budget=ensure_storage_budget,
        )


def _publish_prepared_locked(
    prepared: PreparedC14CasRun,
    *,
    runs_root: Path,
    cas_root: Path,
    existing: int,
    ensure_storage_budget: Callable[[int], None],
) -> C14CasRunArtifact:
    result = prepared.result
    payloads = prepared.payloads
    blobs = prepared.blobs
    manifest_bytes = prepared.manifest_bytes
    complete_bytes = prepared.complete_bytes
    output_root = prepared.output_root
    final_path = prepared.final_path

    new_blob_bytes = sum(
        record["compressed_size_bytes"]
        for record in blobs.values()
        if not (runs_root.parent / record["locator"]).exists()
    )
    projected_delta = new_blob_bytes + len(manifest_bytes) + len(complete_bytes)
    ensure_storage_budget(projected_delta)

    temporary_path = output_root / f".{final_path.name}.tmp-{uuid4().hex}"
    try:
        output_root.mkdir(parents=True, exist_ok=True)
        cas_root.mkdir(parents=True, exist_ok=True)
        for name, payload in payloads.items():
            _publish_blob(payload, blobs[name], formal_root=runs_root.parent)
        temporary_path.mkdir()
        _write_bytes(temporary_path / "cas_manifest.json", manifest_bytes)
        _write_bytes(temporary_path / "COMPLETE", complete_bytes)
        os.replace(temporary_path, final_path)
        verified = verify_c14_cas_run(
            final_path,
            runs_root=runs_root,
            cas_root=cas_root,
        )
        if verified.integrity_hash != result.integrity_hash:
            raise RuntimeError("published C14.1 CAS result hash mismatch")
        actual_delta = persisted_c14_storage_bytes(runs_root, cas_root) - existing
        if actual_delta != projected_delta:
            raise RuntimeError("C14.1 CAS persisted-byte delta mismatch")
        return C14CasRunArtifact(final_path, result.integrity_hash, actual_delta)
    except BaseException as exc:
        if temporary_path.exists():
            quarantine = output_root / "quarantine"
            quarantine.mkdir(parents=True, exist_ok=True)
            os.replace(temporary_path, quarantine / temporary_path.name)
        actual_delta = max(
            0, persisted_c14_storage_bytes(runs_root, cas_root) - existing
        )
        raise C14CasWriteError(
            f"C14.1 CAS publication failed: {type(exc).__name__}",
            storage_bytes_added=actual_delta,
        ) from exc


def verify_c14_cas_run(
    path: Path,
    *,
    runs_root: Path,
    cas_root: Path,
) -> C14CasRunArtifact:
    path = Path(path)
    runs_root = Path(runs_root).resolve()
    cas_root = Path(cas_root).resolve()
    if (
        not path.is_dir()
        or path.is_symlink()
        or path.name == "quarantine"
        or path.name.startswith(".")
        or {item.name for item in path.iterdir()} != _CASE_FILES
        or any(item.is_symlink() or not item.is_file() for item in path.iterdir())
    ):
        raise ValueError("C14.1 CAS run directory is incomplete or invalid")

    manifest_bytes = (path / "cas_manifest.json").read_bytes()
    complete_bytes = (path / "COMPLETE").read_bytes()
    manifest = _canonical_object(manifest_bytes, "cas_manifest.json")
    complete = _canonical_object(complete_bytes, "COMPLETE")
    if (
        set(manifest) != _MANIFEST_FIELDS
        or set(complete) != _COMPLETE_FIELDS
        or
        manifest.get("schema_version") != CAS_MANIFEST_SCHEMA_VERSION
        or complete.get("schema_version") != CAS_COMPLETE_SCHEMA_VERSION
        or complete.get("manifest_sha256") != _sha256_bytes(manifest_bytes)
        or complete.get("result_integrity_hash")
        != manifest.get("result_integrity_hash")
    ):
        raise ValueError("C14.1 CAS completion binding mismatch")
    blobs = manifest.get("blobs")
    if not isinstance(blobs, dict) or set(blobs) != set(_BLOB_NAMES):
        raise ValueError("C14.1 CAS blob map mismatch")

    payloads: dict[str, bytes] = {}
    for name in _BLOB_NAMES:
        record = blobs[name]
        if (
            not isinstance(record, dict)
            or set(record) != _BLOB_FIELDS
            or record.get("logical_name") != name
            or record.get("compression") != CAS_COMPRESSION
            or type(record.get("canonical_size_bytes")) is not int
            or type(record.get("compressed_size_bytes")) is not int
        ):
            raise ValueError("C14.1 CAS blob record mismatch")
        blob_path = (runs_root.parent / record["locator"]).resolve()
        if not blob_path.is_relative_to(cas_root) or not blob_path.is_file():
            raise ValueError("C14.1 CAS blob locator escapes or is missing")
        compressed = blob_path.read_bytes()
        if (
            len(compressed) != record.get("compressed_size_bytes")
            or _sha256_bytes(compressed) != record.get("compressed_sha256")
        ):
            raise ValueError("C14.1 CAS compressed blob integrity mismatch")
        try:
            payload = gzip.decompress(compressed)
        except (OSError, EOFError) as exc:
            raise ValueError("C14.1 CAS blob is not valid gzip") from exc
        if (
            len(payload) != record.get("canonical_size_bytes")
            or _sha256_bytes(payload) != record.get("canonical_sha256")
        ):
            raise ValueError("C14.1 CAS canonical blob integrity mismatch")
        payloads[name] = payload

    raw = _decode_raw(payloads["raw_run.json"])
    metrics = _decode_metrics(payloads["metrics_case.json"])
    if rebuild_metrics(raw) != metrics:
        raise ValueError("C14.1 CAS metrics do not agree with the raw trace")
    result_hash = _canonical_raw_hash(raw)
    if (
        result_hash != manifest.get("result_integrity_hash")
        or manifest.get("root_case_id") != str(raw.tape.root_case_id)
        or manifest.get("arm") != raw.tape.arm.value
        or manifest.get("tape_canonical_sha256") != _canonical_tape_hash(raw.tape)
        or path.name != _case_name(str(raw.tape.root_case_id), raw.tape.arm, result_hash)
    ):
        raise ValueError("C14.1 CAS identity binding mismatch")
    return C14CasRunArtifact(path, result_hash, 0)


def _validate_result(result: RunResult) -> None:
    rebuilt = rebuild_metrics(result.raw_trace)
    if (
        result.schema_version != RUN_RESULT_SCHEMA_VERSION
        or result.raw_trace.schema_version != RAW_RUN_TRACE_SCHEMA_VERSION
        or result.metrics != rebuilt
        or result.root_case_id != str(result.raw_trace.tape.root_case_id)
        or result.arm is not result.raw_trace.tape.arm
        or result.tx_attempts != rebuilt.tx_attempts
        or result.observable_frame_count != len(result.raw_trace.summary_deliveries)
        or result.integrity_hash != _canonical_raw_hash(result.raw_trace)
    ):
        raise ValueError("C14.1 result does not agree with its complete raw trace")


def _blob_record(
    name: str,
    payload: bytes,
    *,
    cas_root: Path,
    runs_root: Path,
) -> dict[str, object]:
    canonical_sha = _sha256_bytes(payload)
    compressed = gzip.compress(payload, compresslevel=9, mtime=0)
    blob_path = cas_root / canonical_sha[:2] / f"{canonical_sha}.json.gz"
    return {
        "logical_name": name,
        "compression": CAS_COMPRESSION,
        "canonical_sha256": canonical_sha,
        "canonical_size_bytes": len(payload),
        "compressed_sha256": _sha256_bytes(compressed),
        "compressed_size_bytes": len(compressed),
        "locator": blob_path.resolve().relative_to(runs_root.parent.resolve()).as_posix(),
    }


def _publish_blob(payload: bytes, record: dict[str, object], *, formal_root: Path) -> None:
    compressed = gzip.compress(payload, compresslevel=9, mtime=0)
    path = Path(formal_root) / str(record["locator"])
    if path.exists():
        if path.read_bytes() != compressed:
            raise ValueError("existing C14.1 CAS blob differs from canonical compression")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{uuid4().hex}")
    try:
        _write_bytes(temporary, compressed)
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def _manifest_bytes(result: RunResult, blobs: dict[str, dict]) -> bytes:
    return _canonical_mapping_bytes(
        {
            "schema_version": CAS_MANIFEST_SCHEMA_VERSION,
            "result_schema_version": result.schema_version,
            "raw_schema_version": result.raw_trace.schema_version,
            "metrics_schema_version": result.metrics.schema_version,
            "root_case_id": result.root_case_id,
            "arm": result.arm.value,
            "protocol_generation": result.raw_trace.tape.protocol_generation,
            "tape_id": str(result.raw_trace.tape.tape_id),
            "config_hash": result.raw_trace.tape.config_hash,
            "tape_canonical_sha256": _canonical_tape_hash(result.raw_trace.tape),
            "result_integrity_hash": result.integrity_hash,
            "blobs": blobs,
        }
    )


def _complete_bytes(result_hash: str, manifest_bytes: bytes) -> bytes:
    return _canonical_mapping_bytes(
        {
            "schema_version": CAS_COMPLETE_SCHEMA_VERSION,
            "manifest_sha256": _sha256_bytes(manifest_bytes),
            "result_integrity_hash": result_hash,
        }
    )


def _decode_raw(payload: bytes) -> RawRunTrace:
    value = _canonical_object(payload, "raw_run.json")
    raw = _decode_value(value, RawRunTrace, "raw_run")
    validate_primary_tape(raw.tape)
    if payload != canonical_json_bytes(
        raw, expected_schema_version=RAW_RUN_TRACE_SCHEMA_VERSION
    ):
        raise ValueError("C14.1 CAS raw trace is not canonical")
    return raw


def _decode_metrics(payload: bytes) -> CaseMetrics:
    value = _canonical_object(payload, "metrics_case.json")
    metrics = _decode_value(value, CaseMetrics, "metrics_case")
    if payload != canonical_json_bytes(
        metrics, expected_schema_version=CASE_METRICS_SCHEMA_VERSION
    ):
        raise ValueError("C14.1 CAS metrics are not canonical")
    return metrics


def _canonical_object(payload: bytes, name: str) -> dict:
    value = _load_json_bytes(payload, name)
    if not isinstance(value, dict):
        raise ValueError(f"C14.1 CAS artifact is not an object: {name}")
    canonical = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    if canonical != payload:
        raise ValueError(f"C14.1 CAS artifact is not canonical JSON: {name}")
    return value


def _write_bytes(path: Path, payload: bytes) -> None:
    with path.open("xb") as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
