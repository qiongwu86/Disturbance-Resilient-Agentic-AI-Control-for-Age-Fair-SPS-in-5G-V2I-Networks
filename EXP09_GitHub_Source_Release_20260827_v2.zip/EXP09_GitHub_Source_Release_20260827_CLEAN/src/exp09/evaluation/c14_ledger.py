"""Append-preserving run ledger and hard-budget accounting for C14.1."""

from __future__ import annotations

from dataclasses import asdict, dataclass, replace
import hashlib
import json
import os
from pathlib import Path
from threading import RLock
import time
from typing import Any
from uuid import uuid4

from .c14_topology import C14MethodCase, C14MethodCaseTopology

LEDGER_SCHEMA_VERSION = "exp09-c14-1-run-ledger-v1"
LEDGER_ROW_SCHEMA_VERSION = "exp09-c14-1-run-ledger-row-v2"
ALLOWED_STATUS = frozenset(
    {"PLANNED", "RUNNING", "PASSED", "FAILED_RETAINED", "ABORTED_RETAINED"}
)
TERMINAL_STATUS = frozenset({"PASSED", "FAILED_RETAINED", "ABORTED_RETAINED"})
ATOMIC_WRITE_ATTEMPTS = 20
ATOMIC_WRITE_BASE_DELAY_SECONDS = 0.025


class C14LedgerError(ValueError):
    """Raised when ledger state, resume history, or budget accounting is invalid."""


class C14BudgetExceeded(C14LedgerError):
    """Raised before a hard budget cap could be exceeded."""


@dataclass(frozen=True, slots=True)
class C14BudgetCaps:
    method_cases: int = 2_304
    environment_steps: int = 5_760_000
    model_transitions: int = 103_680_000_000
    cpu_core_seconds: int = 518_400
    wall_seconds: int = 345_600
    storage_bytes: int = 16_106_127_360
    concurrency: int = 8
    gpu_seconds: int = 0
    api_calls: int = 0
    provider_calls: int = 0
    llm_tokens: int = 0


@dataclass(frozen=True, slots=True)
class C14BudgetUsage:
    method_cases: int = 0
    environment_steps: int = 0
    model_transitions: int = 0
    cpu_core_seconds: int = 0
    wall_seconds: int = 0
    storage_bytes: int = 0
    concurrency: int = 0
    gpu_seconds: int = 0
    api_calls: int = 0
    provider_calls: int = 0
    llm_tokens: int = 0

    def plus(self, other: C14BudgetUsage) -> C14BudgetUsage:
        return C14BudgetUsage(
            **{
                field: getattr(self, field) + getattr(other, field)
                for field in self.__dataclass_fields__
            }
        )


class C14BudgetAccountant:
    def __init__(self, caps: C14BudgetCaps | None = None) -> None:
        self.caps = caps or C14BudgetCaps()
        self.usage = C14BudgetUsage()
        self._lock = RLock()

    def ensure_can_charge(self, delta: C14BudgetUsage) -> C14BudgetUsage:
        with self._lock:
            candidate = self.usage.plus(delta)
            for field in candidate.__dataclass_fields__:
                value = getattr(candidate, field)
                cap = getattr(self.caps, field)
                if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                    raise C14LedgerError(
                        f"budget usage {field} must be a non-negative integer"
                    )
                if value > cap:
                    raise C14BudgetExceeded(f"C14.1 hard budget exceeded: {field}")
            return candidate

    def charge(self, delta: C14BudgetUsage) -> C14BudgetUsage:
        with self._lock:
            candidate = self.ensure_can_charge(delta)
            self.usage = candidate
            return self.usage

    def enter_single_job(self) -> None:
        with self._lock:
            if self.usage.concurrency >= self.caps.concurrency:
                raise C14BudgetExceeded("C14.1 concurrency hard cap reached")
            self.charge(C14BudgetUsage(concurrency=1))

    def exit_single_job(self) -> None:
        with self._lock:
            if self.usage.concurrency <= 0:
                raise C14LedgerError("C14.1 job concurrency accounting is inconsistent")
            self.usage = replace(
                self.usage, concurrency=self.usage.concurrency - 1
            )


@dataclass(frozen=True, slots=True)
class C14LedgerRow:
    schema_version: str
    run_id: str
    case_id: str
    attempt_ordinal: int
    phase: str
    root_family: str
    root_namespace: str
    arm: str
    scenario: str
    method_id: str
    variant_id: str
    train_seed: int | None
    config_sha256: str
    checkpoint_sha256: str | None
    topology_sha256: str
    status: str
    started_at: str | None
    ended_at: str | None
    environment_steps: int
    model_transitions: int
    api_calls: int
    provider_calls: int
    llm_tokens: int
    cpu_core_seconds: int
    gpu_seconds: int
    wall_seconds: int
    storage_bytes: int
    error_code: str | None
    artifact_sha256: str | None
    resume_of: str | None
    abort_reason: str | None

    def validate(self) -> None:
        if self.schema_version != LEDGER_ROW_SCHEMA_VERSION:
            raise C14LedgerError("unsupported C14.1 ledger row schema")
        if self.status not in ALLOWED_STATUS:
            raise C14LedgerError("unsupported C14.1 ledger status")
        if self.api_calls != 0 or self.provider_calls != 0 or self.llm_tokens != 0:
            raise C14LedgerError("C14.1 ledger records forbidden online consumption")
        if self.gpu_seconds != 0:
            raise C14LedgerError("C14.1 ledger records forbidden GPU consumption")
        for field_name in (
            "attempt_ordinal",
            "environment_steps",
            "model_transitions",
            "cpu_core_seconds",
            "wall_seconds",
            "storage_bytes",
        ):
            value = getattr(self, field_name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise C14LedgerError(f"ledger field {field_name} must be non-negative")
        if self.status == "PLANNED" and any(
            value is not None
            for value in (self.started_at, self.ended_at, self.error_code, self.artifact_sha256)
        ):
            raise C14LedgerError("planned ledger row contains execution evidence")
        if self.status == "RUNNING" and (self.started_at is None or self.ended_at is not None):
            raise C14LedgerError("running ledger row timestamps are invalid")
        if self.status in TERMINAL_STATUS and (
            self.started_at is None or self.ended_at is None
        ):
            raise C14LedgerError("terminal ledger row timestamps are incomplete")
        if self.status == "PASSED" and (
            self.artifact_sha256 is None
            or self.error_code is not None
            or self.abort_reason is not None
        ):
            raise C14LedgerError("passed ledger row is incomplete")
        if self.status in {"FAILED_RETAINED", "ABORTED_RETAINED"} and not (
            self.error_code and self.abort_reason
        ):
            raise C14LedgerError("failed/aborted ledger row lacks retained reason evidence")


class C14RunLedger:
    """Hold the frozen plan and append retained resume attempts without deletion."""

    def __init__(
        self,
        topology: C14MethodCaseTopology,
        *,
        topology_sha256: str,
        accountant: C14BudgetAccountant | None = None,
    ) -> None:
        self.topology = topology
        self.topology_sha256 = topology_sha256
        self.accountant = accountant or C14BudgetAccountant()
        self._lock = RLock()
        self._rows: list[C14LedgerRow] = [
            self._planned_row(case, attempt_ordinal=0, resume_of=None)
            for case in topology.cases
        ]

    @property
    def rows(self) -> tuple[C14LedgerRow, ...]:
        with self._lock:
            return tuple(self._rows)

    def start_job(self, case_id: str, *, started_at: str) -> C14LedgerRow:
        """Enter one slot and start its attempt without exposing an inconsistent ledger."""

        with self._lock:
            self.accountant.enter_single_job()
            try:
                return self.start(case_id, started_at=started_at)
            except BaseException:
                self.accountant.exit_single_job()
                raise

    def pass_job(
        self,
        run_id: str,
        *,
        ended_at: str,
        artifact_sha256: str,
        usage: C14BudgetUsage,
    ) -> C14LedgerRow:
        """Pass one attempt and release its slot as one serialized mutation."""

        with self._lock:
            row = self.pass_case(
                run_id,
                ended_at=ended_at,
                artifact_sha256=artifact_sha256,
                usage=usage,
            )
            self.accountant.exit_single_job()
            return row

    def abort_job(
        self,
        run_id: str,
        *,
        ended_at: str,
        error_code: str,
        abort_reason: str,
        failed: bool = False,
        usage: C14BudgetUsage | None = None,
    ) -> C14LedgerRow:
        """Retain one failed attempt and release its slot atomically."""

        with self._lock:
            row = self.abort(
                run_id,
                ended_at=ended_at,
                error_code=error_code,
                abort_reason=abort_reason,
                failed=failed,
                usage=usage,
            )
            self.accountant.exit_single_job()
            return row

    def start(self, case_id: str, *, started_at: str) -> C14LedgerRow:
        with self._lock:
            indexes = [
                index for index, row in enumerate(self._rows) if row.case_id == case_id
            ]
            if not indexes:
                raise C14LedgerError("unknown C14.1 case identifier")
            index = indexes[-1]
            row = self._rows[index]
            if row.status != "PLANNED":
                raise C14LedgerError("C14.1 case has no planned attempt available")
            self.accountant.charge(
                C14BudgetUsage(method_cases=1 if row.attempt_ordinal == 0 else 0)
            )
            running = replace(row, status="RUNNING", started_at=started_at)
            running.validate()
            self._rows[index] = running
            return running

    def pass_case(
        self,
        run_id: str,
        *,
        ended_at: str,
        artifact_sha256: str,
        usage: C14BudgetUsage,
    ) -> C14LedgerRow:
        with self._lock:
            index, row = self._running(run_id)
            self.accountant.charge(usage)
            passed = replace(
                row,
                status="PASSED",
                ended_at=ended_at,
                artifact_sha256=artifact_sha256,
                environment_steps=row.environment_steps + usage.environment_steps,
                model_transitions=row.model_transitions + usage.model_transitions,
                api_calls=row.api_calls + usage.api_calls,
                provider_calls=row.provider_calls + usage.provider_calls,
                llm_tokens=row.llm_tokens + usage.llm_tokens,
                cpu_core_seconds=row.cpu_core_seconds + usage.cpu_core_seconds,
                gpu_seconds=row.gpu_seconds + usage.gpu_seconds,
                wall_seconds=row.wall_seconds + usage.wall_seconds,
                storage_bytes=row.storage_bytes + usage.storage_bytes,
            )
            passed.validate()
            self._rows[index] = passed
            return passed

    def abort(
        self,
        run_id: str,
        *,
        ended_at: str,
        error_code: str,
        abort_reason: str,
        failed: bool = False,
        usage: C14BudgetUsage | None = None,
    ) -> C14LedgerRow:
        with self._lock:
            index, row = self._running(run_id)
            consumed = usage or C14BudgetUsage()
            self.accountant.charge(consumed)
            retained = replace(
                row,
                status="FAILED_RETAINED" if failed else "ABORTED_RETAINED",
                ended_at=ended_at,
                error_code=error_code,
                abort_reason=abort_reason,
                environment_steps=row.environment_steps + consumed.environment_steps,
                model_transitions=row.model_transitions + consumed.model_transitions,
                api_calls=row.api_calls + consumed.api_calls,
                provider_calls=row.provider_calls + consumed.provider_calls,
                llm_tokens=row.llm_tokens + consumed.llm_tokens,
                cpu_core_seconds=row.cpu_core_seconds + consumed.cpu_core_seconds,
                gpu_seconds=row.gpu_seconds + consumed.gpu_seconds,
                wall_seconds=row.wall_seconds + consumed.wall_seconds,
                storage_bytes=row.storage_bytes + consumed.storage_bytes,
            )
            retained.validate()
            self._rows[index] = retained
            return retained

    def checkpoint_running(self, run_id: str, delta: C14BudgetUsage) -> C14LedgerRow:
        with self._lock:
            index, row = self._running(run_id)
            self.accountant.charge(delta)
            checkpointed = replace(
                row,
                environment_steps=row.environment_steps + delta.environment_steps,
                model_transitions=row.model_transitions + delta.model_transitions,
                api_calls=row.api_calls + delta.api_calls,
                provider_calls=row.provider_calls + delta.provider_calls,
                llm_tokens=row.llm_tokens + delta.llm_tokens,
                cpu_core_seconds=row.cpu_core_seconds + delta.cpu_core_seconds,
                gpu_seconds=row.gpu_seconds + delta.gpu_seconds,
                wall_seconds=row.wall_seconds + delta.wall_seconds,
                storage_bytes=row.storage_bytes + delta.storage_bytes,
            )
            checkpointed.validate()
            self._rows[index] = checkpointed
            return checkpointed

    def plan_resume(self, case_id: str) -> C14LedgerRow:
        with self._lock:
            prior = [row for row in self._rows if row.case_id == case_id]
            if not prior or prior[-1].status not in {
                "FAILED_RETAINED",
                "ABORTED_RETAINED",
            }:
                raise C14LedgerError("resume requires a retained failed or aborted attempt")
            previous = prior[-1]
            case = self.topology.by_case_id[case_id]
            resumed = self._planned_row(
                case,
                attempt_ordinal=previous.attempt_ordinal + 1,
                resume_of=previous.run_id,
            )
            self._rows.append(resumed)
            return resumed

    def recover_interrupted(
        self,
        run_id: str,
        *,
        ended_at: str,
        abort_reason: str,
    ) -> C14LedgerRow:
        with self._lock:
            index, row = self._running(run_id)
            if self.accountant.usage.concurrency <= 0:
                raise C14LedgerError("interrupted recovery requires a running job")
            recovered = replace(
                row,
                status="ABORTED_RETAINED",
                ended_at=ended_at,
                error_code="INTERRUPTED_PROCESS_RECOVERY",
                abort_reason=abort_reason,
            )
            recovered.validate()
            self._rows[index] = recovered
            self.accountant.exit_single_job()
            return recovered

    def document(self, *, execution_authorized: bool) -> dict[str, Any]:
        with self._lock:
            if execution_authorized:
                raise C14LedgerError(
                    "ledger serialization cannot self-authorize C14.1 execution"
                )
            rows = [asdict(row) for row in self._rows]
            has_runtime_state = any(row.status != "PLANNED" for row in self._rows)
            return {
                "schema_version": LEDGER_SCHEMA_VERSION,
                "artifact_status": (
                    "RUN_LEDGER_AUTHORITY_EXTERNAL"
                    if has_runtime_state
                    else "PREFLIGHT_PLAN_ONLY"
                ),
                "execution_authorized": False,
                "topology_sha256": self.topology_sha256,
                "planned_method_cases": len(self.topology.cases),
                "row_count": len(rows),
                "budget_caps": asdict(self.accountant.caps),
                "budget_usage": asdict(self.accountant.usage),
                "rows_sha256": _canonical_sha256(rows),
                "rows": rows,
            }

    def write(self, path: Path, *, execution_authorized: bool) -> str:
        with self._lock:
            payload = _canonical_json_bytes(
                self.document(execution_authorized=execution_authorized)
            )
            path = Path(path)
            path.parent.mkdir(parents=True, exist_ok=True)
            for attempt in range(ATOMIC_WRITE_ATTEMPTS):
                temporary = path.with_name(f"{path.name}.tmp-{uuid4().hex}")
                try:
                    with temporary.open("xb") as stream:
                        stream.write(payload)
                        stream.flush()
                        os.fsync(stream.fileno())
                    os.replace(temporary, path)
                    return hashlib.sha256(payload).hexdigest().upper()
                except PermissionError:
                    try:
                        temporary.unlink(missing_ok=True)
                    except OSError:
                        pass
                    if attempt + 1 == ATOMIC_WRITE_ATTEMPTS:
                        raise
                    time.sleep(ATOMIC_WRITE_BASE_DELAY_SECONDS * (attempt + 1))
                except BaseException:
                    try:
                        temporary.unlink(missing_ok=True)
                    except OSError:
                        pass
                    raise
            raise AssertionError("C14 ledger atomic write retry loop exited unexpectedly")

    @classmethod
    def load(
        cls,
        path: Path,
        topology: C14MethodCaseTopology,
        *,
        topology_sha256: str,
    ) -> C14RunLedger:
        document = _strict_json(path)
        expected_fields = {
            "schema_version",
            "artifact_status",
            "execution_authorized",
            "topology_sha256",
            "planned_method_cases",
            "row_count",
            "budget_caps",
            "budget_usage",
            "rows_sha256",
            "rows",
        }
        if not isinstance(document, dict) or set(document) != expected_fields:
            raise C14LedgerError("runtime ledger fields do not match the frozen schema")
        if document["schema_version"] != LEDGER_SCHEMA_VERSION:
            raise C14LedgerError("runtime ledger schema mismatch")
        if document["artifact_status"] not in {
            "PREFLIGHT_PLAN_ONLY",
            "RUN_LEDGER_AUTHORITY_EXTERNAL",
        }:
            raise C14LedgerError("runtime ledger status mismatch")
        if document["execution_authorized"] is not False:
            raise C14LedgerError("runtime ledger cannot authorize execution")
        if document["topology_sha256"] != topology_sha256:
            raise C14LedgerError("runtime ledger topology binding mismatch")
        rows_value = document["rows"]
        if not isinstance(rows_value, list) or document["row_count"] != len(rows_value):
            raise C14LedgerError("runtime ledger row count mismatch")
        if document["rows_sha256"] != _canonical_sha256(rows_value):
            raise C14LedgerError("runtime ledger row SHA-256 mismatch")
        caps = C14BudgetCaps(**document["budget_caps"])
        usage = C14BudgetUsage(**document["budget_usage"])
        accountant = C14BudgetAccountant(caps)
        accountant.ensure_can_charge(usage)
        accountant.usage = usage
        ledger = cls(topology, topology_sha256=topology_sha256, accountant=accountant)
        rows = tuple(C14LedgerRow(**value) for value in rows_value)
        for row in rows:
            row.validate()
            _validate_row_against_topology(row, topology, topology_sha256)
        _validate_attempt_history(rows, topology)
        if document["planned_method_cases"] != len(topology.cases):
            raise C14LedgerError("runtime ledger planned method-case count mismatch")
        derived_usage = _derive_usage(rows)
        if derived_usage != usage:
            raise C14LedgerError("runtime ledger aggregate budget usage mismatch")
        ledger._rows = list(rows)
        return ledger

    def _planned_row(
        self,
        case: C14MethodCase,
        *,
        attempt_ordinal: int,
        resume_of: str | None,
    ) -> C14LedgerRow:
        run_id = f"{case.case_id}__attempt{attempt_ordinal:03d}"
        row = C14LedgerRow(
            schema_version=LEDGER_ROW_SCHEMA_VERSION,
            run_id=run_id,
            case_id=case.case_id,
            attempt_ordinal=attempt_ordinal,
            phase="C14.1_DESIGN_VALIDATION",
            root_family=case.root_case_id,
            root_namespace=case.root_namespace,
            arm=case.arm,
            scenario=case.scenario,
            method_id=case.method_id,
            variant_id=case.variant_id,
            train_seed=case.train_seed,
            config_sha256=self.topology.method_config_sha256,
            checkpoint_sha256=case.checkpoint_sha256,
            topology_sha256=self.topology_sha256,
            status="PLANNED",
            started_at=None,
            ended_at=None,
            environment_steps=0,
            model_transitions=0,
            api_calls=0,
            provider_calls=0,
            llm_tokens=0,
            cpu_core_seconds=0,
            gpu_seconds=0,
            wall_seconds=0,
            storage_bytes=0,
            error_code=None,
            artifact_sha256=None,
            resume_of=resume_of,
            abort_reason=None,
        )
        row.validate()
        return row

    def _running(self, run_id: str) -> tuple[int, C14LedgerRow]:
        matches = [(index, row) for index, row in enumerate(self._rows) if row.run_id == run_id]
        if len(matches) != 1 or matches[0][1].status != "RUNNING":
            raise C14LedgerError("run_id does not identify one running ledger attempt")
        return matches[0]


def _canonical_json_bytes(value: dict[str, Any]) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")


def _canonical_sha256(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(
            value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
        ).encode("utf-8")
    ).hexdigest().upper()


def _validate_row_against_topology(
    row: C14LedgerRow,
    topology: C14MethodCaseTopology,
    topology_sha256: str,
) -> None:
    case = topology.by_case_id.get(row.case_id)
    if case is None:
        raise C14LedgerError("runtime ledger contains a case outside the frozen topology")
    expected = (
        row.root_family,
        row.root_namespace,
        row.arm,
        row.scenario,
        row.method_id,
        row.variant_id,
        row.train_seed,
        row.config_sha256,
        row.checkpoint_sha256,
        row.topology_sha256,
    )
    actual = (
        case.root_case_id,
        case.root_namespace,
        case.arm,
        case.scenario,
        case.method_id,
        case.variant_id,
        case.train_seed,
        topology.method_config_sha256,
        case.checkpoint_sha256,
        topology_sha256,
    )
    if expected != actual:
        raise C14LedgerError("runtime ledger row drifted from the frozen topology")


def _validate_attempt_history(
    rows: tuple[C14LedgerRow, ...], topology: C14MethodCaseTopology
) -> None:
    by_case: dict[str, list[C14LedgerRow]] = {}
    for row in rows:
        by_case.setdefault(row.case_id, []).append(row)
    if set(by_case) != set(topology.by_case_id):
        raise C14LedgerError("runtime ledger does not retain every frozen method case")
    for case_id, attempts in by_case.items():
        if tuple(row.attempt_ordinal for row in attempts) != tuple(range(len(attempts))):
            raise C14LedgerError("runtime ledger attempt ordinals are not contiguous")
        for index, row in enumerate(attempts):
            expected_run_id = f"{case_id}__attempt{index:03d}"
            if row.run_id != expected_run_id:
                raise C14LedgerError("runtime ledger run identifier mismatch")
            if index == 0 and row.resume_of is not None:
                raise C14LedgerError("initial runtime ledger attempt cannot be a resume")
            if index > 0:
                previous = attempts[index - 1]
                if previous.status not in {"FAILED_RETAINED", "ABORTED_RETAINED"}:
                    raise C14LedgerError("resume does not follow a retained failure or abort")
                if row.resume_of != previous.run_id:
                    raise C14LedgerError("resume_of does not bind the retained prior attempt")


def _derive_usage(rows: tuple[C14LedgerRow, ...]) -> C14BudgetUsage:
    return C14BudgetUsage(
        method_cases=sum(
            row.attempt_ordinal == 0 and row.status != "PLANNED" for row in rows
        ),
        environment_steps=sum(row.environment_steps for row in rows),
        model_transitions=sum(row.model_transitions for row in rows),
        cpu_core_seconds=sum(row.cpu_core_seconds for row in rows),
        wall_seconds=sum(row.wall_seconds for row in rows),
        storage_bytes=sum(row.storage_bytes for row in rows),
        concurrency=sum(row.status == "RUNNING" for row in rows),
        gpu_seconds=sum(row.gpu_seconds for row in rows),
        api_calls=sum(row.api_calls for row in rows),
        provider_calls=sum(row.provider_calls for row in rows),
        llm_tokens=sum(row.llm_tokens for row in rows),
    )


def _strict_json(path: Path) -> Any:
    def reject_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise C14LedgerError(f"duplicate runtime ledger key: {key}")
            result[key] = value
        return result

    return json.loads(
        Path(path).read_text(encoding="utf-8"),
        object_pairs_hook=reject_duplicates,
        parse_constant=lambda value: (_ for _ in ()).throw(
            C14LedgerError(f"non-finite runtime ledger value: {value}")
        ),
    )
