"""C03 deterministic disturbance tape generation."""

from dataclasses import replace
import hashlib
import json
from typing import Any

from exp09.contracts.ids import RootCaseId, TapeId, VehicleId
from exp09.contracts.tape import (
    DISTURBANCE_TAPE_SCHEMA_VERSION,
    PROTOCOL_GENERATION_ID,
    TAPE_ARRIVAL_SCHEMA_VERSION,
    TAPE_GRANT_SCHEMA_VERSION,
    TAPE_CHANNEL_DRAW_SCHEMA_VERSION,
    TAPE_COUNTER_SCHEMA_VERSION,
    TAPE_RESELECTION_SCHEMA_VERSION,
    TAPE_VEHICLE_SCHEMA_VERSION,
    DisturbanceTape,
    CounterNamespace,
    TapeArm,
    TapeArrival,
    TapeGrant,
    TapeChannelDraw,
    TapeCounter,
    TapeReselection,
    TapeVehicle,
)
from exp09.contracts.time import SimTimeUs

from .rng import KeyedRng, stable_digest_hex

SIMULATION_START_US = 0
SIMULATION_END_US = 50_000_000
ANALYSIS_ORIGIN_SIMULATION_TIME_US = 10_000_000
ANALYSIS_TAU_START_US = 0
ANALYSIS_TAU_END_US = 40_000_000
PACKET_PERIOD_US = 100_000
SLOT_DURATION_US = 1_000
LOGICAL_SUBCHANNEL_COUNT = 2
LEGAL_RRI_US = (20_000, 50_000, 100_000, 200_000, 300_000, 500_000, 1_000_000)
ONSET_ANALYSIS_TAU_CANDIDATES_US = (10_000_000, 12_000_000, 14_000_000)
ONSET_SIMULATION_CANDIDATES_US = (20_000_000, 22_000_000, 24_000_000)
BACKGROUND_RESELECTION_COUNT = 512
CHANNEL_DRAW_COUNT_PER_VEHICLE = 2_048
REBUILD_COUNTER_COUNT_PER_VEHICLE = 100
PRIMARY_REFERENCE_POPULATION = 6
PRIMARY_EVENT_POPULATION = 9
PRIMARY_INFLUX_COUNT = 3
PRIMARY_ENTRANT_IDS = ("vehicle_6", "vehicle_7", "vehicle_8")
TAPE_CONFIG_SCHEMA_VERSION = "exp09-tape-config-v3"


class _TapeKeyedRng(KeyedRng):
    """Byte-equivalent typed-key hashing without generic JSON object allocation."""

    def __init__(self, *root_parts: str) -> None:
        super().__init__(*root_parts)
        self._tape_root_parts = root_parts

    def draw_uint(self, namespace: str, index: int, modulo: int) -> int:
        if not namespace or index < 0 or modulo <= 0:
            return super().draw_uint(namespace, index, modulo)
        digest = _fast_stable_digest_hex(*self._tape_root_parts, namespace, index)
        return int(digest[:16], 16) % modulo


def build_primary_influx_tape(
    root_case_id: str,
    arm: TapeArm,
    *,
    validate_generated_tape: bool = True,
) -> DisturbanceTape:
    if not isinstance(arm, TapeArm):
        raise ValueError("arm must be a TapeArm")
    (
        hidden_onset_simulation_time_us,
        hidden_onset_analysis_tau_us,
        vehicles,
        arrivals,
        reselections,
        channel_draws,
        counters,
    ) = _materialize_primary_exogenous(root_case_id)
    config_counters = counters
    if arm is TapeArm.REFERENCE:
        vehicles = vehicles[:PRIMARY_REFERENCE_POPULATION]
        arrivals = ()
        shared_ids = {str(vehicle.vehicle_id) for vehicle in vehicles}
        counters = tuple(
            item for item in counters if str(item.vehicle_id) in shared_ids
        )

    primitive = _generation_config_primitive(root_case_id, counters=config_counters)
    config_hash = _stable_config_hash(primitive)
    tape = DisturbanceTape(
        schema_version=DISTURBANCE_TAPE_SCHEMA_VERSION,
        protocol_generation=PROTOCOL_GENERATION_ID,
        tape_id=TapeId("UNBOUND"),
        root_case_id=RootCaseId(root_case_id),
        arm=arm,
        config_hash=config_hash,
        simulation_start_us=SimTimeUs(SIMULATION_START_US),
        simulation_end_us=SimTimeUs(SIMULATION_END_US),
        analysis_origin_simulation_time_us=SimTimeUs(
            ANALYSIS_ORIGIN_SIMULATION_TIME_US
        ),
        analysis_tau_start_us=SimTimeUs(ANALYSIS_TAU_START_US),
        analysis_tau_end_us=SimTimeUs(ANALYSIS_TAU_END_US),
        paired_anchor_simulation_time_us=SimTimeUs(
            hidden_onset_simulation_time_us
        ),
        paired_anchor_analysis_tau_us=SimTimeUs(hidden_onset_analysis_tau_us),
        packet_period_us=PACKET_PERIOD_US,
        slot_duration_us=SLOT_DURATION_US,
        logical_subchannel_count=LOGICAL_SUBCHANNEL_COUNT,
        controlled_vehicle_id=VehicleId("vehicle_0"),
        vehicles=vehicles,
        arrivals=arrivals,
        background_reselections=reselections,
        channel_draws=channel_draws,
        counters=counters,
    )
    tape = replace(tape, tape_id=TapeId(_expected_tape_id(tape)))
    if validate_generated_tape:
        validate_primary_tape(tape)
    return tape


def _materialize_primary_exogenous(
    root_case_id: str,
) -> tuple[
    int,
    int,
    tuple[TapeVehicle, ...],
    tuple[TapeArrival, ...],
    tuple[TapeReselection, ...],
    tuple[TapeChannelDraw, ...],
    tuple[TapeCounter, ...],
]:
    """Rebuild every frozen primary exogenous value from its typed keys."""

    rng = _TapeKeyedRng(PROTOCOL_GENERATION_ID, root_case_id, "primary_influx")
    hidden_onset_analysis_tau_us = ONSET_ANALYSIS_TAU_CANDIDATES_US[
        rng.draw_uint("onset", 0, len(ONSET_ANALYSIS_TAU_CANDIDATES_US))
    ]
    hidden_onset_simulation_time_us = (
        ANALYSIS_ORIGIN_SIMULATION_TIME_US + hidden_onset_analysis_tau_us
    )

    vehicles: list[TapeVehicle] = []
    arrivals: list[TapeArrival] = []
    for index in range(6):
        vehicle_id = f"vehicle_{index}"
        vehicles.append(
            _vehicle(
                rng,
                vehicle_id=vehicle_id,
                key=vehicle_id,
                arrival_simulation_time_us=SIMULATION_START_US,
                last_success_generation_us=-PACKET_PERIOD_US
                - rng.draw_uint(f"pre_entry:vehicle_{index}", 0, PACKET_PERIOD_US),
            )
        )
    for vehicle_index in range(6, 9):
        vehicle_id = f"vehicle_{vehicle_index}"
        vehicles.append(
            _vehicle(
                rng,
                vehicle_id=vehicle_id,
                key=vehicle_id,
                arrival_simulation_time_us=hidden_onset_simulation_time_us,
                last_success_generation_us=hidden_onset_simulation_time_us
                - PACKET_PERIOD_US
                - rng.draw_uint(f"pre_entry:{vehicle_id}", 0, PACKET_PERIOD_US),
            )
        )
        arrivals.append(
            TapeArrival(
                schema_version=TAPE_ARRIVAL_SCHEMA_VERSION,
                vehicle_id=VehicleId(vehicle_id),
                simulation_time_us=SimTimeUs(hidden_onset_simulation_time_us),
                analysis_tau_us=hidden_onset_analysis_tau_us,
            )
        )

    shared_background_ids = tuple(f"vehicle_{index}" for index in range(1, 9))
    reselections = tuple(
        TapeReselection(
            schema_version=TAPE_RESELECTION_SCHEMA_VERSION,
            vehicle_id=VehicleId(vehicle_id),
            ordinal=ordinal,
            grant=_grant(rng, f"background:{vehicle_id}:{ordinal}"),
        )
        for vehicle_id in shared_background_ids
        for ordinal in range(BACKGROUND_RESELECTION_COUNT)
    )
    channel_draws = tuple(
        TapeChannelDraw(
            schema_version=TAPE_CHANNEL_DRAW_SCHEMA_VERSION,
            vehicle_id=VehicleId(f"vehicle_{vehicle_index}"),
            ordinal=ordinal,
            uniform_u64=int(
                _fast_stable_digest_hex(
                    PROTOCOL_GENERATION_ID,
                    root_case_id,
                    "channel_error",
                    f"vehicle_{vehicle_index}",
                    ordinal,
                )[:16],
                16,
            ),
        )
        for vehicle_index in range(9)
        for ordinal in range(CHANNEL_DRAW_COUNT_PER_VEHICLE)
    )
    counters = tuple(
        TapeCounter(
            schema_version=TAPE_COUNTER_SCHEMA_VERSION,
            vehicle_id=VehicleId(f"vehicle_{vehicle_index}"),
            counter_namespace=namespace,
            counter_ordinal=ordinal,
            value=_keyed_counter(
                root_case_id,
                f"vehicle_{vehicle_index}",
                namespace,
                ordinal,
            ),
        )
        for vehicle_index in range(9)
        for namespace, ordinals in (
            (CounterNamespace.INITIAL, (0,)),
            (
                CounterNamespace.REBUILD,
                range(1, REBUILD_COUNTER_COUNT_PER_VEHICLE + 1),
            ),
        )
        for ordinal in ordinals
    )
    return (
        hidden_onset_simulation_time_us,
        hidden_onset_analysis_tau_us,
        tuple(vehicles),
        tuple(arrivals),
        reselections,
        channel_draws,
        counters,
    )


def _keyed_counter(
    root_case_id: str,
    vehicle_id: str,
    namespace: CounterNamespace,
    ordinal: int,
) -> int:
    digest = _fast_stable_digest_hex(
        PROTOCOL_GENERATION_ID,
        root_case_id,
        vehicle_id,
        namespace.value,
        ordinal,
    )
    return 5 + int(digest[:16], 16) % 11


def _generation_config_primitive(
    root_case_id: str,
    *,
    counters: tuple[TapeCounter, ...] | None = None,
) -> dict[str, Any]:
    materialized_counters = counters or _materialize_counters_for_config(root_case_id)
    return {
        "schema_version": TAPE_CONFIG_SCHEMA_VERSION,
        "tape_schema_version": DISTURBANCE_TAPE_SCHEMA_VERSION,
        "protocol_generation": PROTOCOL_GENERATION_ID,
        "root_case_id": root_case_id,
        "simulation_window_us": [SIMULATION_START_US, SIMULATION_END_US],
        "analysis_origin_simulation_time_us": ANALYSIS_ORIGIN_SIMULATION_TIME_US,
        "analysis_tau_window_us": [ANALYSIS_TAU_START_US, ANALYSIS_TAU_END_US],
        "packet_period_us": PACKET_PERIOD_US,
        "slot_duration_us": SLOT_DURATION_US,
        "logical_subchannel_count": LOGICAL_SUBCHANNEL_COUNT,
        "legal_rri_us": list(LEGAL_RRI_US),
        "primary_family": "primary_influx",
        "onset_analysis_tau_candidates_us": list(ONSET_ANALYSIS_TAU_CANDIDATES_US),
        "onset_simulation_candidates_us": list(ONSET_SIMULATION_CANDIDATES_US),
        "reference_population": PRIMARY_REFERENCE_POPULATION,
        "event_population": PRIMARY_EVENT_POPULATION,
        "influx_count": PRIMARY_INFLUX_COUNT,
        "entrant_ids": list(PRIMARY_ENTRANT_IDS),
        "background_reselection_count": BACKGROUND_RESELECTION_COUNT,
        "channel_draw_count_per_vehicle": CHANNEL_DRAW_COUNT_PER_VEHICLE,
        "counter_distribution": "KEYED_DISCRETE_UNIFORM_INTEGER_5_TO_15_INCLUSIVE",
        "counter_key_fields": [
            "protocol_generation",
            "root_case_id",
            "vehicle_id",
            "counter_namespace",
            "counter_ordinal",
        ],
        "counter_namespaces": [
            CounterNamespace.INITIAL.value,
            CounterNamespace.REBUILD.value,
        ],
        "initial_counter_ordinal": 0,
        "rebuild_counter_ordinals": [1, REBUILD_COUNTER_COUNT_PER_VEHICLE],
        "counters": [
            {
                "vehicle_id": str(item.vehicle_id),
                "counter_namespace": item.counter_namespace.value,
                "counter_ordinal": item.counter_ordinal,
                "value": item.value,
            }
            for item in materialized_counters
        ],
    }


def _materialize_counters_for_config(root_case_id: str) -> tuple[TapeCounter, ...]:
    return tuple(
        TapeCounter(
            schema_version=TAPE_COUNTER_SCHEMA_VERSION,
            vehicle_id=VehicleId(f"vehicle_{vehicle_index}"),
            counter_namespace=namespace,
            counter_ordinal=ordinal,
            value=_keyed_counter(
                root_case_id,
                f"vehicle_{vehicle_index}",
                namespace,
                ordinal,
            ),
        )
        for vehicle_index in range(9)
        for namespace, ordinals in (
            (CounterNamespace.INITIAL, (0,)),
            (
                CounterNamespace.REBUILD,
                range(1, REBUILD_COUNTER_COUNT_PER_VEHICLE + 1),
            ),
        )
        for ordinal in ordinals
    )


def _stable_config_hash(value: dict[str, Any]) -> str:
    data = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode(
        "utf-8"
    )
    return hashlib.sha256(data).hexdigest().upper()


def _fast_stable_digest_hex(*parts: str | int) -> str:
    encoded_parts: list[str] = []
    for part in parts:
        if isinstance(part, str):
            value = json.dumps(part, ensure_ascii=False, separators=(",", ":"))
            encoded_parts.append(f'{{"type":"str","value":{value}}}')
        elif isinstance(part, int) and not isinstance(part, bool):
            encoded_parts.append(f'{{"type":"int","value":{part}}}')
        else:
            return stable_digest_hex(*parts)
    payload = f"[{','.join(encoded_parts)}]".encode("utf-8")
    return hashlib.sha256(payload).hexdigest().upper()


def _vehicle(
    rng: KeyedRng,
    *,
    vehicle_id: str,
    key: str,
    arrival_simulation_time_us: int,
    last_success_generation_us: int,
) -> TapeVehicle:
    grant = _grant(rng, f"initial:{key}")
    phase = rng.draw_uint(f"packet_phase:{key}", 0, PACKET_PERIOD_US)
    return TapeVehicle(
        schema_version=TAPE_VEHICLE_SCHEMA_VERSION,
        vehicle_id=VehicleId(vehicle_id),
        arrival_simulation_time_us=SimTimeUs(arrival_simulation_time_us),
        arrival_analysis_tau_us=(
            arrival_simulation_time_us - ANALYSIS_ORIGIN_SIMULATION_TIME_US
        ),
        departure_simulation_time_us=SimTimeUs(SIMULATION_END_US),
        departure_analysis_tau_us=ANALYSIS_TAU_END_US,
        packet_phase_us=phase,
        initial_grant=grant,
        last_success_generation_us_at_entry=SimTimeUs(last_success_generation_us),
    )


def _grant(rng: KeyedRng, key: str) -> TapeGrant:
    rri = LEGAL_RRI_US[rng.draw_uint(f"{key}:rri", 0, len(LEGAL_RRI_US))]
    slot_count = rri // SLOT_DURATION_US
    return TapeGrant(
        schema_version=TAPE_GRANT_SCHEMA_VERSION,
        rri_us=rri,
        slot_offset_us=rng.draw_uint(f"{key}:offset", 0, slot_count) * SLOT_DURATION_US,
        logical_subchannel_id=rng.draw_uint(
            f"{key}:subchannel", 0, LOGICAL_SUBCHANNEL_COUNT
        ),
    )


def validate_primary_tape(tape: DisturbanceTape) -> None:
    root_case_id = str(tape.root_case_id)
    (
        expected_onset_simulation_time_us,
        expected_onset_analysis_tau_us,
        expected_event_vehicles,
        expected_event_arrivals,
        expected_reselections,
        expected_channel_draws,
        expected_counters,
    ) = _materialize_primary_exogenous(root_case_id)
    expected_vehicles = (
        expected_event_vehicles[:PRIMARY_REFERENCE_POPULATION]
        if tape.arm is TapeArm.REFERENCE
        else expected_event_vehicles
    )
    expected_arrivals = () if tape.arm is TapeArm.REFERENCE else expected_event_arrivals
    expected_counter_ids = {str(vehicle.vehicle_id) for vehicle in expected_vehicles}
    expected_counters = tuple(
        item
        for item in expected_counters
        if str(item.vehicle_id) in expected_counter_ids
    )

    expected_header = (
        int(tape.simulation_start_us),
        int(tape.simulation_end_us),
        int(tape.analysis_origin_simulation_time_us),
        int(tape.analysis_tau_start_us),
        int(tape.analysis_tau_end_us),
        int(tape.paired_anchor_simulation_time_us),
        int(tape.paired_anchor_analysis_tau_us),
        tape.packet_period_us,
        tape.slot_duration_us,
        tape.logical_subchannel_count,
        str(tape.controlled_vehicle_id),
    )
    if expected_header != (
        SIMULATION_START_US,
        SIMULATION_END_US,
        ANALYSIS_ORIGIN_SIMULATION_TIME_US,
        ANALYSIS_TAU_START_US,
        ANALYSIS_TAU_END_US,
        expected_onset_simulation_time_us,
        expected_onset_analysis_tau_us,
        PACKET_PERIOD_US,
        SLOT_DURATION_US,
        LOGICAL_SUBCHANNEL_COUNT,
        "vehicle_0",
    ):
        raise ValueError("primary tape header does not match frozen keyed generation")
    expected_config_hash = _stable_config_hash(
        _generation_config_primitive(root_case_id)
    )
    if tape.config_hash != expected_config_hash:
        raise ValueError("tape config_hash does not match the frozen generation inputs")
    if tape.vehicles != expected_vehicles:
        raise ValueError("primary tape vehicles do not match keyed generation")
    if tape.arrivals != expected_arrivals:
        raise ValueError("primary tape arrivals do not match keyed generation")
    if tape.background_reselections != expected_reselections:
        raise ValueError("primary tape reselections do not match keyed generation")
    if tape.channel_draws != expected_channel_draws:
        raise ValueError("primary tape channel draws do not match keyed generation")
    if tape.counters != expected_counters:
        raise ValueError("primary tape counters do not match keyed generation")
    expected_tape_id = _expected_tape_id(tape)
    if str(tape.tape_id) != expected_tape_id:
        raise ValueError("tape_id does not bind the canonical tape content")


validate_primary_pair_tape = validate_primary_tape


class ScenarioSemanticValidator:
    """Validate the frozen primary reference/event pair and realized truth delta."""

    @staticmethod
    def validate_pair(reference: DisturbanceTape, event: DisturbanceTape) -> None:
        if reference.arm is not TapeArm.REFERENCE or event.arm is not TapeArm.EVENT:
            raise ValueError("primary pair must be ordered as REFERENCE then EVENT")
        shared_header = (
            "schema_version",
            "protocol_generation",
            "root_case_id",
            "config_hash",
            "simulation_start_us",
            "simulation_end_us",
            "analysis_origin_simulation_time_us",
            "analysis_tau_start_us",
            "analysis_tau_end_us",
            "paired_anchor_simulation_time_us",
            "paired_anchor_analysis_tau_us",
            "packet_period_us",
            "slot_duration_us",
            "logical_subchannel_count",
            "controlled_vehicle_id",
        )
        for field in shared_header:
            if getattr(reference, field) != getattr(event, field):
                raise ValueError(f"primary pair differs in forbidden field: {field}")
        if len(reference.vehicles) != PRIMARY_REFERENCE_POPULATION:
            raise ValueError("REFERENCE must contain exactly six initial vehicles")
        if len(event.vehicles) != PRIMARY_EVENT_POPULATION:
            raise ValueError("EVENT must contain exactly six shared and three entrant vehicles")
        if reference.vehicles != event.vehicles[:PRIMARY_REFERENCE_POPULATION]:
            raise ValueError("shared vehicle exogenous fields are not byte-equivalent")
        entrants = event.vehicles[PRIMARY_REFERENCE_POPULATION:]
        entrant_ids = tuple(str(vehicle.vehicle_id) for vehicle in entrants)
        if entrant_ids != PRIMARY_ENTRANT_IDS:
            raise ValueError("EVENT entrants are not the preregistered identities")
        arrival_ids = tuple(str(arrival.vehicle_id) for arrival in event.arrivals)
        if arrival_ids != PRIMARY_ENTRANT_IDS or reference.arrivals:
            raise ValueError("arrival delta is not exactly the preregistered three-vehicle batch")
        onset_simulation_times = {
            int(arrival.simulation_time_us) for arrival in event.arrivals
        }
        onset_analysis_times = {arrival.analysis_tau_us for arrival in event.arrivals}
        if (
            len(onset_simulation_times) != 1
            or onset_simulation_times.pop() not in ONSET_SIMULATION_CANDIDATES_US
            or len(onset_analysis_times) != 1
            or onset_analysis_times.pop() not in ONSET_ANALYSIS_TAU_CANDIDATES_US
        ):
            raise ValueError("EVENT onset is outside the frozen candidate set")
        if reference.paired_anchor_simulation_time_us != event.paired_anchor_simulation_time_us:
            raise ValueError("primary pair does not share one hidden anchor")
        if event.paired_anchor_analysis_tau_us != reference.paired_anchor_analysis_tau_us:
            raise ValueError("primary pair does not share one analysis anchor")
        if event.paired_anchor_simulation_time_us != event.arrivals[0].simulation_time_us:
            raise ValueError("EVENT arrivals do not occur at the paired hidden anchor")
        if any(
            int(vehicle.departure_simulation_time_us) != int(event.simulation_end_us)
            for vehicle in entrants
        ):
            raise ValueError("primary entrants must remain through the analysis-window end")
        if reference.background_reselections != event.background_reselections:
            raise ValueError("background-reselection tape changed across the primary pair")
        if reference.channel_draws != event.channel_draws:
            raise ValueError("channel tape changed across the primary pair")
        shared_counter_ids = {str(item.vehicle_id) for item in reference.counters}
        event_shared_counters = tuple(
            item for item in event.counters if str(item.vehicle_id) in shared_counter_ids
        )
        if reference.counters != event_shared_counters:
            raise ValueError("counter tape changed across shared vehicles")

    @staticmethod
    def validate_truth_delta(reference_trace, event_trace) -> None:
        from exp09.plant.state import TruthEventKind

        reference_arrivals = tuple(
            item for item in reference_trace.truth_events
            if item.kind == TruthEventKind.VEHICLE_ARRIVAL
        )
        event_arrivals = tuple(
            item for item in event_trace.truth_events
            if item.kind == TruthEventKind.VEHICLE_ARRIVAL
        )
        reference_departures = tuple(
            item for item in reference_trace.truth_events
            if item.kind == TruthEventKind.VEHICLE_DEPARTURE
        )
        event_departures = tuple(
            item for item in event_trace.truth_events
            if item.kind == TruthEventKind.VEHICLE_DEPARTURE
        )
        if reference_arrivals or reference_departures or event_departures:
            raise ValueError("primary truth contains an undeclared arrival/departure delta")
        if set(item.vehicle_id for item in event_arrivals) != set(PRIMARY_ENTRANT_IDS):
            raise ValueError("realized truth does not contain exactly the registered entrants")
        event_times = {item.time_us for item in event_arrivals}
        if len(event_times) != 1 or event_times.pop() not in ONSET_SIMULATION_CANDIDATES_US:
            raise ValueError("realized entrant onset is outside the frozen candidate set")


def tape_to_bytes(tape: DisturbanceTape) -> bytes:
    from exp09.artifacts.canonical import canonical_json_bytes

    return canonical_json_bytes(tape, expected_schema_version=DISTURBANCE_TAPE_SCHEMA_VERSION)


def _expected_tape_id(tape: DisturbanceTape) -> str:
    identity_view = replace(tape, tape_id=TapeId("UNBOUND"))
    return hashlib.sha256(b"exp09-tape-id-v1\0" + tape_to_bytes(identity_view)).hexdigest().upper()


def save_tape(tape: DisturbanceTape, path) -> None:
    from pathlib import Path

    Path(path).write_bytes(tape_to_bytes(tape))


def load_tape(path) -> DisturbanceTape:
    from pathlib import Path

    return tape_from_bytes(Path(path).read_bytes())


def tape_from_bytes(payload: bytes) -> DisturbanceTape:
    data = json.loads(payload.decode("utf-8"))
    if data.get("schema_version") != DISTURBANCE_TAPE_SCHEMA_VERSION:
        raise ValueError("unsupported disturbance-tape schema version")
    vehicles = tuple(
        TapeVehicle(
            schema_version=item["schema_version"],
            vehicle_id=VehicleId(item["vehicle_id"]),
            arrival_simulation_time_us=SimTimeUs(item["arrival_simulation_time_us"]),
            arrival_analysis_tau_us=item["arrival_analysis_tau_us"],
            departure_simulation_time_us=SimTimeUs(item["departure_simulation_time_us"]),
            departure_analysis_tau_us=item["departure_analysis_tau_us"],
            packet_phase_us=item["packet_phase_us"],
            initial_grant=TapeGrant(**item["initial_grant"]),
            last_success_generation_us_at_entry=SimTimeUs(
                item["last_success_generation_us_at_entry"]
            ),
        )
        for item in data["vehicles"]
    )
    tape = DisturbanceTape(
        schema_version=data["schema_version"],
        protocol_generation=data["protocol_generation"],
        tape_id=TapeId(data["tape_id"]),
        root_case_id=RootCaseId(data["root_case_id"]),
        arm=TapeArm(data["arm"]),
        config_hash=data["config_hash"],
        simulation_start_us=SimTimeUs(data["simulation_start_us"]),
        simulation_end_us=SimTimeUs(data["simulation_end_us"]),
        analysis_origin_simulation_time_us=SimTimeUs(
            data["analysis_origin_simulation_time_us"]
        ),
        analysis_tau_start_us=SimTimeUs(data["analysis_tau_start_us"]),
        analysis_tau_end_us=SimTimeUs(data["analysis_tau_end_us"]),
        paired_anchor_simulation_time_us=SimTimeUs(
            data["paired_anchor_simulation_time_us"]
        ),
        paired_anchor_analysis_tau_us=SimTimeUs(
            data["paired_anchor_analysis_tau_us"]
        ),
        packet_period_us=data["packet_period_us"],
        slot_duration_us=data["slot_duration_us"],
        logical_subchannel_count=data["logical_subchannel_count"],
        controlled_vehicle_id=VehicleId(data["controlled_vehicle_id"]),
        vehicles=vehicles,
        arrivals=tuple(
            TapeArrival(
                schema_version=item["schema_version"],
                vehicle_id=VehicleId(item["vehicle_id"]),
                simulation_time_us=SimTimeUs(item["simulation_time_us"]),
                analysis_tau_us=item["analysis_tau_us"],
            )
            for item in data["arrivals"]
        ),
        background_reselections=tuple(
            TapeReselection(
                schema_version=item["schema_version"],
                vehicle_id=VehicleId(item["vehicle_id"]),
                ordinal=item["ordinal"],
                grant=TapeGrant(**item["grant"]),
            )
            for item in data["background_reselections"]
        ),
        channel_draws=tuple(
            TapeChannelDraw(
                schema_version=item["schema_version"],
                vehicle_id=VehicleId(item["vehicle_id"]),
                ordinal=item["ordinal"],
                uniform_u64=item["uniform_u64"],
            )
            for item in data["channel_draws"]
        ),
        counters=tuple(
            TapeCounter(
                schema_version=item["schema_version"],
                vehicle_id=VehicleId(item["vehicle_id"]),
                counter_namespace=CounterNamespace(item["counter_namespace"]),
                counter_ordinal=item["counter_ordinal"],
                value=item["value"],
            )
            for item in data["counters"]
        ),
    )
    if tape_to_bytes(tape) != payload:
        raise ValueError("tape is not in canonical JSON form")
    validate_primary_tape(tape)
    return tape
