"""C13 deterministic statistical and blinded-readiness tools."""

from dataclasses import dataclass
from enum import Enum

from exp09.contracts.determinism import stable_digest_hex
from exp09.contracts.ids import require_identifier, require_safe_relative_path, require_sha256
from exp09.contracts.time import require_non_negative_int, require_positive_int

ROOT_MEASUREMENT_SCHEMA_VERSION = "exp09-root-measurement-v1"
SEEDED_ROOT_MEASUREMENT_SCHEMA_VERSION = "exp09-seeded-root-measurement-v1"
SIGNED_ROOT_CONTRAST_SCHEMA_VERSION = "exp09-signed-root-contrast-v1"
ROOT_AGGREGATE_SCHEMA_VERSION = "exp09-root-aggregate-v1"
BOOTSTRAP_CI_SCHEMA_VERSION = "exp09-bootstrap-ci-v1"
HOLM_RESULT_SCHEMA_VERSION = "exp09-holm-result-v1"
BLINDED_LABEL_MAP_SCHEMA_VERSION = "exp09-blinded-label-map-v1"
PUBLIC_BLINDING_EXPORT_SCHEMA_VERSION = "exp09-public-blinding-export-v1"
DECISION_TABLE_SCHEMA_VERSION = "exp09-decision-table-v1"
MANUSCRIPT_LOCATOR_SCHEMA_VERSION = "exp09-manuscript-locator-v1"
STABLE_MANUSCRIPT_LOCATOR_SCHEMA_VERSION = "exp09-stable-manuscript-locator-v1"
REVIEWER_EVIDENCE_RECORD_SCHEMA_VERSION = "exp09-reviewer-evidence-record-v1"
REVIEWER_EVIDENCE_BUNDLE_SCHEMA_VERSION = "exp09-reviewer-evidence-bundle-v1"
BLINDED_MAPPING_HASH_DOMAIN = "exp09-blinded-label-map-v1"
CANONICAL_REVIEW_COMMENT_IDS = (
    "E-1",
    "E-2",
    "E-3",
    "E-4",
    "R1-1",
    "R1-2",
    "R1-3",
    "R1-4",
    "R1-5",
    "R1-6",
    "R1-U1",
    "R2-1",
    "R2-2",
    "R2-3-i",
    "R2-3-ii",
    "R2-4-i",
    "R2-4-ii",
    "R2-4-iii",
)
REVIEWER_EVIDENCE_RESULT_STATUSES = frozenset(
    {
        "STRUCTURE_READY",
        "PENDING_C14",
        "PENDING_C15",
        "BLOCKED_AUTHORIZATION",
    }
)


class CoverageLevel(str, Enum):
    A = "A"
    B = "B"
    C = "C"
    NA = "NA"


class MarginGateStatus(str, Enum):
    PASSED = "PASSED"
    FAILED = "FAILED"
    NOT_ASSESSABLE_NO_MARGIN = "NOT_ASSESSABLE_NO_MARGIN"


def _require_signed_int(value: int, field_name: str) -> None:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{field_name} must be an integer")


@dataclass(frozen=True, slots=True)
class RootMeasurement:
    schema_version: str
    root_case_id: str
    family_id: str
    arm_label: str
    value: int

    def __post_init__(self) -> None:
        if self.schema_version != ROOT_MEASUREMENT_SCHEMA_VERSION:
            raise ValueError("unsupported root-measurement schema version")
        for field_name in ("root_case_id", "family_id", "arm_label"):
            require_identifier(getattr(self, field_name), field_name)
        require_non_negative_int(self.value, "value")


@dataclass(frozen=True, slots=True)
class SeededRootMeasurement:
    schema_version: str
    root_case_id: str
    family_id: str
    arm_label: str
    seed_id: str
    value: int

    def __post_init__(self) -> None:
        if self.schema_version != SEEDED_ROOT_MEASUREMENT_SCHEMA_VERSION:
            raise ValueError("unsupported seeded-root-measurement schema version")
        for field_name in ("root_case_id", "family_id", "arm_label", "seed_id"):
            require_identifier(getattr(self, field_name), field_name)
        require_non_negative_int(self.value, "value")


@dataclass(frozen=True, slots=True)
class SignedRootContrast:
    schema_version: str
    contrast_id: str
    root_case_id: str
    family_id: str
    control_arm_label: str
    treatment_arm_label: str
    signed_value: int

    def __post_init__(self) -> None:
        if self.schema_version != SIGNED_ROOT_CONTRAST_SCHEMA_VERSION:
            raise ValueError("unsupported signed-root-contrast schema version")
        for field_name in (
            "contrast_id",
            "root_case_id",
            "family_id",
            "control_arm_label",
            "treatment_arm_label",
        ):
            require_identifier(getattr(self, field_name), field_name)
        if self.control_arm_label == self.treatment_arm_label:
            raise ValueError("paired contrast requires distinct arms")
        _require_signed_int(self.signed_value, "signed_value")


def aggregate_seeded_roots(measurements: tuple[SeededRootMeasurement, ...]) -> tuple[RootMeasurement, ...]:
    if not isinstance(measurements, tuple) or not measurements:
        raise ValueError("seeded measurements must be a non-empty tuple")
    groups: dict[tuple[str, str, str], dict[str, int]] = {}
    for measurement in measurements:
        if not isinstance(measurement, SeededRootMeasurement):
            raise ValueError("measurements must contain SeededRootMeasurement values")
        key = (measurement.root_case_id, measurement.family_id, measurement.arm_label)
        seed_values = groups.setdefault(key, {})
        if measurement.seed_id in seed_values:
            raise ValueError("duplicate seed measurement for root/family/arm")
        seed_values[measurement.seed_id] = measurement.value
    return tuple(
        RootMeasurement(
            schema_version=ROOT_MEASUREMENT_SCHEMA_VERSION,
            root_case_id=root_case_id,
            family_id=family_id,
            arm_label=arm_label,
            value=sum(seed_values.values()) // len(seed_values),
        )
        for (root_case_id, family_id, arm_label), seed_values in sorted(groups.items())
    )


def paired_root_contrasts(
    measurements: tuple[RootMeasurement, ...],
    *,
    contrast_id: str,
    family_id: str,
    control_arm_label: str,
    treatment_arm_label: str,
) -> tuple[SignedRootContrast, ...]:
    if not isinstance(measurements, tuple) or not measurements:
        raise ValueError("measurements must be a non-empty tuple")
    for field_name, value in (
        ("contrast_id", contrast_id),
        ("family_id", family_id),
        ("control_arm_label", control_arm_label),
        ("treatment_arm_label", treatment_arm_label),
    ):
        require_identifier(value, field_name)
    if control_arm_label == treatment_arm_label:
        raise ValueError("paired contrast requires distinct arms")
    root_to_family: dict[str, str] = {}
    paired: dict[str, dict[str, int]] = {}
    expected_arms = {control_arm_label, treatment_arm_label}
    for measurement in measurements:
        if not isinstance(measurement, RootMeasurement):
            raise ValueError("measurements must contain RootMeasurement values")
        previous_family = root_to_family.setdefault(measurement.root_case_id, measurement.family_id)
        if previous_family != measurement.family_id:
            raise ValueError("root_case_id cannot collide across families")
        if measurement.family_id != family_id:
            continue
        if measurement.arm_label not in expected_arms:
            raise ValueError("paired root contains an unexpected arm")
        root_values = paired.setdefault(measurement.root_case_id, {})
        if measurement.arm_label in root_values:
            raise ValueError("duplicate arm measurement for paired root")
        root_values[measurement.arm_label] = measurement.value
    if not paired:
        raise ValueError("no paired roots exist for the requested family")
    contrasts: list[SignedRootContrast] = []
    for root_case_id, root_values in sorted(paired.items()):
        if set(root_values) != expected_arms:
            raise ValueError("paired root is incomplete")
        contrasts.append(
            SignedRootContrast(
                schema_version=SIGNED_ROOT_CONTRAST_SCHEMA_VERSION,
                contrast_id=contrast_id,
                root_case_id=root_case_id,
                family_id=family_id,
                control_arm_label=control_arm_label,
                treatment_arm_label=treatment_arm_label,
                signed_value=root_values[treatment_arm_label] - root_values[control_arm_label],
            )
        )
    return tuple(contrasts)


@dataclass(frozen=True, slots=True)
class RootAggregate:
    schema_version: str
    family_id: str
    arm_label: str
    count: int
    mean_value: int
    aggregate_hash: str

    def __post_init__(self) -> None:
        if self.schema_version != ROOT_AGGREGATE_SCHEMA_VERSION:
            raise ValueError("unsupported root-aggregate schema version")
        require_identifier(self.family_id, "family_id")
        require_identifier(self.arm_label, "arm_label")
        require_positive_int(self.count, "count")
        require_non_negative_int(self.mean_value, "mean_value")
        require_sha256(self.aggregate_hash, "aggregate_hash")


def aggregate_roots(measurements: tuple[RootMeasurement, ...]) -> tuple[RootAggregate, ...]:
    if not isinstance(measurements, tuple) or not measurements:
        raise ValueError("measurements must be a non-empty tuple")
    groups: dict[tuple[str, str], list[int]] = {}
    for measurement in measurements:
        if not isinstance(measurement, RootMeasurement):
            raise ValueError("measurements must contain RootMeasurement values")
        groups.setdefault((measurement.family_id, measurement.arm_label), []).append(measurement.value)
    aggregates: list[RootAggregate] = []
    for (family_id, arm_label), values in sorted(groups.items()):
        count = len(values)
        mean = sum(values) // count
        digest = stable_digest_hex(
            "exp09-root-aggregate-v1",
            family_id,
            arm_label,
            count,
            mean,
            *sorted(values),
        )
        aggregates.append(
            RootAggregate(
                schema_version=ROOT_AGGREGATE_SCHEMA_VERSION,
                family_id=family_id,
                arm_label=arm_label,
                count=count,
                mean_value=mean,
                aggregate_hash=digest,
            )
        )
    return tuple(aggregates)


@dataclass(frozen=True, slots=True)
class BootstrapCi:
    schema_version: str
    statistic_name: str
    estimate: int
    lower: int
    upper: int
    resample_count: int
    seed: int

    def __post_init__(self) -> None:
        if self.schema_version != BOOTSTRAP_CI_SCHEMA_VERSION:
            raise ValueError("unsupported bootstrap-ci schema version")
        require_identifier(self.statistic_name, "statistic_name")
        require_non_negative_int(self.estimate, "estimate")
        require_non_negative_int(self.lower, "lower")
        require_non_negative_int(self.upper, "upper")
        require_positive_int(self.resample_count, "resample_count")
        require_non_negative_int(self.seed, "seed")
        if self.lower > self.estimate or self.estimate > self.upper:
            raise ValueError("bootstrap interval must contain the estimate")


def cluster_bootstrap_mean_ci(values: tuple[int, ...], *, resample_count: int, seed: int) -> BootstrapCi:
    if not values:
        raise ValueError("values must not be empty")
    require_positive_int(resample_count, "resample_count")
    require_non_negative_int(seed, "seed")
    samples: list[int] = []
    state = seed or 1
    for _ in range(resample_count):
        total = 0
        for _ in values:
            state = (1103515245 * state + 12345) % (2**31)
            total += values[state % len(values)]
        samples.append(total // len(values))
    ordered = sorted(samples)
    estimate = sum(values) // len(values)
    lower = min(estimate, ordered[0])
    upper = max(estimate, ordered[-1])
    return BootstrapCi(
        schema_version=BOOTSTRAP_CI_SCHEMA_VERSION,
        statistic_name="cluster_bootstrap_mean",
        estimate=estimate,
        lower=lower,
        upper=upper,
        resample_count=resample_count,
        seed=seed,
    )


def exact_sign_flip_p_value(differences: tuple[int, ...]) -> int:
    if not differences:
        raise ValueError("differences must not be empty")
    observed = abs(sum(differences))
    total = 1 << len(differences)
    extreme = 0
    for mask in range(total):
        signed = 0
        for index, value in enumerate(differences):
            signed += value if mask & (1 << index) else -value
        if abs(signed) >= observed:
            extreme += 1
    return extreme * 1_000_000 // total


@dataclass(frozen=True, slots=True)
class HolmResult:
    schema_version: str
    hypothesis_id: str
    raw_p_ppm: int
    adjusted_p_ppm: int

    def __post_init__(self) -> None:
        if self.schema_version != HOLM_RESULT_SCHEMA_VERSION:
            raise ValueError("unsupported holm-result schema version")
        require_identifier(self.hypothesis_id, "hypothesis_id")
        for field_name in ("raw_p_ppm", "adjusted_p_ppm"):
            require_non_negative_int(getattr(self, field_name), field_name)
            if getattr(self, field_name) > 1_000_000:
                raise ValueError(f"{field_name} cannot exceed 1,000,000")


def holm_adjust(p_values_ppm: tuple[tuple[str, int], ...]) -> tuple[HolmResult, ...]:
    if not p_values_ppm:
        raise ValueError("p_values_ppm must not be empty")
    ordered = sorted(p_values_ppm, key=lambda item: (item[1], item[0]))
    running = 0
    adjusted_by_id: dict[str, int] = {}
    family_size = len(ordered)
    for rank, (hypothesis_id, raw) in enumerate(ordered):
        require_identifier(hypothesis_id, "hypothesis_id")
        require_non_negative_int(raw, "raw_p_ppm")
        adjusted = min(1_000_000, raw * (family_size - rank))
        running = max(running, adjusted)
        adjusted_by_id[hypothesis_id] = running
    return tuple(
        HolmResult(
            schema_version=HOLM_RESULT_SCHEMA_VERSION,
            hypothesis_id=hypothesis_id,
            raw_p_ppm=raw,
            adjusted_p_ppm=adjusted_by_id[hypothesis_id],
        )
        for hypothesis_id, raw in p_values_ppm
    )


def max_t_statistic(contrast_statistics: tuple[int, ...]) -> int:
    if not contrast_statistics:
        raise ValueError("contrast_statistics must not be empty")
    return max(abs(value) for value in contrast_statistics)


def rmst_from_survival(survival_ppm_by_interval: tuple[tuple[int, int], ...]) -> int:
    if not survival_ppm_by_interval:
        raise ValueError("survival intervals must not be empty")
    total = 0
    for duration_us, survival_ppm in survival_ppm_by_interval:
        require_positive_int(duration_us, "duration_us")
        require_non_negative_int(survival_ppm, "survival_ppm")
        if survival_ppm > 1_000_000:
            raise ValueError("survival_ppm cannot exceed 1,000,000")
        total += duration_us * survival_ppm // 1_000_000
    return total


@dataclass(frozen=True, slots=True)
class BlindedLabelMap:
    schema_version: str
    mapping_hash: str
    entries: tuple[tuple[str, str], ...]

    @classmethod
    def create(cls, method_hashes: tuple[str, ...]) -> "BlindedLabelMap":
        if not method_hashes:
            raise ValueError("method_hashes must not be empty")
        for digest in method_hashes:
            require_sha256(digest, "method_hash")
        entries = tuple((f"L{index:02d}", digest) for index, digest in enumerate(sorted(method_hashes)))
        mapping_hash = blinded_mapping_hash(entries)
        return cls(
            schema_version=BLINDED_LABEL_MAP_SCHEMA_VERSION,
            mapping_hash=mapping_hash,
            entries=entries,
        )

    @property
    def public_labels(self) -> tuple[str, ...]:
        return tuple(label for label, _ in self.entries)

    def public_export(self) -> "PublicBlindingExport":
        return PublicBlindingExport(
            schema_version=PUBLIC_BLINDING_EXPORT_SCHEMA_VERSION,
            mapping_hash=self.mapping_hash,
            public_labels=self.public_labels,
        )

    def __post_init__(self) -> None:
        if self.schema_version != BLINDED_LABEL_MAP_SCHEMA_VERSION:
            raise ValueError("unsupported blinded-label-map schema version")
        require_sha256(self.mapping_hash, "mapping_hash")
        if not isinstance(self.entries, tuple) or not self.entries:
            raise ValueError("entries must be a non-empty tuple")
        labels = tuple(label for label, _ in self.entries)
        if len(labels) != len(set(labels)):
            raise ValueError("blind labels must be unique")
        method_hashes = tuple(digest for _, digest in self.entries)
        if len(method_hashes) != len(set(method_hashes)):
            raise ValueError("method hashes must map one-to-one to blind labels")
        for label, digest in self.entries:
            require_identifier(label, "blind_label")
            require_sha256(digest, "method_hash")
        if self.mapping_hash != blinded_mapping_hash(self.entries):
            raise ValueError("mapping_hash does not bind private blind mapping")


def blinded_mapping_hash(entries: tuple[tuple[str, str], ...]) -> str:
    return stable_digest_hex(
        BLINDED_MAPPING_HASH_DOMAIN,
        len(entries),
        *(part for entry in entries for part in entry),
    )


@dataclass(frozen=True, slots=True)
class PublicBlindingExport:
    schema_version: str
    mapping_hash: str
    public_labels: tuple[str, ...]

    def __post_init__(self) -> None:
        if self.schema_version != PUBLIC_BLINDING_EXPORT_SCHEMA_VERSION:
            raise ValueError("unsupported public-blinding-export schema version")
        require_sha256(self.mapping_hash, "mapping_hash")
        if not isinstance(self.public_labels, tuple) or not self.public_labels:
            raise ValueError("public_labels must be a non-empty tuple")
        if len(self.public_labels) != len(set(self.public_labels)):
            raise ValueError("public blind labels must be unique")
        for label in self.public_labels:
            require_identifier(label, "public blind label")
            if len(label) == 64 and all(character in "0123456789abcdefABCDEF" for character in label):
                raise ValueError("public blinding export must not expose method hashes")


def margin_gate_status(
    *,
    signed_effect: int,
    required_margin: int | None,
    improvement_direction: str,
) -> MarginGateStatus:
    _require_signed_int(signed_effect, "signed_effect")
    if required_margin is None:
        return MarginGateStatus.NOT_ASSESSABLE_NO_MARGIN
    require_positive_int(required_margin, "required_margin")
    if improvement_direction == "DECREASE":
        return MarginGateStatus.PASSED if signed_effect <= -required_margin else MarginGateStatus.FAILED
    if improvement_direction == "INCREASE":
        return MarginGateStatus.PASSED if signed_effect >= required_margin else MarginGateStatus.FAILED
    raise ValueError("improvement_direction must be DECREASE or INCREASE")


@dataclass(frozen=True, slots=True)
class DecisionTableRow:
    schema_version: str
    gate_id: str
    family_id: str
    coverage_level: CoverageLevel
    final_result_filled: bool

    def __post_init__(self) -> None:
        if self.schema_version != DECISION_TABLE_SCHEMA_VERSION:
            raise ValueError("unsupported decision-table schema version")
        require_identifier(self.gate_id, "gate_id")
        require_identifier(self.family_id, "family_id")
        if not isinstance(self.coverage_level, CoverageLevel):
            raise ValueError("coverage_level must be a CoverageLevel")
        if self.final_result_filled is not False:
            raise ValueError("C13 decision table schema cannot carry final locked results")


@dataclass(frozen=True, slots=True)
class ManuscriptLocator:
    schema_version: str
    document_id: str
    section_id: str
    line_start: int

    def __post_init__(self) -> None:
        if self.schema_version != MANUSCRIPT_LOCATOR_SCHEMA_VERSION:
            raise ValueError("unsupported manuscript-locator schema version")
        require_identifier(self.document_id, "document_id")
        require_identifier(self.section_id, "section_id")
        require_positive_int(self.line_start, "line_start")


@dataclass(frozen=True, slots=True)
class StableManuscriptLocator:
    schema_version: str
    document_id: str
    document_hash: str
    section_id: str
    anchor_id: str
    line_start: int

    def __post_init__(self) -> None:
        if self.schema_version != STABLE_MANUSCRIPT_LOCATOR_SCHEMA_VERSION:
            raise ValueError("unsupported stable-manuscript-locator schema version")
        require_identifier(self.document_id, "document_id")
        require_sha256(self.document_hash, "document_hash")
        require_identifier(self.section_id, "section_id")
        require_identifier(self.anchor_id, "anchor_id")
        require_positive_int(self.line_start, "line_start")


@dataclass(frozen=True, slots=True)
class ReviewerEvidenceRecord:
    schema_version: str
    review_comment_id: str
    code_locator: str
    test_locator: str
    evidence_locator: str
    result_status: str
    manuscript_locator: StableManuscriptLocator
    response_locator: str
    limitation_or_claim_gate: str
    final_result_filled: bool

    def __post_init__(self) -> None:
        if self.schema_version != REVIEWER_EVIDENCE_RECORD_SCHEMA_VERSION:
            raise ValueError("unsupported reviewer-evidence-record schema version")
        require_identifier(self.review_comment_id, "review_comment_id")
        if self.review_comment_id not in CANONICAL_REVIEW_COMMENT_IDS:
            raise ValueError("unknown canonical review_comment_id")
        for field_name in ("code_locator", "test_locator", "evidence_locator", "response_locator"):
            require_safe_relative_path(getattr(self, field_name), field_name)
        if self.result_status not in REVIEWER_EVIDENCE_RESULT_STATUSES:
            raise ValueError("unsupported reviewer evidence result_status")
        if not isinstance(self.manuscript_locator, StableManuscriptLocator):
            raise ValueError("manuscript_locator must be a StableManuscriptLocator")
        require_identifier(self.limitation_or_claim_gate, "limitation_or_claim_gate")
        if self.final_result_filled is not False:
            raise ValueError("C13 reviewer evidence cannot carry final results")


@dataclass(frozen=True, slots=True)
class ReviewerEvidenceBundle:
    schema_version: str
    records: tuple[ReviewerEvidenceRecord, ...]

    def __post_init__(self) -> None:
        if self.schema_version != REVIEWER_EVIDENCE_BUNDLE_SCHEMA_VERSION:
            raise ValueError("unsupported reviewer-evidence-bundle schema version")
        if not isinstance(self.records, tuple) or not self.records:
            raise ValueError("records must be a non-empty tuple")
        if not all(isinstance(record, ReviewerEvidenceRecord) for record in self.records):
            raise ValueError("records must contain ReviewerEvidenceRecord values")
        ids = tuple(record.review_comment_id for record in self.records)
        if len(ids) != len(set(ids)):
            raise ValueError("duplicate review_comment_id")
        if set(ids) != set(CANONICAL_REVIEW_COMMENT_IDS):
            raise ValueError("missing canonical review_comment_id")
