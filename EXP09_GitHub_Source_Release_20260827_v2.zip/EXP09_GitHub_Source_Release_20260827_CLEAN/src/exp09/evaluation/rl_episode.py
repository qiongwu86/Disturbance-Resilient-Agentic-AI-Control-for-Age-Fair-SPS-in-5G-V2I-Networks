"""Stepwise C12 episode adapter over the frozen EXP09 plant and receiver ledger."""

from dataclasses import dataclass

from exp09.baselines.rl_environment import (
    CausalWorstUserAoiReward,
    EncodedObservation,
    decode_action,
    encode_observation,
)
from exp09.contracts.actions import (
    ACTION_SCHEMA_VERSION,
    ActionKind,
    ControlAction,
    ControlOpportunity,
)
from exp09.contracts.observable import MeasurementDeliveryEvent, ObservableFrame
from exp09.contracts.tape import DisturbanceTape
from exp09.measurement.receiver_ledger import (
    MEASUREMENT_DELAY_US,
    SUMMARY_PERIOD_US,
    ObservationAdapter,
    ReceiverMeasurementLedger,
)
from exp09.plant.plant import DiscreteEventSPSPlant
from exp09.plant.state import PlantSnapshot

from .disturbance_tape import validate_primary_tape
from .metrics_accumulator import CaseMetrics, compute_case_metrics


@dataclass(frozen=True, slots=True)
class EpisodeStep:
    observation: EncodedObservation
    frame: ObservableFrame
    opportunity: ControlOpportunity
    reward: float
    done: bool


class C12Episode:
    """Expose only causally delivered receiver evidence at control opportunities."""

    def __init__(
        self,
        tape: DisturbanceTape,
        *,
        max_decisions: int,
        tape_prevalidated_by_frozen_builder: bool = False,
    ) -> None:
        if not tape_prevalidated_by_frozen_builder:
            validate_primary_tape(tape)
        if max_decisions <= 0:
            raise ValueError("max_decisions must be positive")
        self._tape = tape
        self._max_decisions = int(max_decisions)
        self._plant = DiscreteEventSPSPlant()
        self._ledger = ReceiverMeasurementLedger()
        self._adapter = ObservationAdapter()
        self._last_snapshot = self._plant.reset(tape)
        self._pending_step: EpisodeStep | None = None
        self._decisions = 0
        self._illegal_actions = 0
        self._carried_reward = 0.0
        self._reward = CausalWorstUserAoiReward(
            start_time_us=int(tape.analysis_origin_simulation_time_us),
            end_time_us=int(tape.simulation_end_us),
        )

    @property
    def decisions(self) -> int:
        return self._decisions

    @property
    def illegal_actions(self) -> int:
        return self._illegal_actions

    @property
    def reward_accumulator(self) -> CausalWorstUserAoiReward:
        return self._reward

    @property
    def snapshot(self) -> PlantSnapshot:
        return self._last_snapshot

    def validation_metrics(self) -> CaseMetrics:
        if self._last_snapshot.time_us != int(self._tape.simulation_end_us):
            raise RuntimeError("validation metrics require a completed episode")
        return compute_case_metrics(
            self._tape,
            self._last_snapshot.trace,
            observable_history=(
                *self._ledger.snapshot().packet_observations,
                *self._ledger.snapshot().identity_events,
            ),
        )

    def reset(self) -> EpisodeStep:
        if self._pending_step is not None or self._decisions:
            raise RuntimeError("C12Episode instances are single-use")
        step = self._advance_to_decision(reward=0.0)
        if step is None:
            raise RuntimeError("training tape produced no control opportunity")
        self._carried_reward = step.reward
        initial = EpisodeStep(
            observation=step.observation,
            frame=step.frame,
            opportunity=step.opportunity,
            reward=0.0,
            done=False,
        )
        self._pending_step = initial
        return initial

    def step(self, action_index: int) -> EpisodeStep:
        current = self._pending_step
        if current is None or current.done:
            raise RuntimeError("episode has no open control opportunity")
        try:
            action = decode_action(action_index, current.opportunity)
        except ValueError:
            self._illegal_actions += 1
            raise
        self._last_snapshot = self._plant.apply(current.opportunity, action)
        self._decisions += 1
        if self._decisions >= self._max_decisions:
            reward = self._carried_reward + self._finish_reward()
            self._carried_reward = 0.0
            terminal = EpisodeStep(
                observation=current.observation,
                frame=current.frame,
                opportunity=current.opportunity,
                reward=reward,
                done=True,
            )
            self._pending_step = terminal
            return terminal
        step = self._advance_to_decision(reward=0.0)
        if step is None:
            reward = self._carried_reward + self._finish_reward()
            self._carried_reward = 0.0
            terminal = EpisodeStep(
                observation=current.observation,
                frame=current.frame,
                opportunity=current.opportunity,
                reward=reward,
                done=True,
            )
            self._pending_step = terminal
            return terminal
        delivered = EpisodeStep(
            observation=step.observation,
            frame=step.frame,
            opportunity=step.opportunity,
            reward=self._carried_reward + step.reward,
            done=False,
        )
        self._carried_reward = 0.0
        self._pending_step = delivered
        return delivered

    def _advance_to_decision(self, *, reward: float) -> EpisodeStep | None:
        end_us = int(self._tape.simulation_end_us)
        accumulated_reward = reward
        while self._last_snapshot.time_us < end_us:
            previous_time_us = self._last_snapshot.time_us
            result = self._plant.advance_until(end_us)
            self._last_snapshot = result.snapshot
            boundary_us = self._last_snapshot.time_us
            accumulated_reward += self._ingest_measurements(
                result.measurement_delivery_delta, boundary_us
            )
            if not result.opportunities and boundary_us < end_us and boundary_us <= previous_time_us:
                raise RuntimeError("plant made no forward progress")
            if result.opportunities:
                opportunity = result.opportunities[0]
                frame = self._latest_frame(int(opportunity.time_us))
                return EpisodeStep(
                    observation=encode_observation(frame, opportunity),
                    frame=frame,
                    opportunity=opportunity,
                    reward=accumulated_reward,
                    done=False,
                )
        return None

    def _ingest_measurements(
        self,
        events: tuple[MeasurementDeliveryEvent, ...],
        boundary_us: int,
    ) -> float:
        for event in events:
            self._ledger.ingest_delivery(event)
        reward = self._reward.ingest(events, boundary_us)
        return reward

    def _latest_frame(self, opportunity_us: int) -> ObservableFrame:
        latest_arrived_cutoff_us = (
            (opportunity_us - MEASUREMENT_DELAY_US) // SUMMARY_PERIOD_US
        ) * SUMMARY_PERIOD_US
        if latest_arrived_cutoff_us < int(self._tape.simulation_start_us):
            raise RuntimeError("no summary has arrived before the control opportunity")
        summary = self._ledger.summarize(
            latest_arrived_cutoff_us,
            window_start_us=int(self._tape.simulation_start_us),
        )
        return self._adapter.build(summary, opportunity_us)

    def _finish_reward(self) -> float:
        end_us = int(self._tape.simulation_end_us)
        reward = 0.0
        while self._last_snapshot.time_us < end_us:
            result = self._plant.advance_until(end_us)
            self._last_snapshot = result.snapshot
            reward += self._ingest_measurements(
                result.measurement_delivery_delta,
                self._last_snapshot.time_us,
            )
            if result.opportunities:
                opportunity = result.opportunities[0]
                self._last_snapshot = self._plant.apply(
                    opportunity,
                    ControlAction(
                        schema_version=ACTION_SCHEMA_VERSION,
                        opportunity_id=opportunity.opportunity_id,
                        kind=ActionKind.RETAIN_AT_EXPIRY,
                        target_rri_us=None,
                    ),
                )
        return reward
