"""Unified causal Controller adapters for C14.1 preflight qualification."""

from __future__ import annotations

from dataclasses import dataclass
from dataclasses import asdict
import json
from pathlib import Path
from typing import Any, Protocol

from exp09.artifacts.canonical import canonical_sha256
from exp09.baselines.action_api import (
    AoiAwareHeuristicActionPolicy,
    BASELINE_ACTION_REQUEST_SCHEMA_VERSION,
    BaselineActionRequest,
    GreedyOneActionPolicy,
    KeepSanityActionPolicy,
    NominalMpcActionPolicy,
)
from exp09.baselines.rl_environment import (
    ACTION_COUNT,
    GRAPH_NODE_FEATURE_COUNT,
    VECTOR_OBSERVATION_COUNT,
    decode_action,
    encode_observation,
)
from exp09.baselines.rl_models import C12QAgent, FROZEN_AGENT_CONFIGS, load_checkpoint_payload
from exp09.control.calibration import (
    RESIDUAL_CALIBRATION_RECORD_SCHEMA_VERSION,
    ResidualCalibrationRecord,
)
from exp09.control.candidate_generator import CandidateSet, ExpiryCandidateGenerator
from exp09.control.risk_gate import RiskGate
from exp09.control.robust_selector import RobustScenarioEvaluation, RobustSelector
from exp09.contracts.actions import ControlAction, ControlOpportunity, control_action_fingerprint
from exp09.contracts.controller import (
    COMMITMENT_SCHEMA_VERSION,
    CommitmentRecord,
    ControllerResetContext,
)
from exp09.contracts.determinism import stable_digest_hex
from exp09.contracts.ids import ProgramId, RequestId
from exp09.contracts.observable import ObservableCounterKind, ObservableFrame
from exp09.contracts.supervisor import (
    PROGRAM_PROPOSAL_SCHEMA_VERSION,
    ProgramProposal,
    RationaleCode,
    TransitionId,
)
from exp09.contracts.time import DurationUs, SimTimeUs
from exp09.model.approximate import ApproximateSPSModel, ApproximateSPSModelConfig
from exp09.model.interfaces import MODEL_TRANSITION_BUDGET_SCHEMA_VERSION, ModelTransitionBudget
from exp09.model.scenarios import ForecastBatchConfig, ForecastBatchFactory
from exp09.model.state_estimator import ControllerStateEstimator
from exp09.supervisor.programs import (
    PROGRAM_LIBRARY_SCHEMA_VERSION,
    PROGRAM_STATE_SCHEMA_VERSION,
    RECOVERY_PROGRAM_SCHEMA_VERSION,
    ProgramLibrary,
    ProgramOrchestrator,
    ProgramState,
    RecoveryProgram,
    eligible_proposals,
)
from exp09.supervisor.providers import (
    EVIDENCE_BUNDLE_SCHEMA_VERSION,
    PROVIDER_CONFIG_SCHEMA_VERSION,
    PROVIDER_RESPONSE_SCHEMA_VERSION,
    EvidenceBundle,
    ProviderConfig,
    ProviderKind,
    ProviderRequest,
    ProviderResponse,
    RuleProvider,
    TunedNonLLMProvider,
    canonical_provider_request,
    provider_response_hash,
)

from .c14_offline_cache import AuditableOfflineCache, C14OfflineCacheError

METHODS = (
    "Full",
    "RMPC_SameEvaluator",
    "Rule_SameStack",
    "TunedNonLLM_SameStack",
    "Plain_LLM",
    "DQN",
    "DQN_Strong",
    "GNN_DDQN",
    "KEEP_sanity",
    "AoI_aware_heuristic",
    "Greedy_1",
    "Nominal_MPC",
)
RL_METHODS = ("DQN", "DQN_Strong", "GNN_DDQN")
CONFIG_SCHEMA_VERSION = "exp09-c14-1-method-config-freeze-v2"
PLAIN_INPUT_SCHEMA_VERSION = "exp09-c14-1-plain-llm-input-v1"
PLAIN_OUTPUT_SCHEMA_VERSION = "exp09-c14-1-plain-llm-output-v1"
PLAIN_REQUEST_HASH_DOMAIN = "exp09-c14-1-plain-llm-request-v1"


class C14ControllerConfigurationError(ValueError):
    """Raised when a frozen adapter/config/checkpoint binding is invalid."""


class OfflineFullProvider(Protocol):
    def propose(self, request: ProviderRequest) -> ProviderResponse: ...


@dataclass(frozen=True, slots=True)
class _ModelDecisionEvidence:
    candidates: CandidateSet
    rollouts: tuple[Any, ...]
    robust: tuple[RobustScenarioEvaluation, ...]
    gated_action: ControlAction
    selected_risk_ppm: int


class _ControllerBase:
    def __init__(self, method_id: str, method_config_hash: str) -> None:
        if method_id not in METHODS:
            raise C14ControllerConfigurationError("unknown C14.1 method")
        self.method_id = method_id
        self.method_config_hash = method_config_hash
        self._was_reset = False

    def reset(self, context: ControllerResetContext) -> None:
        if not isinstance(context, ControllerResetContext):
            raise ValueError("context must be a ControllerResetContext")
        # Run/root identities are deliberately not retained or exposed to decide().
        self._was_reset = True

    def _commit(self, frame: ObservableFrame, action: ControlAction) -> CommitmentRecord:
        if not self._was_reset:
            raise RuntimeError("controller must be reset before decide")
        return CommitmentRecord(
            schema_version=COMMITMENT_SCHEMA_VERSION,
            observation_hash=canonical_sha256(
                frame, expected_schema_version=frame.schema_version
            ),
            action=action,
        )


class _FrozenModelStack:
    def __init__(self, config: dict[str, Any]) -> None:
        model = config["shared_model"]
        self.horizon_us = int(model["horizon_us"])
        self.transition_cap = int(model["transitions_per_decision"])
        self.risk_threshold_ppm = int(config["risk_gate"]["risk_threshold_ppm"])
        self._model_config = ApproximateSPSModelConfig.create(
            transition_step_us=int(model["transition_step_us"]),
            packet_period_us=int(model["packet_period_us"]),
            logical_subchannel_count=int(model["logical_subchannel_count"]),
            load_scale_ppm=int(model["load_scale_ppm"]),
            forecast_load_scales_ppm=tuple(model["forecast_load_scales_ppm"]),
        )
        if self._model_config.config_hash != model["model_config_hash"]:
            raise C14ControllerConfigurationError("shared model config hash mismatch")
        self._model = ApproximateSPSModel(self._model_config)
        self._forecast = ForecastBatchFactory(
            ForecastBatchConfig.create(
                model_config_hash=self._model_config.config_hash,
                load_scales_ppm=tuple(model["forecast_load_scales_ppm"]),
            )
        )

    def evaluate(
        self, frame: ObservableFrame, opportunity: ControlOpportunity
    ) -> _ModelDecisionEvidence:
        state = ControllerStateEstimator().estimate(frame, opportunity)
        candidates = ExpiryCandidateGenerator().generate(frame, opportunity)
        scenarios = self._forecast.build(state)
        budget = ModelTransitionBudget(
            schema_version=MODEL_TRANSITION_BUDGET_SCHEMA_VERSION,
            budget_id=stable_digest_hex(
                "exp09-c14-1-model-budget-v1",
                frame.summary_payload_hash,
                str(opportunity.opportunity_id),
            )[:32],
            total_transitions=self.transition_cap,
            consumed_transitions=0,
        )
        rollouts: list[Any] = []
        for action in candidates.actions:
            result = self._model.rollout(
                frame,
                state,
                action,
                scenarios,
                DurationUs(self.horizon_us),
                budget,
            )
            budget = result.budget_after
            rollouts.extend(result.evaluations)
        if budget.consumed_transitions != self.transition_cap:
            raise RuntimeError("frozen model transition charge mismatch")
        robust = tuple(RobustScenarioEvaluation.from_rollout(item) for item in rollouts)
        selection = RobustSelector().select(candidates, robust)
        calibration = ResidualCalibrationRecord(
            schema_version=RESIDUAL_CALIBRATION_RECORD_SCHEMA_VERSION,
            calibration_id="c14-1-structural-risk-threshold",
            threshold_ppm=self.risk_threshold_ppm,
            reachable_min_ppm=0,
            reachable_max_ppm=1_000_000,
            source="c08-constructed-reachability-design-validation-only",
        )
        gated = RiskGate().evaluate(
            selection=selection,
            candidate_set=candidates,
            evaluations=robust,
            calibration=calibration,
        )
        return _ModelDecisionEvidence(
            candidates=candidates,
            rollouts=tuple(rollouts),
            robust=robust,
            gated_action=gated.action,
            selected_risk_ppm=selection.worst_case_risk_ppm,
        )


class BaselineControllerAdapter(_ControllerBase):
    _POLICIES = {
        "KEEP_sanity": KeepSanityActionPolicy,
        "AoI_aware_heuristic": AoiAwareHeuristicActionPolicy,
        "Greedy_1": GreedyOneActionPolicy,
        "Nominal_MPC": NominalMpcActionPolicy,
    }

    def __init__(self, method_id: str, method_config_hash: str, config: dict[str, Any]) -> None:
        super().__init__(method_id, method_config_hash)
        self._policy = self._POLICIES[method_id]()
        self._model_stack = (
            _FrozenModelStack(config) if method_id in {"Greedy_1", "Nominal_MPC"} else None
        )

    def decide(
        self, frame: ObservableFrame, opportunity: ControlOpportunity
    ) -> CommitmentRecord:
        if self._model_stack is None:
            candidates = ExpiryCandidateGenerator().generate(frame, opportunity)
            rollouts: tuple[Any, ...] = ()
        else:
            evidence = self._model_stack.evaluate(frame, opportunity)
            candidates = evidence.candidates
            rollouts = evidence.rollouts
        decision = self._policy.select(
            BaselineActionRequest(
                schema_version=BASELINE_ACTION_REQUEST_SCHEMA_VERSION,
                method_id=self.method_id,
                frame=frame,
                opportunity=opportunity,
                candidate_set=candidates,
                rollouts=rollouts,
            )
        )
        return self._commit(frame, decision.action)


class RmpcControllerAdapter(_ControllerBase):
    def __init__(self, method_config_hash: str, config: dict[str, Any]) -> None:
        super().__init__("RMPC_SameEvaluator", method_config_hash)
        self._model_stack = _FrozenModelStack(config)

    def decide(
        self, frame: ObservableFrame, opportunity: ControlOpportunity
    ) -> CommitmentRecord:
        evidence = self._model_stack.evaluate(frame, opportunity)
        return self._commit(frame, evidence.gated_action)


class _AuditableFullProvider:
    def __init__(self, cache: AuditableOfflineCache) -> None:
        if cache.method_id != "Full":
            raise C14ControllerConfigurationError("Full requires a Full offline cache")
        self._cache = cache

    def propose(self, request: ProviderRequest) -> ProviderResponse:
        raw = self._cache.response_for(request.request_hash)
        proposal_raw = raw.get("proposal")
        if not isinstance(proposal_raw, dict):
            raise C14OfflineCacheError("Full cache response has no proposal")
        try:
            target = proposal_raw.get("target_program_id")
            proposal = ProgramProposal(
                schema_version=PROGRAM_PROPOSAL_SCHEMA_VERSION,
                transition_id=TransitionId(proposal_raw["transition_id"]),
                target_program_id=None if target is None else ProgramId(target),
                rationale_code=RationaleCode(proposal_raw["rationale_code"]),
            )
            response = ProviderResponse(
                schema_version=PROVIDER_RESPONSE_SCHEMA_VERSION,
                request_hash=request.request_hash,
                proposal=proposal,
                response_hash=raw["response_hash"],
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise C14OfflineCacheError("Full cache response schema is invalid") from exc
        if response.response_hash != provider_response_hash(request.request_hash, proposal):
            raise C14OfflineCacheError("Full cache response hash mismatch")
        return response


class SupervisorControllerAdapter(_ControllerBase):
    def __init__(
        self,
        method_id: str,
        method_config_hash: str,
        config: dict[str, Any],
        *,
        full_cache: AuditableOfflineCache | None = None,
    ) -> None:
        if method_id not in {"Full", "Rule_SameStack", "TunedNonLLM_SameStack"}:
            raise C14ControllerConfigurationError("invalid same-stack supervisor method")
        super().__init__(method_id, method_config_hash)
        self._config = config
        self._model_stack = _FrozenModelStack(config)
        supervisor = config["same_stack_supervisor"]
        self._detector_threshold_ppm = int(supervisor["detector_threshold_ppm"])
        self._tuned_threshold_ppm = int(supervisor["tuned_non_llm_threshold_ppm"])
        self._initial_budget = int(supervisor["initial_program_budget_units"])
        self._library = _program_library(supervisor)
        self._balanced_id = ProgramId(supervisor["balanced_program_id"])
        self._protect_id = ProgramId(supervisor["protect_program_id"])
        self._namespace = str(supervisor["full_cache_namespace"])
        self._provider_config = ProviderConfig(
            schema_version=PROVIDER_CONFIG_SCHEMA_VERSION,
            provider_id=f"c14-1-{method_id.lower()}",
            provider_kind={
                "Full": ProviderKind.OFFLINE_LLM_REPLAY,
                "Rule_SameStack": ProviderKind.RULE,
                "TunedNonLLM_SameStack": ProviderKind.TUNED_NON_LLM,
            }[method_id],
            program_library_hash=self._library.library_hash,
            request_budget_units=1,
            retry_budget=0,
            prompt_schema_hash=supervisor["full_provider_protocol_sha256"],
        )
        if method_id == "Full":
            if full_cache is None:
                raise C14OfflineCacheError(
                    "Full is blocked until a provenance-bound, coverage-complete cache is supplied"
                )
            self._full_provider: OfflineFullProvider | None = _AuditableFullProvider(full_cache)
        else:
            self._full_provider = None
        self._program_state = self._initial_state()

    def reset(self, context: ControllerResetContext) -> None:
        super().reset(context)
        self._program_state = self._initial_state()

    def decide(
        self, frame: ObservableFrame, opportunity: ControlOpportunity
    ) -> CommitmentRecord:
        evidence = self._model_stack.evaluate(frame, opportunity)
        bundle = _supervisor_evidence(
            frame,
            opportunity,
            selected_risk_ppm=evidence.selected_risk_ppm,
            detector_threshold_ppm=self._detector_threshold_ppm,
        )
        proposal = self._provider_proposal(bundle)
        proposal = self._normalize_proposal(proposal, opportunity)
        record = ProgramOrchestrator().apply_provider_proposal(
            library=self._library,
            state=self._program_state,
            proposal=proposal,
            now_us=opportunity.time_us,
            trigger_active=bundle.detector_active,
        )
        self._program_state = record.transition_record.next_state
        if self._program_state.current_program_id == self._balanced_id:
            action = evidence.gated_action
        elif self._program_state.current_program_id == self._protect_id:
            action = min(
                (item for item in evidence.candidates.actions if item.target_rri_us is not None),
                key=lambda item: int(item.target_rri_us or 0),
            )
        else:  # pragma: no cover - ProgramLibrary validation makes this unreachable
            raise RuntimeError("unknown frozen recovery program")
        return self._commit(frame, action)

    def _provider_proposal(self, evidence: EvidenceBundle) -> ProgramProposal:
        if self.method_id == "Rule_SameStack":
            return RuleProvider().propose(library=self._library, evidence=evidence)
        if self.method_id == "TunedNonLLM_SameStack":
            return TunedNonLLMProvider(
                risk_threshold_ppm=self._tuned_threshold_ppm
            ).propose(library=self._library, evidence=evidence)
        assert self._full_provider is not None
        request = canonical_provider_request(
            request_id=RequestId(
                stable_digest_hex(
                    "exp09-c14-1-provider-request-id-v1",
                    evidence.evidence_hash,
                    self._library.library_hash,
                )[:32]
            ),
            config=self._provider_config,
            evidence=evidence,
            namespace=self._namespace,
            attempt_ordinal=0,
        )
        return self._full_provider.propose(request).proposal

    def _normalize_proposal(
        self, proposal: ProgramProposal, opportunity: ControlOpportunity
    ) -> ProgramProposal:
        eligible = eligible_proposals(
            library=self._library,
            state=self._program_state,
            now_us=opportunity.time_us,
            trigger_active=True,
        )
        current = self._library.require_program(self._program_state.current_program_id)
        age_us = int(opportunity.time_us) - int(self._program_state.current_started_us)
        if age_us >= current.ttl_us and self._program_state.current_program_id != self._balanced_id:
            return ProgramProposal(
                schema_version=PROGRAM_PROPOSAL_SCHEMA_VERSION,
                transition_id=TransitionId.RETURN_BALANCED,
                target_program_id=self._balanced_id,
                rationale_code=RationaleCode.EVIDENCE_SUPPORTED_TRANSITION,
            )
        if proposal.transition_id is TransitionId.HOLD:
            return ProgramProposal(
                schema_version=PROGRAM_PROPOSAL_SCHEMA_VERSION,
                transition_id=TransitionId.HOLD,
                target_program_id=self._program_state.current_program_id,
                rationale_code=proposal.rationale_code,
            )
        if (
            proposal.transition_id is TransitionId.SWITCH
            and proposal.target_program_id == self._program_state.current_program_id
        ):
            return ProgramProposal(
                schema_version=PROGRAM_PROPOSAL_SCHEMA_VERSION,
                transition_id=TransitionId.HOLD,
                target_program_id=self._program_state.current_program_id,
                rationale_code=RationaleCode.HOLD_UNCERTAIN_EVIDENCE,
            )
        allowed = {(item.transition_id, item.target_program_id) for item in eligible}
        if (proposal.transition_id, proposal.target_program_id) not in allowed:
            raise C14OfflineCacheError("provider proposal is not eligible; fallback is forbidden")
        return proposal

    def _initial_state(self) -> ProgramState:
        return ProgramState(
            schema_version=PROGRAM_STATE_SCHEMA_VERSION,
            state_hash="0" * 64,
            current_program_id=self._balanced_id,
            current_started_us=SimTimeUs(0),
            last_transition_us=SimTimeUs(0),
            remaining_budget_units=self._initial_budget,
        ).seal()


class PlainLlmControllerAdapter(_ControllerBase):
    def __init__(
        self,
        method_config_hash: str,
        config: dict[str, Any],
        cache: AuditableOfflineCache,
    ) -> None:
        super().__init__("Plain_LLM", method_config_hash)
        if cache.method_id != "Plain_LLM":
            raise C14ControllerConfigurationError("Plain_LLM requires a Plain_LLM cache")
        self._cache = cache
        self._protocol_sha256 = config["plain_llm"]["protocol_sha256"]
        self._namespace = config["plain_llm"]["cache_namespace"]

    def decide(
        self, frame: ObservableFrame, opportunity: ControlOpportunity
    ) -> CommitmentRecord:
        candidates = ExpiryCandidateGenerator().generate(frame, opportunity)
        action_by_id = {
            control_action_fingerprint(action): action for action in candidates.actions
        }
        input_payload = _plain_input(frame, opportunity, tuple(action_by_id))
        input_sha = canonical_sha256(
            input_payload, expected_schema_version=PLAIN_INPUT_SCHEMA_VERSION
        )
        eligible_sha = stable_digest_hex(
            "exp09-c14-1-eligible-action-set-v1", len(action_by_id), *action_by_id
        )
        request_hash = stable_digest_hex(
            PLAIN_REQUEST_HASH_DOMAIN,
            self._protocol_sha256,
            input_sha,
            eligible_sha,
            self._namespace,
            0,
        )
        response = self._cache.response_for(request_hash)
        selected_id = _validate_plain_response(response, tuple(action_by_id))
        action = action_by_id[selected_id]
        if action.opportunity_id != opportunity.opportunity_id:
            raise C14OfflineCacheError("Plain_LLM selected an action for another opportunity")
        return self._commit(frame, action)


class RlControllerAdapter(_ControllerBase):
    def __init__(
        self,
        method_id: str,
        method_config_hash: str,
        agent: C12QAgent,
        checkpoint_sha256: str,
    ) -> None:
        if method_id not in RL_METHODS:
            raise C14ControllerConfigurationError("invalid RL method")
        super().__init__(method_id, method_config_hash)
        self._agent = agent
        self.checkpoint_sha256 = checkpoint_sha256

    def decide(
        self, frame: ObservableFrame, opportunity: ControlOpportunity
    ) -> CommitmentRecord:
        encoded = encode_observation(frame, opportunity)
        action_index = self._agent.act(encoded, explore=False)
        return self._commit(frame, decode_action(action_index, opportunity))


class C14ControllerFactory:
    """Build only hash-bound adapters; no factory path can train or call a network."""

    def __init__(
        self,
        project_root: Path,
        frozen_config_locator: str,
        *,
        expected_config_sha256: str,
    ) -> None:
        self.project_root = project_root.resolve()
        path = (self.project_root / frozen_config_locator).resolve()
        if not path.is_file() or _file_sha256(path) != expected_config_sha256:
            raise C14ControllerConfigurationError("frozen C14.1 method config binding mismatch")
        self.config = json.loads(path.read_text(encoding="utf-8"))
        if self.config.get("schema_version") != CONFIG_SCHEMA_VERSION:
            raise C14ControllerConfigurationError("unsupported C14.1 method config")
        if tuple(self.config.get("methods", ())) != METHODS:
            raise C14ControllerConfigurationError("frozen method topology mismatch")
        self.config_sha256 = expected_config_sha256

    def build_non_rl(
        self,
        method_id: str,
        *,
        full_cache: AuditableOfflineCache | None = None,
        plain_cache: AuditableOfflineCache | None = None,
    ) -> _ControllerBase:
        if method_id in BaselineControllerAdapter._POLICIES:
            return BaselineControllerAdapter(
                method_id, self.config_sha256, self.config
            )
        if method_id == "RMPC_SameEvaluator":
            return RmpcControllerAdapter(self.config_sha256, self.config)
        if method_id in {"Full", "Rule_SameStack", "TunedNonLLM_SameStack"}:
            return SupervisorControllerAdapter(
                method_id,
                self.config_sha256,
                self.config,
                full_cache=full_cache,
            )
        if method_id == "Plain_LLM":
            if plain_cache is None:
                raise C14OfflineCacheError(
                    "Plain_LLM is blocked until a provenance-bound, coverage-complete cache is supplied"
                )
            return PlainLlmControllerAdapter(
                self.config_sha256, self.config, plain_cache
            )
        raise C14ControllerConfigurationError("method is not a non-RL C14.1 method")

    def build_rl(
        self,
        method_id: str,
        train_seed: int,
        mapping_entry: dict[str, Any],
    ) -> RlControllerAdapter:
        if method_id not in RL_METHODS:
            raise C14ControllerConfigurationError("method is not an RL C14.1 method")
        if mapping_entry.get("method_id") != method_id or mapping_entry.get(
            "train_seed"
        ) != train_seed:
            raise C14ControllerConfigurationError("RL checkpoint mapping identity mismatch")
        if mapping_entry.get("scenario") != "complex":
            raise C14ControllerConfigurationError("C14.1 RL mapping must use complex checkpoint")
        if mapping_entry.get("arms") != ["REFERENCE", "EVENT"]:
            raise C14ControllerConfigurationError("RL checkpoint must be arm-independent")
        path = (self.project_root / mapping_entry["relative_path"]).resolve()
        if _file_sha256(path) != mapping_entry["sha256"]:
            raise C14ControllerConfigurationError("RL checkpoint SHA-256 mismatch")
        import torch

        payload = load_checkpoint_payload(path, map_location=torch.device("cpu"))
        expected_identity = (
            self.config["rl_inference"]["checkpoint_schema_version"],
            self.config["rl_inference"]["enabled_manifest_sha256"],
            method_id,
            "complex",
            train_seed,
            mapping_entry["episode"],
            self.config["rl_inference"]["checkpoint_kind"],
        )
        actual_identity = (
            payload.get("schema_version"),
            payload.get("manifest_hash"),
            payload.get("method_id"),
            payload.get("scenario"),
            payload.get("train_seed"),
            payload.get("episode"),
            payload.get("checkpoint_kind"),
        )
        if actual_identity != expected_identity or payload.get("config") != asdict(
            FROZEN_AGENT_CONFIGS[method_id]
        ):
            raise C14ControllerConfigurationError("RL checkpoint payload identity mismatch")
        agent = C12QAgent(
            config=FROZEN_AGENT_CONFIGS[method_id],
            vector_size=VECTOR_OBSERVATION_COUNT,
            node_feature_count=GRAPH_NODE_FEATURE_COUNT,
            action_count=ACTION_COUNT,
            seed=train_seed,
            device=torch.device("cpu"),
        )
        state = payload.get("inference_state")
        if not isinstance(state, dict):
            raise C14ControllerConfigurationError("RL checkpoint has no inference state")
        _require_finite_checkpoint_state(state)
        agent.load_inference_state(state)
        agent.policy.eval()
        agent.target.eval()
        return RlControllerAdapter(
            method_id,
            self.config_sha256,
            agent,
            mapping_entry["sha256"],
        )


def _program_library(config: dict[str, Any]) -> ProgramLibrary:
    programs = tuple(
        RecoveryProgram(
            schema_version=RECOVERY_PROGRAM_SCHEMA_VERSION,
            program_id=ProgramId(item["program_id"]),
            priority=int(item["priority"]),
            ttl_us=int(item["ttl_us"]),
            min_dwell_us=int(item["min_dwell_us"]),
            budget_cost_units=int(item["budget_cost_units"]),
        )
        for item in config["program_library"]
    )
    return ProgramLibrary(
        schema_version=PROGRAM_LIBRARY_SCHEMA_VERSION,
        library_id=config["program_library_id"],
        programs=programs,
    )


def _supervisor_evidence(
    frame: ObservableFrame,
    opportunity: ControlOpportunity,
    *,
    selected_risk_ppm: int,
    detector_threshold_ppm: int,
) -> EvidenceBundle:
    counters = {item.kind: item.value for item in frame.counters}
    busy = counters.get(ObservableCounterKind.BUSY_SENSING_UNIT, 0)
    total = counters.get(ObservableCounterKind.TOTAL_SENSING_UNIT, 0)
    observed_busy_ppm = busy * 1_000_000 // total if total else 0
    low = min(observed_busy_ppm, selected_risk_ppm)
    high = max(observed_busy_ppm, selected_risk_ppm)
    return EvidenceBundle(
        schema_version=EVIDENCE_BUNDLE_SCHEMA_VERSION,
        evidence_id=stable_digest_hex(
            "exp09-c14-1-supervisor-evidence-id-v1",
            frame.summary_payload_hash,
            str(opportunity.opportunity_id),
        )[:32],
        causal_cutoff_us=frame.causal_cutoff_us,
        detector_active=selected_risk_ppm >= detector_threshold_ppm,
        risk_ppm=selected_risk_ppm,
        memory_interval_low_ppm=low,
        memory_interval_high_ppm=high,
    )


def _plain_input(
    frame: ObservableFrame,
    opportunity: ControlOpportunity,
    action_ids: tuple[str, ...],
) -> dict[str, Any]:
    return {
        "schema_version": PLAIN_INPUT_SCHEMA_VERSION,
        "instruction": (
            "Rank every eligible action once; chosen_action_id must equal candidate_order[0]."
        ),
        "observation": {
            "source_sequence": frame.source_sequence,
            "causal_cutoff_us": int(frame.causal_cutoff_us),
            "counters": tuple(
                {"kind": item.kind.value, "value": item.value}
                for item in sorted(frame.counters, key=lambda item: item.kind.value)
            ),
            "missing_reasons": tuple(
                sorted(item.value for item in frame.missing_reasons)
            ),
            "observed_user_ages": tuple(
                {"vehicle_id": str(item.vehicle_id), "age_us": item.age_us}
                for item in sorted(frame.observed_user_ages, key=lambda item: str(item.vehicle_id))
            ),
            "observed_users": tuple(
                {
                    "vehicle_id": str(item.vehicle_id),
                    "ledger_state": item.ledger_state.value,
                    "identity_silence_us": item.identity_silence_us,
                    "age_us": item.age_us,
                    "age_missing_reason": (
                        None if item.age_missing_reason is None else item.age_missing_reason.value
                    ),
                }
                for item in sorted(frame.observed_users, key=lambda item: str(item.vehicle_id))
            ),
            "removals": tuple(
                {
                    "vehicle_id": str(item.vehicle_id),
                    "reason": item.reason.value,
                    "event_us": int(item.event_us),
                }
                for item in sorted(frame.removals, key=lambda item: str(item.vehicle_id))
            ),
            "current_rri_us": int(opportunity.current_rri_us),
        },
        "eligible_actions": action_ids,
    }


def _validate_plain_response(response: dict[str, Any], action_ids: tuple[str, ...]) -> str:
    expected_keys = {
        "schema_version",
        "candidate_order",
        "chosen_action_id",
        "confidence_ppm",
        "rationale_code",
    }
    if set(response) != expected_keys:
        raise C14OfflineCacheError("Plain_LLM response keys do not match the frozen schema")
    if response["schema_version"] != PLAIN_OUTPUT_SCHEMA_VERSION:
        raise C14OfflineCacheError("Plain_LLM response schema mismatch")
    order = response["candidate_order"]
    if not isinstance(order, list) or tuple(sorted(order)) != tuple(sorted(action_ids)):
        raise C14OfflineCacheError("Plain_LLM candidate order is not an exact permutation")
    if len(order) != len(set(order)) or response["chosen_action_id"] != order[0]:
        raise C14OfflineCacheError("Plain_LLM chosen action is inconsistent")
    confidence = response["confidence_ppm"]
    if isinstance(confidence, bool) or not isinstance(confidence, int) or not 0 <= confidence <= 1_000_000:
        raise C14OfflineCacheError("Plain_LLM confidence is invalid")
    if response["rationale_code"] not in {
        "FRESHNESS_PRIORITY",
        "COLLISION_RISK_PRIORITY",
        "BALANCED_OBSERVABLE_TRADEOFF",
        "INSUFFICIENT_OBSERVABLE_EVIDENCE",
    }:
        raise C14OfflineCacheError("Plain_LLM rationale code is invalid")
    return str(response["chosen_action_id"])


def _file_sha256(path: Path) -> str:
    import hashlib

    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def _require_finite_checkpoint_state(value: Any) -> None:
    import torch

    if isinstance(value, torch.Tensor):
        if not bool(torch.isfinite(value).all().item()):
            raise C14ControllerConfigurationError("RL checkpoint contains NaN or Inf")
        return
    if isinstance(value, dict):
        for item in value.values():
            _require_finite_checkpoint_state(item)
        return
    if isinstance(value, (tuple, list)):
        for item in value:
            _require_finite_checkpoint_state(item)
