"""C07 controller-side interface scaffolding."""

