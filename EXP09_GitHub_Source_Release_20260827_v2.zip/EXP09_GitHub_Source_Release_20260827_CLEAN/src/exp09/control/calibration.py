"""C08 residual-calibration DTO for threshold provenance."""

from dataclasses import dataclass

from exp09.contracts.determinism import stable_digest_hex
from exp09.contracts.ids import require_identifier
from exp09.contracts.time import require_non_negative_int

RESIDUAL_CALIBRATION_RECORD_SCHEMA_VERSION = "exp09-residual-calibration-record-v1"
RESIDUAL_CALIBRATION_HASH_DOMAIN = "exp09-residual-calibration-v1"


@dataclass(frozen=True, slots=True)
class ResidualCalibrationRecord:
    schema_version: str
    calibration_id: str
    threshold_ppm: int
    reachable_min_ppm: int
    reachable_max_ppm: int
    source: str

    def __post_init__(self) -> None:
        if self.schema_version != RESIDUAL_CALIBRATION_RECORD_SCHEMA_VERSION:
            raise ValueError("unsupported residual-calibration-record schema version")
        require_identifier(self.calibration_id, "calibration_id")
        require_non_negative_int(self.threshold_ppm, "threshold_ppm")
        require_non_negative_int(self.reachable_min_ppm, "reachable_min_ppm")
        require_non_negative_int(self.reachable_max_ppm, "reachable_max_ppm")
        require_identifier(self.source, "source")
        if self.reachable_min_ppm > self.reachable_max_ppm:
            raise ValueError("reachable_min_ppm cannot exceed reachable_max_ppm")
        if not (self.reachable_min_ppm <= self.threshold_ppm <= self.reachable_max_ppm):
            raise ValueError("threshold must be inside the reachable risk interval")

    @property
    def provenance_hash(self) -> str:
        return stable_digest_hex(
            RESIDUAL_CALIBRATION_HASH_DOMAIN,
            self.calibration_id,
            self.threshold_ppm,
            self.reachable_min_ppm,
            self.reachable_max_ppm,
            self.source,
        )
