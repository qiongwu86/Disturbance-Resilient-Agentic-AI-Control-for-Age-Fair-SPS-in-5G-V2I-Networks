"""C08 commitment record for accepted or fallback risk-gated actions."""

from dataclasses import dataclass

from exp09.control.risk_gate import RiskGateDecision
from exp09.contracts.ids import require_identifier, require_sha256

COMMITMENT_RECORD_SCHEMA_VERSION = "exp09-commitment-record-v1"


@dataclass(frozen=True, slots=True)
class CommitmentRecord:
    schema_version: str
    commitment_id: str
    decision: RiskGateDecision
    budget_ledger_hash: str
    committed: bool

    def __post_init__(self) -> None:
        if self.schema_version != COMMITMENT_RECORD_SCHEMA_VERSION:
            raise ValueError("unsupported commitment-record schema version")
        require_identifier(self.commitment_id, "commitment_id")
        if not isinstance(self.decision, RiskGateDecision):
            raise ValueError("decision must be a RiskGateDecision")
        require_sha256(self.budget_ledger_hash, "budget_ledger_hash")
        if not isinstance(self.committed, bool):
            raise ValueError("committed must be boolean")
        if not self.committed:
            raise ValueError("risk-gate decisions must commit their legal action")
