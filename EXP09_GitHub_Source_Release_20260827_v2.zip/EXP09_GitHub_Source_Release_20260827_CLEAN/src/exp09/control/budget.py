"""C08 model-transition budget ledger."""

from dataclasses import dataclass

from exp09.contracts.determinism import stable_digest_hex
from exp09.contracts.ids import require_identifier, require_sha256
from exp09.contracts.time import require_non_negative_int, require_positive_int

BUDGET_ALLOCATION_SCHEMA_VERSION = "exp09-budget-allocation-v1"
MODEL_TRANSITION_BUDGET_LEDGER_SCHEMA_VERSION = "exp09-model-transition-budget-ledger-v1"
BUDGET_LEDGER_HASH_DOMAIN = "exp09-budget-ledger-v1"


@dataclass(frozen=True, slots=True)
class BudgetAllocation:
    schema_version: str
    consumer_id: str
    transition_count: int
    evidence_hash: str

    def __post_init__(self) -> None:
        if self.schema_version != BUDGET_ALLOCATION_SCHEMA_VERSION:
            raise ValueError("unsupported budget-allocation schema version")
        require_identifier(self.consumer_id, "consumer_id")
        require_positive_int(self.transition_count, "transition_count")
        require_sha256(self.evidence_hash, "evidence_hash")


@dataclass(frozen=True, slots=True)
class ModelTransitionBudgetLedger:
    schema_version: str
    ledger_id: str
    total_transitions: int
    allocations: tuple[BudgetAllocation, ...]

    def __post_init__(self) -> None:
        if self.schema_version != MODEL_TRANSITION_BUDGET_LEDGER_SCHEMA_VERSION:
            raise ValueError("unsupported model-transition-budget-ledger schema version")
        require_identifier(self.ledger_id, "ledger_id")
        require_non_negative_int(self.total_transitions, "total_transitions")
        if not isinstance(self.allocations, tuple):
            raise ValueError("allocations must be a tuple")
        if not all(isinstance(allocation, BudgetAllocation) for allocation in self.allocations):
            raise ValueError("allocations must contain BudgetAllocation values")
        if self.consumed_transitions > self.total_transitions:
            raise ValueError("budget allocations exceed total transitions")

    @property
    def consumed_transitions(self) -> int:
        return sum(allocation.transition_count for allocation in self.allocations)

    @property
    def remaining_transitions(self) -> int:
        return self.total_transitions - self.consumed_transitions

    @property
    def ledger_hash(self) -> str:
        parts: list[str | int] = [
            BUDGET_LEDGER_HASH_DOMAIN,
            self.ledger_id,
            self.total_transitions,
            len(self.allocations),
        ]
        for allocation in self.allocations:
            parts.extend(
                (
                    allocation.consumer_id,
                    allocation.transition_count,
                    allocation.evidence_hash,
                )
            )
        return stable_digest_hex(*parts)

    def allocate(
        self,
        *,
        consumer_id: str,
        transition_count: int,
        evidence_hash: str,
    ) -> "ModelTransitionBudgetLedger":
        allocation = BudgetAllocation(
            schema_version=BUDGET_ALLOCATION_SCHEMA_VERSION,
            consumer_id=consumer_id,
            transition_count=transition_count,
            evidence_hash=evidence_hash,
        )
        return ModelTransitionBudgetLedger(
            schema_version=MODEL_TRANSITION_BUDGET_LEDGER_SCHEMA_VERSION,
            ledger_id=self.ledger_id,
            total_transitions=self.total_transitions,
            allocations=(*self.allocations, allocation),
        )

    def allocated_transitions(self, consumer_id: str) -> int:
        require_identifier(consumer_id, "consumer_id")
        return sum(
            allocation.transition_count
            for allocation in self.allocations
            if allocation.consumer_id == consumer_id
        )

    def require_equal_allocations(self, left_consumer_id: str, right_consumer_id: str) -> None:
        require_identifier(left_consumer_id, "left_consumer_id")
        require_identifier(right_consumer_id, "right_consumer_id")
        if left_consumer_id == right_consumer_id:
            raise ValueError("budget comparison requires distinct consumers")
        left_total = self.allocated_transitions(left_consumer_id)
        right_total = self.allocated_transitions(right_consumer_id)
        if left_total == 0 or right_total == 0:
            raise ValueError("budget comparison requires allocations for both consumers")
        if left_total != right_total:
            raise ValueError("consumer transition allocations are not equal")
