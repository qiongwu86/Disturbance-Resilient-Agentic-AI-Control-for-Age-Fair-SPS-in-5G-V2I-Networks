"""C08 robust selector over public candidate/model evidence."""

from dataclasses import dataclass

from exp09.control.budget import (
    MODEL_TRANSITION_BUDGET_LEDGER_SCHEMA_VERSION,
    ModelTransitionBudgetLedger,
)
from exp09.control.candidate_generator import CandidateSet
from exp09.contracts.actions import ControlAction, control_action_fingerprint
from exp09.contracts.ids import require_identifier, require_sha256
from exp09.contracts.observable import ObservableFrame
from exp09.contracts.time import require_non_negative_int
from exp09.model.interfaces import (
    ControllerStateEstimate,
    ModelTransitionBudget,
    PredictiveModel,
    RolloutEvaluation,
    ScenarioBatch,
)

ROBUST_SCENARIO_EVALUATION_SCHEMA_VERSION = "exp09-robust-scenario-evaluation-v1"
ROBUST_SELECTION_SCHEMA_VERSION = "exp09-robust-selection-v1"
RMPC_SAME_EVALUATOR_RESULT_SCHEMA_VERSION = "exp09-rmpc-same-evaluator-result-v1"


@dataclass(frozen=True, slots=True)
class RobustScenarioEvaluation:
    schema_version: str
    action_hash: str
    scenario_member_id: str
    source_state_hash: str
    scenario_artifact_hash: str
    rollout_metric_hash: str
    horizon_us: int
    transition_count: int
    risk_ppm: int

    def __post_init__(self) -> None:
        if self.schema_version != ROBUST_SCENARIO_EVALUATION_SCHEMA_VERSION:
            raise ValueError("unsupported robust-scenario-evaluation schema version")
        require_sha256(self.action_hash, "action_hash")
        require_identifier(self.scenario_member_id, "scenario_member_id")
        require_sha256(self.source_state_hash, "source_state_hash")
        require_sha256(self.scenario_artifact_hash, "scenario_artifact_hash")
        require_sha256(self.rollout_metric_hash, "rollout_metric_hash")
        require_non_negative_int(self.horizon_us, "horizon_us")
        if self.horizon_us == 0:
            raise ValueError("horizon_us must be positive")
        require_non_negative_int(self.transition_count, "transition_count")
        if self.transition_count == 0:
            raise ValueError("transition_count must be positive")
        require_non_negative_int(self.risk_ppm, "risk_ppm")
        if self.risk_ppm > 1_000_000:
            raise ValueError("risk_ppm cannot exceed 1,000,000")

    @classmethod
    def from_rollout(cls, rollout: RolloutEvaluation) -> "RobustScenarioEvaluation":
        if not isinstance(rollout, RolloutEvaluation):
            raise ValueError("rollout must be a RolloutEvaluation")
        return cls(
            schema_version=ROBUST_SCENARIO_EVALUATION_SCHEMA_VERSION,
            action_hash=rollout.action_hash,
            scenario_member_id=rollout.scenario_member_id,
            source_state_hash=rollout.source_state_hash,
            scenario_artifact_hash=rollout.scenario_artifact_hash,
            rollout_metric_hash=rollout.predicted_metric_hash,
            horizon_us=int(rollout.horizon_us),
            transition_count=rollout.transition_count,
            risk_ppm=rollout.predicted_collision_risk_ppm,
        )


@dataclass(frozen=True, slots=True)
class RmpcSameEvaluatorResult:
    schema_version: str
    state_hash: str
    scenario_batch_id: str
    scenario_member_order: tuple[str, ...]
    horizon_us: int
    evaluations: tuple[RobustScenarioEvaluation, ...]
    budget_ledger: ModelTransitionBudgetLedger

    def __post_init__(self) -> None:
        if self.schema_version != RMPC_SAME_EVALUATOR_RESULT_SCHEMA_VERSION:
            raise ValueError("unsupported RMPC same-evaluator result schema version")
        require_sha256(self.state_hash, "state_hash")
        require_identifier(self.scenario_batch_id, "scenario_batch_id")
        if not isinstance(self.scenario_member_order, tuple) or not self.scenario_member_order:
            raise ValueError("scenario_member_order must be a non-empty tuple")
        for member_id in self.scenario_member_order:
            require_identifier(member_id, "scenario_member_id")
        require_non_negative_int(self.horizon_us, "horizon_us")
        if self.horizon_us == 0:
            raise ValueError("horizon_us must be positive")
        if not isinstance(self.evaluations, tuple) or not self.evaluations:
            raise ValueError("evaluations must be a non-empty tuple")
        if not all(isinstance(item, RobustScenarioEvaluation) for item in self.evaluations):
            raise ValueError("evaluations must contain RobustScenarioEvaluation values")
        if not isinstance(self.budget_ledger, ModelTransitionBudgetLedger):
            raise ValueError("budget_ledger must be a ModelTransitionBudgetLedger")
        for evaluation in self.evaluations:
            if evaluation.source_state_hash != self.state_hash:
                raise ValueError("evaluation source state does not match RMPC result")
            if evaluation.scenario_member_id not in self.scenario_member_order:
                raise ValueError("evaluation scenario member is not in the ScenarioBatch")
            if evaluation.horizon_us != self.horizon_us:
                raise ValueError("evaluation horizon does not match RMPC result")


class RmpcSameEvaluator:
    """Build robust evaluations from the shared C07 predictive model."""

    def evaluate(
        self,
        *,
        frame: ObservableFrame,
        state: ControllerStateEstimate,
        candidate_set: CandidateSet,
        scenarios: ScenarioBatch,
        horizon_us: int,
        budget: ModelTransitionBudget,
        model: PredictiveModel,
        ledger_id: str,
    ) -> RmpcSameEvaluatorResult:
        if not isinstance(frame, ObservableFrame):
            raise ValueError("frame must be an ObservableFrame")
        if not isinstance(state, ControllerStateEstimate):
            raise ValueError("state must be a ControllerStateEstimate")
        if not isinstance(candidate_set, CandidateSet):
            raise ValueError("candidate_set must be a CandidateSet")
        if not isinstance(scenarios, ScenarioBatch):
            raise ValueError("scenarios must be a ScenarioBatch")
        if not isinstance(budget, ModelTransitionBudget):
            raise ValueError("budget must be a ModelTransitionBudget")
        require_identifier(ledger_id, "ledger_id")
        if candidate_set.observation_hash != frame.summary_payload_hash:
            raise ValueError("candidate_set observation hash does not match frame")
        if frame.summary_payload_hash != state.source_observation_hash:
            raise ValueError("state source does not match frame")
        member_order = tuple(member.member_id for member in scenarios.members)
        current_budget = budget
        evaluations: list[RobustScenarioEvaluation] = []
        ledger = ModelTransitionBudgetLedger(
            schema_version=MODEL_TRANSITION_BUDGET_LEDGER_SCHEMA_VERSION,
            ledger_id=ledger_id,
            total_transitions=budget.total_transitions,
            allocations=(),
        )
        for action in candidate_set.actions:
            rollout_set = model.rollout(
                frame,
                state,
                action,
                scenarios,
                horizon_us,
                current_budget,
            )
            current_budget = rollout_set.budget_after
            action_hash = control_action_fingerprint(action)
            if tuple(item.scenario_member_id for item in rollout_set.evaluations) != member_order:
                raise ValueError("model rollout does not preserve ScenarioBatch member order")
            if any(item.action_hash != action_hash for item in rollout_set.evaluations):
                raise ValueError("model rollout action hash does not match candidate action")
            for rollout, member in zip(rollout_set.evaluations, scenarios.members, strict=True):
                if rollout.scenario_artifact_hash != member.scenario_artifact_hash:
                    raise ValueError("model rollout scenario artifact does not match ScenarioBatch")
                if rollout.source_state_hash != state.state_hash:
                    raise ValueError("model rollout source state does not match ControllerStateEstimate")
                if int(rollout.horizon_us) != int(horizon_us):
                    raise ValueError("model rollout horizon does not match RMPC horizon")
            action_evaluations = tuple(
                RobustScenarioEvaluation.from_rollout(rollout)
                for rollout in rollout_set.evaluations
            )
            evaluations.extend(action_evaluations)
            ledger = ledger.allocate(
                consumer_id=f"RMPC_SameEvaluator_{action_hash[:12]}",
                transition_count=sum(item.transition_count for item in rollout_set.evaluations),
                evidence_hash=rollout_set.evaluations[0].predicted_metric_hash,
            )
        if ledger.consumed_transitions != current_budget.consumed_transitions - budget.consumed_transitions:
            raise ValueError("RMPC ledger does not match model budget consumption")
        return RmpcSameEvaluatorResult(
            schema_version=RMPC_SAME_EVALUATOR_RESULT_SCHEMA_VERSION,
            state_hash=state.state_hash,
            scenario_batch_id=scenarios.batch_id,
            scenario_member_order=member_order,
            horizon_us=horizon_us,
            evaluations=tuple(evaluations),
            budget_ledger=ledger,
        )


@dataclass(frozen=True, slots=True)
class RobustSelection:
    schema_version: str
    action: ControlAction
    action_hash: str
    worst_case_risk_ppm: int
    scenario_count: int
    tie_break_key: str

    def __post_init__(self) -> None:
        if self.schema_version != ROBUST_SELECTION_SCHEMA_VERSION:
            raise ValueError("unsupported robust-selection schema version")
        if not isinstance(self.action, ControlAction):
            raise ValueError("action must be a ControlAction")
        require_sha256(self.action_hash, "action_hash")
        if self.action_hash != control_action_fingerprint(self.action):
            raise ValueError("action_hash does not match action")
        require_non_negative_int(self.worst_case_risk_ppm, "worst_case_risk_ppm")
        if self.worst_case_risk_ppm > 1_000_000:
            raise ValueError("worst_case_risk_ppm cannot exceed 1,000,000")
        require_non_negative_int(self.scenario_count, "scenario_count")
        if self.scenario_count == 0:
            raise ValueError("scenario_count must be positive")
        require_sha256(self.tie_break_key, "tie_break_key")
        if self.tie_break_key != self.action_hash:
            raise ValueError("tie_break_key must match action_hash")


class RobustSelector:
    """Select the minimum worst-case-risk action with a deterministic hash tie-break."""

    def select(
        self,
        candidate_set: CandidateSet,
        evaluations: tuple[RobustScenarioEvaluation, ...],
    ) -> RobustSelection:
        risk_by_action = worst_case_risk_by_action(candidate_set, evaluations)
        action_by_hash = {
            control_action_fingerprint(action): action for action in candidate_set.actions
        }
        selected_hash = min(risk_by_action, key=lambda action_hash: (risk_by_action[action_hash], action_hash))
        return RobustSelection(
            schema_version=ROBUST_SELECTION_SCHEMA_VERSION,
            action=action_by_hash[selected_hash],
            action_hash=selected_hash,
            worst_case_risk_ppm=risk_by_action[selected_hash],
            scenario_count=sum(1 for evaluation in evaluations if evaluation.action_hash == selected_hash),
            tie_break_key=selected_hash,
        )


def worst_case_risk_by_action(
    candidate_set: CandidateSet,
    evaluations: tuple[RobustScenarioEvaluation, ...],
) -> dict[str, int]:
    if not isinstance(candidate_set, CandidateSet):
        raise ValueError("candidate_set must be a CandidateSet")
    if not isinstance(evaluations, tuple) or not evaluations:
        raise ValueError("evaluations must be a non-empty tuple")
    action_hashes = tuple(control_action_fingerprint(action) for action in candidate_set.actions)
    grouped: dict[str, dict[str, int]] = {action_hash: {} for action_hash in action_hashes}
    for evaluation in evaluations:
        if not isinstance(evaluation, RobustScenarioEvaluation):
            raise ValueError("evaluations must contain RobustScenarioEvaluation values")
        if evaluation.action_hash not in grouped:
            raise ValueError("evaluation action hash is not in the candidate set")
        if evaluation.horizon_us != evaluations[0].horizon_us:
            raise ValueError("robust evaluations must share one physical horizon")
        risks_by_member = grouped[evaluation.action_hash]
        if evaluation.scenario_member_id in risks_by_member:
            raise ValueError("duplicate robust evaluation for action and scenario member")
        risks_by_member[evaluation.scenario_member_id] = evaluation.risk_ppm
    missing = [action_hash for action_hash, risks_by_member in grouped.items() if not risks_by_member]
    if missing:
        raise ValueError("every candidate action requires at least one robust evaluation")
    expected_members = set(next(iter(grouped.values())).keys())
    for risks_by_member in grouped.values():
        if set(risks_by_member.keys()) != expected_members:
            raise ValueError("every candidate action requires the same scenario members")
    return {action_hash: max(risks_by_member.values()) for action_hash, risks_by_member in grouped.items()}
