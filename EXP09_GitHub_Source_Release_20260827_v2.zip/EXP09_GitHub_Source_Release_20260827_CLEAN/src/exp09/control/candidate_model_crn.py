"""Method-blind C07 candidate/model/CRN evidence from real model rollouts."""

from dataclasses import dataclass

from exp09.control.candidate_generator import CandidateSet
from exp09.contracts.actions import ControlAction, control_action_fingerprint
from exp09.contracts.ids import require_identifier, require_sha256
from exp09.contracts.observable import ObservableFrame
from exp09.contracts.time import DurationUs, require_non_negative_int, require_positive_int
from exp09.model.interfaces import (
    ControllerStateEstimate,
    ModelTransitionBudget,
    PredictiveModel,
    ScenarioBatch,
)

CANDIDATE_TRACE_EVIDENCE_SCHEMA_VERSION = "exp09-candidate-trace-evidence-v2"
CANDIDATE_MODEL_CRN_EVIDENCE_SCHEMA_VERSION = "exp09-candidate-model-crn-evidence-v2"


@dataclass(frozen=True, slots=True)
class CandidateTraceEvidence:
    schema_version: str
    action_hash: str
    selected_rri_us: DurationUs
    scenario_member_order: tuple[str, ...]
    horizon_us: DurationUs
    transition_count_per_member: int
    numeric_rollout_hashes: tuple[str, ...]
    terminal_mean_ages_us: tuple[int, ...]
    terminal_worst_ages_us: tuple[int, ...]

    def __post_init__(self) -> None:
        if self.schema_version != CANDIDATE_TRACE_EVIDENCE_SCHEMA_VERSION:
            raise ValueError("unsupported candidate-trace-evidence schema version")
        require_sha256(self.action_hash, "action_hash")
        require_positive_int(self.selected_rri_us, "selected_rri_us")
        if not isinstance(self.scenario_member_order, tuple) or not self.scenario_member_order:
            raise ValueError("scenario_member_order must be a non-empty tuple")
        require_positive_int(self.horizon_us, "horizon_us")
        require_positive_int(self.transition_count_per_member, "transition_count_per_member")
        expected = len(self.scenario_member_order)
        if not (
            len(self.numeric_rollout_hashes)
            == len(self.terminal_mean_ages_us)
            == len(self.terminal_worst_ages_us)
            == expected
        ):
            raise ValueError("candidate trace evidence must cover every scenario member")
        for digest in self.numeric_rollout_hashes:
            require_sha256(digest, "numeric_rollout_hash")
        for value in (*self.terminal_mean_ages_us, *self.terminal_worst_ages_us):
            require_non_negative_int(value, "terminal_age_us")


@dataclass(frozen=True, slots=True)
class CandidateModelCrnEvidence:
    schema_version: str
    evidence_id: str
    frame_hash: str
    state_hash_before: str
    state_hash_after: str
    scenario_member_order: tuple[str, ...]
    scenario_artifact_hashes: tuple[str, ...]
    horizon_us: DurationUs
    budget_before_consumed: int
    budget_after_consumed: int
    traces: tuple[CandidateTraceEvidence, ...]

    def __post_init__(self) -> None:
        if self.schema_version != CANDIDATE_MODEL_CRN_EVIDENCE_SCHEMA_VERSION:
            raise ValueError("unsupported candidate-model-CRN-evidence schema version")
        require_identifier(self.evidence_id, "evidence_id")
        require_sha256(self.frame_hash, "frame_hash")
        require_sha256(self.state_hash_before, "state_hash_before")
        require_sha256(self.state_hash_after, "state_hash_after")
        if self.state_hash_before != self.state_hash_after:
            raise ValueError("state hash changed during model evidence generation")
        if not isinstance(self.scenario_member_order, tuple) or not self.scenario_member_order:
            raise ValueError("scenario_member_order must be a non-empty tuple")
        if len(self.scenario_artifact_hashes) != len(self.scenario_member_order):
            raise ValueError("scenario artifact evidence must cover the ScenarioBatch")
        for digest in self.scenario_artifact_hashes:
            require_sha256(digest, "scenario_artifact_hash")
        require_positive_int(self.horizon_us, "horizon_us")
        require_non_negative_int(self.budget_before_consumed, "budget_before_consumed")
        require_non_negative_int(self.budget_after_consumed, "budget_after_consumed")
        if not isinstance(self.traces, tuple) or not self.traces:
            raise ValueError("traces must be a non-empty tuple")
        action_hashes = tuple(trace.action_hash for trace in self.traces)
        if len(set(action_hashes)) != len(action_hashes):
            raise ValueError("trace action hashes must be unique")
        transition_counts = {trace.transition_count_per_member for trace in self.traces}
        if len(transition_counts) != 1:
            raise ValueError("all actions must use the same physical transition count")
        for trace in self.traces:
            if trace.scenario_member_order != self.scenario_member_order:
                raise ValueError("CRN scenario order must be shared across actions")
            if trace.horizon_us != self.horizon_us:
                raise ValueError("all actions must use the same physical horizon")
        expected_charge = (
            next(iter(transition_counts))
            * len(self.scenario_member_order)
            * len(self.traces)
        )
        if self.budget_after_consumed - self.budget_before_consumed != expected_charge:
            raise ValueError("candidate/model evidence budget charge is not conserved")
        numeric_traces = {trace.numeric_rollout_hashes for trace in self.traces}
        if len(numeric_traces) < 2:
            raise ValueError("different legal candidates must produce different numeric traces")


def build_candidate_model_crn_evidence(
    *,
    evidence_id: str,
    frame: ObservableFrame,
    state: ControllerStateEstimate,
    candidate_set: CandidateSet,
    scenarios: ScenarioBatch,
    horizon_us: DurationUs,
    budget: ModelTransitionBudget,
    model: PredictiveModel,
) -> CandidateModelCrnEvidence:
    if not isinstance(frame, ObservableFrame):
        raise ValueError("frame must be an ObservableFrame")
    if not isinstance(state, ControllerStateEstimate):
        raise ValueError("state must be a ControllerStateEstimate")
    if not isinstance(candidate_set, CandidateSet):
        raise ValueError("candidate_set must be a CandidateSet")
    if not isinstance(scenarios, ScenarioBatch):
        raise ValueError("scenarios must be a ScenarioBatch")
    if not isinstance(budget, ModelTransitionBudget):
        raise ValueError("budget must be a ModelTransitionBudget")
    if candidate_set.observation_hash != frame.summary_payload_hash:
        raise ValueError("candidate_set observation hash does not match frame")
    require_positive_int(horizon_us, "horizon_us")

    current_budget = budget
    traces: list[CandidateTraceEvidence] = []
    member_order = tuple(member.member_id for member in scenarios.members)
    for action in candidate_set.actions:
        rollout_set = model.rollout(
            frame,
            state,
            action,
            scenarios,
            horizon_us,
            current_budget,
        )
        current_budget = rollout_set.budget_after
        traces.append(_trace_action(action, member_order, rollout_set.evaluations))

    return CandidateModelCrnEvidence(
        schema_version=CANDIDATE_MODEL_CRN_EVIDENCE_SCHEMA_VERSION,
        evidence_id=evidence_id,
        frame_hash=frame.summary_payload_hash,
        state_hash_before=state.state_hash,
        state_hash_after=state.state_hash,
        scenario_member_order=member_order,
        scenario_artifact_hashes=tuple(
            member.scenario_artifact_hash for member in scenarios.members
        ),
        horizon_us=horizon_us,
        budget_before_consumed=budget.consumed_transitions,
        budget_after_consumed=current_budget.consumed_transitions,
        traces=tuple(traces),
    )


def _trace_action(
    action: ControlAction,
    member_order: tuple[str, ...],
    evaluations,
) -> CandidateTraceEvidence:
    by_member = {evaluation.scenario_member_id: evaluation for evaluation in evaluations}
    ordered = tuple(by_member[member_id] for member_id in member_order)
    if len(by_member) != len(member_order):
        raise ValueError("model rollout does not exactly cover the ScenarioBatch")
    return CandidateTraceEvidence(
        schema_version=CANDIDATE_TRACE_EVIDENCE_SCHEMA_VERSION,
        action_hash=control_action_fingerprint(action),
        selected_rri_us=ordered[0].selected_rri_us,
        scenario_member_order=member_order,
        horizon_us=ordered[0].horizon_us,
        transition_count_per_member=ordered[0].transition_count,
        numeric_rollout_hashes=tuple(item.predicted_metric_hash for item in ordered),
        terminal_mean_ages_us=tuple(item.terminal_mean_age_us for item in ordered),
        terminal_worst_ages_us=tuple(item.terminal_worst_age_us for item in ordered),
    )
