"""C09 causal detector and residual-only calibration memory."""

from collections.abc import Mapping
from dataclasses import dataclass, replace
from enum import Enum

from exp09.contracts.determinism import stable_digest_hex
from exp09.contracts.ids import require_identifier, require_sha256
from exp09.contracts.time import SimTimeUs, require_non_negative_int, require_positive_int

PPM_DENOMINATOR = 1_000_000
DETECTOR_CONFIG_SCHEMA_VERSION = "exp09-detector-config-v1"
DETECTOR_OBSERVATION_SCHEMA_VERSION = "exp09-detector-observation-v1"
DETECTOR_STATE_SCHEMA_VERSION = "exp09-detector-state-v1"
DETECTOR_DECISION_SCHEMA_VERSION = "exp09-detector-decision-v1"
DETECTOR_METRIC_SCHEMA_VERSION = "exp09-detector-metric-v1"
MEMORY_ENTRY_SCHEMA_VERSION = "exp09-calibration-memory-entry-v1"
MEMORY_SNAPSHOT_SCHEMA_VERSION = "exp09-calibration-memory-snapshot-v1"
DETECTOR_STATE_HASH_DOMAIN = "exp09-detector-state-v1"
MEMORY_SNAPSHOT_HASH_DOMAIN = "exp09-calibration-memory-snapshot-v1"


class DetectorStatus(str, Enum):
    QUIET = "QUIET"
    WATCH = "WATCH"
    ACTIVE = "ACTIVE"


class ObservationLifecycle(str, Enum):
    COMPLETE = "COMPLETE"
    CENSORED = "CENSORED"


def _require_ppm(value: int, field_name: str) -> None:
    require_non_negative_int(value, field_name)
    if value > PPM_DENOMINATOR:
        raise ValueError(f"{field_name} must not exceed {PPM_DENOMINATOR}")


@dataclass(frozen=True, slots=True)
class DetectorConfig:
    schema_version: str
    detector_id: str
    ewma_alpha_ppm: int
    watch_threshold_ppm: int
    active_threshold_ppm: int
    exit_threshold_ppm: int
    cusum_reference_ppm: int
    cusum_drift_ppm: int
    cusum_active_threshold_ppm: int
    min_active_observations: int

    def __post_init__(self) -> None:
        if self.schema_version != DETECTOR_CONFIG_SCHEMA_VERSION:
            raise ValueError("unsupported detector-config schema version")
        require_identifier(self.detector_id, "detector_id")
        for field_name in (
            "ewma_alpha_ppm",
            "watch_threshold_ppm",
            "active_threshold_ppm",
            "exit_threshold_ppm",
            "cusum_reference_ppm",
            "cusum_drift_ppm",
            "cusum_active_threshold_ppm",
        ):
            _require_ppm(getattr(self, field_name), field_name)
        require_positive_int(self.min_active_observations, "min_active_observations")
        if self.ewma_alpha_ppm == 0:
            raise ValueError("ewma_alpha_ppm must be positive")
        if not self.exit_threshold_ppm <= self.watch_threshold_ppm <= self.active_threshold_ppm:
            raise ValueError("detector thresholds must be ordered")


@dataclass(frozen=True, slots=True)
class DetectorObservation:
    schema_version: str
    observation_id: str
    case_id: str
    arm_id: str
    time_us: SimTimeUs
    risk_residual_ppm: int
    lifecycle: ObservationLifecycle

    def __post_init__(self) -> None:
        if self.schema_version != DETECTOR_OBSERVATION_SCHEMA_VERSION:
            raise ValueError("unsupported detector-observation schema version")
        require_identifier(self.observation_id, "observation_id")
        require_identifier(self.case_id, "case_id")
        require_identifier(self.arm_id, "arm_id")
        require_non_negative_int(self.time_us, "time_us")
        _require_ppm(self.risk_residual_ppm, "risk_residual_ppm")
        if not isinstance(self.lifecycle, ObservationLifecycle):
            raise ValueError("lifecycle must be an ObservationLifecycle")


@dataclass(frozen=True, slots=True)
class DetectorState:
    schema_version: str
    state_hash: str
    detector_id: str
    case_id: str
    arm_id: str
    last_time_us: SimTimeUs
    observation_count: int
    active_observation_count: int
    ewma_ppm: int
    cusum_ppm: int
    status: DetectorStatus
    complete: bool

    @classmethod
    def initial(
        cls,
        *,
        detector_id: str,
        case_id: str,
        arm_id: str,
        time_us: SimTimeUs,
    ) -> "DetectorState":
        return cls(
            schema_version=DETECTOR_STATE_SCHEMA_VERSION,
            state_hash="0" * 64,
            detector_id=detector_id,
            case_id=case_id,
            arm_id=arm_id,
            last_time_us=time_us,
            observation_count=0,
            active_observation_count=0,
            ewma_ppm=0,
            cusum_ppm=0,
            status=DetectorStatus.QUIET,
            complete=False,
        ).seal()

    def seal(self) -> "DetectorState":
        return replace(self, state_hash=detector_state_hash(self))

    def __post_init__(self) -> None:
        if self.schema_version != DETECTOR_STATE_SCHEMA_VERSION:
            raise ValueError("unsupported detector-state schema version")
        require_sha256(self.state_hash, "state_hash")
        require_identifier(self.detector_id, "detector_id")
        require_identifier(self.case_id, "case_id")
        require_identifier(self.arm_id, "arm_id")
        require_non_negative_int(self.last_time_us, "last_time_us")
        require_non_negative_int(self.observation_count, "observation_count")
        require_non_negative_int(self.active_observation_count, "active_observation_count")
        _require_ppm(self.ewma_ppm, "ewma_ppm")
        _require_ppm(self.cusum_ppm, "cusum_ppm")
        if not isinstance(self.status, DetectorStatus):
            raise ValueError("status must be a DetectorStatus")
        if not isinstance(self.complete, bool):
            raise ValueError("complete must be boolean")
        if self.state_hash != "0" * 64 and self.state_hash != detector_state_hash(self):
            raise ValueError("state_hash does not bind detector state")


def detector_state_hash(state: DetectorState) -> str:
    return stable_digest_hex(
        DETECTOR_STATE_HASH_DOMAIN,
        state.detector_id,
        state.case_id,
        state.arm_id,
        int(state.last_time_us),
        state.observation_count,
        state.active_observation_count,
        state.ewma_ppm,
        state.cusum_ppm,
        state.status.value,
        state.complete,
    )


@dataclass(frozen=True, slots=True)
class DetectorDecision:
    schema_version: str
    prior_state_hash: str
    next_state: DetectorState
    triggered: bool
    censored: bool

    def __post_init__(self) -> None:
        if self.schema_version != DETECTOR_DECISION_SCHEMA_VERSION:
            raise ValueError("unsupported detector-decision schema version")
        require_sha256(self.prior_state_hash, "prior_state_hash")
        if not isinstance(self.next_state, DetectorState):
            raise ValueError("next_state must be a DetectorState")
        if not isinstance(self.triggered, bool) or not isinstance(self.censored, bool):
            raise ValueError("triggered and censored must be booleans")


class CausalEwmaCusumDetector:
    """Prefix-invariant EWMA/CUSUM detector with explicit hysteresis."""

    def __init__(self, config: DetectorConfig) -> None:
        if not isinstance(config, DetectorConfig):
            raise ValueError("config must be a DetectorConfig")
        self._config = config

    def update(self, state: DetectorState, observation: DetectorObservation) -> DetectorDecision:
        if state.detector_id != self._config.detector_id:
            raise ValueError("detector config and state IDs differ")
        if observation.case_id != state.case_id or observation.arm_id != state.arm_id:
            raise ValueError("detector observations are case/arm isolated")
        if observation.time_us < state.last_time_us:
            raise ValueError("detector observations cannot move time backward")
        prior_hash = state.state_hash
        if observation.lifecycle is ObservationLifecycle.CENSORED:
            next_state = replace(
                state,
                state_hash="0" * 64,
                last_time_us=observation.time_us,
                complete=True,
            ).seal()
            return DetectorDecision(
                schema_version=DETECTOR_DECISION_SCHEMA_VERSION,
                prior_state_hash=prior_hash,
                next_state=next_state,
                triggered=False,
                censored=True,
            )

        ewma = (
            self._config.ewma_alpha_ppm * observation.risk_residual_ppm
            + (PPM_DENOMINATOR - self._config.ewma_alpha_ppm) * state.ewma_ppm
        ) // PPM_DENOMINATOR
        excess = max(0, observation.risk_residual_ppm - self._config.cusum_reference_ppm)
        cusum = min(
            PPM_DENOMINATOR,
            max(0, state.cusum_ppm + excess - self._config.cusum_drift_ppm),
        )
        raw_active = (
            ewma >= self._config.active_threshold_ppm
            or cusum >= self._config.cusum_active_threshold_ppm
        )
        raw_watch = ewma >= self._config.watch_threshold_ppm or cusum > 0
        if state.status is DetectorStatus.ACTIVE:
            raw_active = not (
                ewma <= self._config.exit_threshold_ppm
                and cusum < self._config.cusum_active_threshold_ppm // 2
                and state.active_observation_count >= self._config.min_active_observations
            )
        status = DetectorStatus.ACTIVE if raw_active else DetectorStatus.WATCH if raw_watch else DetectorStatus.QUIET
        active_count = (
            state.active_observation_count + 1
            if status is DetectorStatus.ACTIVE
            else 0
        )
        next_state = replace(
            state,
            state_hash="0" * 64,
            last_time_us=observation.time_us,
            observation_count=state.observation_count + 1,
            active_observation_count=active_count,
            ewma_ppm=ewma,
            cusum_ppm=cusum,
            status=status,
            complete=False,
        ).seal()
        return DetectorDecision(
            schema_version=DETECTOR_DECISION_SCHEMA_VERSION,
            prior_state_hash=prior_hash,
            next_state=next_state,
            triggered=state.status is not DetectorStatus.ACTIVE and status is DetectorStatus.ACTIVE,
            censored=False,
        )

    def replay(
        self,
        initial_state: DetectorState,
        observations: tuple[DetectorObservation, ...],
    ) -> tuple[DetectorDecision, ...]:
        state = initial_state
        decisions: list[DetectorDecision] = []
        for observation in observations:
            decision = self.update(state, observation)
            decisions.append(decision)
            state = decision.next_state
        return tuple(decisions)


@dataclass(frozen=True, slots=True)
class DetectorMechanismMetrics:
    schema_version: str
    first_trigger_index: int | None
    detection_delay_steps: int | None
    false_positive_count: int
    false_negative_count: int
    complete_count: int
    censored_count: int

    def __post_init__(self) -> None:
        if self.schema_version != DETECTOR_METRIC_SCHEMA_VERSION:
            raise ValueError("unsupported detector-metric schema version")
        for field_name in (
            "false_positive_count",
            "false_negative_count",
            "complete_count",
            "censored_count",
        ):
            require_non_negative_int(getattr(self, field_name), field_name)
        if self.first_trigger_index is not None:
            require_non_negative_int(self.first_trigger_index, "first_trigger_index")
        if self.detection_delay_steps is not None:
            require_non_negative_int(self.detection_delay_steps, "detection_delay_steps")


def detector_mechanism_metrics(
    decisions: tuple[DetectorDecision, ...],
    *,
    disturbance_start_index: int,
) -> DetectorMechanismMetrics:
    require_non_negative_int(disturbance_start_index, "disturbance_start_index")
    first_trigger = next(
        (index for index, decision in enumerate(decisions) if decision.triggered),
        None,
    )
    false_positive_count = sum(
        1
        for index, decision in enumerate(decisions)
        if index < disturbance_start_index and decision.next_state.status is DetectorStatus.ACTIVE
    )
    false_negative_count = sum(
        1
        for index, decision in enumerate(decisions)
        if index >= disturbance_start_index
        and not decision.censored
        and decision.next_state.status is not DetectorStatus.ACTIVE
    )
    complete_count = sum(1 for decision in decisions if not decision.censored)
    censored_count = sum(1 for decision in decisions if decision.censored)
    delay = None if first_trigger is None else max(0, first_trigger - disturbance_start_index)
    return DetectorMechanismMetrics(
        schema_version=DETECTOR_METRIC_SCHEMA_VERSION,
        first_trigger_index=first_trigger,
        detection_delay_steps=delay,
        false_positive_count=false_positive_count,
        false_negative_count=false_negative_count,
        complete_count=complete_count,
        censored_count=censored_count,
    )


@dataclass(frozen=True, slots=True)
class CalibrationMemoryEntry:
    schema_version: str
    case_id: str
    arm_id: str
    residual_ppm: int
    lifecycle: ObservationLifecycle

    def __post_init__(self) -> None:
        if self.schema_version != MEMORY_ENTRY_SCHEMA_VERSION:
            raise ValueError("unsupported calibration-memory-entry schema version")
        require_identifier(self.case_id, "case_id")
        require_identifier(self.arm_id, "arm_id")
        _require_ppm(self.residual_ppm, "residual_ppm")
        if not isinstance(self.lifecycle, ObservationLifecycle):
            raise ValueError("lifecycle must be an ObservationLifecycle")


@dataclass(frozen=True, slots=True)
class CalibrationMemorySnapshot:
    schema_version: str
    memory_id: str
    snapshot_hash: str
    entries: tuple[CalibrationMemoryEntry, ...]

    @classmethod
    def create(
        cls,
        *,
        memory_id: str,
        entries: tuple[CalibrationMemoryEntry, ...],
    ) -> "CalibrationMemorySnapshot":
        return cls(
            schema_version=MEMORY_SNAPSHOT_SCHEMA_VERSION,
            memory_id=memory_id,
            snapshot_hash="0" * 64,
            entries=entries,
        ).seal()

    def seal(self) -> "CalibrationMemorySnapshot":
        return replace(self, snapshot_hash=memory_snapshot_hash(self))

    def __post_init__(self) -> None:
        if self.schema_version != MEMORY_SNAPSHOT_SCHEMA_VERSION:
            raise ValueError("unsupported calibration-memory-snapshot schema version")
        require_identifier(self.memory_id, "memory_id")
        require_sha256(self.snapshot_hash, "snapshot_hash")
        if not isinstance(self.entries, tuple):
            raise ValueError("entries must be a tuple")
        if not all(isinstance(entry, CalibrationMemoryEntry) for entry in self.entries):
            raise ValueError("entries must contain CalibrationMemoryEntry values")
        if self.snapshot_hash != "0" * 64 and self.snapshot_hash != memory_snapshot_hash(self):
            raise ValueError("snapshot_hash does not bind memory entries")

    def interval_for(self, *, case_id: str, arm_id: str) -> tuple[int, int]:
        require_identifier(case_id, "case_id")
        require_identifier(arm_id, "arm_id")
        residuals = tuple(
            entry.residual_ppm
            for entry in self.entries
            if entry.case_id == case_id
            and entry.arm_id == arm_id
            and entry.lifecycle is ObservationLifecycle.COMPLETE
        )
        if not residuals:
            raise ValueError("no complete residuals exist for the requested case/arm")
        return (min(residuals), max(residuals))

    def mean_absolute_error_ppm(self, *, case_id: str, arm_id: str) -> int:
        require_identifier(case_id, "case_id")
        require_identifier(arm_id, "arm_id")
        residuals = tuple(
            abs(entry.residual_ppm)
            for entry in self.entries
            if entry.case_id == case_id
            and entry.arm_id == arm_id
            and entry.lifecycle is ObservationLifecycle.COMPLETE
        )
        if not residuals:
            raise ValueError("no complete residuals exist for the requested case/arm")
        return sum(residuals) // len(residuals)


def memory_snapshot_hash(snapshot: CalibrationMemorySnapshot) -> str:
    parts: list[str | int] = [
        MEMORY_SNAPSHOT_HASH_DOMAIN,
        snapshot.memory_id,
        len(snapshot.entries),
    ]
    for entry in snapshot.entries:
        parts.extend(
            (
                entry.case_id,
                entry.arm_id,
                entry.residual_ppm,
                entry.lifecycle.value,
            )
        )
    return stable_digest_hex(*parts)


def assert_residual_only_memory_config(config: Mapping[str, object]) -> None:
    forbidden = {
        "action" + "_bonus",
        "memory" + "_bonus",
        "action" + "_value_clip",
        "r" + "_opt",
        "weighted" + "_synthesis",
        "selected_action",
    }
    seen = {str(key).lower() for key in config}
    blocked = forbidden & seen
    if blocked:
        raise ValueError("CalibrationMemory config must be residual-only")
