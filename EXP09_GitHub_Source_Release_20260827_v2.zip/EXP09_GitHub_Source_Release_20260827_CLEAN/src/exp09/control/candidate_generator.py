"""Candidate generation contracts without selector or plant execution."""

from dataclasses import dataclass
from typing import Protocol

from exp09.contracts.actions import (
    ACTION_SCHEMA_VERSION,
    ActionKind,
    ControlAction,
    ControlOpportunity,
    control_action_fingerprint,
)
from exp09.contracts.ids import ControlOpportunityId, require_identifier, require_sha256
from exp09.contracts.observable import ObservableFrame

CANDIDATE_SET_SCHEMA_VERSION = "exp09-candidate-set-v1"


@dataclass(frozen=True, slots=True)
class CandidateSet:
    schema_version: str
    opportunity_id: ControlOpportunityId
    observation_hash: str
    actions: tuple[ControlAction, ...]

    def __post_init__(self) -> None:
        if self.schema_version != CANDIDATE_SET_SCHEMA_VERSION:
            raise ValueError("unsupported candidate-set schema version")
        require_identifier(self.opportunity_id, "opportunity_id")
        require_sha256(self.observation_hash, "observation_hash")
        if not isinstance(self.actions, tuple) or not self.actions:
            raise ValueError("actions must be a non-empty tuple")
        if not all(isinstance(action, ControlAction) for action in self.actions):
            raise ValueError("actions must contain ControlAction values")
        for action in self.actions:
            if action.opportunity_id != self.opportunity_id:
                raise ValueError("candidate action opportunity ID mismatch")
        action_keys = tuple((action.kind.value, action.target_rri_us) for action in self.actions)
        if len(set(action_keys)) != len(action_keys):
            raise ValueError("candidate actions must be unique")


class CandidateGenerator(Protocol):
    def generate(
        self,
        frame: ObservableFrame,
        opportunity: ControlOpportunity,
    ) -> CandidateSet: ...


action_fingerprint = control_action_fingerprint


class ExpiryCandidateGenerator:
    """Generate legal expiry actions from public opportunity fields only."""

    def generate(
        self,
        frame: ObservableFrame,
        opportunity: ControlOpportunity,
    ) -> CandidateSet:
        actions = [
            ControlAction(
                schema_version=ACTION_SCHEMA_VERSION,
                opportunity_id=opportunity.opportunity_id,
                kind=ActionKind.RETAIN_AT_EXPIRY,
                target_rri_us=None,
            )
        ]
        actions.extend(
            ControlAction(
                schema_version=ACTION_SCHEMA_VERSION,
                opportunity_id=opportunity.opportunity_id,
                kind=ActionKind.RESELECT,
                target_rri_us=rri_us,
            )
            for rri_us in opportunity.legal_rri_us
        )
        return CandidateSet(
            schema_version=CANDIDATE_SET_SCHEMA_VERSION,
            opportunity_id=opportunity.opportunity_id,
            observation_hash=frame.summary_payload_hash,
            actions=tuple(actions),
        )
