"""C08 RiskGate over robust-selector outputs."""

from dataclasses import dataclass
from enum import Enum

from exp09.control.calibration import ResidualCalibrationRecord
from exp09.control.candidate_generator import CandidateSet
from exp09.control.robust_selector import (
    RobustScenarioEvaluation,
    RobustSelection,
    RobustSelector,
    worst_case_risk_by_action,
)
from exp09.contracts.actions import ControlAction, control_action_fingerprint
from exp09.contracts.ids import require_identifier, require_sha256
from exp09.contracts.time import require_non_negative_int

RISK_THRESHOLD_SCHEMA_VERSION = "exp09-risk-threshold-v1"
RISK_GATE_DECISION_SCHEMA_VERSION = "exp09-risk-gate-decision-v1"


class RiskGateDecisionStatus(str, Enum):
    ACCEPT = "ACCEPT"
    REJECT_FALLBACK = "REJECT_FALLBACK"
    UNAVOIDABLE_RISK = "UNAVOIDABLE_RISK"


@dataclass(frozen=True, slots=True)
class RiskThreshold:
    schema_version: str
    threshold_id: str
    risk_threshold_ppm: int
    provenance_hash: str

    def __post_init__(self) -> None:
        if self.schema_version != RISK_THRESHOLD_SCHEMA_VERSION:
            raise ValueError("unsupported risk-threshold schema version")
        require_identifier(self.threshold_id, "threshold_id")
        require_non_negative_int(self.risk_threshold_ppm, "risk_threshold_ppm")
        if self.risk_threshold_ppm > 1_000_000:
            raise ValueError("risk_threshold_ppm cannot exceed 1,000,000")
        require_sha256(self.provenance_hash, "provenance_hash")

    @classmethod
    def from_calibration(cls, calibration: ResidualCalibrationRecord) -> "RiskThreshold":
        if not isinstance(calibration, ResidualCalibrationRecord):
            raise ValueError("calibration must be a ResidualCalibrationRecord")
        return cls(
            schema_version=RISK_THRESHOLD_SCHEMA_VERSION,
            threshold_id=calibration.calibration_id,
            risk_threshold_ppm=calibration.threshold_ppm,
            provenance_hash=calibration.provenance_hash,
        )


@dataclass(frozen=True, slots=True)
class RiskGateDecision:
    schema_version: str
    status: RiskGateDecisionStatus
    action: ControlAction
    action_hash: str
    risk_ppm: int
    threshold_id: str
    threshold_ppm: int

    def __post_init__(self) -> None:
        if self.schema_version != RISK_GATE_DECISION_SCHEMA_VERSION:
            raise ValueError("unsupported risk-gate-decision schema version")
        if not isinstance(self.status, RiskGateDecisionStatus):
            raise ValueError("status must be a RiskGateDecisionStatus")
        if not isinstance(self.action, ControlAction):
            raise ValueError("action must be a ControlAction")
        require_sha256(self.action_hash, "action_hash")
        if self.action_hash != control_action_fingerprint(self.action):
            raise ValueError("action_hash does not match action")
        require_non_negative_int(self.risk_ppm, "risk_ppm")
        require_identifier(self.threshold_id, "threshold_id")
        require_non_negative_int(self.threshold_ppm, "threshold_ppm")
        if self.risk_ppm > 1_000_000 or self.threshold_ppm > 1_000_000:
            raise ValueError("risk and threshold ppm values cannot exceed 1,000,000")
        if self.status is RiskGateDecisionStatus.UNAVOIDABLE_RISK:
            if self.risk_ppm <= self.threshold_ppm:
                raise ValueError("unavoidable-risk decisions must exceed the threshold")
        elif self.risk_ppm > self.threshold_ppm:
            raise ValueError("accepted and fallback decisions must satisfy the threshold")


class RiskGate:
    """Accept robust selections at or below threshold, otherwise choose safe fallback."""

    def evaluate(
        self,
        *,
        selection: RobustSelection,
        candidate_set: CandidateSet,
        evaluations: tuple[RobustScenarioEvaluation, ...],
        calibration: ResidualCalibrationRecord,
    ) -> RiskGateDecision:
        if not isinstance(selection, RobustSelection):
            raise ValueError("selection must be a RobustSelection")
        threshold = RiskThreshold.from_calibration(calibration)
        risk_by_action = worst_case_risk_by_action(candidate_set, evaluations)
        action_by_hash = {
            control_action_fingerprint(action): action for action in candidate_set.actions
        }
        selected_risk = risk_by_action.get(selection.action_hash)
        if selected_risk is None or action_by_hash[selection.action_hash] != selection.action:
            raise ValueError("selection action is not in the candidate set")
        if selection.worst_case_risk_ppm != selected_risk:
            raise ValueError("selection risk does not match robust evaluation evidence")
        scenario_count = sum(
            evaluation.action_hash == selection.action_hash for evaluation in evaluations
        )
        if selection.scenario_count != scenario_count:
            raise ValueError("selection scenario count does not match robust evaluation evidence")
        if selection.worst_case_risk_ppm <= threshold.risk_threshold_ppm:
            return _decision(
                status=RiskGateDecisionStatus.ACCEPT,
                action=selection.action,
                risk_ppm=selection.worst_case_risk_ppm,
                threshold=threshold,
            )

        acceptable = tuple(
            action_hash
            for action_hash, risk_ppm in risk_by_action.items()
            if risk_ppm <= threshold.risk_threshold_ppm
        )
        if not acceptable:
            fallback_hash = min(
                risk_by_action,
                key=lambda action_hash: (risk_by_action[action_hash], action_hash),
            )
            return _decision(
                status=RiskGateDecisionStatus.UNAVOIDABLE_RISK,
                action=action_by_hash[fallback_hash],
                risk_ppm=risk_by_action[fallback_hash],
                threshold=threshold,
            )
        fallback_hash = min(acceptable, key=lambda action_hash: (risk_by_action[action_hash], action_hash))
        return _decision(
            status=RiskGateDecisionStatus.REJECT_FALLBACK,
            action=action_by_hash[fallback_hash],
            risk_ppm=risk_by_action[fallback_hash],
            threshold=threshold,
        )


def select_and_gate(
    *,
    candidate_set: CandidateSet,
    evaluations: tuple[RobustScenarioEvaluation, ...],
    calibration: ResidualCalibrationRecord,
) -> RiskGateDecision:
    selection = RobustSelector().select(candidate_set, evaluations)
    return RiskGate().evaluate(
        selection=selection,
        candidate_set=candidate_set,
        evaluations=evaluations,
        calibration=calibration,
    )


def _decision(
    *,
    status: RiskGateDecisionStatus,
    action: ControlAction,
    risk_ppm: int,
    threshold: RiskThreshold,
) -> RiskGateDecision:
    return RiskGateDecision(
        schema_version=RISK_GATE_DECISION_SCHEMA_VERSION,
        status=status,
        action=action,
        action_hash=control_action_fingerprint(action),
        risk_ppm=risk_ppm,
        threshold_id=threshold.threshold_id,
        threshold_ppm=threshold.risk_threshold_ppm,
    )
