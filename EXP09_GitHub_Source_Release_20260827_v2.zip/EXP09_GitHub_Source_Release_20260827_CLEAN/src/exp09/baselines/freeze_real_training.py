"""Generate the hash-bound C12 completion package and disable training."""

import hashlib
import json
import os
from pathlib import Path
from typing import Any

from .audit_real_training import (
    BUDGET_LEDGER_LOCATOR,
    C14_HANDOFF_LOCATOR,
    CHECKPOINT_REGISTRY_LOCATOR,
    CURRENT_MANIFEST_LOCATOR,
    DEFAULT_ENABLED_MANIFEST,
    DEFECT_RECOVERY_LOCATOR,
    ENABLED_MANIFEST_SHA256,
    FINAL_AUDIT_LOCATOR,
    FINAL_FREEZE_LOCATOR,
    LEDGER_LOCATOR,
    QUALIFICATION_REPORT_LOCATOR,
    audit_c12_closed_state,
    audit_c12_real_training,
)

FREEZE_ARTIFACT_LOCATORS = (
    DEFAULT_ENABLED_MANIFEST,
    LEDGER_LOCATOR,
    "protocol/c12/c12_training_freeze.json",
    "protocol/c12/c12_validation_roots.json",
    "protocol/c12/c12_environment_freeze.json",
    "protocol/c12/c12_checkpoint_migration_20260727.json",
    "protocol/c12/c12_recovery_report_20260727.json",
    "protocol/c12/c12_recovery_spec_20260727.json",
    "src/exp09/baselines/audit_real_training.py",
    "src/exp09/baselines/freeze_real_training.py",
    "tests/c09_c13/test_c12_final_audit.py",
    FINAL_AUDIT_LOCATOR,
    CHECKPOINT_REGISTRY_LOCATOR,
    BUDGET_LEDGER_LOCATOR,
    DEFECT_RECOVERY_LOCATOR,
    QUALIFICATION_REPORT_LOCATOR,
    C14_HANDOFF_LOCATOR,
)


def freeze_c12_evidence(project_root: Path) -> dict[str, Any]:
    """Freeze audited C12 evidence, then replace the enabling manifest with closure."""

    root = project_root.resolve()
    current_manifest_path = root / CURRENT_MANIFEST_LOCATOR
    archive_path = root / DEFAULT_ENABLED_MANIFEST
    if archive_path.is_file():
        _require(_file_hash(archive_path) == ENABLED_MANIFEST_SHA256, "enabled archive drift")
    else:
        _require(current_manifest_path.is_file(), "current execution manifest is missing")
        enabled_bytes = current_manifest_path.read_bytes()
        _require(_bytes_hash(enabled_bytes) == ENABLED_MANIFEST_SHA256, "enabled manifest drift")
        _atomic_write_bytes(archive_path, enabled_bytes)
        _require(_file_hash(archive_path) == ENABLED_MANIFEST_SHA256, "archive copy mismatch")

    audit = audit_c12_real_training(root)
    _write_json(root / FINAL_AUDIT_LOCATOR, audit)
    audit_hash = _file_hash(root / FINAL_AUDIT_LOCATOR)

    registry = {
        "schema_version": "exp09-c12-checkpoint-registry-v1",
        "artifact_status": "FROZEN_AUDITED",
        "protocol_generation": "EXP09_G0_AD12A_20260726_V2",
        "route": "A_CORRECTED_EXP09_REAL_RETRAINING",
        "source_enabled_manifest_locator": DEFAULT_ENABLED_MANIFEST,
        "source_enabled_manifest_sha256": ENABLED_MANIFEST_SHA256,
        "source_final_audit": {"locator": FINAL_AUDIT_LOCATOR, "sha256": audit_hash},
        "checkpoint_topology": "METHOD_X_TRAIN_SEED_X_SCENARIO",
        "selected_checkpoint_count": 30,
        "formal_candidate_count": 375,
        "selection_rule": {
            "primary": "worst_user_time_average_AoI_ms_LOWER",
            "tie_break": [
                "collision_event_rate_LOWER",
                "jain_freshness_HIGHER",
                "earlier_checkpoint",
                "checkpoint_sha256_ASC",
            ],
            "locked_test_used": False,
            "cross_seed_best_seed_selection": False,
        },
        "checkpoint_status": "AUDITED_LOADABLE_HASH_BOUND",
        "evaluation_input_status": "READY_FOR_SEPARATELY_AUTHORIZED_C14_FREEZE_ONLY",
        "performance_claim_allowed": False,
        "c14_execution_authorized": False,
        "selected_checkpoints": audit["selected_checkpoints"],
    }
    _write_json(root / CHECKPOINT_REGISTRY_LOCATOR, registry)

    frozen_budget = {
        "schema_version": "exp09-c12-budget-ledger-frozen-v1",
        "artifact_status": "FROZEN_PASS",
        "source_final_audit": {"locator": FINAL_AUDIT_LOCATOR, "sha256": audit_hash},
        "budget": audit["budget"],
        "resource_budget": audit["resource_budget"],
        "storage": audit["storage"],
        "budget_interpretation": "HARD_CAPS_NOT_TARGETS_UNUSED_BUDGET_CANNOT_EXTEND_TRAINING",
        "api_provider_llm_cost": "ZERO",
        "all_caps_pass": True,
    }
    _write_json(root / BUDGET_LEDGER_LOCATOR, frozen_budget)

    frozen_recovery = {
        "schema_version": "exp09-c12-defect-recovery-record-v1",
        "artifact_status": "FROZEN_RECOVERED_AUDITED",
        "source_final_audit": {"locator": FINAL_AUDIT_LOCATOR, "sha256": audit_hash},
        "defect": "INTERRUPTION_DURING_RESUME_CHECKPOINT_ATOMIC_REPLACEMENT",
        "recovery_policy": "DETERMINISTIC_REPLAY_NO_VALIDATION_NO_DELETION",
        "recovery": audit["recovery"],
        "failed_artifact_retention": "PRESERVED_DO_NOT_DELETE_OR_OVERWRITE",
        "formal_candidate_treatment": "RECOVERED_CANDIDATES_COUNTED_HISTORICAL_FILES_EXCLUDED",
    }
    _write_json(root / DEFECT_RECOVERY_LOCATOR, frozen_recovery)

    handoff = {
        "schema_version": "exp09-c12-to-c14-entry-v1",
        "artifact_status": "C12_COMPLETE_C14_NOT_AUTHORIZED",
        "protocol_generation": "EXP09_G0_AD12A_20260726_V2",
        "c12_status": "REAL_TRAINING_COMPLETE_AUDITED_EVIDENCE_FROZEN",
        "checkpoint_registry": {
            "locator": CHECKPOINT_REGISTRY_LOCATOR,
            "sha256": _file_hash(root / CHECKPOINT_REGISTRY_LOCATOR),
        },
        "final_audit": {"locator": FINAL_AUDIT_LOCATOR, "sha256": audit_hash},
        "methods": ["DQN", "DQN_Strong", "GNN_DDQN"],
        "selected_checkpoint_count": 30,
        "formal_candidate_count": 375,
        "c14_execution_authorized": False,
        "method_identified_comparison_authorized": False,
        "api_provider_profiling_authorized": False,
        "shadow_precision_locked_authorized": False,
        "performance_claim_allowed": False,
        "next_boundary": "SEPARATE_C14_PREFREEZE_AND_USER_AUTHORIZATION_REQUIRED",
    }
    _write_json(root / C14_HANDOFF_LOCATOR, handoff)

    report = _qualification_report(audit, audit_hash, registry)
    _atomic_write_text(root / QUALIFICATION_REPORT_LOCATOR, report)

    freeze_artifacts = [
        {"locator": locator, "sha256": _file_hash(root / locator)}
        for locator in FREEZE_ARTIFACT_LOCATORS
    ]
    freeze = {
        "schema_version": "exp09-c12-final-freeze-manifest-v1",
        "artifact_status": "C12_COMPLETE_EVIDENCE_FROZEN",
        "protocol_generation": "EXP09_G0_AD12A_20260726_V2",
        "route": "A_CORRECTED_EXP09_REAL_RETRAINING",
        "source_enabled_manifest": {
            "locator": DEFAULT_ENABLED_MANIFEST,
            "sha256": ENABLED_MANIFEST_SHA256,
        },
        "completion": {
            "methods": ["DQN", "DQN_Strong", "GNN_DDQN"],
            "completed_runs": 30,
            "selected_checkpoints": 30,
            "formal_candidates": 375,
            "checkpoint_status": "AUDITED_LOADABLE_HASH_BOUND",
        },
        "claim_boundary": {
            "performance_claim_allowed": False,
            "c14_execution_authorized": False,
            "locked_test_executed": False,
        },
        "closure_postcondition": {
            "current_execution_manifest": CURRENT_MANIFEST_LOCATOR,
            "artifact_status": "C12_COMPLETE_TRAINING_DISABLED",
            "training_capability": "DISABLED",
            "hard_stop_before_step": "C14",
        },
        "frozen_artifacts": freeze_artifacts,
    }
    _write_json(root / FINAL_FREEZE_LOCATOR, freeze)
    freeze_hash = _file_hash(root / FINAL_FREEZE_LOCATOR)

    closure = {
        "schema_version": "exp09-c12-execution-closure-v1",
        "artifact_status": "C12_COMPLETE_TRAINING_DISABLED",
        "execution_scope": "C12_CLOSED_C14_HARD_STOP",
        "training_capability": "DISABLED",
        "c14_execution_authorized": False,
        "api_allowed": False,
        "performance_claim_allowed": False,
        "source_enabled_manifest": {
            "locator": DEFAULT_ENABLED_MANIFEST,
            "sha256": ENABLED_MANIFEST_SHA256,
        },
        "final_audit": {"locator": FINAL_AUDIT_LOCATOR, "sha256": audit_hash},
        "final_freeze_manifest": {"locator": FINAL_FREEZE_LOCATOR, "sha256": freeze_hash},
        "checkpoint_registry": {
            "locator": CHECKPOINT_REGISTRY_LOCATOR,
            "sha256": _file_hash(root / CHECKPOINT_REGISTRY_LOCATOR),
        },
        "budget_ledger": {
            "locator": BUDGET_LEDGER_LOCATOR,
            "sha256": _file_hash(root / BUDGET_LEDGER_LOCATOR),
        },
        "defect_recovery_record": {
            "locator": DEFECT_RECOVERY_LOCATOR,
            "sha256": _file_hash(root / DEFECT_RECOVERY_LOCATOR),
        },
        "c14_handoff": {
            "locator": C14_HANDOFF_LOCATOR,
            "sha256": _file_hash(root / C14_HANDOFF_LOCATOR),
        },
        "postconditions": [
            "NO_FURTHER_C12_TRAINING_UNDER_ARCHIVED_AUTHORITY",
            "NO_C14_EXECUTION_WITHOUT_SEPARATE_USER_AUTHORIZATION",
            "NO_API_LLM_PROVIDER_CALLS",
            "NO_PERFORMANCE_CLAIM_FROM_C12_VALIDATION",
        ],
    }
    _write_json(current_manifest_path, closure)
    return audit_c12_closed_state(root)


def _qualification_report(
    audit: dict[str, Any], audit_hash: str, registry: dict[str, Any]
) -> str:
    budget = audit["budget"]
    storage = audit["storage"]
    recovery = audit["recovery"]
    return f"""# C12 Real RL Training Qualification Report

REPORT_ID: c12_real_training_qualification_20260728  
REPORT_DATE: 2026-07-28  
STATUS: C12_REAL_TRAINING_COMPLETE  
CHECKPOINT_STATUS: AUDITED_LOADABLE_HASH_BOUND  
PERFORMANCE_CLAIM_ALLOWED: false  
C14_EXECUTION_AUTHORIZED: false  
LOCKED_TEST_STATUS: NOT_EXECUTED

## Qualified Scope

Route A corrected EXP09 real retraining is complete for DQN, DQN_Strong, and GNN_DDQN.
The frozen topology contains 30 method x train-seed x scenario runs, 375 formal validation
candidates, 30 selected checkpoints, and 30 loadable deterministic resume checkpoints.

## Audit Result

- Final audit: `{FINAL_AUDIT_LOCATOR}` (`{audit_hash}`).
- Enabled training authority archive: `{DEFAULT_ENABLED_MANIFEST}`
  (`{ENABLED_MANIFEST_SHA256}`).
- Checkpoint registry: `{CHECKPOINT_REGISTRY_LOCATOR}` with
  `{registry['selected_checkpoint_count']}` selected checkpoints.
- All formal candidate and resume checkpoint hashes, identities, frozen configurations, tensor
  finiteness, validation records, and selection decisions passed the independent read-only audit.
- Validation roots remain hash-frozen at `{audit['validation_roots']['sha256']}` and isolated from
  C14/C15.

## Budget Result

- Successful training transitions: `{budget['training_steps']}`.
- Attempted training transitions: `{budget['attempted_training_steps']} / {budget['training_transition_hard_cap']}`.
- Attempted validation steps: `{budget['attempted_validation_steps']} / {budget['validation_step_hard_cap']}`.
- Attempted combined environment steps: `{budget['attempted_environment_steps']} / {budget['combined_environment_step_hard_cap']}`.
- Final checkpoint/log bytes: `{storage['checkpoint_log_bytes']} / {storage['checkpoint_log_byte_cap']}`.
- Total C12 bytes: `{storage['total_c12_bytes']} / {storage['total_c12_byte_cap']}`.
- API calls, provider calls, LLM tokens, and API cost: zero.

## Recovery Qualification

The interrupted DQN simple seed 101 run was deterministically replayed through episode 470 without
repeating validation. Policy, target, epsilon, and train-step state matched at episodes 100, 200,
300, and 400. The corrupt checkpoint, four historical candidates, and recovered metadata remain
preserved. Recovery report status: `{recovery['status']}`.

## Claim Boundary

C12 validation is checkpoint-selection evidence, not final method-performance evidence. This report
does not authorize C14, method-identified comparison, shadow, precision, Locked Test, unblinding,
figures, manuscript result filling, or any performance, fairness, superiority, noninferiority,
deployment, or all-baseline-best claim.

## Closure

The enabling manifest is preserved byte-for-byte under its original SHA-256. The current execution
manifest disables training and preserves the hard stop before C14. Any later C14 action requires a
separate freeze and explicit user authorization.
"""


def _write_json(path: Path, value: dict[str, Any]) -> None:
    text = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        indent=2,
        allow_nan=False,
    ) + "\n"
    _atomic_write_text(path, text)


def _atomic_write_text(path: Path, text: str) -> None:
    _atomic_write_bytes(path, text.encode("utf-8"))


def _atomic_write_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_bytes(data)
    os.replace(temporary, path)


def _bytes_hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def _file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    arguments = parser.parse_args()
    report = freeze_c12_evidence(arguments.project_root)
    print(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
