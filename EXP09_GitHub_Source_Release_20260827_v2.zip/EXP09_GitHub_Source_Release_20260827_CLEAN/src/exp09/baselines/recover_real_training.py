"""Fail-closed deterministic recovery for an interrupted C12 training run."""

from dataclasses import asdict
import json
from pathlib import Path
from typing import Any

import torch

from .real_training import (
    BudgetLedger,
    CHECKPOINT_SCHEMA_VERSION,
    MAX_STEPS,
    RUN_LEDGER_SCHEMA_VERSION,
    _agent_seed,
    _file_hash,
    _run_training_episode,
    _validate_checkpoint_identity,
    _verify_execution_manifest,
    _write_json,
)
from .rl_environment import ACTION_COUNT, GRAPH_NODE_FEATURE_COUNT, VECTOR_OBSERVATION_COUNT
from .rl_models import (
    C12QAgent,
    FROZEN_AGENT_CONFIGS,
    load_checkpoint_payload,
    save_checkpoint_payload,
)

RECOVERY_SCHEMA_VERSION = "exp09-c12-deterministic-recovery-v1"


def recover_interrupted_run(
    output_root: Path,
    *,
    manifest_hash: str,
    execution_manifest_path: Path,
    recovery_spec_path: Path,
    device_name: str = "cpu",
) -> dict[str, Any]:
    _verify_execution_manifest(execution_manifest_path, manifest_hash)
    spec = json.loads(recovery_spec_path.read_text(encoding="utf-8"))
    _validate_recovery_spec(spec, output_root, manifest_hash)
    method_id = spec["method_id"]
    scenario = spec["scenario"]
    train_seed = int(spec["train_seed"])
    replay_through_episode = int(spec["replay_through_episode"])
    device = torch.device(device_name)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("requested CUDA device is unavailable")
    torch.use_deterministic_algorithms(True)
    torch.set_num_threads(8)

    ledger_path = output_root / "run_ledger.json"
    ledger_primitive = json.loads(ledger_path.read_text(encoding="utf-8"))
    source_manifest_hash = spec["source_manifest_sha256"]
    if ledger_primitive.get("manifest_hash") not in (source_manifest_hash, manifest_hash):
        raise ValueError("durable ledger source manifest mismatch")
    source_budget = BudgetLedger(**ledger_primitive["budget"])
    expected_completed_steps = replay_through_episode * MAX_STEPS[scenario]
    if source_budget.training_steps != expected_completed_steps:
        raise ValueError("durable ledger completed training count mismatch")
    if source_budget.validation_steps != int(spec["source_completed_validation_steps"]):
        raise ValueError("durable ledger validation count mismatch")
    recovered_candidates = tuple(spec["recovered_candidates"])
    if tuple(item["episode"] for item in recovered_candidates) != tuple(
        range(100, replay_through_episode + 1, 100)
    ):
        raise ValueError("recovered candidate episode sequence mismatch")

    replay_ledger = source_budget.reserve_training_attempts(expected_completed_steps)
    _write_json(
        ledger_path,
        {
            "schema_version": RUN_LEDGER_SCHEMA_VERSION,
            "manifest_hash": manifest_hash,
            "budget": asdict(replay_ledger),
            "active_run": spec["run_id"],
            "recovery_status": "REPLAY_PRE_RESERVED",
            "replay_through_episode": replay_through_episode,
        },
    )
    agent = C12QAgent(
        config=FROZEN_AGENT_CONFIGS[method_id],
        vector_size=VECTOR_OBSERVATION_COUNT,
        node_feature_count=GRAPH_NODE_FEATURE_COUNT,
        action_count=ACTION_COUNT,
        seed=_agent_seed(method_id, scenario, train_seed),
        device=device,
    )
    summary_state: dict[str, int | float] = {
        "episode_count": 0,
        "loss_count": 0,
        "loss_sum": 0.0,
        "reward_sum": 0.0,
    }
    comparisons: list[dict[str, Any]] = []
    migrated_candidates: list[dict[str, Any]] = []
    for episode in range(1, replay_through_episode + 1):
        result = _run_training_episode(agent, scenario, train_seed, episode)
        summary_state["episode_count"] += 1
        summary_state["loss_count"] += int(result["loss_count"])
        summary_state["loss_sum"] += float(result["loss_sum"])
        summary_state["reward_sum"] += float(result["reward_sum"])
        if episode % 100:
            continue
        recovered = recovered_candidates[len(comparisons)]
        source_path = output_root / recovered["source_relative_path"]
        if _file_hash(source_path) != recovered["source_sha256"]:
            raise ValueError("source candidate content hash mismatch")
        source = load_checkpoint_payload(source_path, map_location=device)
        _validate_checkpoint_identity(source, source_manifest_hash, method_id, scenario, train_seed)
        if source.get("checkpoint_kind") != "INFERENCE_CANDIDATE":
            raise ValueError("source candidate kind mismatch")
        fields = _compare_inference_states(agent.inference_state(), source["inference_state"])
        comparisons.append({"episode": episode, "fields": fields, "equal": True})

        migrated_path = (
            output_root
            / "runs"
            / spec["run_id"]
            / "candidates_recovered"
            / f"episode_{episode:04d}.pt"
        )
        migrated_payload = dict(source)
        migrated_payload["manifest_hash"] = manifest_hash
        migrated_payload["recovery"] = {
            "schema_version": RECOVERY_SCHEMA_VERSION,
            "source_manifest_sha256": source_manifest_hash,
            "source_checkpoint_sha256": recovered["source_sha256"],
            "inference_state_equal_after_deterministic_replay": True,
        }
        save_checkpoint_payload(migrated_payload, migrated_path)
        migrated_hash = _file_hash(migrated_path)
        migrated_candidates.append(
            {
                **recovered["validation"],
                "episode": episode,
                "relative_path": migrated_path.relative_to(output_root).as_posix(),
                "sha256": migrated_hash,
            }
        )

    resume_path = output_root / "runs" / spec["run_id"] / "resume.pt"
    resume_payload = {
        "schema_version": CHECKPOINT_SCHEMA_VERSION,
        "manifest_hash": manifest_hash,
        "method_id": method_id,
        "scenario": scenario,
        "train_seed": train_seed,
        "episode": replay_through_episode,
        "config": asdict(FROZEN_AGENT_CONFIGS[method_id]),
        "checkpoint_kind": "DETERMINISTIC_RESUME",
        "agent_state": agent.checkpoint_state(),
        "next_episode": replay_through_episode + 1,
        "candidates": tuple(migrated_candidates),
        "budget": asdict(
            BudgetLedger(
                training_steps=source_budget.training_steps,
                validation_steps=source_budget.validation_steps,
                attempted_training_steps=replay_ledger.attempted_training_steps,
                attempted_validation_steps=source_budget.attempted_validation_steps,
            )
        ),
        "summary_state": summary_state,
        "recovery": {
            "schema_version": RECOVERY_SCHEMA_VERSION,
            "replay_validation_steps": 0,
            "replay_attempted_training_steps": expected_completed_steps,
            "source_corrupt_checkpoint_sha256": spec["source_corrupt_checkpoint_sha256"],
        },
    }
    save_checkpoint_payload(resume_payload, resume_path)
    rebuilt_resume_hash = _file_hash(resume_path)
    load_checkpoint_payload(resume_path, map_location=device)
    final_budget = BudgetLedger(**resume_payload["budget"])
    _write_json(
        ledger_path,
        {
            "schema_version": RUN_LEDGER_SCHEMA_VERSION,
            "manifest_hash": manifest_hash,
            "budget": asdict(final_budget),
            "active_run": spec["run_id"],
            "last_completed_episode": replay_through_episode,
            "recovery_status": "DETERMINISTIC_REPLAY_COMPLETE",
        },
    )
    report = {
        "schema_version": RECOVERY_SCHEMA_VERSION,
        "status": "DETERMINISTIC_REPLAY_COMPLETE_RESUME_LOADABLE",
        "run_id": spec["run_id"],
        "source_manifest_sha256": source_manifest_hash,
        "target_manifest_sha256": manifest_hash,
        "source_corrupt_checkpoint": {
            "relative_path": spec["source_corrupt_checkpoint_relative_path"],
            "sha256": spec["source_corrupt_checkpoint_sha256"],
            "preserved": True,
        },
        "recovered_data_pickle": {
            "relative_path": spec["recovered_data_pickle_relative_path"],
            "sha256": spec["recovered_data_pickle_sha256"],
        },
        "candidate_comparisons": comparisons,
        "candidate_migrations": migrated_candidates,
        "replay_attempted_training_steps": expected_completed_steps,
        "replay_validation_steps": 0,
        "budget_after_recovery": asdict(final_budget),
        "rebuilt_resume": {
            "relative_path": resume_path.relative_to(output_root).as_posix(),
            "sha256": rebuilt_resume_hash,
            "next_episode": replay_through_episode + 1,
        },
        "summary_state": summary_state,
    }
    _write_json(recovery_spec_path.with_name("c12_recovery_report_20260727.json"), report)
    return report


def _validate_recovery_spec(
    spec: dict[str, Any], output_root: Path, manifest_hash: str
) -> None:
    expected = ("DQN_simple_seed101", "DQN", "simple", 101, 470)
    actual = (
        spec.get("run_id"),
        spec.get("method_id"),
        spec.get("scenario"),
        spec.get("train_seed"),
        spec.get("replay_through_episode"),
    )
    if actual != expected:
        raise ValueError("recovery identity mismatch")
    if spec.get("target_manifest_sha256") != manifest_hash:
        raise ValueError("recovery target manifest mismatch")
    for relative_field, hash_field in (
        ("source_corrupt_checkpoint_relative_path", "source_corrupt_checkpoint_sha256"),
        ("recovered_data_pickle_relative_path", "recovered_data_pickle_sha256"),
    ):
        path = output_root.parent / spec[relative_field]
        if _file_hash(path) != spec[hash_field]:
            raise ValueError(f"recovery evidence hash mismatch: {relative_field}")


def _compare_inference_states(
    replayed: dict[str, Any], source: dict[str, Any]
) -> tuple[str, ...]:
    if set(replayed) != set(source):
        raise ValueError("candidate inference state schema mismatch")
    for network in ("policy", "target"):
        replayed_network = replayed[network]
        source_network = source[network]
        if tuple(replayed_network) != tuple(source_network):
            raise ValueError(f"candidate {network} state keys mismatch")
        for key in replayed_network:
            if not torch.equal(replayed_network[key].cpu(), source_network[key].cpu()):
                raise ValueError(f"candidate {network} tensor mismatch: {key}")
    if replayed["epsilon"] != source["epsilon"]:
        raise ValueError("candidate epsilon mismatch")
    if replayed["train_steps"] != source["train_steps"]:
        raise ValueError("candidate train_steps mismatch")
    return ("policy", "target", "epsilon", "train_steps")
