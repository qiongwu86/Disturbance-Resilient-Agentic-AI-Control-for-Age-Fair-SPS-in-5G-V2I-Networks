"""C12 deterministic baseline qualification pipeline without external training."""

from dataclasses import dataclass

from exp09.baselines.registry import C07_METHOD_IDS
from exp09.contracts.determinism import stable_digest_hex
from exp09.contracts.ids import require_identifier, require_sha256
from exp09.contracts.time import require_non_negative_int, require_positive_int

TRAINING_SPEC_SCHEMA_VERSION = "exp09-training-spec-v1"
SEED_RECORD_SCHEMA_VERSION = "exp09-training-seed-record-v1"
CHECKPOINT_RECORD_SCHEMA_VERSION = "exp09-checkpoint-record-v1"
TRAINING_MANIFEST_SCHEMA_VERSION = "exp09-training-manifest-v1"
BASELINE_QUALIFICATION_SCHEMA_VERSION = "exp09-baseline-qualification-v1"
TRAINING_SPEC_HASH_DOMAIN = "exp09-training-spec-v1"
SEED_HASH_DOMAIN = "exp09-training-seed-v1"
CHECKPOINT_HASH_DOMAIN = "exp09-checkpoint-v1"
TRAINING_MANIFEST_HASH_DOMAIN = "exp09-training-manifest-v1"

_TRUTH_TOKENS = ("truth", "plant_state", "future", "scenario_id", "arm", "test_label")


@dataclass(frozen=True, slots=True)
class TrainingSpec:
    schema_version: str
    spec_id: str
    method_id: str
    observation_fields: tuple[str, ...]
    reward_fields: tuple[str, ...]
    transition_budget: int
    validation_split_hash: str

    @property
    def spec_hash(self) -> str:
        parts: list[str | int] = [
            TRAINING_SPEC_HASH_DOMAIN,
            self.spec_id,
            self.method_id,
            self.transition_budget,
            self.validation_split_hash,
            len(self.observation_fields),
        ]
        parts.extend(self.observation_fields)
        parts.append(len(self.reward_fields))
        parts.extend(self.reward_fields)
        return stable_digest_hex(*parts)

    def __post_init__(self) -> None:
        if self.schema_version != TRAINING_SPEC_SCHEMA_VERSION:
            raise ValueError("unsupported training-spec schema version")
        require_identifier(self.spec_id, "spec_id")
        require_identifier(self.method_id, "method_id")
        require_positive_int(self.transition_budget, "transition_budget")
        require_sha256(self.validation_split_hash, "validation_split_hash")
        if not isinstance(self.observation_fields, tuple) or not self.observation_fields:
            raise ValueError("observation_fields must be a non-empty tuple")
        if not isinstance(self.reward_fields, tuple) or not self.reward_fields:
            raise ValueError("reward_fields must be a non-empty tuple")
        for field in (*self.observation_fields, *self.reward_fields):
            require_identifier(field, "training field")
            if any(token in field.lower() for token in _TRUTH_TOKENS):
                raise ValueError("training fields cannot expose truth or test identity")


@dataclass(frozen=True, slots=True)
class TrainingSeedRecord:
    schema_version: str
    method_id: str
    seed: int
    seed_hash: str
    transition_budget: int
    consumed_transitions: int

    @classmethod
    def create(cls, *, method_id: str, seed: int, transition_budget: int) -> "TrainingSeedRecord":
        require_identifier(method_id, "method_id")
        require_non_negative_int(seed, "seed")
        require_positive_int(transition_budget, "transition_budget")
        consumed = transition_budget
        return cls(
            schema_version=SEED_RECORD_SCHEMA_VERSION,
            method_id=method_id,
            seed=seed,
            seed_hash=training_seed_hash(
                method_id=method_id,
                seed=seed,
                transition_budget=transition_budget,
                consumed_transitions=consumed,
            ),
            transition_budget=transition_budget,
            consumed_transitions=consumed,
        )

    def __post_init__(self) -> None:
        if self.schema_version != SEED_RECORD_SCHEMA_VERSION:
            raise ValueError("unsupported training-seed-record schema version")
        require_identifier(self.method_id, "method_id")
        require_non_negative_int(self.seed, "seed")
        require_sha256(self.seed_hash, "seed_hash")
        require_positive_int(self.transition_budget, "transition_budget")
        require_non_negative_int(self.consumed_transitions, "consumed_transitions")
        if self.consumed_transitions > self.transition_budget:
            raise ValueError("seed consumed transitions exceed budget")
        if self.seed_hash != training_seed_hash(
            method_id=self.method_id,
            seed=self.seed,
            transition_budget=self.transition_budget,
            consumed_transitions=self.consumed_transitions,
        ):
            raise ValueError("seed_hash does not bind training seed record")


def training_seed_hash(
    *,
    method_id: str,
    seed: int,
    transition_budget: int,
    consumed_transitions: int,
) -> str:
    return stable_digest_hex(
        SEED_HASH_DOMAIN,
        method_id,
        seed,
        transition_budget,
        consumed_transitions,
    )


@dataclass(frozen=True, slots=True)
class CheckpointRecord:
    schema_version: str
    checkpoint_id: str
    method_id: str
    seed_hash: str
    validation_score_ppm: int
    checkpoint_hash: str
    selected_by_validation: bool

    @classmethod
    def create(
        cls,
        *,
        checkpoint_id: str,
        method_id: str,
        seed_hash: str,
        validation_score_ppm: int,
        selected_by_validation: bool,
    ) -> "CheckpointRecord":
        require_identifier(checkpoint_id, "checkpoint_id")
        require_identifier(method_id, "method_id")
        require_sha256(seed_hash, "seed_hash")
        require_non_negative_int(validation_score_ppm, "validation_score_ppm")
        if validation_score_ppm > 1_000_000:
            raise ValueError("validation_score_ppm cannot exceed 1,000,000")
        return cls(
            schema_version=CHECKPOINT_RECORD_SCHEMA_VERSION,
            checkpoint_id=checkpoint_id,
            method_id=method_id,
            seed_hash=seed_hash,
            validation_score_ppm=validation_score_ppm,
            checkpoint_hash=checkpoint_record_hash(
                checkpoint_id=checkpoint_id,
                method_id=method_id,
                seed_hash=seed_hash,
                validation_score_ppm=validation_score_ppm,
                selected_by_validation=selected_by_validation,
            ),
            selected_by_validation=selected_by_validation,
        )

    def __post_init__(self) -> None:
        if self.schema_version != CHECKPOINT_RECORD_SCHEMA_VERSION:
            raise ValueError("unsupported checkpoint-record schema version")
        require_identifier(self.checkpoint_id, "checkpoint_id")
        require_identifier(self.method_id, "method_id")
        require_sha256(self.seed_hash, "seed_hash")
        require_non_negative_int(self.validation_score_ppm, "validation_score_ppm")
        if self.validation_score_ppm > 1_000_000:
            raise ValueError("validation_score_ppm cannot exceed 1,000,000")
        require_sha256(self.checkpoint_hash, "checkpoint_hash")
        if not isinstance(self.selected_by_validation, bool):
            raise ValueError("selected_by_validation must be boolean")
        if self.checkpoint_hash != checkpoint_record_hash(
            checkpoint_id=self.checkpoint_id,
            method_id=self.method_id,
            seed_hash=self.seed_hash,
            validation_score_ppm=self.validation_score_ppm,
            selected_by_validation=self.selected_by_validation,
        ):
            raise ValueError("checkpoint_hash does not bind checkpoint record")


def checkpoint_record_hash(
    *,
    checkpoint_id: str,
    method_id: str,
    seed_hash: str,
    validation_score_ppm: int,
    selected_by_validation: bool,
) -> str:
    return stable_digest_hex(
        CHECKPOINT_HASH_DOMAIN,
        checkpoint_id,
        method_id,
        seed_hash,
        validation_score_ppm,
        selected_by_validation,
    )


@dataclass(frozen=True, slots=True)
class TrainingManifest:
    schema_version: str
    manifest_hash: str
    spec: TrainingSpec
    seed_records: tuple[TrainingSeedRecord, ...]
    checkpoints: tuple[CheckpointRecord, ...]

    @classmethod
    def create(
        cls,
        *,
        spec: TrainingSpec,
        seed_records: tuple[TrainingSeedRecord, ...],
        checkpoints: tuple[CheckpointRecord, ...],
    ) -> "TrainingManifest":
        return cls(
            schema_version=TRAINING_MANIFEST_SCHEMA_VERSION,
            manifest_hash=training_manifest_hash(
                spec=spec,
                seed_records=seed_records,
                checkpoints=checkpoints,
            ),
            spec=spec,
            seed_records=seed_records,
            checkpoints=checkpoints,
        )

    def __post_init__(self) -> None:
        if self.schema_version != TRAINING_MANIFEST_SCHEMA_VERSION:
            raise ValueError("unsupported training-manifest schema version")
        require_sha256(self.manifest_hash, "manifest_hash")
        if not isinstance(self.spec, TrainingSpec):
            raise ValueError("spec must be a TrainingSpec")
        if not isinstance(self.seed_records, tuple) or not self.seed_records:
            raise ValueError("seed_records must be a non-empty tuple")
        if not all(isinstance(record, TrainingSeedRecord) for record in self.seed_records):
            raise ValueError("seed_records must contain TrainingSeedRecord values")
        if not isinstance(self.checkpoints, tuple) or not self.checkpoints:
            raise ValueError("checkpoints must be a non-empty tuple")
        if not all(isinstance(checkpoint, CheckpointRecord) for checkpoint in self.checkpoints):
            raise ValueError("checkpoints must contain CheckpointRecord values")
        seed_hashes = tuple(record.seed_hash for record in self.seed_records)
        if len(seed_hashes) != len(set(seed_hashes)):
            raise ValueError("seed records must have unique seed hashes")
        if any(record.method_id != self.spec.method_id for record in self.seed_records):
            raise ValueError("seed records must match the training spec method")
        checkpoint_ids = tuple(checkpoint.checkpoint_id for checkpoint in self.checkpoints)
        if len(checkpoint_ids) != len(set(checkpoint_ids)):
            raise ValueError("checkpoint IDs must be unique")
        for checkpoint in self.checkpoints:
            if checkpoint.method_id != self.spec.method_id:
                raise ValueError("checkpoints must match the training spec method")
            if checkpoint.seed_hash not in seed_hashes:
                raise ValueError("checkpoint seed_hash must reference a manifest seed record")
        selected = [checkpoint for checkpoint in self.checkpoints if checkpoint.selected_by_validation]
        if len(selected) != 1:
            raise ValueError("exactly one checkpoint must be selected by validation")
        best = max(self.checkpoints, key=lambda item: (item.validation_score_ppm, item.checkpoint_hash))
        if selected[0] != best:
            raise ValueError("checkpoint selection must use validation score only")
        if self.manifest_hash != training_manifest_hash(
            spec=self.spec,
            seed_records=self.seed_records,
            checkpoints=self.checkpoints,
        ):
            raise ValueError("manifest_hash does not bind training manifest")

    @property
    def total_consumed_transitions(self) -> int:
        return sum(record.consumed_transitions for record in self.seed_records)


def training_manifest_hash(
    *,
    spec: TrainingSpec,
    seed_records: tuple[TrainingSeedRecord, ...],
    checkpoints: tuple[CheckpointRecord, ...],
) -> str:
    parts: list[str | int] = [
        TRAINING_MANIFEST_HASH_DOMAIN,
        spec.spec_hash,
        len(seed_records),
    ]
    parts.extend(record.seed_hash for record in seed_records)
    parts.append(len(checkpoints))
    parts.extend(checkpoint.checkpoint_hash for checkpoint in checkpoints)
    return stable_digest_hex(*parts)


def build_synthetic_training_manifest(
    *,
    spec: TrainingSpec,
    seeds: tuple[int, ...],
) -> TrainingManifest:
    if not isinstance(seeds, tuple) or not seeds:
        raise ValueError("seeds must be a non-empty tuple")
    seed_records = tuple(
        TrainingSeedRecord.create(
            method_id=spec.method_id,
            seed=seed,
            transition_budget=spec.transition_budget,
        )
        for seed in seeds
    )
    scores: list[int] = []
    for record in seed_records:
        score_hash = stable_digest_hex("exp09-synthetic-validation-score-v1", record.seed_hash)
        scores.append(int(score_hash[:8], 16) % 1_000_001)
    best_index = max(range(len(scores)), key=lambda index: (scores[index], seed_records[index].seed_hash))
    checkpoints = tuple(
        CheckpointRecord.create(
            checkpoint_id=f"{spec.method_id}-seed-{record.seed}",
            method_id=spec.method_id,
            seed_hash=record.seed_hash,
            validation_score_ppm=scores[index],
            selected_by_validation=index == best_index,
        )
        for index, record in enumerate(seed_records)
    )
    return TrainingManifest.create(
        spec=spec,
        seed_records=seed_records,
        checkpoints=checkpoints,
    )


@dataclass(frozen=True, slots=True)
class BaselineQualificationRecord:
    schema_version: str
    qualification_id: str
    method_ids: tuple[str, ...]
    manifest_hashes: tuple[str, ...]
    manifests: tuple[TrainingManifest, ...]
    capability_status: str

    def __post_init__(self) -> None:
        if self.schema_version != BASELINE_QUALIFICATION_SCHEMA_VERSION:
            raise ValueError("unsupported baseline-qualification schema version")
        require_identifier(self.qualification_id, "qualification_id")
        if tuple(self.method_ids) != C07_METHOD_IDS:
            raise ValueError("baseline qualification must preserve the full registered method set")
        if not isinstance(self.manifest_hashes, tuple) or len(self.manifest_hashes) != len(self.method_ids):
            raise ValueError("manifest_hashes must match method_ids")
        for digest in self.manifest_hashes:
            require_sha256(digest, "manifest_hash")
        if not isinstance(self.manifests, tuple) or len(self.manifests) != len(self.method_ids):
            raise ValueError("manifests must match method_ids")
        if not all(isinstance(manifest, TrainingManifest) for manifest in self.manifests):
            raise ValueError("manifests must contain TrainingManifest values")
        if tuple(manifest.spec.method_id for manifest in self.manifests) != self.method_ids:
            raise ValueError("manifests must preserve method_id order")
        if tuple(manifest.manifest_hash for manifest in self.manifests) != self.manifest_hashes:
            raise ValueError("manifest_hashes must be bound to TrainingManifest records")
        if self.capability_status != "QUALIFIED_FOR_PIPELINE_NO_PERFORMANCE_CLAIM":
            raise ValueError("unsupported baseline capability status")
