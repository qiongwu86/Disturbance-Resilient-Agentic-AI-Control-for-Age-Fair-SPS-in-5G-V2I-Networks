"""C12 causal RL observation, action, reward, and episode contracts."""

from dataclasses import dataclass
from fractions import Fraction

import numpy as np

from exp09.contracts.actions import ACTION_SCHEMA_VERSION, ActionKind, ControlAction, ControlOpportunity
from exp09.contracts.observable import (
    IdentityState,
    MeasurementDeliveryEvent,
    MeasurementEventKind,
    ObservableCounterKind,
    ObservableFrame,
    ReceiverObservableKind,
)

ACTION_COUNT = 8
GRAPH_NODE_COUNT = 9
GRAPH_NODE_FEATURE_COUNT = 6
VECTOR_OBSERVATION_COUNT = 16
LEGAL_RRI_US = (20_000, 50_000, 100_000, 200_000, 300_000, 500_000, 1_000_000)
ANALYSIS_WINDOW_US = 40_000_000
REWARD_SCALE_US2_PER_MS = ANALYSIS_WINDOW_US * 1_000


@dataclass(frozen=True, slots=True)
class EncodedObservation:
    vector: np.ndarray
    node_features: np.ndarray
    adjacency: np.ndarray
    action_mask: np.ndarray


class CausalWorstUserAoiReward:
    """Telescoping reward over receiver-ledger cumulative per-user AoI area."""

    def __init__(self, *, start_time_us: int, end_time_us: int) -> None:
        if start_time_us < 0 or end_time_us <= start_time_us:
            raise ValueError("reward interval must be positive and non-negative")
        self._area_twice_us2: dict[str, int] = {}
        self._last_success_generation_us: dict[str, int] = {}
        self._active_vehicle_ids: set[str] = set()
        self._start_time_us = int(start_time_us)
        self._end_time_us = int(end_time_us)
        self._last_time_us = 0
        self._previous_worst_twice_us2 = 0

    def ingest(
        self,
        events: tuple[MeasurementDeliveryEvent, ...],
        boundary_time_us: int,
    ) -> float:
        boundary = min(int(boundary_time_us), self._end_time_us)
        if boundary < self._last_time_us:
            raise ValueError("reward time cannot move backwards")
        for event in events:
            event_time_us = int(event.delivered_at_us)
            if event_time_us < self._last_time_us or event_time_us > boundary:
                raise ValueError("reward events must be a causal prefix in timestamp order")
            self._integrate_to(event_time_us)
            self._apply_event(event)
        self._integrate_to(boundary)
        worst_twice_us2 = max(self._area_twice_us2.values(), default=0)
        increment_twice_us2 = worst_twice_us2 - self._previous_worst_twice_us2
        if increment_twice_us2 < 0:
            raise RuntimeError("worst-user cumulative AoI area cannot decrease")
        self._previous_worst_twice_us2 = worst_twice_us2
        return -float(Fraction(increment_twice_us2, 2 * REWARD_SCALE_US2_PER_MS))

    def _integrate_to(self, time_us: int) -> None:
        right = max(self._start_time_us, min(time_us, self._end_time_us))
        left = max(self._start_time_us, min(self._last_time_us, self._end_time_us))
        duration_us = right - left
        if duration_us > 0:
            for vehicle_id in self._active_vehicle_ids:
                generation_us = self._last_success_generation_us.get(vehicle_id)
                if generation_us is None:
                    continue
                start_age_us = left - generation_us
                if start_age_us < 0:
                    raise ValueError("causal receiver AoI cannot be negative")
                self._area_twice_us2[vehicle_id] = self._area_twice_us2.get(vehicle_id, 0) + (
                    2 * start_age_us * duration_us + duration_us * duration_us
                )
        self._last_time_us = time_us

    def _apply_event(self, event: MeasurementDeliveryEvent) -> None:
        if event.kind is MeasurementEventKind.PACKET:
            assert event.packet is not None
            vehicle_id = str(event.packet.vehicle_id)
            self._active_vehicle_ids.add(vehicle_id)
            self._last_success_generation_us[vehicle_id] = int(
                event.packet.packet_generation_us
            )
            self._area_twice_us2.setdefault(vehicle_id, 0)
        elif event.kind is MeasurementEventKind.IDENTITY:
            assert event.identity is not None
            vehicle_id = str(event.identity.vehicle_id)
            if event.identity.kind is ReceiverObservableKind.AUTHENTICATED_HANDOVER:
                self._active_vehicle_ids.add(vehicle_id)
                if event.identity.last_success_generation_us is not None:
                    self._last_success_generation_us[vehicle_id] = int(
                        event.identity.last_success_generation_us
                    )
                    self._area_twice_us2.setdefault(vehicle_id, 0)
            else:
                self._active_vehicle_ids.discard(vehicle_id)
                self._last_success_generation_us.pop(vehicle_id, None)

    @property
    def worst_cumulative_area_twice_us2(self) -> int:
        return self._previous_worst_twice_us2

    @property
    def worst_time_average_aoi_ms(self) -> Fraction:
        return Fraction(
            self._previous_worst_twice_us2,
            2 * REWARD_SCALE_US2_PER_MS,
        )


def encode_observation(
    frame: ObservableFrame,
    opportunity: ControlOpportunity,
) -> EncodedObservation:
    counters = {item.kind: item.value for item in frame.counters}
    total_sensing = counters.get(ObservableCounterKind.TOTAL_SENSING_UNIT, 0)
    decode_trials = counters.get(ObservableCounterKind.OBSERVABLE_DECODE_TRIAL, 0)
    users = tuple(sorted(frame.observed_users, key=lambda item: str(item.vehicle_id)))
    known_ages = sorted(item.age_us for item in users if item.age_us is not None)
    max_age = max(known_ages, default=0)
    mean_age = sum(known_ages) / len(known_ages) if known_ages else 0.0
    vector = np.asarray(
        (
            min(max_age / 1_000_000.0, 100.0),
            min(mean_age / 1_000_000.0, 100.0),
            min(len(users) / GRAPH_NODE_COUNT, 1.0),
            min(counters.get(ObservableCounterKind.FRESH_OBSERVED, 0) / GRAPH_NODE_COUNT, 1.0),
            min(counters.get(ObservableCounterKind.STALE_RETAINED, 0) / GRAPH_NODE_COUNT, 1.0),
            min(counters.get(ObservableCounterKind.UNKNOWN_RETAINED, 0) / GRAPH_NODE_COUNT, 1.0),
            _safe_ratio(
                counters.get(ObservableCounterKind.BUSY_SENSING_UNIT, 0), total_sensing
            ),
            _safe_ratio(
                counters.get(ObservableCounterKind.DECODED_SUCCESS, 0), decode_trials
            ),
            opportunity.current_rri_us / 1_000_000.0,
            min(opportunity.reservation_version / 100.0, 1.0),
            min(len(frame.removals) / GRAPH_NODE_COUNT, 1.0),
            1.0 if not known_ages else 0.0,
            1.0 if total_sensing == 0 else 0.0,
            1.0 if decode_trials == 0 else 0.0,
            min(len(frame.missing_reasons) / 6.0, 1.0),
            1.0,
        ),
        dtype=np.float32,
    )
    nodes = np.zeros((GRAPH_NODE_COUNT, GRAPH_NODE_FEATURE_COUNT), dtype=np.float32)
    for index, user in enumerate(users[:GRAPH_NODE_COUNT]):
        nodes[index] = (
            min((user.age_us or 0) / 1_000_000.0, 100.0),
            min(user.identity_silence_us / 1_000_000.0, 100.0),
            float(user.ledger_state is IdentityState.FRESH),
            float(user.ledger_state is IdentityState.STALE_RETAINED),
            float(user.ledger_state is IdentityState.UNKNOWN_RETAINED),
            float(user.age_us is not None),
        )
    adjacency = np.zeros((GRAPH_NODE_COUNT, GRAPH_NODE_COUNT), dtype=np.float32)
    active = min(len(users), GRAPH_NODE_COUNT)
    if active:
        adjacency[:active, :active] = 1.0 / active
    return EncodedObservation(
        vector=vector,
        node_features=nodes,
        adjacency=adjacency,
        action_mask=legal_action_mask(opportunity),
    )


def legal_action_mask(opportunity: ControlOpportunity) -> np.ndarray:
    mask = np.zeros(ACTION_COUNT, dtype=np.bool_)
    mask[0] = True
    legal = {int(value) for value in opportunity.legal_rri_us}
    for index, rri_us in enumerate(LEGAL_RRI_US, start=1):
        mask[index] = rri_us in legal
    return mask


def decode_action(action_index: int, opportunity: ControlOpportunity) -> ControlAction:
    index = int(action_index)
    mask = legal_action_mask(opportunity)
    if index < 0 or index >= ACTION_COUNT or not bool(mask[index]):
        raise ValueError("RL action is outside the legal opportunity domain")
    if index == 0:
        return ControlAction(
            schema_version=ACTION_SCHEMA_VERSION,
            opportunity_id=opportunity.opportunity_id,
            kind=ActionKind.RETAIN_AT_EXPIRY,
            target_rri_us=None,
        )
    return ControlAction(
        schema_version=ACTION_SCHEMA_VERSION,
        opportunity_id=opportunity.opportunity_id,
        kind=ActionKind.RESELECT,
        target_rri_us=LEGAL_RRI_US[index - 1],
    )


def _safe_ratio(numerator: int, denominator: int) -> float:
    return float(numerator / denominator) if denominator else 0.0
