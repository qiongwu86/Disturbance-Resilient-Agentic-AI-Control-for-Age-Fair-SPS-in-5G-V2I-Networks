"""Public C07 baseline action policies over direct numeric controller evidence."""

from dataclasses import dataclass
from enum import Enum
from typing import Protocol

from exp09.control.candidate_generator import CandidateSet
from exp09.contracts.actions import ActionKind, ControlAction, ControlOpportunity
from exp09.contracts.actions import control_action_fingerprint
from exp09.contracts.determinism import stable_digest_hex
from exp09.contracts.ids import require_sha256
from exp09.contracts.observable import ObservableFrame
from exp09.model.interfaces import RolloutEvaluation

BASELINE_ACTION_REQUEST_SCHEMA_VERSION = "exp09-baseline-action-request-v2"
BASELINE_ACTION_DECISION_SCHEMA_VERSION = "exp09-baseline-action-decision-v2"
BASELINE_DECISION_EVIDENCE_DOMAIN = "exp09-c07-baseline-decision-v1"
PACKET_PERIOD_US = 100_000
HEADROOM_BUSY_THRESHOLD_PPM = 500_000

C07_BASELINE_ACTION_METHODS = (
    "KEEP_sanity",
    "AoI_aware_heuristic",
    "Greedy_1",
    "Nominal_MPC",
)


class BaselineDecisionStatus(str, Enum):
    IMPLEMENTED_C07_C12_QUALIFICATION_PENDING = (
        "IMPLEMENTED_C07_C12_QUALIFICATION_PENDING"
    )


@dataclass(frozen=True, slots=True)
class BaselineActionRequest:
    schema_version: str
    method_id: str
    frame: ObservableFrame
    opportunity: ControlOpportunity
    candidate_set: CandidateSet
    rollouts: tuple[RolloutEvaluation, ...]

    def __post_init__(self) -> None:
        if self.schema_version != BASELINE_ACTION_REQUEST_SCHEMA_VERSION:
            raise ValueError("unsupported baseline-action-request schema version")
        _require_c07_baseline_method(self.method_id)
        if not isinstance(self.frame, ObservableFrame):
            raise ValueError("frame must be an ObservableFrame")
        if not isinstance(self.opportunity, ControlOpportunity):
            raise ValueError("opportunity must be a ControlOpportunity")
        if not isinstance(self.candidate_set, CandidateSet):
            raise ValueError("candidate_set must be a CandidateSet")
        if self.candidate_set.opportunity_id != self.opportunity.opportunity_id:
            raise ValueError("candidate_set opportunity does not match request opportunity")
        if self.candidate_set.observation_hash != self.frame.summary_payload_hash:
            raise ValueError("candidate_set observation hash does not match request frame")
        if not isinstance(self.rollouts, tuple):
            raise ValueError("rollouts must be a tuple")
        if not all(isinstance(rollout, RolloutEvaluation) for rollout in self.rollouts):
            raise ValueError("rollouts must contain RolloutEvaluation values")
        action_hashes = {
            control_action_fingerprint(action) for action in self.candidate_set.actions
        }
        for rollout in self.rollouts:
            if rollout.action_hash not in action_hashes:
                raise ValueError("rollout action hash is not in the candidate set")
        if self.method_id in {"Greedy_1", "Nominal_MPC"}:
            _validate_complete_rollout_matrix(self)


@dataclass(frozen=True, slots=True)
class BaselineActionDecision:
    schema_version: str
    method_id: str
    action: ControlAction
    action_hash: str
    decision_status: BaselineDecisionStatus
    evidence_hashes: tuple[str, ...]

    def __post_init__(self) -> None:
        if self.schema_version != BASELINE_ACTION_DECISION_SCHEMA_VERSION:
            raise ValueError("unsupported baseline-action-decision schema version")
        _require_c07_baseline_method(self.method_id)
        if not isinstance(self.action, ControlAction):
            raise ValueError("action must be a ControlAction")
        require_sha256(self.action_hash, "action_hash")
        if self.action_hash != control_action_fingerprint(self.action):
            raise ValueError("action_hash does not match action")
        if (
            self.decision_status
            is not BaselineDecisionStatus.IMPLEMENTED_C07_C12_QUALIFICATION_PENDING
        ):
            raise ValueError("unsupported C07 baseline decision status")
        if not isinstance(self.evidence_hashes, tuple) or not self.evidence_hashes:
            raise ValueError("implemented C07 decisions require evidence hashes")
        for digest in self.evidence_hashes:
            require_sha256(digest, "evidence_hash")


class BaselineActionPolicy(Protocol):
    method_id: str

    def select(self, request: BaselineActionRequest) -> BaselineActionDecision: ...


class KeepSanityActionPolicy:
    method_id = "KEEP_sanity"

    def select(self, request: BaselineActionRequest) -> BaselineActionDecision:
        _require_request_method(request, self.method_id)
        return _decision(self.method_id, _retain_action(request), request)


class AoiAwareHeuristicActionPolicy:
    """Adapted observable-only age/congestion heuristic; not a literature reproduction."""

    method_id = "AoI_aware_heuristic"

    def select(self, request: BaselineActionRequest) -> BaselineActionDecision:
        _require_request_method(request, self.method_id)
        reselects = tuple(
            action
            for action in request.candidate_set.actions
            if action.kind is ActionKind.RESELECT
        )
        if not reselects:
            return _decision(self.method_id, _retain_action(request), request)
        known_ages = tuple(item.age_us for item in request.frame.observed_user_ages)
        counters = {counter.kind.value: counter.value for counter in request.frame.counters}
        busy = counters.get("busy_sensing_unit_count", 0)
        total = counters.get("total_sensing_unit_count", 0)
        busy_ppm = busy * 1_000_000 // total if total else None
        if known_ages and max(known_ages) > PACKET_PERIOD_US:
            selected = min(reselects, key=_rri_key)
        elif busy_ppm is not None and busy_ppm > HEADROOM_BUSY_THRESHOLD_PPM:
            selected = max(reselects, key=_rri_key)
        else:
            selected = _retain_action(request)
        return _decision(self.method_id, selected, request)


class GreedyOneActionPolicy:
    method_id = "Greedy_1"

    def select(self, request: BaselineActionRequest) -> BaselineActionDecision:
        _require_request_method(request, self.method_id)
        selected = _select_by_expected_lexicographic_score(request, first_attempt_only=True)
        return _decision(self.method_id, selected, request)


class NominalMpcActionPolicy:
    method_id = "Nominal_MPC"

    def select(self, request: BaselineActionRequest) -> BaselineActionDecision:
        _require_request_method(request, self.method_id)
        selected = _select_by_expected_lexicographic_score(request, first_attempt_only=False)
        return _decision(self.method_id, selected, request)


def _require_c07_baseline_method(method_id: str) -> None:
    if method_id not in C07_BASELINE_ACTION_METHODS:
        raise ValueError("method_id is not a C07 baseline action method")


def _require_request_method(request: BaselineActionRequest, method_id: str) -> None:
    if not isinstance(request, BaselineActionRequest):
        raise ValueError("request must be a BaselineActionRequest")
    if request.method_id != method_id:
        raise ValueError("request method_id does not match the policy")


def _retain_action(request: BaselineActionRequest) -> ControlAction:
    for action in request.candidate_set.actions:
        if action.kind is ActionKind.RETAIN_AT_EXPIRY:
            return action
    raise ValueError("candidate set has no RETAIN_AT_EXPIRY action")


def _rri_key(action: ControlAction) -> int:
    assert action.target_rri_us is not None
    return int(action.target_rri_us)


def _validate_complete_rollout_matrix(request: BaselineActionRequest) -> None:
    if not request.rollouts:
        raise ValueError("rollout-backed baseline requires rollout evaluations")
    action_hashes = tuple(
        control_action_fingerprint(action) for action in request.candidate_set.actions
    )
    scenario_ids_by_action: dict[str, set[str]] = {digest: set() for digest in action_hashes}
    horizon_by_action: dict[str, set[int]] = {digest: set() for digest in action_hashes}
    source_state_hashes: set[str] = set()
    for rollout in request.rollouts:
        if rollout.scenario_member_id in scenario_ids_by_action[rollout.action_hash]:
            raise ValueError("rollout matrix contains a duplicate action/scenario cell")
        scenario_ids_by_action[rollout.action_hash].add(rollout.scenario_member_id)
        horizon_by_action[rollout.action_hash].add(int(rollout.horizon_us))
        source_state_hashes.add(rollout.source_state_hash)
    scenario_sets = {frozenset(values) for values in scenario_ids_by_action.values()}
    if len(scenario_sets) != 1 or not next(iter(scenario_sets)):
        raise ValueError("all candidate actions must share the complete ScenarioBatch")
    if any(len(values) != 1 for values in horizon_by_action.values()):
        raise ValueError("each candidate action must use one physical horizon")
    if len({next(iter(values)) for values in horizon_by_action.values()}) != 1:
        raise ValueError("all candidate actions must share the physical horizon")
    if len(source_state_hashes) != 1:
        raise ValueError("all candidate actions must share one immutable source state")


def _select_by_expected_lexicographic_score(
    request: BaselineActionRequest,
    *,
    first_attempt_only: bool,
) -> ControlAction:
    action_by_hash = {
        control_action_fingerprint(action): action for action in request.candidate_set.actions
    }
    rollouts_by_action: dict[str, list[RolloutEvaluation]] = {
        digest: [] for digest in action_by_hash
    }
    for rollout in request.rollouts:
        rollouts_by_action[rollout.action_hash].append(rollout)

    def score(action_hash: str) -> tuple[int, int, int, int, str]:
        values = rollouts_by_action[action_hash]
        count = len(values)
        if first_attempt_only:
            worst_age = sum(item.first_attempt_worst_age_us for item in values) // count
            mean_age = sum(item.first_attempt_mean_age_us for item in values) // count
        else:
            worst_age = sum(item.time_average_worst_age_us for item in values) // count
            mean_age = sum(item.time_average_mean_age_us for item in values) // count
        collision = sum(item.predicted_collision_risk_ppm for item in values) // count
        switch_cost = int(action_by_hash[action_hash].kind is ActionKind.RESELECT)
        return worst_age, mean_age, collision, switch_cost, action_hash

    selected_hash = min(action_by_hash, key=score)
    return action_by_hash[selected_hash]


def _decision(
    method_id: str,
    action: ControlAction,
    request: BaselineActionRequest,
) -> BaselineActionDecision:
    action_hash = control_action_fingerprint(action)
    rollout_hashes = tuple(
        sorted(
            item.predicted_metric_hash
            for item in request.rollouts
            if item.action_hash == action_hash
        )
    )
    evidence_hash = stable_digest_hex(
        BASELINE_DECISION_EVIDENCE_DOMAIN,
        method_id,
        request.frame.summary_payload_hash,
        action_hash,
        len(rollout_hashes),
        *rollout_hashes,
    )
    return BaselineActionDecision(
        schema_version=BASELINE_ACTION_DECISION_SCHEMA_VERSION,
        method_id=method_id,
        action=action,
        action_hash=action_hash,
        decision_status=BaselineDecisionStatus.IMPLEMENTED_C07_C12_QUALIFICATION_PENDING,
        evidence_hashes=(evidence_hash,),
    )
