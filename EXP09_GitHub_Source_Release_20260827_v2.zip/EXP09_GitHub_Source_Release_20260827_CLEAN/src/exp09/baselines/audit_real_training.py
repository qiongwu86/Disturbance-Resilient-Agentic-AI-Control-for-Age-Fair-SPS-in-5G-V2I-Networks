"""Read-only, fail-closed audit of the completed C12 real RL training run."""

from collections.abc import Mapping, Sequence
from dataclasses import asdict, fields, is_dataclass
from decimal import Decimal, InvalidOperation
import gc
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
from typing import Any

import numpy as np
import torch

from .real_training import (
    CHECKPOINT_SCHEMA_VERSION,
    COMBINED_HARD_CAP,
    EPISODES,
    MAX_STEPS,
    METHODS,
    RUN_LEDGER_SCHEMA_VERSION,
    SCENARIOS,
    TRAINING_HARD_CAP,
    TRAIN_SEEDS,
    VALIDATION_HARD_CAP,
)
from .rl_environment import (
    ACTION_COUNT,
    GRAPH_NODE_FEATURE_COUNT,
    VECTOR_OBSERVATION_COUNT,
)
from .rl_models import C12QAgent, FROZEN_AGENT_CONFIGS, load_checkpoint_payload

ENABLED_MANIFEST_SHA256 = (
    "4F469FF723DBD9C2DA0B82C2C838A3CA5FEED34697C53A7D34A5C4EBEC4B288D"
)
VALIDATION_ROOTS_SHA256 = (
    "D2E4925AD0DB1A95D34652414C5D76DCEC299F22D2537BB0D7B1AF919E539C3D"
)
FINAL_AUDIT_SCHEMA_VERSION = "exp09-c12-final-audit-v1"
DEFAULT_ENABLED_MANIFEST = "protocol/c12/c12_execution_manifest.ENABLED_ARCHIVE.json"
LEDGER_LOCATOR = "artifacts/c12_real_training/final/run_ledger.json"
OUTPUT_LOCATOR = "artifacts/c12_real_training/final"
FINAL_AUDIT_LOCATOR = "protocol/c12/c12_final_audit.json"
FINAL_FREEZE_LOCATOR = "protocol/c12/c12_final_freeze_manifest.json"
CURRENT_MANIFEST_LOCATOR = "protocol/c12/c12_execution_manifest.json"
CHECKPOINT_REGISTRY_LOCATOR = "protocol/c12/c12_checkpoint_registry.json"
BUDGET_LEDGER_LOCATOR = "protocol/c12/c12_budget_ledger_frozen.json"
DEFECT_RECOVERY_LOCATOR = "protocol/c12/c12_defect_recovery_record.json"
QUALIFICATION_REPORT_LOCATOR = (
    "protocol/evidence/C12_real_training_qualification_report_20260728.md"
)
C14_HANDOFF_LOCATOR = "protocol/c14/c12_real_training_entry_20260728.json"
HISTORICAL_CANDIDATES = tuple(
    f"runs/DQN_simple_seed101/candidates/episode_{episode:04d}.pt"
    for episode in (100, 200, 300, 400)
)


class C12AuditError(ValueError):
    """Raised when final C12 evidence violates a frozen invariant."""


def audit_c12_real_training(
    project_root: Path,
    *,
    enabled_manifest_locator: str = DEFAULT_ENABLED_MANIFEST,
) -> dict[str, Any]:
    """Audit all C12 outputs without writing to the project or checkpoint tree."""

    root = project_root.resolve()
    enabled_manifest_path = _resolve_locator(root, enabled_manifest_locator)
    enabled_manifest = _audit_enabled_manifest(root, enabled_manifest_path)
    training_freeze = _load_json_object(root / "protocol/c12/c12_training_freeze.json")
    validation_roots = _audit_validation_roots(root, training_freeze)
    output_root = root / OUTPUT_LOCATOR
    ledger_path = root / LEDGER_LOCATOR
    ledger = _load_json_object(ledger_path)
    _require(ledger.get("schema_version") == RUN_LEDGER_SCHEMA_VERSION, "ledger schema mismatch")
    _require(
        ledger.get("manifest_hash") == ENABLED_MANIFEST_SHA256,
        "ledger is not bound to the enabled execution manifest",
    )

    expected_topology = {
        (method_id, train_seed, scenario)
        for method_id in METHODS
        for train_seed in TRAIN_SEEDS
        for scenario in SCENARIOS
    }
    completed_runs = ledger.get("completed_runs")
    selected_checkpoints = ledger.get("selected_checkpoints")
    _require(isinstance(completed_runs, list), "ledger completed_runs must be a list")
    _require(isinstance(selected_checkpoints, list), "ledger selected_checkpoints must be a list")
    _require(len(completed_runs) == 30, "ledger must contain exactly 30 completed runs")
    _require(
        len(selected_checkpoints) == 30,
        "ledger must contain exactly 30 selected checkpoints",
    )
    ledger_runs = _index_by_run_id(completed_runs, "ledger completed run")
    ledger_selected = _index_by_run_id(selected_checkpoints, "ledger selected checkpoint")
    actual_topology = {
        (record.get("method_id"), record.get("train_seed"), record.get("scenario"))
        for record in completed_runs
    }
    _require(actual_topology == expected_topology, "completed-run topology is incomplete or duplicated")

    run_directories = {
        path.name for path in (output_root / "runs").iterdir() if path.is_dir()
    }
    expected_run_ids = {
        _run_id(method_id, scenario, train_seed)
        for method_id, train_seed, scenario in expected_topology
    }
    _require(run_directories == expected_run_ids, "run directory topology mismatch")

    inference_agents = _make_agents()
    resume_agents = _make_agents()
    formal_candidate_paths: set[str] = set()
    selected_records: list[dict[str, Any]] = []
    resume_budgets: dict[str, dict[str, int]] = {}
    training_steps_sum = 0
    candidate_count_sum = 0
    illegal_action_sum = 0
    hard_violation_sum = 0

    for method_id in METHODS:
        for train_seed in TRAIN_SEEDS:
            for scenario in SCENARIOS:
                run_id = _run_id(method_id, scenario, train_seed)
                complete_path = output_root / "runs" / run_id / "run_complete.json"
                complete = _load_json_object(complete_path)
                run = complete.get("run")
                candidates = complete.get("candidates")
                selected = complete.get("selected_checkpoint")
                _require(isinstance(run, dict), f"{run_id}: run record is missing")
                _require(isinstance(candidates, list), f"{run_id}: candidate list is missing")
                _require(isinstance(selected, dict), f"{run_id}: selected checkpoint is missing")
                _audit_run_record(run, method_id, scenario, train_seed)
                _require(ledger_runs.get(run_id) == run, f"{run_id}: ledger run record mismatch")

                expected_candidate_count = EPISODES[scenario] // 100
                _require(
                    len(candidates) == expected_candidate_count,
                    f"{run_id}: candidate count violates the 100-episode cadence",
                )
                _require(
                    run.get("candidate_count") == expected_candidate_count,
                    f"{run_id}: recorded candidate count mismatch",
                )
                expected_episodes = list(range(100, EPISODES[scenario] + 1, 100))
                _require(
                    [candidate.get("episode") for candidate in candidates] == expected_episodes,
                    f"{run_id}: candidate cadence or ordering mismatch",
                )
                for candidate in candidates:
                    _audit_candidate_record(candidate, run_id)
                    relative_path = candidate["relative_path"]
                    _require(
                        relative_path not in formal_candidate_paths,
                        f"duplicate formal candidate locator: {relative_path}",
                    )
                    formal_candidate_paths.add(relative_path)
                    _audit_candidate_checkpoint(
                        output_root,
                        candidate,
                        method_id=method_id,
                        scenario=scenario,
                        train_seed=train_seed,
                        agent=inference_agents[method_id],
                    )
                expected_selected = {
                    "run_id": run_id,
                    "method_id": method_id,
                    "scenario": scenario,
                    "train_seed": train_seed,
                    **min(candidates, key=_selection_key),
                }
                _require(selected == expected_selected, f"{run_id}: selected checkpoint is not optimal")
                _require(
                    ledger_selected.get(run_id) == selected,
                    f"{run_id}: selected checkpoint differs from the ledger",
                )
                selected_records.append(selected)

                resume_path = output_root / "runs" / run_id / "resume.pt"
                resume_budgets[run_id] = _audit_resume_checkpoint(
                    resume_path,
                    candidates=candidates,
                    method_id=method_id,
                    scenario=scenario,
                    train_seed=train_seed,
                    agent=resume_agents[method_id],
                )
                training_steps_sum += int(run["training_steps"])
                candidate_count_sum += len(candidates)
                illegal_action_sum += int(run["illegal_action_count"])
                hard_violation_sum += int(run["hard_constraint_violation_count"])
                gc.collect()

    _require(candidate_count_sum == 375, "formal candidate total must be exactly 375")
    _audit_candidate_filesystem(output_root, formal_candidate_paths)
    budget = _audit_budget(
        ledger,
        training_steps_sum=training_steps_sum,
        resume_budgets=resume_budgets,
    )
    _require(illegal_action_sum == 0, "completed runs contain illegal actions")
    _require(hard_violation_sum == 0, "completed runs contain hard-constraint violations")
    recovery = _audit_recovery(root, output_root, formal_candidate_paths, budget)
    storage = _audit_storage(root)
    resource_budget = _audit_resource_budget(root, training_freeze)

    return {
        "schema_version": FINAL_AUDIT_SCHEMA_VERSION,
        "artifact_status": "PASS_C12_REAL_TRAINING_COMPLETE_AUDITED",
        "claim_boundary": {
            "c14_execution_authorized": False,
            "locked_test_executed": False,
            "performance_claim_allowed": False,
        },
        "enabled_execution_manifest": {
            "locator": enabled_manifest_locator,
            "sha256": ENABLED_MANIFEST_SHA256,
            "frozen_artifact_count": len(enabled_manifest["frozen_artifacts"]),
            "all_frozen_artifact_hashes_match": True,
        },
        "source_ledger": {
            "locator": LEDGER_LOCATOR,
            "sha256": _file_hash(ledger_path),
            "schema_version": RUN_LEDGER_SCHEMA_VERSION,
        },
        "topology": {
            "methods": list(METHODS),
            "train_seeds": list(TRAIN_SEEDS),
            "scenarios": list(SCENARIOS),
            "completed_run_count": len(completed_runs),
            "selected_checkpoint_count": len(selected_records),
            "formal_candidate_count": candidate_count_sum,
            "historical_recovery_candidate_count": len(HISTORICAL_CANDIDATES),
            "resume_checkpoint_count": len(resume_budgets),
        },
        "checkpoint_audit": {
            "all_formal_hashes_match": True,
            "all_formal_checkpoints_torch_loadable": True,
            "all_formal_checkpoint_tensors_finite": True,
            "all_resume_checkpoints_torch_loadable": True,
            "all_resume_checkpoint_tensors_finite": True,
            "all_identities_and_configs_match": True,
            "all_selections_match_frozen_rule": True,
            "all_validation_records_finite": True,
            "all_validation_root_counts": 16,
            "illegal_action_count": illegal_action_sum,
            "hard_constraint_violation_count": hard_violation_sum,
        },
        "validation_roots": validation_roots,
        "budget": budget,
        "resource_budget": resource_budget,
        "storage": storage,
        "recovery": recovery,
        "selected_checkpoints": selected_records,
        "checks": {
            "topology_3x5x2": "PASS",
            "candidate_cadence_and_count": "PASS",
            "checkpoint_hash_load_identity_finiteness": "PASS",
            "selection_rule": "PASS",
            "resume_load_identity_finiteness": "PASS",
            "ledger_reconciliation": "PASS",
            "budget_caps": "PASS",
            "compute_time_concurrency_and_zero_api_caps": "PASS",
            "storage_caps": "PASS",
            "validation_root_freeze": "PASS",
            "recovery_evidence_and_history_retention": "PASS",
            "enabled_manifest_frozen_artifacts": "PASS",
        },
    }


def audit_c12_closed_state(project_root: Path) -> dict[str, Any]:
    """Prove that audited C12 evidence is frozen and training is disabled."""

    root = project_root.resolve()
    audit = audit_c12_real_training(root)
    frozen_audit_path = root / FINAL_AUDIT_LOCATOR
    frozen_audit = _load_json_object(frozen_audit_path)
    _require(frozen_audit == audit, "frozen final audit differs from a fresh read-only audit")

    registry_path = root / CHECKPOINT_REGISTRY_LOCATOR
    registry = _load_json_object(registry_path)
    _require(
        registry.get("schema_version") == "exp09-c12-checkpoint-registry-v1",
        "checkpoint registry schema mismatch",
    )
    _require(registry.get("artifact_status") == "FROZEN_AUDITED", "registry is not frozen")
    _require(
        registry.get("source_enabled_manifest_sha256") == ENABLED_MANIFEST_SHA256,
        "registry enabled-manifest binding mismatch",
    )
    _require(
        registry.get("selected_checkpoints") == audit["selected_checkpoints"],
        "checkpoint registry differs from the audited selections",
    )

    budget_path = root / BUDGET_LEDGER_LOCATOR
    frozen_budget = _load_json_object(budget_path)
    _require(
        frozen_budget.get("schema_version") == "exp09-c12-budget-ledger-frozen-v1",
        "frozen budget schema mismatch",
    )
    _require(frozen_budget.get("artifact_status") == "FROZEN_PASS", "budget is not frozen")
    _require(frozen_budget.get("budget") == audit["budget"], "frozen budget differs from audit")
    _require(
        frozen_budget.get("resource_budget") == audit["resource_budget"],
        "frozen resource budget differs from audit",
    )
    _require(frozen_budget.get("storage") == audit["storage"], "frozen storage differs from audit")

    recovery_path = root / DEFECT_RECOVERY_LOCATOR
    frozen_recovery = _load_json_object(recovery_path)
    _require(
        frozen_recovery.get("schema_version") == "exp09-c12-defect-recovery-record-v1",
        "defect-recovery schema mismatch",
    )
    _require(
        frozen_recovery.get("artifact_status") == "FROZEN_RECOVERED_AUDITED",
        "defect recovery is not frozen",
    )
    _require(
        frozen_recovery.get("recovery") == audit["recovery"],
        "defect recovery differs from audit",
    )

    qualification_path = root / QUALIFICATION_REPORT_LOCATOR
    _require(qualification_path.is_file(), "real-training qualification report is missing")
    qualification_text = qualification_path.read_text(encoding="utf-8")
    for marker in (
        "STATUS: C12_REAL_TRAINING_COMPLETE",
        "CHECKPOINT_STATUS: AUDITED_LOADABLE_HASH_BOUND",
        "PERFORMANCE_CLAIM_ALLOWED: false",
        "C14_EXECUTION_AUTHORIZED: false",
        "LOCKED_TEST_STATUS: NOT_EXECUTED",
    ):
        _require(marker in qualification_text, f"qualification report marker is missing: {marker}")

    freeze_path = root / FINAL_FREEZE_LOCATOR
    freeze = _load_json_object(freeze_path)
    _require(
        freeze.get("schema_version") == "exp09-c12-final-freeze-manifest-v1",
        "final freeze manifest schema mismatch",
    )
    _require(
        freeze.get("artifact_status") == "C12_COMPLETE_EVIDENCE_FROZEN",
        "C12 evidence is not frozen",
    )
    expected_freeze_artifacts = {
        DEFAULT_ENABLED_MANIFEST,
        LEDGER_LOCATOR,
        "protocol/c12/c12_training_freeze.json",
        "protocol/c12/c12_validation_roots.json",
        "protocol/c12/c12_environment_freeze.json",
        "protocol/c12/c12_checkpoint_migration_20260727.json",
        "protocol/c12/c12_recovery_report_20260727.json",
        "protocol/c12/c12_recovery_spec_20260727.json",
        "src/exp09/baselines/audit_real_training.py",
        "src/exp09/baselines/freeze_real_training.py",
        "tests/c09_c13/test_c12_final_audit.py",
        FINAL_AUDIT_LOCATOR,
        CHECKPOINT_REGISTRY_LOCATOR,
        BUDGET_LEDGER_LOCATOR,
        DEFECT_RECOVERY_LOCATOR,
        QUALIFICATION_REPORT_LOCATOR,
        C14_HANDOFF_LOCATOR,
    }
    artifacts = freeze.get("frozen_artifacts")
    _require(isinstance(artifacts, list), "final freeze artifact list is missing")
    actual_freeze_artifacts = {
        artifact.get("locator") for artifact in artifacts if isinstance(artifact, dict)
    }
    _require(
        actual_freeze_artifacts == expected_freeze_artifacts,
        "final freeze artifact set mismatch",
    )
    _require(len(artifacts) == len(actual_freeze_artifacts), "final freeze has duplicates")
    for artifact in artifacts:
        locator = artifact.get("locator")
        _require(isinstance(locator, str), "final freeze artifact locator is invalid")
        path = _resolve_locator(root, locator)
        _require(path.is_file(), f"final frozen artifact is missing: {locator}")
        _require(
            _file_hash(path) == artifact.get("sha256"),
            f"final frozen artifact hash mismatch: {locator}",
        )

    current_manifest_path = root / CURRENT_MANIFEST_LOCATOR
    current_manifest = _load_json_object(current_manifest_path)
    expected_closure = (
        "exp09-c12-execution-closure-v1",
        "C12_COMPLETE_TRAINING_DISABLED",
        "C12_CLOSED_C14_HARD_STOP",
        "DISABLED",
        False,
        False,
        False,
    )
    actual_closure = (
        current_manifest.get("schema_version"),
        current_manifest.get("artifact_status"),
        current_manifest.get("execution_scope"),
        current_manifest.get("training_capability"),
        current_manifest.get("c14_execution_authorized"),
        current_manifest.get("api_allowed"),
        current_manifest.get("performance_claim_allowed"),
    )
    _require(actual_closure == expected_closure, "current execution manifest is not closed")
    _require(
        current_manifest.get("source_enabled_manifest")
        == {"locator": DEFAULT_ENABLED_MANIFEST, "sha256": ENABLED_MANIFEST_SHA256},
        "current manifest enabled-source binding mismatch",
    )
    _require(
        current_manifest.get("final_audit")
        == {"locator": FINAL_AUDIT_LOCATOR, "sha256": _file_hash(frozen_audit_path)},
        "current manifest final-audit binding mismatch",
    )
    _require(
        current_manifest.get("final_freeze_manifest")
        == {"locator": FINAL_FREEZE_LOCATOR, "sha256": _file_hash(freeze_path)},
        "current manifest final-freeze binding mismatch",
    )

    gate_text = (root / "protocol/gate_registry.yaml").read_text(encoding="utf-8")
    for marker in (
        "status: C13_STATS_READINESS_PASSED_C14_HARD_STOP",
        "hard_stop_before_step: C14",
        "training_allowed: false",
        "API_allowed: false",
        "pilot_shadow_precision_locked_allowed: false",
    ):
        _require(marker in gate_text, f"C14 hard-stop marker is missing: {marker}")
    c09_c13 = _load_json_object(root / "protocol/c09_c13/c09_c13_manifest.json")
    for field_name in (
        "method_execution_allowed",
        "method_comparison_allowed",
        "training_allowed",
        "api_allowed",
        "shadow_precision_locked_allowed",
        "performance_claim_allowed",
    ):
        _require(c09_c13.get(field_name) is False, f"C14 boundary enables {field_name}")
    _require(c09_c13.get("hard_stop_before_step") == "C14", "C14 hard stop moved")

    return {
        "schema_version": "exp09-c12-closed-state-audit-v1",
        "artifact_status": "PASS_C12_COMPLETE_TRAINING_DISABLED_C14_HARD_STOP",
        "training_audit": audit,
        "closure": {
            "enabled_manifest_archived_and_hash_bound": True,
            "final_evidence_hash_frozen": True,
            "training_capability": "DISABLED",
            "api_allowed": False,
            "performance_claim_allowed": False,
            "c14_execution_authorized": False,
            "locked_test_executed": False,
        },
    }


def _audit_enabled_manifest(root: Path, path: Path) -> dict[str, Any]:
    _require(path.is_file(), f"enabled execution manifest is missing: {path}")
    _require(
        _file_hash(path) == ENABLED_MANIFEST_SHA256,
        "enabled execution manifest archive hash mismatch",
    )
    manifest = _load_json_object(path)
    expected = (
        "exp09-c12-execution-manifest-v1",
        "SIGNED_PREFLIGHT_PASSED_EXECUTION_ENABLED",
        "C12_REAL_RL_TRAINING_ONLY",
        "ENABLED_ONLY_FOR_THIS_MANIFEST_HASH",
        False,
        False,
        False,
    )
    actual = (
        manifest.get("schema_version"),
        manifest.get("artifact_status"),
        manifest.get("execution_scope"),
        manifest.get("training_capability"),
        manifest.get("c14_execution_authorized"),
        manifest.get("api_allowed"),
        manifest.get("performance_claim_allowed"),
    )
    _require(actual == expected, "enabled execution manifest semantics mismatch")
    artifacts = manifest.get("frozen_artifacts")
    _require(isinstance(artifacts, list) and artifacts, "enabled manifest artifact list is empty")
    seen: set[str] = set()
    for artifact in artifacts:
        _require(isinstance(artifact, dict), "enabled manifest artifact must be an object")
        locator = artifact.get("locator")
        _require(isinstance(locator, str), "enabled manifest artifact locator is invalid")
        _require(locator not in seen, f"duplicate enabled manifest artifact: {locator}")
        seen.add(locator)
        artifact_path = _resolve_locator(root, locator)
        _require(artifact_path.is_file(), f"frozen execution artifact is missing: {locator}")
        _require(
            _file_hash(artifact_path) == artifact.get("sha256"),
            f"frozen execution artifact hash mismatch: {locator}",
        )
    return manifest


def _audit_validation_roots(
    root: Path, training_freeze: dict[str, Any]
) -> dict[str, Any]:
    record = _load_json_object(root / "protocol/c12/c12_validation_roots.json")
    _require(record.get("roots_sha256") == VALIDATION_ROOTS_SHA256, "root hash mismatch")
    _require(
        training_freeze.get("validation", {}).get("validation_roots_sha256")
        == VALIDATION_ROOTS_SHA256,
        "training freeze validation-root hash mismatch",
    )
    roots: dict[str, list[str]] = {}
    for scenario in SCENARIOS:
        values = record.get(scenario)
        _require(isinstance(values, list), f"{scenario}: validation roots must be a list")
        _require(len(values) == 16 and len(set(values)) == 16, f"{scenario}: root count mismatch")
        _require(
            all(isinstance(value, str) and value.startswith(f"c12_validation_{scenario}_") for value in values),
            f"{scenario}: validation root domain mismatch",
        )
        roots[scenario] = values
    _require(set(roots["simple"]).isdisjoint(roots["complex"]), "validation roots overlap")
    _require(_json_hash(roots) == VALIDATION_ROOTS_SHA256, "validation root content hash mismatch")
    _require(training_freeze.get("methods") == list(METHODS), "frozen method list mismatch")
    _require(training_freeze.get("train_seeds") == list(TRAIN_SEEDS), "frozen seed list mismatch")
    return {
        "sha256": VALIDATION_ROOTS_SHA256,
        "root_count_per_scenario": 16,
        "matched_crn_across_methods": True,
        "isolated_from_c14_c15": True,
    }


def _audit_run_record(
    run: dict[str, Any], method_id: str, scenario: str, train_seed: int
) -> None:
    run_id = _run_id(method_id, scenario, train_seed)
    expected = {
        "run_id": run_id,
        "method_id": method_id,
        "scenario": scenario,
        "train_seed": train_seed,
        "episodes": EPISODES[scenario],
        "max_steps": MAX_STEPS[scenario],
        "training_steps": EPISODES[scenario] * MAX_STEPS[scenario],
        "candidate_count": EPISODES[scenario] // 100,
        "illegal_action_count": 0,
        "hard_constraint_violation_count": 0,
        "training_root_policy": "METHOD_INDEPENDENT_KEYED_SEGMENTS_NO_ROOT_FILTERING",
    }
    for field_name, expected_value in expected.items():
        _require(run.get(field_name) == expected_value, f"{run_id}: {field_name} mismatch")
    _require(_finite_number(run.get("mean_training_reward")), f"{run_id}: reward is non-finite")
    _require(_finite_number(run.get("mean_loss")), f"{run_id}: loss is non-finite")
    resumed = run.get("resumed_from_episode")
    if run_id == "DQN_simple_seed101":
        _require(resumed == 471, "recovered run must resume from episode 471")
    else:
        _require(resumed is None, f"{run_id}: unexpected recovery marker")


def _audit_candidate_record(candidate: dict[str, Any], run_id: str) -> None:
    required = {
        "episode",
        "relative_path",
        "sha256",
        "validation_root_count",
        "worst_user_time_average_AoI_ms",
        "collision_event_rate",
        "jain_freshness",
        "illegal_action_count",
        "hard_constraint_violation_count",
        "eligible",
    }
    _require(set(candidate) == required, f"{run_id}: candidate record schema mismatch")
    _require(type(candidate["episode"]) is int, f"{run_id}: candidate episode is invalid")
    _require(candidate["validation_root_count"] == 16, f"{run_id}: root count mismatch")
    _require(candidate["illegal_action_count"] == 0, f"{run_id}: illegal candidate")
    _require(candidate["hard_constraint_violation_count"] == 0, f"{run_id}: violation")
    _require(candidate["eligible"] is True, f"{run_id}: ineligible candidate")
    _require(_is_sha256(candidate["sha256"]), f"{run_id}: candidate SHA-256 is invalid")
    _resolve_relative_output_locator(candidate["relative_path"])
    for field_name in (
        "worst_user_time_average_AoI_ms",
        "collision_event_rate",
        "jain_freshness",
    ):
        _require(
            _finite_decimal_text(candidate[field_name]),
            f"{run_id}: candidate {field_name} is non-finite",
        )


def _audit_candidate_checkpoint(
    output_root: Path,
    candidate: dict[str, Any],
    *,
    method_id: str,
    scenario: str,
    train_seed: int,
    agent: C12QAgent,
) -> None:
    path = output_root / _resolve_relative_output_locator(candidate["relative_path"])
    _require(path.is_file(), f"formal candidate is missing: {candidate['relative_path']}")
    _require(_file_hash(path) == candidate["sha256"], f"candidate hash mismatch: {path}")
    payload = load_checkpoint_payload(path, map_location=torch.device("cpu"))
    _audit_checkpoint_identity(
        payload,
        method_id=method_id,
        scenario=scenario,
        train_seed=train_seed,
        episode=int(candidate["episode"]),
        kind="INFERENCE_CANDIDATE",
    )
    state = payload.get("inference_state")
    _require(isinstance(state, dict), f"candidate inference state is missing: {path}")
    _assert_tensors_finite(state, str(path))
    try:
        agent.load_inference_state(state)
    except Exception as exc:  # pragma: no cover - exact Torch error is version-specific
        raise C12AuditError(f"candidate model state is not loadable: {path}") from exc


def _audit_resume_checkpoint(
    path: Path,
    *,
    candidates: list[dict[str, Any]],
    method_id: str,
    scenario: str,
    train_seed: int,
    agent: C12QAgent,
) -> dict[str, int]:
    _require(path.is_file(), f"resume checkpoint is missing: {path}")
    payload = load_checkpoint_payload(path, map_location=torch.device("cpu"))
    _audit_checkpoint_identity(
        payload,
        method_id=method_id,
        scenario=scenario,
        train_seed=train_seed,
        episode=EPISODES[scenario],
        kind="DETERMINISTIC_RESUME",
    )
    _require(
        payload.get("next_episode") == EPISODES[scenario] + 1,
        f"resume next_episode mismatch: {path}",
    )
    _require(list(payload.get("candidates", ())) == candidates, f"resume candidates mismatch: {path}")
    summary = payload.get("summary_state")
    _require(isinstance(summary, dict), f"resume summary is missing: {path}")
    _require(summary.get("episode_count") == EPISODES[scenario], f"resume summary mismatch: {path}")
    _require(type(summary.get("loss_count")) is int, f"resume loss count mismatch: {path}")
    _require(_finite_number(summary.get("loss_sum")), f"resume loss sum is non-finite: {path}")
    _require(_finite_number(summary.get("reward_sum")), f"resume reward sum is non-finite: {path}")
    state = payload.get("agent_state")
    _require(isinstance(state, dict), f"resume agent state is missing: {path}")
    _assert_tensors_finite(state, str(path))
    try:
        agent.load_checkpoint_state(state)
    except Exception as exc:  # pragma: no cover - exact Torch error is version-specific
        raise C12AuditError(f"resume model state is not loadable: {path}") from exc
    budget = payload.get("budget")
    _require(isinstance(budget, dict), f"resume budget is missing: {path}")
    _audit_budget_fields(budget, prefix=f"resume budget {path}")
    return {key: int(value) for key, value in budget.items()}


def _audit_checkpoint_identity(
    payload: dict[str, Any],
    *,
    method_id: str,
    scenario: str,
    train_seed: int,
    episode: int,
    kind: str,
) -> None:
    expected = (
        CHECKPOINT_SCHEMA_VERSION,
        ENABLED_MANIFEST_SHA256,
        method_id,
        scenario,
        train_seed,
        episode,
        asdict(FROZEN_AGENT_CONFIGS[method_id]),
        kind,
    )
    actual = (
        payload.get("schema_version"),
        payload.get("manifest_hash"),
        payload.get("method_id"),
        payload.get("scenario"),
        payload.get("train_seed"),
        payload.get("episode"),
        payload.get("config"),
        payload.get("checkpoint_kind"),
    )
    _require(actual == expected, "checkpoint identity/configuration mismatch")


def _audit_candidate_filesystem(output_root: Path, formal_paths: set[str]) -> None:
    filesystem_paths = {
        path.relative_to(output_root).as_posix()
        for path in (output_root / "runs").glob("*/candidates*/episode_*.pt")
    }
    _require(
        filesystem_paths - formal_paths == set(HISTORICAL_CANDIDATES),
        "unexpected candidate files exist outside the 375 formal candidates",
    )
    _require(not formal_paths - filesystem_paths, "formal candidate files are missing")
    _require(len(filesystem_paths) == 379, "candidate filesystem total must be exactly 379")


def _audit_budget(
    ledger: dict[str, Any],
    *,
    training_steps_sum: int,
    resume_budgets: dict[str, dict[str, int]],
) -> dict[str, Any]:
    budget = ledger.get("budget")
    _require(isinstance(budget, dict), "ledger budget is missing")
    _audit_budget_fields(budget, prefix="ledger budget")
    _require(training_steps_sum == 1_080_000, "completed training sum is not 1,080,000")
    _require(budget["training_steps"] == training_steps_sum, "ledger training sum mismatch")
    _require(
        budget["attempted_training_steps"] <= TRAINING_HARD_CAP,
        "training attempt cap exceeded",
    )
    _require(
        budget["attempted_validation_steps"] <= VALIDATION_HARD_CAP,
        "validation cap exceeded",
    )
    attempted_total = budget["attempted_training_steps"] + budget["attempted_validation_steps"]
    _require(attempted_total <= COMBINED_HARD_CAP, "combined step cap exceeded")
    _require(
        budget["validation_steps"] == budget["attempted_validation_steps"],
        "validation attempted/completed accounting mismatch",
    )
    final_run_id = _run_id(METHODS[-1], SCENARIOS[-1], TRAIN_SEEDS[-1])
    _require(resume_budgets[final_run_id] == budget, "last resume budget differs from ledger")
    for run_id, resume_budget in resume_budgets.items():
        _require(
            all(resume_budget[key] <= budget[key] for key in budget),
            f"{run_id}: resume budget exceeds final ledger",
        )
    return {
        **budget,
        "attempted_environment_steps": attempted_total,
        "training_transition_hard_cap": TRAINING_HARD_CAP,
        "validation_step_hard_cap": VALIDATION_HARD_CAP,
        "combined_environment_step_hard_cap": COMBINED_HARD_CAP,
        "all_caps_pass": True,
    }


def _audit_budget_fields(budget: Mapping[str, Any], *, prefix: str) -> None:
    required = {
        "training_steps",
        "validation_steps",
        "attempted_training_steps",
        "attempted_validation_steps",
    }
    _require(set(budget) == required, f"{prefix}: schema mismatch")
    _require(
        all(type(value) is int and value >= 0 for value in budget.values()),
        f"{prefix}: values must be non-negative integers",
    )
    _require(
        budget["training_steps"] <= budget["attempted_training_steps"],
        f"{prefix}: training completion exceeds attempts",
    )
    _require(
        budget["validation_steps"] <= budget["attempted_validation_steps"],
        f"{prefix}: validation completion exceeds attempts",
    )


def _audit_recovery(
    root: Path,
    output_root: Path,
    formal_candidate_paths: set[str],
    budget: dict[str, Any],
) -> dict[str, Any]:
    report_path = root / "protocol/c12/c12_recovery_report_20260727.json"
    spec_path = root / "protocol/c12/c12_recovery_spec_20260727.json"
    report = _load_json_object(report_path)
    spec = _load_json_object(spec_path)
    _require(
        report.get("status") == "DETERMINISTIC_REPLAY_COMPLETE_RESUME_LOADABLE",
        "recovery report status mismatch",
    )
    _require(report.get("target_manifest_sha256") == ENABLED_MANIFEST_SHA256, "recovery target mismatch")
    _require(spec.get("target_manifest_sha256") == ENABLED_MANIFEST_SHA256, "recovery spec target mismatch")
    _require(report.get("run_id") == "DQN_simple_seed101", "recovery run mismatch")
    comparisons = report.get("candidate_comparisons")
    _require(
        isinstance(comparisons, list)
        and [item.get("episode") for item in comparisons] == [100, 200, 300, 400]
        and all(item.get("equal") is True for item in comparisons),
        "deterministic recovery comparisons did not all pass",
    )
    _require(report.get("replay_validation_steps") == 0, "recovery repeated validation")
    _require(report.get("replay_attempted_training_steps") == 11_280, "recovery replay count mismatch")
    corrupt = report.get("source_corrupt_checkpoint")
    _require(isinstance(corrupt, dict) and corrupt.get("preserved") is True, "corrupt checkpoint not preserved")
    corrupt_path = _resolve_locator(root / "artifacts/c12_real_training", corrupt["relative_path"])
    _require(_file_hash(corrupt_path) == corrupt.get("sha256"), "corrupt checkpoint evidence hash mismatch")
    _require(
        corrupt.get("sha256")
        == "53DD2246E103C4C53536946F1398726D9038BD4F92B5E07B59873148E6C226A5",
        "corrupt checkpoint evidence identity mismatch",
    )
    recovered_pickle = report.get("recovered_data_pickle")
    _require(isinstance(recovered_pickle, dict), "recovered data.pkl evidence is missing")
    recovered_pickle_path = _resolve_locator(
        root / "artifacts/c12_real_training", recovered_pickle["relative_path"]
    )
    _require(
        _file_hash(recovered_pickle_path) == recovered_pickle.get("sha256"),
        "recovered data.pkl hash mismatch",
    )
    spec_candidates = spec.get("recovered_candidates")
    migrations = report.get("candidate_migrations")
    _require(isinstance(spec_candidates, list) and len(spec_candidates) == 4, "recovery spec candidate mismatch")
    _require(isinstance(migrations, list) and len(migrations) == 4, "recovery migration count mismatch")
    for spec_candidate, migration, historical_path in zip(
        spec_candidates, migrations, HISTORICAL_CANDIDATES, strict=True
    ):
        _require(
            spec_candidate.get("source_relative_path") == historical_path,
            "historical recovery candidate locator mismatch",
        )
        historical_file = output_root / _resolve_relative_output_locator(historical_path)
        _require(
            _file_hash(historical_file) == spec_candidate.get("source_sha256"),
            "historical recovery candidate hash mismatch",
        )
        formal_path = migration.get("relative_path")
        _require(formal_path in formal_candidate_paths, "recovered formal candidate is not registered")
        _require(
            _file_hash(output_root / _resolve_relative_output_locator(formal_path))
            == migration.get("sha256"),
            "recovered formal candidate hash mismatch",
        )
    recovery_budget = report.get("budget_after_recovery")
    _require(isinstance(recovery_budget, dict), "recovery budget is missing")
    _require(
        budget["attempted_training_steps"] - budget["training_steps"]
        == recovery_budget["attempted_training_steps"] - recovery_budget["training_steps"],
        "final attempted-training overhead is not explained by recovery",
    )
    return {
        "status": report["status"],
        "run_id": report["run_id"],
        "replayed_training_steps": report["replay_attempted_training_steps"],
        "replayed_validation_steps": report["replay_validation_steps"],
        "candidate_state_comparisons_passed": 4,
        "historical_candidates_preserved": 4,
        "corrupt_checkpoint_preserved": True,
        "recovery_report_sha256": _file_hash(report_path),
        "recovery_spec_sha256": _file_hash(spec_path),
        "corrupt_checkpoint_sha256": corrupt["sha256"],
        "recovered_data_pickle_sha256": recovered_pickle["sha256"],
    }


def _audit_storage(root: Path) -> dict[str, Any]:
    final_root = root / OUTPUT_LOCATOR
    c12_root = root / "artifacts/c12_real_training"
    final_bytes = _directory_bytes(final_root)
    total_bytes = _directory_bytes(c12_root)
    checkpoint_log_cap = 15 * 1024**3
    total_cap = 30 * 1024**3
    _require(final_bytes <= checkpoint_log_cap, "checkpoint/log storage cap exceeded")
    _require(total_bytes <= total_cap, "total C12 storage cap exceeded")
    return {
        "checkpoint_log_bytes": final_bytes,
        "checkpoint_log_byte_cap": checkpoint_log_cap,
        "total_c12_bytes": total_bytes,
        "total_c12_byte_cap": total_cap,
        "all_caps_pass": True,
    }


def _audit_resource_budget(
    root: Path, training_freeze: dict[str, Any]
) -> dict[str, Any]:
    frozen_budget = training_freeze.get("budget")
    _require(isinstance(frozen_budget, dict), "training freeze resource budget is missing")
    environment = _load_json_object(root / "protocol/c12/c12_environment_freeze.json")
    _require(environment.get("device") == "cpu", "C12 device was not CPU")
    _require(environment.get("torch_cuda_available") is False, "C12 Torch exposed CUDA")
    _require(environment.get("CPU_threads_per_job") == 8, "C12 thread cap mismatch")
    _require(environment.get("API_or_provider_calls") == 0, "C12 used an API/provider")
    _require(frozen_budget.get("training_job_concurrency") == 1, "concurrency cap mismatch")
    _require(frozen_budget.get("CPU_threads_per_job") == 8, "frozen thread cap mismatch")
    for field_name in ("API_calls", "LLM_tokens", "API_cost_CNY", "API_cost_USD"):
        _require(frozen_budget.get(field_name) == 0, f"non-zero frozen C12 {field_name}")

    output_root = root / OUTPUT_LOCATOR
    ledger_path = root / LEDGER_LOCATOR
    started_at = output_root.stat().st_ctime
    completed_at = ledger_path.stat().st_mtime
    _require(completed_at >= started_at, "C12 wall-time evidence is inconsistent")
    elapsed_wall_seconds = completed_at - started_at
    wall_cap_seconds = int(frozen_budget["wall_hours"]) * 60 * 60
    cpu_core_second_upper_bound = elapsed_wall_seconds * int(
        frozen_budget["CPU_threads_per_job"]
    )
    cpu_core_second_cap = int(frozen_budget["CPU_core_hours"]) * 60 * 60
    _require(elapsed_wall_seconds <= wall_cap_seconds, "C12 wall-time cap exceeded")
    _require(
        cpu_core_second_upper_bound <= cpu_core_second_cap,
        "C12 conservative CPU-core-hour upper bound exceeds cap",
    )
    return {
        "device": "cpu",
        "gpu_hours": 0,
        "gpu_hour_cap": frozen_budget["GPU_hours"],
        "cpu_thread_cap": frozen_budget["CPU_threads_per_job"],
        "cpu_core_second_upper_bound": math.ceil(cpu_core_second_upper_bound),
        "cpu_core_second_cap": cpu_core_second_cap,
        "elapsed_wall_second_upper_bound": math.ceil(elapsed_wall_seconds),
        "wall_second_cap": wall_cap_seconds,
        "training_job_concurrency": 1,
        "training_job_concurrency_cap": frozen_budget["training_job_concurrency"],
        "concurrency_evidence": "FROZEN_TRAIN_SUITE_SEQUENTIAL_LOOPS_NO_WORKER_POOL",
        "api_calls": 0,
        "llm_tokens": 0,
        "api_cost_cny": 0,
        "api_cost_usd": 0,
        "all_caps_pass": True,
    }


def _selection_key(candidate: dict[str, Any]) -> tuple[Any, ...]:
    if not candidate["eligible"] or candidate["hard_constraint_violation_count"]:
        return (1, Decimal("Infinity"), Decimal("Infinity"), Decimal("Infinity"), 0, "")
    return (
        0,
        Decimal(candidate["worst_user_time_average_AoI_ms"]),
        Decimal(candidate["collision_event_rate"]),
        -Decimal(candidate["jain_freshness"]),
        int(candidate["episode"]),
        candidate["sha256"],
    )


def _make_agents() -> dict[str, C12QAgent]:
    return {
        method_id: C12QAgent(
            config=FROZEN_AGENT_CONFIGS[method_id],
            vector_size=VECTOR_OBSERVATION_COUNT,
            node_feature_count=GRAPH_NODE_FEATURE_COUNT,
            action_count=ACTION_COUNT,
            seed=0,
            device=torch.device("cpu"),
        )
        for method_id in METHODS
    }


def _assert_tensors_finite(value: Any, path: str) -> None:
    if isinstance(value, torch.Tensor):
        if (value.is_floating_point() or value.is_complex()) and not torch.isfinite(value).all():
            raise C12AuditError(f"non-finite checkpoint tensor: {path}")
        return
    if isinstance(value, np.ndarray):
        if (np.issubdtype(value.dtype, np.floating) or np.issubdtype(value.dtype, np.complexfloating)) and not np.isfinite(value).all():
            raise C12AuditError(f"non-finite checkpoint array: {path}")
        return
    if isinstance(value, (float, np.floating)) and not math.isfinite(float(value)):
        raise C12AuditError(f"non-finite checkpoint scalar: {path}")
    if is_dataclass(value) and not isinstance(value, type):
        for field in fields(value):
            _assert_tensors_finite(getattr(value, field.name), f"{path}.{field.name}")
        return
    if isinstance(value, Mapping):
        for key, child in value.items():
            _assert_tensors_finite(child, f"{path}.{key}")
        return
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        for index, child in enumerate(value):
            _assert_tensors_finite(child, f"{path}[{index}]")


def _index_by_run_id(records: list[Any], description: str) -> dict[str, dict[str, Any]]:
    indexed: dict[str, dict[str, Any]] = {}
    for record in records:
        _require(isinstance(record, dict), f"{description} must be an object")
        run_id = record.get("run_id")
        _require(isinstance(run_id, str), f"{description} run_id is invalid")
        _require(run_id not in indexed, f"duplicate {description}: {run_id}")
        indexed[run_id] = record
    return indexed


def _resolve_relative_output_locator(locator: Any) -> Path:
    _require(isinstance(locator, str), "output locator must be a string")
    _require("\\" not in locator, f"unsafe output locator: {locator}")
    path = PurePosixPath(locator)
    _require(
        not path.is_absolute()
        and ".." not in path.parts
        and bool(path.parts)
        and path.parts[0] == "runs"
        and ":" not in path.parts[0],
        f"unsafe output locator: {locator}",
    )
    return Path(*path.parts)


def _resolve_locator(root: Path, locator: str) -> Path:
    _require(isinstance(locator, str) and locator, "locator must be a non-empty string")
    _require("\\" not in locator, f"unsafe locator: {locator}")
    path = PurePosixPath(locator)
    _require(
        not path.is_absolute() and ".." not in path.parts and ":" not in path.parts[0],
        f"unsafe locator: {locator}",
    )
    resolved = (root / Path(*path.parts)).resolve()
    _require(resolved == root or root in resolved.parents, f"locator escapes root: {locator}")
    return resolved


def _run_id(method_id: str, scenario: str, train_seed: int) -> str:
    return f"{method_id}_{scenario}_seed{train_seed}"


def _finite_decimal_text(value: Any) -> bool:
    if not isinstance(value, str):
        return False
    try:
        return Decimal(value).is_finite()
    except InvalidOperation:
        return False


def _finite_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _is_sha256(value: Any) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(character in "0123456789ABCDEF" for character in value)
    )


def _load_json_object(path: Path) -> dict[str, Any]:
    _require(path.is_file(), f"JSON evidence is missing: {path}")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise C12AuditError(f"JSON evidence is unreadable: {path}") from exc
    _require(isinstance(value, dict), f"JSON evidence must be an object: {path}")
    return value


def _file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def _json_hash(value: Any) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest().upper()


def _directory_bytes(root: Path) -> int:
    return sum(path.stat().st_size for path in root.rglob("*") if path.is_file())


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise C12AuditError(message)


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    parser.add_argument("--enabled-manifest", default=DEFAULT_ENABLED_MANIFEST)
    arguments = parser.parse_args()
    report = audit_c12_real_training(
        arguments.project_root,
        enabled_manifest_locator=arguments.enabled_manifest,
    )
    print(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
