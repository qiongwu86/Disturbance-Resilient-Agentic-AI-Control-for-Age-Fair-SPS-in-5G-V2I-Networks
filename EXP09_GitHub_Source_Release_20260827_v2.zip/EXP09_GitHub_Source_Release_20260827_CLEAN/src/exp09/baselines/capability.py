"""C07 baseline capability-table contracts."""

from dataclasses import dataclass

from exp09.baselines.registry import (
    METHOD_REGISTRY_ENTRY_SCHEMA_VERSION,
    METHOD_REGISTRY_SCHEMA_VERSION,
    MethodCapability,
    MethodRegistry,
    MethodRegistryEntry,
    QualificationStatus,
)

CAPABILITY_TABLE_ROW_SCHEMA_VERSION = "exp09-capability-table-row-v1"
CAPABILITY_TABLE_SCHEMA_VERSION = "exp09-capability-table-v1"


@dataclass(frozen=True, slots=True)
class CapabilityTableRow:
    schema_version: str
    method_id: str
    capability: MethodCapability
    observable_fields: tuple[str, ...]
    model_access: str
    program_access: str
    transition_budget: int
    training_budget: int
    checkpoint_rule: str
    qualification_status: QualificationStatus

    @classmethod
    def from_registry_entry(cls, entry: MethodRegistryEntry) -> "CapabilityTableRow":
        return cls(
            schema_version=CAPABILITY_TABLE_ROW_SCHEMA_VERSION,
            method_id=entry.method_id,
            capability=entry.capability,
            observable_fields=entry.observable_fields,
            model_access=entry.model_access,
            program_access=entry.program_access,
            transition_budget=entry.transition_budget,
            training_budget=entry.training_budget,
            checkpoint_rule=entry.checkpoint_rule,
            qualification_status=entry.qualification_status,
        )

    def __post_init__(self) -> None:
        MethodRegistryEntry(
            schema_version=METHOD_REGISTRY_ENTRY_SCHEMA_VERSION,
            method_id=self.method_id,
            capability=self.capability,
            observable_fields=self.observable_fields,
            model_access=self.model_access,
            program_access=self.program_access,
            transition_budget=self.transition_budget,
            training_budget=self.training_budget,
            checkpoint_rule=self.checkpoint_rule,
            config_hash="0" * 64,
            qualification_status=self.qualification_status,
            evidence_hashes=(),
        )


@dataclass(frozen=True, slots=True)
class CapabilityTable:
    schema_version: str
    rows: tuple[CapabilityTableRow, ...]

    def __post_init__(self) -> None:
        if self.schema_version != CAPABILITY_TABLE_SCHEMA_VERSION:
            raise ValueError("unsupported capability-table schema version")
        if not isinstance(self.rows, tuple):
            raise ValueError("rows must be a tuple")
        method_ids = tuple(row.method_id for row in self.rows)
        if len(set(method_ids)) != len(method_ids):
            raise ValueError("capability rows must have unique method IDs")
        if any(row.qualification_status is QualificationStatus.QUALIFIED for row in self.rows):
            raise ValueError("C07 scaffold cannot mark methods as qualified")


def capability_table_from_registry(registry: MethodRegistry) -> CapabilityTable:
    if not isinstance(registry, MethodRegistry):
        raise ValueError("registry must be a MethodRegistry")
    if registry.schema_version != METHOD_REGISTRY_SCHEMA_VERSION:
        raise ValueError("unsupported method-registry schema version")
    return CapabilityTable(
        schema_version=CAPABILITY_TABLE_SCHEMA_VERSION,
        rows=tuple(CapabilityTableRow.from_registry_entry(entry) for entry in registry.entries),
    )

