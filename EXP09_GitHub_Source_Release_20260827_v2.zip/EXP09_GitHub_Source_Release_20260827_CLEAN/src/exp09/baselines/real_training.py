"""Manifest-driven C12 real training, validation, selection, and audit runner."""

from dataclasses import asdict, dataclass
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path
import time
from typing import Any

import torch

from exp09.contracts.determinism import stable_digest_hex
from exp09.contracts.tape import TapeArm
from exp09.evaluation.disturbance_tape import build_primary_influx_tape
from exp09.evaluation.rl_episode import C12Episode

from .rl_environment import (
    ACTION_COUNT,
    GRAPH_NODE_FEATURE_COUNT,
    VECTOR_OBSERVATION_COUNT,
)
from .rl_models import (
    C12QAgent,
    FROZEN_AGENT_CONFIGS,
    load_checkpoint_payload,
    save_checkpoint_payload,
)

METHODS = ("DQN", "DQN_Strong", "GNN_DDQN")
TRAIN_SEEDS = (101, 202, 303, 404, 505)
SCENARIOS = ("simple", "complex")
SCENARIO_ARMS = {"simple": TapeArm.REFERENCE, "complex": TapeArm.EVENT}
EPISODES = {"simple": 1_000, "complex": 1_500}
MAX_STEPS = {"simple": 24, "complex": 32}
VALIDATION_EVERY = 100
VALIDATION_ROOT_COUNT = 16
TRAINING_HARD_CAP = 1_200_000
VALIDATION_HARD_CAP = 172_800
COMBINED_HARD_CAP = 1_372_800
CHECKPOINT_SCHEMA_VERSION = "exp09-c12-real-checkpoint-v1"
RUN_LEDGER_SCHEMA_VERSION = "exp09-c12-real-run-ledger-v1"


@dataclass(frozen=True, slots=True)
class BudgetLedger:
    training_steps: int = 0
    validation_steps: int = 0
    attempted_training_steps: int = 0
    attempted_validation_steps: int = 0

    def reserve_training_attempts(self, count: int) -> "BudgetLedger":
        updated = BudgetLedger(
            self.training_steps,
            self.validation_steps,
            self.attempted_training_steps + count,
            self.attempted_validation_steps,
        )
        updated.validate()
        return updated

    def complete_training(self, count: int = 1) -> "BudgetLedger":
        updated = BudgetLedger(
            self.training_steps + count,
            self.validation_steps,
            self.attempted_training_steps,
            self.attempted_validation_steps,
        )
        updated.validate()
        return updated

    def consume_validation(self, count: int = 1) -> "BudgetLedger":
        updated = BudgetLedger(
            self.training_steps,
            self.validation_steps + count,
            self.attempted_training_steps,
            self.attempted_validation_steps + count,
        )
        updated.validate()
        return updated

    def validate(self) -> None:
        if self.training_steps > self.attempted_training_steps:
            raise RuntimeError("completed training steps exceed pre-recorded attempts")
        if self.validation_steps > self.attempted_validation_steps:
            raise RuntimeError("completed validation steps exceed attempted validation steps")
        if self.attempted_training_steps > TRAINING_HARD_CAP:
            raise RuntimeError("C12 training transition hard cap exceeded")
        if self.attempted_validation_steps > VALIDATION_HARD_CAP:
            raise RuntimeError("C12 validation step hard cap exceeded")
        if self.attempted_training_steps + self.attempted_validation_steps > COMBINED_HARD_CAP:
            raise RuntimeError("C12 combined environment-step hard cap exceeded")


def validation_roots() -> dict[str, tuple[str, ...]]:
    return {
        scenario: tuple(
            f"c12_validation_{scenario}_{index:02d}_"
            + stable_digest_hex("exp09-c12-validation-root-v1", scenario, index)[:12].lower()
            for index in range(VALIDATION_ROOT_COUNT)
        )
        for scenario in SCENARIOS
    }


def validation_roots_hash() -> str:
    primitive = validation_roots()
    return _json_hash(primitive)


def train_root(
    scenario: str,
    train_seed: int,
    episode: int,
    segment: int = 0,
) -> str:
    digest = stable_digest_hex(
        "exp09-c12-train-root-v1", scenario, train_seed, episode, segment
    )
    return (
        f"c12_train_{scenario}_{train_seed}_{episode:04d}_{segment:02d}_"
        f"{digest[:12].lower()}"
    )


def train_suite(
    output_root: Path,
    *,
    manifest_hash: str,
    device_name: str = "cpu",
    resume: bool = True,
    methods: tuple[str, ...] = METHODS,
    seeds: tuple[int, ...] = TRAIN_SEEDS,
    scenarios: tuple[str, ...] = SCENARIOS,
    episode_limits: dict[str, int] | None = None,
    validation_every: int = VALIDATION_EVERY,
    validation_root_limit: int = VALIDATION_ROOT_COUNT,
    execution_manifest_path: Path | None = None,
    max_wall_seconds: int = 96 * 60 * 60,
    max_process_cpu_seconds: int = 144 * 60 * 60,
    max_storage_bytes: int = 30 * 1024**3,
) -> dict[str, Any]:
    _require_sha256(manifest_hash, "manifest_hash")
    if execution_manifest_path is not None:
        _verify_execution_manifest(execution_manifest_path, manifest_hash)
    device = torch.device(device_name)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("requested CUDA device is unavailable")
    torch.use_deterministic_algorithms(True)
    torch.set_num_threads(8)
    output_root.mkdir(parents=True, exist_ok=True)
    ledger_path = output_root / "run_ledger.json"
    ledger = _load_budget_ledger(ledger_path) if resume and ledger_path.is_file() else BudgetLedger()
    started = time.monotonic()
    cpu_started = time.process_time()
    run_records: list[dict[str, Any]] = []
    selected_records: list[dict[str, Any]] = []
    if any(method_id not in METHODS for method_id in methods):
        raise ValueError("training subset contains an unknown method")
    if any(seed not in TRAIN_SEEDS for seed in seeds):
        raise ValueError("training subset contains an unauthorized seed")
    if any(scenario not in SCENARIOS for scenario in scenarios):
        raise ValueError("training subset contains an unknown scenario")
    for method_id in methods:
        for train_seed in seeds:
            for scenario in scenarios:
                result, ledger = _train_one(
                    output_root,
                    manifest_hash=manifest_hash,
                    method_id=method_id,
                    train_seed=train_seed,
                    scenario=scenario,
                    device=device,
                    ledger=ledger,
                    ledger_path=ledger_path,
                    resume=resume,
                    episode_limit=(episode_limits or EPISODES)[scenario],
                    validation_every=validation_every,
                    validation_root_limit=validation_root_limit,
                    started=started,
                    cpu_started=cpu_started,
                    max_wall_seconds=max_wall_seconds,
                    max_process_cpu_seconds=max_process_cpu_seconds,
                )
                run_records.append(result["run"])
                selected_records.append(result["selected_checkpoint"])
                _write_json(
                    ledger_path,
                    {
                        "schema_version": RUN_LEDGER_SCHEMA_VERSION,
                        "manifest_hash": manifest_hash,
                        "budget": asdict(ledger),
                        "completed_runs": run_records,
                        "selected_checkpoints": selected_records,
                    },
                )
                _enforce_runtime_caps(
                    output_root,
                    started,
                    cpu_started,
                    max_wall_seconds=max_wall_seconds,
                    max_process_cpu_seconds=max_process_cpu_seconds,
                    max_storage_bytes=max_storage_bytes,
                )
    return {
        "schema_version": RUN_LEDGER_SCHEMA_VERSION,
        "manifest_hash": manifest_hash,
        "budget": asdict(ledger),
        "elapsed_seconds": time.monotonic() - started,
        "completed_runs": run_records,
        "selected_checkpoints": selected_records,
    }


def _train_one(
    output_root: Path,
    *,
    manifest_hash: str,
    method_id: str,
    train_seed: int,
    scenario: str,
    device: torch.device,
    ledger: BudgetLedger,
    ledger_path: Path,
    resume: bool,
    episode_limit: int,
    validation_every: int,
    validation_root_limit: int,
    started: float,
    cpu_started: float,
    max_wall_seconds: int,
    max_process_cpu_seconds: int,
) -> tuple[dict[str, Any], BudgetLedger]:
    run_id = f"{method_id}_{scenario}_seed{train_seed}"
    run_dir = output_root / "runs" / run_id
    final_path = run_dir / "run_complete.json"
    if resume and final_path.is_file():
        complete = json.loads(final_path.read_text(encoding="utf-8"))
        _verify_selected_record(output_root, complete["selected_checkpoint"], manifest_hash)
        return complete, ledger
    config = FROZEN_AGENT_CONFIGS[method_id]
    agent = C12QAgent(
        config=config,
        vector_size=VECTOR_OBSERVATION_COUNT,
        node_feature_count=GRAPH_NODE_FEATURE_COUNT,
        action_count=ACTION_COUNT,
        seed=_agent_seed(method_id, scenario, train_seed),
        device=device,
    )
    resume_path = run_dir / "resume.pt"
    start_episode = 1
    candidates: list[dict[str, Any]] = []
    if resume and resume_path.is_file():
        payload = load_checkpoint_payload(resume_path, map_location=device)
        _validate_checkpoint_identity(payload, manifest_hash, method_id, scenario, train_seed)
        if payload.get("checkpoint_kind") != "DETERMINISTIC_RESUME":
            raise ValueError("resume checkpoint kind mismatch")
        agent.load_checkpoint_state(payload["agent_state"])
        start_episode = int(payload["next_episode"])
        candidates = list(payload["candidates"])
        payload_budget = payload.get("budget")
        if not isinstance(payload_budget, dict):
            raise ValueError("resume checkpoint is missing budget state")
        checkpoint_ledger = BudgetLedger(**payload_budget)
        if (
            ledger.attempted_training_steps < checkpoint_ledger.attempted_training_steps
            or ledger.attempted_validation_steps < checkpoint_ledger.attempted_validation_steps
        ):
            raise ValueError("durable budget ledger is behind the resume checkpoint")
        ledger = BudgetLedger(
            training_steps=checkpoint_ledger.training_steps,
            validation_steps=checkpoint_ledger.validation_steps,
            attempted_training_steps=ledger.attempted_training_steps,
            attempted_validation_steps=ledger.attempted_validation_steps,
        )
    summary_state = {
        "episode_count": 0,
        "loss_count": 0,
        "loss_sum": 0.0,
        "reward_sum": 0.0,
    }
    if start_episode > 1:
        restored_summary = payload.get("summary_state")
        if not isinstance(restored_summary, dict):
            raise ValueError("resume checkpoint is missing cumulative training summary")
        summary_state = _validate_summary_state(restored_summary, start_episode - 1)
    if not 0 < episode_limit <= EPISODES[scenario]:
        raise ValueError("episode limit exceeds frozen schedule")
    if validation_every <= 0 or episode_limit % validation_every:
        raise ValueError("validation cadence must partition the episode limit")
    if not 0 < validation_root_limit <= VALIDATION_ROOT_COUNT:
        raise ValueError("validation root limit is invalid")
    for episode in range(start_episode, episode_limit + 1):
        _enforce_time_caps(
            started,
            cpu_started,
            max_wall_seconds=max_wall_seconds,
            max_process_cpu_seconds=max_process_cpu_seconds,
        )
        ledger = ledger.reserve_training_attempts(MAX_STEPS[scenario])
        _write_json(
            ledger_path,
            {
                "schema_version": RUN_LEDGER_SCHEMA_VERSION,
                "manifest_hash": manifest_hash,
                "budget": asdict(ledger),
                "active_run": run_id,
                "pre_reserved_episode": episode,
            },
        )
        episode_result = _run_training_episode(agent, scenario, train_seed, episode)
        ledger = ledger.complete_training(episode_result["training_steps"])
        summary_state["episode_count"] += 1
        summary_state["loss_count"] += episode_result["loss_count"]
        summary_state["loss_sum"] += episode_result["loss_sum"]
        summary_state["reward_sum"] += episode_result["reward_sum"]
        if episode % validation_every == 0:
            candidate_path = run_dir / "candidates" / f"episode_{episode:04d}.pt"
            save_checkpoint_payload(
                _candidate_checkpoint_payload(
                    manifest_hash, method_id, scenario, train_seed, episode, agent
                ),
                candidate_path,
            )
            candidate_hash = _file_hash(candidate_path)
            validation, ledger = _validate_candidate(
                agent,
                scenario=scenario,
                ledger=ledger,
                root_limit=validation_root_limit,
            )
            candidates.append(
                {
                    "episode": episode,
                    "relative_path": candidate_path.relative_to(output_root).as_posix(),
                    "sha256": candidate_hash,
                    **validation,
                }
            )
            save_checkpoint_payload(
                {
                    **_resume_checkpoint_payload(
                        manifest_hash,
                        method_id,
                        scenario,
                        train_seed,
                        episode,
                        agent,
                    ),
                    "next_episode": episode + 1,
                    "candidates": tuple(candidates),
                    "budget": asdict(ledger),
                    "summary_state": summary_state,
                },
                resume_path,
            )
            _write_json(
                ledger_path,
                {
                    "schema_version": RUN_LEDGER_SCHEMA_VERSION,
                    "manifest_hash": manifest_hash,
                    "budget": asdict(ledger),
                    "active_run": run_id,
                    "last_completed_episode": episode,
                },
            )
        elif episode % 10 == 0:
            _write_json(
                ledger_path,
                {
                    "schema_version": RUN_LEDGER_SCHEMA_VERSION,
                    "manifest_hash": manifest_hash,
                    "budget": asdict(ledger),
                    "active_run": run_id,
                    "last_completed_episode": episode,
                },
            )
            save_checkpoint_payload(
                {
                    **_resume_checkpoint_payload(
                        manifest_hash,
                        method_id,
                        scenario,
                        train_seed,
                        episode,
                        agent,
                    ),
                    "next_episode": episode + 1,
                    "candidates": tuple(candidates),
                    "budget": asdict(ledger),
                    "summary_state": summary_state,
                },
                resume_path,
            )
    if not any(candidate["eligible"] for candidate in candidates):
        raise RuntimeError("all checkpoint candidates are ineligible")
    selected = min(candidates, key=_selection_key)
    selected_record = {
        "run_id": run_id,
        "method_id": method_id,
        "scenario": scenario,
        "train_seed": train_seed,
        **selected,
    }
    complete = {
        "run": {
            "run_id": run_id,
            "method_id": method_id,
            "scenario": scenario,
            "train_seed": train_seed,
            "episodes": episode_limit,
            "max_steps": MAX_STEPS[scenario],
            "training_steps": episode_limit * MAX_STEPS[scenario],
            "candidate_count": len(candidates),
            "mean_training_reward": summary_state["reward_sum"] / episode_limit,
            "mean_loss": (
                summary_state["loss_sum"] / summary_state["loss_count"]
                if summary_state["loss_count"]
                else None
            ),
            "illegal_action_count": 0,
            "hard_constraint_violation_count": 0,
            "training_root_policy": "METHOD_INDEPENDENT_KEYED_SEGMENTS_NO_ROOT_FILTERING",
            "resumed_from_episode": start_episode if start_episode > 1 else None,
        },
        "selected_checkpoint": selected_record,
        "candidates": candidates,
    }
    _write_json(final_path, complete)
    return complete, ledger


def _run_training_episode(
    agent: C12QAgent,
    scenario: str,
    train_seed: int,
    episode: int,
) -> dict[str, int | float]:
    transitions_remaining = MAX_STEPS[scenario]
    loss_count = 0
    loss_sum = 0.0
    reward_sum = 0.0
    segment = 0
    while transitions_remaining:
        environment = C12Episode(
            build_primary_influx_tape(
                train_root(scenario, train_seed, episode, segment),
                SCENARIO_ARMS[scenario],
                validate_generated_tape=False,
            ),
            max_decisions=transitions_remaining,
            tape_prevalidated_by_frozen_builder=True,
        )
        current = environment.reset()
        while transitions_remaining:
            action = agent.act(current.observation, explore=True)
            next_step = environment.step(action)
            loss = agent.observe(
                current.observation,
                action,
                next_step.reward,
                next_step.observation,
                next_step.done,
            )
            transitions_remaining -= 1
            if loss is not None:
                loss_count += 1
                loss_sum += loss
            reward_sum += next_step.reward
            current = next_step
            if next_step.done:
                break
        if environment.illegal_actions:
            raise RuntimeError("training emitted an illegal action")
        segment += 1
    return {
        "training_steps": MAX_STEPS[scenario],
        "loss_count": loss_count,
        "loss_sum": loss_sum,
        "reward_sum": reward_sum,
    }


def _validate_summary_state(
    primitive: dict[str, Any], expected_episode_count: int
) -> dict[str, int | float]:
    expected = {"episode_count", "loss_count", "loss_sum", "reward_sum"}
    if set(primitive) != expected:
        raise ValueError("training summary schema mismatch")
    episode_count = primitive["episode_count"]
    loss_count = primitive["loss_count"]
    loss_sum = primitive["loss_sum"]
    reward_sum = primitive["reward_sum"]
    if (
        type(episode_count) is not int
        or episode_count != expected_episode_count
        or type(loss_count) is not int
        or loss_count < 0
        or not isinstance(loss_sum, (int, float))
        or not math.isfinite(float(loss_sum))
        or not isinstance(reward_sum, (int, float))
        or not math.isfinite(float(reward_sum))
    ):
        raise ValueError("training summary content mismatch")
    return {
        "episode_count": episode_count,
        "loss_count": loss_count,
        "loss_sum": float(loss_sum),
        "reward_sum": float(reward_sum),
    }


def _validate_candidate(
    agent: C12QAgent,
    *,
    scenario: str,
    ledger: BudgetLedger,
    root_limit: int,
) -> tuple[dict[str, Any], BudgetLedger]:
    primary: list[Decimal] = []
    collisions: list[Decimal] = []
    jain: list[Decimal] = []
    illegal = 0
    for root in validation_roots()[scenario][:root_limit]:
        environment = C12Episode(
            build_primary_influx_tape(
                root, SCENARIO_ARMS[scenario], validate_generated_tape=False
            ),
            max_decisions=MAX_STEPS[scenario],
            tape_prevalidated_by_frozen_builder=True,
        )
        current = environment.reset()
        for _ in range(MAX_STEPS[scenario]):
            action = agent.act(current.observation, explore=False)
            current = environment.step(action)
            ledger = ledger.consume_validation()
            if current.done:
                break
        metrics = environment.validation_metrics()
        primary.append(Decimal(metrics.worst_user_time_average_aoi_ms))
        collisions.append(Decimal(metrics.collision_event_rate))
        jain.append(Decimal(metrics.jain_freshness))
        illegal += environment.illegal_actions
    return (
        {
            "validation_root_count": root_limit,
            "worst_user_time_average_AoI_ms": _mean_decimal_text(primary),
            "collision_event_rate": _mean_decimal_text(collisions),
            "jain_freshness": _mean_decimal_text(jain),
            "illegal_action_count": illegal,
            "hard_constraint_violation_count": 0,
            "eligible": illegal == 0,
        },
        ledger,
    )


def _selection_key(candidate: dict[str, Any]) -> tuple[Any, ...]:
    if not candidate["eligible"] or candidate["hard_constraint_violation_count"]:
        return (1, Decimal("Infinity"), Decimal("Infinity"), Decimal("Infinity"), 0, "")
    return (
        0,
        Decimal(candidate["worst_user_time_average_AoI_ms"]),
        Decimal(candidate["collision_event_rate"]),
        -Decimal(candidate["jain_freshness"]),
        int(candidate["episode"]),
        candidate["sha256"],
    )


def _checkpoint_identity(
    manifest_hash: str,
    method_id: str,
    scenario: str,
    train_seed: int,
    episode: int,
) -> dict[str, Any]:
    return {
        "schema_version": CHECKPOINT_SCHEMA_VERSION,
        "manifest_hash": manifest_hash,
        "method_id": method_id,
        "scenario": scenario,
        "train_seed": train_seed,
        "episode": episode,
        "config": asdict(FROZEN_AGENT_CONFIGS[method_id]),
    }


def _candidate_checkpoint_payload(
    manifest_hash: str,
    method_id: str,
    scenario: str,
    train_seed: int,
    episode: int,
    agent: C12QAgent,
) -> dict[str, Any]:
    return {
        **_checkpoint_identity(manifest_hash, method_id, scenario, train_seed, episode),
        "checkpoint_kind": "INFERENCE_CANDIDATE",
        "inference_state": agent.inference_state(),
    }


def _resume_checkpoint_payload(
    manifest_hash: str,
    method_id: str,
    scenario: str,
    train_seed: int,
    episode: int,
    agent: C12QAgent,
) -> dict[str, Any]:
    return {
        **_checkpoint_identity(manifest_hash, method_id, scenario, train_seed, episode),
        "checkpoint_kind": "DETERMINISTIC_RESUME",
        "agent_state": agent.checkpoint_state(),
    }


def _verify_selected_record(
    output_root: Path, record: dict[str, Any], manifest_hash: str
) -> None:
    path = output_root / record["relative_path"]
    if _file_hash(path) != record["sha256"]:
        raise ValueError("selected checkpoint content hash mismatch")
    payload = load_checkpoint_payload(path, map_location=torch.device("cpu"))
    _validate_checkpoint_identity(
        payload,
        manifest_hash,
        record["method_id"],
        record["scenario"],
        int(record["train_seed"]),
    )


def _validate_checkpoint_identity(
    payload: dict[str, Any],
    manifest_hash: str,
    method_id: str,
    scenario: str,
    train_seed: int,
) -> None:
    expected = (
        CHECKPOINT_SCHEMA_VERSION,
        manifest_hash,
        method_id,
        scenario,
        train_seed,
        asdict(FROZEN_AGENT_CONFIGS[method_id]),
    )
    actual = (
        payload.get("schema_version"),
        payload.get("manifest_hash"),
        payload.get("method_id"),
        payload.get("scenario"),
        payload.get("train_seed"),
        payload.get("config"),
    )
    if actual != expected:
        raise ValueError("checkpoint identity/configuration mismatch")


def _agent_seed(method_id: str, scenario: str, train_seed: int) -> int:
    return int(
        stable_digest_hex("exp09-c12-agent-seed-v1", method_id, scenario, train_seed)[:16],
        16,
    ) % (2**63 - 1)


def _mean_decimal_text(values: list[Decimal]) -> str:
    return format(sum(values) / len(values), ".6f")


def _load_budget_ledger(path: Path) -> BudgetLedger:
    primitive = json.loads(path.read_text(encoding="utf-8"))
    ledger = BudgetLedger(**primitive["budget"])
    ledger.validate()
    return ledger


def _write_json(path: Path, primitive: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(primitive, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        + "\n",
        encoding="utf-8",
    )


def _json_hash(primitive: Any) -> str:
    payload = json.dumps(
        primitive, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest().upper()


def _file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def _require_sha256(value: str, field: str) -> None:
    if len(value) != 64 or any(character not in "0123456789ABCDEF" for character in value):
        raise ValueError(f"{field} must be uppercase SHA-256")


def _enforce_time_caps(
    started: float,
    cpu_started: float,
    *,
    max_wall_seconds: int,
    max_process_cpu_seconds: int,
) -> None:
    if time.monotonic() - started > max_wall_seconds:
        raise RuntimeError("C12 wall-time hard cap exceeded")
    if time.process_time() - cpu_started > max_process_cpu_seconds:
        raise RuntimeError("C12 process CPU-time hard cap exceeded")


def _enforce_runtime_caps(
    output_root: Path,
    started: float,
    cpu_started: float,
    *,
    max_wall_seconds: int,
    max_process_cpu_seconds: int,
    max_storage_bytes: int,
) -> None:
    _enforce_time_caps(
        started,
        cpu_started,
        max_wall_seconds=max_wall_seconds,
        max_process_cpu_seconds=max_process_cpu_seconds,
    )
    total_bytes = sum(path.stat().st_size for path in output_root.rglob("*") if path.is_file())
    if total_bytes > max_storage_bytes:
        raise RuntimeError("C12 storage hard cap exceeded")


def _verify_execution_manifest(path: Path, manifest_hash: str) -> None:
    if _file_hash(path) != manifest_hash:
        raise ValueError("execution manifest content hash mismatch")
    manifest = json.loads(path.read_text(encoding="utf-8"))
    expected = (
        "exp09-c12-execution-manifest-v1",
        "SIGNED_PREFLIGHT_PASSED_EXECUTION_ENABLED",
        "C12_REAL_RL_TRAINING_ONLY",
        "ENABLED_ONLY_FOR_THIS_MANIFEST_HASH",
        False,
        False,
    )
    actual = (
        manifest.get("schema_version"),
        manifest.get("artifact_status"),
        manifest.get("execution_scope"),
        manifest.get("training_capability"),
        manifest.get("c14_execution_authorized"),
        manifest.get("api_allowed"),
    )
    if actual != expected:
        raise ValueError("execution manifest does not authorize C12 training")
    root = path.resolve().parents[2]
    for artifact in manifest.get("frozen_artifacts", ()):
        locator = artifact.get("locator")
        expected_hash = artifact.get("sha256")
        if not isinstance(locator, str) or ".." in Path(locator).parts:
            raise ValueError("execution manifest artifact locator is unsafe")
        if _file_hash(root / locator) != expected_hash:
            raise ValueError(f"frozen execution artifact mismatch: {locator}")
