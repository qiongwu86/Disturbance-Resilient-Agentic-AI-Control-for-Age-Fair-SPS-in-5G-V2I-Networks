"""Frozen C12 PyTorch Q networks and local-RNG agents."""

from collections import deque
from dataclasses import dataclass
from pathlib import Path
import random
from typing import Any

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from .rl_environment import EncodedObservation


@dataclass(frozen=True, slots=True)
class AgentConfig:
    method_id: str
    hidden_size: int
    learning_rate: float
    gamma: float
    epsilon_start: float
    epsilon_end: float
    epsilon_decay: float
    batch_size: int
    target_sync: int
    replay_capacity: int
    double_dqn: bool


FROZEN_AGENT_CONFIGS = {
    "DQN": AgentConfig("DQN", 64, 7.5e-4, 0.97, 1.0, 0.10, 0.997, 64, 200, 12_000, False),
    "DQN_Strong": AgentConfig(
        "DQN_Strong", 128, 1e-3, 0.98, 1.0, 0.05, 0.995, 64, 100, 20_000, True
    ),
    "GNN_DDQN": AgentConfig(
        "GNN_DDQN", 64, 1e-3, 0.98, 1.0, 0.05, 0.995, 64, 100, 20_000, True
    ),
}


class MLPQNetwork(nn.Module):
    def __init__(self, input_dim: int, action_count: int, hidden_size: int) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, action_count),
        )

    def forward(self, vector: torch.Tensor) -> torch.Tensor:
        return self.net(vector)


class GraphQNetwork(nn.Module):
    def __init__(self, node_feature_count: int, action_count: int, hidden_size: int) -> None:
        super().__init__()
        self.node_in = nn.Linear(node_feature_count, hidden_size)
        self.aggregate_1 = nn.Linear(hidden_size * 2, hidden_size)
        self.aggregate_2 = nn.Linear(hidden_size * 2, hidden_size)
        self.head = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, action_count),
        )

    def forward(self, nodes: torch.Tensor, adjacency: torch.Tensor) -> torch.Tensor:
        hidden = F.relu(self.node_in(nodes))
        neighbors = torch.matmul(adjacency, hidden)
        hidden = F.relu(self.aggregate_1(torch.cat((hidden, neighbors), dim=-1)))
        neighbors = torch.matmul(adjacency, hidden)
        hidden = F.relu(self.aggregate_2(torch.cat((hidden, neighbors), dim=-1)))
        return self.head(hidden.mean(dim=1))


@dataclass(frozen=True, slots=True)
class ReplayTransition:
    vector: np.ndarray
    nodes: np.ndarray
    adjacency: np.ndarray
    action: int
    reward: float
    next_vector: np.ndarray
    next_nodes: np.ndarray
    next_adjacency: np.ndarray
    next_action_mask: np.ndarray
    done: bool


class C12QAgent:
    def __init__(
        self,
        *,
        config: AgentConfig,
        vector_size: int,
        node_feature_count: int,
        action_count: int,
        seed: int,
        device: torch.device,
    ) -> None:
        self.config = config
        self.device = device
        self.action_count = action_count
        self.python_rng = random.Random(seed)
        self.numpy_rng = np.random.default_rng(seed)
        self.torch_generator = torch.Generator(device="cpu").manual_seed(seed)
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(seed)
            if config.method_id == "GNN_DDQN":
                self.policy = GraphQNetwork(node_feature_count, action_count, config.hidden_size)
                self.target = GraphQNetwork(node_feature_count, action_count, config.hidden_size)
            else:
                self.policy = MLPQNetwork(vector_size, action_count, config.hidden_size)
                self.target = MLPQNetwork(vector_size, action_count, config.hidden_size)
        self.policy.to(device)
        self.target.to(device)
        self.target.load_state_dict(self.policy.state_dict())
        self.optimizer = torch.optim.Adam(self.policy.parameters(), lr=config.learning_rate)
        self.replay: deque[ReplayTransition] = deque(maxlen=config.replay_capacity)
        self.epsilon = config.epsilon_start
        self.train_steps = 0

    def act(self, observation: EncodedObservation, *, explore: bool) -> int:
        legal = np.flatnonzero(observation.action_mask)
        if not len(legal):
            raise ValueError("observation exposes no legal action")
        if explore and self.python_rng.random() < self.epsilon:
            return int(legal[self.python_rng.randrange(len(legal))])
        with torch.no_grad():
            values = self._q_values(observation)
            mask = torch.as_tensor(observation.action_mask, dtype=torch.bool, device=self.device)
            values = values.masked_fill(~mask.unsqueeze(0), float("-inf"))
            return int(torch.argmax(values, dim=1).item())

    def observe(
        self,
        observation: EncodedObservation,
        action: int,
        reward: float,
        next_observation: EncodedObservation,
        done: bool,
    ) -> float | None:
        self.replay.append(
            ReplayTransition(
                observation.vector.copy(),
                observation.node_features.copy(),
                observation.adjacency.copy(),
                int(action),
                float(reward),
                next_observation.vector.copy(),
                next_observation.node_features.copy(),
                next_observation.adjacency.copy(),
                next_observation.action_mask.copy(),
                bool(done),
            )
        )
        loss = self._train_step()
        self.epsilon = max(self.config.epsilon_end, self.epsilon * self.config.epsilon_decay)
        return loss

    def _q_values(self, observation: EncodedObservation) -> torch.Tensor:
        if self.config.method_id == "GNN_DDQN":
            return self.policy(
                torch.as_tensor(
                    observation.node_features, dtype=torch.float32, device=self.device
                ).unsqueeze(0),
                torch.as_tensor(
                    observation.adjacency, dtype=torch.float32, device=self.device
                ).unsqueeze(0),
            )
        return self.policy(
            torch.as_tensor(observation.vector, dtype=torch.float32, device=self.device).unsqueeze(0)
        )

    def _train_step(self) -> float | None:
        if len(self.replay) < self.config.batch_size:
            return None
        indexes = self.numpy_rng.choice(
            len(self.replay), self.config.batch_size, replace=False
        )
        values = tuple(self.replay[int(index)] for index in indexes)
        actions = torch.as_tensor(
            [item.action for item in values], dtype=torch.long, device=self.device
        ).unsqueeze(1)
        rewards = torch.as_tensor(
            [item.reward for item in values], dtype=torch.float32, device=self.device
        ).unsqueeze(1)
        done = torch.as_tensor(
            [item.done for item in values], dtype=torch.float32, device=self.device
        ).unsqueeze(1)
        masks = torch.as_tensor(
            np.stack([item.next_action_mask for item in values]),
            dtype=torch.bool,
            device=self.device,
        )
        if self.config.method_id == "GNN_DDQN":
            nodes = _tensor_stack(values, "nodes", self.device)
            adjacency = _tensor_stack(values, "adjacency", self.device)
            next_nodes = _tensor_stack(values, "next_nodes", self.device)
            next_adjacency = _tensor_stack(values, "next_adjacency", self.device)
            q_values = self.policy(nodes, adjacency).gather(1, actions)
            policy_next = self.policy(next_nodes, next_adjacency).masked_fill(~masks, float("-inf"))
            target_next_all = self.target(next_nodes, next_adjacency)
        else:
            vectors = _tensor_stack(values, "vector", self.device)
            next_vectors = _tensor_stack(values, "next_vector", self.device)
            q_values = self.policy(vectors).gather(1, actions)
            policy_next = self.policy(next_vectors).masked_fill(~masks, float("-inf"))
            target_next_all = self.target(next_vectors)
        if self.config.double_dqn:
            next_actions = torch.argmax(policy_next, dim=1, keepdim=True)
            next_q = target_next_all.gather(1, next_actions)
        else:
            next_q = target_next_all.masked_fill(~masks, float("-inf")).max(
                dim=1, keepdim=True
            ).values
        target = rewards + self.config.gamma * next_q.detach() * (1.0 - done)
        loss = F.smooth_l1_loss(q_values, target)
        if not torch.isfinite(loss):
            raise FloatingPointError("non-finite RL loss")
        self.optimizer.zero_grad(set_to_none=True)
        loss.backward()
        nn.utils.clip_grad_norm_(self.policy.parameters(), 5.0)
        self.optimizer.step()
        self.train_steps += 1
        if self.train_steps % self.config.target_sync == 0:
            self.target.load_state_dict(self.policy.state_dict())
        return float(loss.detach().cpu().item())

    def checkpoint_state(self) -> dict[str, Any]:
        return {
            "policy": self.policy.state_dict(),
            "target": self.target.state_dict(),
            "optimizer": self.optimizer.state_dict(),
            "epsilon": self.epsilon,
            "train_steps": self.train_steps,
            "python_rng": self.python_rng.getstate(),
            "numpy_rng": self.numpy_rng.bit_generator.state,
            "torch_generator": self.torch_generator.get_state(),
            "replay": tuple(self.replay),
        }

    def inference_state(self) -> dict[str, Any]:
        return {
            "policy": self.policy.state_dict(),
            "target": self.target.state_dict(),
            "epsilon": self.epsilon,
            "train_steps": self.train_steps,
        }

    def load_inference_state(self, state: dict[str, Any]) -> None:
        self.policy.load_state_dict(state["policy"])
        self.target.load_state_dict(state["target"])
        self.epsilon = float(state["epsilon"])
        self.train_steps = int(state["train_steps"])

    def load_checkpoint_state(self, state: dict[str, Any]) -> None:
        self.policy.load_state_dict(state["policy"])
        self.target.load_state_dict(state["target"])
        self.optimizer.load_state_dict(state["optimizer"])
        self.epsilon = float(state["epsilon"])
        self.train_steps = int(state["train_steps"])
        self.python_rng.setstate(state["python_rng"])
        self.numpy_rng.bit_generator.state = state["numpy_rng"]
        self.torch_generator.set_state(state["torch_generator"])
        self.replay = deque(state["replay"], maxlen=self.config.replay_capacity)


def save_checkpoint_payload(payload: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    torch.save(payload, temporary)
    temporary.replace(path)


def load_checkpoint_payload(path: Path, *, map_location: torch.device) -> dict[str, Any]:
    payload = torch.load(path, map_location=map_location, weights_only=False)
    if not isinstance(payload, dict):
        raise ValueError("checkpoint payload must be a dictionary")
    return payload


def _tensor_stack(values, field: str, device: torch.device) -> torch.Tensor:
    return torch.as_tensor(
        np.stack([getattr(item, field) for item in values]),
        dtype=torch.float32,
        device=device,
    )
