"""C07 method and baseline registry scaffolding."""

