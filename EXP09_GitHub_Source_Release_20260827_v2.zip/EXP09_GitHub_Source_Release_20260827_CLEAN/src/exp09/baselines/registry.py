"""C07 method registry metadata and implementation readiness."""

from dataclasses import dataclass
from enum import Enum

from exp09.contracts.determinism import stable_digest_hex
from exp09.contracts.ids import require_identifier, require_sha256
from exp09.contracts.time import require_non_negative_int

METHOD_REGISTRY_ENTRY_SCHEMA_VERSION = "exp09-method-registry-entry-v1"
METHOD_REGISTRY_SCHEMA_VERSION = "exp09-method-registry-v1"

C07_METHOD_IDS = (
    "Full",
    "RMPC_SameEvaluator",
    "Rule_SameStack",
    "TunedNonLLM_SameStack",
    "Plain_LLM",
    "DQN",
    "DQN_Strong",
    "GNN_DDQN",
    "KEEP_sanity",
    "AoI_aware_heuristic",
    "Greedy_1",
    "Nominal_MPC",
)

_FORBIDDEN_VISIBLE_FIELDS = frozenset(
    {
        "scenario_id",
        "family_id",
        "arm",
        "shock_label",
        "configured_onset_us",
        "future_onset_candidates_us",
        "true_active_set",
        "plant_truth",
        "evaluation_truth",
        "method_identity",
        "test_ranking",
    }
)


class MethodCapability(str, Enum):
    SANITY = "sanity"
    HEURISTIC = "heuristic"
    MODEL_BASED = "model_based"
    SUPERVISORY = "supervisory"
    RL_BASELINE = "rl_baseline"
    LLM_PROVIDER = "llm_provider"


class QualificationStatus(str, Enum):
    PLANNED = "PLANNED"
    IMPLEMENTED_NOT_QUALIFIED = "IMPLEMENTED_NOT_QUALIFIED"
    QUALIFIED = "QUALIFIED"


@dataclass(frozen=True, slots=True)
class MethodRegistryEntry:
    schema_version: str
    method_id: str
    capability: MethodCapability
    observable_fields: tuple[str, ...]
    model_access: str
    program_access: str
    transition_budget: int
    training_budget: int
    checkpoint_rule: str
    config_hash: str
    qualification_status: QualificationStatus
    evidence_hashes: tuple[str, ...]

    def __post_init__(self) -> None:
        if self.schema_version != METHOD_REGISTRY_ENTRY_SCHEMA_VERSION:
            raise ValueError("unsupported method-registry-entry schema version")
        require_identifier(self.method_id, "method_id")
        if not isinstance(self.capability, MethodCapability):
            raise ValueError("capability must be a MethodCapability")
        if not isinstance(self.observable_fields, tuple):
            raise ValueError("observable_fields must be a tuple")
        if not self.observable_fields:
            raise ValueError("observable_fields must not be empty")
        for field in self.observable_fields:
            require_identifier(field, "observable field")
            if field in _FORBIDDEN_VISIBLE_FIELDS:
                raise ValueError("observable field is forbidden by the C07 visibility boundary")
        for field_name, value in (
            ("model_access", self.model_access),
            ("program_access", self.program_access),
            ("checkpoint_rule", self.checkpoint_rule),
        ):
            require_identifier(value, field_name)
        require_non_negative_int(self.transition_budget, "transition_budget")
        require_non_negative_int(self.training_budget, "training_budget")
        require_sha256(self.config_hash, "config_hash")
        if not isinstance(self.qualification_status, QualificationStatus):
            raise ValueError("qualification_status must be a QualificationStatus")
        if not isinstance(self.evidence_hashes, tuple):
            raise ValueError("evidence_hashes must be a tuple")
        for digest in self.evidence_hashes:
            require_sha256(digest, "evidence_hash")
        if self.qualification_status is QualificationStatus.QUALIFIED and not self.evidence_hashes:
            raise ValueError("qualified methods require evidence hashes")


@dataclass(frozen=True, slots=True)
class MethodRegistry:
    schema_version: str
    entries: tuple[MethodRegistryEntry, ...]

    def __post_init__(self) -> None:
        if self.schema_version != METHOD_REGISTRY_SCHEMA_VERSION:
            raise ValueError("unsupported method-registry schema version")
        if not isinstance(self.entries, tuple):
            raise ValueError("entries must be a tuple")
        method_ids = tuple(entry.method_id for entry in self.entries)
        if len(set(method_ids)) != len(method_ids):
            raise ValueError("method IDs must be unique")


def planned_c07_registry() -> MethodRegistry:
    entries = tuple(
        MethodRegistryEntry(
            schema_version=METHOD_REGISTRY_ENTRY_SCHEMA_VERSION,
            method_id=method_id,
            capability=_capability_for(method_id),
            observable_fields=("ObservableFrame", "ControlOpportunity"),
            model_access="C07_SHARED_MODEL_CONTRACT",
            program_access="NONE_UNTIL_C10",
            transition_budget=72000 if method_id in {"Greedy_1", "Nominal_MPC"} else 0,
            training_budget=0,
            checkpoint_rule="NOT_APPLICABLE_OR_UNQUALIFIED",
            config_hash=(
                stable_digest_hex("exp09-c07-baseline-config-v1", method_id)
                if method_id in C07_METHOD_IDS[-4:]
                else "0" * 64
            ),
            qualification_status=(
                QualificationStatus.IMPLEMENTED_NOT_QUALIFIED
                if method_id in C07_METHOD_IDS[-4:]
                else QualificationStatus.PLANNED
            ),
            evidence_hashes=(),
        )
        for method_id in C07_METHOD_IDS
    )
    return MethodRegistry(schema_version=METHOD_REGISTRY_SCHEMA_VERSION, entries=entries)


def _capability_for(method_id: str) -> MethodCapability:
    if method_id in {"KEEP_sanity"}:
        return MethodCapability.SANITY
    if method_id in {"AoI_aware_heuristic", "Greedy_1"}:
        return MethodCapability.HEURISTIC
    if method_id in {"DQN", "DQN_Strong", "GNN_DDQN"}:
        return MethodCapability.RL_BASELINE
    if method_id == "Plain_LLM":
        return MethodCapability.LLM_PROVIDER
    if method_id in {"Full", "Rule_SameStack", "TunedNonLLM_SameStack"}:
        return MethodCapability.SUPERVISORY
    return MethodCapability.MODEL_BASED
