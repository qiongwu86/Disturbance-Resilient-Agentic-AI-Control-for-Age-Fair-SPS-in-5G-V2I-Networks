"""Metric identity contracts without metric computation or values."""

from dataclasses import dataclass
from enum import Enum

from .ids import RootCaseId, RunId, VehicleId, require_identifier

METRIC_CONTRACT_SCHEMA_VERSION = "exp09-metric-contract-v1"
METRIC_RECORD_HEADER_SCHEMA_VERSION = "exp09-metric-record-header-v1"


class MetricDirection(str, Enum):
    LOWER_IS_BETTER = "lower_is_better"
    HIGHER_IS_BETTER = "higher_is_better"


@dataclass(frozen=True, slots=True)
class MetricContract:
    schema_version: str
    metric_id: str
    unit: str
    direction: MetricDirection

    def __post_init__(self) -> None:
        if self.schema_version != METRIC_CONTRACT_SCHEMA_VERSION:
            raise ValueError("unsupported metric-contract schema version")
        require_identifier(self.metric_id, "metric_id")
        require_identifier(self.unit, "unit")
        if not isinstance(self.direction, MetricDirection):
            raise ValueError("direction must be a MetricDirection")


@dataclass(frozen=True, slots=True)
class MetricRecordHeader:
    schema_version: str
    run_id: RunId
    root_case_id: RootCaseId
    metric_id: str
    vehicle_id: VehicleId | None

    def __post_init__(self) -> None:
        if self.schema_version != METRIC_RECORD_HEADER_SCHEMA_VERSION:
            raise ValueError("unsupported metric-record-header schema version")
        require_identifier(self.run_id, "run_id")
        require_identifier(self.root_case_id, "root_case_id")
        require_identifier(self.metric_id, "metric_id")
        if self.vehicle_id is not None:
            require_identifier(self.vehicle_id, "vehicle_id")
