"""Strong identifier aliases and fail-closed scalar validators."""

import re
from typing import Any, NewType

RunId = NewType("RunId", str)
RootCaseId = NewType("RootCaseId", str)
TapeId = NewType("TapeId", str)
TapeFamilyId = NewType("TapeFamilyId", str)
EventId = NewType("EventId", str)
VehicleId = NewType("VehicleId", str)
ResourceId = NewType("ResourceId", str)
ControlOpportunityId = NewType("ControlOpportunityId", str)
RequestId = NewType("RequestId", str)
ProgramId = NewType("ProgramId", str)
ProgramStateVersion = NewType("ProgramStateVersion", int)
ModelArtifactId = NewType("ModelArtifactId", str)
ConfigHash = NewType("ConfigHash", str)

_SHA256_PATTERN = re.compile(r"[0-9A-Fa-f]{64}")


def require_identifier(value: Any, field_name: str) -> None:
    if not isinstance(value, str) or not value or value.strip() != value:
        raise ValueError(f"{field_name} must be a non-empty string without surrounding whitespace")


def require_sha256(value: Any, field_name: str) -> None:
    if not isinstance(value, str) or _SHA256_PATTERN.fullmatch(value) is None:
        raise ValueError(f"{field_name} must be a 64-character hexadecimal SHA-256 digest")


def require_safe_relative_path(value: Any, field_name: str) -> None:
    if (
        not isinstance(value, str)
        or not value
        or value.strip() != value
        or "\\" in value
        or ":" in value
        or "\x00" in value
    ):
        raise ValueError(f"{field_name} must be a non-empty POSIX relative path")
    parts = value.split("/")
    if any(part in ("", ".", "..") for part in parts):
        raise ValueError(f"{field_name} must not be absolute or contain empty, dot, or parent parts")
