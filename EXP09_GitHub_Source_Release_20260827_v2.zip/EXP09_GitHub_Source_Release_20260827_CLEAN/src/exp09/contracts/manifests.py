"""Manifest reference contracts without signing or file-writing behavior."""

from dataclasses import dataclass

from .ids import ConfigHash, require_identifier, require_safe_relative_path, require_sha256

ARTIFACT_REFERENCE_SCHEMA_VERSION = "exp09-artifact-reference-v1"
MANIFEST_HEADER_SCHEMA_VERSION = "exp09-manifest-header-v1"


@dataclass(frozen=True, slots=True)
class ArtifactReference:
    schema_version: str
    artifact_id: str
    relative_path: str
    sha256: str

    def __post_init__(self) -> None:
        if self.schema_version != ARTIFACT_REFERENCE_SCHEMA_VERSION:
            raise ValueError("unsupported artifact-reference schema version")
        require_identifier(self.artifact_id, "artifact_id")
        require_safe_relative_path(self.relative_path, "relative_path")
        require_sha256(self.sha256, "sha256")


@dataclass(frozen=True, slots=True)
class ManifestHeader:
    schema_version: str
    generation_id: str
    config_hash: ConfigHash
    signing_status: str

    def __post_init__(self) -> None:
        if self.schema_version != MANIFEST_HEADER_SCHEMA_VERSION:
            raise ValueError("unsupported manifest-header schema version")
        require_identifier(self.generation_id, "generation_id")
        require_sha256(self.config_hash, "config_hash")
        if self.signing_status != "SIGNING_UNRESOLVED":
            raise ValueError("C02 permits only SIGNING_UNRESOLVED")
