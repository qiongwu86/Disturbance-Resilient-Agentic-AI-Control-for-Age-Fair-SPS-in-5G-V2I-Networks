"""Offline-only evaluation truth contract.

This module must never be imported by controller-facing packages.
"""

from dataclasses import dataclass

from .events import EventHeader
from .ids import require_identifier, require_sha256

EVALUATION_TRUTH_SCHEMA_VERSION = "exp09-evaluation-truth-v1"


@dataclass(frozen=True, slots=True)
class EvaluationTruthEvent:
    schema_version: str
    header: EventHeader
    truth_code: str
    payload_hash: str

    def __post_init__(self) -> None:
        if self.schema_version != EVALUATION_TRUTH_SCHEMA_VERSION:
            raise ValueError("unsupported evaluation-truth schema version")
        if not isinstance(self.header, EventHeader):
            raise ValueError("header must be an EventHeader")
        require_identifier(self.truth_code, "truth_code")
        require_sha256(self.payload_hash, "payload_hash")
