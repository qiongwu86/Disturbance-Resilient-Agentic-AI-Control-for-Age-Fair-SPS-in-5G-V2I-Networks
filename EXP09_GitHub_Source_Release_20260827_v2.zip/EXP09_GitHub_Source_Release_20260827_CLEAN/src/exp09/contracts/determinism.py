"""Typed canonical digest helpers shared by deterministic runtime layers."""

import hashlib
import json
from typing import Any


_EVENT_ID_DOMAIN = "event-v1"


def stable_digest_hex(*parts: Any) -> str:
    payload = json.dumps(
        [_typed_part(part) for part in parts],
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest().upper()


def stable_event_id(
    causal_parent_id: str | None,
    event_kind: str,
    entity_id: str,
    resource_id: str | None,
    ordinal: int,
) -> str:
    """Derive an event ID from the five frozen causal components."""

    if not isinstance(event_kind, str) or not event_kind:
        raise ValueError("event_kind must be a non-empty string")
    if not isinstance(entity_id, str) or not entity_id:
        raise ValueError("entity_id must be a non-empty string")
    if causal_parent_id is not None and (
        not isinstance(causal_parent_id, str) or not causal_parent_id
    ):
        raise ValueError("causal_parent_id must be null or a non-empty string")
    if resource_id is not None and (
        not isinstance(resource_id, str) or not resource_id
    ):
        raise ValueError("resource_id must be null or a non-empty string")
    if isinstance(ordinal, bool) or not isinstance(ordinal, int) or ordinal < 0:
        raise ValueError("ordinal must be a non-negative integer")
    return stable_digest_hex(
        _EVENT_ID_DOMAIN,
        causal_parent_id,
        event_kind,
        entity_id,
        resource_id,
        ordinal,
    )[:32]


def _typed_part(value: Any) -> dict[str, Any]:
    if value is None:
        return {"type": "null", "value": None}
    if isinstance(value, bool):
        return {"type": "bool", "value": value}
    if isinstance(value, int):
        return {"type": "int", "value": value}
    if isinstance(value, str):
        return {"type": "str", "value": value}
    raise TypeError(f"unsupported deterministic-key part type: {type(value).__name__}")
