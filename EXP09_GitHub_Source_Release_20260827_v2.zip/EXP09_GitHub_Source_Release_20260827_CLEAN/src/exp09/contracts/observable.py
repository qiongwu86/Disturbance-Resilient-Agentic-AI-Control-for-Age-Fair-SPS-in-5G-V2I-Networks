"""Controller-visible contracts with no evaluation-truth fields."""

from dataclasses import dataclass
from enum import Enum

from .determinism import stable_event_id
from .ids import EventId, VehicleId, require_identifier, require_sha256
from .time import SimTimeUs, require_non_negative_int

RECEIVER_OBSERVABLE_EVENT_SCHEMA_VERSION = "exp09-receiver-observable-event-v1"
MEASUREMENT_SUMMARY_HEADER_SCHEMA_VERSION = "exp09-measurement-summary-header-v1"
OBSERVABLE_COUNTER_SCHEMA_VERSION = "exp09-observable-counter-v1"
OBSERVABLE_FRAME_SCHEMA_VERSION = "exp09-observable-frame-v1"
RECEIVER_PACKET_OBSERVATION_SCHEMA_VERSION = "exp09-receiver-packet-observation-v1"
RECEIVER_ATTEMPT_OBSERVATION_SCHEMA_VERSION = "exp09-receiver-attempt-observation-v2"
RECEIVER_IDENTITY_EVENT_SCHEMA_VERSION = "exp09-receiver-identity-event-v1"
OBSERVED_USER_AGE_SCHEMA_VERSION = "exp09-observed-user-age-v1"
OBSERVED_USER_STATE_SCHEMA_VERSION = "exp09-observed-user-state-v1"
IDENTITY_REMOVAL_SCHEMA_VERSION = "exp09-identity-removal-v1"
MEASUREMENT_DELIVERY_EVENT_SCHEMA_VERSION = "exp09-measurement-delivery-event-v2"


class ObservableCounterKind(str, Enum):
    FRESH_OBSERVED = "fresh_observed_count"
    STALE_RETAINED = "stale_retained_count"
    UNKNOWN_RETAINED = "unknown_retained_count"
    BUSY_SENSING_UNIT = "busy_sensing_unit_count"
    TOTAL_SENSING_UNIT = "total_sensing_unit_count"
    DECODED_SUCCESS = "decoded_success_count"
    OBSERVABLE_DECODE_TRIAL = "observable_decode_trial_count"


class ReceiverObservableKind(str, Enum):
    PACKET_RECEIVED = "packet_received"
    SENSING_SAMPLE = "sensing_sample"
    CONTROL_DECODED = "control_decoded"
    AUTHENTICATED_HANDOVER = "authenticated_handover"
    AUTHENTICATED_DEPARTURE = "authenticated_departure"


class IdentityState(str, Enum):
    FRESH = "FRESH"
    STALE_RETAINED = "STALE_RETAINED"
    UNKNOWN_RETAINED = "UNKNOWN_RETAINED"


class IdentityRemovalReason(str, Enum):
    AUTHENTICATED_DEPARTURE = "AUTHENTICATED_DEPARTURE"
    AUTHENTICATED_HANDOVER_REMOVAL = "AUTHENTICATED_HANDOVER_REMOVAL"


class MeasurementEventKind(str, Enum):
    ATTEMPT = "ATTEMPT"
    PACKET = "PACKET"
    IDENTITY = "IDENTITY"


class MissingReasonCode(str, Enum):
    NEVER_OBSERVED = "NEVER_OBSERVED"
    SOURCE_FIELD_ABSENT = "SOURCE_FIELD_ABSENT"
    SUMMARY_UNAVAILABLE = "SUMMARY_UNAVAILABLE"
    SUMMARY_STALE = "SUMMARY_STALE"
    ZERO_DECODE_TRIAL = "ZERO_DECODE_TRIAL"
    ZERO_SENSING_DENOMINATOR = "ZERO_SENSING_DENOMINATOR"


@dataclass(frozen=True, slots=True)
class ReceiverObservableEvent:
    schema_version: str
    event_id: EventId
    observed_at_us: SimTimeUs
    kind: ReceiverObservableKind
    payload_hash: str

    def __post_init__(self) -> None:
        if self.schema_version != RECEIVER_OBSERVABLE_EVENT_SCHEMA_VERSION:
            raise ValueError("unsupported receiver-observable-event schema version")
        require_identifier(self.event_id, "event_id")
        require_non_negative_int(self.observed_at_us, "observed_at_us")
        if not isinstance(self.kind, ReceiverObservableKind):
            raise ValueError("kind must be a ReceiverObservableKind")
        require_sha256(self.payload_hash, "payload_hash")


@dataclass(frozen=True, slots=True)
class ReceiverPacketObservation:
    schema_version: str
    event_id: EventId
    vehicle_id: VehicleId
    observed_at_us: SimTimeUs
    packet_generation_us: SimTimeUs

    def __post_init__(self) -> None:
        if self.schema_version != RECEIVER_PACKET_OBSERVATION_SCHEMA_VERSION:
            raise ValueError("unsupported receiver-packet-observation schema version")
        require_identifier(self.event_id, "event_id")
        require_identifier(self.vehicle_id, "vehicle_id")
        require_non_negative_int(self.observed_at_us, "observed_at_us")
        require_non_negative_int(self.packet_generation_us, "packet_generation_us")
        if self.packet_generation_us > self.observed_at_us:
            raise ValueError("packet generation cannot follow receiver observation")


@dataclass(frozen=True, slots=True)
class ReceiverAttemptObservation:
    schema_version: str
    event_id: EventId
    vehicle_id: VehicleId
    observed_at_us: SimTimeUs
    decoded: bool
    busy_slot_us: SimTimeUs

    def __post_init__(self) -> None:
        if self.schema_version != RECEIVER_ATTEMPT_OBSERVATION_SCHEMA_VERSION:
            raise ValueError("unsupported receiver-attempt-observation schema version")
        require_identifier(self.event_id, "event_id")
        require_identifier(self.vehicle_id, "vehicle_id")
        require_non_negative_int(self.observed_at_us, "observed_at_us")
        if not isinstance(self.decoded, bool):
            raise ValueError("decoded must be boolean")
        require_non_negative_int(self.busy_slot_us, "busy_slot_us")


@dataclass(frozen=True, slots=True)
class ReceiverIdentityEvent:
    schema_version: str
    event_id: EventId
    vehicle_id: VehicleId
    observed_at_us: SimTimeUs
    kind: ReceiverObservableKind
    last_success_generation_us: SimTimeUs | None
    removal_reason: IdentityRemovalReason | None

    def __post_init__(self) -> None:
        if self.schema_version != RECEIVER_IDENTITY_EVENT_SCHEMA_VERSION:
            raise ValueError("unsupported receiver-identity-event schema version")
        require_identifier(self.event_id, "event_id")
        require_identifier(self.vehicle_id, "vehicle_id")
        require_non_negative_int(self.observed_at_us, "observed_at_us")
        if self.kind not in (
            ReceiverObservableKind.AUTHENTICATED_HANDOVER,
            ReceiverObservableKind.AUTHENTICATED_DEPARTURE,
        ):
            raise ValueError("identity event must be authenticated handover or departure")
        if self.last_success_generation_us is not None:
            require_non_negative_int(
                self.last_success_generation_us, "last_success_generation_us"
            )
            if self.last_success_generation_us > self.observed_at_us:
                raise ValueError("handover last success cannot follow metadata delivery")
        if self.kind is ReceiverObservableKind.AUTHENTICATED_HANDOVER:
            if self.removal_reason is not None:
                raise ValueError("handover registration cannot carry a removal reason")
        else:
            if self.last_success_generation_us is not None:
                raise ValueError("departure cannot carry a last-success generation timestamp")
            if self.removal_reason is None:
                object.__setattr__(
                    self,
                    "removal_reason",
                    IdentityRemovalReason.AUTHENTICATED_DEPARTURE,
                )


@dataclass(frozen=True, slots=True)
class ObservedUserAge:
    schema_version: str
    vehicle_id: VehicleId
    age_us: int

    def __post_init__(self) -> None:
        if self.schema_version != OBSERVED_USER_AGE_SCHEMA_VERSION:
            raise ValueError("unsupported observed-user-age schema version")
        require_identifier(self.vehicle_id, "vehicle_id")
        require_non_negative_int(self.age_us, "age_us")


@dataclass(frozen=True, slots=True)
class ObservedUserState:
    schema_version: str
    vehicle_id: VehicleId
    ledger_state: IdentityState
    identity_silence_us: int
    age_us: int | None
    age_missing_reason: MissingReasonCode | None

    def __post_init__(self) -> None:
        if self.schema_version != OBSERVED_USER_STATE_SCHEMA_VERSION:
            raise ValueError("unsupported observed-user-state schema version")
        require_identifier(self.vehicle_id, "vehicle_id")
        if not isinstance(self.ledger_state, IdentityState):
            raise ValueError("ledger_state must be an IdentityState")
        require_non_negative_int(self.identity_silence_us, "identity_silence_us")
        if self.age_us is None:
            if self.age_missing_reason is None:
                raise ValueError("a missing age requires an explicit reason")
        else:
            require_non_negative_int(self.age_us, "age_us")
            if self.age_missing_reason is not None:
                raise ValueError("a known age cannot carry an age missing reason")


@dataclass(frozen=True, slots=True)
class IdentityRemoval:
    schema_version: str
    vehicle_id: VehicleId
    reason: IdentityRemovalReason
    event_us: SimTimeUs

    def __post_init__(self) -> None:
        if self.schema_version != IDENTITY_REMOVAL_SCHEMA_VERSION:
            raise ValueError("unsupported identity-removal schema version")
        require_identifier(self.vehicle_id, "vehicle_id")
        if not isinstance(self.reason, IdentityRemovalReason):
            raise ValueError("reason must be an IdentityRemovalReason")
        require_non_negative_int(self.event_us, "event_us")


@dataclass(frozen=True, slots=True)
class MeasurementDeliveryEvent:
    schema_version: str
    event_id: EventId
    delivered_at_us: SimTimeUs
    kind: MeasurementEventKind
    packet: ReceiverPacketObservation | None
    attempt: ReceiverAttemptObservation | None
    identity: ReceiverIdentityEvent | None

    def __post_init__(self) -> None:
        if self.schema_version != MEASUREMENT_DELIVERY_EVENT_SCHEMA_VERSION:
            raise ValueError("unsupported measurement-delivery-event schema version")
        require_identifier(self.event_id, "event_id")
        require_non_negative_int(self.delivered_at_us, "delivered_at_us")
        if not isinstance(self.kind, MeasurementEventKind):
            raise ValueError("kind must be a MeasurementEventKind")
        payloads = tuple(
            item for item in (self.packet, self.attempt, self.identity) if item is not None
        )
        if len(payloads) != 1:
            raise ValueError("measurement delivery must carry exactly one payload")
        expected_type = {
            MeasurementEventKind.PACKET: ReceiverPacketObservation,
            MeasurementEventKind.ATTEMPT: ReceiverAttemptObservation,
            MeasurementEventKind.IDENTITY: ReceiverIdentityEvent,
        }[self.kind]
        if not isinstance(payloads[0], expected_type):
            raise ValueError("measurement delivery kind does not match its payload")
        if int(payloads[0].observed_at_us) != int(self.delivered_at_us):
            raise ValueError("payload observation time must equal phase-60 delivery time")
        payload = payloads[0]
        vehicle_id = str(payload.vehicle_id)
        resource_id = self.kind.value.lower()
        expected_event_id = stable_event_id(
            str(payload.event_id),
            "measurement_delivery",
            vehicle_id,
            resource_id,
            0,
        )
        if str(self.event_id) != expected_event_id:
            raise ValueError("measurement delivery event ID does not match its payload")


@dataclass(frozen=True, slots=True)
class MeasurementSummaryHeader:
    schema_version: str
    sequence: int
    causal_cutoff_us: SimTimeUs
    window_start_us: SimTimeUs

    def __post_init__(self) -> None:
        if self.schema_version != MEASUREMENT_SUMMARY_HEADER_SCHEMA_VERSION:
            raise ValueError("unsupported measurement-summary-header schema version")
        require_non_negative_int(self.sequence, "sequence")
        require_non_negative_int(self.causal_cutoff_us, "causal_cutoff_us")
        require_non_negative_int(self.window_start_us, "window_start_us")
        if self.window_start_us > self.causal_cutoff_us:
            raise ValueError("window_start_us must not exceed causal_cutoff_us")


@dataclass(frozen=True, slots=True)
class ObservableCounter:
    schema_version: str
    kind: ObservableCounterKind
    value: int

    def __post_init__(self) -> None:
        if self.schema_version != OBSERVABLE_COUNTER_SCHEMA_VERSION:
            raise ValueError("unsupported observable-counter schema version")
        if not isinstance(self.kind, ObservableCounterKind):
            raise ValueError("kind must be an ObservableCounterKind")
        require_non_negative_int(self.value, "value")


@dataclass(frozen=True, slots=True)
class ObservableFrame:
    schema_version: str
    source_sequence: int
    causal_cutoff_us: SimTimeUs
    summary_payload_hash: str
    counters: tuple[ObservableCounter, ...]
    missing_reasons: tuple[MissingReasonCode, ...]
    observed_user_ages: tuple[ObservedUserAge, ...]
    observed_users: tuple[ObservedUserState, ...]
    removals: tuple[IdentityRemoval, ...]

    def __post_init__(self) -> None:
        if self.schema_version != OBSERVABLE_FRAME_SCHEMA_VERSION:
            raise ValueError("unsupported observable-frame schema version")
        require_non_negative_int(self.source_sequence, "source_sequence")
        require_non_negative_int(self.causal_cutoff_us, "causal_cutoff_us")
        require_sha256(self.summary_payload_hash, "summary_payload_hash")
        if not isinstance(self.counters, tuple):
            raise ValueError("counters must be a tuple")
        if not all(isinstance(counter, ObservableCounter) for counter in self.counters):
            raise ValueError("counters items must be ObservableCounter values")
        if not isinstance(self.missing_reasons, tuple):
            raise ValueError("missing_reasons must be a tuple")
        if not all(isinstance(reason, MissingReasonCode) for reason in self.missing_reasons):
            raise ValueError("missing_reasons items must be MissingReasonCode values")
        if not isinstance(self.observed_user_ages, tuple) or not all(
            isinstance(item, ObservedUserAge) for item in self.observed_user_ages
        ):
            raise ValueError("observed_user_ages items must be ObservedUserAge values")
        if not isinstance(self.observed_users, tuple) or not all(
            isinstance(item, ObservedUserState) for item in self.observed_users
        ):
            raise ValueError("observed_users items must be ObservedUserState values")
        if not isinstance(self.removals, tuple) or not all(
            isinstance(item, IdentityRemoval) for item in self.removals
        ):
            raise ValueError("removals items must be IdentityRemoval values")
        if len({str(item.vehicle_id) for item in self.observed_users}) != len(
            self.observed_users
        ):
            raise ValueError("observed user IDs must be unique")
        if len({str(item.vehicle_id) for item in self.removals}) != len(self.removals):
            raise ValueError("removal vehicle IDs must be unique")
        kinds = tuple(counter.kind for counter in self.counters)
        if len(set(kinds)) != len(kinds):
            raise ValueError("counter kinds must be unique")
