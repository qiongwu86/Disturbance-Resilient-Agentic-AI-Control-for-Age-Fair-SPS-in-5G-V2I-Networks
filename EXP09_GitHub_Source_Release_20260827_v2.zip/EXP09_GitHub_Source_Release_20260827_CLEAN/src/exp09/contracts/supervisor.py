"""Bounded slow-path provider content contracts."""

from dataclasses import dataclass
from enum import Enum

from .ids import ProgramId, ProgramStateVersion, require_identifier, require_sha256
from .time import SimTimeUs, require_non_negative_int

PROGRAM_PROPOSAL_SCHEMA_VERSION = "exp09-program-proposal-v1"
SUPERVISOR_INPUT_SCHEMA_VERSION = "exp09-supervisor-input-v1"
ELIGIBLE_PROPOSAL_SCHEMA_VERSION = "exp09-eligible-proposal-v1"


class TransitionId(str, Enum):
    START = "START"
    HOLD = "HOLD"
    ADVANCE = "ADVANCE"
    SWITCH = "SWITCH"
    RETURN_BALANCED = "RETURN_BALANCED"


class RationaleCode(str, Enum):
    NO_CHANGE = "NO_CHANGE"
    EVIDENCE_SUPPORTED_TRANSITION = "EVIDENCE_SUPPORTED_TRANSITION"
    HOLD_UNCERTAIN_EVIDENCE = "HOLD_UNCERTAIN_EVIDENCE"
    RETURN_TO_BALANCED = "RETURN_TO_BALANCED"


@dataclass(frozen=True, slots=True)
class EligibleProposal:
    schema_version: str
    transition_id: TransitionId
    target_program_id: ProgramId | None

    def __post_init__(self) -> None:
        if self.schema_version != ELIGIBLE_PROPOSAL_SCHEMA_VERSION:
            raise ValueError("unsupported eligible-proposal schema version")
        if not isinstance(self.transition_id, TransitionId):
            raise ValueError("transition_id must be a TransitionId")
        if self.target_program_id is not None:
            require_identifier(self.target_program_id, "target_program_id")


@dataclass(frozen=True, slots=True)
class ProgramProposal:
    schema_version: str
    transition_id: TransitionId
    target_program_id: ProgramId | None
    rationale_code: RationaleCode

    def __post_init__(self) -> None:
        if self.schema_version != PROGRAM_PROPOSAL_SCHEMA_VERSION:
            raise ValueError("unsupported program-proposal schema version")
        if not isinstance(self.transition_id, TransitionId):
            raise ValueError("transition_id must be a TransitionId")
        if self.target_program_id is not None:
            require_identifier(self.target_program_id, "target_program_id")
        if not isinstance(self.rationale_code, RationaleCode):
            raise ValueError("rationale_code must be a RationaleCode")


@dataclass(frozen=True, slots=True)
class SupervisorInput:
    schema_version: str
    causal_cutoff_us: SimTimeUs
    based_on_sequence: int
    program_state_id: ProgramId
    program_state_version: ProgramStateVersion
    eligible_proposals: tuple[EligibleProposal, ...]
    evidence_hash: str
    remaining_budget_units: int

    def __post_init__(self) -> None:
        if self.schema_version != SUPERVISOR_INPUT_SCHEMA_VERSION:
            raise ValueError("unsupported supervisor-input schema version")
        require_non_negative_int(self.causal_cutoff_us, "causal_cutoff_us")
        require_non_negative_int(self.based_on_sequence, "based_on_sequence")
        require_identifier(self.program_state_id, "program_state_id")
        require_non_negative_int(self.program_state_version, "program_state_version")
        require_non_negative_int(self.remaining_budget_units, "remaining_budget_units")
        if not isinstance(self.eligible_proposals, tuple) or not self.eligible_proposals:
            raise ValueError("eligible_proposals must be a non-empty tuple")
        if not all(isinstance(proposal, EligibleProposal) for proposal in self.eligible_proposals):
            raise ValueError("eligible_proposals items must be EligibleProposal values")
        require_sha256(self.evidence_hash, "evidence_hash")
