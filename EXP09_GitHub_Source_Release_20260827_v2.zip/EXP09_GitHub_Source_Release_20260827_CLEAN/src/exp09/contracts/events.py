"""Versioned event headers without queue or dispatch behavior."""

from dataclasses import dataclass
from enum import Enum

from .ids import EventId, require_identifier
from .time import SimTimeUs, require_non_negative_int

EVENT_HEADER_SCHEMA_VERSION = "exp09-event-header-v1"


class EventKind(str, Enum):
    TX = "tx"
    RX_SUCCESS = "rx_success"
    COLLISION = "collision"
    CHANNEL_ERROR = "channel_error"
    VEHICLE_DEPARTURE = "vehicle_departure"
    VEHICLE_ARRIVAL = "vehicle_arrival"
    HANDOVER_ARRIVAL = "handover_arrival"
    PACKET_GENERATE = "packet_generate"
    BACKGROUND_COUNTER_EXPIRE = "background_counter_expire"
    BACKGROUND_RESOURCE_RESELECT = "background_resource_reselect"
    MEASUREMENT_DELIVERY = "measurement_delivery"
    RECEIVER_LEDGER_UPDATE = "receiver_ledger_update"
    CONTROLLED_COUNTER_EXPIRE = "controlled_counter_expire"
    CONTROL_OPPORTUNITY = "control_opportunity"
    SUPERVISOR_RESPONSE_ARRIVAL = "supervisor_response_arrival"
    PROPOSAL_VERIFICATION = "proposal_verification"
    PENDING_PROGRAM_UPDATE = "pending_program_update"
    FRAME_BUILD = "frame_build"
    CONTROLLER_DECISION = "controller_decision"
    RESERVATION_COMMIT = "reservation_commit"
    FUTURE_TX_SCHEDULE = "future_tx_schedule"

    # Compatibility aliases for the C02 structure-only contract. Runtime code uses
    # the exact event-order names above.
    SPS_COUNTER_EXPIRE = "controlled_counter_expire"
    RESOURCE_RESELECT = "background_resource_reselect"
    CONTROL_EPOCH = "control_opportunity"
    SUPERVISOR_TRIGGER = "frame_build"
    SUPERVISOR_RESPONSE = "supervisor_response_arrival"


@dataclass(frozen=True, slots=True)
class EventHeader:
    schema_version: str
    event_id: EventId
    kind: EventKind
    time_us: SimTimeUs
    causal_parent_id: EventId | None

    def __post_init__(self) -> None:
        if self.schema_version != EVENT_HEADER_SCHEMA_VERSION:
            raise ValueError("unsupported event-header schema version")
        require_identifier(self.event_id, "event_id")
        if not isinstance(self.kind, EventKind):
            raise ValueError("kind must be an EventKind")
        require_non_negative_int(self.time_us, "time_us")
        if self.causal_parent_id is not None:
            require_identifier(self.causal_parent_id, "causal_parent_id")
