"""Integer-only simulation and profiling time types."""

from typing import NewType

SimTimeUs = NewType("SimTimeUs", int)
DurationUs = NewType("DurationUs", int)
RuntimeNs = NewType("RuntimeNs", int)


def require_non_negative_int(value: int, field_name: str) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{field_name} must be a non-negative integer")


def require_positive_int(value: int, field_name: str) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError(f"{field_name} must be a positive integer")
