"""Controller-facing protocols and immutable records only."""

from dataclasses import dataclass
from typing import Protocol

from .actions import ControlAction, ControlOpportunity
from .ids import RootCaseId, RunId, require_identifier, require_sha256
from .observable import ObservableFrame

CONTROLLER_RESET_SCHEMA_VERSION = "exp09-controller-reset-v1"
COMMITMENT_SCHEMA_VERSION = "exp09-commitment-v1"


@dataclass(frozen=True, slots=True)
class ControllerResetContext:
    schema_version: str
    run_id: RunId
    root_case_id: RootCaseId
    config_hash: str

    def __post_init__(self) -> None:
        if self.schema_version != CONTROLLER_RESET_SCHEMA_VERSION:
            raise ValueError("unsupported controller-reset schema version")
        require_identifier(self.run_id, "run_id")
        require_identifier(self.root_case_id, "root_case_id")
        require_sha256(self.config_hash, "config_hash")


@dataclass(frozen=True, slots=True)
class CommitmentRecord:
    schema_version: str
    observation_hash: str
    action: ControlAction

    def __post_init__(self) -> None:
        if self.schema_version != COMMITMENT_SCHEMA_VERSION:
            raise ValueError("unsupported commitment schema version")
        require_sha256(self.observation_hash, "observation_hash")
        if not isinstance(self.action, ControlAction):
            raise ValueError("action must be a ControlAction")


class Controller(Protocol):
    def reset(self, context: ControllerResetContext) -> None: ...

    def decide(
        self,
        frame: ObservableFrame,
        opportunity: ControlOpportunity,
    ) -> CommitmentRecord: ...
