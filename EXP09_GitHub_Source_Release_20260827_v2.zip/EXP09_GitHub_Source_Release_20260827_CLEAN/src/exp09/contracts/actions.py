"""Structure-only control opportunity and action contracts."""

from dataclasses import dataclass
from enum import Enum

from .determinism import stable_digest_hex
from .ids import ControlOpportunityId, VehicleId, require_identifier
from .time import DurationUs, SimTimeUs, require_non_negative_int, require_positive_int

ACTION_SCHEMA_VERSION = "exp09-action-v1"
OPPORTUNITY_SCHEMA_VERSION = "exp09-control-opportunity-v2"
ACTION_FINGERPRINT_DOMAIN = "exp09-action-fingerprint-v1"


class ActionKind(str, Enum):
    NOOP_BEFORE_EXPIRY = "NOOP_BEFORE_EXPIRY"
    RETAIN_AT_EXPIRY = "RETAIN_AT_EXPIRY"
    RESELECT = "RESELECT"


@dataclass(frozen=True, slots=True)
class ControlOpportunity:
    schema_version: str
    opportunity_id: ControlOpportunityId
    vehicle_id: VehicleId
    time_us: SimTimeUs
    reservation_version: int
    current_rri_us: DurationUs
    legal_rri_us: tuple[DurationUs, ...]

    def __post_init__(self) -> None:
        if self.schema_version != OPPORTUNITY_SCHEMA_VERSION:
            raise ValueError("unsupported control-opportunity schema version")
        require_identifier(self.opportunity_id, "opportunity_id")
        require_identifier(self.vehicle_id, "vehicle_id")
        require_non_negative_int(self.time_us, "time_us")
        require_non_negative_int(self.reservation_version, "reservation_version")
        require_positive_int(self.current_rri_us, "current_rri_us")
        if not isinstance(self.legal_rri_us, tuple):
            raise ValueError("legal_rri_us must be a tuple")
        if not self.legal_rri_us:
            raise ValueError("legal_rri_us must not be empty")
        for value in self.legal_rri_us:
            require_positive_int(value, "legal_rri_us item")
        if len(set(self.legal_rri_us)) != len(self.legal_rri_us):
            raise ValueError("legal_rri_us must not contain duplicates")
        if self.current_rri_us not in self.legal_rri_us:
            raise ValueError("current_rri_us must belong to the legal controller domain")


@dataclass(frozen=True, slots=True)
class ControlAction:
    schema_version: str
    opportunity_id: ControlOpportunityId
    kind: ActionKind
    target_rri_us: DurationUs | None

    def __post_init__(self) -> None:
        if self.schema_version != ACTION_SCHEMA_VERSION:
            raise ValueError("unsupported control-action schema version")
        require_identifier(self.opportunity_id, "opportunity_id")
        if not isinstance(self.kind, ActionKind):
            raise ValueError("kind must be an ActionKind")
        if self.kind is ActionKind.RESELECT:
            if self.target_rri_us is None:
                raise ValueError("RESELECT requires target_rri_us")
            require_positive_int(self.target_rri_us, "target_rri_us")
        elif self.target_rri_us is not None:
            raise ValueError("only RESELECT may carry target_rri_us")


def control_action_fingerprint(action: ControlAction) -> str:
    if not isinstance(action, ControlAction):
        raise ValueError("action must be a ControlAction")
    target = action.target_rri_us if action.target_rri_us is not None else "NONE"
    return stable_digest_hex(
        ACTION_FINGERPRINT_DOMAIN,
        str(action.opportunity_id),
        action.kind.value,
        target,
    )
