"""Frozen C03 disturbance-tape contracts."""

from dataclasses import dataclass
from enum import Enum

from .ids import RootCaseId, TapeId, VehicleId, require_identifier, require_sha256
from .time import SimTimeUs, require_non_negative_int, require_positive_int

DISTURBANCE_TAPE_SCHEMA_VERSION = "exp09-disturbance-tape-v3"
TAPE_VEHICLE_SCHEMA_VERSION = "exp09-tape-vehicle-v2"
TAPE_GRANT_SCHEMA_VERSION = "exp09-tape-grant-v1"
TAPE_ARRIVAL_SCHEMA_VERSION = "exp09-tape-arrival-v2"
TAPE_RESELECTION_SCHEMA_VERSION = "exp09-tape-reselection-v1"
TAPE_CHANNEL_DRAW_SCHEMA_VERSION = "exp09-tape-channel-draw-v1"
TAPE_COUNTER_SCHEMA_VERSION = "exp09-tape-counter-v1"
PROTOCOL_GENERATION_ID = "EXP09_G0_AD12A_20260726_V2"


class TapeArm(str, Enum):
    REFERENCE = "REFERENCE"
    EVENT = "EVENT"


class CounterNamespace(str, Enum):
    INITIAL = "initial_counter"
    REBUILD = "rebuild_counter"


@dataclass(frozen=True, slots=True)
class TapeGrant:
    schema_version: str
    rri_us: int
    slot_offset_us: int
    logical_subchannel_id: int

    def __post_init__(self) -> None:
        if self.schema_version != TAPE_GRANT_SCHEMA_VERSION:
            raise ValueError("unsupported tape-grant schema version")
        require_positive_int(self.rri_us, "rri_us")
        require_non_negative_int(self.slot_offset_us, "slot_offset_us")
        require_non_negative_int(self.logical_subchannel_id, "logical_subchannel_id")
        if self.slot_offset_us >= self.rri_us:
            raise ValueError("slot_offset_us must be inside the RRI interval")


@dataclass(frozen=True, slots=True)
class TapeVehicle:
    schema_version: str
    vehicle_id: VehicleId
    arrival_simulation_time_us: SimTimeUs
    arrival_analysis_tau_us: int
    departure_simulation_time_us: SimTimeUs
    departure_analysis_tau_us: int
    packet_phase_us: int
    initial_grant: TapeGrant
    last_success_generation_us_at_entry: SimTimeUs

    def __post_init__(self) -> None:
        if self.schema_version != TAPE_VEHICLE_SCHEMA_VERSION:
            raise ValueError("unsupported tape-vehicle schema version")
        require_identifier(self.vehicle_id, "vehicle_id")
        require_non_negative_int(
            self.arrival_simulation_time_us, "arrival_simulation_time_us"
        )
        if isinstance(self.arrival_analysis_tau_us, bool) or not isinstance(
            self.arrival_analysis_tau_us, int
        ):
            raise ValueError("arrival_analysis_tau_us must be an integer")
        require_non_negative_int(
            self.departure_simulation_time_us, "departure_simulation_time_us"
        )
        if isinstance(self.departure_analysis_tau_us, bool) or not isinstance(
            self.departure_analysis_tau_us, int
        ):
            raise ValueError("departure_analysis_tau_us must be an integer")
        if self.departure_simulation_time_us <= self.arrival_simulation_time_us:
            raise ValueError("departure simulation time must exceed arrival simulation time")
        require_non_negative_int(self.packet_phase_us, "packet_phase_us")
        if self.packet_phase_us >= 100000:
            raise ValueError("packet_phase_us must be inside the packet period")
        if not isinstance(self.initial_grant, TapeGrant):
            raise ValueError("initial_grant must be a TapeGrant")
        if isinstance(self.last_success_generation_us_at_entry, bool) or not isinstance(
            self.last_success_generation_us_at_entry, int
        ):
            raise ValueError("last_success_generation_us_at_entry must be an integer")
        if self.last_success_generation_us_at_entry > self.arrival_simulation_time_us:
            raise ValueError("pre-entry last success cannot be later than arrival")


@dataclass(frozen=True, slots=True)
class TapeArrival:
    schema_version: str
    vehicle_id: VehicleId
    simulation_time_us: SimTimeUs
    analysis_tau_us: int

    def __post_init__(self) -> None:
        if self.schema_version != TAPE_ARRIVAL_SCHEMA_VERSION:
            raise ValueError("unsupported tape-arrival schema version")
        require_identifier(self.vehicle_id, "vehicle_id")
        require_non_negative_int(self.simulation_time_us, "simulation_time_us")
        if isinstance(self.analysis_tau_us, bool) or not isinstance(
            self.analysis_tau_us, int
        ):
            raise ValueError("analysis_tau_us must be an integer")


@dataclass(frozen=True, slots=True)
class TapeCounter:
    schema_version: str
    vehicle_id: VehicleId
    counter_namespace: CounterNamespace
    counter_ordinal: int
    value: int

    def __post_init__(self) -> None:
        if self.schema_version != TAPE_COUNTER_SCHEMA_VERSION:
            raise ValueError("unsupported tape-counter schema version")
        require_identifier(self.vehicle_id, "vehicle_id")
        if not isinstance(self.counter_namespace, CounterNamespace):
            raise ValueError("counter_namespace must be a CounterNamespace")
        require_non_negative_int(self.counter_ordinal, "counter_ordinal")
        if self.counter_namespace is CounterNamespace.INITIAL:
            if self.counter_ordinal != 0:
                raise ValueError("initial counter ordinal must be zero")
        elif self.counter_ordinal < 1:
            raise ValueError("rebuild counter ordinal must start at one")
        if isinstance(self.value, bool) or not isinstance(self.value, int):
            raise ValueError("counter value must be an integer")
        if not 5 <= self.value <= 15:
            raise ValueError("counter value must be in [5, 15] inclusive")


@dataclass(frozen=True, slots=True)
class TapeReselection:
    schema_version: str
    vehicle_id: VehicleId
    ordinal: int
    grant: TapeGrant

    def __post_init__(self) -> None:
        if self.schema_version != TAPE_RESELECTION_SCHEMA_VERSION:
            raise ValueError("unsupported tape-reselection schema version")
        require_identifier(self.vehicle_id, "vehicle_id")
        require_non_negative_int(self.ordinal, "ordinal")
        if not isinstance(self.grant, TapeGrant):
            raise ValueError("grant must be a TapeGrant")


@dataclass(frozen=True, slots=True)
class TapeChannelDraw:
    schema_version: str
    vehicle_id: VehicleId
    ordinal: int
    uniform_u64: int

    def __post_init__(self) -> None:
        if self.schema_version != TAPE_CHANNEL_DRAW_SCHEMA_VERSION:
            raise ValueError("unsupported tape-channel-draw schema version")
        require_identifier(self.vehicle_id, "vehicle_id")
        require_non_negative_int(self.ordinal, "ordinal")
        require_non_negative_int(self.uniform_u64, "uniform_u64")
        if self.uniform_u64 >= 2**64:
            raise ValueError("uniform_u64 must be below 2**64")


@dataclass(frozen=True, slots=True)
class DisturbanceTape:
    schema_version: str
    protocol_generation: str
    tape_id: TapeId
    root_case_id: RootCaseId
    arm: TapeArm
    config_hash: str
    simulation_start_us: SimTimeUs
    simulation_end_us: SimTimeUs
    analysis_origin_simulation_time_us: SimTimeUs
    analysis_tau_start_us: SimTimeUs
    analysis_tau_end_us: SimTimeUs
    paired_anchor_simulation_time_us: SimTimeUs
    paired_anchor_analysis_tau_us: SimTimeUs
    packet_period_us: int
    slot_duration_us: int
    logical_subchannel_count: int
    controlled_vehicle_id: VehicleId
    vehicles: tuple[TapeVehicle, ...]
    arrivals: tuple[TapeArrival, ...]
    background_reselections: tuple[TapeReselection, ...]
    channel_draws: tuple[TapeChannelDraw, ...]
    counters: tuple[TapeCounter, ...]

    def __post_init__(self) -> None:
        if self.schema_version != DISTURBANCE_TAPE_SCHEMA_VERSION:
            raise ValueError("unsupported disturbance-tape schema version")
        if self.protocol_generation != PROTOCOL_GENERATION_ID:
            raise ValueError("unsupported protocol generation")
        require_identifier(self.tape_id, "tape_id")
        require_identifier(self.root_case_id, "root_case_id")
        if not isinstance(self.arm, TapeArm):
            raise ValueError("arm must be a TapeArm")
        require_sha256(self.config_hash, "config_hash")
        require_non_negative_int(self.simulation_start_us, "simulation_start_us")
        require_positive_int(self.simulation_end_us, "simulation_end_us")
        require_non_negative_int(
            self.analysis_origin_simulation_time_us,
            "analysis_origin_simulation_time_us",
        )
        require_non_negative_int(self.analysis_tau_start_us, "analysis_tau_start_us")
        require_positive_int(self.analysis_tau_end_us, "analysis_tau_end_us")
        if not (
            self.simulation_start_us
            <= self.analysis_origin_simulation_time_us
            < self.simulation_end_us
        ):
            raise ValueError("analysis origin must lie inside the simulation window")
        if self.analysis_tau_start_us != 0:
            raise ValueError("analysis_tau_start_us must be zero")
        if (
            self.simulation_end_us - self.analysis_origin_simulation_time_us
            != self.analysis_tau_end_us
        ):
            raise ValueError("simulation and analysis windows use inconsistent coordinates")
        require_non_negative_int(
            self.paired_anchor_simulation_time_us,
            "paired_anchor_simulation_time_us",
        )
        require_non_negative_int(
            self.paired_anchor_analysis_tau_us,
            "paired_anchor_analysis_tau_us",
        )
        if (
            self.paired_anchor_simulation_time_us
            - self.analysis_origin_simulation_time_us
            != self.paired_anchor_analysis_tau_us
        ):
            raise ValueError("paired anchor simulation and analysis coordinates disagree")
        if not self.analysis_tau_start_us <= self.paired_anchor_analysis_tau_us < self.analysis_tau_end_us:
            raise ValueError("paired anchor must lie inside the analysis window")
        require_positive_int(self.packet_period_us, "packet_period_us")
        require_positive_int(self.slot_duration_us, "slot_duration_us")
        require_positive_int(self.logical_subchannel_count, "logical_subchannel_count")
        require_identifier(self.controlled_vehicle_id, "controlled_vehicle_id")
        if not isinstance(self.vehicles, tuple) or not self.vehicles:
            raise ValueError("vehicles must be a non-empty tuple")
        if not all(isinstance(vehicle, TapeVehicle) for vehicle in self.vehicles):
            raise ValueError("vehicles items must be TapeVehicle values")
        if not isinstance(self.arrivals, tuple):
            raise ValueError("arrivals must be a tuple")
        if not all(isinstance(arrival, TapeArrival) for arrival in self.arrivals):
            raise ValueError("arrivals items must be TapeArrival values")
        if not isinstance(self.background_reselections, tuple) or not all(
            isinstance(item, TapeReselection) for item in self.background_reselections
        ):
            raise ValueError("background_reselections items must be TapeReselection values")
        if not isinstance(self.channel_draws, tuple) or not all(
            isinstance(item, TapeChannelDraw) for item in self.channel_draws
        ):
            raise ValueError("channel_draws items must be TapeChannelDraw values")
        if not isinstance(self.counters, tuple) or not self.counters or not all(
            isinstance(item, TapeCounter) for item in self.counters
        ):
            raise ValueError("counters items must be TapeCounter values")
        _require_contiguous_ordinals(
            self.background_reselections,
            "background_reselections",
        )
        _require_contiguous_ordinals(self.channel_draws, "channel_draws")
        vehicle_ids = tuple(vehicle.vehicle_id for vehicle in self.vehicles)
        if len(set(vehicle_ids)) != len(vehicle_ids):
            raise ValueError("vehicle IDs must be unique")
        if self.controlled_vehicle_id not in vehicle_ids:
            raise ValueError("controlled vehicle must be present in the tape")
        counter_vehicle_ids = {item.vehicle_id for item in self.counters}
        if counter_vehicle_ids != set(vehicle_ids):
            raise ValueError("counter tape vehicle IDs must exactly match tape vehicles")
        if self.packet_period_us != 100_000 or self.slot_duration_us != 1_000:
            raise ValueError("unsupported frozen packet or slot duration")
        if self.logical_subchannel_count != 2:
            raise ValueError("unsupported frozen logical-subchannel count")
        arrivals_by_vehicle = {
            str(item.vehicle_id): (
                int(item.simulation_time_us),
                item.analysis_tau_us,
            )
            for item in self.arrivals
        }
        if len(arrivals_by_vehicle) != len(self.arrivals):
            raise ValueError("arrival vehicle IDs must be unique")
        expected_arrivals = {
            str(vehicle.vehicle_id): (
                int(vehicle.arrival_simulation_time_us),
                vehicle.arrival_analysis_tau_us,
            )
            for vehicle in self.vehicles
            if int(vehicle.arrival_simulation_time_us) > int(self.simulation_start_us)
        }
        if arrivals_by_vehicle != expected_arrivals:
            raise ValueError("arrivals must exactly match non-initial vehicle arrival times")
        is_frozen_primary_window = (
            int(self.simulation_start_us) == 0
            and int(self.simulation_end_us) == 50_000_000
            and int(self.analysis_origin_simulation_time_us) == 10_000_000
            and int(self.analysis_tau_end_us) == 40_000_000
        )
        if (
            is_frozen_primary_window
            and self.arm is TapeArm.REFERENCE
            and (len(self.vehicles) != 6 or self.arrivals)
        ):
            raise ValueError("primary REFERENCE tape must contain exactly six initial vehicles")
        if (
            is_frozen_primary_window
            and self.arm is TapeArm.EVENT
            and (len(self.vehicles) != 9 or len(self.arrivals) != 3)
        ):
            raise ValueError("primary EVENT tape must contain six initial and three arriving vehicles")
        for vehicle in self.vehicles:
            _validate_tape_grant(
                vehicle.initial_grant,
                self.slot_duration_us,
                self.logical_subchannel_count,
            )
            if vehicle.packet_phase_us >= self.packet_period_us:
                raise ValueError("vehicle packet phase must be inside the packet period")
            if (
                vehicle.arrival_simulation_time_us
                - self.analysis_origin_simulation_time_us
                != vehicle.arrival_analysis_tau_us
                or vehicle.departure_simulation_time_us
                - self.analysis_origin_simulation_time_us
                != vehicle.departure_analysis_tau_us
            ):
                raise ValueError("vehicle simulation and analysis coordinates disagree")
            if int(vehicle.departure_simulation_time_us) > int(self.simulation_end_us):
                raise ValueError("vehicle departure exceeds the simulation window")
        for item in self.background_reselections:
            _validate_tape_grant(
                item.grant,
                self.slot_duration_us,
                self.logical_subchannel_count,
            )
        _validate_counter_tape(self.counters)


def _require_contiguous_ordinals(items: tuple, field_name: str) -> None:
    ordinals_by_vehicle: dict[str, list[int]] = {}
    for item in items:
        ordinals_by_vehicle.setdefault(str(item.vehicle_id), []).append(item.ordinal)
    for ordinals in ordinals_by_vehicle.values():
        if ordinals != list(range(len(ordinals))):
            raise ValueError(f"{field_name} ordinals must be contiguous from zero per vehicle")


def _validate_counter_tape(items: tuple[TapeCounter, ...]) -> None:
    keys = tuple(
        (str(item.vehicle_id), item.counter_namespace, item.counter_ordinal)
        for item in items
    )
    if len(set(keys)) != len(keys):
        raise ValueError("counter tape keys must be unique")
    vehicle_ids = tuple(sorted({str(item.vehicle_id) for item in items}))
    for vehicle_id in vehicle_ids:
        initial = tuple(
            item.counter_ordinal
            for item in items
            if str(item.vehicle_id) == vehicle_id
            and item.counter_namespace is CounterNamespace.INITIAL
        )
        rebuild = tuple(
            item.counter_ordinal
            for item in items
            if str(item.vehicle_id) == vehicle_id
            and item.counter_namespace is CounterNamespace.REBUILD
        )
        if initial != (0,):
            raise ValueError("counter tape requires exactly initial ordinal zero per vehicle")
        if rebuild != tuple(range(1, len(rebuild) + 1)):
            raise ValueError("rebuild counter ordinals must be contiguous from one")


def _validate_tape_grant(
    grant: TapeGrant,
    slot_duration_us: int,
    logical_subchannel_count: int,
) -> None:
    if grant.rri_us not in (20_000, 50_000, 100_000, 200_000, 300_000, 500_000, 1_000_000):
        raise ValueError("tape grant uses an illegal RRI")
    if grant.slot_offset_us % slot_duration_us:
        raise ValueError("tape grant offset must align to the slot duration")
    if grant.logical_subchannel_id >= logical_subchannel_count:
        raise ValueError("tape grant subchannel is outside the logical grid")
