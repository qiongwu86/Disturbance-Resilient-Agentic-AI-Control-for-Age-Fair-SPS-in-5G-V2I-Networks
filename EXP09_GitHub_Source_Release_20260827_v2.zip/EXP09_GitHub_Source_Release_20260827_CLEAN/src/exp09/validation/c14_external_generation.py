"""Fail-closed readiness and intake audits for external C14.1 responses."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
import re
from typing import Any

from .c14_cache_coverage import (
    CacheCoverageError,
    _validate_inventory_record,
    _validate_method_response,
    validate_offline_cache_coverage,
)
from .c14_phase_a import validate_c14_phase_a_first_frontier

AUTHORITATIVE_DESIGN_LOCATOR = "../EXP09_方法重构与重投可执行设计方案_20260716.md"
AUTHORITATIVE_DESIGN_SHA256 = (
    "244EF3E0FA12648C888D96ADEED246FA6B56EA83C069B300DE170E0D04135CB3"
)
PHASE_A_OUTPUT = "artifacts/c14_1_offline_cache_phase_a_frontier"
EXTERNAL_SOURCE_SCHEMA_VERSION = "exp09-c14-1-external-response-source-v1"
FIRST_FRONTIER_STATUS = "MATERIALIZED_FROM_AUTHORIZED_C14_1_FIRST_FRONTIER_ONLY"
_SHA256 = re.compile(r"[0-9A-Fa-f]{64}")
_METHODS = ("Full", "Plain_LLM")
_PROVIDER_CONFIG_FIELDS = {
    "provider_name",
    "model_identifier",
    "model_revision",
    "endpoint_class",
    "temperature_ppm",
    "seed",
    "seed_supported",
    "max_input_tokens",
    "max_output_tokens",
    "timeout_ms",
    "retry_budget",
    "tool_calls_allowed",
    "provider_memory_allowed",
}
_SOURCE_FIELDS = {
    "schema_version",
    "artifact_status",
    "method_id",
    "generation_scope",
    "inventory_binding",
    "protocol_binding",
    "provider_config",
    "provider_config_sha256",
    "generation_run",
    "usage",
    "records",
}


class C14ExternalGenerationError(ValueError):
    """Raised when external generation evidence is incomplete or inconsistent."""


@dataclass(frozen=True, slots=True)
class ExternalSourceAudit:
    method_id: str
    source_sha256: str
    provider_config_sha256: str
    request_count: int
    provider_calls: int
    llm_tokens: int
    qualified: bool


@dataclass(frozen=True, slots=True)
class ResponseIntakeAudit:
    method_id: str
    source_sha256: str
    bundle_sha256: str
    request_count: int
    qualified: bool


def validate_c14_external_generation_readiness(project_root: Path) -> dict[str, Any]:
    """Reconstruct whether the retained first frontier is safe to send for generation."""

    root = project_root.resolve()
    phase_a = validate_c14_phase_a_first_frontier(root)
    reasons: list[str] = []
    design_path = _resolve(root, AUTHORITATIVE_DESIGN_LOCATOR, allow_parent=True)
    if _sha(design_path) != AUTHORITATIVE_DESIGN_SHA256:
        reasons.append("AUTHORITATIVE_DESIGN_HASH_MISMATCH")

    full_protocol = _strict_json(
        root / "protocol/c14/full_offline_provider_protocol.FROZEN_REMEDIATION_20260728.json"
    )
    plain_protocol = _strict_json(
        root / "protocol/c14/plain_llm_protocol.FROZEN_20260728.json"
    )
    full_inventory = _strict_json(
        root / PHASE_A_OUTPUT / "Full.first_frontier_request_inventory.json"
    )
    plain_inventory = _strict_json(
        root / PHASE_A_OUTPUT / "Plain_LLM.first_frontier_request_inventory.json"
    )

    required_full_input = {
        "causal_cutoff_us",
        "program_state",
        "eligible_proposals",
        "evidence",
        "evidence_hash",
        "remaining_budget",
    }
    declared_full = set(full_protocol.get("request", {}).get("evidence_fields", ()))
    full_record_fields = set(full_inventory["records"][0]["request_payload"])
    if not required_full_input.issubset(declared_full) or not required_full_input.issubset(
        full_record_fields
    ):
        reasons.append("FULL_SUPERVISOR_INPUT_CONTRACT_INCOMPLETE")
    if not isinstance(full_protocol.get("system_prompt"), str) or not isinstance(
        full_protocol.get("user_prompt_template"), dict
    ):
        reasons.append("FULL_PROMPT_NOT_FROZEN")
    controller_source = (
        root / "src/exp09/evaluation/c14_controllers.py"
    ).read_text(encoding="utf-8")
    if (
        "proposal = self._provider_proposal(bundle)" in controller_source
        and "trigger_active=True" in controller_source
    ):
        reasons.append("FULL_PROVIDER_TRIGGER_SEMANTICS_NOT_IMPLEMENTED")

    provider_fields = {
        "provider_name",
        "model_identifier",
        "model_revision",
        "max_input_tokens",
        "max_output_tokens",
        "timeout_ms",
        "seed_supported",
    }
    if not provider_fields.issubset(full_protocol):
        reasons.append("FULL_MODEL_PROVIDER_CONFIG_NOT_FROZEN")
    if not provider_fields.issubset(plain_protocol):
        reasons.append("PLAIN_LLM_MODEL_PROVIDER_CONFIG_NOT_FROZEN")
    for method_id, inventory in (
        ("Full", full_inventory),
        ("Plain_LLM", plain_inventory),
    ):
        if inventory.get("request_count") != 96:
            reasons.append(f"{method_id.upper()}_ARM_CACHE_NAMESPACE_NOT_ISOLATED")
    open_decisions = (root / "protocol/open_decisions.yaml").read_text(encoding="utf-8")
    latency_protocol = (root / "protocol/latency_protocol.yaml").read_text(encoding="utf-8")
    if (
        "supervisor_lifecycle_profile:\n        status: UNRESOLVED" in open_decisions
        or "supervisor_lifecycle:\n  status: UNRESOLVED" in latency_protocol
    ):
        reasons.append("SUPERVISOR_LIFECYCLE_PROFILE_UNRESOLVED")
    if plain_inventory.get("artifact_status") != FIRST_FRONTIER_STATUS:
        reasons.append("PLAIN_LLM_FIRST_FRONTIER_STATUS_MISMATCH")
    if full_inventory.get("artifact_status") != FIRST_FRONTIER_STATUS:
        reasons.append("FULL_FIRST_FRONTIER_STATUS_MISMATCH")

    intake = root / "artifacts/c14_1_offline_cache_phase_a_response_intake"
    expected_intake = tuple(
        intake / f"{method}.{suffix}.json"
        for method in _METHODS
        for suffix in ("source", "bundle")
    )
    response_inputs_present = all(path.is_file() for path in expected_intake)
    if not response_inputs_present:
        reasons.append("FIRST_FRONTIER_RESPONSE_SOURCE_AND_BUNDLES_ABSENT")

    contract_reasons = tuple(
        reason
        for reason in reasons
        if reason
        not in {
            "FIRST_FRONTIER_RESPONSE_SOURCE_AND_BUNDLES_ABSENT",
        }
    )
    return {
        "schema_version": "exp09-c14-1-external-generation-readiness-audit-v1",
        "artifact_status": "EXTERNAL_GENERATION_NOT_READY_FAIL_CLOSED",
        "phase_a_evidence_valid": phase_a["passed"],
        "frontier_cases_retained": phase_a["frontier_cases"],
        "unique_requests": phase_a["unique_requests"],
        "existing_frontier_reusable": {
            "Full": False,
            "Plain_LLM": False,
            "reason": "provider/model/revision must be part of a frozen protocol hash; Full also requires the complete SupervisorInput contract",
        },
        "external_generation_contract_ready": not contract_reasons,
        "response_inputs_present": response_inputs_present,
        "second_round_cases_advanced": 0,
        "cache_qualified": False,
        "c14_1_execution_authorized": False,
        "api_provider_llm_calls_in_repository": 0,
        "network_fallback": False,
        "training_capability": "DISABLED",
        "reasons": reasons,
        "required_remediation": [
            "freeze complete Full SupervisorInput and exact Full prompt",
            "make Full provider invocation and eligibility obey the frozen trigger semantics",
            "freeze one provider/model/revision/token/timeout configuration for Full and Plain_LLM",
            "regenerate request hashes under the corrected protocol generation",
            "obtain a separate authorization before any real provider or LLM generation",
        ],
        "self_authorization_forbidden": True,
    }


def validate_external_response_source(
    project_root: Path,
    source_locator: str,
    *,
    expected_source_sha256: str,
    expected_method_id: str,
    expected_inventory_sha256: str,
    expected_protocol_sha256: str,
    expected_provider_config_sha256: str,
    expected_request_hashes: tuple[str, ...],
) -> ExternalSourceAudit:
    """Audit raw external response provenance without invoking a provider."""

    root = project_root.resolve()
    for value, field in (
        (expected_source_sha256, "source SHA-256"),
        (expected_inventory_sha256, "inventory SHA-256"),
        (expected_protocol_sha256, "protocol SHA-256"),
        (expected_provider_config_sha256, "provider-config SHA-256"),
    ):
        _require_sha(value, field)
    if expected_method_id not in _METHODS:
        raise C14ExternalGenerationError("unsupported external response method")
    _validate_request_hashes(expected_request_hashes)

    source_path = _resolve(root, source_locator)
    if _sha(source_path) != expected_source_sha256:
        raise C14ExternalGenerationError("external response source SHA-256 mismatch")
    source = _strict_json(source_path)
    if not isinstance(source, dict) or set(source) != _SOURCE_FIELDS:
        raise C14ExternalGenerationError("external response source fields mismatch")
    if (
        source["schema_version"] != EXTERNAL_SOURCE_SCHEMA_VERSION
        or source["artifact_status"] != "EXTERNAL_RESPONSE_SOURCE_RETAINED_UNQUALIFIED"
        or source["method_id"] != expected_method_id
        or source["generation_scope"] != "C14_1_FIRST_FRONTIER_ONLY"
    ):
        raise C14ExternalGenerationError("external response source identity mismatch")
    _validate_binding(
        source["inventory_binding"], expected_inventory_sha256, "inventory binding"
    )
    _validate_binding(source["protocol_binding"], expected_protocol_sha256, "protocol binding")

    provider_config = source["provider_config"]
    if not isinstance(provider_config, dict) or set(provider_config) != _PROVIDER_CONFIG_FIELDS:
        raise C14ExternalGenerationError("external provider configuration fields mismatch")
    if source["provider_config_sha256"] != _canonical_sha(provider_config):
        raise C14ExternalGenerationError("external provider configuration hash mismatch")
    if source["provider_config_sha256"] != expected_provider_config_sha256:
        raise C14ExternalGenerationError("external provider configuration is not frozen")
    _validate_provider_config(provider_config)
    _validate_generation_run(source["generation_run"])

    usage = source["usage"]
    if not isinstance(usage, dict) or set(usage) != {
        "api_calls",
        "provider_calls",
        "input_tokens",
        "output_tokens",
        "llm_tokens",
        "retry_count",
        "tool_call_count",
    }:
        raise C14ExternalGenerationError("external generation usage fields mismatch")
    for field, value in usage.items():
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise C14ExternalGenerationError(f"external generation usage is invalid: {field}")
    if usage["retry_count"] != 0 or usage["tool_call_count"] != 0:
        raise C14ExternalGenerationError("retry or tool use is forbidden")
    if usage["llm_tokens"] != usage["input_tokens"] + usage["output_tokens"]:
        raise C14ExternalGenerationError("external token accounting is inconsistent")

    records = source["records"]
    if not isinstance(records, list) or len(records) != len(expected_request_hashes):
        raise C14ExternalGenerationError("external response source record count mismatch")
    actual_hashes = []
    for record in records:
        if not isinstance(record, dict) or set(record) != {
            "request_hash",
            "request_payload_sha256",
            "raw_response",
            "parsed_response",
            "finish_reason",
            "input_tokens",
            "output_tokens",
        }:
            raise C14ExternalGenerationError("external response source record fields mismatch")
        _require_sha(record["request_hash"], "source request hash")
        _require_sha(record["request_payload_sha256"], "source request-payload SHA-256")
        if not isinstance(record["raw_response"], (dict, str)) or not isinstance(
            record["parsed_response"], dict
        ):
            raise C14ExternalGenerationError("external response source content is invalid")
        for field in ("input_tokens", "output_tokens"):
            value = record[field]
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise C14ExternalGenerationError("external response token count is invalid")
        if not isinstance(record["finish_reason"], str) or not record["finish_reason"]:
            raise C14ExternalGenerationError("external response finish reason is missing")
        actual_hashes.append(record["request_hash"])
    if tuple(actual_hashes) != expected_request_hashes:
        raise C14ExternalGenerationError("external response source request order mismatch")
    if usage["provider_calls"] != len(records):
        raise C14ExternalGenerationError("external provider-call count mismatch")
    if usage["input_tokens"] != sum(record["input_tokens"] for record in records) or usage[
        "output_tokens"
    ] != sum(record["output_tokens"] for record in records):
        raise C14ExternalGenerationError("external per-record token accounting mismatch")
    return ExternalSourceAudit(
        method_id=expected_method_id,
        source_sha256=expected_source_sha256,
        provider_config_sha256=expected_provider_config_sha256,
        request_count=len(records),
        provider_calls=usage["provider_calls"],
        llm_tokens=usage["llm_tokens"],
        qualified=True,
    )


def validate_response_intake(
    project_root: Path,
    inventory_locator: str,
    bundle_locator: str,
    source_locator: str,
    *,
    expected_inventory_sha256: str,
    expected_bundle_sha256: str,
    expected_source_sha256: str,
    expected_method_id: str,
    expected_namespace: str,
    expected_method_config_sha256: str,
    expected_protocol_sha256: str,
    expected_provider_config_sha256: str,
) -> ResponseIntakeAudit:
    """Cross-check source, parsed responses, bundle, and first-frontier inventory."""

    root = project_root.resolve()
    inventory = _strict_json(_resolve(root, inventory_locator))
    request_hashes = tuple(inventory.get("request_hashes", ()))
    source_audit = validate_external_response_source(
        root,
        source_locator,
        expected_source_sha256=expected_source_sha256,
        expected_method_id=expected_method_id,
        expected_inventory_sha256=expected_inventory_sha256,
        expected_protocol_sha256=expected_protocol_sha256,
        expected_provider_config_sha256=expected_provider_config_sha256,
        expected_request_hashes=request_hashes,
    )
    coverage = _validate_first_frontier_bundle(
        root,
        inventory,
        bundle_locator,
        expected_inventory_sha256=expected_inventory_sha256,
        expected_bundle_sha256=expected_bundle_sha256,
        expected_method_id=expected_method_id,
        expected_namespace=expected_namespace,
        expected_method_config_sha256=expected_method_config_sha256,
        expected_protocol_sha256=expected_protocol_sha256,
        inventory_path=_resolve(root, inventory_locator),
    )

    source = _strict_json(_resolve(root, source_locator))
    bundle = _strict_json(_resolve(root, bundle_locator))
    provenance = bundle.get("provenance", {})
    if provenance != {
        "source_artifact_locator": source_locator,
        "source_artifact_sha256": expected_source_sha256,
    }:
        raise C14ExternalGenerationError("bundle provenance does not bind the audited source")
    source_responses = [record["parsed_response"] for record in source["records"]]
    bundle_responses = [entry["response"] for entry in bundle["entries"]]
    payload_hashes = [
        _canonical_sha(record["request_payload"])
        for record in inventory["records"]
    ]
    source_payload_hashes = [
        record["request_payload_sha256"] for record in source["records"]
    ]
    if source_payload_hashes != payload_hashes:
        raise C14ExternalGenerationError(
            "external source request payloads do not bind the audited inventory"
        )
    if source_responses != bundle_responses:
        raise C14ExternalGenerationError("bundle responses differ from audited source responses")
    return ResponseIntakeAudit(
        method_id=expected_method_id,
        source_sha256=source_audit.source_sha256,
        bundle_sha256=expected_bundle_sha256,
        request_count=coverage.entry_count,
        qualified=True,
    )


def _validate_first_frontier_bundle(
    root: Path,
    inventory: Any,
    bundle_locator: str,
    *,
    expected_inventory_sha256: str,
    expected_bundle_sha256: str,
    expected_method_id: str,
    expected_namespace: str,
    expected_method_config_sha256: str,
    expected_protocol_sha256: str,
    inventory_path: Path,
):
    if _sha(inventory_path) != expected_inventory_sha256:
        raise C14ExternalGenerationError("request inventory SHA-256 mismatch")
    if (
        not isinstance(inventory, dict)
        or inventory.get("schema_version") != "exp09-c14-1-request-inventory-v1"
        or inventory.get("artifact_status") != FIRST_FRONTIER_STATUS
    ):
        raise C14ExternalGenerationError("first-frontier inventory identity mismatch")
    for field, expected in (
        ("method_id", expected_method_id),
        ("namespace", expected_namespace),
        ("method_config_sha256", expected_method_config_sha256),
        ("protocol_sha256", expected_protocol_sha256),
    ):
        if inventory.get(field) != expected:
            raise C14ExternalGenerationError(f"request inventory {field} mismatch")
    records = inventory.get("records")
    hashes = inventory.get("request_hashes")
    if not isinstance(records, list) or not isinstance(hashes, list) or not records:
        raise C14ExternalGenerationError("request inventory records are missing")
    if (
        inventory.get("request_count") != len(records)
        or inventory.get("records_sha256") != _canonical_sha(records)
    ):
        raise C14ExternalGenerationError("request inventory count or records hash mismatch")
    try:
        actual_hashes = [
            _validate_inventory_record(record, expected_method_id, expected_protocol_sha256)
            for record in records
        ]
        if hashes != actual_hashes or len(set(hashes)) != len(hashes):
            raise C14ExternalGenerationError("request inventory ordering or uniqueness mismatch")
        coverage = validate_offline_cache_coverage(
            root,
            bundle_locator,
            expected_bundle_sha256=expected_bundle_sha256,
            expected_method_id=expected_method_id,
            expected_namespace=expected_namespace,
            expected_method_config_sha256=expected_method_config_sha256,
            expected_protocol_sha256=expected_protocol_sha256,
            expected_request_hashes=tuple(hashes),
        )
        bundle = _strict_json(_resolve(root, bundle_locator))
        for record, entry in zip(records, bundle["entries"], strict=True):
            if set(entry) != {"request_hash", "response", "response_binding_sha256"}:
                raise C14ExternalGenerationError("cache entry fields do not match qualification schema")
            binding = _canonical_sha(
                {"request_hash": entry["request_hash"], "response": entry["response"]}
            )
            if entry["response_binding_sha256"] != binding:
                raise C14ExternalGenerationError("cache response binding SHA-256 mismatch")
            _validate_method_response(expected_method_id, record, entry["response"])
    except CacheCoverageError as exc:
        raise C14ExternalGenerationError(str(exc)) from exc
    return coverage


def audit_as_dict(value: ExternalSourceAudit | ResponseIntakeAudit) -> dict[str, Any]:
    return asdict(value)


def _validate_binding(binding: Any, expected_sha256: str, label: str) -> None:
    if not isinstance(binding, dict) or set(binding) != {"locator", "sha256"}:
        raise C14ExternalGenerationError(f"{label} fields mismatch")
    if not isinstance(binding["locator"], str) or not binding["locator"]:
        raise C14ExternalGenerationError(f"{label} locator is missing")
    if binding["sha256"] != expected_sha256:
        raise C14ExternalGenerationError(f"{label} SHA-256 mismatch")


def _validate_provider_config(config: dict[str, Any]) -> None:
    for field in ("provider_name", "model_identifier", "model_revision", "endpoint_class"):
        if not isinstance(config[field], str) or not config[field].strip():
            raise C14ExternalGenerationError(f"external provider field is missing: {field}")
    for field in (
        "temperature_ppm",
        "max_input_tokens",
        "max_output_tokens",
        "timeout_ms",
        "retry_budget",
    ):
        value = config[field]
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise C14ExternalGenerationError(f"external provider field is invalid: {field}")
    if config["temperature_ppm"] != 0 or config["retry_budget"] != 0:
        raise C14ExternalGenerationError("temperature and retry budget must remain zero")
    if config["max_input_tokens"] <= 0 or config["max_output_tokens"] <= 0 or config[
        "timeout_ms"
    ] <= 0:
        raise C14ExternalGenerationError("external provider caps must be positive")
    if not isinstance(config["seed_supported"], bool):
        raise C14ExternalGenerationError("seed_supported must be boolean")
    if config["seed_supported"]:
        if isinstance(config["seed"], bool) or not isinstance(config["seed"], int):
            raise C14ExternalGenerationError("provider seed is invalid")
    elif config["seed"] is not None:
        raise C14ExternalGenerationError("provider seed must be null when unsupported")
    if config["tool_calls_allowed"] is not False or config["provider_memory_allowed"] is not False:
        raise C14ExternalGenerationError("tools and provider memory are forbidden")


def _validate_generation_run(value: Any) -> None:
    expected = {
        "generation_run_id",
        "started_at",
        "completed_at",
        "client_name",
        "client_version",
        "operator",
    }
    if not isinstance(value, dict) or set(value) != expected:
        raise C14ExternalGenerationError("external generation run fields mismatch")
    if any(not isinstance(value[field], str) or not value[field].strip() for field in expected):
        raise C14ExternalGenerationError("external generation run value is missing")


def _validate_request_hashes(values: tuple[str, ...]) -> None:
    if not values or len(values) != len(set(values)):
        raise C14ExternalGenerationError("expected request hashes must be non-empty and unique")
    for value in values:
        _require_sha(value, "expected request hash")


def _resolve(root: Path, locator: Any, *, allow_parent: bool = False) -> Path:
    if not isinstance(locator, str) or not locator or "\\" in locator:
        raise C14ExternalGenerationError("external generation locator is invalid")
    path = (root / locator).resolve()
    boundary = root.parent if allow_parent else root
    try:
        path.relative_to(boundary)
    except ValueError as exc:
        raise C14ExternalGenerationError("external generation locator escapes its boundary") from exc
    if not path.is_file():
        raise C14ExternalGenerationError(f"external generation artifact is missing: {locator}")
    return path


def _strict_json(path: Path) -> Any:
    def reject_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise C14ExternalGenerationError(f"duplicate JSON key is forbidden: {key}")
            result[key] = value
        return result

    try:
        return json.loads(
            path.read_text(encoding="utf-8"),
            object_pairs_hook=reject_duplicates,
            parse_constant=lambda value: (_ for _ in ()).throw(
                C14ExternalGenerationError(f"non-finite JSON value is forbidden: {value}")
            ),
        )
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise C14ExternalGenerationError("external generation artifact is not strict JSON") from exc


def _canonical_sha(value: Any) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest().upper()


def _require_sha(value: Any, field: str) -> None:
    if not isinstance(value, str) or _SHA256.fullmatch(value) is None:
        raise C14ExternalGenerationError(f"{field} must be a SHA-256 digest")


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()
