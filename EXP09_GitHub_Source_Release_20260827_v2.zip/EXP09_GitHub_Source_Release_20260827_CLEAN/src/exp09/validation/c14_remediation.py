"""Independent audit for C14.1 preflight remediation artifacts."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

METHODS = (
    "Full",
    "RMPC_SameEvaluator",
    "Rule_SameStack",
    "TunedNonLLM_SameStack",
    "Plain_LLM",
    "DQN",
    "DQN_Strong",
    "GNN_DDQN",
    "KEEP_sanity",
    "AoI_aware_heuristic",
    "Greedy_1",
    "Nominal_MPC",
)

REMEDIATION_CONFIG = "protocol/c14/c14_1_method_configs.FROZEN_REMEDIATION_20260728.json"
REMEDIATION_RL_MAPPING = (
    "protocol/c14/c14_1_complex_checkpoint_registry.FROZEN_20260728.json"
)
REMEDIATION_AUTHORIZATION = (
    "protocol/c14/c14_1_preflight_remediation_authorization_20260728.json"
)
REMEDIATION_EVIDENCE_INDEX = (
    "protocol/c14/c14_1_preflight_remediation_evidence_index_20260729.json"
)

REQUIRED_EVIDENCE_BINDINGS = {
    REMEDIATION_AUTHORIZATION,
    "protocol/c14/c14_1_preflight_remediation_authorization_20260728.md",
    REMEDIATION_CONFIG,
    REMEDIATION_RL_MAPPING,
    "protocol/c14/full_offline_provider_protocol.FROZEN_REMEDIATION_20260728.json",
    "protocol/c14/plain_llm_protocol.FROZEN_20260728.json",
    "protocol/c14/checkpoint_registry.CANDIDATE_V2_20260728.json",
    "protocol/c14/c14_1_execution_gate_20260728.json",
    "protocol/c14/c14_1_failed_preflight_evidence_index_20260728.json",
    "protocol/c14/c14_1_preflight_remediation_verification_20260729.json",
    "src/exp09/evaluation/c14_controllers.py",
    "src/exp09/evaluation/c14_offline_cache.py",
    "src/exp09/validation/c14_remediation.py",
    "tests/c14/test_c14_preflight_remediation.py",
    "tests/c14/fixtures/offline_cache_source.SYNTHETIC.json",
    "tests/c14/fixtures/offline_cache_bundle.SYNTHETIC.json",
    "protocol/c12/c12_final_audit.json",
    "protocol/c12/c12_final_freeze_manifest.json",
    "protocol/c12/c12_checkpoint_registry.json",
    "protocol/c12/c12_budget_ledger_frozen.json",
    "protocol/c12/c12_defect_recovery_record.json",
    "protocol/evidence/C12_real_training_qualification_report_20260728.md",
    "protocol/c12/c12_execution_manifest.ENABLED_ARCHIVE.json",
    "protocol/c12/c12_execution_manifest.json",
}


def validate_c14_1_preflight_remediation(project_root: Path) -> dict[str, Any]:
    """Qualify code/config remediation while preserving the cache hard stop."""

    root = project_root.resolve()
    reasons: list[str] = []
    for locator in (
        REMEDIATION_AUTHORIZATION,
        REMEDIATION_CONFIG,
        REMEDIATION_RL_MAPPING,
        "src/exp09/evaluation/c14_controllers.py",
        "src/exp09/evaluation/c14_offline_cache.py",
    ):
        if not (root / locator).is_file():
            reasons.append(f"missing remediation artifact: {locator}")
    if reasons:
        return {"passed": False, "reasons": tuple(reasons)}

    historical_index = _load_json(
        root, "protocol/c14/c14_1_failed_preflight_evidence_index_20260728.json"
    )
    if historical_index.get("artifact_status") != (
        "FAIL_CLOSED_EVIDENCE_FROZEN_C14_1_NOT_STARTED"
    ):
        reasons.append("historical failed-preflight evidence status drifted")
    for binding in historical_index.get("artifacts", ()) + historical_index.get(
        "historical_bindings", ()
    ):
        path = root / binding.get("locator", "")
        if not path.is_file() or _sha(path) != binding.get("sha256"):
            reasons.append(
                f"historical failed-preflight binding mismatch: {binding.get('locator')}"
            )

    authorization = _load_json(root, REMEDIATION_AUTHORIZATION)
    permissions = authorization.get("permissions", {})
    if authorization.get("artifact_status") != (
        "AUTHORIZED_REMEDIATION_ONLY_METHOD_CASES_FORBIDDEN"
    ):
        reasons.append("remediation authorization scope mismatch")
    if any(value is not False for value in permissions.values()):
        reasons.append("remediation authorization enables a forbidden permission")
    if authorization.get("self_authorization_forbidden") is not True:
        reasons.append("remediation authorization can self-authorize")

    config = _load_json(root, REMEDIATION_CONFIG)
    if config.get("execution_qualified") is not False:
        reasons.append("cache-blocked method config claims execution qualification")
    if tuple(config.get("methods", ())) != METHODS:
        reasons.append("remediation method topology is not exactly the frozen 12 methods")
    if set(config.get("offline_cache_status", {})) != {"Full", "Plain_LLM"}:
        reasons.append("offline-cache blocked method set mismatch")
    if any(
        "HARD_STOP" not in str(value)
        for value in config.get("offline_cache_status", {}).values()
    ):
        reasons.append("offline-cache absence does not retain a hard stop")
    if any(
        value is not False
        for value in config.get("execution_permissions", {}).values()
    ):
        reasons.append("method config enables a forbidden permission")

    shared = config.get("shared_model", {})
    source = root / shared.get("source_locator", "")
    if not source.is_file() or _sha(source) != shared.get("source_sha256"):
        reasons.append("shared C07 model config binding mismatch")
    if shared.get("horizon_us") != 3_000_000 or shared.get(
        "transitions_per_decision"
    ) != 72_000:
        reasons.append("shared model horizon/budget drifted")
    risk = config.get("risk_gate", {})
    risk_source = root / risk.get("source_locator", "")
    if not risk_source.is_file() or _sha(risk_source) != risk.get("source_sha256"):
        reasons.append("structural C08 RiskGate source binding mismatch")
    if "NOT_EMPIRICAL_CALIBRATION" not in str(risk.get("provenance_boundary")):
        reasons.append("constructed RiskGate value is misrepresented as calibration")

    prompt = root / config.get("plain_llm", {}).get("protocol_locator", "")
    if not prompt.is_file() or _sha(prompt) != config.get("plain_llm", {}).get(
        "protocol_sha256"
    ):
        reasons.append("Plain_LLM protocol binding mismatch")
    if config.get("plain_llm", {}).get("network_fallback") is not False:
        reasons.append("Plain_LLM config permits network fallback")
    supervisor = config.get("same_stack_supervisor", {})
    full_protocol = root / supervisor.get("full_provider_protocol_locator", "")
    if not full_protocol.is_file() or _sha(full_protocol) != supervisor.get(
        "full_provider_protocol_sha256"
    ):
        reasons.append("Full offline provider protocol binding mismatch")
    for key in ("controller_adapter", "offline_cache_loader"):
        bindings = config.get("implementation_bindings", {})
        implementation = root / bindings.get(f"{key}_locator", "")
        if not implementation.is_file() or _sha(implementation) != bindings.get(
            f"{key}_sha256"
        ):
            reasons.append(f"{key} implementation binding mismatch")

    rl_inference = config.get("rl_inference", {})
    enabled_manifest = root / rl_inference.get("enabled_manifest_locator", "")
    if not enabled_manifest.is_file() or _sha(enabled_manifest) != rl_inference.get(
        "enabled_manifest_sha256"
    ):
        reasons.append("RL enabled-manifest archive binding mismatch")
    if (
        rl_inference.get("scenario") != "complex"
        or rl_inference.get("arms") != ["REFERENCE", "EVENT"]
        or rl_inference.get("explore") is not False
        or rl_inference.get("training_or_observe_allowed") is not False
    ):
        reasons.append("RL inference config is not complex-only deterministic inference")

    mapping = _load_json(root, REMEDIATION_RL_MAPPING)
    entries = mapping.get("entries", [])
    expected_pairs = {
        (method, seed)
        for method in METHODS[5:8]
        for seed in (101, 202, 303, 404, 505)
    }
    actual_pairs = {
        (entry.get("method_id"), entry.get("train_seed")) for entry in entries
    }
    if mapping.get("unique_checkpoint_count") != 15 or len(entries) != 15:
        reasons.append("complex checkpoint registry does not contain 15 entries")
    if actual_pairs != expected_pairs or len(actual_pairs) != len(entries):
        reasons.append("complex checkpoint registry identity set is incomplete or duplicated")
    if any(
        entry.get("scenario") != "complex"
        or entry.get("arms") != ["REFERENCE", "EVENT"]
        or entry.get("same_checkpoint_identity_across_arms") is not True
        for entry in entries
    ):
        reasons.append("RL checkpoint identity is not complex-only and arm-independent")

    source_registry = root / mapping.get("source_registry_locator", "")
    if not source_registry.is_file() or _sha(source_registry) != mapping.get(
        "source_registry_sha256"
    ):
        reasons.append("complex checkpoint source-registry binding mismatch")
    else:
        source_entries = _load_json(root, mapping["source_registry_locator"]).get(
            "checkpoint_entries", []
        )
        source_by_pair = {
            (item.get("method_id"), item.get("train_seed")): item
            for item in source_entries
            if item.get("scenario") == "complex"
        }
        for entry in entries:
            source_entry = source_by_pair.get(
                (entry.get("method_id"), entry.get("train_seed"))
            )
            if source_entry is None or any(
                entry.get(field) != source_entry.get(field)
                for field in ("episode", "relative_path", "sha256", "config_hash")
            ):
                reasons.append(
                    "complex checkpoint mapping does not reproduce C12 source: "
                    f"{entry.get('method_id')} seed {entry.get('train_seed')}"
                )
                continue
            checkpoint = root / entry.get("relative_path", "")
            if not checkpoint.is_file() or _sha(checkpoint) != entry.get("sha256"):
                reasons.append(
                    f"complex checkpoint file/hash mismatch: {entry.get('relative_path')}"
                )

    gate = _load_json(root, "protocol/c14/c14_1_execution_gate_20260728.json")
    if any(
        gate.get(field) is not False
        for field in (
            "c14_1_execution_enabled",
            "method_execution_allowed",
            "training_allowed",
            "api_allowed",
            "provider_calls_allowed",
            "llm_calls_allowed",
            "shadow_allowed",
            "precision_allowed",
            "locked_test_allowed",
            "performance_claim_allowed",
        )
    ):
        reasons.append("historical execution gate is no longer fail-closed")
    if (root / "artifacts/c14_1_design_validation").exists():
        reasons.append("C14.1 method-case artifact directory exists")

    _audit_remediation_evidence_index(root, reasons)

    return {
        "passed": not reasons,
        "artifact_status": (
            "CODE_CONFIG_CHECKPOINT_REMEDIATION_PASS_CACHE_INPUT_ABSENT_HARD_STOP"
            if not reasons
            else "REMEDIATION_AUDIT_FAILED_HARD_STOP"
        ),
        "code_and_config_remediated": not reasons,
        "cache_qualified": False,
        "c14_1_execution_authorized": False,
        "execution_started": False,
        "executed_method_cases": 0,
        "api_provider_llm_calls": 0,
        "reasons": tuple(reasons),
    }


def _load_json(root: Path, locator: str) -> Any:
    return json.loads((root / locator).read_text(encoding="utf-8"))


def _audit_remediation_evidence_index(root: Path, reasons: list[str]) -> None:
    path = root / REMEDIATION_EVIDENCE_INDEX
    if not path.is_file():
        reasons.append("remediation evidence index is missing")
        return

    index = _load_json(root, REMEDIATION_EVIDENCE_INDEX)
    if index.get("artifact_status") != (
        "CODE_CONFIG_CHECKPOINT_REMEDIATION_PASS_CACHE_INPUT_ABSENT_HARD_STOP"
    ):
        reasons.append("remediation evidence index status mismatch")
    if index.get("self_authorization_forbidden") is not True:
        reasons.append("remediation evidence index can self-authorize")

    terminal = index.get("terminal_state", {})
    expected_terminal = {
        "cache_qualified": False,
        "c14_1_execution_authorized": False,
        "execution_started": False,
        "executed_method_cases": 0,
        "api_provider_llm_calls": 0,
        "training_capability": "DISABLED",
        "c14_2_allowed": False,
        "shadow_allowed": False,
        "precision_allowed": False,
        "locked_test_allowed": False,
        "performance_claim_allowed": False,
    }
    if terminal != expected_terminal:
        reasons.append("remediation evidence terminal state is not exactly fail-closed")

    bindings = index.get("artifacts", [])
    if not isinstance(bindings, list):
        reasons.append("remediation evidence bindings must be a list")
        return
    locators = [binding.get("locator") for binding in bindings if isinstance(binding, dict)]
    if len(locators) != len(bindings) or len(set(locators)) != len(locators):
        reasons.append("remediation evidence bindings are malformed or duplicated")
        return
    if set(locators) != REQUIRED_EVIDENCE_BINDINGS:
        reasons.append("remediation evidence binding set is incomplete or unexpected")
    for binding in bindings:
        locator = binding["locator"]
        locator_path = Path(locator)
        if locator_path.is_absolute() or ".." in locator_path.parts:
            reasons.append(f"remediation evidence locator is unsafe: {locator}")
            continue
        artifact = root / locator_path
        if not artifact.is_file() or _sha(artifact) != binding.get("sha256"):
            reasons.append(f"remediation evidence binding mismatch: {locator}")


def _sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()
