"""Independent read-only audit for the C14.1 Phase A first frontier."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from .c14_cache_coverage import _validate_inventory_record
from .c14_executable_preflight import _expand_topology

PHASE_A_CASE_COUNT = 192
PHASE_A_METHODS = ("Full", "Plain_LLM")
PHASE_A_OUTPUT_LOCATOR = "artifacts/c14_1_offline_cache_phase_a_frontier"
FORMAL_C14_1_OUTPUT_LOCATOR = "artifacts/c14_1_design_validation"

TOPOLOGY_LOCATOR = (
    "protocol/c14/c14_1_method_case_topology.FROZEN_PREFLIGHT_20260729.json"
)
AUTHORIZATION_LOCATOR = (
    "protocol/c14/"
    "c14_1_offline_cache_phase_a_first_frontier_authorization.FROZEN_20260729.json"
)


class C14PhaseAValidationError(ValueError):
    """Raised when retained Phase A evidence is incomplete or inconsistent."""


def validate_c14_phase_a_first_frontier(project_root: Path) -> dict[str, Any]:
    root = project_root.resolve()
    output = root / PHASE_A_OUTPUT_LOCATOR
    if (root / FORMAL_C14_1_OUTPUT_LOCATOR).exists():
        raise C14PhaseAValidationError("formal C14.1 artifact exists during Phase A")
    topology_path = root / TOPOLOGY_LOCATOR
    topology = _strict_json(topology_path)
    if not isinstance(topology, dict):
        raise C14PhaseAValidationError("C14.1 topology is not a JSON object")
    cases = tuple(
        case
        for case in _expand_topology(root, topology)
        if case["method_id"] in PHASE_A_METHODS
    )
    _validate_cases(cases)
    authorization_path = root / AUTHORIZATION_LOCATOR
    authorization = _strict_json(authorization_path)
    if not isinstance(authorization, dict):
        raise C14PhaseAValidationError("Phase A authorization is not a JSON object")
    authorization_sha = _sha(authorization_path)
    phase_sha = _canonical_sha(cases)
    config_sha = topology["method_config_binding"]["sha256"]
    _validate_authorization(
        authorization,
        topology_sha=_sha(topology_path),
        phase_sha=phase_sha,
        config_sha=config_sha,
    )
    ledger_path = output / "phase_a_frontier_ledger.json"
    ledger, latest, usage = _validate_ledger(
        ledger_path,
        cases,
        source_topology_sha256=_sha(topology_path),
        phase_a_topology_sha256=phase_sha,
        authorization_sha256=authorization_sha,
        budget_caps=authorization["budget_caps"],
    )
    inventories = {
        method: output / f"{method}.first_frontier_request_inventory.json"
        for method in PHASE_A_METHODS
    }
    inventory_documents: dict[str, dict[str, Any]] = {}
    for method, path in inventories.items():
        document = _strict_json(path)
        if not isinstance(document, dict):
            raise C14PhaseAValidationError("Phase A inventory is not a JSON object")
        if document.get("artifact_status") != (
            "MATERIALIZED_FROM_AUTHORIZED_C14_1_FIRST_FRONTIER_ONLY"
        ):
            raise C14PhaseAValidationError("Phase A inventory status mismatch")
        binding = authorization["methods"][method]
        expected_identity = (
            document.get("method_id"),
            document.get("namespace"),
            document.get("method_config_sha256"),
            document.get("protocol_sha256"),
        )
        if expected_identity != (
            method,
            binding["namespace"],
            config_sha,
            binding["protocol_sha256"],
        ):
            raise C14PhaseAValidationError("Phase A inventory binding mismatch")
        records = document.get("records")
        hashes = document.get("request_hashes")
        if not isinstance(records, list) or not isinstance(hashes, list):
            raise C14PhaseAValidationError("Phase A inventory records are missing")
        rebuilt = [
            _validate_inventory_record(record, method, binding["protocol_sha256"])
            for record in records
        ]
        if (
            document.get("request_count") != len(records)
            or document.get("records_sha256") != _canonical_sha(records)
            or hashes != rebuilt
            or len(hashes) != len(set(hashes))
        ):
            raise C14PhaseAValidationError("Phase A inventory hash audit failed")
        if any(
            document.get(field) != expected
            for field, expected in (
                ("network_fallback", False),
                ("api_calls", 0),
                ("provider_calls", 0),
                ("llm_tokens", 0),
                ("cache_coverage_qualified", False),
                ("execution_authorized", False),
            )
        ):
            raise C14PhaseAValidationError("Phase A inventory records a forbidden gate")
        inventory_documents[method] = document

    rebuilt_audit = _rebuild_audit(root, output, latest, usage, inventory_documents)
    audit_path = output / "phase_a_frontier_audit.json"
    stored_audit = _strict_json(audit_path)
    provenance_binding = stored_audit.pop("provenance", None)
    if stored_audit != rebuilt_audit:
        raise C14PhaseAValidationError("stored Phase A audit is not independently reproducible")

    provenance_path = output / "phase_a_frontier_provenance.json"
    if provenance_binding != {
        "locator": provenance_path.relative_to(root).as_posix(),
        "sha256": _sha(provenance_path),
    }:
        raise C14PhaseAValidationError("Phase A audit provenance binding mismatch")
    provenance = _strict_json(provenance_path)
    if provenance.get("authorization_sha256") != authorization_sha or provenance.get(
        "phase_a_topology_sha256"
    ) != phase_sha:
        raise C14PhaseAValidationError("Phase A provenance authority binding mismatch")
    if any(
        _sha(_resolve(root, item.get("locator"))) != item.get("sha256")
        for item in provenance.get("bindings", [])
    ):
        raise C14PhaseAValidationError("Phase A provenance source hash mismatch")
    if (
        provenance.get("response_bytes_read") != 0
        or provenance.get("network_fallback") is not False
        or provenance.get("c14_1_method_cases_executed") != 0
    ):
        raise C14PhaseAValidationError("Phase A provenance records a forbidden effect")

    external_path = output / "external_response_generation_input.json"
    external = _strict_json(external_path)
    if (
        external.get("artifact_status")
        != "READY_FOR_EXTERNAL_FIRST_FRONTIER_RESPONSE_GENERATION"
        or external.get("generation_scope")
        != "FIRST_FRONTIER_ONLY_NOT_COMPLETE_C14_1_CACHE"
        or external.get("authorization_sha256") != authorization_sha
        or external.get("automatic_continuation") is not False
    ):
        raise C14PhaseAValidationError("external response input gate mismatch")
    if external.get("audit") != {
        "locator": audit_path.relative_to(root).as_posix(),
        "sha256": _sha(audit_path),
    }:
        raise C14PhaseAValidationError("external response input audit binding mismatch")
    for method, inventory in inventory_documents.items():
        method_input = external.get("methods", {}).get(method, {})
        if (
            method_input.get("inventory_sha256") != _sha(inventories[method])
            or method_input.get("unique_request_count") != inventory["request_count"]
            or method_input.get("required_request_hashes") != inventory["request_hashes"]
        ):
            raise C14PhaseAValidationError("external response input inventory binding mismatch")
    if external.get("qualification_state") != {
        "first_frontier_responses_provided": False,
        "complete_c14_1_request_inventory": False,
        "cache_qualified": False,
        "c14_1_execution_authorized": False,
    }:
        raise C14PhaseAValidationError("external response input overstates qualification")

    completion_path = output / "phase_a_first_frontier_completion.json"
    completion = _strict_json(completion_path)
    expected_completion_bindings = {
        "authorization_sha256": authorization_sha,
        "ledger_sha256": _sha(ledger_path),
        "provenance_sha256": _sha(provenance_path),
        "audit_sha256": _sha(audit_path),
        "external_response_generation_input_sha256": _sha(external_path),
    }
    if completion.get("bindings") != expected_completion_bindings:
        raise C14PhaseAValidationError("Phase A completion hash chain mismatch")
    expected_completion_state = (
        completion.get("phase_a_first_frontier_complete"),
        completion.get("frontier_case_count"),
        completion.get("c14_1_method_cases_executed"),
        completion.get("cache_qualified"),
        completion.get("c14_1_execution_authorized"),
        completion.get("automatic_continuation"),
    )
    if expected_completion_state != (True, PHASE_A_CASE_COUNT, 0, False, False, False):
        raise C14PhaseAValidationError("Phase A completion state mismatch")

    return {
        "schema_version": "exp09-c14-1-offline-cache-phase-a-validation-v1",
        "artifact_status": "PHASE_A_FIRST_FRONTIER_INDEPENDENT_VALIDATION_PASS",
        "passed": True,
        "frontier_cases": PHASE_A_CASE_COUNT,
        "unique_requests": {
            method: inventory_documents[method]["request_count"]
            for method in PHASE_A_METHODS
        },
        "duplicate_case_requests": {
            method: 96 - inventory_documents[method]["request_count"]
            for method in PHASE_A_METHODS
        },
        "hash_collisions": 0,
        "api_calls": 0,
        "provider_calls": 0,
        "llm_tokens": 0,
        "network_attempts": 0,
        "cache_miss_continuations": 0,
        "c14_1_method_cases_executed": 0,
        "formal_c14_1_artifact_created": False,
        "cache_qualified": False,
        "c14_1_execution_authorized": False,
        "external_response_generation_input": {
            "locator": external_path.relative_to(root).as_posix(),
            "sha256": _sha(external_path),
        },
        "completion": {
            "locator": completion_path.relative_to(root).as_posix(),
            "sha256": _sha(completion_path),
        },
    }


def _validate_cases(cases: tuple[dict[str, Any], ...]) -> None:
    if len(cases) != PHASE_A_CASE_COUNT or len({case["case_id"] for case in cases}) != (
        PHASE_A_CASE_COUNT
    ):
        raise C14PhaseAValidationError("Phase A topology is not exactly 192 unique cases")
    counts = {
        method: sum(case["method_id"] == method for case in cases)
        for method in PHASE_A_METHODS
    }
    roots = {case["root_case_id"] for case in cases}
    expected = {
        (root, arm, method)
        for root in roots
        for arm in ("REFERENCE", "EVENT")
        for method in PHASE_A_METHODS
    }
    if (
        counts != {"Full": 96, "Plain_LLM": 96}
        or len(roots) != 48
        or {
            (case["root_case_id"], case["arm"], case["method_id"])
            for case in cases
        }
        != expected
        or any(case["train_seed"] is not None for case in cases)
    ):
        raise C14PhaseAValidationError("Phase A topology scope drifted")


def _validate_authorization(
    document: dict[str, Any],
    *,
    topology_sha: str,
    phase_sha: str,
    config_sha: str,
) -> None:
    if (
        document.get("schema_version")
        != "exp09-c14-1-offline-cache-phase-a-authorization-v1"
        or document.get("artifact_status") != "FROZEN_USER_AUTHORIZED_FIRST_FRONTIER_ONLY"
    ):
        raise C14PhaseAValidationError("Phase A authorization identity mismatch")
    expected_gates = {
        "first_frontier_materialization_authorized": True,
        "cache_miss_continuation_authorized": False,
        "c14_1_method_case_execution_authorized": False,
        "api_provider_llm_authorized": False,
        "network_fallback_authorized": False,
        "training_authorized": False,
        "performance_statistics_authorized": False,
        "c14_2_authorized": False,
        "shadow_authorized": False,
        "precision_authorized": False,
        "locked_test_authorized": False,
    }
    topology = document.get("topology", {})
    if document.get("gates") != expected_gates or (
        topology.get("source_topology_sha256"),
        topology.get("phase_a_topology_sha256"),
        topology.get("frontier_case_count"),
        topology.get("root_count"),
        topology.get("arms"),
        topology.get("methods"),
        document.get("method_config_sha256"),
    ) != (
        topology_sha,
        phase_sha,
        192,
        48,
        ["REFERENCE", "EVENT"],
        ["Full", "Plain_LLM"],
        config_sha,
    ):
        raise C14PhaseAValidationError("Phase A authorization scope/gate mismatch")


def _validate_ledger(
    path: Path,
    cases: tuple[dict[str, Any], ...],
    *,
    source_topology_sha256: str,
    phase_a_topology_sha256: str,
    authorization_sha256: str,
    budget_caps: dict[str, int],
) -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, int]]:
    document = _strict_json(path)
    if not isinstance(document, dict) or document.get("schema_version") != (
        "exp09-c14-1-offline-cache-phase-a-ledger-v1"
    ):
        raise C14PhaseAValidationError("Phase A ledger schema mismatch")
    if (
        document.get("source_topology_sha256"),
        document.get("phase_a_topology_sha256"),
        document.get("authorization_sha256"),
        document.get("budget_caps"),
    ) != (
        source_topology_sha256,
        phase_a_topology_sha256,
        authorization_sha256,
        budget_caps,
    ):
        raise C14PhaseAValidationError("Phase A ledger authority/budget binding mismatch")
    rows = document.get("rows")
    if (
        not isinstance(rows, list)
        or document.get("attempt_row_count") != len(rows)
        or document.get("rows_sha256") != _canonical_sha(rows)
    ):
        raise C14PhaseAValidationError("Phase A ledger row hash mismatch")
    case_by_id = {case["case_id"]: case for case in cases}
    by_case: dict[str, list[dict[str, Any]]] = {case_id: [] for case_id in case_by_id}
    counter_fields = (
        "decision_attempts",
        "model_transitions",
        "cache_lookup_attempts",
        "cache_misses",
        "api_calls",
        "provider_calls",
        "llm_tokens",
        "network_attempts",
        "controller_commitments",
        "post_miss_plant_actions",
    )
    for row in rows:
        if not isinstance(row, dict) or row.get("case_id") not in by_case:
            raise C14PhaseAValidationError("Phase A ledger contains an invalid case")
        case = case_by_id[row["case_id"]]
        identity = (
            row.get("source_ordinal"),
            row.get("root_case_id"),
            row.get("root_namespace"),
            row.get("arm"),
            row.get("scenario"),
            row.get("method_id"),
            row.get("variant_id"),
        )
        if identity != (
            case["ordinal"],
            case["root_case_id"],
            case["root_namespace"],
            case["arm"],
            case["scenario"],
            case["method_id"],
            case["variant_id"],
        ):
            raise C14PhaseAValidationError("Phase A ledger row topology mismatch")
        if any(
            isinstance(row.get(field), bool)
            or not isinstance(row.get(field), int)
            or row[field] < 0
            for field in counter_fields
        ):
            raise C14PhaseAValidationError("Phase A ledger counter is invalid")
        by_case[row["case_id"]].append(row)
    latest: list[dict[str, Any]] = []
    for case_id, attempts in by_case.items():
        if not attempts or [row["attempt_ordinal"] for row in attempts] != list(
            range(len(attempts))
        ):
            raise C14PhaseAValidationError("Phase A attempt history is invalid")
        for index, row in enumerate(attempts):
            if row["run_id"] != f"phase-a__{case_id}__attempt{index:03d}":
                raise C14PhaseAValidationError("Phase A run identifier mismatch")
            if index == 0 and row["resume_of"] is not None:
                raise C14PhaseAValidationError("initial Phase A attempt is a resume")
            if index > 0 and row["resume_of"] != attempts[index - 1]["run_id"]:
                raise C14PhaseAValidationError("Phase A resume binding mismatch")
        retained = attempts[-1]
        expected_transitions = 72_000 if retained["method_id"] == "Full" else 0
        if (
            retained["status"],
            retained["decision_attempts"],
            retained["model_transitions"],
            retained["cache_lookup_attempts"],
            retained["cache_misses"],
            retained["error_code"],
        ) != (
            "CACHE_MISS_FRONTIER_RETAINED",
            1,
            expected_transitions,
            1,
            1,
            "EXPECTED_OFFLINE_CACHE_MISS",
        ):
            raise C14PhaseAValidationError("Phase A case did not retain the expected miss")
        if not _is_sha(retained.get("request_hash")) or not _is_sha(
            retained.get("inventory_sha256_at_miss")
        ):
            raise C14PhaseAValidationError("Phase A retained row lacks hash evidence")
        if any(
            retained[field] != 0
            for field in (
                "api_calls",
                "provider_calls",
                "llm_tokens",
                "network_attempts",
                "controller_commitments",
                "post_miss_plant_actions",
            )
        ):
            raise C14PhaseAValidationError("Phase A retained row records a forbidden effect")
        latest.append(retained)
    usage = {
        "frontier_cases": sum(
            row["attempt_ordinal"] == 0 and row["status"] != "PLANNED" for row in rows
        ),
        **{field: sum(row[field] for row in rows) for field in counter_fields},
        "concurrency": sum(row["status"] == "RUNNING" for row in rows),
    }
    if document.get("budget_usage") != usage or any(
        usage[field] > budget_caps[field] for field in usage
    ):
        raise C14PhaseAValidationError("Phase A ledger budget usage mismatch")
    return document, latest, usage


def _rebuild_audit(
    root: Path,
    output: Path,
    latest: list[dict[str, Any]],
    usage: dict[str, int],
    inventories: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    expected_usage = {
        "frontier_cases": 192,
        "decision_attempts": 192,
        "model_transitions": 6_912_000,
        "cache_lookup_attempts": 192,
        "cache_misses": 192,
        "concurrency": 0,
        "api_calls": 0,
        "provider_calls": 0,
        "llm_tokens": 0,
        "network_attempts": 0,
        "controller_commitments": 0,
        "post_miss_plant_actions": 0,
    }
    if usage != expected_usage:
        raise C14PhaseAValidationError("Phase A successful usage mismatch")
    summaries: dict[str, dict[str, Any]] = {}
    for method, inventory in inventories.items():
        case_hashes = [row["request_hash"] for row in latest if row["method_id"] == method]
        hashes = inventory["request_hashes"]
        if len(case_hashes) != 96 or set(case_hashes) != set(hashes):
            raise C14PhaseAValidationError("Phase A ledger/inventory request mismatch")
        path = output / f"{method}.first_frontier_request_inventory.json"
        summaries[method] = {
            "frontier_case_count": 96,
            "unique_request_count": len(hashes),
            "duplicate_case_request_count": 96 - len(set(case_hashes)),
            "hash_collision_count": 0,
            "locator": path.relative_to(root).as_posix(),
            "sha256": _sha(path),
            "records_sha256": inventory["records_sha256"],
        }
    ledger_path = output / "phase_a_frontier_ledger.json"
    return {
        "schema_version": "exp09-c14-1-offline-cache-phase-a-audit-v1",
        "artifact_status": "PHASE_A_FIRST_FRONTIER_AUDIT_PASS",
        "passed": True,
        "frontier_case_count": 192,
        "root_count": 48,
        "arms": ["REFERENCE", "EVENT"],
        "methods": ["Full", "Plain_LLM"],
        "inventories": summaries,
        "budget_usage": usage,
        "ledger": {
            "locator": ledger_path.relative_to(root).as_posix(),
            "sha256": _sha(ledger_path),
        },
        "c14_1_method_cases_executed": 0,
        "performance_statistics_generated": False,
        "response_bytes_read": 0,
        "cache_miss_continuations": 0,
        "api_calls": 0,
        "provider_calls": 0,
        "llm_tokens": 0,
        "network_attempts": 0,
        "training_capability": "DISABLED",
        "forbidden_stages_executed": [],
        "formal_c14_1_artifact_created": False,
    }


def _resolve(root: Path, locator: Any) -> Path:
    if not isinstance(locator, str) or not locator or "\\" in locator:
        raise C14PhaseAValidationError("Phase A provenance locator is invalid")
    path = (root / locator).resolve()
    try:
        path.relative_to(root)
    except ValueError as exc:
        raise C14PhaseAValidationError("Phase A provenance locator escapes project") from exc
    if not path.is_file():
        raise C14PhaseAValidationError("Phase A provenance source is missing")
    return path


def _strict_json(path: Path) -> Any:
    def reject_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise C14PhaseAValidationError(f"duplicate JSON key is forbidden: {key}")
            result[key] = value
        return result

    try:
        return json.loads(
            path.read_text(encoding="utf-8"),
            object_pairs_hook=reject_duplicates,
            parse_constant=lambda value: (_ for _ in ()).throw(
                C14PhaseAValidationError(f"non-finite JSON value is forbidden: {value}")
            ),
        )
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise C14PhaseAValidationError("Phase A artifact is not strict UTF-8 JSON") from exc


def _canonical_sha(value: Any) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest().upper()


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def _is_sha(value: Any) -> bool:
    return isinstance(value, str) and len(value) == 64 and all(
        character in "0123456789ABCDEFabcdef" for character in value
    )
