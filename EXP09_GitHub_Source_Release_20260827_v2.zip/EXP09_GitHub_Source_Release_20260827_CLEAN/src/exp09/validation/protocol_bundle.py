"""Fail-closed validation for the non-executable G0 protocol bundle."""

from collections.abc import Mapping
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path, PurePosixPath
from typing import Any

import yaml


@dataclass(frozen=True, slots=True)
class ProtocolBundleValidationReport:
    passed: bool
    reasons: tuple[str, ...]


_YAML_RECORDS = (
    "event_order.yaml",
    "scenario_registry.yaml",
    "protocol.yaml",
    "metrics_spec.yaml",
    "gate_registry.yaml",
    "latency_protocol.yaml",
)
_JSON_RECORDS = (
    "observable_schema.json",
    "static_capacity_certificate.json",
    "protocol_generation_candidate.json",
)
_REQUIRED_MANIFEST_ARTIFACTS = frozenset(
    {
        "protocol/open_decisions.yaml",
        "protocol/event_order.yaml",
        "protocol/scenario_registry.yaml",
        "protocol/protocol.yaml",
        "protocol/metrics_spec.yaml",
        "protocol/observable_schema.json",
        "protocol/gate_registry.yaml",
        "protocol/latency_protocol.yaml",
        "protocol/static_capacity_certificate.json",
        "protocol/evidence/C01_O08_target_application_margin_audit_20260721.md",
        "protocol/evidence/C01_AD06B_author_resolution_20260722.md",
        "protocol/evidence/C01_remaining_preC03_author_decisions_20260722.md",
        "protocol/evidence/C01_AD07_AD11_author_resolution_20260722.md",
        "protocol/evidence/C01_AD12A_author_resolution_20260726.md",
        "protocol/evidence/G1_event_queue_rng_report.md",
        "protocol/evidence/G1_measurement_boundary_report.md",
        "protocol/evidence/G1_metric_runner_report.md",
        "protocol/evidence/G1_plant_report.md",
        "protocol/schemas/measurement_summary.schema.json",
        "protocol/schemas/measurement_summary_header.schema.json",
        "protocol/schemas/observable_frame.schema.json",
        "protocol/schemas/program_proposal.schema.json",
        "protocol/forbidden_fields.json",
    }
)
_PROTOCOL_GENERATION_ID = "EXP09_G0_AD12A_20260726_V2"
_EXECUTION_PLAN_LOCATOR = "EXP09_代码级执行方案_20260717.md"
_EXECUTION_PLAN_SHA256 = (
    "D4FE5F97AF716FCBEA0B88DACD657664EF50F0ED3976D62B5E3CF4CEFCA321FD"
)
_AD12_MANIFEST_BLOCKERS = [
    "AD12_COUNTER_INITIAL_AND_REBUILD_DISTRIBUTION",
    "AD12_BURN_IN_INTERNAL_TIME_MAPPING_AND_CONTROLLED_KEEP_POLICY",
]
_AD12_GATE_BLOCKERS = ["AD12_COUNTER_AND_BURN_IN_CLARIFICATION"]
_INVALIDATED_V1_STATUS = "INVALIDATED_PROTOCOL_GENERATION_V1_BLOCKED_BY_AD12"
_G1_REPORTS = {
    "event_queue_rng_report": "protocol/evidence/G1_event_queue_rng_report.md",
    "plant_report": "protocol/evidence/G1_plant_report.md",
    "measurement_boundary_report": "protocol/evidence/G1_measurement_boundary_report.md",
    "metric_runner_report": "protocol/evidence/G1_metric_runner_report.md",
}
_GATE_RUNTIME_FIELDS = (
    "event_queue_allowed",
    "plant_allowed",
    "measurement_allowed",
    "metric_runner_allowed",
    "method_allowed",
    "training_allowed",
    "API_allowed",
    "pilot_shadow_precision_locked_allowed",
)


def _load_yaml(path: Path) -> Any:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def _load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _float_paths(value: Any, *, path: str = "root") -> tuple[str, ...]:
    found: list[str] = []
    if isinstance(value, float):
        found.append(path)
    elif isinstance(value, Mapping):
        for key, child in value.items():
            found.extend(_float_paths(child, path=f"{path}.{key}"))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            found.extend(_float_paths(child, path=f"{path}[{index}]"))
    return tuple(found)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def _safe_locator(locator: Any) -> bool:
    if not isinstance(locator, str) or not locator or "\\" in locator:
        return False
    path = PurePosixPath(locator)
    return not path.is_absolute() and ".." not in path.parts and ":" not in path.parts[0]


def validate_protocol_bundle(project_root: Path) -> ProtocolBundleValidationReport:
    project_root = project_root.resolve()
    protocol_root = project_root / "protocol"
    reasons: list[str] = []
    records: dict[str, Any] = {}

    for name in _YAML_RECORDS:
        path = protocol_root / name
        if not path.is_file():
            reasons.append(f"{name}: missing")
            continue
        try:
            records[name] = _load_yaml(path)
        except yaml.YAMLError:
            reasons.append(f"{name}: invalid YAML")
    for name in _JSON_RECORDS:
        path = protocol_root / name
        if not path.is_file():
            reasons.append(f"{name}: missing")
            continue
        try:
            records[name] = _load_json(path)
        except json.JSONDecodeError:
            reasons.append(f"{name}: invalid JSON")

    for name, record in records.items():
        for path in _float_paths(record):
            reasons.append(f"{name}: float is forbidden at {path}")

    event_order = records.get("event_order.yaml", {})
    priorities = event_order.get("ordering_contract", {}).get("priorities", [])
    if [item.get("event_priority") for item in priorities] != list(range(10, 101, 10)):
        reasons.append("event_order.yaml: exact ten-level priority order is required")
    if event_order.get("ordering_contract", {}).get("sort_key") != [
        "time_us",
        "event_priority",
        "stable_event_id",
    ]:
        reasons.append("event_order.yaml: canonical sort key mismatch")
    event_boundary = event_order.get("execution_boundary", {})
    if (
        event_boundary.get("queue_implementation_present") is not True
        or event_boundary.get("hard_stop_before_step") != "C07"
    ):
        reasons.append("event_order.yaml: C03-C06 implementation boundary mismatch")

    scenario = records.get("scenario_registry.yaml", {})
    if scenario.get("protocol_generation") != _PROTOCOL_GENERATION_ID:
        reasons.append("scenario_registry.yaml: protocol generation mismatch")
    population = scenario.get("frozen_population_contract", {})
    if (population.get("initial_total_vehicles"), population.get("maximum_realized_total_vehicles")) != (6, 9):
        reasons.append("scenario_registry.yaml: population continuity must be 6 to 9")
    if population.get("primary_influx_new_background_vehicles") != 3:
        reasons.append("scenario_registry.yaml: primary influx must be +3")
    if scenario.get("timing", {}).get("primary_event_end_recovery") != (
        "NONE_PERSISTENT_TO_ANALYSIS_WINDOW_END"
    ):
        reasons.append("scenario_registry.yaml: persistent primary cannot claim recovery")

    protocol = records.get("protocol.yaml", {})
    metrics = records.get("metrics_spec.yaml", {})
    latency = records.get("latency_protocol.yaml", {})
    observable = records.get("observable_schema.json", {})
    certificate = records.get("static_capacity_certificate.json", {})
    if protocol.get("time_and_order", {}).get("queue_implementation_allowed") is not True:
        reasons.append("protocol.yaml: event queue must be allowed after C03 implementation")
    if protocol.get("protocol_generation") != _PROTOCOL_GENERATION_ID:
        reasons.append("protocol.yaml: protocol generation mismatch")
    if metrics.get("protocol_generation") != _PROTOCOL_GENERATION_ID:
        reasons.append("metrics_spec.yaml: protocol generation mismatch")
    if protocol.get("resource_and_action", {}).get("logical_subchannel_count") != 2:
        reasons.append("protocol.yaml: logical subchannel count must match C=2 certificate")
    if certificate.get("selection", {}).get("logical_subchannel_count") != 2:
        reasons.append("static certificate: logical subchannel count must be 2")
    if certificate.get("selection", {}).get("minimum_c_by_headroom") != 1:
        reasons.append("static certificate: headroom alone must resolve C=1")
    if certificate.get("selection", {}).get("minimum_c_by_required_2d_witnesses") != 2:
        reasons.append("static certificate: structural witnesses must resolve C=2")
    if protocol.get("resource_and_action", {}).get("selection_lead_time_us") != "NONE_ADDITIONAL":
        reasons.append("protocol.yaml: selection lead-time policy mismatch")
    if metrics.get("margin_and_claim_contract", {}).get("AD_06_status") != (
        "FROZEN_AD06B_EFFECT_AND_CI_DOWNGRADE"
    ):
        reasons.append("metrics_spec.yaml: AD-06B downgrade must be frozen")
    if metrics.get("containment_and_recovery", {}).get("primary_event_end_recovery_time") != "NOT_DEFINED":
        reasons.append("metrics_spec.yaml: persistent primary recovery must be undefined")
    if latency.get("fast_path", {}).get("deployment_action_deadline_us") != "NOT_ESTABLISHED":
        reasons.append("latency_protocol.yaml: deployment deadline must not be invented")
    if latency.get("fast_path", {}).get("target_may_be_used_as_deadline_or_gate") is not False:
        reasons.append("latency_protocol.yaml: 5 ms target must remain non-executable")
    if observable.get("delivery_contract", {}).get("delay_us") != 10000:
        reasons.append("observable_schema.json: measurement delay must be 10000 us")
    if observable.get("delivery_contract", {}).get("telemetry_dropout_performance_duration_us") != 500000:
        reasons.append("observable_schema.json: telemetry performance dropout mismatch")

    gate_registry = records.get("gate_registry.yaml", {})
    manifest = records.get("protocol_generation_candidate.json", {})
    if manifest.get("status") not in {"G1_REVALIDATION_IN_PROGRESS", "FROZEN"}:
        reasons.append("protocol generation manifest has an unknown lifecycle state")
    if manifest.get("protocol_generation") != _PROTOCOL_GENERATION_ID:
        reasons.append("protocol generation manifest has the wrong generation ID")
    if manifest.get("status") == "FROZEN":
        if manifest.get("signing_status") != "FROZEN_SIGNED":
            reasons.append("frozen protocol generation must carry a frozen signing status")
    elif manifest.get("signing_status") != "PENDING_G1_REVALIDATION":
        reasons.append("V2 protocol generation must remain pending until G1 passes")
    artifacts = manifest.get("artifacts", [])
    artifact_locators = [
        artifact.get("locator") if isinstance(artifact, Mapping) else None
        for artifact in artifacts
    ]
    if len(artifact_locators) != len(set(artifact_locators)):
        reasons.append("protocol generation candidate contains duplicate artifact locators")
    if frozenset(artifact_locators) != _REQUIRED_MANIFEST_ARTIFACTS:
        reasons.append("protocol generation candidate artifact set is incomplete or unknown")
    manifest_blockers = manifest.get("blockers")
    if manifest.get("status") == "FROZEN":
        if manifest.get("runtime_allowed") is not True or manifest_blockers != []:
            reasons.append("frozen protocol generation must be executable and blocker-free")
    elif manifest.get("runtime_allowed") is not True or manifest_blockers != [
        "G1_REVALIDATION_NOT_YET_COMPLETE"
    ]:
        reasons.append("V2 protocol generation has an invalid G1-pending state")
    execution_plan = manifest.get("authoritative_execution_plan")
    if (
        not isinstance(execution_plan, Mapping)
        or execution_plan.get("locator") != _EXECUTION_PLAN_LOCATOR
        or execution_plan.get("sha256") != _EXECUTION_PLAN_SHA256
    ):
        reasons.append("protocol generation candidate execution-plan authority mismatch")
    else:
        execution_plan_path = project_root.parent / _EXECUTION_PLAN_LOCATOR
        if not execution_plan_path.is_file():
            reasons.append("authoritative execution plan is missing")
        elif _sha256(execution_plan_path) != _EXECUTION_PLAN_SHA256:
            reasons.append("authoritative execution plan hash mismatch")
    if manifest.get("status") in {"FROZEN", "G1_REVALIDATION_IN_PROGRESS"}:
        if (
            event_order.get("status") != "FROZEN_STATIC_CONTRACT"
            or event_boundary.get("runtime_allowed") is not True
            or scenario.get("status") != "PRIMARY_AND_ROUTING_FROZEN"
            or scenario.get("runtime_allowed") is not True
            or protocol.get("status") != "FROZEN_C03_C06_RUNTIME_PROTOCOL"
            or protocol.get("runtime_allowed") is not True
            or metrics.get("status") != "FROZEN_EFFECT_AND_CI_REDUCED_CLAIM_PROTOCOL"
            or metrics.get("runtime_allowed") is not True
            or observable.get("status") != "FROZEN_POC_OBSERVATION_CONTRACT"
            or observable.get("runtime_allowed") is not True
            or latency.get("status") != "FROZEN_FOR_C03_C06_MEASUREMENT_POC"
            or latency.get("runtime_allowed") is not True
        ):
            reasons.append("frozen protocol records must consistently allow runtime")
    else:
        scenario_boundary = scenario.get("blocking_contract", {})
        protocol_boundary = protocol.get("execution_boundary", {})
        metrics_boundary = metrics.get("execution_boundary", {})
        observable_boundary = observable.get("execution_boundary", {})
        latency_boundary = latency.get("execution_boundary", {})
        records_are_invalidated = all(
            record.get("status") == _INVALIDATED_V1_STATUS
            and record.get("runtime_allowed") is False
            for record in (scenario, protocol, metrics, observable, latency)
        ) and (
            event_order.get("status") == _INVALIDATED_V1_STATUS
            and event_boundary.get("runtime_allowed") is False
        )
        blocked_capabilities = (
            scenario_boundary.get("blocker") == _AD12_GATE_BLOCKERS[0]
            and scenario_boundary.get("generation_state")
            == "INVALIDATED_PROTOCOL_GENERATION_V1"
            and all(
                scenario_boundary.get(field) is False
                for field in (
                    "runtime_allowed",
                    "scenario_tape_generation_allowed",
                    "design_validation_run_allowed",
                    "method_free_dynamic_run_allowed",
                    "method_identified_run_allowed",
                )
            )
            and all(
                protocol_boundary.get(field) is False
                for field in (
                    "event_queue_allowed",
                    "tape_generation_allowed",
                    "plant_execution_allowed",
                    "measurement_allowed",
                    "metric_runner_allowed",
                    "method_execution_allowed",
                    "experiment_execution_allowed",
                    "training_allowed",
                    "API_allowed",
                    "pilot_shadow_precision_locked_allowed",
                )
            )
            and all(
                metrics_boundary.get(field) is False
                for field in (
                    "accumulator_implementation_allowed",
                    "metric_execution_allowed",
                    "method_comparison_allowed",
                )
            )
            and all(
                observable_boundary.get(field) is False
                for field in (
                    "measurement_business_logic_allowed",
                    "observation_adapter_allowed",
                )
            )
            and all(
                latency_boundary.get(field) is False
                for field in (
                    "latency_business_logic_allowed",
                    "provider_call_allowed",
                    "profiling_allowed",
                    "deployment_claim_allowed",
                )
            )
        )
        if not records_are_invalidated or not blocked_capabilities:
            reasons.append("invalidated V1 protocol records expose an executable capability")
    gate_blockers = tuple(
        gate_registry.get("gates", {}).get("G0_SCIENCE", {}).get("blockers", [])
    )
    if manifest.get("status") == "FROZEN":
        if gate_blockers != ():
            reasons.append("gate_registry.yaml: frozen G0-SCIENCE must be blocker-free")
    elif gate_blockers != ():
        reasons.append("gate_registry.yaml: V2 G0-SCIENCE must be blocker-free")

    g0_science = gate_registry.get("gates", {}).get("G0_SCIENCE", {})
    g1 = gate_registry.get("gates", {}).get("G1", {})
    current_boundary = gate_registry.get("current_boundary", {})
    gate_execution_boundary = gate_registry.get("execution_boundary", {})
    if manifest.get("status") == "G1_REVALIDATION_IN_PROGRESS":
        if (
            gate_registry.get("status")
            != "AD12A_IMPLEMENTED_G1_REVALIDATION_IN_PROGRESS"
            or gate_registry.get("runtime_allowed") is not True
            or g0_science.get("status") != "PASSED_AD12A"
            or g1.get("status") != "REVALIDATION_IN_PROGRESS"
            or current_boundary.get("C03_C06_status")
            != "AD12A_IMPLEMENTED_REVALIDATION_IN_PROGRESS"
            or current_boundary.get("method_identified_comparison_allowed") is not False
        ):
            reasons.append("gate_registry.yaml: V2 G1-pending lifecycle is inconsistent")
        for field in ("event_queue_allowed", "plant_allowed", "measurement_allowed", "metric_runner_allowed"):
            if gate_execution_boundary.get(field) is not True:
                reasons.append("gate_registry.yaml: V2 method-free validation capability is missing")
        for field in ("method_allowed", "training_allowed", "API_allowed", "pilot_shadow_precision_locked_allowed"):
            if gate_execution_boundary.get(field) is not False:
                reasons.append("gate_registry.yaml: V2 exposes a forbidden post-G1 capability")
    if manifest.get("status") == "FROZEN":
        common_lifecycle_is_valid = (
            gate_registry.get("runtime_allowed") is True
            and g0_science.get("status") == "PASSED_AD12A"
            and g1.get("status") == "PASSED"
            and current_boundary.get("C03_C06_status") == "AD12A_IMPLEMENTED_G1_PASSED"
            and current_boundary.get("method_identified_comparison_allowed") is False
        )
        c07_status = current_boundary.get("C07_status")
        if c07_status == "IN_PROGRESS_SYNTHETIC_DIAGNOSTICS_ONLY":
            if (
                not common_lifecycle_is_valid
                or gate_registry.get("status") != "C07_IN_PROGRESS_G2A_NOT_PASSED"
                or gate_registry.get("gates", {}).get("G2_A", {}).get("status") != "NOT_PASSED"
                or gate_registry.get("gates", {}).get("G2", {}).get("status")
                != "NOT_STARTED_C07_BLOCKED"
                or current_boundary.get("completed_through_step") != "C06"
                or current_boundary.get("C08_status")
                != "CONSTRUCTED_DIAGNOSTICS_ONLY_NOT_FORMALLY_STARTED"
                or current_boundary.get("blocker")
                != "C07_REAL_MODEL_AND_BASELINES_INCOMPLETE_G2A_NOT_PASSED"
                or current_boundary.get("hard_stop_before_step") != "C08"
            ):
                reasons.append("gate_registry.yaml: C07/G2-A pending lifecycle is inconsistent")
        elif c07_status == "G2A_PASSED_REAL_MODEL_BASELINES_CORRECTNESS":
            c07_only_lifecycle = (
                common_lifecycle_is_valid
                and gate_registry.get("status") == "C07_COMPLETE_G2A_PASSED_C08_HARD_STOP"
                and gate_registry.get("gates", {}).get("G2_A", {}).get("status") == "PASSED"
                and gate_registry.get("gates", {}).get("G2", {}).get("status") == "NOT_STARTED"
                and gate_registry.get("gates", {}).get("G2_THROUGH_G5", {}).get("status")
                == "NOT_STARTED_C08_HARD_STOP"
                and current_boundary.get("completed_through_step") == "C07"
                and current_boundary.get("C08_status")
                == "CONSTRUCTED_DIAGNOSTICS_ONLY_NOT_FORMALLY_STARTED"
                and current_boundary.get("blocker") == "FORMAL_C08_NOT_STARTED"
                and current_boundary.get("hard_stop_before_step") == "C08"
            )
            c13_lifecycle = (
                common_lifecycle_is_valid
                and gate_registry.get("status") == "C13_STATS_READINESS_PASSED_C14_HARD_STOP"
                and gate_registry.get("gates", {}).get("G2_A", {}).get("status") == "PASSED"
                and gate_registry.get("gates", {}).get("G2", {}).get("status") == "PASSED"
                and gate_registry.get("gates", {}).get("G2_THROUGH_G5", {}).get("status")
                == "C13_PASSED_C14_NOT_STARTED"
                and gate_registry.get("gates", {}).get("G3_G4", {}).get("status") == "PASSED"
                and gate_registry.get("gates", {}).get("G5_P", {}).get("status") == "PASSED"
                and gate_registry.get("gates", {}).get("BASELINE_QUALIFICATION", {}).get("status")
                == "PASSED"
                and gate_registry.get("gates", {}).get("STATS_READINESS", {}).get("status")
                == "PASSED"
                and current_boundary.get("completed_through_step") == "C13"
                and current_boundary.get("C08_status") == "G2_PASSED_CONSTRUCTED_MECHANISM"
                and current_boundary.get("C09_status") == "G3_G4_PASSED_DETECTOR_CALIBRATION"
                and current_boundary.get("C10_C11_status") == "G5P_PASSED_PROVIDER_PROPAGATION_NO_API"
                and current_boundary.get("C12_status")
                == "REAL_RL_TRAINING_COMPLETE_AUDITED_NO_PERFORMANCE_CLAIM"
                and current_boundary.get("C13_status") == "STATS_READINESS_SYNTHETIC_PASSED"
                and current_boundary.get("blocker") == "C14_NOT_STARTED"
                and current_boundary.get("hard_stop_before_step") == "C14"
            )
            if not c07_only_lifecycle and not c13_lifecycle:
                reasons.append("gate_registry.yaml: C07/G2-A passed lifecycle is inconsistent")
        elif (
            not common_lifecycle_is_valid
            or gate_registry.get("status") != "C08_RMPC_RISKGATE_BUDGET_PASSED"
            or gate_registry.get("gates", {}).get("G2_A", {}).get("status") != "PASSED"
            or gate_registry.get("gates", {}).get("G2", {}).get("status") != "PASSED"
            or c07_status != "G2A_PASSED_METHOD_BLIND_PREFLIGHT"
            or current_boundary.get("C08_status") != "G2_PASSED_CONSTRUCTED_MECHANISM"
            or current_boundary.get("blocker") not in (None, "NONE")
            or current_boundary.get("hard_stop_before_step") != "C09"
        ):
            reasons.append("gate_registry.yaml: C08/G2 lifecycle is inconsistent")
        for field in ("event_queue_allowed", "plant_allowed", "measurement_allowed", "metric_runner_allowed"):
            if gate_execution_boundary.get(field) is not True:
                reasons.append("gate_registry.yaml: V2 frozen method-free capability is missing")
        for field in ("method_allowed", "training_allowed", "API_allowed", "pilot_shadow_precision_locked_allowed"):
            if gate_execution_boundary.get(field) is not False:
                reasons.append("gate_registry.yaml: V2 frozen state exposes a forbidden execution capability")
    if g1.get("required_artifacts") != list(_G1_REPORTS):
        reasons.append("gate_registry.yaml: G1 required-artifact registry mismatch")
    report_statuses = g1.get("artifact_statuses")
    if not isinstance(report_statuses, Mapping) or set(report_statuses) != set(_G1_REPORTS):
        reasons.append("gate_registry.yaml: G1 report statuses are incomplete")
    else:
        allowed_status = (
            "REVALIDATION_IN_PROGRESS"
            if manifest.get("status") != "FROZEN"
            else "PASSED"
        )
        if any(report_statuses[name] != allowed_status for name in _G1_REPORTS):
            reasons.append("gate_registry.yaml: G1 report status contradicts protocol lifecycle")
    for report_name, locator in _G1_REPORTS.items():
        report_path = project_root / locator
        if not report_path.is_file():
            reasons.append(f"G1 evidence report missing: {locator}")
            continue
        report_text = report_path.read_text(encoding="utf-8")
        expected_marker = (
            "STATUS: REVALIDATION_IN_PROGRESS"
            if manifest.get("status") != "FROZEN"
            else "STATUS: PASSED"
        )
        if expected_marker not in report_text or f"REPORT_ID: {report_name}" not in report_text:
            reasons.append(f"G1 evidence report lifecycle mismatch: {locator}")
    for artifact in artifacts:
        locator = artifact.get("locator") if isinstance(artifact, Mapping) else None
        expected = artifact.get("sha256") if isinstance(artifact, Mapping) else None
        if not _safe_locator(locator):
            reasons.append("protocol generation candidate contains an unsafe locator")
            continue
        path = project_root / locator
        if not path.is_file():
            reasons.append(f"protocol generation candidate artifact missing: {locator}")
        elif not isinstance(expected, str) or len(expected) != 64:
            reasons.append(f"protocol generation candidate hash is invalid: {locator}")
        elif _sha256(path) != expected:
            reasons.append(f"protocol generation candidate hash mismatch: {locator}")

    return ProtocolBundleValidationReport(passed=not reasons, reasons=tuple(reasons))
