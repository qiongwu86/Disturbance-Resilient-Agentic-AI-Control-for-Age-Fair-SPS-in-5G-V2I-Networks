"""Fail-closed audit for the corrected C14.1 offline-cache protocol generation."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import yaml

PROTOCOL_GENERATION = "EXP09_C14_1_OFFLINE_CACHE_V2_20260729"
ARMS = ("REFERENCE", "EVENT")
METHODS = ("Full", "Plain_LLM")
PHASE_A_CASE_COUNT = 192
PHASE_A_LEDGER_SCHEMA_VERSION = "exp09-c14-1-phase-a-rematerialization-ledger-v2"
PHASE_A_LEDGER_ROW_SCHEMA_VERSION = (
    "exp09-c14-1-phase-a-rematerialization-ledger-row-v2"
)

MANIFEST_LOCATOR = (
    "protocol/c14/c14_1_protocol_generation_manifest.FROZEN_20260729.json"
)
OLD_PHASE_A_LOCATOR = "artifacts/c14_1_offline_cache_phase_a_frontier"
V2_PHASE_A_LOCATOR = "artifacts/c14_1_offline_cache_phase_a_frontier_v2"
PHASE_A_PLAN_LOCATOR = (
    "protocol/c14/c14_1_phase_a_rematerialization_plan.CANDIDATE_20260729.json"
)
PHASE_A_LEDGER_LOCATOR = (
    "protocol/c14/c14_1_phase_a_rematerialization_ledger.CANDIDATE_20260729.json"
)


def validate_c14_protocol_generation(project_root: Path) -> dict[str, Any]:
    root = project_root.resolve()
    reasons: list[str] = []
    manifest = _json(root / MANIFEST_LOCATOR)
    if manifest.get("protocol_generation") != PROTOCOL_GENERATION:
        reasons.append("PROTOCOL_GENERATION_MISMATCH")
    if manifest.get("artifact_status") != (
        "PROTOCOL_GENERATION_FROZEN_PHASE_A_REMATERIALIZATION_NOT_AUTHORIZED"
    ):
        reasons.append("PROTOCOL_GENERATION_STATUS_MISMATCH")
    _audit_bindings(root, manifest.get("bindings"), reasons)

    config = _json(
        root / "protocol/c14/method_config.C14_1_OFFLINE_CACHE_V2_20260729.json"
    )
    provider = _json(
        root / "protocol/c14/provider_config.C14_1_OFFLINE_CACHE_V2_20260729.json"
    )
    lifecycle = _json(
        root
        / "protocol/c14/supervisor_lifecycle.C14_1_OFFLINE_CACHE_V2_20260729.json"
    )
    full = _json(root / "protocol/c14/full_protocol.C14_1_OFFLINE_CACHE_V2_20260729.json")
    plain = _json(
        root / "protocol/c14/plain_llm_protocol.C14_1_OFFLINE_CACHE_V2_20260729.json"
    )
    if any(
        document.get("protocol_generation") != PROTOCOL_GENERATION
        for document in (config, provider, lifecycle, full, plain)
    ):
        reasons.append("PROTOCOL_DOCUMENT_GENERATION_MISMATCH")

    _validate_provider(provider, reasons)
    _validate_prompts(full, plain, reasons)
    _validate_namespaces(root, config, reasons)
    _validate_lifecycle(lifecycle, reasons)
    _validate_authority_records(root, lifecycle, reasons)
    _validate_phase_a_candidate(root, reasons)

    terminal = manifest.get("terminal_state", {})
    expected_terminal = {
        "real_frontier_cases_read_or_executed": 0,
        "v2_frontier_cases_materialized": 0,
        "formal_c14_1_method_cases_executed": 0,
        "cache_qualified": False,
        "c14_1_execution_authorized": False,
        "api_calls": 0,
        "provider_calls": 0,
        "llm_tokens": 0,
        "network_attempts": 0,
        "training_capability": "DISABLED",
        "c14_2_executed": False,
        "shadow_executed": False,
        "precision_executed": False,
        "locked_test_executed": False,
        "performance_statistics_generated": False,
    }
    if terminal != expected_terminal:
        reasons.append("TERMINAL_STATE_MISMATCH")
    if manifest.get("self_authorization_forbidden") is not True:
        reasons.append("SELF_AUTHORIZATION_NOT_FORBIDDEN")
    if (root / V2_PHASE_A_LOCATOR).exists():
        reasons.append("V2_PHASE_A_ARTIFACT_EXISTS_BEFORE_AUTHORIZATION")
    if not (root / OLD_PHASE_A_LOCATOR).is_dir():
        reasons.append("OLD_PHASE_A_EVIDENCE_MISSING")
    if (root / "artifacts/c14_1_design_validation").exists():
        reasons.append("FORMAL_C14_1_ARTIFACT_EXISTS")

    return {
        "schema_version": "exp09-c14-1-protocol-generation-audit-v1",
        "passed": not reasons,
        "protocol_generation": PROTOCOL_GENERATION,
        "protocol_generation_frozen": not reasons,
        "old_phase_a_retained": (root / OLD_PHASE_A_LOCATOR).is_dir(),
        "v2_phase_a_materialized": False,
        "cache_qualified": False,
        "c14_1_execution_authorized": False,
        "api_provider_llm_network_calls": 0,
        "next_action": "OBTAIN_V2_PHASE_A_FIRST_FRONTIER_REMATERIALIZATION_AUTHORIZATION",
        "reasons": reasons,
    }


def _validate_phase_a_candidate(root: Path, reasons: list[str]) -> None:
    plan_path = root / PHASE_A_PLAN_LOCATOR
    ledger_path = root / PHASE_A_LEDGER_LOCATOR
    if not plan_path.is_file() or not ledger_path.is_file():
        reasons.append("V2_PHASE_A_CANDIDATE_MISSING")
        return
    try:
        stored_plan = _json(plan_path)
        plan = _rebuild_phase_a_plan(root)
        if stored_plan != _compact_phase_a_plan(plan):
            reasons.append("V2_PHASE_A_PLAN_NOT_REPRODUCIBLE")
        stored_ledger = _json(ledger_path)
        ledger = _rebuild_zero_use_ledger(plan)
        if stored_ledger != _compact_zero_use_ledger(ledger):
            reasons.append("V2_PHASE_A_LEDGER_MISMATCH")
            return
        rows = ledger["rows"]
        if any(
            row.get("schema_version") != PHASE_A_LEDGER_ROW_SCHEMA_VERSION
            or row.get("status") != "PLANNED"
            or row.get("attempt_ordinal") != 0
            or row.get("resume_of") is not None
            or row.get("started_at") is not None
            or row.get("ended_at") is not None
            or row.get("request_hash") is not None
            or row.get("inventory_sha256_at_miss") is not None
            or row.get("error_code") is not None
            or row.get("retained_reason") is not None
            or any(
                row.get(field) != 0
                for field in (
                    "decision_attempts",
                    "model_transitions",
                    "pre_miss_controller_commitments",
                    "cache_lookup_attempts",
                    "cache_misses",
                    "post_miss_controller_commitments",
                    "post_miss_plant_actions",
                    "api_calls",
                    "provider_calls",
                    "llm_tokens",
                    "network_attempts",
                )
            )
            for row in rows
        ):
            reasons.append("V2_PHASE_A_LEDGER_HAS_RUNTIME_EVIDENCE")
    except (OSError, ValueError, TypeError, KeyError) as exc:
        reasons.append(f"V2_PHASE_A_CANDIDATE_INVALID:{type(exc).__name__}")


def _rebuild_phase_a_plan(root: Path) -> dict[str, Any]:
    source_locator = (
        "protocol/c14/c14_1_method_case_topology.FROZEN_PREFLIGHT_20260729.json"
    )
    roots_locator = "protocol/c14/c14_1_design_roots.FROZEN_20260728.json"
    method_config_locator = "protocol/c14/method_config.C14_1_OFFLINE_CACHE_V2_20260729.json"
    provider_locator = "protocol/c14/provider_config.C14_1_OFFLINE_CACHE_V2_20260729.json"
    lifecycle_locator = (
        "protocol/c14/supervisor_lifecycle.C14_1_OFFLINE_CACHE_V2_20260729.json"
    )
    roots = _json(root / roots_locator)["roots"]
    if len(roots) != 48 or len(set(roots)) != 48:
        raise ValueError("v2 Phase A root set mismatch")
    config = _json(root / method_config_locator)
    cases = [
        {
            "ordinal": ordinal,
            "case_id": f"{root_id}__{arm}__{method_id}__fixed",
            "root_case_id": root_id,
            "arm": arm,
            "scenario": "nominal_fixed" if arm == "REFERENCE" else "influx_event",
            "method_id": method_id,
            "variant_id": "fixed",
            "namespace": config["methods"][method_id]["arm_namespaces"][arm],
        }
        for ordinal, (root_id, arm, method_id) in enumerate(
            (root_id, arm, method_id)
            for root_id in roots
            for arm in ARMS
            for method_id in METHODS
        )
    ]
    if len(cases) != PHASE_A_CASE_COUNT or len({case["case_id"] for case in cases}) != len(
        cases
    ):
        raise ValueError("v2 Phase A case topology mismatch")
    caps = _phase_a_budget_caps()
    return {
        "schema_version": "exp09-c14-1-phase-a-rematerialization-plan-v2",
        "artifact_status": "CANDIDATE_NOT_AUTHORIZED_NOT_EXECUTED",
        "protocol_generation": PROTOCOL_GENERATION,
        "execution_authorized": False,
        "automatic_continuation": False,
        "topology": {
            "source_topology_locator": source_locator,
            "source_topology_sha256": _sha(root / source_locator),
            "source_protocol_generation": "EXP09_G0_AD12A_20260726_V2",
            "design_roots_locator": roots_locator,
            "design_roots_sha256": _sha(root / roots_locator),
            "root_count": 48,
            "frontier_case_count": PHASE_A_CASE_COUNT,
            "arms": list(ARMS),
            "methods": list(METHODS),
            "other_method_count": 0,
            "cases_sha256": _canonical_sha(cases),
            "cases": cases,
        },
        "bindings": {
            "method_config": _binding(root, method_config_locator),
            "provider_config": _binding(root, provider_locator),
            "supervisor_lifecycle": _binding(root, lifecycle_locator),
            "full_protocol": _binding(
                root, config["methods"]["Full"]["prompt_protocol_locator"]
            ),
            "plain_llm_protocol": _binding(
                root, config["methods"]["Plain_LLM"]["prompt_protocol_locator"]
            ),
            "implementation": _binding(root, "src/exp09/evaluation/c14_protocol_generation.py"),
        },
        "causal_prefix_contract": {
            "full_debounce_requires_pre_miss_progress": True,
            "pre_miss_controller_commitments_allowed": True,
            "pre_miss_controller_commitments_hard_cap_per_case": 23,
            "cache_lookup_requires_prior_materialization": True,
            "stop_at_first_cache_miss": True,
            "post_miss_controller_commitments": 0,
            "post_miss_plant_actions": 0,
            "case_without_request_by_run_end": "FAIL_CLOSED_NO_FRONTIER",
        },
        "budget_caps": caps,
        "budget_usage": {field: 0 for field in caps},
        "ledger_locator": PHASE_A_LEDGER_LOCATOR,
        "v2_output_locator": V2_PHASE_A_LOCATOR,
        "old_phase_a_disposition": (
            "RETAIN_UNCHANGED_AS_SUPERSEDED_PROTOCOL_CAUSAL_FRONTIER_EVIDENCE"
        ),
        "forbidden": [
            "network",
            "api",
            "provider",
            "llm",
            "key_access",
            "training",
            "formal_c14_1_method_case",
            "performance_statistics",
            "c14_2",
            "shadow",
            "precision",
            "locked_test",
        ],
        "self_authorization_forbidden": True,
    }


def _rebuild_zero_use_ledger(plan: dict[str, Any]) -> dict[str, Any]:
    rows = [
        {
            "schema_version": PHASE_A_LEDGER_ROW_SCHEMA_VERSION,
            "run_id": f"phase-a-v2__{case['case_id']}__attempt000",
            "case_id": case["case_id"],
            "source_ordinal": case["ordinal"],
            "root_case_id": case["root_case_id"],
            "arm": case["arm"],
            "scenario": case["scenario"],
            "method_id": case["method_id"],
            "variant_id": case["variant_id"],
            "namespace": case["namespace"],
            "attempt_ordinal": 0,
            "resume_of": None,
            "status": "PLANNED",
            "started_at": None,
            "ended_at": None,
            "decision_attempts": 0,
            "model_transitions": 0,
            "pre_miss_controller_commitments": 0,
            "cache_lookup_attempts": 0,
            "cache_misses": 0,
            "post_miss_controller_commitments": 0,
            "post_miss_plant_actions": 0,
            "api_calls": 0,
            "provider_calls": 0,
            "llm_tokens": 0,
            "network_attempts": 0,
            "request_hash": None,
            "inventory_sha256_at_miss": None,
            "error_code": None,
            "retained_reason": None,
        }
        for case in plan["topology"]["cases"]
    ]
    return {
        "schema_version": PHASE_A_LEDGER_SCHEMA_VERSION,
        "artifact_status": "CANDIDATE_PLAN_ONLY_NOT_AUTHORIZED_NOT_EXECUTED",
        "protocol_generation": PROTOCOL_GENERATION,
        "execution_authorized": False,
        "plan_sha256": _canonical_sha(plan),
        "planned_frontier_cases": PHASE_A_CASE_COUNT,
        "row_count": len(rows),
        "budget_caps": plan["budget_caps"],
        "budget_usage": {field: 0 for field in plan["budget_caps"]},
        "rows_sha256": _canonical_sha(rows),
        "rows": rows,
        "resume_rule": (
            "append attempt only after FAILED_RETAINED or ABORTED_RETAINED; "
            "preserve prior row and bind resume_of"
        ),
        "abort_rule": (
            "retain failure, causal-prefix counters, hashes, and reason; never skip a case"
        ),
        "self_authorization_forbidden": True,
    }


def _compact_phase_a_plan(plan: dict[str, Any]) -> dict[str, Any]:
    compact = json.loads(json.dumps(plan))
    compact["topology"].pop("cases")
    compact["topology"]["case_materialization"] = (
        "design_roots order x REFERENCE/EVENT x Full/Plain_LLM; contiguous ordinals"
    )
    return compact


def _compact_zero_use_ledger(ledger: dict[str, Any]) -> dict[str, Any]:
    compact = json.loads(json.dumps(ledger))
    compact.pop("rows")
    compact["row_materialization"] = (
        "derive 192 PLANNED attempt000 rows from the bound Phase A plan before execution"
    )
    return compact


def _phase_a_budget_caps() -> dict[str, int]:
    return {
        "frontier_cases": 192,
        "decision_attempts": 4_608,
        "model_transitions": 165_888_000,
        "pre_miss_controller_commitments": 4_416,
        "cache_lookup_attempts": 192,
        "cache_misses": 192,
        "post_miss_controller_commitments": 0,
        "post_miss_plant_actions": 0,
        "concurrency": 1,
        "api_calls": 0,
        "provider_calls": 0,
        "llm_tokens": 0,
        "network_attempts": 0,
    }


def _validate_provider(provider: dict[str, Any], reasons: list[str]) -> None:
    expected = {
        "provider_name": "openai",
        "model_identifier": "gpt-4o-mini",
        "model_revision": "gpt-4o-mini-2024-07-18",
        "temperature_ppm": 0,
        "seed_supported": False,
        "max_input_tokens": 8192,
        "max_output_tokens": 512,
        "timeout_ms": 30000,
        "retry_budget": 0,
        "tool_calls_allowed": False,
        "provider_memory_allowed": False,
    }
    for field, expected_value in expected.items():
        if provider.get(field) != expected_value:
            reasons.append(f"PROVIDER_CONFIG_MISMATCH_{field.upper()}")
    permissions = provider.get("execution_permissions", {})
    if set(permissions) != {"network", "api", "provider", "llm", "key_access"} or any(
        permissions.values()
    ):
        reasons.append("PROVIDER_EXECUTION_PERMISSION_EXPOSED")


def _validate_prompts(
    full: dict[str, Any], plain: dict[str, Any], reasons: list[str]
) -> None:
    for method_id, protocol in (("Full", full), ("Plain_LLM", plain)):
        if not protocol.get("system_prompt") or not isinstance(
            protocol.get("user_prompt_template"), dict
        ):
            reasons.append(f"{method_id.upper()}_PROMPT_INCOMPLETE")
        if protocol.get("request_contract", {}).get(
            "cache_envelope_visible_to_model"
        ) is not False:
            reasons.append(f"{method_id.upper()}_CACHE_ENVELOPE_MODEL_VISIBLE")
        forbidden = set(protocol.get("forbidden_model_fields", ()))
        if not {"arm", "scenario", "root_case_id", "method_id"}.issubset(forbidden):
            reasons.append(f"{method_id.upper()}_FORBIDDEN_MODEL_FIELDS_INCOMPLETE")
    required = set(full.get("user_prompt_template", {}).get("required_fields", ()))
    if required != {
        "causal_cutoff_us",
        "based_on_sequence",
        "program_state",
        "eligible_proposals",
        "evidence",
        "evidence_hash",
        "remaining_budget",
    }:
        reasons.append("FULL_SUPERVISOR_INPUT_FIELDS_MISMATCH")
    trigger = full.get("trigger_and_activation", {})
    if trigger != {
        "request_when_untriggered": False,
        "request_when_only_hold_is_eligible": False,
        "eligible_proposals_use_real_trigger_state": True,
        "activate_at_next_legal_control_opportunity": True,
        "recompute_eligibility_before_activation": True,
    }:
        reasons.append("FULL_TRIGGER_AND_ACTIVATION_MISMATCH")


def _validate_namespaces(
    root: Path, config: dict[str, Any], reasons: list[str]
) -> None:
    implementation = config.get("implementation_locator")
    expected_implementation_sha = config.get("implementation_sha256")
    if not isinstance(implementation, str) or not isinstance(
        expected_implementation_sha, str
    ):
        reasons.append("METHOD_CONFIG_IMPLEMENTATION_BINDING_MISSING")
    else:
        implementation_path = (root / implementation).resolve()
        try:
            implementation_path.relative_to(root)
        except ValueError:
            reasons.append("METHOD_CONFIG_IMPLEMENTATION_BINDING_ESCAPES_ROOT")
        else:
            if (
                not implementation_path.is_file()
                or _sha(implementation_path) != expected_implementation_sha
            ):
                reasons.append("METHOD_CONFIG_IMPLEMENTATION_BINDING_MISMATCH")
    namespaces: list[str] = []
    methods = config.get("methods", {})
    if set(methods) != set(METHODS):
        reasons.append("METHOD_CONFIG_SCOPE_MISMATCH")
        return
    for method_id in METHODS:
        arm_namespaces = methods[method_id].get("arm_namespaces", {})
        if set(arm_namespaces) != set(ARMS):
            reasons.append(f"{method_id.upper()}_ARM_NAMESPACE_SCOPE_MISMATCH")
            continue
        reference = arm_namespaces["REFERENCE"]
        event = arm_namespaces["EVENT"]
        if reference == event or not reference.endswith("--reference") or not event.endswith(
            "--event"
        ):
            reasons.append(f"{method_id.upper()}_ARM_NAMESPACE_NOT_ISOLATED")
        namespaces.extend((reference, event))
    if len(namespaces) != len(set(namespaces)):
        reasons.append("CROSS_METHOD_OR_ARM_NAMESPACE_COLLISION")


def _validate_lifecycle(lifecycle: dict[str, Any], reasons: list[str]) -> None:
    expected = {
        "debounce_us": 100000,
        "rate_limit_us": 100000,
        "request_expiry_us": 3000000,
        "response_age_limit_us": 3000000,
        "program_state_ttl_us": 3000000,
        "maximum_inflight": 1,
        "provider_timeout_ms": 30000,
        "activation": "NEXT_LEGAL_CONTROL_OPPORTUNITY_ONLY",
        "fast_path_nonblocking": True,
        "deployment_or_real_time_claim_allowed": False,
    }
    for field, expected_value in expected.items():
        if lifecycle.get(field) != expected_value:
            reasons.append(f"SUPERVISOR_LIFECYCLE_MISMATCH_{field.upper()}")
    if lifecycle.get("retry_policy", {}).get("retry_budget") != 0:
        reasons.append("SUPERVISOR_RETRY_BUDGET_NONZERO")
    if lifecycle.get("failure_fallback", {}).get("network_fallback") is not False:
        reasons.append("SUPERVISOR_NETWORK_FALLBACK_ENABLED")


def _validate_authority_records(
    root: Path, lifecycle: dict[str, Any], reasons: list[str]
) -> None:
    open_decisions = yaml.safe_load(
        (root / "protocol/open_decisions.yaml").read_text(encoding="utf-8")
    )
    o01 = next(item for item in open_decisions["decisions"] if item["id"] == "O-01")
    supervisor = o01["subdecisions"]["supervisor_lifecycle_profile"]
    deployment = o01["subdecisions"]["deployment_provider_profile"]
    if supervisor.get("status") != "FROZEN" or deployment.get("status") != "UNRESOLVED":
        reasons.append("O01_LIFECYCLE_OR_DEPLOYMENT_BOUNDARY_MISMATCH")
    latency = yaml.safe_load(
        (root / "protocol/latency_protocol.yaml").read_text(encoding="utf-8")
    )
    frozen = latency.get("supervisor_lifecycle", {})
    if frozen.get("protocol_generation") != PROTOCOL_GENERATION:
        reasons.append("LATENCY_PROTOCOL_GENERATION_MISMATCH")
    if frozen.get("debounce_us") != lifecycle.get("debounce_us") or frozen.get(
        "request_expiry_us"
    ) != lifecycle.get("request_expiry_us"):
        reasons.append("LATENCY_LIFECYCLE_VALUE_MISMATCH")


def _audit_bindings(root: Path, bindings: Any, reasons: list[str]) -> None:
    if not isinstance(bindings, list) or not bindings:
        reasons.append("MANIFEST_BINDINGS_MISSING")
        return
    locators = [binding.get("locator") for binding in bindings if isinstance(binding, dict)]
    if len(locators) != len(bindings) or len(locators) != len(set(locators)):
        reasons.append("MANIFEST_BINDINGS_DUPLICATE_OR_MALFORMED")
        return
    for binding in bindings:
        path = (root / binding["locator"]).resolve()
        try:
            path.relative_to(root)
        except ValueError:
            reasons.append(f"MANIFEST_BINDING_ESCAPES_ROOT_{binding['locator']}")
            continue
        if not path.is_file() or _sha(path) != binding.get("sha256"):
            reasons.append(f"MANIFEST_BINDING_MISMATCH_{binding['locator']}")


def _json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def _canonical_sha(value: Any) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest().upper()


def _binding(root: Path, locator: str) -> dict[str, str]:
    path = (root / locator).resolve()
    path.relative_to(root)
    if not path.is_file():
        raise ValueError(f"bound Phase A artifact is missing: {locator}")
    return {"locator": locator, "sha256": _sha(path)}
