"""Fail-closed validation for the conditionally authorized C14.1 preflight."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from typing import Any

import yaml

METHODS = (
    "Full",
    "RMPC_SameEvaluator",
    "Rule_SameStack",
    "TunedNonLLM_SameStack",
    "Plain_LLM",
    "DQN",
    "DQN_Strong",
    "GNN_DDQN",
    "KEEP_sanity",
    "AoI_aware_heuristic",
    "Greedy_1",
    "Nominal_MPC",
)
FATAL_CODES = {
    "C14_PREFLIGHT_OFFLINE_CACHE_ABSENT",
    "C14_PREFLIGHT_NON_RL_CONFIG_UNRESOLVED",
    "C14_PREFLIGHT_RL_MAPPING_UNRESOLVED",
    "C14_PREFLIGHT_UNIFIED_RUNNER_INCOMPLETE",
}
GATE_SHA256 = "77F21E1FD88B8D74A45718E641F0AB2F2B4F3FDC47FD03F5AAF27C93CB301C84"


def _load_json(root: Path, locator: str) -> Any:
    return json.loads((root / locator).read_text(encoding="utf-8"))


def _sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def validate_c14_1_preflight_failure(project_root: Path) -> dict[str, Any]:
    """Prove that the authorized preflight failed before any method case ran."""

    root = project_root.resolve()
    reasons: list[str] = []
    locators = (
        "protocol/c14/c14_1_authorization_record_20260728.md",
        "protocol/c14/plain_llm_protocol.FROZEN_20260728.json",
        "protocol/c14/c14_1_non_rl_config_freeze_20260728.json",
        "protocol/c14/c14_1_rl_checkpoint_mapping_20260728.json",
        "protocol/c14/c14_1_design_roots.FROZEN_20260728.json",
        "protocol/c14/c14_1_offline_cache_inventory_20260728.json",
        "protocol/c14/c14_1_preflight_report_20260728.json",
        "protocol/c14/c14_1_execution_gate_20260728.json",
    )
    for locator in locators:
        if not (root / locator).is_file():
            reasons.append(f"missing C14.1 preflight artifact: {locator}")
    if reasons:
        return {"passed": False, "reasons": tuple(reasons)}

    try:
        env = os.environ.copy()
        env["PYTHONPATH"] = str(root / "src")
        probe = subprocess.run(
            [
                sys.executable,
                "-c",
                "from pathlib import Path; import json; "
                "from exp09.baselines.audit_real_training import audit_c12_closed_state; "
                "print(json.dumps(audit_c12_closed_state(Path.cwd())))",
            ],
            cwd=root,
            env=env,
            check=True,
            capture_output=True,
            text=True,
            timeout=300,
        )
        c12 = json.loads(probe.stdout)
        if c12.get("artifact_status") != (
            "PASS_C12_COMPLETE_TRAINING_DISABLED_C14_HARD_STOP"
        ):
            reasons.append("fresh C12 closed-state audit failed")
    except Exception as exc:
        reasons.append(f"fresh C12 closed-state audit failed: {exc}")

    historical_request = _load_json(
        root, "protocol/c14/c14_1_unified_authorization_package_20260728.json"
    )
    state = historical_request.get("authorization_state", {})
    if state.get("c14_1_execution_authorized") is not False:
        reasons.append("historical authorization request was mutated into an execution authority")
    if state.get("self_authorization_forbidden") is not True:
        reasons.append("historical authorization request can self-authorize")

    authorization_text = (root / locators[0]).read_text(encoding="utf-8")
    if "AUTHORIZED_CONDITIONAL_ON_PREFLIGHT" not in authorization_text:
        reasons.append("authorization record does not preserve its conditional status")
    if "cannot enable execution by itself" not in authorization_text:
        reasons.append("authorization record lacks the no-self-enable boundary")

    prompt = _load_json(root, locators[1])
    if prompt.get("execution_qualified") is not False:
        reasons.append("Plain LLM protocol incorrectly claims execution qualification")
    if prompt.get("provider_mode") != "OFFLINE_REPLAY_ONLY":
        reasons.append("Plain LLM is not offline-replay-only")
    if prompt.get("network_possible") is not False:
        reasons.append("Plain LLM protocol permits network access")
    if prompt.get("api_calls") != 0 or prompt.get("llm_tokens") != 0:
        reasons.append("Plain LLM protocol permits API or token consumption")
    input_fields = set(prompt.get("user_prompt_template", {}).get("observation", {}))
    forbidden_input_fields = {
        "scenario_id",
        "family_id",
        "arm",
        "shock_flag",
        "shock_label",
        "configured_onset_us",
        "future_onset_candidates_us",
        "plant_truth",
        "evaluation_truth",
        "method_identity",
        "test_ranking",
    }
    if input_fields & forbidden_input_fields:
        reasons.append("Plain LLM input exposes a forbidden field")
    required_output = prompt.get("required_output_schema", {})
    if required_output.get("chosen_action_id") != "must equal candidate_order[0]":
        reasons.append("Plain LLM candidate selection rule is not exact")
    if prompt.get("safety_filter", {}).get("network_fallback") is not False:
        reasons.append("Plain LLM safety filter permits network fallback")
    legacy = prompt.get("legacy_exp08_prompt", {})
    legacy_path = (root / legacy.get("locator", "")).resolve()
    if not legacy_path.is_file() or _sha(legacy_path) != legacy.get("sha256"):
        reasons.append("legacy EXP08 prompt rejection is not hash-bound")
    elif "shock_flag" not in legacy_path.read_text(encoding="utf-8"):
        reasons.append("legacy prompt leakage finding is not reproducible")

    cache = _load_json(root, locators[5])
    for key in ("plain_llm_cache", "full_cache"):
        if cache.get(key, {}).get("entry_count") != 0:
            reasons.append(f"{key} inventory no longer proves zero cache entries")
    if cache.get("network_fallback") is not False:
        reasons.append("cache inventory permits a network fallback")

    non_rl = _load_json(root, locators[2])
    entries = non_rl.get("methods", [])
    if non_rl.get("method_count") != 9 or len(entries) != 9:
        reasons.append("non-RL inventory does not contain exactly nine methods")
    if non_rl.get("execution_qualified") is not False:
        reasons.append("unresolved non-RL inventory claims execution qualification")
    unresolved = {
        item.get("method_id")
        for item in entries
        if "UNRESOLVED" in str(item.get("config_status"))
    }
    expected_unresolved = {
        "Full",
        "RMPC_SameEvaluator",
        "Rule_SameStack",
        "TunedNonLLM_SameStack",
    }
    if unresolved != expected_unresolved:
        reasons.append("non-RL unresolved method set drifted")

    mapping = _load_json(root, locators[3])
    if mapping.get("artifact_status") != "UNRESOLVED_FAIL_CLOSED":
        reasons.append("RL checkpoint mapping is not fail-closed")
    registry_path = root / mapping.get("checkpoint_registry_locator", "")
    if not registry_path.is_file() or _sha(registry_path) != mapping.get(
        "checkpoint_registry_sha256"
    ):
        reasons.append("RL checkpoint mapping registry binding mismatch")
    if mapping.get("forbidden_mapping") != "REFERENCE_TO_simple_AND_EVENT_TO_complex":
        reasons.append("arm-revealing RL mapping is not explicitly forbidden")

    roots = _load_json(root, locators[4])
    design_roots = roots.get("roots", [])
    if roots.get("root_count") != 48 or len(design_roots) != 48:
        reasons.append("C14.1 root manifest does not contain 48 roots")
    if len(set(design_roots)) != 48:
        reasons.append("C14.1 root manifest contains duplicates")
    c12_roots = _load_json(root, roots.get("c12_validation_roots_locator", ""))
    prior = set(c12_roots.get("simple", ())) | set(c12_roots.get("complex", ()))
    if set(design_roots) & prior:
        reasons.append("C14.1 roots overlap C12 validation roots")

    report = _load_json(root, locators[6])
    if report.get("artifact_status") != "FAIL_CLOSED_EXECUTION_NOT_STARTED":
        reasons.append("preflight report does not preserve the failed hard stop")
    if report.get("preflight_passed") is not False:
        reasons.append("failed preflight is marked passed")
    if report.get("c14_1_execution_started") is not False:
        reasons.append("preflight report claims C14.1 execution started")
    if report.get("executed_method_cases") != 0:
        reasons.append("preflight report records method-case execution")
    consumed = report.get("budget_consumed", {})
    if any(value != 0 for value in consumed.values()):
        reasons.append("preflight report records nonzero method-execution budget")
    if set(report.get("fatal_error_codes", ())) != FATAL_CODES:
        reasons.append("fatal preflight error set drifted")

    gate = _load_json(root, locators[7])
    permission_fields = (
        "c14_1_execution_enabled",
        "method_execution_allowed",
        "training_allowed",
        "api_allowed",
        "provider_calls_allowed",
        "llm_calls_allowed",
        "shadow_allowed",
        "precision_allowed",
        "locked_test_allowed",
        "performance_claim_allowed",
    )
    if any(gate.get(field) is not False for field in permission_fields):
        reasons.append("failed C14.1 gate contains an enabled permission")
    if gate.get("self_authorization_forbidden") is not True:
        reasons.append("failed C14.1 gate can self-authorize")

    historical_gate_path = root / "protocol/gate_registry.yaml"
    if _sha(historical_gate_path) != GATE_SHA256:
        reasons.append("historical C14 hard-stop gate drifted")
    else:
        historical_gate = yaml.safe_load(historical_gate_path.read_text(encoding="utf-8"))
        if historical_gate.get("execution_boundary", {}).get("method_allowed") is not False:
            reasons.append("historical gate permits method execution")

    execution_artifacts = root / "artifacts/c14_1_design_validation"
    if execution_artifacts.exists():
        reasons.append("C14.1 method execution artifact directory exists despite preflight failure")

    index_locator = "protocol/c14/c14_1_failed_preflight_evidence_index_20260728.json"
    index_path = root / index_locator
    if not index_path.is_file():
        reasons.append("failed-preflight evidence index is missing")
    else:
        index = _load_json(root, index_locator)
        if index.get("artifact_status") != "FAIL_CLOSED_EVIDENCE_FROZEN_C14_1_NOT_STARTED":
            reasons.append("failed-preflight evidence index status mismatch")
        for binding in index.get("artifacts", ()) + index.get("historical_bindings", ()):
            locator = binding.get("locator", "")
            path = root / locator
            if not path.is_file() or _sha(path) != binding.get("sha256"):
                reasons.append(f"failed-preflight evidence binding mismatch: {locator}")
        terminal = index.get("terminal_state", {})
        false_fields = (
            "preflight_passed",
            "c14_1_execution_started",
            "training_allowed",
            "c14_2_allowed",
            "shadow_allowed",
            "precision_allowed",
            "locked_test_allowed",
            "performance_claim_allowed",
        )
        if any(terminal.get(field) is not False for field in false_fields):
            reasons.append("failed-preflight evidence index contains an enabled terminal state")
        if terminal.get("executed_method_cases") != 0 or terminal.get(
            "api_provider_llm_calls"
        ) != 0:
            reasons.append("failed-preflight evidence index records forbidden execution")
        if index.get("self_authorization_forbidden") is not True:
            reasons.append("failed-preflight evidence index can self-authorize")

    return {
        "passed": not reasons,
        "preflight_passed": False,
        "execution_started": False,
        "fatal_error_codes": tuple(sorted(FATAL_CODES)),
        "reasons": tuple(reasons),
    }
