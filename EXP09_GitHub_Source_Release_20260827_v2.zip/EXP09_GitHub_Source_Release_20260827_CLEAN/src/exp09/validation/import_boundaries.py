"""AST-based import dependency checks for the EXP09 package."""

import ast
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class ImportViolation:
    source: str
    imported: str
    reason: str


@dataclass(frozen=True, slots=True)
class _ImportTarget:
    name: str
    parse_error: str | None


_LEGACY_PREFIXES = (
    "agentic_v2x_system",
    "agents",
    "env",
    "experiment08_true_agentic_planning",
)

_RULES: dict[str, frozenset[str]] = {
    "__root__": frozenset(),
    "contracts": frozenset({"contracts"}),
    "artifacts": frozenset({"artifacts", "contracts"}),
    "validation": frozenset({"validation"}),
    "plant": frozenset({"plant", "contracts"}),
    "measurement": frozenset({"measurement", "contracts", "artifacts"}),
    "model": frozenset({"model", "contracts"}),
    "control": frozenset({"control", "contracts", "model"}),
    "supervisor": frozenset({"supervisor", "contracts", "control", "model"}),
    "baselines": frozenset(
        {"baselines", "contracts", "control", "model", "supervisor", "evaluation"}
    ),
    "evaluation": frozenset(
        {
            "evaluation",
            "contracts",
            "artifacts",
            "plant",
            "measurement",
            "model",
            "control",
            "supervisor",
            "baselines",
        }
    ),
    "legacy_metrics": frozenset({"legacy_metrics", "contracts"}),
}

_TRUTH_FORBIDDEN_CONSUMERS = frozenset(
    {"measurement", "model", "control", "supervisor", "baselines"}
)


def _package_area(path: Path, src_root: Path) -> str | None:
    parts = path.relative_to(src_root).parts
    if len(parts) < 2 or parts[0] != "exp09":
        return None
    if len(parts) == 2 and parts[1] == "__init__.py":
        return "__root__"
    if len(parts) == 2:
        return Path(parts[1]).stem
    return parts[1]


def _resolve_relative(
    module: str | None, level: int, source: Path, src_root: Path
) -> str | None:
    if source.name == "__init__.py":
        package_parts = list(source.relative_to(src_root).parent.parts)
    else:
        package_parts = list(source.relative_to(src_root).with_suffix("").parts[:-1])
    if not package_parts or package_parts[0] != "exp09" or level > len(package_parts):
        return None
    keep = len(package_parts) - level + 1
    prefix = package_parts[:keep]
    if module:
        prefix.extend(module.split("."))
    return ".".join(prefix)


def _imports(path: Path, src_root: Path) -> tuple[_ImportTarget, ...]:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    found: list[_ImportTarget] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            found.extend(_ImportTarget(alias.name, None) for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            if node.level:
                base = _resolve_relative(node.module, node.level, path, src_root)
                if base is None:
                    relative_name = f"{'.' * node.level}{node.module or ''}"
                    found.append(
                        _ImportTarget(
                            relative_name,
                            "relative import escapes the EXP09 package root",
                        )
                    )
                    continue
            elif node.module:
                base = node.module
            else:
                found.append(_ImportTarget("<missing-module>", "import target is indeterminate"))
                continue
            for alias in node.names:
                if alias.name == "*":
                    found.append(
                        _ImportTarget(
                            f"{base}.*",
                            "wildcard import target cannot be bounded statically",
                        )
                    )
                else:
                    found.append(_ImportTarget(f"{base}.{alias.name}", None))
    return tuple(found)


def _is_module_or_child(imported: str, module: str) -> bool:
    return imported == module or imported.startswith(f"{module}.")


def lint_import_boundaries(src_root: Path) -> tuple[ImportViolation, ...]:
    violations: list[ImportViolation] = []
    for path in sorted((src_root / "exp09").rglob("*.py")):
        area = _package_area(path, src_root)
        if area is not None and area not in _RULES:
            violations.append(
                ImportViolation(str(path), area, "unknown EXP09 source package area is forbidden")
            )
        for target in _imports(path, src_root):
            imported = target.name
            if target.parse_error is not None:
                violations.append(ImportViolation(str(path), imported, target.parse_error))
                continue
            if any(_is_module_or_child(imported, prefix) for prefix in _LEGACY_PREFIXES):
                violations.append(ImportViolation(str(path), imported, "legacy direct import is forbidden"))
                continue
            if imported == "exp09":
                violations.append(
                    ImportViolation(str(path), imported, "bare EXP09 package import is forbidden")
                )
                continue
            if not imported.startswith("exp09."):
                continue
            imported_parts = imported.split(".")
            imported_area = imported_parts[1] if len(imported_parts) > 1 else None
            if imported_area not in _RULES:
                violations.append(ImportViolation(str(path), imported, "unknown EXP09 imported package area"))
                continue
            if area in _RULES and imported_area not in _RULES[area]:
                violations.append(ImportViolation(str(path), imported, "package dependency is forbidden"))
            if area in _TRUTH_FORBIDDEN_CONSUMERS and _is_module_or_child(
                imported, "exp09.contracts.evaluation_truth"
            ):
                violations.append(ImportViolation(str(path), imported, "evaluation truth is controller-inaccessible"))
    return tuple(violations)
