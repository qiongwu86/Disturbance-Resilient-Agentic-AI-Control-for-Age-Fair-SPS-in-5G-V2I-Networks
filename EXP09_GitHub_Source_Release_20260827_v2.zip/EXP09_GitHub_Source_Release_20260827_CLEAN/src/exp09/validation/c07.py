"""C07 G2-A artifact and implementation-boundary validation."""

from collections.abc import Mapping
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path, PurePosixPath
from typing import Any


@dataclass(frozen=True, slots=True)
class C07ForbiddenUse:
    source: str
    token: str
    reason: str


@dataclass(frozen=True, slots=True)
class C07ScaffoldValidationReport:
    passed: bool
    reasons: tuple[str, ...]


_C07_RUNTIME_AREAS = ("model", "control", "baselines", "supervisor")
_FORBIDDEN_LEGACY_TOKENS = (
    "r_opt",
    "weighted_synthesis",
    "compute_raafu",
    "RAAFU",
    "action_bonus",
    "memory_bonus",
)
_HEX_DIGITS = frozenset("0123456789abcdefABCDEF")
_MODEL_CONFIG_LOCATOR = "protocol/c07/approximate_sps_model_config.json"
_MODEL_METADATA_LOCATOR = "protocol/c07/model_artifact_metadata.json"
_CRITERIA_LOCATOR = "protocol/c07/candidate_model_crn_criteria.json"
_CRN_REPORT_LOCATOR = "protocol/c07/candidate_model_crn_report.json"
_BASELINE_LOCATOR = "protocol/c07/baseline_action_api_qualification.json"
_PREFLIGHT_LOCATOR = "protocol/c07/g2a_preflight_review.json"
_MISMATCH_FREEZE_LOCATOR = "protocol/c07/mismatch_axis_level_freeze.json"
_MISMATCH_SCHEMA_LOCATOR = "protocol/c07/mismatch_profile_schema.json"
_CAPABILITY_LOCATOR = "protocol/c07/capability_table.json"
_MANIFEST_LOCATOR = "protocol/c07/scaffold_manifest.json"
_REPORT_LOCATOR = "protocol/evidence/G2A_c07_model_baseline_scaffold_report.md"
_EXPECTED_MANIFEST_ARTIFACTS = frozenset(
    {
        _MODEL_CONFIG_LOCATOR,
        _MODEL_METADATA_LOCATOR,
        _CRITERIA_LOCATOR,
        _CRN_REPORT_LOCATOR,
        _BASELINE_LOCATOR,
        _PREFLIGHT_LOCATOR,
        _MISMATCH_FREEZE_LOCATOR,
        _MISMATCH_SCHEMA_LOCATOR,
        _CAPABILITY_LOCATOR,
        _REPORT_LOCATOR,
        "src/exp09/contracts/actions.py",
        "src/exp09/control/candidate_generator.py",
        "src/exp09/control/candidate_model_crn.py",
        "src/exp09/model/interfaces.py",
        "src/exp09/model/state_estimator.py",
        "src/exp09/model/scenarios.py",
        "src/exp09/model/approximate.py",
        "src/exp09/model/mismatch.py",
        "src/exp09/model/artifacts.py",
        "src/exp09/baselines/action_api.py",
        "src/exp09/baselines/registry.py",
        "src/exp09/baselines/capability.py",
        "src/exp09/validation/c07.py",
        "tests/c07/test_c07_scaffold.py",
    }
)
_EXPECTED_METHODS = (
    "Full",
    "RMPC_SameEvaluator",
    "Rule_SameStack",
    "TunedNonLLM_SameStack",
    "Plain_LLM",
    "DQN",
    "DQN_Strong",
    "GNN_DDQN",
    "KEEP_sanity",
    "AoI_aware_heuristic",
    "Greedy_1",
    "Nominal_MPC",
)


def _load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def _is_sha256(value: Any) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(character in _HEX_DIGITS for character in value)
    )


def _safe_locator(locator: Any) -> bool:
    if not isinstance(locator, str) or not locator:
        return False
    path = PurePosixPath(locator)
    return not path.is_absolute() and ".." not in path.parts and "\\" not in locator


def lint_c07_forbidden_legacy_logic(src_root: Path) -> tuple[C07ForbiddenUse, ...]:
    violations: list[C07ForbiddenUse] = []
    package_root = src_root / "exp09"
    for area in _C07_RUNTIME_AREAS:
        area_root = package_root / area
        if not area_root.is_dir():
            continue
        for path in sorted(area_root.rglob("*.py")):
            text = path.read_text(encoding="utf-8")
            for token in _FORBIDDEN_LEGACY_TOKENS:
                if token in text:
                    violations.append(
                        C07ForbiddenUse(
                            source=str(path),
                            token=token,
                            reason="legacy objective or action-bonus logic is forbidden in C07",
                        )
                    )
    return tuple(violations)


def validate_c07_scaffold_bundle(project_root: Path) -> C07ScaffoldValidationReport:
    reasons: list[str] = []
    records = {
        locator: _load_json(project_root / locator)
        for locator in (
            _MODEL_CONFIG_LOCATOR,
            _MODEL_METADATA_LOCATOR,
            _CRITERIA_LOCATOR,
            _CRN_REPORT_LOCATOR,
            _BASELINE_LOCATOR,
            _PREFLIGHT_LOCATOR,
            _MISMATCH_FREEZE_LOCATOR,
            _MISMATCH_SCHEMA_LOCATOR,
            _CAPABILITY_LOCATOR,
            _MANIFEST_LOCATOR,
        )
        if (project_root / locator).is_file()
    }
    for locator in (
        _MODEL_CONFIG_LOCATOR,
        _MODEL_METADATA_LOCATOR,
        _CRITERIA_LOCATOR,
        _CRN_REPORT_LOCATOR,
        _BASELINE_LOCATOR,
        _PREFLIGHT_LOCATOR,
        _MISMATCH_FREEZE_LOCATOR,
        _MISMATCH_SCHEMA_LOCATOR,
        _CAPABILITY_LOCATOR,
        _MANIFEST_LOCATOR,
    ):
        if locator not in records:
            reasons.append(f"{locator}: missing")
    if reasons:
        return C07ScaffoldValidationReport(False, tuple(reasons))

    _validate_model_config(records[_MODEL_CONFIG_LOCATOR], reasons)
    _validate_model_metadata(records[_MODEL_METADATA_LOCATOR], project_root, reasons)
    _validate_criteria(records[_CRITERIA_LOCATOR], reasons)
    _validate_crn_report(records[_CRN_REPORT_LOCATOR], reasons)
    _validate_baseline(records[_BASELINE_LOCATOR], reasons)
    _validate_preflight(records[_PREFLIGHT_LOCATOR], reasons)
    _validate_mismatch(records[_MISMATCH_FREEZE_LOCATOR], records[_MISMATCH_SCHEMA_LOCATOR], reasons)
    _validate_capability(records[_CAPABILITY_LOCATOR], reasons)
    _validate_manifest(records[_MANIFEST_LOCATOR], project_root, reasons)
    _validate_report(project_root, reasons)
    for violation in lint_c07_forbidden_legacy_logic(project_root / "src"):
        reasons.append(f"{violation.source}: forbidden legacy token {violation.token}")
    return C07ScaffoldValidationReport(not reasons, tuple(reasons))


def _validate_model_config(record: Any, reasons: list[str]) -> None:
    expected = {
        "schema_version": "exp09-approximate-sps-model-config-v2",
        "status": "C07_METHOD_BLIND_CORRECTNESS_CONFIG_FROZEN",
        "model_kind": "ApproximateSPSModel",
        "config_hash": "0810AA86A59257FE7060B153EB9A9F7EE532383075240CFCCE1EDE01BCD8A6BC",
        "transition_step_us": 1000,
        "packet_period_us": 100000,
        "logical_subchannel_count": 2,
        "load_scale_ppm": 1000000,
        "correctness_horizon_us": 3000000,
        "model_transition_budget_per_decision": 72000,
        "method_execution_allowed": False,
        "method_comparison_allowed": False,
        "performance_claim_allowed": False,
    }
    if not isinstance(record, Mapping):
        reasons.append("C07 approximate model config must be an object")
        return
    for key, value in expected.items():
        if record.get(key) != value:
            reasons.append(f"C07 approximate model config {key} mismatch")
    forecast = record.get("forecast_batch")
    if not isinstance(forecast, Mapping) or forecast != {
        "schema_version": "exp09-forecast-batch-config-v2",
        "config_hash": "628ECD0F5782285B1F06D8830FC851024B5A6101B1FD46ACDB6EB99391E5AD61",
        "load_scales_ppm": [800000, 1000000, 1200000],
        "source": "METHOD_BLIND_FROZEN_CONTROLLER_LOAD_SCALE_LEVELS",
    }:
        reasons.append("C07 forecast batch load grid mismatch")


def _validate_model_metadata(record: Any, project_root: Path, reasons: list[str]) -> None:
    if not isinstance(record, Mapping):
        reasons.append("C07 model artifact metadata must be an object")
        return
    if record.get("status") != "C07_CORRECTNESS_QUALIFIED_C12_PERFORMANCE_QUALIFICATION_PENDING":
        reasons.append("C07 model artifact metadata status mismatch")
    artifacts = record.get("artifacts")
    if not isinstance(artifacts, list) or len(artifacts) != 1:
        reasons.append("C07 model metadata must contain one model artifact")
        return
    artifact = artifacts[0]
    if not isinstance(artifact, Mapping):
        reasons.append("C07 model artifact entry must be an object")
        return
    expected = {
        "artifact_id": "approximate-sps-model-c07-v1",
        "model_kind": "ApproximateSPSModel",
        "training_source": "NO_TRAINING_STRUCTURAL_C07_APPROXIMATION",
        "status": "QUALIFIED",
    }
    for key, value in expected.items():
        if artifact.get(key) != value:
            reasons.append(f"C07 model artifact {key} mismatch")
    if artifact.get("config_hash") != _sha256(project_root / _MODEL_CONFIG_LOCATOR):
        reasons.append("C07 model artifact config_hash mismatch")
    if artifact.get("interface_hash") != _sha256(project_root / "src/exp09/model/interfaces.py"):
        reasons.append("C07 model artifact interface_hash mismatch")
    evidence = artifact.get("evidence_hashes")
    expected_evidence = [_sha256(project_root / _CRN_REPORT_LOCATOR)]
    if evidence != expected_evidence:
        reasons.append("C07 model artifact evidence hashes mismatch")


def _validate_criteria(record: Any, reasons: list[str]) -> None:
    if not isinstance(record, Mapping):
        reasons.append("C07 candidate/model criteria must be an object")
        return
    expected = {
        "schema_version": "exp09-c07-candidate-model-crn-criteria-v2",
        "status": "C07_CORRECTNESS_CRITERIA_PASSED",
        "g2a_gate_status": "PASSED",
        "method_execution_allowed": False,
        "method_comparison_allowed": False,
        "performance_claim_allowed": False,
    }
    for key, value in expected.items():
        if record.get(key) != value:
            reasons.append(f"C07 candidate/model criteria {key} mismatch")
    checks = record.get("required_checks")
    if not isinstance(checks, list) or len(checks) != 10:
        reasons.append("C07 candidate/model criteria required-check list mismatch")
    elif any(not str(item.get("status", "")).startswith("PASSED") for item in checks):
        reasons.append("C07 candidate/model criteria contains a non-passed check")
    pass_rule = record.get("g2a_pass_rule")
    if not isinstance(pass_rule, Mapping) or pass_rule.get("allows_hash_only_model_as_pass") is not False:
        reasons.append("C07 candidate/model criteria hash-only exclusion mismatch")


def _validate_crn_report(record: Any, reasons: list[str]) -> None:
    if not isinstance(record, Mapping):
        reasons.append("C07 candidate/model report must be an object")
        return
    expected = {
        "schema_version": "exp09-c07-candidate-model-crn-report-v2",
        "status": "METHOD_BLIND_REAL_MODEL_CORRECTNESS_PASSED",
        "g2a_gate_status": "PASSED",
        "method_execution_allowed": False,
        "method_comparison_allowed": False,
        "performance_claim_allowed": False,
        "evidence_type": "REAL_INTEGER_STATE_TRANSITION_AND_NUMERIC_TRACE",
        "remaining_g2a_blockers": [],
    }
    for key, value in expected.items():
        if record.get(key) != value:
            reasons.append(f"C07 candidate/model report {key} mismatch")
    evidence = record.get("non_hash_trace_evidence")
    expected_evidence = {
        "horizon_us": 3000000,
        "transition_step_us": 1000,
        "transition_count_per_member": 3000,
        "scenario_member_count": 3,
        "candidate_count": 8,
        "total_transition_budget": 72000,
        "state_hash_before_equals_after": True,
        "crn_order_shared_across_actions": True,
        "all_legal_rri_candidates_have_distinct_numeric_rollout_hashes": True,
        "all_legal_rri_candidates_have_distinct_attempt_schedules": True,
        "all_legal_rri_candidates_have_distinct_controlled_age_trajectories": True,
        "frozen_load_scales_applied_multiplicatively": True,
        "scenario_semantic_resealing_rejected": True,
        "mismatch_freeze_semantic_resealing_rejected": True,
        "budget_before_consumed": 0,
        "budget_after_consumed": 72000,
    }
    if evidence != expected_evidence:
        reasons.append("C07 candidate/model numeric evidence mismatch")


def _validate_baseline(record: Any, reasons: list[str]) -> None:
    if not isinstance(record, Mapping):
        reasons.append("C07 baseline qualification record must be an object")
        return
    expected = {
        "schema_version": "exp09-c07-baseline-action-api-qualification-v2",
        "status": "C07_IMPLEMENTATIONS_COMPLETE_C12_QUALIFICATION_PENDING",
        "g2a_gate_status": "PASSED",
        "method_execution_allowed": False,
        "method_comparison_allowed": False,
        "training_allowed": False,
        "api_allowed": False,
        "performance_claim_allowed": False,
        "decision_status_required": "IMPLEMENTED_C07_C12_QUALIFICATION_PENDING",
        "evidence_hashes_required_on_decisions": True,
    }
    for key, value in expected.items():
        if record.get(key) != value:
            reasons.append(f"C07 baseline qualification {key} mismatch")
    if tuple(record.get("implemented_public_action_methods", ())) != _EXPECTED_METHODS[-4:]:
        reasons.append("C07 baseline implemented-method list mismatch")
    disclosure = record.get("adapted_aoi_disclosure")
    if not isinstance(disclosure, Mapping) or disclosure.get("status") != "ADAPTED_NOT_LITERATURE_REPRODUCTION":
        reasons.append("C07 adapted AoI disclosure mismatch")


def _validate_preflight(record: Any, reasons: list[str]) -> None:
    if not isinstance(record, Mapping):
        reasons.append("C07 G2-A preflight must be an object")
        return
    expected = {
        "schema_version": "exp09-c07-g2a-preflight-review-v2",
        "status": "METHOD_BLIND_C07_CORRECTNESS_PASSED",
        "g2a_gate_status": "PASSED",
        "hard_stop_before_step": "C08",
        "method_execution_allowed": False,
        "method_comparison_allowed": False,
        "training_allowed": False,
        "api_allowed": False,
        "performance_claim_allowed": False,
    }
    for key, value in expected.items():
        if record.get(key) != value:
            reasons.append(f"C07 G2-A preflight {key} mismatch")
    rollout = record.get("candidate_rollout_boundary")
    if not isinstance(rollout, Mapping) or rollout.get("pending_for_g2a_pass") != []:
        reasons.append("C07 candidate rollout boundary is not closed")
    baseline = record.get("baseline_fairness_connection")
    if not isinstance(baseline, Mapping):
        reasons.append("C07 baseline fairness preflight must be an object")
    elif tuple(baseline.get("required_methods", ())) != _EXPECTED_METHODS:
        reasons.append("C07 baseline fairness required-method list mismatch")


def _validate_mismatch(freeze: Any, schema: Any, reasons: list[str]) -> None:
    expected = {
        "g2a_gate_status": "PASSED",
        "injection_point": "ControllerModel_only",
        "ground_truth_plant_changed": False,
        "supporting_family_run_allowed": False,
        "method_execution_allowed": False,
        "method_comparison_allowed": False,
        "performance_claim_allowed": False,
    }
    for name, record in (("freeze", freeze), ("schema", schema)):
        if not isinstance(record, Mapping):
            reasons.append(f"C07 mismatch {name} must be an object")
            continue
        for key, value in expected.items():
            if record.get(key) != value:
                reasons.append(f"C07 mismatch {name} {key} mismatch")
    if isinstance(freeze, Mapping):
        axes = freeze.get("axes")
        if not isinstance(axes, list) or len(axes) != 1 or not isinstance(axes[0], Mapping):
            reasons.append("C07 mismatch axis catalog mismatch")
            return
        axis = axes[0]
        if (
            axis.get("schema_version") != "exp09-c07-mismatch-axis-v1"
            or axis.get("axis_id") != "controller_load_scale"
            or axis.get("injection_point") != "ControllerModel_only"
        ):
            reasons.append("C07 mismatch axis semantics mismatch")
        levels = axis.get("levels")
        if not isinstance(levels, list):
            reasons.append("C07 mismatch levels must be a list")
            return
        expected_levels = (
            ("nominal", "NOMINAL", 1000000),
            ("under_predict_load", "DECREASE", 800000),
            ("over_predict_load", "INCREASE", 1200000),
        )
        actual_levels = tuple(
            (
                level.get("level_id"),
                level.get("direction"),
                level.get("parameterization", {}).get("load_scale_ppm")
                if isinstance(level.get("parameterization"), Mapping)
                else None,
            )
            for level in levels
            if isinstance(level, Mapping)
        )
        if actual_levels != expected_levels:
            reasons.append("C07 mismatch load-scale levels mismatch")
        for level in levels:
            if not isinstance(level, Mapping):
                reasons.append("C07 mismatch level must be an object")
                continue
            parameterization = level.get("parameterization")
            expected_hash = (
                _canonical_json_sha256(parameterization)
                if isinstance(parameterization, Mapping)
                else None
            )
            if level.get("parameterization_hash") != expected_hash:
                reasons.append("C07 mismatch parameterization hash mismatch")
        if freeze.get("axis_level_grid_hash") != _canonical_json_sha256(axes):
            reasons.append("C07 mismatch axis-level grid hash mismatch")
        freeze_without_self_hash = {
            key: value
            for key, value in freeze.items()
            if key != "method_blind_freeze_record_hash"
        }
        if freeze.get("method_blind_freeze_record_hash") != _canonical_json_sha256(
            freeze_without_self_hash
        ):
            reasons.append("C07 mismatch freeze-record hash mismatch")


def _canonical_json_sha256(value: Any) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest().upper()


def _validate_capability(record: Any, reasons: list[str]) -> None:
    rows = record.get("rows") if isinstance(record, Mapping) else None
    if not isinstance(rows, list) or tuple(row.get("method_id") for row in rows) != _EXPECTED_METHODS:
        reasons.append("C07 capability table method list mismatch")
        return
    for row in rows:
        method_id = row.get("method_id")
        if method_id in _EXPECTED_METHODS[-4:]:
            if row.get("qualification_status") != "IMPLEMENTED_NOT_QUALIFIED":
                reasons.append(f"C07 capability row {method_id} status mismatch")
        elif row.get("qualification_status") != "PLANNED":
            reasons.append(f"C07 downstream capability row {method_id} status mismatch")
        if row.get("training_budget") != 0:
            reasons.append(f"C07 capability row {method_id} training budget must remain zero")


def _validate_manifest(record: Any, project_root: Path, reasons: list[str]) -> None:
    if not isinstance(record, Mapping):
        reasons.append("C07 manifest must be an object")
        return
    expected = {
        "schema_version": "exp09-c07-scaffold-manifest-v2",
        "status": "C07_COMPLETE_G2A_PASSED",
        "g2a_gate_status": "PASSED",
        "hard_stop_before_step": "C08",
        "method_execution_allowed": False,
        "method_comparison_allowed": False,
        "performance_claim_allowed": False,
    }
    for key, value in expected.items():
        if record.get(key) != value:
            reasons.append(f"C07 manifest {key} mismatch")
    artifacts = record.get("artifacts")
    if not isinstance(artifacts, list):
        reasons.append("C07 manifest artifacts must be a list")
        return
    locators = tuple(item.get("locator") for item in artifacts if isinstance(item, Mapping))
    if len(locators) != len(set(locators)):
        reasons.append("C07 manifest contains duplicate locators")
    if frozenset(locators) != _EXPECTED_MANIFEST_ARTIFACTS:
        reasons.append("C07 manifest artifact set mismatch")
    for artifact in artifacts:
        locator = artifact.get("locator") if isinstance(artifact, Mapping) else None
        expected_hash = artifact.get("sha256") if isinstance(artifact, Mapping) else None
        if not _safe_locator(locator):
            reasons.append("C07 manifest contains an unsafe locator")
            continue
        path = project_root / locator
        if not path.is_file():
            reasons.append(f"C07 manifest artifact missing: {locator}")
        elif not _is_sha256(expected_hash) or _sha256(path) != expected_hash:
            reasons.append(f"C07 manifest hash mismatch: {locator}")


def _validate_report(project_root: Path, reasons: list[str]) -> None:
    path = project_root / _REPORT_LOCATOR
    if not path.is_file():
        reasons.append(f"{_REPORT_LOCATOR}: missing")
        return
    text = path.read_text(encoding="utf-8")
    for marker in (
        "REPORT_ID: g2a_c07_model_baseline",
        "STATUS: C07_COMPLETE_G2A_PASSED",
        "G2A_GATE_STATUS: PASSED",
        "validate_c07_scaffold_bundle=PASS",
        "METHOD_EXECUTION_ALLOWED: false",
    ):
        if marker not in text:
            reasons.append(f"G2-A report missing marker: {marker}")
