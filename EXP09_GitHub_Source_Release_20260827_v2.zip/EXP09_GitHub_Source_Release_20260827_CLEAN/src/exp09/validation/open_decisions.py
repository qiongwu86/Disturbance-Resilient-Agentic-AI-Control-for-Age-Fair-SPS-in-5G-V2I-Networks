"""Fail-closed validation for the C02 decision registry."""

from collections.abc import Mapping
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
from typing import Any


class DecisionValidationError(ValueError):
    """Raised for an unsupported validation request."""


@dataclass(frozen=True, slots=True)
class DecisionValidationReport:
    level: str
    passed: bool
    reasons: tuple[str, ...]


_ALLOWED_STATUSES = frozenset({"UNRESOLVED", "FROZEN", "REOPENED"})
_EXPECTED_IDS = tuple(f"O-{index:02d}" for index in range(1, 13))
_C02_REQUIRED_SUBDECISIONS = {
    "O-01": frozenset(
        {
            "placement_authority",
            "keep_reselect_mapping",
            "custom_message_schema_and_causality",
            "revision_continuity",
        }
    ),
    "O-07": frozenset({"event_sample_and_reset", "zero_event_and_censoring"}),
    "O-10": frozenset({"endpoint_definition", "contrast_and_wording_contract"}),
    "O-11": frozenset({"minimum_and_stretch_scope", "ledger_schema_and_formulas"}),
}
_G0_REQUIRED_AGGREGATES = frozenset({"O-02", "O-03", "O-04", "O-05", "O-06", "O-07", "O-08"})
_G0_REQUIRED_SUBDECISIONS = {
    "O-01": frozenset(
        {
            "placement_authority",
            "keep_reselect_mapping",
            "custom_message_schema_and_causality",
            "measurement_assistance_delivery_profile",
            "revision_continuity",
        }
    ),
    "O-05": frozenset(
        {
            "logical_grid_structure",
            "collision_channel_selector",
            "resource_capacity_certificate",
            "selector_grant_domain_and_timing",
            "half_duplex_and_assistance",
        }
    ),
    "O-07": frozenset(
        {
            "event_sample_and_reset",
            "zero_event_and_censoring",
            "eligible_population_binding",
            "finite_sample_and_denominator_contract",
        }
    ),
    "O-10": frozenset({"endpoint_definition", "contrast_and_wording_contract"}),
    "O-11": frozenset({"minimum_and_stretch_scope", "ledger_schema_and_formulas"}),
}
_TOOLCHAIN_GROUPS = frozenset({"runtime", "training", "llm", "analysis", "dev_test"})
_HEX_256 = re.compile(r"^[0-9A-F]{64}$")

_O08_GATE_KEYS = frozenset(
    {
        "G5_SUP",
        "G5_LLM",
        "G6_S",
        "KEY_FAIRNESS_SUPERIORITY",
        "NOMINAL_NI",
        "CORE_HARM_NONINFERIORITY",
        "DEPLOYMENT_DEGRADATION_NI",
    }
)
_O08_CLAIM_KEYS = frozenset(
    {
        "practical_superiority",
        "all_baseline_outperformance",
        "supervisory_adds_value",
        "llm_adds_value",
        "fairness_improvement",
        "noninferior",
        "comparable_or_equivalent",
        "nonharm",
        "deployment_degradation_noninferiority",
    }
)
_O08_EFFECT_ONLY_OUTPUTS = frozenset(
    {
        "absolute_effect_estimate",
        "adjusted_or_simultaneous_CI",
        "adjusted_p_value",
        "descriptive_endpoint_report",
    }
)
_O08_MARGIN_OUTPUTS = _O08_EFFECT_ONLY_OUTPUTS | frozenset({"frozen_margin_gate_result"})
_O08_B_GATE_DISPOSITION = {
    "G5_SUP": "NOT_ASSESSABLE_NO_MARGIN",
    "G5_LLM": "NOT_ASSESSABLE_NO_MARGIN",
    "G6_S": "NOT_ASSESSABLE_NO_MARGIN",
    "KEY_FAIRNESS_SUPERIORITY": "NOT_ASSESSABLE_NO_MARGIN",
    "NOMINAL_NI": "NOT_ASSESSABLE_NO_MARGIN",
    "CORE_HARM_NONINFERIORITY": "NOT_ASSESSABLE_NO_MARGIN",
    "DEPLOYMENT_DEGRADATION_NI": "NOT_APPLICABLE_AD02A_AND_NO_MARGIN",
}
_O08_A_GATE_DISPOSITION = {
    name: "ENABLED_NOT_EVALUATED" for name in _O08_GATE_KEYS
}
_O08_A_GATE_DISPOSITION["DEPLOYMENT_DEGRADATION_NI"] = "NOT_APPLICABLE_AD02A"
_O08_B_CLAIM_AUTHORIZATION = {
    name: "FORBIDDEN_NO_MARGIN" for name in _O08_CLAIM_KEYS
}
_O08_B_CLAIM_AUTHORIZATION[
    "deployment_degradation_noninferiority"
] = "FORBIDDEN_AD02A_AND_NO_MARGIN"
_O08_A_CLAIM_AUTHORIZATION = {
    name: "NOT_ESTABLISHED_PENDING_GATE" for name in _O08_CLAIM_KEYS
}
_O08_A_CLAIM_AUTHORIZATION[
    "deployment_degradation_noninferiority"
] = "FORBIDDEN_AD02A"

_O08_MARGIN_UNITS = {
    ("direct_superiority", "MeanAoI_W"): "ms",
    ("direct_superiority", "Q95AoI_W"): "ms",
    ("all_baseline_superiority", "MeanAoI_W"): "ms",
    ("all_baseline_superiority", "Q95AoI_W"): "ms",
    ("nominal_noninferiority", "MeanAoI_W"): "ms",
    ("nominal_noninferiority", "Q95AoI_W"): "ms",
    ("nominal_noninferiority", "collision_event_rate"): "absolute_rate",
    ("fairness_superiority", "worst_user_time_average_AoI"): "ms",
    ("core_harm_noninferiority", "collision_event_rate"): "absolute_rate",
    ("core_harm_noninferiority", "JainLoss"): "absolute_index",
    ("core_harm_noninferiority", "worst_user_time_average_AoI"): "ms",
    ("core_harm_noninferiority", "zero_success_fraction"): "absolute_rate",
    ("core_harm_noninferiority", "never_observed_fraction"): "absolute_rate",
    ("absolute_ceiling", "collision_event_rate"): "absolute_rate",
}


def _validate_registry_shape(registry: Mapping[str, Any]) -> tuple[str, ...]:
    reasons: list[str] = []
    if registry.get("schema_version") != "exp09-open-decisions-v1":
        reasons.append("unsupported registry schema version")
    decisions = registry.get("decisions")
    if not isinstance(decisions, list):
        return tuple(reasons + ["decisions must be a list"])
    ids = tuple(item.get("id") for item in decisions if isinstance(item, Mapping))
    if ids != _EXPECTED_IDS:
        reasons.append("decision IDs must be unique and ordered O-01 through O-12")
    for item in decisions:
        if not isinstance(item, Mapping):
            reasons.append("every decision must be an object")
            continue
        status = item.get("status")
        if status not in _ALLOWED_STATUSES:
            reasons.append(f"{item.get('id')}: invalid status")
        if status == "FROZEN" and item.get("value") is None:
            reasons.append(f"{item.get('id')}: FROZEN requires value")
        if status != "FROZEN" and item.get("value") is not None:
            reasons.append(f"{item.get('id')}: non-FROZEN value must be null")
        subdecisions = item.get("subdecisions", {})
        if not isinstance(subdecisions, Mapping):
            reasons.append(f"{item.get('id')}: subdecisions must be an object")
            continue
        for name, subdecision in subdecisions.items():
            if not isinstance(name, str) or not isinstance(subdecision, Mapping):
                reasons.append(f"{item.get('id')}.{name}: subdecision must be an object")
                continue
            substatus = subdecision.get("status")
            if substatus not in _ALLOWED_STATUSES:
                reasons.append(f"{item.get('id')}.{name}: invalid status")
            if substatus == "FROZEN" and subdecision.get("value") is None:
                reasons.append(f"{item.get('id')}.{name}: FROZEN requires value")
            if substatus != "FROZEN" and subdecision.get("value") is not None:
                reasons.append(f"{item.get('id')}.{name}: non-FROZEN value must be null")
    declared_g0 = (
        registry.get("gate_layers", {})
        .get("G0_SCIENCE", {})
        .get("required_aggregate_decisions")
    )
    if not isinstance(declared_g0, list) or frozenset(declared_g0) != _G0_REQUIRED_AGGREGATES:
        reasons.append("G0 required aggregate declaration does not match the validator")
    return tuple(reasons)


def _find_float_paths(value: Any, *, path: str = "root") -> tuple[str, ...]:
    paths: list[str] = []
    if isinstance(value, float):
        paths.append(path)
    elif isinstance(value, Mapping):
        for key, child in value.items():
            paths.extend(_find_float_paths(child, path=f"{path}.{key}"))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            paths.extend(_find_float_paths(child, path=f"{path}[{index}]"))
    return tuple(paths)


def _is_non_empty_mapping(value: Any) -> bool:
    return isinstance(value, Mapping) and bool(value)


def _safe_locator(value: Any) -> bool:
    if not isinstance(value, str) or not value or "\\" in value:
        return False
    path = PurePosixPath(value)
    return not path.is_absolute() and ".." not in path.parts and ":" not in path.parts[0]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def _validate_artifact_record(
    record: Any,
    *,
    label: str,
    reasons: list[str],
    project_root: Path | None,
) -> None:
    if not isinstance(record, Mapping):
        reasons.append(f"{label}: artifact record must be an object")
        return
    locator = record.get("locator")
    expected_hash = record.get("sha256")
    if not _safe_locator(locator):
        reasons.append(f"{label}: unsafe artifact locator")
        return
    if not isinstance(expected_hash, str) or _HEX_256.fullmatch(expected_hash) is None:
        reasons.append(f"{label}: sha256 must be uppercase hexadecimal")
        return
    if project_root is not None:
        artifact = project_root / locator
        if not artifact.is_file():
            reasons.append(f"{label}: artifact is missing")
        elif _sha256(artifact) != expected_hash:
            reasons.append(f"{label}: artifact hash mismatch")


def _validate_toolchain(
    toolchain: Any, *, project_root: Path | None
) -> tuple[str, ...]:
    reasons: list[str] = []
    if not isinstance(toolchain, Mapping):
        return ("C02 toolchain record must be an object",)
    if toolchain.get("status") != "FROZEN":
        reasons.append("C02 toolchain and lock are unresolved")
        return tuple(reasons)
    value = toolchain.get("value")
    if not isinstance(value, Mapping):
        return tuple(reasons + ["C02 toolchain and lock have no frozen value"])

    python = value.get("target_python")
    if not isinstance(python, Mapping) or any(
        not python.get(name)
        for name in ("implementation", "version", "platform", "architecture")
    ):
        reasons.append("C02 target Python record is incomplete")
    tool = value.get("lock_tool")
    if not isinstance(tool, Mapping) or any(
        not tool.get(name) for name in ("name", "version", "format")
    ):
        reasons.append("C02 lock tool record is incomplete")
    groups = value.get("dependency_groups")
    if not isinstance(groups, Mapping) or set(groups) != _TOOLCHAIN_GROUPS:
        reasons.append("C02 dependency groups are incomplete")
    elif any(not isinstance(items, list) or not items for items in groups.values()):
        reasons.append("C02 dependency groups must be non-empty lists")
    if not _is_non_empty_mapping(value.get("sync_scope")):
        reasons.append("C02 sync scope is incomplete")
    policy = value.get("version_hash_policy")
    if not isinstance(policy, Mapping) or any(
        not policy.get(name)
        for name in (
            "direct_requirements",
            "transitive_versions",
            "distribution_hashes",
            "local_artifacts",
        )
    ):
        reasons.append("C02 version/hash policy is incomplete")

    artifacts = value.get("artifacts")
    if not isinstance(artifacts, Mapping):
        reasons.append("C02 artifact records are incomplete")
    else:
        for name in ("pyproject_toml", "uv_lock", "environment_lock"):
            _validate_artifact_record(
                artifacts.get(name),
                label=f"C02 {name}",
                reasons=reasons,
                project_root=project_root,
            )
    _validate_artifact_record(
        value.get("evidence"),
        label="C02 toolchain evidence",
        reasons=reasons,
        project_root=project_root,
    )
    if project_root is None:
        reasons.append("C02 artifact hashes were not verified against disk")
    return tuple(reasons)


def _frozen_mapping(value: Any) -> bool:
    return isinstance(value, Mapping) and value.get("status") == "FROZEN" and value.get(
        "value"
    ) is not None


def _validate_required_subdecisions(
    by_id: Mapping[str, Any],
    required: Mapping[str, frozenset[str]],
    *,
    label: str,
) -> tuple[str, ...]:
    reasons: list[str] = []
    for decision_id, names in required.items():
        decision = by_id.get(decision_id)
        subdecisions = decision.get("subdecisions") if isinstance(decision, Mapping) else None
        for name in sorted(names):
            subdecision = subdecisions.get(name) if isinstance(subdecisions, Mapping) else None
            if not _frozen_mapping(subdecision):
                reasons.append(f"{decision_id}.{name}: required {label} decision is not frozen")
    return tuple(reasons)


def _validate_authority_record(record: Any, *, label: str) -> tuple[str, ...]:
    reasons: list[str] = []
    if not isinstance(record, Mapping):
        return (f"{label}: authority record must be an object",)
    if not _safe_locator(record.get("locator")):
        reasons.append(f"{label}: authority locator is unsafe")
    sha256 = record.get("sha256")
    if not isinstance(sha256, str) or _HEX_256.fullmatch(sha256) is None:
        reasons.append(f"{label}: authority sha256 must be uppercase hexadecimal")
    return tuple(reasons)


def _validate_static_capacity_certificate(
    decision: Any, *, project_root: Path | None
) -> tuple[str, ...]:
    reasons: list[str] = []
    if not isinstance(decision, Mapping):
        return ("O-05.resource_capacity_certificate: missing subdecision",)
    subdecisions = decision.get("subdecisions")
    certificate = (
        subdecisions.get("resource_capacity_certificate")
        if isinstance(subdecisions, Mapping)
        else None
    )
    if not _frozen_mapping(certificate):
        return ("O-05.resource_capacity_certificate: required certificate is not frozen",)
    value = certificate.get("value")
    if not isinstance(value, Mapping):
        return ("O-05.resource_capacity_certificate: frozen value must be an object",)
    if value.get("headroom_cap_numerator") != 1 or value.get(
        "headroom_cap_denominator"
    ) != 2:
        reasons.append("O-05.resource_capacity_certificate: rho must be rational 1/2")
    if value.get("minimum_c_by_headroom") != 1:
        reasons.append("O-05.resource_capacity_certificate: headroom must resolve C=1")
    if value.get("minimum_c_by_required_2d_witnesses") != 2:
        reasons.append("O-05.resource_capacity_certificate: 2D witnesses must require C=2")
    if value.get("logical_subchannel_count") != 2:
        reasons.append("O-05.resource_capacity_certificate: selected C must be 2")
    if value.get("selector_domain_status") != "UNRESOLVED_OUTSIDE_CERTIFICATE_SCOPE":
        reasons.append("O-05.resource_capacity_certificate: selector scope is overstated")
    artifact = value.get("artifact")
    _validate_artifact_record(
        artifact,
        label="O-05 static capacity certificate",
        reasons=reasons,
        project_root=project_root,
    )
    if project_root is not None and isinstance(artifact, Mapping) and _safe_locator(
        artifact.get("locator")
    ):
        path = project_root / artifact["locator"]
        if path.is_file():
            try:
                payload = json.loads(path.read_text(encoding="ascii"))
            except (UnicodeError, json.JSONDecodeError):
                reasons.append("O-05 static capacity certificate: invalid canonical JSON")
            else:
                selection = payload.get("selection", {})
                structural = payload.get("structural_requirement", {})
                if selection.get("logical_subchannel_count") != value.get(
                    "logical_subchannel_count"
                ):
                    reasons.append("O-05 static capacity certificate: C mismatch")
                if selection.get("minimum_c_by_headroom") != value.get(
                    "minimum_c_by_headroom"
                ):
                    reasons.append("O-05 static capacity certificate: headroom result mismatch")
                if structural.get("selector_domain_status") != value.get(
                    "selector_domain_status"
                ):
                    reasons.append("O-05 static capacity certificate: selector scope mismatch")
    return tuple(reasons)


def _validate_o02_composition(decision: Any) -> tuple[str, ...]:
    reasons: list[str] = []
    if not _frozen_mapping(decision):
        return ("O-02: required G0 aggregate is not frozen",)
    value = decision["value"]
    expected = {
        "composition_schema": "exp09-o02-composition-v1",
        "frozen_subdecisions": [
            "packet_structure",
            "packet_numeric_profile",
            "initialization_contract",
            "entity_population_contract",
            "handover_and_population_binding",
            "payload_abstraction",
        ],
        "packet_period_us": 100000,
        "burn_in_us": 10000000,
        "initial_total_vehicles": 6,
        "primary_influx_new_background_vehicles": 3,
        "maximum_realized_total_vehicles": 9,
        "aggregate_authority": "AD_03A",
    }
    if value != expected:
        reasons.append("O-02: frozen composition does not match AD-03A exactly")
    return tuple(reasons)


def _validate_o06_composition(decision: Any) -> tuple[str, ...]:
    reasons: list[str] = []
    if not _frozen_mapping(decision):
        return ("O-06: required G0 aggregate is not frozen",)
    value = decision["value"]
    expected = {
        "composition_schema": "exp09-o06-composition-v1",
        "frozen_subdecisions": [
            "retained_identity_fsm",
            "numeric_observability_profile",
            "measurement_transport_profile",
            "summary_and_population_binding",
            "receiver_measurement_and_dropout",
        ],
        "identity_removal_timeout_us": "NONE",
        "summary_period_us": 50000,
        "aggregation_window_us": 500000,
        "measurement_delay_us": 10000,
        "telemetry_performance_duration_us": 500000,
        "telemetry_construction_only_duration_us": 1100000,
        "sensing_unit_us": 1000,
        "aggregate_authorities": ["AD_05A", "AD_09A"],
    }
    if value != expected:
        reasons.append("O-06: frozen composition does not match AD-05A/AD-09A exactly")
    return tuple(reasons)


def _validate_o05_composition(decision: Any) -> tuple[str, ...]:
    if not _frozen_mapping(decision):
        return ("O-05: required G0 aggregate is not frozen",)
    expected = {
        "composition_schema": "exp09-o05-composition-v1",
        "frozen_subdecisions": [
            "logical_grid_structure",
            "collision_channel_selector",
            "selector_grant_domain_and_timing",
            "resource_capacity_certificate",
            "half_duplex_and_assistance",
        ],
        "slot_duration_us": 1000,
        "logical_subchannel_count": 2,
        "numeric_selection_lead_time_us": "NONE",
        "empty_candidate_rule": "FAIL_CLOSED_NO_LEGAL_GRANT",
        "capacity_certificate_sha256": (
            "98CA0741FBFF8B962184D988E7F40614E19E931BC36A33E742665A69E4FE65D8"
        ),
        "aggregate_authorities": ["AD_04A", "AD_08A"],
    }
    if decision["value"] != expected:
        return ("O-05: frozen composition does not match AD-04A/AD-08A exactly",)
    return ()


def _validate_o07_composition(decision: Any) -> tuple[str, ...]:
    if not _frozen_mapping(decision):
        return ("O-07: required G0 aggregate is not frozen",)
    expected = {
        "composition_schema": "exp09-o07-composition-v1",
        "frozen_subdecisions": [
            "event_sample_and_reset",
            "zero_event_and_censoring",
            "eligible_population_binding",
            "finite_sample_and_denominator_contract",
        ],
        "Q95_convention": "NEAREST_RANK_1_BASED_INDEX_CEIL_95N_OVER_100",
        "collision_denominator": "ALL_NON_EMPTY_BUFFER_TERMINAL_TX_ATTEMPTS",
        "Jain_numeric_epsilon": "NONE",
        "aggregate_authorities": [
            "METHOD_BLIND_ESTIMAND_RECORD",
            "AD_03A",
            "AD_05A",
            "AD_10A",
        ],
    }
    if decision["value"] != expected:
        return (
            "O-07: frozen composition does not match the estimand and "
            "AD-03A/AD-05A/AD-10A authorities exactly",
        )
    return ()


def _validate_o08_common(value: Mapping[str, Any]) -> tuple[str, ...]:
    reasons: list[str] = []
    expected_keys = {
        "schema_version",
        "resolution_mode",
        "margin_state",
        "margins",
        "zero_reference",
        "analysis_contract",
        "gate_disposition",
        "claim_authorization",
        "permitted_result_wording_class",
        "reopen_rule",
        "authority_record",
    }
    if set(value) != expected_keys:
        reasons.append("O-08: resolution fields are incomplete or unknown")
    if value.get("schema_version") != "exp09-o08-resolution-v1":
        reasons.append("O-08: unsupported resolution schema version")
    analysis = value.get("analysis_contract")
    if not isinstance(analysis, Mapping):
        reasons.append("O-08: analysis contract must be an object")
    else:
        if set(analysis) != {
            "allowed_outputs",
            "margin_dependent_decisions",
            "recovery_AUC_role",
            "pilot_may_choose_margin",
        }:
            reasons.append("O-08: analysis contract fields are incomplete or unknown")
        outputs = analysis.get("allowed_outputs")
        if not isinstance(outputs, list) or len(outputs) != len(set(outputs)):
            reasons.append("O-08: allowed outputs must be a unique list")
        if analysis.get("recovery_AUC_role") != "SUPPORTING_EFFECT_AND_CI_ONLY":
            reasons.append("O-08: recovery AUC must remain supporting effect-and-CI only")
        if analysis.get("pilot_may_choose_margin") is not False:
            reasons.append("O-08: the precision pilot must not choose margins")
    reasons.extend(_validate_authority_record(value.get("authority_record"), label="O-08"))
    if value.get("reopen_rule") != (
        "NEW_AUTHOR_DECISION_AND_NEW_PROTOCOL_GENERATION_BEFORE_ANY_"
        "RETAINED_MARGIN_DEPENDENT_CLAIM"
    ):
        reasons.append("O-08: margin-dependent claims require a new author decision and generation")
    return tuple(reasons)


def _validate_o08_margin_record(
    record: Any, *, group: str, endpoint: str, required_unit: str
) -> tuple[str, ...]:
    label = f"O-08.margins.{group}.{endpoint}"
    reasons: list[str] = []
    if not isinstance(record, Mapping):
        return (f"{label}: margin record must be an object",)
    expected_keys = {
        "value",
        "unit",
        "direction",
        "purpose",
        "source_locator",
        "source_sha256",
        "method_blind_statement",
        "application_interpretation",
    }
    if set(record) != expected_keys:
        reasons.append(f"{label}: margin record fields are incomplete or unknown")
    number = record.get("value")
    if isinstance(number, bool) or not isinstance(number, (int, float)) or number <= 0:
        reasons.append(f"{label}: margin must be a positive absolute number")
    elif required_unit in {"absolute_rate", "absolute_index"} and number > 1:
        reasons.append(f"{label}: normalized absolute margin must not exceed one")
    if record.get("unit") != required_unit:
        reasons.append(f"{label}: margin unit must be {required_unit}")
    if record.get("direction") != "LOWER_IS_BETTER":
        reasons.append(f"{label}: direction must be LOWER_IS_BETTER")
    if not isinstance(record.get("purpose"), str) or not record.get("purpose"):
        reasons.append(f"{label}: purpose is required")
    if not _safe_locator(record.get("source_locator")):
        reasons.append(f"{label}: source locator is unsafe")
    source_hash = record.get("source_sha256")
    if not isinstance(source_hash, str) or _HEX_256.fullmatch(source_hash) is None:
        reasons.append(f"{label}: source sha256 must be uppercase hexadecimal")
    if record.get("method_blind_statement") != "APPROVED_BEFORE_METHOD_IDENTITIES":
        reasons.append(f"{label}: method-blind approval is required")
    if not isinstance(record.get("application_interpretation"), str) or not record.get(
        "application_interpretation"
    ):
        reasons.append(f"{label}: application interpretation is required")
    return tuple(reasons)


def _validate_o08_resolution(decision: Any, *, o10_decision: Any) -> tuple[str, ...]:
    if not isinstance(decision, Mapping) or decision.get("status") != "FROZEN":
        return ("O-08: required G0 aggregate is not frozen",)
    value = decision.get("value")
    if not isinstance(value, Mapping):
        return ("O-08: frozen resolution must be an object",)

    reasons = list(_validate_o08_common(value))
    mode = value.get("resolution_mode")
    analysis = value.get("analysis_contract", {})
    gates = value.get("gate_disposition")
    claims = value.get("claim_authorization")
    if not isinstance(gates, Mapping) or set(gates) != _O08_GATE_KEYS:
        reasons.append("O-08: gate disposition must cover the frozen gate set exactly")
    if not isinstance(claims, Mapping) or set(claims) != _O08_CLAIM_KEYS:
        reasons.append("O-08: claim authorization must cover the frozen claim set exactly")

    if mode == "EFFECT_AND_CI_DOWNGRADE":
        if value.get("margin_state") != "NOT_ESTABLISHED_BY_AUTHORIZED_SOURCE":
            reasons.append("O-08: downgraded mode must state that margins are not established")
        if value.get("margins") is not None:
            reasons.append("O-08: downgraded mode requires margins to be null")
        zero = value.get("zero_reference")
        if not isinstance(zero, Mapping) or zero != {
            "role": "STATISTICAL_NULL_ONLY",
            "may_be_used_as_practical_margin": False,
            "may_be_used_as_NI_margin": False,
            "may_be_used_as_harm_margin": False,
        }:
            reasons.append("O-08: zero may only be a statistical null")
        if analysis.get("margin_dependent_decisions") != "DISABLED":
            reasons.append("O-08: downgraded mode must disable margin-dependent decisions")
        if set(analysis.get("allowed_outputs", [])) != _O08_EFFECT_ONLY_OUTPUTS:
            reasons.append("O-08: downgraded mode permits only effect-and-uncertainty outputs")
        if gates != _O08_B_GATE_DISPOSITION:
            reasons.append("O-08: downgraded gate dispositions are incomplete or unsafe")
        if claims != _O08_B_CLAIM_AUTHORIZATION:
            reasons.append("O-08: downgraded claims must all be forbidden")
        if value.get("permitted_result_wording_class") != "EFFECT_AND_UNCERTAINTY_ONLY":
            reasons.append("O-08: downgraded wording class is invalid")
        o10_subdecisions = (
            o10_decision.get("subdecisions") if isinstance(o10_decision, Mapping) else None
        )
        numerical_binding = (
            o10_subdecisions.get("numerical_gate_binding")
            if isinstance(o10_subdecisions, Mapping)
            else None
        )
        if isinstance(numerical_binding, Mapping) and numerical_binding.get("status") == "FROZEN":
            if numerical_binding.get("value") != "DISABLED_BY_O08_AD06B":
                reasons.append("O-08: downgraded mode is incompatible with an enabled O-10 gate")
    elif mode == "APPLICATION_DERIVED_MARGINS":
        if value.get("margin_state") != "ESTABLISHED_BY_METHOD_BLIND_APPLICATION_SOURCE":
            reasons.append("O-08: application-derived mode requires established margins")
        if value.get("zero_reference") is not None:
            reasons.append("O-08: application-derived mode must not repurpose zero")
        margins = value.get("margins")
        expected_groups: dict[str, set[str]] = {}
        for group, endpoint in _O08_MARGIN_UNITS:
            expected_groups.setdefault(group, set()).add(endpoint)
        if not isinstance(margins, Mapping) or set(margins) != set(expected_groups):
            reasons.append("O-08: application margin groups are incomplete or unknown")
        else:
            for group, endpoints in expected_groups.items():
                records = margins.get(group)
                if not isinstance(records, Mapping) or set(records) != endpoints:
                    reasons.append(f"O-08.margins.{group}: endpoints are incomplete or unknown")
                    continue
                for endpoint in sorted(endpoints):
                    reasons.extend(
                        _validate_o08_margin_record(
                            records.get(endpoint),
                            group=group,
                            endpoint=endpoint,
                            required_unit=_O08_MARGIN_UNITS[(group, endpoint)],
                        )
                    )
        direct = margins.get("direct_superiority", {}) if isinstance(margins, Mapping) else {}
        all_baseline = (
            margins.get("all_baseline_superiority", {})
            if isinstance(margins, Mapping)
            else {}
        )
        for endpoint in ("MeanAoI_W", "Q95AoI_W"):
            direct_value = direct.get(endpoint, {}).get("value") if isinstance(direct, Mapping) else None
            all_value = (
                all_baseline.get(endpoint, {}).get("value")
                if isinstance(all_baseline, Mapping)
                else None
            )
            if isinstance(direct_value, (int, float)) and isinstance(all_value, (int, float)):
                if all_value < direct_value:
                    reasons.append(
                        f"O-08.margins.all_baseline_superiority.{endpoint}: "
                        "must be at least the direct superiority margin"
                    )
        if analysis.get("margin_dependent_decisions") != "ENABLED_NOT_EVALUATED":
            reasons.append("O-08: application-derived mode must leave gates unevaluated")
        if set(analysis.get("allowed_outputs", [])) != _O08_MARGIN_OUTPUTS:
            reasons.append("O-08: application-derived output contract is invalid")
        if gates != _O08_A_GATE_DISPOSITION:
            reasons.append("O-08: application-derived gate dispositions are invalid")
        if claims != _O08_A_CLAIM_AUTHORIZATION:
            reasons.append("O-08: application-derived claims must remain unestablished")
        if value.get("permitted_result_wording_class") != "GATE_CONDITIONAL_ONLY":
            reasons.append("O-08: application-derived wording class is invalid")
    else:
        reasons.append("O-08: unsupported resolution mode")
    return tuple(reasons)


def validate_open_decisions(
    registry: Mapping[str, Any],
    *,
    level: str,
    project_root: Path | None = None,
) -> DecisionValidationReport:
    reasons = list(_validate_registry_shape(registry))
    for path in _find_float_paths(registry):
        reasons.append(f"YAML float is forbidden in the decision registry: {path}")
    gates = registry.get("gate_layers", {})
    boundary = gates.get("current_execution_boundary", {})
    if level == "c02_contract":
        if gates.get("G0_CONTRACT", {}).get("status") != "FROZEN":
            reasons.append("G0_CONTRACT is not frozen")
        if boundary.get("allowed_through_step") not in {"C02", "C06"}:
            reasons.append("current boundary does not include the C02 contract scope")
        if boundary.get("hard_stop_before_step") not in {"C03", "C07"}:
            reasons.append("current hard stop is not a registered C02/C06 boundary")
        if gates.get("G0_CONTRACT", {}).get("unresolved_runtime_default_policy") != "FORBIDDEN":
            reasons.append("unresolved runtime defaults are not forbidden")
        by_id = {
            item.get("id"): item
            for item in registry.get("decisions", [])
            if isinstance(item, Mapping)
        }
        reasons.extend(
            _validate_required_subdecisions(
                by_id, _C02_REQUIRED_SUBDECISIONS, label="C02"
            )
        )
    elif level == "c02_exit":
        contract_report = validate_open_decisions(registry, level="c02_contract")
        reasons.extend(contract_report.reasons)
        reasons.extend(
            _validate_toolchain(
                registry.get("c02_toolchain_and_lock", {}), project_root=project_root
            )
        )
    elif level == "design_validation":
        if gates.get("G0_SCIENCE", {}).get("status") != "FROZEN":
            reasons.append("G0_SCIENCE is unresolved")
        if registry.get("protocol_generation") != "FROZEN":
            reasons.append("protocol generation is unresolved")
        ad12 = registry.get("author_science_resolutions", {}).get("AD_12", {})
        if not isinstance(ad12, Mapping) or ad12.get("status") != "FROZEN":
            reasons.append("AD-12 counter and burn-in clarification is unresolved")
        by_id = {
            item.get("id"): item
            for item in registry.get("decisions", [])
            if isinstance(item, Mapping)
        }
        for decision_id in sorted(_G0_REQUIRED_AGGREGATES - {"O-08"}):
            if not _frozen_mapping(by_id.get(decision_id)):
                reasons.append(f"{decision_id}: required G0 aggregate is not frozen")
        reasons.extend(_validate_o02_composition(by_id.get("O-02")))
        reasons.extend(_validate_o05_composition(by_id.get("O-05")))
        reasons.extend(_validate_o06_composition(by_id.get("O-06")))
        reasons.extend(_validate_o07_composition(by_id.get("O-07")))
        reasons.extend(
            _validate_required_subdecisions(
                by_id, _G0_REQUIRED_SUBDECISIONS, label="G0"
            )
        )
        reasons.extend(
            _validate_static_capacity_certificate(
                by_id.get("O-05"), project_root=project_root
            )
        )
        reasons.extend(
            _validate_o08_resolution(
                by_id.get("O-08"), o10_decision=by_id.get("O-10")
            )
        )
    else:
        raise DecisionValidationError(f"unsupported validation level: {level}")
    return DecisionValidationReport(level=level, passed=not reasons, reasons=tuple(reasons))
