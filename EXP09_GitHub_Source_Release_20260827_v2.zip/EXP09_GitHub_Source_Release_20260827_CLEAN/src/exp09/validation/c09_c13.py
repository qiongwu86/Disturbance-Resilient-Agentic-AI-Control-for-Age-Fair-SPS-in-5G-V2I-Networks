"""C09-C13 mechanism and readiness bundle validation."""

from collections.abc import Mapping
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path, PurePosixPath
from typing import Any


@dataclass(frozen=True, slots=True)
class C09C13BundleValidationReport:
    passed: bool
    reasons: tuple[str, ...]


_MANIFEST_LOCATOR = "protocol/c09_c13/c09_c13_manifest.json"
_REPORT_MARKERS = {
    "protocol/evidence/G3_G4_c09_detector_calibration_report.md": (
        "REPORT_ID: g3_g4_c09_detector_calibration",
        "STATUS: G3_G4_MECHANISM_UNIT_PASSED",
        "G3_GATE_STATUS: PASSED",
        "G4_GATE_STATUS: PASSED",
        "C09_MAE_RULE: COMPLETE_RESIDUAL_ARITHMETIC_MEAN",
        "MEMORY_HASH_RESEALING: REJECTED",
        "validate_c09_c13_bundle=PASS",
    ),
    "protocol/evidence/G5P_c10_c11_provider_propagation_report.md": (
        "REPORT_ID: g5p_c10_c11_provider_propagation",
        "STATUS: G5P_PREFLIGHT_MECHANISM_PASSED",
        "G5P_GATE_STATUS: PASSED",
        "PROVIDER_RESPONSE_HASH: SEMANTIC_CONTENT_BOUND",
        "OFFLINE_REPLAY_DUPLICATE_REQUEST: REJECTED",
        "validate_c09_c13_bundle=PASS",
    ),
    "protocol/evidence/C12_baseline_qualification_report.md": (
        "REPORT_ID: c12_baseline_qualification",
        "STATUS: B_ALL_PIPELINE_QUALIFIED_NO_PERFORMANCE_CLAIM",
        "BASELINE_QUALIFICATION_STATUS: PASSED",
        "C12_REAL_TRAINING_STATUS: NOT_STARTED_SYNTHETIC_SCHEMA_ONLY",
        "TRAINING_MANIFEST_HASH: SEMANTIC_CONTENT_BOUND",
        "REPORT_LIFECYCLE: SUPERSEDED_AS_CURRENT_C12_STATUS_BY_C12_real_training_qualification_report_20260728",
        "validate_c09_c13_bundle=PASS",
    ),
    "protocol/evidence/C13_stats_readiness_report.md": (
        "REPORT_ID: c13_stats_readiness",
        "STATUS: STATS_READINESS_SYNTHETIC_PASSED",
        "STATS_READINESS_STATUS: PASSED",
        "ROOT_PAIRING_STATUS: SYNTHETIC_KNOWN_RESULT_PASSED",
        "PUBLIC_PRIVATE_BLINDING_STATUS: SEPARATED",
        "REVIEWER_EVIDENCE_SCHEMA_STATUS: CLOSED_PENDING_ONLY",
        "MARGIN_DEPENDENT_GATES: NOT_ASSESSABLE_NO_MARGIN",
        "validate_c09_c13_bundle=PASS",
    ),
}
_EXPECTED_ARTIFACTS = frozenset(
    {
        *_REPORT_MARKERS,
        "src/exp09/control/detector.py",
        "src/exp09/supervisor/programs.py",
        "src/exp09/supervisor/providers.py",
        "src/exp09/baselines/training_pipeline.py",
        "src/exp09/evaluation/stats.py",
        "src/exp09/validation/c09_c13.py",
        "tests/c09_c13/test_c09_detector_memory.py",
        "tests/c09_c13/test_c10_c11_supervisor.py",
        "tests/c09_c13/test_c12_training_pipeline.py",
        "tests/c09_c13/test_c13_stats_readiness.py",
    }
)
_HEX_DIGITS = frozenset("0123456789abcdefABCDEF")
_FORBIDDEN_MARKERS = (
    '"method_execution_allowed": true',
    '"method_comparison_allowed": true',
    '"training_allowed": true',
    '"api_allowed": true',
    '"performance_claim_allowed": true',
    "METHOD_PERFORMANCE_ESTABLISHED",
    "AGENT_OUTPERFORMS_BASELINES",
    "LLM_ADDS_VALUE",
    "FAIRNESS_IMPROVEMENT",
    "NONINFERIOR_OR_NONHARM",
    "COMPARABLE_OR_EQUIVALENT",
    "ALL_BASELINE_BEST",
    "REAL_TIME_FEASIBLE",
    "DEPLOYMENT_FEASIBLE",
)
_FORBIDDEN_ENABLEMENT_PATTERNS = (
    "method_execution_allowed: true",
    "method_execution_allowed=true",
    "method_comparison_allowed: true",
    "method_comparison_allowed=true",
    "training_allowed: true",
    "training_allowed=true",
    "api_allowed: true",
    "api_allowed=true",
    "performance_claim_allowed: true",
    "performance_claim_allowed=true",
)


def validate_c09_c13_bundle(project_root: Path) -> C09C13BundleValidationReport:
    project_root = project_root.resolve()
    reasons: list[str] = []
    path = project_root / _MANIFEST_LOCATOR
    if not path.is_file():
        return C09C13BundleValidationReport(False, (f"{_MANIFEST_LOCATOR}: missing",))
    try:
        manifest = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return C09C13BundleValidationReport(False, (f"{_MANIFEST_LOCATOR}: invalid JSON",))
    _validate_manifest(manifest, project_root, reasons)
    _validate_reports(project_root, reasons)
    return C09C13BundleValidationReport(passed=not reasons, reasons=tuple(reasons))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def _is_sha256(value: Any) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(character in _HEX_DIGITS for character in value)
    )


def _safe_locator(locator: Any) -> bool:
    if not isinstance(locator, str) or not locator or "\\" in locator:
        return False
    path = PurePosixPath(locator)
    return not path.is_absolute() and ".." not in path.parts and ":" not in path.parts[0]


def _float_paths(value: Any, *, path: str = "root") -> tuple[str, ...]:
    found: list[str] = []
    if isinstance(value, float):
        found.append(path)
    elif isinstance(value, Mapping):
        for key, child in value.items():
            found.extend(_float_paths(child, path=f"{path}.{key}"))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            found.extend(_float_paths(child, path=f"{path}[{index}]"))
    return tuple(found)


def _validate_manifest(record: Any, project_root: Path, reasons: list[str]) -> None:
    if not isinstance(record, Mapping):
        reasons.append("C09-C13 manifest must be a JSON object")
        return
    expected = {
        "schema_version": "exp09-c09-c13-manifest-v1",
        "status": "C13_STATS_READINESS_PASSED",
        "completed_through_step": "C13",
        "hard_stop_before_step": "C14",
        "method_execution_allowed": False,
        "method_comparison_allowed": False,
        "training_allowed": False,
        "api_allowed": False,
        "shadow_precision_locked_allowed": False,
        "performance_claim_allowed": False,
    }
    for key, value in expected.items():
        if record.get(key) != value:
            reasons.append(f"C09-C13 manifest {key} mismatch")
    for float_path in _float_paths(record):
        reasons.append(f"C09-C13 manifest float is forbidden at {float_path}")
    artifacts = record.get("artifacts")
    if not isinstance(artifacts, list):
        reasons.append("C09-C13 manifest artifacts must be a list")
        return
    locators = [
        artifact.get("locator") if isinstance(artifact, Mapping) else None
        for artifact in artifacts
    ]
    if len(locators) != len(set(locators)):
        reasons.append("C09-C13 manifest contains duplicate locators")
    if frozenset(locators) != _EXPECTED_ARTIFACTS:
        reasons.append("C09-C13 manifest artifact set mismatch")
    for artifact in artifacts:
        locator = artifact.get("locator") if isinstance(artifact, Mapping) else None
        expected_hash = artifact.get("sha256") if isinstance(artifact, Mapping) else None
        if not _safe_locator(locator):
            reasons.append("C09-C13 manifest contains an unsafe locator")
            continue
        path = project_root / locator
        if not path.is_file():
            reasons.append(f"C09-C13 manifest artifact missing: {locator}")
        elif not _is_sha256(expected_hash):
            reasons.append(f"C09-C13 manifest hash is invalid: {locator}")
        elif _sha256(path) != expected_hash:
            reasons.append(f"C09-C13 manifest hash mismatch: {locator}")


def _validate_reports(project_root: Path, reasons: list[str]) -> None:
    for locator, markers in _REPORT_MARKERS.items():
        path = project_root / locator
        if not path.is_file():
            reasons.append(f"{locator}: missing")
            continue
        text = path.read_text(encoding="utf-8")
        for marker in markers:
            if marker not in text:
                reasons.append(f"{locator}: missing marker {marker}")
        for marker in _FORBIDDEN_MARKERS:
            if marker in text:
                reasons.append(f"{locator}: forbidden marker {marker}")
        lowered = text.lower()
        for marker in _FORBIDDEN_ENABLEMENT_PATTERNS:
            if marker in lowered:
                reasons.append(f"{locator}: forbidden enablement marker {marker}")
