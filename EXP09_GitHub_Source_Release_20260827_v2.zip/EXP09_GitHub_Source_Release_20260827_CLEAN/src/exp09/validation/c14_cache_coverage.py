"""Independent exact-coverage audit for C14.1 offline cache bundles."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re
from typing import Any

_SHA256 = re.compile(r"[0-9A-Fa-f]{64}")
_BUNDLE_SCHEMA = "exp09-c14-1-offline-cache-bundle-v1"
_INVENTORY_SCHEMA = "exp09-c14-1-request-inventory-v1"
_RECORD_SCHEMA = "exp09-c14-1-request-record-v1"
_PLAIN_INPUT_SCHEMA = "exp09-c14-1-plain-llm-input-v1"
_PLAIN_OUTPUT_SCHEMA = "exp09-c14-1-plain-llm-output-v1"
_PLAIN_REQUEST_DOMAIN = "exp09-c14-1-plain-llm-request-v1"


class CacheCoverageError(ValueError):
    """Raised when request provenance, response content, or coverage is invalid."""


@dataclass(frozen=True, slots=True)
class OfflineCacheCoverageReport:
    method_id: str
    namespace: str
    expected_request_count: int
    entry_count: int
    duplicate_request_hash_count: int
    missing_request_hashes: tuple[str, ...]
    unexpected_request_hashes: tuple[str, ...]
    qualified: bool


def validate_offline_cache_coverage(
    project_root: Path,
    bundle_locator: str,
    *,
    expected_bundle_sha256: str,
    expected_method_id: str,
    expected_namespace: str,
    expected_method_config_sha256: str,
    expected_protocol_sha256: str,
    expected_request_hashes: tuple[str, ...],
) -> OfflineCacheCoverageReport:
    """Validate the legacy bundle contract and return exact-set coverage evidence."""

    root = project_root.resolve()
    for value, field in (
        (expected_bundle_sha256, "bundle SHA-256"),
        (expected_method_config_sha256, "method config SHA-256"),
        (expected_protocol_sha256, "protocol SHA-256"),
    ):
        _require_sha(value, field)
    if not expected_request_hashes or len(set(expected_request_hashes)) != len(
        expected_request_hashes
    ):
        raise CacheCoverageError("expected request hashes must be non-empty and unique")
    for request_hash in expected_request_hashes:
        _require_sha(request_hash, "expected request hash")
    path = _resolve(root, bundle_locator)
    if _sha(path) != expected_bundle_sha256:
        raise CacheCoverageError("offline cache bundle SHA-256 mismatch")
    bundle = _strict_json(path)
    if not isinstance(bundle, dict) or bundle.get("schema_version") != _BUNDLE_SCHEMA:
        raise CacheCoverageError("offline cache bundle schema mismatch")
    if bundle.get("method_id") != expected_method_id:
        raise CacheCoverageError("offline cache method identity mismatch")
    if bundle.get("namespace") != expected_namespace:
        raise CacheCoverageError("offline cache namespace mismatch")
    if bundle.get("network_fallback") is not False or any(
        bundle.get(field) != 0 for field in ("api_calls", "provider_calls", "llm_tokens")
    ):
        raise CacheCoverageError("offline cache permits online consumption")
    bindings = bundle.get("bindings", {})
    if bindings.get("method_config_sha256") != expected_method_config_sha256:
        raise CacheCoverageError("offline cache method-config binding mismatch")
    if bindings.get("protocol_sha256") != expected_protocol_sha256:
        raise CacheCoverageError("offline cache protocol binding mismatch")
    provenance = bundle.get("provenance", {})
    source_locator = provenance.get("source_artifact_locator")
    source_sha256 = provenance.get("source_artifact_sha256")
    _require_sha(source_sha256, "source artifact SHA-256")
    if _sha(_resolve(root, source_locator)) != source_sha256:
        raise CacheCoverageError("offline cache source-artifact SHA-256 mismatch")
    coverage = bundle.get("coverage", {})
    if coverage.get("status") != "COMPLETE":
        raise CacheCoverageError("offline cache coverage status is not COMPLETE")
    if coverage.get("required_request_hashes") != list(expected_request_hashes):
        raise CacheCoverageError("offline cache required-request coverage mismatch")
    entries = bundle.get("entries")
    if not isinstance(entries, list):
        raise CacheCoverageError("offline cache entries must be a list")
    actual: list[str] = []
    for entry in entries:
        if not isinstance(entry, dict):
            raise CacheCoverageError("offline cache entry must be an object")
        request_hash = entry.get("request_hash")
        if not isinstance(entry.get("response"), dict):
            raise CacheCoverageError("offline cache response must be an object")
        _require_sha(request_hash, "cache entry request hash")
        actual.append(request_hash)
    duplicate_count = len(actual) - len(set(actual))
    if duplicate_count:
        raise CacheCoverageError("offline cache contains duplicate request hashes")
    expected_set = set(expected_request_hashes)
    actual_set = set(actual)
    if tuple(actual) != expected_request_hashes:
        raise CacheCoverageError("offline cache entries do not exactly cover required requests")
    return OfflineCacheCoverageReport(
        method_id=expected_method_id,
        namespace=expected_namespace,
        expected_request_count=len(expected_request_hashes),
        entry_count=len(actual),
        duplicate_request_hash_count=duplicate_count,
        missing_request_hashes=tuple(sorted(expected_set - actual_set)),
        unexpected_request_hashes=tuple(sorted(actual_set - expected_set)),
        qualified=True,
    )


def validate_cache_bundle_against_inventory(
    project_root: Path,
    inventory_locator: str,
    bundle_locator: str,
    *,
    expected_inventory_sha256: str,
    expected_bundle_sha256: str,
    expected_method_id: str,
    expected_namespace: str,
    expected_method_config_sha256: str,
    expected_protocol_sha256: str,
    allow_synthetic_fixture: bool = False,
) -> OfflineCacheCoverageReport:
    """Qualify response content and exact coverage against a hash-bound inventory."""

    root = project_root.resolve()
    inventory_path = _resolve(root, inventory_locator)
    if _sha(inventory_path) != expected_inventory_sha256:
        raise CacheCoverageError("request inventory SHA-256 mismatch")
    inventory = _strict_json(inventory_path)
    if not isinstance(inventory, dict) or inventory.get("schema_version") != _INVENTORY_SCHEMA:
        raise CacheCoverageError("request inventory schema mismatch")
    allowed_status = (
        "SYNTHETIC_FIXTURE_ONLY_NOT_REAL_C14_1_COVERAGE"
        if allow_synthetic_fixture
        else "MATERIALIZED_FROM_AUTHORIZED_C14_1_CASES"
    )
    if inventory.get("artifact_status") != allowed_status:
        raise CacheCoverageError("request inventory provenance status is not allowed")
    for field, expected in (
        ("method_id", expected_method_id),
        ("namespace", expected_namespace),
        ("method_config_sha256", expected_method_config_sha256),
        ("protocol_sha256", expected_protocol_sha256),
    ):
        if inventory.get(field) != expected:
            raise CacheCoverageError(f"request inventory {field} mismatch")
    records = inventory.get("records")
    hashes = inventory.get("request_hashes")
    if not isinstance(records, list) or not isinstance(hashes, list) or not records:
        raise CacheCoverageError("request inventory records are missing")
    if inventory.get("request_count") != len(records):
        raise CacheCoverageError("request inventory count mismatch")
    if inventory.get("records_sha256") != _canonical_sha(records):
        raise CacheCoverageError("request inventory records SHA-256 mismatch")
    actual_hashes = [
        _validate_inventory_record(record, expected_method_id, expected_protocol_sha256)
        for record in records
    ]
    if hashes != actual_hashes or len(set(hashes)) != len(hashes):
        raise CacheCoverageError("request inventory ordering or uniqueness mismatch")
    report = validate_offline_cache_coverage(
        root,
        bundle_locator,
        expected_bundle_sha256=expected_bundle_sha256,
        expected_method_id=expected_method_id,
        expected_namespace=expected_namespace,
        expected_method_config_sha256=expected_method_config_sha256,
        expected_protocol_sha256=expected_protocol_sha256,
        expected_request_hashes=tuple(hashes),
    )
    bundle = _strict_json(_resolve(root, bundle_locator))
    for record, entry in zip(records, bundle["entries"], strict=True):
        if set(entry) != {"request_hash", "response", "response_binding_sha256"}:
            raise CacheCoverageError("cache entry fields do not match qualification schema")
        binding = _canonical_sha(
            {"request_hash": entry["request_hash"], "response": entry["response"]}
        )
        if entry["response_binding_sha256"] != binding:
            raise CacheCoverageError("cache response binding SHA-256 mismatch")
        _validate_method_response(expected_method_id, record, entry["response"])
    return report


def _validate_inventory_record(record: Any, method_id: str, protocol_sha256: str) -> str:
    fields = {
        "schema_version",
        "method_id",
        "namespace",
        "request_hash",
        "request_payload",
        "opportunity_id",
        "causal_cutoff_us",
    }
    if not isinstance(record, dict) or set(record) != fields:
        raise CacheCoverageError("request inventory record fields mismatch")
    if record["schema_version"] != _RECORD_SCHEMA or record["method_id"] != method_id:
        raise CacheCoverageError("request inventory record identity mismatch")
    payload = record["request_payload"]
    if method_id == "Plain_LLM":
        input_payload = payload.get("input")
        if not isinstance(input_payload, dict) or input_payload.get("schema_version") != (
            _PLAIN_INPUT_SCHEMA
        ):
            raise CacheCoverageError("Plain_LLM inventory input schema mismatch")
        input_sha = _canonical_sha(input_payload)
        action_ids = tuple(input_payload.get("eligible_actions", ()))
        eligible_sha = _stable_digest(
            "exp09-c14-1-eligible-action-set-v1", len(action_ids), *action_ids
        )
        if payload.get("input_sha256") != input_sha or payload.get(
            "eligible_action_set_sha256"
        ) != eligible_sha:
            raise CacheCoverageError("Plain_LLM inventory input binding mismatch")
        expected_hash = _stable_digest(
            _PLAIN_REQUEST_DOMAIN,
            protocol_sha256,
            input_sha,
            eligible_sha,
            record["namespace"],
            0,
        )
    else:
        evidence = payload.get("evidence")
        evidence_fields = {
            "schema_version",
            "evidence_id",
            "causal_cutoff_us",
            "detector_active",
            "risk_ppm",
            "memory_interval_low_ppm",
            "memory_interval_high_ppm",
        }
        if not isinstance(evidence, dict) or set(evidence) != evidence_fields:
            raise CacheCoverageError("Full inventory evidence fields mismatch")
        evidence_hash = _stable_digest(
            "exp09-evidence-bundle-v1",
            evidence["evidence_id"],
            evidence["causal_cutoff_us"],
            evidence["detector_active"],
            evidence["risk_ppm"],
            evidence["memory_interval_low_ppm"],
            evidence["memory_interval_high_ppm"],
        )
        if payload.get("evidence_hash") != evidence_hash:
            raise CacheCoverageError("Full inventory evidence hash mismatch")
        expected_hash = _stable_digest(
            "exp09-provider-request-v1",
            payload.get("request_id"),
            payload.get("config_hash"),
            payload.get("evidence_hash"),
            payload.get("namespace"),
            payload.get("attempt_ordinal"),
        )
    if record["request_hash"] != expected_hash:
        raise CacheCoverageError("request inventory record hash mismatch")
    return expected_hash


def _validate_method_response(method_id: str, record: dict[str, Any], response: Any) -> None:
    if not isinstance(response, dict):
        raise CacheCoverageError("cache response must be a JSON object")
    if method_id == "Plain_LLM":
        expected_keys = {
            "schema_version",
            "candidate_order",
            "chosen_action_id",
            "confidence_ppm",
            "rationale_code",
        }
        if set(response) != expected_keys or response["schema_version"] != _PLAIN_OUTPUT_SCHEMA:
            raise CacheCoverageError("Plain_LLM response schema mismatch")
        action_ids = tuple(record["request_payload"]["input"]["eligible_actions"])
        order = response["candidate_order"]
        if not isinstance(order, list) or sorted(order) != sorted(action_ids):
            raise CacheCoverageError("Plain_LLM candidate order is not an exact permutation")
        if len(order) != len(set(order)) or response["chosen_action_id"] != order[0]:
            raise CacheCoverageError("Plain_LLM selected action is inconsistent")
        confidence = response["confidence_ppm"]
        if isinstance(confidence, bool) or not isinstance(confidence, int) or not (
            0 <= confidence <= 1_000_000
        ):
            raise CacheCoverageError("Plain_LLM confidence is invalid")
        if response["rationale_code"] not in {
            "FRESHNESS_PRIORITY",
            "COLLISION_RISK_PRIORITY",
            "BALANCED_OBSERVABLE_TRADEOFF",
            "INSUFFICIENT_OBSERVABLE_EVIDENCE",
        }:
            raise CacheCoverageError("Plain_LLM rationale code is invalid")
        return
    if set(response) != {"proposal", "response_hash"} or not isinstance(
        response["proposal"], dict
    ):
        raise CacheCoverageError("Full response fields mismatch")
    proposal = response["proposal"]
    if set(proposal) != {"transition_id", "target_program_id", "rationale_code"}:
        raise CacheCoverageError("Full proposal fields mismatch")
    if proposal["transition_id"] not in {"START", "HOLD", "ADVANCE", "SWITCH", "RETURN_BALANCED"}:
        raise CacheCoverageError("Full transition identifier is invalid")
    if proposal["rationale_code"] not in {
        "NO_CHANGE",
        "EVIDENCE_SUPPORTED_TRANSITION",
        "HOLD_UNCERTAIN_EVIDENCE",
        "RETURN_TO_BALANCED",
    }:
        raise CacheCoverageError("Full rationale code is invalid")
    target = "NONE" if proposal["target_program_id"] is None else proposal["target_program_id"]
    response_hash = _stable_digest(
        "exp09-provider-response-v1",
        record["request_hash"],
        proposal["transition_id"],
        target,
        proposal["rationale_code"],
    )
    if response["response_hash"] != response_hash:
        raise CacheCoverageError("Full response content hash mismatch")


def _stable_digest(*parts: Any) -> str:
    typed = []
    for part in parts:
        if part is None:
            typed.append({"type": "null", "value": None})
        elif isinstance(part, bool):
            typed.append({"type": "bool", "value": part})
        elif isinstance(part, int):
            typed.append({"type": "int", "value": part})
        elif isinstance(part, str):
            typed.append({"type": "str", "value": part})
        else:
            raise CacheCoverageError("unsupported deterministic request-hash part")
    payload = json.dumps(
        typed, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest().upper()


def _resolve(root: Path, locator: Any) -> Path:
    if not isinstance(locator, str) or not locator or "\\" in locator:
        raise CacheCoverageError("cache qualification locator is invalid")
    path = (root / locator).resolve()
    try:
        path.relative_to(root)
    except ValueError as exc:
        raise CacheCoverageError("cache qualification locator escapes project root") from exc
    if not path.is_file():
        raise CacheCoverageError(f"cache qualification artifact missing: {locator}")
    return path


def _strict_json(path: Path) -> Any:
    def reject_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise CacheCoverageError(f"duplicate JSON key is forbidden: {key}")
            result[key] = value
        return result

    try:
        return json.loads(
            path.read_text(encoding="utf-8"),
            object_pairs_hook=reject_duplicates,
            parse_constant=lambda value: (_ for _ in ()).throw(
                CacheCoverageError(f"non-finite JSON value is forbidden: {value}")
            ),
        )
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise CacheCoverageError("cache qualification artifact is not strict UTF-8 JSON") from exc


def _canonical_sha(value: Any) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest().upper()


def _require_sha(value: Any, field: str) -> None:
    if not isinstance(value, str) or _SHA256.fullmatch(value) is None:
        raise CacheCoverageError(f"{field} must be a SHA-256 digest")


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()
