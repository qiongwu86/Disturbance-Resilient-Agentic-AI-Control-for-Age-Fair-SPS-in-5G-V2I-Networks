"""Independent fail-closed audit for the prepared C14.1 execution preflight."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

MANIFEST_LOCATOR = "protocol/c14/c14_1_executable_preflight_manifest.FROZEN_20260729.json"
EVIDENCE_INDEX_LOCATOR = (
    "protocol/c14/c14_1_executable_preflight_evidence_index_20260729.json"
)
TOPOLOGY_LOCATOR = "protocol/c14/c14_1_method_case_topology.FROZEN_PREFLIGHT_20260729.json"
LEDGER_PLAN_LOCATOR = "protocol/c14/c14_1_run_ledger_plan.FROZEN_PREFLIGHT_20260729.json"
REQUEST_PROTOCOL_LOCATOR = (
    "protocol/c14/c14_1_offline_request_inventory_protocol.FROZEN_PREFLIGHT_20260729.json"
)
_METHODS = (
    "Full",
    "RMPC_SameEvaluator",
    "Rule_SameStack",
    "TunedNonLLM_SameStack",
    "Plain_LLM",
    "DQN",
    "DQN_Strong",
    "GNN_DDQN",
    "KEEP_sanity",
    "AoI_aware_heuristic",
    "Greedy_1",
    "Nominal_MPC",
)
_RL_METHODS = ("DQN", "DQN_Strong", "GNN_DDQN")
_RL_SEEDS = (101, 202, 303, 404, 505)
_ARMS = ("REFERENCE", "EVENT")
_MODEL_METHODS = frozenset(
    {"Full", "RMPC_SameEvaluator", "Rule_SameStack", "TunedNonLLM_SameStack", "Greedy_1", "Nominal_MPC"}
)


def validate_c14_1_executable_preflight(project_root: Path) -> dict[str, Any]:
    root = project_root.resolve()
    reasons: list[str] = []
    try:
        topology = _load_json(root / TOPOLOGY_LOCATOR)
        cases = _expand_topology(root, topology)
    except Exception as exc:
        return _report((f"frozen topology validation failed: {exc}",))
    topology_sha = _sha(root / TOPOLOGY_LOCATOR)
    if len(cases) != 2304 or len({case["case_id"] for case in cases}) != 2304:
        reasons.append("topology does not expand to exactly 2,304 unique method cases")
    ledger_plan = _load_json(root / LEDGER_PLAN_LOCATOR)
    rows = [_planned_row(case, topology["method_config_binding"]["sha256"], topology_sha) for case in cases]
    expected_caps = {
        "method_cases": 2304,
        "environment_steps": 55296,
        "model_transitions": 995328000,
        "cpu_core_seconds": 518400,
        "wall_seconds": 345600,
        "storage_bytes": 16106127360,
        "concurrency": 1,
        "gpu_seconds": 0,
        "api_calls": 0,
        "provider_calls": 0,
        "llm_tokens": 0,
    }
    zero_usage = {field: 0 for field in expected_caps}
    expected_plan = {
        "schema_version": "exp09-c14-1-run-ledger-v1",
        "artifact_status": "PREFLIGHT_PLAN_ONLY",
        "execution_authorized": False,
        "topology_sha256": topology_sha,
        "planned_method_cases": 2304,
        "row_count": 2304,
        "budget_caps": expected_caps,
        "budget_usage": zero_usage,
        "rows_sha256": _canonical_sha(rows),
    }
    for field, expected in expected_plan.items():
        if ledger_plan.get(field) != expected:
            reasons.append(f"ledger plan field mismatch: {field}")
    request_protocol = _load_json(root / REQUEST_PROTOCOL_LOCATOR)
    state = request_protocol.get("current_state", {})
    if any(state.get(field) is not False for field in state):
        reasons.append("request/cache protocol claims materialized or qualified real cache")
    coverage = request_protocol.get("coverage_contract", {})
    if coverage.get("network_fallback") is not False or any(
        coverage.get(field) != 0 for field in ("api_calls", "provider_calls", "llm_tokens")
    ):
        reasons.append("request/cache protocol permits online fallback")
    manifest = _load_json(root / MANIFEST_LOCATOR)
    terminal = {
        "execution_authorized": False,
        "cache_qualified": False,
        "execution_started": False,
        "executed_method_cases": 0,
        "api_provider_llm_calls": 0,
        "training_capability": "DISABLED",
        "self_authorization_forbidden": True,
    }
    for field, expected in terminal.items():
        if manifest.get(field) != expected:
            reasons.append(f"executable preflight terminal field mismatch: {field}")
    _audit_bindings(root, manifest.get("bindings"), reasons)
    evidence_index = _load_json(root / EVIDENCE_INDEX_LOCATOR)
    evidence_terminal = {
        "c14_1_execution_authorized": False,
        "cache_qualified": False,
        "execution_started": False,
        "executed_method_cases": 0,
        "api_provider_llm_calls": 0,
        "training_capability": "DISABLED",
    }
    for field, expected in evidence_terminal.items():
        if evidence_index.get("terminal_state", {}).get(field) != expected:
            reasons.append(f"executable preflight evidence terminal mismatch: {field}")
    _audit_bindings(root, evidence_index.get("artifacts"), reasons)
    if (root / "artifacts/c14_1_design_validation").exists():
        reasons.append("real C14.1 method-case artifact directory exists")
    return _report(tuple(reasons))


def _expand_topology(root: Path, topology: dict[str, Any]) -> list[dict[str, Any]]:
    if topology.get("execution_authorized") is not False:
        raise ValueError("topology can authorize execution")
    if topology.get("methods") != list(_METHODS) or topology.get("arms") != list(_ARMS):
        raise ValueError("topology method/arm order mismatch")
    roots_document = _load_bound(root, topology.get("design_roots_binding"))
    checkpoints_document = _load_bound(root, topology.get("checkpoint_registry_binding"))
    config_binding = topology.get("method_config_binding")
    _load_bound(root, config_binding)
    roots = roots_document.get("roots")
    if not isinstance(roots, list) or len(roots) != 48 or len(set(roots)) != 48:
        raise ValueError("topology root set mismatch")
    checkpoint_map = {
        (entry["method_id"], entry["train_seed"]): entry
        for entry in checkpoints_document.get("entries", ())
    }
    if set(checkpoint_map) != {(method, seed) for method in _RL_METHODS for seed in _RL_SEEDS}:
        raise ValueError("topology checkpoint identities mismatch")
    cases: list[dict[str, Any]] = []
    for root_case_id in roots:
        for arm in _ARMS:
            for method_id in _METHODS:
                for train_seed in (_RL_SEEDS if method_id in _RL_METHODS else (None,)):
                    checkpoint = checkpoint_map.get((method_id, train_seed))
                    if checkpoint is not None and (
                        checkpoint.get("scenario") != "complex"
                        or checkpoint.get("arms") != list(_ARMS)
                    ):
                        raise ValueError("checkpoint arm/scenario binding mismatch")
                    variant = f"complex_seed{train_seed}" if train_seed is not None else "fixed"
                    cases.append(
                        {
                            "ordinal": len(cases),
                            "case_id": f"{root_case_id}__{arm}__{method_id}__{variant}",
                            "root_case_id": root_case_id,
                            "root_namespace": "exp09-c14-1-design-root-v1",
                            "arm": arm,
                            "scenario": "nominal_fixed" if arm == "REFERENCE" else "influx_event",
                            "method_id": method_id,
                            "variant_id": variant,
                            "train_seed": train_seed,
                            "checkpoint_sha256": None if checkpoint is None else checkpoint["sha256"],
                            "checkpoint_locator": None if checkpoint is None else checkpoint["relative_path"],
                            "transitions_per_opportunity": 72000 if method_id in _MODEL_METHODS else 0,
                        }
                    )
    if topology.get("entries_sha256") != _canonical_sha(cases):
        raise ValueError("expanded topology SHA-256 mismatch")
    return cases


def _planned_row(case: dict[str, Any], config_sha: str, topology_sha: str) -> dict[str, Any]:
    return {
        "schema_version": "exp09-c14-1-run-ledger-row-v2",
        "run_id": f"{case['case_id']}__attempt000",
        "case_id": case["case_id"],
        "attempt_ordinal": 0,
        "phase": "C14.1_DESIGN_VALIDATION",
        "root_family": case["root_case_id"],
        "root_namespace": case["root_namespace"],
        "arm": case["arm"],
        "scenario": case["scenario"],
        "method_id": case["method_id"],
        "variant_id": case["variant_id"],
        "train_seed": case["train_seed"],
        "config_sha256": config_sha,
        "checkpoint_sha256": case["checkpoint_sha256"],
        "topology_sha256": topology_sha,
        "status": "PLANNED",
        "started_at": None,
        "ended_at": None,
        "environment_steps": 0,
        "model_transitions": 0,
        "api_calls": 0,
        "provider_calls": 0,
        "llm_tokens": 0,
        "cpu_core_seconds": 0,
        "gpu_seconds": 0,
        "wall_seconds": 0,
        "storage_bytes": 0,
        "error_code": None,
        "artifact_sha256": None,
        "resume_of": None,
        "abort_reason": None,
    }


def _load_bound(root: Path, binding: Any) -> dict[str, Any]:
    if not isinstance(binding, dict) or set(binding) != {"locator", "sha256"}:
        raise ValueError("topology source binding is malformed")
    path = (root / binding["locator"]).resolve()
    if not path.is_file() or _sha(path) != binding["sha256"]:
        raise ValueError(f"topology source binding mismatch: {binding['locator']}")
    return _load_json(path)


def _audit_bindings(root: Path, bindings: Any, reasons: list[str]) -> None:
    if not isinstance(bindings, list) or not bindings:
        reasons.append("executable preflight bindings are missing")
        return
    seen: set[str] = set()
    for binding in bindings:
        if not isinstance(binding, dict) or set(binding) != {"role", "locator", "sha256"}:
            reasons.append("executable preflight binding is malformed")
            continue
        locator = binding["locator"]
        path = (root / locator).resolve()
        if locator in seen or not path.is_file() or _sha(path) != binding["sha256"]:
            reasons.append(f"executable preflight binding mismatch: {locator}")
        seen.add(locator)


def _report(reasons: tuple[str, ...]) -> dict[str, Any]:
    return {
        "passed": not reasons,
        "artifact_status": (
            "EXECUTABLE_PREFLIGHT_PREPARED_CACHE_INPUT_ABSENT_HARD_STOP"
            if not reasons
            else "EXECUTABLE_PREFLIGHT_AUDIT_FAILED_HARD_STOP"
        ),
        "topology_method_cases": 2304 if not reasons else 0,
        "cache_qualified": False,
        "c14_1_execution_authorized": False,
        "execution_started": False,
        "executed_method_cases": 0,
        "api_provider_llm_calls": 0,
        "training_capability": "DISABLED",
        "reasons": reasons,
    }


def _load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path.name}")
    return value


def _canonical_sha(value: Any) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest().upper()


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()
