"""Fail-closed validation for the 20260728 C14 pre-freeze package."""

from __future__ import annotations

from collections.abc import Mapping
import hashlib
import json
from pathlib import Path, PurePosixPath
import os
import subprocess
import sys
from typing import Any

import yaml

METHODS = (
    "Full",
    "RMPC_SameEvaluator",
    "Rule_SameStack",
    "TunedNonLLM_SameStack",
    "Plain_LLM",
    "DQN",
    "DQN_Strong",
    "GNN_DDQN",
    "KEEP_sanity",
    "AoI_aware_heuristic",
    "Greedy_1",
    "Nominal_MPC",
)
RL_METHODS = ("DQN", "DQN_Strong", "GNN_DDQN")
SEEDS = (101, 202, 303, 404, 505)
SCENARIOS = ("simple", "complex")
CURRENT_V2 = (
    "protocol/c14/checkpoint_registry.CANDIDATE_V2_20260728.json",
    "protocol/c14/method_config_inventory.PREFREEZE_V2_20260728.json",
    "protocol/c14/c14_1_design_validation_manifest.PREFREEZE_V2_20260728.json",
    "protocol/c14/c14_1_data_run_protocol.PREFREEZE_V2_20260728.json",
    "protocol/c14/c14_1_run_ledger_schema.CANDIDATE_V2_20260728.json",
    "protocol/c14/c14_1_run_ledger_row.schema.json",
    "protocol/c14/stats_config_inventory.PREFREEZE_V2_20260728.json",
    "protocol/c14/c14_1_budget_authorization_request_20260728.json",
    "protocol/c14/claim_boundary_check.V2_20260728.md",
    "protocol/c14/c14_history_supersession_20260728.json",
)
HISTORY = (
    "protocol/c14/c14_1_design_validation_manifest.DRAFT.json",
    "protocol/c14/method_config_inventory.DRAFT.json",
    "protocol/c14/checkpoint_registry.DRAFT.json",
    "protocol/c14/provider_profile_protocol.DRAFT.json",
    "protocol/c14/stats_config_inventory.DRAFT.json",
    "protocol/c14/run_ledger_budget_request.DRAFT.json",
    "protocol/c14/claim_boundary_check.DRAFT.md",
    "protocol/c14/c14_freeze_candidate_package.CANDIDATE.json",
    "protocol/c14/c14_freeze_candidate_manual_review_20260727.md",
    "protocol/evidence/C14_pre_freeze_preparation_package_20260727.md",
    "protocol/evidence/C14_pre_freeze_compliance_audit_report.md",
    "protocol/evidence/C08_C13_reaudit_pre_c14_handoff_20260727.md",
)
ENTRY_INDEX = "protocol/c14/c14_entry_evidence_index_20260728.json"
UNIFIED = "protocol/c14/c14_1_unified_authorization_package_20260728.json"
HEX = frozenset("0123456789abcdefABCDEF")


class C14PrefreezeError(ValueError):
    """Raised when a C14 pre-freeze invariant fails."""


def _sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def _json(root: Path, locator: str) -> Any:
    return json.loads((root / locator).read_text(encoding="utf-8"))


def _is_sha(value: Any) -> bool:
    return isinstance(value, str) and len(value) == 64 and all(char in HEX for char in value)


def _safe_locator(value: Any) -> bool:
    if not isinstance(value, str) or not value or "\\" in value:
        return False
    path = PurePosixPath(value)
    return not path.is_absolute() and ".." not in path.parts and ":" not in path.parts[0]


def _check_binding(root: Path, record: Mapping[str, Any], reasons: list[str], label: str) -> None:
    locator = record.get("locator")
    expected = record.get("sha256")
    if not _safe_locator(locator) or not _is_sha(expected):
        reasons.append(f"{label}: invalid hash-bound locator")
        return
    path = root / locator
    if not path.is_file():
        reasons.append(f"{label}: missing bound artifact {locator}")
    elif _sha(path) != expected:
        reasons.append(f"{label}: hash mismatch {locator}")


def _all_false(value: Any, *, path: str = "root") -> list[str]:
    reasons: list[str] = []
    if isinstance(value, Mapping):
        for key, child in value.items():
            lowered = str(key).lower()
            if lowered in {
                "execution_authorized", "c14_execution_authorized", "c14_1_execution_authorized",
                "method_identified_comparison_authorized", "training_authorized", "training_allowed",
                "api_allowed", "api_provider_profiling_authorized", "shadow_precision_locked_authorized",
                "shadow_precision_locked_allowed", "locked_test_authorized", "performance_claim_allowed",
                "method_execution_allowed", "method_comparison_allowed", "api_provider_profiling_allowed",
            } and child is not False:
                reasons.append(f"{path}.{key} must be false")
            reasons.extend(_all_false(child, path=f"{path}.{key}"))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            reasons.extend(_all_false(child, path=f"{path}[{index}]"))
    return reasons


def validate_c14_prefreeze(project_root: Path, *, verify_c12: bool = True) -> dict[str, Any]:
    """Validate current C14 artifacts without writing or executing anything."""

    root = project_root.resolve()
    reasons: list[str] = []
    if verify_c12:
        try:
            # Keep validation package dependency boundaries narrow while still
            # asking the canonical C12 auditor for a fresh, read-only result.
            env = os.environ.copy()
            env["PYTHONPATH"] = str(root / "src")
            probe = subprocess.run(
                [
                    sys.executable,
                    "-c",
                    "from pathlib import Path; import json; from exp09.baselines.audit_real_training import audit_c12_closed_state; print(json.dumps(audit_c12_closed_state(Path.cwd())))",
                ],
                cwd=root,
                env=env,
                check=True,
                capture_output=True,
                text=True,
                timeout=300,
            )
            c12 = json.loads(probe.stdout)
            if c12["artifact_status"] != "PASS_C12_COMPLETE_TRAINING_DISABLED_C14_HARD_STOP":
                reasons.append("fresh C12 closed-state audit did not pass")
        except Exception as exc:  # fail closed while retaining a useful reason
            reasons.append(f"fresh C12 closed-state audit failed: {exc}")
    for locator in CURRENT_V2 + (ENTRY_INDEX, UNIFIED):
        if not (root / locator).is_file():
            reasons.append(f"current C14 artifact missing: {locator}")
    if reasons:
        return {"passed": False, "reasons": tuple(reasons)}

    index = _json(root, ENTRY_INDEX)
    if index.get("artifact_status") != "C14_PREFREEZE_COMPLETE_HARD_STOP":
        reasons.append("entry index status is not hard-stopped")
    if index.get("current_authority") != "20260728_V2_ONLY":
        reasons.append("entry index does not designate 20260728 V2 as current authority")
    closure = index.get("c12_closure", {})
    expected_closure = {"completed_runs": 30, "formal_candidates": 375, "selected_checkpoints": 30, "training_capability": "DISABLED", "c14_execution_authorized": False, "performance_claim_allowed": False}
    for key, expected in expected_closure.items():
        if closure.get(key) != expected:
            reasons.append(f"entry C12 closure mismatch: {key}")
    for record in index.get("c12_bindings", []):
        _check_binding(root, record, reasons, "entry C12 binding")
    for record in index.get("current_v2_artifacts", []):
        _check_binding(root, record, reasons, "entry current artifact")
    _check_binding(root, index.get("current_disabled_execution_manifest", {}), reasons, "disabled execution manifest")
    _check_binding(root, index.get("enabled_manifest_archive", {}), reasons, "enabled manifest archive")

    candidate = _json(root, CURRENT_V2[0])
    entries = candidate.get("checkpoint_entries")
    expected_topology = {(method, seed, scenario) for method in RL_METHODS for seed in SEEDS for scenario in SCENARIOS}
    actual_topology = {(item.get("method_id"), item.get("train_seed"), item.get("scenario")) for item in entries or []}
    if len(entries or []) != 30 or actual_topology != expected_topology:
        reasons.append("checkpoint candidate topology is not exactly 3 x 5 x 2")
    if len({(item.get("method_id"), item.get("train_seed"), item.get("scenario")) for item in entries or []}) != len(entries or []):
        reasons.append("checkpoint candidate contains duplicate method/seed/scenario")
    if candidate.get("selection_constraints", {}).get("cross_seed_best_seed_selection") is not False:
        reasons.append("cross-seed best-seed selection is not disabled")
    for item in entries or []:
        path_value = item.get("relative_path")
        if not _safe_locator(path_value) or not _is_sha(item.get("sha256")):
            reasons.append("checkpoint entry has invalid path/hash")
            continue
        path = root / path_value
        if not path.is_file() or _sha(path) != item["sha256"]:
            reasons.append(f"checkpoint hash mismatch or missing: {path_value}")
        for key in ("manifest", "training_freeze"):
            _check_binding(root, item.get(key, {}), reasons, f"checkpoint {key} binding")
        if item.get("candidate_input_only") is not True or item.get("performance_or_claim_status") != "NOT_GENERATED" or item.get("locked_test_access") is not False:
            reasons.append("checkpoint candidate is not marked input-only")

    inventory = _json(root, CURRENT_V2[1])
    if inventory.get("method_count") != len(METHODS):
        reasons.append("method inventory count mismatch")
    inventory_ids = [item.get("method_id") for item in inventory.get("method_configs", [])]
    if tuple(inventory_ids) != METHODS:
        reasons.append("method inventory silently changes protocol method set")
    for item in inventory.get("method_configs", []):
        for binding in item.get("implementation_files", []) + item.get("dependency_bindings", []):
            _check_binding(root, binding, reasons, f"method {item.get('method_id')} source")
        if item.get("config_status") == "UNRESOLVED_AUTHOR_FREEZE_REQUIRED" and item.get("config_hash") != "UNRESOLVED_NOT_FROZEN":
            reasons.append(f"unresolved config has fabricated hash: {item.get('method_id')}")
        for field, status in item.get("leakage_checks", {}).items():
            if status != "FORBIDDEN":
                reasons.append(f"leakage boundary is not forbidden: {item.get('method_id')} {field}")

    manifest = _json(root, CURRENT_V2[2])
    if manifest.get("hard_stop_before_step") != "C14" or manifest.get("c14_execution_authorized") is not False:
        reasons.append("C14.1 manifest does not preserve the C14 hard stop")
    protocol = _json(root, CURRENT_V2[3])
    ledger_schema = _json(root, CURRENT_V2[4])
    if protocol.get("execution_authorized") is not False or ledger_schema.get("execution_authorized") is not False:
        reasons.append("protocol or ledger schema has execution permission")
    row_schema = _json(root, CURRENT_V2[5])
    expected_row_fields = set(ledger_schema.get("row_fields", []))
    if set(row_schema.get("required", [])) != expected_row_fields:
        reasons.append("machine ledger JSON Schema does not require every declared row field")
    if row_schema.get("additionalProperties") is not False:
        reasons.append("machine ledger JSON Schema is not closed")
    if row_schema.get("properties", {}).get("api_calls", {}).get("const") != 0:
        reasons.append("machine ledger schema permits API calls")
    if row_schema.get("properties", {}).get("tokens", {}).get("const") != 0:
        reasons.append("machine ledger schema permits LLM tokens")
    stats_inventory = _json(root, CURRENT_V2[6])
    if stats_inventory.get("O08") != "FROZEN_EFFECT_AND_CI_DOWNGRADE; margin-dependent decisions and claims disabled":
        reasons.append("stats inventory misstates frozen O-08 downgrade")
    budget = _json(root, CURRENT_V2[7])
    if budget.get("artifact_status") != "REQUEST_ONLY_NOT_AUTHORIZED" or budget.get("execution_authorized") is not False:
        reasons.append("budget request is not request-only")
    unified = _json(root, UNIFIED)
    if unified.get("authorization_state", {}).get("c14_1_execution_authorized") is not False or unified.get("authorization_state", {}).get("self_authorization_forbidden") is not True:
        reasons.append("unified package could self-authorize")
    for locator in CURRENT_V2 + (UNIFIED,):
        try:
            value = _json(root, locator)
        except (json.JSONDecodeError, UnicodeDecodeError):
            continue
        reasons.extend(_all_false(value, path=locator))
    exact_scope = unified.get("exact_scope", {})
    if exact_scope.get("scenarios") != ["nominal_fixed", "influx_event"]:
        reasons.append("C14.1 scope does not use the frozen primary scenario pair")
    if exact_scope.get("recommended_roots") != 48 or exact_scope.get("method_cases") != 2304:
        reasons.append("C14.1 root/case recommendation does not match the protocol-planned tier")

    gate = yaml.safe_load((root / "protocol/gate_registry.yaml").read_text(encoding="utf-8"))
    boundary = gate.get("current_boundary", {})
    execution = gate.get("execution_boundary", {})
    if boundary.get("hard_stop_before_step") != "C14" or gate.get("status") != "C13_STATS_READINESS_PASSED_C14_HARD_STOP":
        reasons.append("gate registry no longer has C14 hard stop")
    for key in ("method_identified_comparison_allowed", "training_allowed", "API_allowed", "pilot_shadow_precision_locked_allowed"):
        if execution.get(key) is not False and boundary.get(key) is not False:
            reasons.append(f"gate permission is not false: {key}")

    history = _json(root, "protocol/c14/c14_history_supersession_20260728.json")
    history_records = {record.get("locator"): record for record in history.get("history_files", [])}
    for locator in HISTORY:
        record = history_records.get(locator)
        if record is None or record.get("history_status") != "SUPERSEDED_HISTORY":
            reasons.append(f"historical file is not explicitly superseded: {locator}")
        elif not (root / locator).is_file() or _sha(root / locator) != record.get("sha256"):
            reasons.append(f"historical file hash binding mismatch: {locator}")

    claim_text = (root / "protocol/c14/claim_boundary_check.V2_20260728.md").read_text(encoding="utf-8")
    for forbidden in ("PERFORMANCE_CLAIM_ALLOWED: true", "METHOD_PERFORMANCE_ESTABLISHED", "AGENT_OUTPERFORMS_BASELINES", "REAL_TIME_FEASIBLE", "DEPLOYMENT_FEASIBLE"):
        if forbidden.lower() in claim_text.lower():
            reasons.append(f"claim boundary contains forbidden assertion: {forbidden}")
    return {"passed": not reasons, "reasons": tuple(reasons), "checks": {"c12_closed": not any("C12" in reason for reason in reasons), "checkpoint_topology": actual_topology == expected_topology, "permissions_false": not any("permission" in reason for reason in reasons), "history_bound": not any("historical" in reason for reason in reasons)}}
