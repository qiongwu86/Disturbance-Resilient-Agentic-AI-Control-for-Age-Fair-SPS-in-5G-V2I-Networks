"""Fail-closed validator for the closed JSON Schema subset used in C02."""

from collections.abc import Mapping
import re
from typing import Any


class SchemaValidationError(ValueError):
    """Raised when a schema or instance violates the C02 closed subset."""


_DIALECT = "https://json-schema.org/draft/2020-12/schema"
_ANNOTATION_KEYWORDS = frozenset({"$id", "$schema", "title"})
_ASSERTION_KEYWORDS = frozenset(
    {"const", "enum", "maxLength", "minLength", "minimum", "pattern", "type"}
)
_STRUCTURAL_KEYWORDS = frozenset(
    {"additionalProperties", "items", "properties", "required"}
)
_SUPPORTED_KEYWORDS = (
    _ANNOTATION_KEYWORDS | _ASSERTION_KEYWORDS | _STRUCTURAL_KEYWORDS
)
_SUPPORTED_TYPES = frozenset({"array", "boolean", "integer", "null", "object", "string"})


def validate_closed_schema_instance(
    instance: Any, schema: Mapping[str, Any], path: str = "$"
) -> None:
    """Validate a schema and then its instance without accepting unknown semantics."""

    _validate_schema(schema, "$schema")
    _validate_instance(instance, schema, path)
    _validate_semantics(instance, schema, path)


def _validate_semantics(instance: Any, schema: Mapping[str, Any], path: str) -> None:
    """Enforce cross-field constraints that the deliberately small subset cannot express."""

    schema_id = schema.get("$id")
    if schema_id == "urn:exp09:schema:measurement-summary-header:v1":
        if instance["window_start_us"] > instance["causal_cutoff_us"]:
            raise SchemaValidationError(f"{path}: window_start_us exceeds causal_cutoff_us")
    elif schema_id == "urn:exp09:schema:observable-frame:v1":
        kinds = [counter["kind"] for counter in instance["counters"]]
        if len(kinds) != len(set(kinds)):
            raise SchemaValidationError(f"{path}: counter kinds must be unique")
        _validate_unique_vehicle_ids(instance["observed_user_ages"], path, "observed_user_ages")
        _validate_unique_vehicle_ids(instance["observed_users"], path, "observed_users")
        _validate_unique_vehicle_ids(instance["removals"], path, "removals")
        for index, user in enumerate(instance["observed_users"]):
            if (user["age_us"] is None) == (user["age_missing_reason"] is None):
                raise SchemaValidationError(
                    f"{path}.observed_users[{index}]: exactly one of age_us and "
                    "age_missing_reason must be null"
                )
    elif schema_id == "urn:exp09:schema:measurement-summary:v2":
        header = instance["header"]
        if header["window_start_us"] > header["causal_cutoff_us"]:
            raise SchemaValidationError(
                f"{path}.header: window_start_us exceeds causal_cutoff_us"
            )
        counts = (
            instance["fresh_count"]
            + instance["stale_count"]
            + instance["unknown_count"]
        )
        if counts != instance["known_vehicle_count"]:
            raise SchemaValidationError(
                f"{path}: identity-state counts do not equal known_vehicle_count"
            )
        if instance["decoded_success_count"] > instance["decode_trial_count"]:
            raise SchemaValidationError(
                f"{path}: decoded_success_count exceeds decode_trial_count"
            )
        if instance["busy_sensing_slot_count"] > instance["eligible_sensing_slot_count"]:
            raise SchemaValidationError(
                f"{path}: busy_sensing_slot_count exceeds eligible_sensing_slot_count"
            )
        _validate_unique_pairs(instance["last_success_by_vehicle"], path, "last_success_by_vehicle")
        _validate_unique_pairs(
            instance["last_observed_at_by_vehicle"], path, "last_observed_at_by_vehicle"
        )
        _validate_unique_vehicle_ids(instance["observed_users"], path, "observed_users")
        _validate_unique_vehicle_ids(instance["removals"], path, "removals")
        removed = [item["vehicle_id"] for item in instance["removals"]]
        if instance["removed_vehicle_ids"] != removed:
            raise SchemaValidationError(
                f"{path}: removed_vehicle_ids must match removals in canonical order"
            )
        for index, user in enumerate(instance["observed_users"]):
            if (user["age_us"] is None) == (user["age_missing_reason"] is None):
                raise SchemaValidationError(
                    f"{path}.observed_users[{index}]: exactly one of age_us and "
                    "age_missing_reason must be null"
                )


def _validate_unique_vehicle_ids(
    values: list[Mapping[str, Any]], path: str, field_name: str
) -> None:
    identifiers = [item["vehicle_id"] for item in values]
    if len(identifiers) != len(set(identifiers)):
        raise SchemaValidationError(f"{path}.{field_name}: vehicle IDs must be unique")


def _validate_unique_pairs(values: list[list[Any]], path: str, field_name: str) -> None:
    for index, item in enumerate(values):
        if (
            len(item) != 2
            or not isinstance(item[0], str)
            or not item[0]
            or isinstance(item[1], bool)
            or not isinstance(item[1], int)
            or item[1] < 0
        ):
            raise SchemaValidationError(
                f"{path}.{field_name}[{index}]: expected [non-empty vehicle ID, "
                "non-negative integer timestamp]"
            )
    identifiers = [item[0] for item in values]
    if len(identifiers) != len(set(identifiers)):
        raise SchemaValidationError(f"{path}.{field_name}: vehicle IDs must be unique")


def _validate_schema(schema: Any, path: str) -> None:
    if not isinstance(schema, Mapping):
        raise SchemaValidationError(f"{path}: schema must be an object")

    unsupported = [
        keyword
        for keyword in schema
        if not isinstance(keyword, str) or keyword not in _SUPPORTED_KEYWORDS
    ]
    if unsupported:
        rendered = sorted(repr(keyword) for keyword in unsupported)
        raise SchemaValidationError(f"{path}: unsupported schema keywords {rendered}")

    if "$schema" in schema and schema["$schema"] != _DIALECT:
        raise SchemaValidationError(f"{path}.$schema: unsupported schema dialect")
    for keyword in ("$id", "title"):
        if keyword in schema and not isinstance(schema[keyword], str):
            raise SchemaValidationError(f"{path}.{keyword}: expected string")

    declared_types = (
        _validate_types(schema["type"], f"{path}.type")
        if "type" in schema
        else frozenset()
    )
    if not (set(schema) & (_ASSERTION_KEYWORDS | _STRUCTURAL_KEYWORDS)):
        raise SchemaValidationError(f"{path}: unconstrained schemas are unsupported")

    if "enum" in schema:
        enum = schema["enum"]
        if not isinstance(enum, list) or not enum:
            raise SchemaValidationError(f"{path}.enum: expected non-empty array")

    object_keywords = {"additionalProperties", "properties", "required"}
    present_object_keywords = object_keywords & set(schema)
    if present_object_keywords and "object" not in declared_types:
        raise SchemaValidationError(
            f"{path}: object keywords require the object type"
        )
    if "object" in declared_types:
        missing = sorted(object_keywords - set(schema))
        if missing:
            raise SchemaValidationError(
                f"{path}: closed object schema is missing keywords {missing}"
            )
        if schema["additionalProperties"] is not False:
            raise SchemaValidationError(
                f"{path}.additionalProperties: only false is supported"
            )
        properties = schema["properties"]
        if not isinstance(properties, Mapping) or any(
            not isinstance(name, str) for name in properties
        ):
            raise SchemaValidationError(f"{path}.properties: expected string-keyed object")
        required = schema["required"]
        if (
            not isinstance(required, list)
            or any(not isinstance(name, str) for name in required)
            or len(required) != len(set(required))
        ):
            raise SchemaValidationError(
                f"{path}.required: expected array of unique strings"
            )
        unknown_required = sorted(set(required) - set(properties))
        if unknown_required:
            raise SchemaValidationError(
                f"{path}.required: fields absent from properties {unknown_required}"
            )
        for name, child_schema in properties.items():
            _validate_schema(child_schema, f"{path}.properties.{name}")

    if "items" in schema and "array" not in declared_types:
        raise SchemaValidationError(f"{path}: items requires the array type")
    if "array" in declared_types:
        if "items" not in schema:
            raise SchemaValidationError(f"{path}: closed array schema requires items")
        _validate_schema(schema["items"], f"{path}.items")

    if "minimum" in schema:
        if "integer" not in declared_types:
            raise SchemaValidationError(f"{path}: minimum requires the integer type")
        minimum = schema["minimum"]
        if isinstance(minimum, bool) or not isinstance(minimum, int):
            raise SchemaValidationError(f"{path}.minimum: expected integer")

    for keyword in ("minLength", "maxLength"):
        if keyword in schema:
            if "string" not in declared_types:
                raise SchemaValidationError(f"{path}: {keyword} requires the string type")
            bound = schema[keyword]
            if isinstance(bound, bool) or not isinstance(bound, int) or bound < 0:
                raise SchemaValidationError(f"{path}.{keyword}: expected non-negative integer")
    if (
        "minLength" in schema
        and "maxLength" in schema
        and schema["minLength"] > schema["maxLength"]
    ):
        raise SchemaValidationError(f"{path}: minLength exceeds maxLength")
    if "pattern" in schema:
        if "string" not in declared_types:
            raise SchemaValidationError(f"{path}: pattern requires the string type")
        pattern = schema["pattern"]
        if not isinstance(pattern, str):
            raise SchemaValidationError(f"{path}.pattern: expected string")
        try:
            re.compile(pattern)
        except re.error as exc:
            raise SchemaValidationError(f"{path}.pattern: invalid regular expression") from exc


def _validate_types(value: Any, path: str) -> frozenset[str]:
    if isinstance(value, str):
        candidates = [value]
    elif isinstance(value, list) and value:
        candidates = value
    else:
        raise SchemaValidationError(f"{path}: expected type name or non-empty array")
    if any(not isinstance(candidate, str) for candidate in candidates):
        raise SchemaValidationError(f"{path}: type names must be strings")
    if len(candidates) != len(set(candidates)):
        raise SchemaValidationError(f"{path}: duplicate type names are unsupported")
    unsupported = sorted(set(candidates) - _SUPPORTED_TYPES)
    if unsupported:
        raise SchemaValidationError(f"{path}: unsupported types {unsupported}")
    return frozenset(candidates)


def _validate_instance(instance: Any, schema: Mapping[str, Any], path: str) -> None:
    if "const" in schema and instance != schema["const"]:
        raise SchemaValidationError(f"{path}: value does not match const")
    if "enum" in schema and instance not in schema["enum"]:
        raise SchemaValidationError(f"{path}: value is not in enum")

    declared_types = _declared_types(schema)
    if declared_types and not any(
        _is_type(instance, candidate) for candidate in declared_types
    ):
        raise SchemaValidationError(
            f"{path}: expected one of {sorted(declared_types)}"
        )

    if "object" in declared_types and isinstance(instance, dict):
        properties = schema["properties"]
        missing = [name for name in schema["required"] if name not in instance]
        if missing:
            raise SchemaValidationError(f"{path}: missing required fields {missing}")
        extra = sorted(set(instance) - set(properties))
        if extra:
            raise SchemaValidationError(f"{path}: unknown fields {extra}")
        for name, value in instance.items():
            _validate_instance(value, properties[name], f"{path}.{name}")

    if "array" in declared_types and isinstance(instance, list):
        for index, item in enumerate(instance):
            _validate_instance(item, schema["items"], f"{path}[{index}]")

    if (
        "integer" in declared_types
        and _is_type(instance, "integer")
        and "minimum" in schema
        and instance < schema["minimum"]
    ):
        raise SchemaValidationError(f"{path}: value is below minimum")

    if "string" in declared_types and isinstance(instance, str):
        if "minLength" in schema and len(instance) < schema["minLength"]:
            raise SchemaValidationError(f"{path}: string is shorter than minLength")
        if "maxLength" in schema and len(instance) > schema["maxLength"]:
            raise SchemaValidationError(f"{path}: string is longer than maxLength")
        if "pattern" in schema:
            if re.search(schema["pattern"], instance) is None:
                raise SchemaValidationError(f"{path}: string does not match pattern")


def _declared_types(schema: Mapping[str, Any]) -> frozenset[str]:
    value = schema.get("type")
    if value is None:
        return frozenset()
    if isinstance(value, str):
        return frozenset({value})
    return frozenset(value)


def _is_type(instance: Any, expected_type: str) -> bool:
    if expected_type == "object":
        return isinstance(instance, dict)
    if expected_type == "array":
        return isinstance(instance, list)
    if expected_type == "string":
        return isinstance(instance, str)
    if expected_type == "integer":
        return isinstance(instance, int) and not isinstance(instance, bool)
    if expected_type == "boolean":
        return isinstance(instance, bool)
    return instance is None
