"""Fail-closed structural validation for the C00 defect and claim ledgers."""

from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


@dataclass(frozen=True, slots=True)
class LedgerValidationReport:
    passed: bool
    reasons: tuple[str, ...]


_CLAIM_DISPOSITIONS = frozenset({"retain", "correct", "rerun", "delete", "gate-dependent"})
_DEFECT_STATUSES = frozenset({"PLANNED_FIX", "IN_PROGRESS", "VERIFIED_FIXED"})
_REQUIRED_CLAIM_FIELDS = frozenset(
    {
        "claim_id",
        "source_document",
        "source_locator",
        "original_text",
        "disposition",
        "claim_kind",
        "evidence_generation",
        "evidence_status",
        "required_gates",
        "required_endpoints",
        "required_contrasts",
        "required_ci",
        "required_figures_or_tables",
        "allowed_wording_before_gate",
        "allowed_wording_after_gate",
        "failure_wording",
        "evidence_artifacts",
    }
)
_REQUIRED_DEFECT_FIELDS = frozenset(
    {
        "id",
        "severity",
        "status",
        "old_evidence",
        "new_components",
        "test_ids",
        "artifact_ids",
        "manuscript_impacts",
        "verification_note",
    }
)
_AD06B_FORBIDDEN_RESULT_CLAIMS = frozenset(
    {
        "CLM-EXP09-002",
        "CLM-EXP09-003",
        "CLM-EXP09-004",
        "CLM-EXP09-005",
        "CLM-EXP09-006",
        "CLM-EXP09-007",
    }
)


def validate_ledgers(project_root: Path) -> LedgerValidationReport:
    reasons: list[str] = []
    claim_path = project_root / "reporting" / "claim_ledger.yaml"
    defect_path = project_root / "protocol" / "defect_ledger.yaml"
    claim = _load_yaml(claim_path, reasons)
    defect = _load_yaml(defect_path, reasons)
    if isinstance(claim, Mapping):
        _validate_claim_ledger(claim, reasons)
    if isinstance(defect, Mapping):
        _validate_defect_ledger(defect, project_root, reasons)
    return LedgerValidationReport(passed=not reasons, reasons=tuple(reasons))


def _load_yaml(path: Path, reasons: list[str]) -> Any:
    if not path.is_file():
        reasons.append(f"ledger missing: {path.name}")
        return None
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError:
        reasons.append(f"ledger invalid YAML: {path.name}")
        return None


def _validate_claim_ledger(value: Mapping[str, Any], reasons: list[str]) -> None:
    if value.get("schema_version") != "c00-claim-ledger-v1":
        reasons.append("claim ledger schema version mismatch")
    rules = value.get("rules")
    if not isinstance(rules, Mapping) or frozenset(rules.get("dispositions", [])) != (
        _CLAIM_DISPOSITIONS
    ):
        reasons.append("claim ledger dispositions are incomplete")
    claims = value.get("claims")
    if not isinstance(claims, list):
        reasons.append("claim ledger claims must be a list")
        return
    identifiers: list[str] = []
    by_id: dict[str, Mapping[str, Any]] = {}
    for index, item in enumerate(claims):
        if not isinstance(item, Mapping) or set(item) != _REQUIRED_CLAIM_FIELDS:
            reasons.append(f"claim ledger entry {index} has an invalid field set")
            continue
        claim_id = item.get("claim_id")
        if not isinstance(claim_id, str) or not claim_id:
            reasons.append(f"claim ledger entry {index} has an invalid claim ID")
            continue
        identifiers.append(claim_id)
        by_id[claim_id] = item
        if item.get("disposition") not in _CLAIM_DISPOSITIONS:
            reasons.append(f"claim {claim_id} has an unknown disposition")
        for field in (
            "required_gates",
            "required_endpoints",
            "required_contrasts",
            "required_figures_or_tables",
            "evidence_artifacts",
        ):
            if not isinstance(item.get(field), list):
                reasons.append(f"claim {claim_id} field {field} must be a list")
    if len(identifiers) != len(set(identifiers)):
        reasons.append("claim IDs must be unique")

    for claim_id in _AD06B_FORBIDDEN_RESULT_CLAIMS:
        item = by_id.get(claim_id)
        if item is None:
            reasons.append(f"claim ledger is missing required AD-06B claim {claim_id}")
        elif (
            item.get("disposition") != "delete"
            or item.get("evidence_status") != "NOT_ALLOWED_UNDER_AD06B"
            or item.get("required_gates") != []
            or item.get("allowed_wording_after_gate") != "NOT_ALLOWED_UNDER_AD06B"
        ):
            reasons.append(f"claim {claim_id} does not enforce the AD-06B deletion boundary")
    real_time = by_id.get("CLM-EXP09-009")
    if real_time is None or (
        real_time.get("disposition") != "delete"
        or real_time.get("evidence_status") != "NOT_ALLOWED_UNDER_AD02A"
        or real_time.get("required_gates") != []
        or real_time.get("allowed_wording_after_gate") != "NOT_ALLOWED_UNDER_AD02A"
    ):
        reasons.append("CLM-EXP09-009 must be deleted under the frozen AD-02A claim tier")
    for claim_id in ("CLM-EXP09-001", "CLM-EXP09-008"):
        item = by_id.get(claim_id)
        wording = "" if item is None else str(item.get("allowed_wording_after_gate"))
        if "absolute effect" not in wording or "adjusted" not in wording or "superiority" not in wording:
            reasons.append(f"claim {claim_id} lacks the effect-and-adjusted-CI wording boundary")


def _validate_defect_ledger(
    value: Mapping[str, Any], project_root: Path, reasons: list[str]
) -> None:
    if value.get("schema_version") != "c00-defect-ledger-v1":
        reasons.append("defect ledger schema version mismatch")
    defects = value.get("defects")
    if not isinstance(defects, list):
        reasons.append("defect ledger defects must be a list")
        return
    identifiers: list[str] = []
    by_id: dict[str, Mapping[str, Any]] = {}
    for index, item in enumerate(defects):
        if not isinstance(item, Mapping) or set(item) != _REQUIRED_DEFECT_FIELDS:
            reasons.append(f"defect ledger entry {index} has an invalid field set")
            continue
        defect_id = item.get("id")
        if not isinstance(defect_id, str) or not defect_id:
            reasons.append(f"defect ledger entry {index} has an invalid defect ID")
            continue
        identifiers.append(defect_id)
        by_id[defect_id] = item
        if item.get("status") not in _DEFECT_STATUSES:
            reasons.append(f"defect {defect_id} has an unknown status")
        test_ids = item.get("test_ids")
        artifact_ids = item.get("artifact_ids")
        if not isinstance(test_ids, list) or not isinstance(artifact_ids, list):
            reasons.append(f"defect {defect_id} tests and artifacts must be lists")
            continue
        if item.get("status") == "VERIFIED_FIXED" and (
            not test_ids
            or not artifact_ids
            or any(str(test_id).startswith("PLANNED:") for test_id in test_ids)
        ):
            reasons.append(f"defect {defect_id} cannot be VERIFIED_FIXED without closed evidence")
        for artifact_id in artifact_ids:
            if not isinstance(artifact_id, str) or not (project_root / artifact_id).is_file():
                reasons.append(f"defect {defect_id} references a missing artifact: {artifact_id}")
    if len(identifiers) != len(set(identifiers)):
        reasons.append("defect IDs must be unique")
    for defect_id in ("BUG-02", "BUG-03", "BUG-04"):
        item = by_id.get(defect_id)
        if item is None or item.get("status") != "IN_PROGRESS":
            reasons.append(f"defect {defect_id} must record partial C03-C06 remediation")
        elif not item.get("artifact_ids"):
            reasons.append(f"defect {defect_id} must link its blocked G1 evidence reports")
