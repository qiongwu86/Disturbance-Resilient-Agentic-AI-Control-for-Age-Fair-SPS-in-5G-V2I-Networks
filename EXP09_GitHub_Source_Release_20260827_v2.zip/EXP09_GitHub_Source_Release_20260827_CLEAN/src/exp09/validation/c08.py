"""C08 RMPC/RiskGate/budget bundle validation."""

from collections.abc import Mapping
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path, PurePosixPath
from typing import Any


@dataclass(frozen=True, slots=True)
class C08BundleValidationReport:
    passed: bool
    reasons: tuple[str, ...]


_C08_MANIFEST_LOCATOR = "protocol/c08/c08_manifest.json"
_RMPC_MECHANISM_REPORT_LOCATOR = "protocol/c08/rmpc_mechanism_report.json"
_RISK_GATE_ACTIVATION_REPORT_LOCATOR = "protocol/c08/risk_gate_activation_report.json"
_G2_REPORT_LOCATOR = "protocol/evidence/G2_c08_rmpc_risk_budget_report.md"
_EXPECTED_MANIFEST_ARTIFACTS = frozenset(
    {
        _RMPC_MECHANISM_REPORT_LOCATOR,
        _RISK_GATE_ACTIVATION_REPORT_LOCATOR,
        _G2_REPORT_LOCATOR,
        "src/exp09/control/budget.py",
        "src/exp09/control/calibration.py",
        "src/exp09/control/commitment.py",
        "src/exp09/control/risk_gate.py",
        "src/exp09/control/robust_selector.py",
        "src/exp09/validation/c08.py",
        "tests/c08/test_c08_rmpc_risk_budget.py",
    }
)
_HEX_DIGITS = frozenset("0123456789abcdefABCDEF")


def _load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def _is_sha256(value: Any) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(character in _HEX_DIGITS for character in value)
    )


def _safe_locator(locator: Any) -> bool:
    if not isinstance(locator, str) or not locator or "\\" in locator:
        return False
    path = PurePosixPath(locator)
    return not path.is_absolute() and ".." not in path.parts and ":" not in path.parts[0]


def _float_paths(value: Any, *, path: str = "root") -> tuple[str, ...]:
    found: list[str] = []
    if isinstance(value, float):
        found.append(path)
    elif isinstance(value, Mapping):
        for key, child in value.items():
            found.extend(_float_paths(child, path=f"{path}.{key}"))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            found.extend(_float_paths(child, path=f"{path}[{index}]"))
    return tuple(found)


def validate_c08_bundle(project_root: Path) -> C08BundleValidationReport:
    project_root = project_root.resolve()
    reasons: list[str] = []
    records: dict[str, Any] = {}
    for locator in (
        _C08_MANIFEST_LOCATOR,
        _RMPC_MECHANISM_REPORT_LOCATOR,
        _RISK_GATE_ACTIVATION_REPORT_LOCATOR,
    ):
        path = project_root / locator
        if not path.is_file():
            reasons.append(f"{locator}: missing")
            continue
        try:
            record = _load_json(path)
        except json.JSONDecodeError:
            reasons.append(f"{locator}: invalid JSON")
            continue
        records[locator] = record
        for float_path in _float_paths(record):
            reasons.append(f"{locator}: float is forbidden at {float_path}")

    _validate_rmpc_mechanism(records.get(_RMPC_MECHANISM_REPORT_LOCATOR), reasons)
    _validate_risk_gate_activation(records.get(_RISK_GATE_ACTIVATION_REPORT_LOCATOR), reasons)
    _validate_manifest(records.get(_C08_MANIFEST_LOCATOR), project_root, reasons)
    _validate_g2_report(project_root, reasons)
    return C08BundleValidationReport(passed=not reasons, reasons=tuple(reasons))


def _validate_rmpc_mechanism(record: Any, reasons: list[str]) -> None:
    if record is None:
        return
    if not isinstance(record, Mapping):
        reasons.append("C08 RMPC mechanism report must be a JSON object")
        return
    expected = {
        "schema_version": "exp09-c08-rmpc-mechanism-report-v1",
        "status": "G2_MECHANISM_UNIT_PASSED",
        "g2_gate_status": "PASSED",
        "method_execution_allowed": False,
        "method_comparison_allowed": False,
        "training_allowed": False,
        "api_allowed": False,
        "performance_claim_allowed": False,
        "mechanism_scope": "CONSTRUCTED_UNIT_DOMAIN_NO_RUNNER_NO_METHOD_COMPARISON",
    }
    for key, value in expected.items():
        if record.get(key) != value:
            reasons.append(f"C08 RMPC mechanism report {key} mismatch")
    required_checks = {
        "c07_model_to_rmpc_same_evaluator_rollouts",
        "scenario_artifact_state_horizon_binding",
        "budget_conservation",
        "full_rmpc_budget_equality",
        "deterministic_worst_case_tie_break",
        "safe_boundary_unsafe_unavoidable_risk_paths",
        "threshold_reachability",
        "commitment_consistency",
    }
    if set(record.get("closed_checks", ())) != required_checks:
        reasons.append("C08 RMPC mechanism report closed checks mismatch")


def _validate_risk_gate_activation(record: Any, reasons: list[str]) -> None:
    if record is None:
        return
    if not isinstance(record, Mapping):
        reasons.append("C08 RiskGate activation report must be a JSON object")
        return
    expected = {
        "schema_version": "exp09-c08-risk-gate-activation-report-v1",
        "status": "CONSTRUCTED_REACHABILITY_PASSED",
        "g2_gate_status": "PASSED",
        "method_execution_allowed": False,
        "method_comparison_allowed": False,
        "performance_claim_allowed": False,
        "activation_rate_claim_allowed": False,
    }
    for key, value in expected.items():
        if record.get(key) != value:
            reasons.append(f"C08 RiskGate activation report {key} mismatch")
    threshold = record.get("threshold")
    if not isinstance(threshold, Mapping):
        reasons.append("C08 RiskGate threshold must be an object")
    elif (
        threshold.get("risk_threshold_ppm") != 250000
        or threshold.get("reachable_min_ppm") != 100000
        or threshold.get("reachable_max_ppm") != 900000
    ):
        reasons.append("C08 RiskGate threshold reachability mismatch")
    cases = record.get("constructed_cases")
    expected_cases = (
        {"case_id": "safe_accept", "selection_risk_ppm": 100000, "expected_status": "ACCEPT"},
        {"case_id": "boundary_accept", "selection_risk_ppm": 250000, "expected_status": "ACCEPT"},
        {
            "case_id": "unsafe_fallback",
            "selection_risk_ppm": 500000,
            "fallback_risk_ppm": 250000,
            "expected_status": "REJECT_FALLBACK",
        },
        {
            "case_id": "unavoidable_risk",
            "selection_risk_ppm": 800000,
            "fallback_risk_ppm": 800000,
            "expected_status": "UNAVOIDABLE_RISK",
        },
    )
    if not isinstance(cases, list) or tuple(cases) != expected_cases:
        reasons.append("C08 RiskGate constructed case list mismatch")


def _validate_manifest(record: Any, project_root: Path, reasons: list[str]) -> None:
    if record is None:
        return
    if not isinstance(record, Mapping):
        reasons.append("C08 manifest must be a JSON object")
        return
    expected = {
        "schema_version": "exp09-c08-manifest-v1",
        "status": "G2_PASSED_C08_COMPLETE",
        "g2_gate_status": "PASSED",
        "hard_stop_before_step": "C09",
        "method_execution_allowed": False,
        "method_comparison_allowed": False,
        "performance_claim_allowed": False,
    }
    for key, value in expected.items():
        if record.get(key) != value:
            reasons.append(f"C08 manifest {key} mismatch")
    artifacts = record.get("artifacts")
    if not isinstance(artifacts, list):
        reasons.append("C08 manifest artifacts must be a list")
        return
    locators = [
        artifact.get("locator") if isinstance(artifact, Mapping) else None
        for artifact in artifacts
    ]
    if len(locators) != len(set(locators)):
        reasons.append("C08 manifest contains duplicate locators")
    if frozenset(locators) != _EXPECTED_MANIFEST_ARTIFACTS:
        reasons.append("C08 manifest artifact set mismatch")
    for artifact in artifacts:
        locator = artifact.get("locator") if isinstance(artifact, Mapping) else None
        expected_hash = artifact.get("sha256") if isinstance(artifact, Mapping) else None
        if not _safe_locator(locator):
            reasons.append("C08 manifest contains an unsafe locator")
            continue
        path = project_root / locator
        if not path.is_file():
            reasons.append(f"C08 manifest artifact missing: {locator}")
        elif not _is_sha256(expected_hash):
            reasons.append(f"C08 manifest hash is invalid: {locator}")
        elif _sha256(path) != expected_hash:
            reasons.append(f"C08 manifest hash mismatch: {locator}")


def _validate_g2_report(project_root: Path, reasons: list[str]) -> None:
    report_path = project_root / _G2_REPORT_LOCATOR
    if not report_path.is_file():
        reasons.append(f"{_G2_REPORT_LOCATOR}: missing")
        return
    report = report_path.read_text(encoding="utf-8")
    for marker in (
        "REPORT_ID: g2_c08_rmpc_risk_budget",
        "STATUS: G2_MECHANISM_UNIT_PASSED",
        "G2_GATE_STATUS: PASSED",
        "RMPC_SAME_EVALUATOR_STATUS: C07_MODEL_ROLLOUT_CHAIN_CLOSED",
        "SCENARIO_BINDING_STATUS: STATE_HORIZON_ARTIFACT_BOUND",
        "validate_c08_bundle=PASS",
    ):
        if marker not in report:
            reasons.append(f"G2 report missing marker: {marker}")
