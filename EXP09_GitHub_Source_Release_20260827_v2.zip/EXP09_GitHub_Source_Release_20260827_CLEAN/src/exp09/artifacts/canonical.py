"""Fail-closed canonical JSON for versioned contract objects."""

from dataclasses import fields, is_dataclass
from decimal import Decimal
from enum import Enum
import hashlib
import json
from typing import Any


class CanonicalizationError(ValueError):
    """Raised when a value has no frozen canonical representation."""


def to_primitive(value: Any) -> Any:
    if isinstance(value, Enum):
        if not isinstance(value.value, str):
            raise CanonicalizationError("enum values must be strings")
        return value.value
    if value is None or isinstance(value, str):
        return value
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, (float, Decimal)):
        raise CanonicalizationError("float and Decimal policy is unresolved")
    if is_dataclass(value) and not isinstance(value, type):
        return {field.name: to_primitive(getattr(value, field.name)) for field in fields(value)}
    if isinstance(value, tuple):
        return [to_primitive(item) for item in value]
    if isinstance(value, list):
        raise CanonicalizationError("mutable lists are not canonical contract containers")
    if isinstance(value, dict):
        if any(not isinstance(key, str) for key in value):
            raise CanonicalizationError("canonical object keys must be strings")
        return {key: to_primitive(item) for key, item in value.items()}
    raise CanonicalizationError(f"unsupported canonical type: {type(value).__name__}")


def canonical_json_bytes(value: Any, *, expected_schema_version: str | None = None) -> bytes:
    primitive = to_primitive(value)
    if not isinstance(primitive, dict):
        raise CanonicalizationError("top-level canonical value must be an object")
    schema_version = primitive.get("schema_version")
    if not isinstance(schema_version, str) or not schema_version:
        raise CanonicalizationError("top-level schema_version is required")
    if expected_schema_version is not None and schema_version != expected_schema_version:
        raise CanonicalizationError("schema_version mismatch")
    try:
        text = json.dumps(
            primitive,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
    except (TypeError, ValueError) as exc:
        raise CanonicalizationError(str(exc)) from exc
    return text.encode("utf-8")


def canonical_sha256(value: Any, *, expected_schema_version: str | None = None) -> str:
    payload = canonical_json_bytes(value, expected_schema_version=expected_schema_version)
    return hashlib.sha256(payload).hexdigest().upper()
