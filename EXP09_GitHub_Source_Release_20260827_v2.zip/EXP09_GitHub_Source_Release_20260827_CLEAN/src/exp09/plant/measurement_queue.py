"""Deterministic phase-60 queue owned by the plant runtime."""

import heapq

from exp09.contracts.observable import MeasurementDeliveryEvent


class MeasurementDeliveryQueue:
    def __init__(self, events: tuple[MeasurementDeliveryEvent, ...] = ()) -> None:
        self._heap: list[tuple[int, str, MeasurementDeliveryEvent]] = []
        self._event_ids: set[str] = set()
        for event in events:
            self.push(event)

    def push(self, event: MeasurementDeliveryEvent) -> None:
        event_id = str(event.event_id)
        if event_id in self._event_ids:
            raise ValueError(f"duplicate measurement-delivery event: {event_id}")
        heapq.heappush(
            self._heap,
            (int(event.delivered_at_us), event_id, event),
        )
        self._event_ids.add(event_id)

    def pop_due(self, cutoff_us: int) -> tuple[MeasurementDeliveryEvent, ...]:
        due: list[MeasurementDeliveryEvent] = []
        while self._heap and self._heap[0][0] <= cutoff_us:
            _, event_id, event = heapq.heappop(self._heap)
            self._event_ids.remove(event_id)
            due.append(event)
        return tuple(due)

    def snapshot(self) -> tuple[MeasurementDeliveryEvent, ...]:
        return tuple(item[2] for item in sorted(self._heap))
