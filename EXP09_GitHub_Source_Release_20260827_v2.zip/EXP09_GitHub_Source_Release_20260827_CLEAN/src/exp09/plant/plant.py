"""Corrected deterministic discrete-event SPS plant for C04."""

from dataclasses import replace

from exp09.contracts.actions import (
    ACTION_SCHEMA_VERSION,
    OPPORTUNITY_SCHEMA_VERSION,
    ActionKind,
    ControlAction,
    ControlOpportunity,
)
from exp09.contracts.determinism import stable_digest_hex, stable_event_id
from exp09.contracts.ids import ControlOpportunityId, VehicleId
from exp09.contracts.observable import (
    MEASUREMENT_DELIVERY_EVENT_SCHEMA_VERSION,
    RECEIVER_ATTEMPT_OBSERVATION_SCHEMA_VERSION,
    RECEIVER_IDENTITY_EVENT_SCHEMA_VERSION,
    RECEIVER_PACKET_OBSERVATION_SCHEMA_VERSION,
    MeasurementDeliveryEvent,
    MeasurementEventKind,
    ReceiverAttemptObservation,
    ReceiverIdentityEvent,
    ReceiverObservableKind,
    ReceiverPacketObservation,
)
from exp09.contracts.tape import CounterNamespace, DisturbanceTape, TapeGrant
from exp09.contracts.time import DurationUs, SimTimeUs
from .event_queue import EVENT_PRIORITIES, EventKind, EventQueue, make_event
from .measurement_queue import MeasurementDeliveryQueue
from .state import (
    PLANT_ADVANCE_RESULT_SCHEMA_VERSION,
    PLANT_SNAPSHOT_SCHEMA_VERSION,
    PLANT_TRACE_SCHEMA_VERSION,
    TRUTH_EVENT_RECORD_SCHEMA_VERSION,
    TX_ATTEMPT_RECORD_SCHEMA_VERSION,
    VEHICLE_STATE_SCHEMA_VERSION,
    PlantAdvanceResult,
    PlantSnapshot,
    PlantTrace,
    TerminalOutcome,
    TruthEventKind,
    TruthEventRecord,
    TxAttemptRecord,
    VehicleState,
)

LEGAL_RRI_US = (20_000, 50_000, 100_000, 200_000, 300_000, 500_000, 1_000_000)


class DiscreteEventSPSPlant:
    def __init__(self) -> None:
        self._tape: DisturbanceTape | None = None
        self._vehicles: dict[str, VehicleState] = {}
        self._queue = EventQueue()
        self._time_us = 0
        self._pending_opportunity: ControlOpportunity | None = None
        self._trace: list[TxAttemptRecord] = []
        self._truth_events: list[TruthEventRecord] = []
        self._observations: list[ReceiverPacketObservation] = []
        self._measurement_queue = MeasurementDeliveryQueue()
        self._measurement_deliveries: list[MeasurementDeliveryEvent] = []
        self._action_history: list[ControlAction] = []
        self._channel_draw_index: dict[tuple[str, int], int] = {}
        self._counter_index: dict[tuple[str, CounterNamespace, int], int] = {}
        self._reselection_index: dict[str, tuple] = {}

    @property
    def observations(self) -> tuple[ReceiverPacketObservation, ...]:
        return tuple(self._observations)

    def reset(self, tape: DisturbanceTape) -> PlantSnapshot:
        self._tape = tape
        self._vehicles = {}
        self._queue = EventQueue()
        self._time_us = int(tape.simulation_start_us)
        self._pending_opportunity = None
        self._trace = []
        self._truth_events = []
        self._observations = []
        self._measurement_queue = MeasurementDeliveryQueue()
        self._measurement_deliveries = []
        self._action_history = []
        self._build_tape_indexes(tape)
        for vehicle in tape.vehicles:
            arrival = int(vehicle.arrival_simulation_time_us)
            present = arrival == int(tape.simulation_start_us)
            state = VehicleState(
                schema_version=VEHICLE_STATE_SCHEMA_VERSION,
                vehicle_id=str(vehicle.vehicle_id),
                present=present,
                grant=vehicle.initial_grant,
                next_packet_generation_us=_next_lattice_time(
                    arrival, vehicle.packet_phase_us, tape.packet_period_us
                ),
                waiting_packet_generation_us=None,
                last_success_generation_us=int(vehicle.last_success_generation_us_at_entry),
                reselection_counter=self._counter_value(
                    str(vehicle.vehicle_id), CounterNamespace.INITIAL, 0
                ),
                reservation_version=0,
                departure_time_us=int(vehicle.departure_simulation_time_us),
                tx_ordinal=0,
                reselection_ordinal=0,
            )
            self._vehicles[state.vehicle_id] = state
            if present:
                self._queue_identity_delivery(
                    state, ReceiverObservableKind.AUTHENTICATED_HANDOVER
                )
                self._schedule_packet(state.vehicle_id, state.next_packet_generation_us)
                self._schedule_tx(state.vehicle_id, int(tape.simulation_start_us), strict=False)
            else:
                self._queue.push(
                    make_event(
                        EventKind.VEHICLE_ARRIVAL,
                        arrival,
                        _event_id(None, "arrival", state.vehicle_id, None, 0),
                        state.vehicle_id,
                    )
                )
            if state.departure_time_us < int(tape.simulation_end_us):
                self._queue.push(
                    make_event(
                        EventKind.VEHICLE_DEPARTURE,
                        state.departure_time_us,
                        _event_id(None, "departure", state.vehicle_id, None, 0),
                        state.vehicle_id,
                    )
                )
        return self.snapshot()

    def advance_until(self, time_us: int) -> PlantAdvanceResult:
        if self._tape is None:
            raise RuntimeError("plant is not reset")
        if time_us < self._time_us:
            raise ValueError("time_us must not move backwards")
        opportunities: list[ControlOpportunity] = []
        start_trace_len = len(self._trace)
        start_truth_len = len(self._truth_events)
        start_delivery_len = len(self._measurement_deliveries)
        while self._queue.peek_time_us() is not None and self._queue.peek_time_us() < time_us:
            if self._pending_opportunity is not None:
                break
            batch = self._queue.pop_phase_batch()
            event_time = int(batch[0].header.time_us)
            if event_time < self._time_us:
                raise RuntimeError("event queue attempted to move simulation time backwards")
            self._time_us = event_time
            self._process_phase(batch, opportunities)
        if self._pending_opportunity is None:
            self._time_us = time_us
        delta = PlantTrace(
            schema_version=PLANT_TRACE_SCHEMA_VERSION,
            tx_attempts=tuple(self._trace[start_trace_len:]),
            truth_events=tuple(self._truth_events[start_truth_len:]),
        )
        return PlantAdvanceResult(
            schema_version=PLANT_ADVANCE_RESULT_SCHEMA_VERSION,
            snapshot=self.snapshot(),
            opportunities=tuple(opportunities),
            trace_delta=delta,
            measurement_delivery_delta=tuple(
                self._measurement_deliveries[start_delivery_len:]
            ),
        )

    def apply(self, opportunity: ControlOpportunity, action: ControlAction) -> PlantSnapshot:
        if self._tape is None:
            raise RuntimeError("plant is not reset")
        if self._pending_opportunity != opportunity:
            raise ValueError("opportunity is stale or already consumed")
        if action.schema_version != ACTION_SCHEMA_VERSION:
            raise ValueError("unsupported action schema")
        if action.opportunity_id != opportunity.opportunity_id:
            raise ValueError("action opportunity_id does not match the open opportunity")
        if int(opportunity.time_us) != self._time_us:
            raise ValueError("opportunity time is stale")
        vehicle = self._vehicles[str(opportunity.vehicle_id)]
        if vehicle.reservation_version != opportunity.reservation_version:
            raise ValueError("opportunity reservation version is stale")
        if action.kind is ActionKind.RESELECT:
            if action.target_rri_us not in opportunity.legal_rri_us:
                raise ValueError("target RRI is outside the legal opportunity domain")
            grant = self._select_replacement_grant(vehicle, int(action.target_rri_us))
            vehicle = vehicle.with_grant(
                grant,
                self._counter_value(
                    vehicle.vehicle_id,
                    CounterNamespace.REBUILD,
                    vehicle.reservation_version + 1,
                ),
            )
            self._record_truth(TruthEventKind.RESERVATION_RESELECT, vehicle)
        elif action.kind is ActionKind.RETAIN_AT_EXPIRY:
            vehicle = replace(
                vehicle,
                reselection_counter=self._counter_value(
                    vehicle.vehicle_id,
                    CounterNamespace.REBUILD,
                    vehicle.reservation_version + 1,
                ),
                reservation_version=vehicle.reservation_version + 1,
            )
        else:
            raise ValueError("expired counter requires RETAIN_AT_EXPIRY or RESELECT")
        self._vehicles[vehicle.vehicle_id] = vehicle
        self._pending_opportunity = None
        self._schedule_tx(vehicle.vehicle_id, self._time_us, strict=True)
        self._action_history.append(action)
        return self.snapshot()

    def snapshot(self) -> PlantSnapshot:
        if self._tape is None:
            raise RuntimeError("plant is not reset")
        return PlantSnapshot(
            schema_version=PLANT_SNAPSHOT_SCHEMA_VERSION,
            time_us=self._time_us,
            tape=self._tape,
            vehicles=tuple(self._vehicles[key] for key in sorted(self._vehicles)),
            event_queue=self._queue.snapshot(),
            pending_opportunity=self._pending_opportunity,
            trace=PlantTrace(
                schema_version=PLANT_TRACE_SCHEMA_VERSION,
                tx_attempts=tuple(self._trace),
                truth_events=tuple(self._truth_events),
            ),
            observations=tuple(self._observations),
            measurement_delivery_queue=self._measurement_queue.snapshot(),
            measurement_deliveries=tuple(self._measurement_deliveries),
            queue_processed_time_us=self._queue.processed_time_us,
            queue_processed_priority=self._queue.processed_priority,
            queue_consumed_event_ids=self._queue.consumed_event_ids(),
            action_history=tuple(self._action_history),
        )

    def restore(self, snapshot: PlantSnapshot) -> None:
        _validate_snapshot_for_restore(snapshot)
        queue = EventQueue(
            snapshot.event_queue,
            processed_time_us=snapshot.queue_processed_time_us,
            processed_priority=snapshot.queue_processed_priority,
            consumed_event_ids=snapshot.queue_consumed_event_ids,
        )
        measurement_queue = MeasurementDeliveryQueue(
            snapshot.measurement_delivery_queue
        )

        # Commit only after every validation and queue reconstruction succeeds.
        self._tape = snapshot.tape
        self._time_us = snapshot.time_us
        self._vehicles = {state.vehicle_id: state for state in snapshot.vehicles}
        self._queue = queue
        self._pending_opportunity = snapshot.pending_opportunity
        self._trace = list(snapshot.trace.tx_attempts)
        self._truth_events = list(snapshot.trace.truth_events)
        self._observations = list(snapshot.observations)
        self._measurement_queue = measurement_queue
        self._measurement_deliveries = list(snapshot.measurement_deliveries)
        self._action_history = list(snapshot.action_history)

    def _process_phase(self, batch, opportunities: list[ControlOpportunity]) -> None:
        tx_events = tuple(event for event in batch if event.header.kind is EventKind.TX)
        measurement_events = tuple(
            event
            for event in batch
            if event.header.kind is EventKind.MEASUREMENT_DELIVERY
        )
        self._handle_tx_batch(tx_events)
        if measurement_events:
            self._handle_measurement_delivery_batch(measurement_events)
        for event in batch:
            kind = event.header.kind
            if kind in (EventKind.TX, EventKind.MEASUREMENT_DELIVERY):
                continue
            if kind is EventKind.VEHICLE_DEPARTURE:
                self._handle_departure(event.vehicle_id)
            elif kind in (EventKind.VEHICLE_ARRIVAL, EventKind.HANDOVER_ARRIVAL):
                self._handle_arrival(event.vehicle_id)
            elif kind is EventKind.PACKET_GENERATE:
                self._handle_packet_generate(event.vehicle_id)
            elif kind is EventKind.BACKGROUND_COUNTER_EXPIRE:
                self._validate_expired_counter(event.vehicle_id, controlled=False)
            elif kind is EventKind.BACKGROUND_RESOURCE_RESELECT:
                self._handle_background_reselection(event.vehicle_id)
            elif kind is EventKind.CONTROLLED_COUNTER_EXPIRE:
                self._validate_expired_counter(event.vehicle_id, controlled=True)
            elif kind is EventKind.CONTROL_OPPORTUNITY:
                self._create_control_opportunity(self._vehicles[event.vehicle_id], opportunities)
            else:
                raise RuntimeError(f"unsupported plant event kind: {kind.value}")

    def _handle_arrival(self, vehicle_id: str) -> None:
        state = replace(self._vehicles[vehicle_id], present=True)
        if state.next_packet_generation_us < self._time_us:
            raise RuntimeError("arrival attempted to schedule a past packet generation")
        self._vehicles[vehicle_id] = state
        self._record_truth(TruthEventKind.VEHICLE_ARRIVAL, state)
        self._queue_identity_delivery(
            state, ReceiverObservableKind.AUTHENTICATED_HANDOVER
        )
        self._schedule_packet(vehicle_id, state.next_packet_generation_us)
        self._schedule_tx(vehicle_id, self._time_us, strict=True)

    def _handle_departure(self, vehicle_id: str) -> None:
        state = self._vehicles[vehicle_id]
        if state.present:
            self._queue.cancel_where(
                lambda event: event.vehicle_id == vehicle_id
                and event.header.kind is not EventKind.MEASUREMENT_DELIVERY
            )
            state = replace(
                state,
                present=False,
                waiting_packet_generation_us=None,
                reservation_version=state.reservation_version + 1,
            )
            self._vehicles[vehicle_id] = state
            self._record_truth(TruthEventKind.VEHICLE_DEPARTURE, state)
            self._queue_identity_delivery(
                state, ReceiverObservableKind.AUTHENTICATED_DEPARTURE
            )

    def _handle_packet_generate(self, vehicle_id: str) -> None:
        state = self._vehicles[vehicle_id]
        if not state.present:
            return
        next_generation = state.next_packet_generation_us + self._require_tape().packet_period_us
        self._vehicles[vehicle_id] = replace(
            state,
            next_packet_generation_us=next_generation,
            waiting_packet_generation_us=self._time_us,
        )
        self._schedule_packet(vehicle_id, next_generation)

    def _handle_tx_batch(self, tx_events) -> None:
        attempts: list[tuple[str, VehicleState]] = []
        for event in tx_events:
            state = self._vehicles[event.vehicle_id]
            if not state.present:
                continue
            if state.waiting_packet_generation_us is None:
                self._schedule_tx(event.vehicle_id, self._time_us + 1, strict=False)
                continue
            attempts.append((event.vehicle_id, state))
        counts: dict[int, int] = {}
        for _, state in attempts:
            channel = state.grant.logical_subchannel_id
            counts[channel] = counts.get(channel, 0) + 1
        for vehicle_id, state in attempts:
            collided = counts[state.grant.logical_subchannel_id] > 1
            draw = self._channel_draw(vehicle_id, state.tx_ordinal)
            outcome = TerminalOutcome.COLLISION if collided else TerminalOutcome.RX_SUCCESS
            success = outcome is TerminalOutcome.RX_SUCCESS
            packet_generation = int(state.waiting_packet_generation_us)
            attempt_id = _event_id(None, "attempt", vehicle_id, None, state.tx_ordinal)
            self._trace.append(
                TxAttemptRecord(
                    schema_version=TX_ATTEMPT_RECORD_SCHEMA_VERSION,
                    attempt_id=attempt_id,
                    time_us=self._time_us,
                    vehicle_id=vehicle_id,
                    packet_generation_us=packet_generation,
                    logical_subchannel_id=state.grant.logical_subchannel_id,
                    channel_uniform_u64=draw,
                    outcome=outcome,
                    collided=collided,
                    success=success,
                )
            )
            self._queue_attempt_delivery(self._trace[-1])
            if success:
                observation = ReceiverPacketObservation(
                        schema_version=RECEIVER_PACKET_OBSERVATION_SCHEMA_VERSION,
                        event_id=_event_id(
                            attempt_id,
                            "rx_success",
                            vehicle_id,
                            str(state.grant.logical_subchannel_id),
                            0,
                        ),
                        vehicle_id=VehicleId(vehicle_id),
                        observed_at_us=SimTimeUs(self._time_us),
                        packet_generation_us=SimTimeUs(packet_generation),
                    )
                self._observations.append(observation)
                self._queue_measurement_delivery(
                    MeasurementDeliveryEvent(
                        schema_version=MEASUREMENT_DELIVERY_EVENT_SCHEMA_VERSION,
                        event_id=_event_id(
                            str(observation.event_id),
                            "measurement_delivery",
                            vehicle_id,
                            "packet",
                            0,
                        ),
                        delivered_at_us=observation.observed_at_us,
                        kind=MeasurementEventKind.PACKET,
                        packet=observation,
                        attempt=None,
                        identity=None,
                    ),
                    vehicle_id,
                )
            updated = replace(
                state,
                waiting_packet_generation_us=None,
                last_success_generation_us=(
                    packet_generation if success else state.last_success_generation_us
                ),
                reselection_counter=state.reselection_counter - 1,
                tx_ordinal=state.tx_ordinal + 1,
            )
            self._vehicles[vehicle_id] = updated
            if updated.reselection_counter <= 0:
                expiry_kind = (
                    EventKind.CONTROLLED_COUNTER_EXPIRE
                    if vehicle_id == str(self._require_tape().controlled_vehicle_id)
                    else EventKind.BACKGROUND_COUNTER_EXPIRE
                )
                resolution_kind = (
                    EventKind.CONTROL_OPPORTUNITY
                    if expiry_kind is EventKind.CONTROLLED_COUNTER_EXPIRE
                    else EventKind.BACKGROUND_RESOURCE_RESELECT
                )
                expiry_id = _event_id(
                    attempt_id,
                    expiry_kind.value,
                    vehicle_id,
                    None,
                    updated.tx_ordinal,
                )
                self._queue.push(
                    make_event(
                        expiry_kind,
                        self._time_us,
                        expiry_id,
                        vehicle_id,
                        causal_parent_id=attempt_id,
                    )
                )
                self._queue.push(
                    make_event(
                        resolution_kind,
                        self._time_us,
                        _event_id(
                            expiry_id,
                            resolution_kind.value,
                            vehicle_id,
                            None,
                            updated.tx_ordinal,
                        ),
                        vehicle_id,
                        causal_parent_id=expiry_id,
                    )
                )
            else:
                self._schedule_tx(vehicle_id, self._time_us + 1, strict=False)

    def _create_control_opportunity(
        self, state: VehicleState, opportunities: list[ControlOpportunity]
    ) -> None:
        if self._time_us < int(
            self._require_tape().analysis_origin_simulation_time_us
        ):
            self._apply_burn_in_retain(state)
            return
        opportunity = ControlOpportunity(
            schema_version=OPPORTUNITY_SCHEMA_VERSION,
            opportunity_id=ControlOpportunityId(
                _event_id(
                    None,
                    "opportunity",
                    state.vehicle_id,
                    None,
                    state.reservation_version,
                )
            ),
            vehicle_id=VehicleId(state.vehicle_id),
            time_us=SimTimeUs(self._time_us),
            reservation_version=state.reservation_version,
            current_rri_us=DurationUs(state.grant.rri_us),
            legal_rri_us=tuple(DurationUs(value) for value in LEGAL_RRI_US),
        )
        opportunities.append(opportunity)
        self._pending_opportunity = opportunity
        self._record_truth(TruthEventKind.CONTROL_OPPORTUNITY, state)

    def _apply_burn_in_retain(self, state: VehicleState) -> None:
        rebuild_ordinal = state.reservation_version + 1
        updated = replace(
            state,
            reselection_counter=self._counter_value(
                state.vehicle_id,
                CounterNamespace.REBUILD,
                rebuild_ordinal,
            ),
            reservation_version=rebuild_ordinal,
        )
        self._vehicles[state.vehicle_id] = updated
        self._schedule_tx(state.vehicle_id, self._time_us, strict=True)

    def _handle_background_reselection(self, vehicle_id: str) -> None:
        state = self._vehicles[vehicle_id]
        if not state.present:
            return
        updated = self._background_reselect(state)
        self._vehicles[vehicle_id] = updated
        self._schedule_tx(vehicle_id, self._time_us + 1, strict=False)

    def _validate_expired_counter(self, vehicle_id: str, *, controlled: bool) -> None:
        expected_controlled = vehicle_id == str(self._require_tape().controlled_vehicle_id)
        if expected_controlled != controlled:
            raise RuntimeError("counter-expiry event does not match the committed vehicle state")

    def _background_reselect(self, state: VehicleState) -> VehicleState:
        candidates = self._reselection_index.get(state.vehicle_id, ())
        if state.reselection_ordinal >= len(candidates):
            raise RuntimeError("background reselection tape is exhausted")
        grant = candidates[state.reselection_ordinal].grant
        if grant == state.grant:
            grant = self._select_replacement_grant(state, grant.rri_us)
        updated = state.with_grant(
            grant,
            self._counter_value(
                state.vehicle_id,
                CounterNamespace.REBUILD,
                state.reselection_ordinal + 1,
            ),
        )
        self._record_truth(TruthEventKind.RESERVATION_RESELECT, updated)
        return updated

    def _select_replacement_grant(self, vehicle: VehicleState, rri_us: int) -> TapeGrant:
        candidates = tuple(
            item.grant
            for item in self._reselection_index.get(vehicle.vehicle_id, ())
            if item.ordinal >= vehicle.reselection_ordinal
            and item.grant.rri_us == rri_us
            and item.grant != vehicle.grant
        )
        if not candidates:
            all_offsets = range(0, rri_us, self._require_tape().slot_duration_us)
            candidates = tuple(
                TapeGrant(
                    schema_version=vehicle.grant.schema_version,
                    rri_us=rri_us,
                    slot_offset_us=offset,
                    logical_subchannel_id=channel,
                )
                for offset in all_offsets
                for channel in range(self._require_tape().logical_subchannel_count)
                if (rri_us, offset, channel)
                != (
                    vehicle.grant.rri_us,
                    vehicle.grant.slot_offset_us,
                    vehicle.grant.logical_subchannel_id,
                )
            )
        if not candidates:
            raise RuntimeError("NO_LEGAL_GRANT")
        index = int(
            stable_digest_hex(
                "selector",
                self._require_tape().protocol_generation,
                self._require_tape().root_case_id,
                vehicle.vehicle_id,
                self._time_us,
                vehicle.reservation_version,
                rri_us,
            )[:16],
            16,
        ) % len(candidates)
        return candidates[index]

    def _channel_draw(self, vehicle_id: str, ordinal: int) -> int:
        try:
            return self._channel_draw_index[(vehicle_id, ordinal)]
        except KeyError as exc:
            raise RuntimeError("channel-error tape is exhausted") from exc

    def _counter_value(
        self,
        vehicle_id: str,
        namespace: CounterNamespace,
        ordinal: int,
    ) -> int:
        try:
            return self._counter_index[(vehicle_id, namespace, ordinal)]
        except KeyError as exc:
            raise RuntimeError("counter tape is exhausted or ambiguous") from exc

    def _build_tape_indexes(self, tape: DisturbanceTape) -> None:
        channel_draw_index = {
            (str(item.vehicle_id), item.ordinal): item.uniform_u64
            for item in tape.channel_draws
        }
        if len(channel_draw_index) != len(tape.channel_draws):
            raise ValueError("channel-error tape contains duplicate keys")
        counter_index = {
            (str(item.vehicle_id), item.counter_namespace, item.counter_ordinal): item.value
            for item in tape.counters
        }
        if len(counter_index) != len(tape.counters):
            raise ValueError("counter tape contains duplicate keys")
        reselections: dict[str, list] = {}
        for item in tape.background_reselections:
            reselections.setdefault(str(item.vehicle_id), []).append(item)
        for items in reselections.values():
            if tuple(item.ordinal for item in items) != tuple(range(len(items))):
                raise ValueError("background reselection tape ordinals are not contiguous")
        self._channel_draw_index = channel_draw_index
        self._counter_index = counter_index
        self._reselection_index = {
            vehicle_id: tuple(items) for vehicle_id, items in reselections.items()
        }

    def _record_truth(self, kind: TruthEventKind, state: VehicleState) -> None:
        self._truth_events.append(
            TruthEventRecord(
                schema_version=TRUTH_EVENT_RECORD_SCHEMA_VERSION,
                event_id=_event_id(
                    None,
                    kind.value,
                    state.vehicle_id,
                    None,
                    state.reservation_version,
                ),
                time_us=self._time_us,
                kind=kind,
                vehicle_id=state.vehicle_id,
                reservation_version=state.reservation_version,
            )
        )

    def _queue_attempt_delivery(self, attempt: TxAttemptRecord) -> None:
        observation = ReceiverAttemptObservation(
            schema_version=RECEIVER_ATTEMPT_OBSERVATION_SCHEMA_VERSION,
            event_id=attempt.attempt_id,
            vehicle_id=VehicleId(attempt.vehicle_id),
            observed_at_us=SimTimeUs(attempt.time_us),
            decoded=attempt.success,
            busy_slot_us=SimTimeUs(attempt.time_us),
        )
        self._queue_measurement_delivery(
            MeasurementDeliveryEvent(
                schema_version=MEASUREMENT_DELIVERY_EVENT_SCHEMA_VERSION,
                event_id=_event_id(
                    attempt.attempt_id,
                    "measurement_delivery",
                    attempt.vehicle_id,
                    "attempt",
                    0,
                ),
                delivered_at_us=observation.observed_at_us,
                kind=MeasurementEventKind.ATTEMPT,
                packet=None,
                attempt=observation,
                identity=None,
            ),
            attempt.vehicle_id,
        )

    def _queue_identity_delivery(
        self, state: VehicleState, kind: ReceiverObservableKind
    ) -> None:
        event = ReceiverIdentityEvent(
            schema_version=RECEIVER_IDENTITY_EVENT_SCHEMA_VERSION,
            event_id=_event_id(
                None,
                kind.value,
                state.vehicle_id,
                None,
                state.reservation_version,
            ),
            vehicle_id=VehicleId(state.vehicle_id),
            observed_at_us=SimTimeUs(self._time_us),
            kind=kind,
            last_success_generation_us=(
                SimTimeUs(state.last_success_generation_us)
                if kind is ReceiverObservableKind.AUTHENTICATED_HANDOVER
                and state.last_success_generation_us >= 0
                else None
            ),
            removal_reason=None,
        )
        self._queue_measurement_delivery(
            MeasurementDeliveryEvent(
                schema_version=MEASUREMENT_DELIVERY_EVENT_SCHEMA_VERSION,
                event_id=_event_id(
                    str(event.event_id),
                    "measurement_delivery",
                    state.vehicle_id,
                    "identity",
                    0,
                ),
                delivered_at_us=event.observed_at_us,
                kind=MeasurementEventKind.IDENTITY,
                packet=None,
                attempt=None,
                identity=event,
            ),
            state.vehicle_id,
        )

    def _queue_measurement_delivery(
        self, event: MeasurementDeliveryEvent, vehicle_id: str
    ) -> None:
        self._measurement_queue.push(event)
        self._queue.push(
            make_event(
                EventKind.MEASUREMENT_DELIVERY,
                int(event.delivered_at_us),
                _event_id(
                    str(event.event_id),
                    EventKind.MEASUREMENT_DELIVERY.value,
                    vehicle_id,
                    "phase60",
                    0,
                ),
                vehicle_id,
                causal_parent_id=str(event.event_id),
            )
        )

    def _handle_measurement_delivery_batch(self, markers) -> None:
        deliveries = self._measurement_queue.pop_due(self._time_us)
        marker_parents = tuple(
            sorted(str(marker.header.causal_parent_id) for marker in markers)
        )
        delivery_ids = tuple(sorted(str(event.event_id) for event in deliveries))
        if marker_parents != delivery_ids:
            raise RuntimeError("phase-60 markers do not match measurement deliveries")
        self._measurement_deliveries.extend(deliveries)

    def _schedule_packet(self, vehicle_id: str, time_us: int) -> None:
        if time_us < self._time_us:
            raise RuntimeError("cannot schedule packet generation in the past")
        if time_us < int(self._require_tape().simulation_end_us):
            self._queue.push(
                make_event(
                    EventKind.PACKET_GENERATE,
                    time_us,
                    _event_id(None, EventKind.PACKET_GENERATE.value, vehicle_id, None, time_us),
                    vehicle_id,
                )
            )

    def _schedule_tx(self, vehicle_id: str, earliest_us: int, *, strict: bool) -> None:
        state = self._vehicles[vehicle_id]
        lower_bound = max(earliest_us, self._time_us + (1 if strict else 0))
        time_us = _next_tx_time(lower_bound, state.grant.rri_us, state.grant.slot_offset_us)
        if time_us < self._time_us or (strict and time_us <= self._time_us):
            raise RuntimeError("cannot schedule a retroactive transmission")
        if time_us < int(self._require_tape().simulation_end_us):
            self._queue.push(
                make_event(
                    EventKind.TX,
                    time_us,
                    _event_id(
                        None,
                        EventKind.TX.value,
                        vehicle_id,
                        str(state.grant.logical_subchannel_id),
                        time_us,
                    ),
                    vehicle_id,
                )
            )

    def _require_tape(self) -> DisturbanceTape:
        if self._tape is None:
            raise RuntimeError("plant is not reset")
        return self._tape


def _event_id(
    causal_parent_id: str | None,
    event_kind: str,
    entity_id: str,
    resource_id: str | None,
    ordinal: int,
) -> str:
    return stable_event_id(
        causal_parent_id,
        event_kind,
        entity_id,
        resource_id,
        ordinal,
    )


def _validate_snapshot_for_restore(snapshot: PlantSnapshot) -> None:
    if not isinstance(snapshot, PlantSnapshot):
        raise ValueError("snapshot must be a PlantSnapshot")
    if not isinstance(snapshot.tape, DisturbanceTape):
        raise ValueError("snapshot tape must be a DisturbanceTape")

    time_us = snapshot.time_us
    if isinstance(time_us, bool) or not isinstance(time_us, int):
        raise ValueError("snapshot time must be an integer")
    simulation_start_us = int(snapshot.tape.simulation_start_us)
    simulation_end_us = int(snapshot.tape.simulation_end_us)
    if not simulation_start_us <= time_us <= simulation_end_us:
        raise ValueError("snapshot time is outside the tape simulation window")

    if not isinstance(snapshot.vehicles, tuple) or not all(
        isinstance(state, VehicleState) for state in snapshot.vehicles
    ):
        raise ValueError("snapshot vehicles must be VehicleState values")
    vehicle_ids = tuple(state.vehicle_id for state in snapshot.vehicles)
    if len(set(vehicle_ids)) != len(vehicle_ids):
        raise ValueError("snapshot vehicle states must be unique")
    controlled_vehicle_id = str(snapshot.tape.controlled_vehicle_id)
    if controlled_vehicle_id not in vehicle_ids:
        raise ValueError("snapshot is missing the controlled vehicle state")
    tape_vehicles = {str(item.vehicle_id): item for item in snapshot.tape.vehicles}
    if set(vehicle_ids) != set(tape_vehicles):
        raise ValueError("snapshot vehicle states must exactly match the tape")
    vehicles_by_id = {state.vehicle_id: state for state in snapshot.vehicles}
    for state in snapshot.vehicles:
        tape_vehicle = tape_vehicles[state.vehicle_id]
        if state.departure_time_us != int(tape_vehicle.departure_simulation_time_us):
            raise ValueError("snapshot vehicle departure does not match the tape")
        if state.grant.rri_us not in LEGAL_RRI_US:
            raise ValueError("snapshot vehicle grant uses an illegal RRI")
        if state.grant.slot_offset_us % snapshot.tape.slot_duration_us:
            raise ValueError("snapshot vehicle grant is not slot aligned")
        if state.grant.logical_subchannel_id >= snapshot.tape.logical_subchannel_count:
            raise ValueError("snapshot vehicle grant is outside the logical grid")
        _validate_vehicle_snapshot_state(snapshot, state, tape_vehicle)

    watermark_time = snapshot.queue_processed_time_us
    watermark_priority = snapshot.queue_processed_priority
    if (watermark_time is None) != (watermark_priority is None):
        raise ValueError("snapshot queue watermark fields must be provided together")
    if watermark_time is not None:
        if (
            isinstance(watermark_time, bool)
            or not isinstance(watermark_time, int)
            or not simulation_start_us <= watermark_time <= time_us
        ):
            raise ValueError("snapshot queue watermark time is inconsistent")
        if (
            isinstance(watermark_priority, bool)
            or not isinstance(watermark_priority, int)
            or watermark_priority not in set(EVENT_PRIORITIES.values())
        ):
            raise ValueError("snapshot queue watermark priority is invalid")

    if not isinstance(snapshot.event_queue, tuple):
        raise ValueError("snapshot event queue must be a tuple")
    consumed_event_ids = snapshot.queue_consumed_event_ids
    if not isinstance(consumed_event_ids, tuple) or any(
        not isinstance(event_id, str) or not event_id
        for event_id in consumed_event_ids
    ):
        raise ValueError("snapshot consumed event IDs must be non-empty strings")
    if len(set(consumed_event_ids)) != len(consumed_event_ids):
        raise ValueError("snapshot consumed event IDs must be unique")
    queued_event_ids = tuple(str(event.header.event_id) for event in snapshot.event_queue)
    if set(consumed_event_ids).intersection(queued_event_ids):
        raise ValueError("snapshot event ID cannot be both queued and consumed")
    for event in snapshot.event_queue:
        event_time_us = int(event.header.time_us)
        if not time_us <= event_time_us < simulation_end_us:
            raise ValueError("snapshot contains an event outside its remaining time window")
        if event.vehicle_id not in vehicles_by_id:
            raise ValueError("snapshot event references an unknown vehicle")

    opportunity = snapshot.pending_opportunity
    if opportunity is not None:
        opportunity_vehicle_id = str(opportunity.vehicle_id)
        if int(opportunity.time_us) != time_us:
            raise ValueError("pending opportunity time does not match the snapshot")
        if int(opportunity.time_us) >= simulation_end_us:
            raise ValueError("pending opportunity lies outside the simulation window")
        if opportunity_vehicle_id != controlled_vehicle_id:
            raise ValueError("pending opportunity does not target the controlled vehicle")
        state = vehicles_by_id[opportunity_vehicle_id]
        if opportunity.reservation_version != state.reservation_version:
            raise ValueError("pending opportunity reservation version is stale")
        if not state.present:
            raise ValueError("pending opportunity vehicle is not present")
        if tuple(int(value) for value in opportunity.legal_rri_us) != LEGAL_RRI_US:
            raise ValueError("pending opportunity legal RRI domain is inconsistent")
        if int(opportunity.current_rri_us) != state.grant.rri_us:
            raise ValueError("pending opportunity current RRI does not match the grant")

    queued_deliveries = snapshot.measurement_delivery_queue
    committed_deliveries = snapshot.measurement_deliveries
    if not isinstance(queued_deliveries, tuple) or not isinstance(
        committed_deliveries, tuple
    ):
        raise ValueError("snapshot measurement collections must be tuples")
    queued_ids = tuple(str(event.event_id) for event in queued_deliveries)
    committed_ids = tuple(str(event.event_id) for event in committed_deliveries)
    if len(set(queued_ids)) != len(queued_ids):
        raise ValueError("snapshot measurement queue contains duplicate deliveries")
    if len(set(committed_ids)) != len(committed_ids):
        raise ValueError("snapshot committed measurements contain duplicates")
    if set(queued_ids).intersection(committed_ids):
        raise ValueError("measurement delivery cannot be both queued and committed")
    if any(
        not time_us <= int(event.delivered_at_us) < simulation_end_us
        for event in queued_deliveries
    ):
        raise ValueError("queued measurement delivery time is inconsistent")
    if any(
        not (
            simulation_start_us
            <= int(event.delivered_at_us)
            < simulation_end_us
            and int(event.delivered_at_us) <= time_us
        )
        for event in committed_deliveries
    ):
        raise ValueError("committed measurement delivery time is inconsistent")

    markers = tuple(
        event
        for event in snapshot.event_queue
        if event.header.kind is EventKind.MEASUREMENT_DELIVERY
    )
    marker_parent_ids = tuple(
        str(event.header.causal_parent_id)
        for event in markers
        if event.header.causal_parent_id is not None
    )
    if tuple(sorted(marker_parent_ids)) != tuple(sorted(queued_ids)):
        raise ValueError("phase-60 markers do not match queued measurement deliveries")
    queued_by_id = {str(event.event_id): event for event in queued_deliveries}
    for marker in markers:
        delivery = queued_by_id[str(marker.header.causal_parent_id)]
        if int(marker.header.time_us) != int(delivery.delivered_at_us):
            raise ValueError("phase-60 marker time does not match its delivery")

    _validate_snapshot_history(snapshot, vehicles_by_id, tape_vehicles)
    _validate_snapshot_by_replay(snapshot)


def _validate_snapshot_by_replay(snapshot: PlantSnapshot) -> None:
    if not isinstance(snapshot.action_history, tuple) or not all(
        isinstance(action, ControlAction) for action in snapshot.action_history
    ):
        raise ValueError("snapshot action history must contain ControlAction values")

    replay = DiscreteEventSPSPlant()
    replay.reset(snapshot.tape)
    for action in snapshot.action_history:
        result = replay.advance_until(int(snapshot.tape.simulation_end_us))
        if len(result.opportunities) != 1:
            raise ValueError("snapshot action history has no matching opportunity")
        opportunity = result.opportunities[0]
        if action.opportunity_id != opportunity.opportunity_id:
            raise ValueError("snapshot action history is not causally ordered")
        replay.apply(opportunity, action)

    replay.advance_until(
        snapshot.time_us + int(snapshot.pending_opportunity is not None)
    )
    if replay.snapshot() != snapshot:
        raise ValueError("snapshot does not match deterministic plant replay")


def _validate_vehicle_snapshot_state(snapshot, state, tape_vehicle) -> None:
    time_us = snapshot.time_us
    arrival_us = int(tape_vehicle.arrival_simulation_time_us)
    departure_us = int(tape_vehicle.departure_simulation_time_us)
    arrival_processed = arrival_us == int(snapshot.tape.simulation_start_us) or (
        arrival_us < time_us
        or _queue_phase_has_run(snapshot, arrival_us, EVENT_PRIORITIES[EventKind.VEHICLE_ARRIVAL])
    )
    departure_processed = departure_us < time_us or _queue_phase_has_run(
        snapshot,
        departure_us,
        EVENT_PRIORITIES[EventKind.VEHICLE_DEPARTURE],
    )
    if state.present != (arrival_processed and not departure_processed):
        raise ValueError("snapshot vehicle presence contradicts the event timeline")
    if not state.present and state.waiting_packet_generation_us is not None:
        raise ValueError("an absent vehicle cannot retain a waiting packet")
    if state.present and state.next_packet_generation_us < time_us:
        raise ValueError("present vehicle next packet generation is in the past")
    if state.waiting_packet_generation_us is not None:
        if state.waiting_packet_generation_us > time_us:
            raise ValueError("waiting packet generation is in the future")
        if state.waiting_packet_generation_us < arrival_us:
            raise ValueError("waiting packet predates vehicle arrival")
    period_us = snapshot.tape.packet_period_us
    packet_phase_us = tape_vehicle.packet_phase_us
    for packet_time_us in (
        state.next_packet_generation_us,
        state.waiting_packet_generation_us,
    ):
        if packet_time_us is not None and (
            packet_time_us < arrival_us
            or (packet_time_us - packet_phase_us) % period_us
        ):
            raise ValueError("vehicle packet timestamp is outside its frozen lattice")
    if state.present and state.last_success_generation_us > time_us:
        raise ValueError("present vehicle last success is in the future")
    if state.reservation_version < state.reselection_ordinal:
        raise ValueError("reservation version precedes the reselection ordinal")


def _queue_phase_has_run(snapshot, event_time_us: int, priority: int) -> bool:
    watermark_time = snapshot.queue_processed_time_us
    watermark_priority = snapshot.queue_processed_priority
    if watermark_time is None or watermark_priority is None:
        return False
    return watermark_time > event_time_us or (
        watermark_time == event_time_us and watermark_priority >= priority
    )


def _validate_snapshot_history(snapshot, vehicles_by_id, tape_vehicles) -> None:
    if not isinstance(snapshot.trace, PlantTrace):
        raise ValueError("snapshot trace must be a PlantTrace")
    attempts = snapshot.trace.tx_attempts
    truth_events = snapshot.trace.truth_events
    if not isinstance(attempts, tuple) or not all(
        isinstance(item, TxAttemptRecord) for item in attempts
    ):
        raise ValueError("snapshot attempts must be TxAttemptRecord values")
    if not isinstance(truth_events, tuple) or not all(
        isinstance(item, TruthEventRecord) for item in truth_events
    ):
        raise ValueError("snapshot truth events must be TruthEventRecord values")
    if not isinstance(snapshot.observations, tuple) or not all(
        isinstance(item, ReceiverPacketObservation) for item in snapshot.observations
    ):
        raise ValueError("snapshot observations must be packet observations")

    attempts_by_vehicle = {vehicle_id: [] for vehicle_id in vehicles_by_id}
    expected_observations = {}
    previous_attempt_time_us = int(snapshot.tape.simulation_start_us)
    channel_draws = {
        (str(item.vehicle_id), item.ordinal): item.uniform_u64
        for item in snapshot.tape.channel_draws
    }
    for attempt in attempts:
        if attempt.vehicle_id not in vehicles_by_id:
            raise ValueError("trace attempt references an unknown vehicle")
        attempt_time_us = attempt.time_us
        tape_vehicle = tape_vehicles[attempt.vehicle_id]
        if (
            attempt_time_us < previous_attempt_time_us
            or attempt_time_us > snapshot.time_us
            or attempt_time_us < int(tape_vehicle.arrival_simulation_time_us)
            or attempt_time_us > int(tape_vehicle.departure_simulation_time_us)
        ):
            raise ValueError("trace attempt time is inconsistent")
        previous_attempt_time_us = attempt_time_us
        ordinal = len(attempts_by_vehicle[attempt.vehicle_id])
        expected_attempt_id = _event_id(
            None, "attempt", attempt.vehicle_id, None, ordinal
        )
        if attempt.attempt_id != expected_attempt_id:
            raise ValueError("trace attempt ID does not match its ordinal")
        if not int(tape_vehicle.arrival_simulation_time_us) <= attempt.packet_generation_us <= attempt_time_us:
            raise ValueError("trace attempt packet timestamp is inconsistent")
        if (
            attempt.packet_generation_us - tape_vehicle.packet_phase_us
        ) % snapshot.tape.packet_period_us:
            raise ValueError("trace attempt packet is outside its frozen lattice")
        if not 0 <= attempt.logical_subchannel_id < snapshot.tape.logical_subchannel_count:
            raise ValueError("trace attempt subchannel is outside the logical grid")
        if channel_draws.get((attempt.vehicle_id, ordinal)) != attempt.channel_uniform_u64:
            raise ValueError("trace attempt channel draw does not match the tape")
        if attempt.success != (attempt.outcome is TerminalOutcome.RX_SUCCESS) or (
            attempt.collided != (attempt.outcome is TerminalOutcome.COLLISION)
        ):
            raise ValueError("trace attempt terminal flags are inconsistent")
        attempts_by_vehicle[attempt.vehicle_id].append(attempt)
        if attempt.success:
            observation = ReceiverPacketObservation(
                schema_version=RECEIVER_PACKET_OBSERVATION_SCHEMA_VERSION,
                event_id=_event_id(
                    attempt.attempt_id,
                    "rx_success",
                    attempt.vehicle_id,
                    str(attempt.logical_subchannel_id),
                    0,
                ),
                vehicle_id=VehicleId(attempt.vehicle_id),
                observed_at_us=SimTimeUs(attempt.time_us),
                packet_generation_us=SimTimeUs(attempt.packet_generation_us),
            )
            expected_observations[str(observation.event_id)] = observation

    actual_observations = {
        str(observation.event_id): observation for observation in snapshot.observations
    }
    if len(actual_observations) != len(snapshot.observations) or (
        actual_observations != expected_observations
    ):
        raise ValueError("packet observations do not exactly match successful attempts")

    _validate_vehicle_history_counters(
        snapshot,
        vehicles_by_id,
        tape_vehicles,
        attempts_by_vehicle,
        truth_events,
    )
    _validate_measurement_history(
        snapshot,
        attempts,
        expected_observations,
        truth_events,
        tape_vehicles,
    )


def _validate_vehicle_history_counters(
    snapshot,
    vehicles_by_id,
    tape_vehicles,
    attempts_by_vehicle,
    truth_events,
) -> None:
    truth_ids = tuple(item.event_id for item in truth_events)
    if len(set(truth_ids)) != len(truth_ids):
        raise ValueError("snapshot truth event IDs must be unique")
    if tuple(item.time_us for item in truth_events) != tuple(
        sorted(item.time_us for item in truth_events)
    ):
        raise ValueError("snapshot truth events are not time ordered")
    for event in truth_events:
        if event.vehicle_id not in vehicles_by_id:
            raise ValueError("truth event references an unknown vehicle")
        if not int(snapshot.tape.simulation_start_us) <= event.time_us <= snapshot.time_us:
            raise ValueError("truth event time is outside the snapshot history")
        if event.event_id != _event_id(
            None,
            event.kind.value,
            event.vehicle_id,
            None,
            event.reservation_version,
        ):
            raise ValueError("truth event ID is inconsistent")

    controlled_vehicle_id = str(snapshot.tape.controlled_vehicle_id)
    pending = snapshot.pending_opportunity
    for vehicle_id, state in vehicles_by_id.items():
        vehicle_attempts = attempts_by_vehicle[vehicle_id]
        if state.tx_ordinal != len(vehicle_attempts):
            raise ValueError("vehicle TX ordinal does not match the trace history")
        successful_generations = tuple(
            item.packet_generation_us for item in vehicle_attempts if item.success
        )
        expected_last_success = max(
            (int(tape_vehicles[vehicle_id].last_success_generation_us_at_entry),)
            + successful_generations
        )
        if state.last_success_generation_us != expected_last_success:
            raise ValueError("vehicle last success does not match the trace history")

        reselections = tuple(
            event
            for event in truth_events
            if event.vehicle_id == vehicle_id
            and event.kind is TruthEventKind.RESERVATION_RESELECT
        )
        if len(reselections) != state.reselection_ordinal:
            raise ValueError("vehicle reselection ordinal does not match truth history")
        reselection_versions = tuple(event.reservation_version for event in reselections)
        if tuple(sorted(set(reselection_versions))) != reselection_versions:
            raise ValueError("vehicle reselection versions are not strictly increasing")

        departure_events = tuple(
            event
            for event in truth_events
            if event.vehicle_id == vehicle_id
            and event.kind is TruthEventKind.VEHICLE_DEPARTURE
        )
        departure_count = len(departure_events)
        if vehicle_id == controlled_vehicle_id:
            opportunities = tuple(
                event
                for event in truth_events
                if event.vehicle_id == vehicle_id
                and event.kind is TruthEventKind.CONTROL_OPPORTUNITY
            )
            expected_opportunity_count = len(snapshot.action_history) + int(
                pending is not None
            )
            if len(opportunities) != expected_opportunity_count:
                raise ValueError("controlled opportunity history is incomplete")
            opportunity_versions = tuple(
                event.reservation_version for event in opportunities
            )
            if opportunity_versions != tuple(sorted(set(opportunity_versions))):
                raise ValueError("controlled opportunity versions are not strictly increasing")
            if any(
                action.opportunity_id
                != ControlOpportunityId(
                    _event_id(
                        None,
                        "opportunity",
                        vehicle_id,
                        None,
                        opportunity.reservation_version,
                    )
                )
                for action, opportunity in zip(
                    snapshot.action_history,
                    opportunities,
                    strict=False,
                )
            ):
                raise ValueError("controlled action history does not match opportunities")
            if (state.reselection_counter == 0) != (pending is not None):
                raise ValueError("controlled counter and pending opportunity disagree")
        else:
            if state.reservation_version != state.reselection_ordinal + departure_count:
                raise ValueError("background reservation version contradicts truth history")
            if state.reselection_counter == 0:
                raise ValueError(
                    "background vehicle cannot be restored at an unresolved expiry"
                )

    expected_arrivals = {
        _event_id(None, TruthEventKind.VEHICLE_ARRIVAL.value, vehicle_id, None, 0)
        for vehicle_id, tape_vehicle in tape_vehicles.items()
        if int(tape_vehicle.arrival_simulation_time_us) > int(snapshot.tape.simulation_start_us)
        and _queue_phase_has_run(
            snapshot,
            int(tape_vehicle.arrival_simulation_time_us),
            EVENT_PRIORITIES[EventKind.VEHICLE_ARRIVAL],
        )
    }
    actual_arrivals = {
        event.event_id
        for event in truth_events
        if event.kind is TruthEventKind.VEHICLE_ARRIVAL
    }
    if actual_arrivals != expected_arrivals:
        raise ValueError("vehicle arrival truth history is incomplete")

    expected_departures = {
        _event_id(
            None,
            TruthEventKind.VEHICLE_DEPARTURE.value,
            vehicle_id,
            None,
            vehicles_by_id[vehicle_id].reservation_version,
        )
        for vehicle_id, tape_vehicle in tape_vehicles.items()
        if int(tape_vehicle.departure_simulation_time_us) < int(snapshot.tape.simulation_end_us)
        and _queue_phase_has_run(
            snapshot,
            int(tape_vehicle.departure_simulation_time_us),
            EVENT_PRIORITIES[EventKind.VEHICLE_DEPARTURE],
        )
    }
    actual_departures = {
        event.event_id
        for event in truth_events
        if event.kind is TruthEventKind.VEHICLE_DEPARTURE
    }
    if actual_departures != expected_departures:
        raise ValueError("vehicle departure truth history is incomplete")


def _validate_measurement_history(
    snapshot,
    attempts,
    expected_observations,
    truth_events,
    tape_vehicles,
) -> None:
    expected = {}
    for attempt in attempts:
        payload = ReceiverAttemptObservation(
            schema_version=RECEIVER_ATTEMPT_OBSERVATION_SCHEMA_VERSION,
            event_id=attempt.attempt_id,
            vehicle_id=VehicleId(attempt.vehicle_id),
            observed_at_us=SimTimeUs(attempt.time_us),
            decoded=attempt.success,
            busy_slot_us=SimTimeUs(attempt.time_us),
        )
        delivery_id = _event_id(
            attempt.attempt_id,
            "measurement_delivery",
            attempt.vehicle_id,
            "attempt",
            0,
        )
        expected[delivery_id] = (MeasurementEventKind.ATTEMPT, payload)
    for observation in expected_observations.values():
        delivery_id = _event_id(
            str(observation.event_id),
            "measurement_delivery",
            str(observation.vehicle_id),
            "packet",
            0,
        )
        expected[delivery_id] = (MeasurementEventKind.PACKET, observation)

    identity_origins = [
        (
            vehicle_id,
            int(tape_vehicle.arrival_simulation_time_us),
            ReceiverObservableKind.AUTHENTICATED_HANDOVER,
            0,
        )
        for vehicle_id, tape_vehicle in tape_vehicles.items()
        if int(tape_vehicle.arrival_simulation_time_us) == int(snapshot.tape.simulation_start_us)
    ]
    identity_origins.extend(
        (
            event.vehicle_id,
            event.time_us,
            ReceiverObservableKind.AUTHENTICATED_HANDOVER,
            event.reservation_version,
        )
        for event in truth_events
        if event.kind is TruthEventKind.VEHICLE_ARRIVAL
    )
    identity_origins.extend(
        (
            event.vehicle_id,
            event.time_us,
            ReceiverObservableKind.AUTHENTICATED_DEPARTURE,
            event.reservation_version,
        )
        for event in truth_events
        if event.kind is TruthEventKind.VEHICLE_DEPARTURE
    )
    for vehicle_id, event_time_us, kind, reservation_version in identity_origins:
        tape_vehicle = tape_vehicles[vehicle_id]
        last_success = int(tape_vehicle.last_success_generation_us_at_entry)
        payload = ReceiverIdentityEvent(
            schema_version=RECEIVER_IDENTITY_EVENT_SCHEMA_VERSION,
            event_id=_event_id(None, kind.value, vehicle_id, None, reservation_version),
            vehicle_id=VehicleId(vehicle_id),
            observed_at_us=SimTimeUs(event_time_us),
            kind=kind,
            last_success_generation_us=(
                SimTimeUs(last_success)
                if kind is ReceiverObservableKind.AUTHENTICATED_HANDOVER
                and last_success >= 0
                else None
            ),
            removal_reason=None,
        )
        delivery_id = _event_id(
            str(payload.event_id),
            "measurement_delivery",
            vehicle_id,
            "identity",
            0,
        )
        expected[delivery_id] = (MeasurementEventKind.IDENTITY, payload)

    deliveries = snapshot.measurement_delivery_queue + snapshot.measurement_deliveries
    actual = {str(event.event_id): event for event in deliveries}
    if set(actual) != set(expected):
        raise ValueError("measurement delivery history is incomplete")
    for event_id, event in actual.items():
        expected_kind, expected_payload = expected[event_id]
        payload = event.packet or event.attempt or event.identity
        if event.kind is not expected_kind or payload != expected_payload:
            raise ValueError("measurement delivery payload does not match plant history")


def _next_lattice_time(start_us: int, phase_us: int, period_us: int) -> int:
    if phase_us >= start_us:
        return phase_us
    steps = (start_us - phase_us + period_us - 1) // period_us
    return phase_us + steps * period_us


def _next_tx_time(earliest_us: int, rri_us: int, offset_us: int) -> int:
    if earliest_us <= offset_us:
        return offset_us
    steps = (earliest_us - offset_us + rri_us - 1) // rri_us
    return offset_us + steps * rri_us
