"""Stable, fail-closed event queue implementing the frozen ten-phase order."""

from dataclasses import dataclass
import heapq

from exp09.contracts.events import EVENT_HEADER_SCHEMA_VERSION, EventHeader, EventKind
from exp09.contracts.ids import EventId
from exp09.contracts.time import SimTimeUs

QUEUED_EVENT_SCHEMA_VERSION = "exp09-queued-event-v1"

EVENT_PRIORITIES = {
    EventKind.TX: 10,
    EventKind.RX_SUCCESS: 10,
    EventKind.COLLISION: 10,
    EventKind.CHANNEL_ERROR: 10,
    EventKind.VEHICLE_DEPARTURE: 20,
    EventKind.VEHICLE_ARRIVAL: 30,
    EventKind.HANDOVER_ARRIVAL: 30,
    EventKind.PACKET_GENERATE: 40,
    EventKind.BACKGROUND_COUNTER_EXPIRE: 50,
    EventKind.BACKGROUND_RESOURCE_RESELECT: 50,
    EventKind.MEASUREMENT_DELIVERY: 60,
    EventKind.RECEIVER_LEDGER_UPDATE: 60,
    EventKind.CONTROLLED_COUNTER_EXPIRE: 70,
    EventKind.CONTROL_OPPORTUNITY: 70,
    EventKind.SUPERVISOR_RESPONSE_ARRIVAL: 80,
    EventKind.PROPOSAL_VERIFICATION: 80,
    EventKind.PENDING_PROGRAM_UPDATE: 80,
    EventKind.FRAME_BUILD: 90,
    EventKind.CONTROLLER_DECISION: 90,
    EventKind.RESERVATION_COMMIT: 100,
    EventKind.FUTURE_TX_SCHEDULE: 100,
}


@dataclass(frozen=True, slots=True)
class QueuedEvent:
    schema_version: str
    header: EventHeader
    vehicle_id: str

    def __post_init__(self) -> None:
        if self.schema_version != QUEUED_EVENT_SCHEMA_VERSION:
            raise ValueError("unsupported queued-event schema version")

    @property
    def sort_key(self) -> tuple[int, int, str]:
        return (
            int(self.header.time_us),
            EVENT_PRIORITIES[self.header.kind],
            str(self.header.event_id),
        )


class EventQueue:
    def __init__(
        self,
        events: tuple[QueuedEvent, ...] = (),
        *,
        processed_time_us: int | None = None,
        processed_priority: int | None = None,
        consumed_event_ids: tuple[str, ...] = (),
    ) -> None:
        if (processed_time_us is None) != (processed_priority is None):
            raise ValueError("queue watermark time and priority must be provided together")
        if not isinstance(consumed_event_ids, tuple) or any(
            not isinstance(event_id, str) or not event_id
            for event_id in consumed_event_ids
        ):
            raise ValueError("consumed event IDs must be a tuple of non-empty strings")
        if len(set(consumed_event_ids)) != len(consumed_event_ids):
            raise ValueError("consumed event IDs must be unique")
        self._heap: list[tuple[tuple[int, int, str], QueuedEvent]] = []
        self._events_by_id: dict[str, QueuedEvent] = {}
        self._consumed_event_ids = set(consumed_event_ids)
        self._processed_time_us = processed_time_us
        self._processed_priority = processed_priority
        for event in events:
            self.push(event)

    def push(self, event: QueuedEvent) -> None:
        event_id = str(event.header.event_id)
        if event_id in self._events_by_id or event_id in self._consumed_event_ids:
            raise ValueError(f"duplicate event_id: {event_id}")
        event_time = int(event.header.time_us)
        event_priority = EVENT_PRIORITIES[event.header.kind]
        if self._processed_time_us is not None:
            if event_time < self._processed_time_us:
                raise ValueError("cannot insert an event before the processed queue watermark")
            if (
                event_time == self._processed_time_us
                and event_priority <= self._processed_priority
            ):
                raise ValueError(
                    "same-time child event must use a strictly later unprocessed priority"
                )
        heapq.heappush(self._heap, (event.sort_key, event))
        self._events_by_id[event_id] = event

    def pop(self) -> QueuedEvent:
        if not self._heap:
            raise IndexError("event queue is empty")
        self._mark_phase_processed(self._heap[0][0][0], self._heap[0][0][1])
        event = heapq.heappop(self._heap)[1]
        del self._events_by_id[str(event.header.event_id)]
        self._consumed_event_ids.add(str(event.header.event_id))
        return event

    def peek_time_us(self) -> int | None:
        if not self._heap:
            return None
        return self._heap[0][0][0]

    def peek_priority(self) -> int | None:
        if not self._heap:
            return None
        return self._heap[0][0][1]

    def pop_phase_batch(self) -> tuple[QueuedEvent, ...]:
        """Pop one timestamp/priority phase so handlers can enqueue later phases."""

        time_us = self.peek_time_us()
        if time_us is None:
            return ()
        priority = self.peek_priority()
        assert priority is not None
        self._mark_phase_processed(time_us, priority)
        batch = []
        while self._heap and self._heap[0][0][:2] == (time_us, priority):
            event = heapq.heappop(self._heap)[1]
            del self._events_by_id[str(event.header.event_id)]
            self._consumed_event_ids.add(str(event.header.event_id))
            batch.append(event)
        return tuple(batch)

    def pop_time_batch(self) -> tuple[QueuedEvent, ...]:
        """Pop an already-closed timestamp; runtime dispatch must use phase batches."""

        time_us = self.peek_time_us()
        if time_us is None:
            return ()
        batch = []
        while self.peek_time_us() == time_us:
            batch.extend(self.pop_phase_batch())
        return tuple(batch)

    def cancel_where(self, predicate) -> tuple[QueuedEvent, ...]:
        cancelled = tuple(event for _, event in self._heap if predicate(event))
        if not cancelled:
            return ()
        cancelled_ids = {str(event.header.event_id) for event in cancelled}
        self._heap = [
            (key, event)
            for key, event in self._heap
            if str(event.header.event_id) not in cancelled_ids
        ]
        heapq.heapify(self._heap)
        for event_id in cancelled_ids:
            del self._events_by_id[event_id]
        self._consumed_event_ids.update(cancelled_ids)
        return tuple(sorted(cancelled, key=lambda event: event.sort_key))

    def snapshot(self) -> tuple[QueuedEvent, ...]:
        return tuple(event for _, event in sorted(self._heap))

    def consumed_event_ids(self) -> tuple[str, ...]:
        return tuple(sorted(self._consumed_event_ids))

    @property
    def processed_time_us(self) -> int | None:
        return self._processed_time_us

    @property
    def processed_priority(self) -> int | None:
        return self._processed_priority

    def _mark_phase_processed(self, time_us: int, priority: int) -> None:
        if self._processed_time_us is None or time_us > self._processed_time_us:
            self._processed_time_us = time_us
            self._processed_priority = priority
            return
        if time_us < self._processed_time_us:
            raise RuntimeError("event queue attempted to move backwards")
        assert self._processed_priority is not None
        if priority < self._processed_priority:
            raise RuntimeError("event queue attempted to reopen a processed phase")
        if priority > self._processed_priority:
            self._processed_priority = priority


def make_event(
    kind: EventKind,
    time_us: int,
    event_id: str,
    vehicle_id: str,
    *,
    causal_parent_id: str | None = None,
) -> QueuedEvent:
    return QueuedEvent(
        schema_version=QUEUED_EVENT_SCHEMA_VERSION,
        header=EventHeader(
            schema_version=EVENT_HEADER_SCHEMA_VERSION,
            event_id=EventId(event_id),
            kind=kind,
            time_us=SimTimeUs(time_us),
            causal_parent_id=(
                EventId(causal_parent_id) if causal_parent_id is not None else None
            ),
        ),
        vehicle_id=vehicle_id,
    )
