"""C04 plant state, truth trace, and complete snapshot records."""

from dataclasses import dataclass, replace
from enum import Enum

from exp09.contracts.actions import ControlAction, ControlOpportunity
from exp09.contracts.ids import require_identifier
from exp09.contracts.observable import MeasurementDeliveryEvent, ReceiverPacketObservation
from exp09.contracts.tape import DisturbanceTape, TapeGrant
from exp09.contracts.time import require_non_negative_int, require_positive_int

from .event_queue import QueuedEvent

VEHICLE_STATE_SCHEMA_VERSION = "exp09-vehicle-state-v1"
TX_ATTEMPT_RECORD_SCHEMA_VERSION = "exp09-tx-attempt-record-v1"
TRUTH_EVENT_RECORD_SCHEMA_VERSION = "exp09-truth-event-record-v1"
PLANT_TRACE_SCHEMA_VERSION = "exp09-plant-trace-v1"
PLANT_SNAPSHOT_SCHEMA_VERSION = "exp09-plant-snapshot-v4"
PLANT_ADVANCE_RESULT_SCHEMA_VERSION = "exp09-plant-advance-result-v3"


class TerminalOutcome(str, Enum):
    RX_SUCCESS = "RX_SUCCESS"
    COLLISION = "COLLISION"
    CHANNEL_ERROR = "CHANNEL_ERROR"


class TruthEventKind(str, Enum):
    VEHICLE_ARRIVAL = "VEHICLE_ARRIVAL"
    VEHICLE_DEPARTURE = "VEHICLE_DEPARTURE"
    RESERVATION_RESELECT = "RESERVATION_RESELECT"
    CONTROL_OPPORTUNITY = "CONTROL_OPPORTUNITY"


@dataclass(frozen=True, slots=True)
class VehicleState:
    schema_version: str
    vehicle_id: str
    present: bool
    grant: TapeGrant
    next_packet_generation_us: int
    waiting_packet_generation_us: int | None
    last_success_generation_us: int
    reselection_counter: int
    reservation_version: int
    departure_time_us: int
    tx_ordinal: int
    reselection_ordinal: int

    def __post_init__(self) -> None:
        if self.schema_version != VEHICLE_STATE_SCHEMA_VERSION:
            raise ValueError("unsupported vehicle-state schema version")
        require_identifier(self.vehicle_id, "vehicle_id")
        if not isinstance(self.present, bool):
            raise ValueError("present must be boolean")
        if not isinstance(self.grant, TapeGrant):
            raise ValueError("grant must be a TapeGrant")
        require_non_negative_int(
            self.next_packet_generation_us, "next_packet_generation_us"
        )
        if self.waiting_packet_generation_us is not None:
            require_non_negative_int(
                self.waiting_packet_generation_us,
                "waiting_packet_generation_us",
            )
            if self.waiting_packet_generation_us >= self.next_packet_generation_us:
                raise ValueError(
                    "waiting packet generation must precede the next generation"
                )
        if isinstance(self.last_success_generation_us, bool) or not isinstance(
            self.last_success_generation_us, int
        ):
            raise ValueError("last_success_generation_us must be an integer")
        require_non_negative_int(self.reselection_counter, "reselection_counter")
        require_non_negative_int(self.reservation_version, "reservation_version")
        require_positive_int(self.departure_time_us, "departure_time_us")
        require_non_negative_int(self.tx_ordinal, "tx_ordinal")
        require_non_negative_int(self.reselection_ordinal, "reselection_ordinal")

    def with_grant(self, grant: TapeGrant, counter: int) -> "VehicleState":
        return replace(
            self,
            grant=grant,
            reselection_counter=counter,
            reservation_version=self.reservation_version + 1,
            reselection_ordinal=self.reselection_ordinal + 1,
        )


@dataclass(frozen=True, slots=True)
class TxAttemptRecord:
    schema_version: str
    attempt_id: str
    time_us: int
    vehicle_id: str
    packet_generation_us: int
    logical_subchannel_id: int
    channel_uniform_u64: int
    outcome: TerminalOutcome
    collided: bool
    success: bool

    def __post_init__(self) -> None:
        if self.schema_version != TX_ATTEMPT_RECORD_SCHEMA_VERSION:
            raise ValueError("unsupported tx-attempt-record schema version")


@dataclass(frozen=True, slots=True)
class TruthEventRecord:
    schema_version: str
    event_id: str
    time_us: int
    kind: TruthEventKind
    vehicle_id: str
    reservation_version: int

    def __post_init__(self) -> None:
        if self.schema_version != TRUTH_EVENT_RECORD_SCHEMA_VERSION:
            raise ValueError("unsupported truth-event-record schema version")


@dataclass(frozen=True, slots=True)
class PlantTrace:
    schema_version: str
    tx_attempts: tuple[TxAttemptRecord, ...]
    truth_events: tuple[TruthEventRecord, ...]

    def __post_init__(self) -> None:
        if self.schema_version != PLANT_TRACE_SCHEMA_VERSION:
            raise ValueError("unsupported plant-trace schema version")


@dataclass(frozen=True, slots=True)
class PlantSnapshot:
    schema_version: str
    time_us: int
    tape: DisturbanceTape
    vehicles: tuple[VehicleState, ...]
    event_queue: tuple[QueuedEvent, ...]
    pending_opportunity: ControlOpportunity | None
    trace: PlantTrace
    observations: tuple[ReceiverPacketObservation, ...]
    measurement_delivery_queue: tuple[MeasurementDeliveryEvent, ...]
    measurement_deliveries: tuple[MeasurementDeliveryEvent, ...]
    queue_processed_time_us: int | None
    queue_processed_priority: int | None
    queue_consumed_event_ids: tuple[str, ...]
    action_history: tuple[ControlAction, ...] = ()

    def __post_init__(self) -> None:
        if self.schema_version != PLANT_SNAPSHOT_SCHEMA_VERSION:
            raise ValueError("unsupported plant-snapshot schema version")
        if not isinstance(self.action_history, tuple) or not all(
            isinstance(action, ControlAction) for action in self.action_history
        ):
            raise ValueError("action_history must contain ControlAction values")


@dataclass(frozen=True, slots=True)
class PlantAdvanceResult:
    schema_version: str
    snapshot: PlantSnapshot
    opportunities: tuple[ControlOpportunity, ...]
    trace_delta: PlantTrace
    measurement_delivery_delta: tuple[MeasurementDeliveryEvent, ...]

    def __post_init__(self) -> None:
        if self.schema_version != PLANT_ADVANCE_RESULT_SCHEMA_VERSION:
            raise ValueError("unsupported plant-advance-result schema version")
