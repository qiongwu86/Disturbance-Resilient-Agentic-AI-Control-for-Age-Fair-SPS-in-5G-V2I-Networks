"""Corrected C04 discrete-event plant package."""
