# Release validation

Validation was performed from the assembled source-only directory on 2026-08-27. No formal
experiment, RL training run, or provider/API call was executed.

## Results

- Included test suite: 150 passed, with 101 subtests passed.
- Strict Ruff target (`src`, `tests`, and `scripts/reproduce_smoke.py`): passed.
- Python syntax parse: 140 files passed.
- Locked dependency resolution dry run: 76 packages resolved from `uv.lock` with CPython 3.12.12.
- Data-free deterministic smoke: four cases passed; repeated runs produced identical metrics and
  integrity hashes.
- Smoke case-set SHA-256: `1A2D76C1C4FC07B36A77D8F2865FA8B82D7EC2CB2B6BCED2AEF794DA4EF22766`.
- Forbidden-content scan: no LaTeX, PDF, figure, CSV/TSV result, checkpoint, bytecode, log, virtual
  environment, generated experiment-output directory, or credential value was included.
- Machine-specific path scan: no local absolute Windows or Unix home path was found in the
  packaged implementation or configuration.

The source package contains the non-secret model and provider configuration, including the model
identifier and credential-file locator. The credential file itself is not included.
