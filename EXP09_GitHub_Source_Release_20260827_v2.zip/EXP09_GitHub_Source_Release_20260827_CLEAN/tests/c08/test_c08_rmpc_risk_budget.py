from copy import deepcopy
import unittest
from unittest.mock import patch

from _support import PROJECT_ROOT, SRC_ROOT

from exp09.control.budget import (
    MODEL_TRANSITION_BUDGET_LEDGER_SCHEMA_VERSION,
    ModelTransitionBudgetLedger,
)
from exp09.control.calibration import (
    RESIDUAL_CALIBRATION_RECORD_SCHEMA_VERSION,
    ResidualCalibrationRecord,
)
from exp09.control.candidate_generator import ExpiryCandidateGenerator
from exp09.control.commitment import COMMITMENT_RECORD_SCHEMA_VERSION, CommitmentRecord
from exp09.control.risk_gate import RiskGate, RiskGateDecisionStatus, RiskThreshold
from exp09.control.robust_selector import (
    ROBUST_SCENARIO_EVALUATION_SCHEMA_VERSION,
    RmpcSameEvaluator,
    RobustScenarioEvaluation,
    RobustSelection,
    RobustSelector,
)
from exp09.contracts.actions import OPPORTUNITY_SCHEMA_VERSION, ControlOpportunity, ControlOpportunityId
from exp09.contracts.actions import control_action_fingerprint
from exp09.contracts.observable import (
    OBSERVABLE_COUNTER_SCHEMA_VERSION,
    OBSERVED_USER_AGE_SCHEMA_VERSION,
    OBSERVED_USER_STATE_SCHEMA_VERSION,
    IdentityState,
    ObservableCounter,
    ObservableCounterKind,
    ObservedUserAge,
    ObservedUserState,
)
from exp09.contracts.ids import VehicleId
from exp09.contracts.observable import OBSERVABLE_FRAME_SCHEMA_VERSION, ObservableFrame
from exp09.contracts.time import DurationUs, SimTimeUs
from exp09.model.approximate import ApproximateSPSModel, ApproximateSPSModelConfig
from exp09.model.interfaces import (
    MODEL_TRANSITION_BUDGET_SCHEMA_VERSION,
    ModelTransitionBudget,
    RolloutEvaluation,
    RolloutSet,
)
from exp09.model.scenarios import ForecastBatchConfig, ForecastBatchFactory
from exp09.model.state_estimator import ControllerStateEstimator
from exp09.validation.c08 import validate_c08_bundle
from exp09.validation.import_boundaries import lint_import_boundaries


class C08RmpcRiskBudgetTests(unittest.TestCase):
    def _frame(self) -> ObservableFrame:
        return ObservableFrame(
            schema_version=OBSERVABLE_FRAME_SCHEMA_VERSION,
            source_sequence=1,
            causal_cutoff_us=SimTimeUs(1000),
            summary_payload_hash="a" * 64,
            counters=(
                self._counter(ObservableCounterKind.FRESH_OBSERVED, 2),
                self._counter(ObservableCounterKind.STALE_RETAINED, 0),
                self._counter(ObservableCounterKind.UNKNOWN_RETAINED, 0),
                self._counter(ObservableCounterKind.BUSY_SENSING_UNIT, 1),
                self._counter(ObservableCounterKind.TOTAL_SENSING_UNIT, 10),
                self._counter(ObservableCounterKind.DECODED_SUCCESS, 8),
                self._counter(ObservableCounterKind.OBSERVABLE_DECODE_TRIAL, 10),
            ),
            missing_reasons=(),
            observed_user_ages=(
                ObservedUserAge(
                    schema_version=OBSERVED_USER_AGE_SCHEMA_VERSION,
                    vehicle_id=VehicleId("vehicle-0"),
                    age_us=250_000,
                ),
                ObservedUserAge(
                    schema_version=OBSERVED_USER_AGE_SCHEMA_VERSION,
                    vehicle_id=VehicleId("vehicle-1"),
                    age_us=80_000,
                ),
            ),
            observed_users=(
                ObservedUserState(
                    schema_version=OBSERVED_USER_STATE_SCHEMA_VERSION,
                    vehicle_id=VehicleId("vehicle-0"),
                    ledger_state=IdentityState.FRESH,
                    identity_silence_us=0,
                    age_us=250_000,
                    age_missing_reason=None,
                ),
                ObservedUserState(
                    schema_version=OBSERVED_USER_STATE_SCHEMA_VERSION,
                    vehicle_id=VehicleId("vehicle-1"),
                    ledger_state=IdentityState.FRESH,
                    identity_silence_us=0,
                    age_us=80_000,
                    age_missing_reason=None,
                ),
            ),
            removals=(),
        )

    def _counter(self, kind: ObservableCounterKind, value: int) -> ObservableCounter:
        return ObservableCounter(
            schema_version=OBSERVABLE_COUNTER_SCHEMA_VERSION,
            kind=kind,
            value=value,
        )

    def _opportunity(self) -> ControlOpportunity:
        return ControlOpportunity(
            schema_version=OPPORTUNITY_SCHEMA_VERSION,
            opportunity_id=ControlOpportunityId("op-1"),
            vehicle_id=VehicleId("vehicle-0"),
            time_us=SimTimeUs(1000),
            reservation_version=1,
            current_rri_us=DurationUs(50000),
            legal_rri_us=(DurationUs(20000), DurationUs(50000)),
        )

    def _candidate_set(self):
        return ExpiryCandidateGenerator().generate(self._frame(), self._opportunity())

    def _evaluation(self, action_hash: str, member: str, risk_ppm: int) -> RobustScenarioEvaluation:
        return RobustScenarioEvaluation(
            schema_version=ROBUST_SCENARIO_EVALUATION_SCHEMA_VERSION,
            action_hash=action_hash,
            scenario_member_id=member,
            source_state_hash="b" * 64,
            scenario_artifact_hash="c" * 64,
            rollout_metric_hash="d" * 64,
            horizon_us=100000,
            transition_count=100,
            risk_ppm=risk_ppm,
        )

    def _calibration(self, threshold_ppm: int = 250000) -> ResidualCalibrationRecord:
        return ResidualCalibrationRecord(
            schema_version=RESIDUAL_CALIBRATION_RECORD_SCHEMA_VERSION,
            calibration_id="constructed-threshold",
            threshold_ppm=threshold_ppm,
            reachable_min_ppm=100000,
            reachable_max_ppm=900000,
            source="constructed_c08_fixture",
        )

    def test_c08_package_boundaries_are_clean(self) -> None:
        self.assertEqual(lint_import_boundaries(SRC_ROOT), ())

    def test_budget_ledger_conserves_transitions_and_rejects_overflow(self) -> None:
        ledger = ModelTransitionBudgetLedger(
            schema_version=MODEL_TRANSITION_BUDGET_LEDGER_SCHEMA_VERSION,
            ledger_id="ledger-1",
            total_transitions=100,
            allocations=(),
        )
        first = ledger.allocate(
            consumer_id="Full",
            transition_count=40,
            evidence_hash="1" * 64,
        )
        second = first.allocate(
            consumer_id="RMPC_SameEvaluator",
            transition_count=40,
            evidence_hash="2" * 64,
        )
        self.assertEqual(second.consumed_transitions, 80)
        self.assertEqual(second.remaining_transitions, 20)
        self.assertNotEqual(first.ledger_hash, second.ledger_hash)

        with self.assertRaises(ValueError):
            second.allocate(
                consumer_id="overflow",
                transition_count=21,
                evidence_hash="3" * 64,
            )

    def test_full_and_rmpc_budget_equality_is_explicit(self) -> None:
        ledger = ModelTransitionBudgetLedger(
            schema_version=MODEL_TRANSITION_BUDGET_LEDGER_SCHEMA_VERSION,
            ledger_id="ledger-1",
            total_transitions=200,
            allocations=(),
        )
        ledger = ledger.allocate(consumer_id="Full", transition_count=64, evidence_hash="4" * 64)
        ledger = ledger.allocate(
            consumer_id="RMPC_SameEvaluator",
            transition_count=64,
            evidence_hash="4" * 64,
        )
        ledger.require_equal_allocations("Full", "RMPC_SameEvaluator")
        self.assertEqual(ledger.allocated_transitions("Full"), 64)

        unequal = ledger.allocate(
            consumer_id="Full",
            transition_count=1,
            evidence_hash="5" * 64,
        )
        with self.assertRaisesRegex(ValueError, "allocations are not equal"):
            unequal.require_equal_allocations("Full", "RMPC_SameEvaluator")

    def test_robust_selector_uses_worst_case_risk_and_hash_tie_break(self) -> None:
        candidate_set = self._candidate_set()
        action_hashes = tuple(control_action_fingerprint(action) for action in candidate_set.actions)
        evaluations = (
            self._evaluation(action_hashes[0], "member-a", 300000),
            self._evaluation(action_hashes[0], "member-b", 300000),
            self._evaluation(action_hashes[1], "member-a", 200000),
            self._evaluation(action_hashes[1], "member-b", 200000),
            self._evaluation(action_hashes[2], "member-a", 200000),
            self._evaluation(action_hashes[2], "member-b", 200000),
        )
        selection = RobustSelector().select(candidate_set, evaluations)
        self.assertEqual(selection.worst_case_risk_ppm, 200000)
        self.assertEqual(selection.action_hash, min(action_hashes[1], action_hashes[2]))

        with self.assertRaises(ValueError):
            RobustSelector().select(candidate_set, evaluations[:-1])

    def test_rmpc_same_evaluator_calls_c07_model_and_binds_rollout_hashes(self) -> None:
        frame = self._frame()
        opportunity = self._opportunity()
        candidate_set = ExpiryCandidateGenerator().generate(frame, opportunity)
        model_config = ApproximateSPSModelConfig.create()
        model = ApproximateSPSModel(model_config)
        state = ControllerStateEstimator().estimate(frame, opportunity)
        scenarios = ForecastBatchFactory(
            ForecastBatchConfig.create(model_config_hash=model_config.config_hash)
        ).build(state)
        result = RmpcSameEvaluator().evaluate(
            frame=frame,
            state=state,
            candidate_set=candidate_set,
            scenarios=scenarios,
            horizon_us=100000,
            budget=ModelTransitionBudget(
                schema_version=MODEL_TRANSITION_BUDGET_SCHEMA_VERSION,
                budget_id="rmpc-budget",
                total_transitions=100000,
                consumed_transitions=0,
            ),
            model=model,
            ledger_id="rmpc-ledger",
        )
        self.assertEqual(len(result.evaluations), len(candidate_set.actions) * len(scenarios.members))
        self.assertEqual(
            tuple(result.scenario_member_order),
            tuple(member.member_id for member in scenarios.members),
        )
        self.assertGreater(result.budget_ledger.consumed_transitions, 0)
        risks = {evaluation.risk_ppm for evaluation in result.evaluations}
        self.assertGreater(len(risks), 1)

        forged_rollout = model.rollout(
            frame,
            state,
            candidate_set.actions[0],
            scenarios,
            DurationUs(100000),
            ModelTransitionBudget(
                schema_version=MODEL_TRANSITION_BUDGET_SCHEMA_VERSION,
                budget_id="forge-budget",
                total_transitions=100000,
                consumed_transitions=0,
            ),
        ).evaluations[0]
        with self.assertRaisesRegex(ValueError, "predicted_metric_hash"):
            RolloutEvaluation(
                schema_version=forged_rollout.schema_version,
                action_hash=forged_rollout.action_hash,
                scenario_member_id=forged_rollout.scenario_member_id,
                scenario_artifact_hash=forged_rollout.scenario_artifact_hash,
                source_state_hash=forged_rollout.source_state_hash,
                predicted_metric_hash="f" * 64,
                selected_rri_us=forged_rollout.selected_rri_us,
                horizon_us=forged_rollout.horizon_us,
                transition_count=forged_rollout.transition_count,
                time_average_mean_age_us=forged_rollout.time_average_mean_age_us + 1,
                time_average_worst_age_us=forged_rollout.time_average_worst_age_us,
                terminal_mean_age_us=forged_rollout.terminal_mean_age_us,
                terminal_worst_age_us=forged_rollout.terminal_worst_age_us,
                first_attempt_mean_age_us=forged_rollout.first_attempt_mean_age_us,
                first_attempt_worst_age_us=forged_rollout.first_attempt_worst_age_us,
                predicted_collision_risk_ppm=forged_rollout.predicted_collision_risk_ppm,
                expected_collision_events_ppm=forged_rollout.expected_collision_events_ppm,
                trace=forged_rollout.trace,
            )

        class BadScenarioArtifactModel:
            def rollout(self, frame, state, action, scenarios, horizon_us, budget):
                rollout_set = model.rollout(frame, state, action, scenarios, horizon_us, budget)
                first = rollout_set.evaluations[0]
                bad = RolloutEvaluation.create(
                    action_hash=first.action_hash,
                    scenario_member_id=first.scenario_member_id,
                    scenario_artifact_hash="9" * 64,
                    source_state_hash=first.source_state_hash,
                    selected_rri_us=first.selected_rri_us,
                    horizon_us=first.horizon_us,
                    transition_count=first.transition_count,
                    time_average_mean_age_us=first.time_average_mean_age_us,
                    time_average_worst_age_us=first.time_average_worst_age_us,
                    terminal_mean_age_us=first.terminal_mean_age_us,
                    terminal_worst_age_us=first.terminal_worst_age_us,
                    first_attempt_mean_age_us=first.first_attempt_mean_age_us,
                    first_attempt_worst_age_us=first.first_attempt_worst_age_us,
                    predicted_collision_risk_ppm=first.predicted_collision_risk_ppm,
                    expected_collision_events_ppm=first.expected_collision_events_ppm,
                    trace=first.trace,
                )
                return RolloutSet(
                    schema_version=rollout_set.schema_version,
                    budget_before=rollout_set.budget_before,
                    budget_after=rollout_set.budget_after,
                    evaluations=(bad, *rollout_set.evaluations[1:]),
                )

        with self.assertRaisesRegex(ValueError, "scenario artifact"):
            RmpcSameEvaluator().evaluate(
                frame=frame,
                state=state,
                candidate_set=candidate_set,
                scenarios=scenarios,
                horizon_us=100000,
                budget=ModelTransitionBudget(
                    schema_version=MODEL_TRANSITION_BUDGET_SCHEMA_VERSION,
                    budget_id="bad-artifact-budget",
                    total_transitions=100000,
                    consumed_transitions=0,
                ),
                model=BadScenarioArtifactModel(),
                ledger_id="bad-artifact-ledger",
            )

    def test_risk_gate_accepts_boundary_rejects_fallback_and_marks_unavoidable(self) -> None:
        candidate_set = self._candidate_set()
        actions = candidate_set.actions
        action_hashes = tuple(control_action_fingerprint(action) for action in actions)
        evaluations = (
            self._evaluation(action_hashes[0], "member-a", 250000),
            self._evaluation(action_hashes[1], "member-a", 500000),
            self._evaluation(action_hashes[2], "member-a", 700000),
        )
        calibration = self._calibration(250000)
        boundary_selection = RobustSelection(
            schema_version="exp09-robust-selection-v1",
            action=actions[0],
            action_hash=action_hashes[0],
            worst_case_risk_ppm=250000,
            scenario_count=1,
            tie_break_key=action_hashes[0],
        )
        accepted = RiskGate().evaluate(
            selection=boundary_selection,
            candidate_set=candidate_set,
            evaluations=evaluations,
            calibration=calibration,
        )
        self.assertEqual(accepted.status, RiskGateDecisionStatus.ACCEPT)

        unsafe_selection = RobustSelection(
            schema_version="exp09-robust-selection-v1",
            action=actions[1],
            action_hash=action_hashes[1],
            worst_case_risk_ppm=500000,
            scenario_count=1,
            tie_break_key=action_hashes[1],
        )
        fallback = RiskGate().evaluate(
            selection=unsafe_selection,
            candidate_set=candidate_set,
            evaluations=evaluations,
            calibration=calibration,
        )
        self.assertEqual(fallback.status, RiskGateDecisionStatus.REJECT_FALLBACK)
        self.assertEqual(fallback.action_hash, action_hashes[0])

        unavoidable = RiskGate().evaluate(
            selection=RobustSelection(
                schema_version="exp09-robust-selection-v1",
                action=actions[1],
                action_hash=action_hashes[1],
                worst_case_risk_ppm=800000,
                scenario_count=1,
                tie_break_key=action_hashes[1],
            ),
            candidate_set=candidate_set,
            evaluations=tuple(
                self._evaluation(action_hash, "member-a", 800000)
                for action_hash in action_hashes
            ),
            calibration=calibration,
        )
        self.assertEqual(unavoidable.status, RiskGateDecisionStatus.UNAVOIDABLE_RISK)
        self.assertIsNotNone(unavoidable.action)
        self.assertEqual(unavoidable.action_hash, min(action_hashes))

    def test_risk_gate_rejects_selection_not_bound_to_robust_evidence(self) -> None:
        candidate_set = self._candidate_set()
        actions = candidate_set.actions
        action_hashes = tuple(control_action_fingerprint(action) for action in actions)
        evaluations = tuple(
            self._evaluation(action_hash, "member-a", 500000)
            for action_hash in action_hashes
        )
        forged = RobustSelection(
            schema_version="exp09-robust-selection-v1",
            action=actions[0],
            action_hash=action_hashes[0],
            worst_case_risk_ppm=100000,
            scenario_count=1,
            tie_break_key=action_hashes[0],
        )
        with self.assertRaisesRegex(ValueError, "selection risk does not match"):
            RiskGate().evaluate(
                selection=forged,
                candidate_set=candidate_set,
                evaluations=evaluations,
                calibration=self._calibration(250000),
            )

        foreign_candidate_set = ExpiryCandidateGenerator().generate(
            self._frame(),
            ControlOpportunity(
                schema_version=OPPORTUNITY_SCHEMA_VERSION,
                opportunity_id=ControlOpportunityId("op-2"),
                vehicle_id=VehicleId("vehicle-0"),
                time_us=SimTimeUs(2000),
                reservation_version=2,
                current_rri_us=DurationUs(20000),
                legal_rri_us=(DurationUs(20000),),
            ),
        )
        foreign_action = foreign_candidate_set.actions[0]
        foreign_selection = RobustSelection(
            schema_version="exp09-robust-selection-v1",
            action=foreign_action,
            action_hash=control_action_fingerprint(foreign_action),
            worst_case_risk_ppm=100000,
            scenario_count=1,
            tie_break_key=control_action_fingerprint(foreign_action),
        )
        with self.assertRaisesRegex(ValueError, "selection action is not in"):
            RiskGate().evaluate(
                selection=foreign_selection,
                candidate_set=candidate_set,
                evaluations=evaluations,
                calibration=self._calibration(250000),
            )

    def test_threshold_provenance_must_be_reachable(self) -> None:
        with self.assertRaises(ValueError):
            ResidualCalibrationRecord(
                schema_version=RESIDUAL_CALIBRATION_RECORD_SCHEMA_VERSION,
                calibration_id="bad-threshold",
                threshold_ppm=950000,
                reachable_min_ppm=100000,
                reachable_max_ppm=900000,
                source="constructed_c08_fixture",
            )

        calibration = self._calibration(250000)
        threshold = RiskThreshold.from_calibration(calibration)
        self.assertEqual(threshold.provenance_hash, calibration.provenance_hash)
        with self.assertRaisesRegex(ValueError, "ResidualCalibrationRecord"):
            RiskThreshold.from_calibration(object())  # type: ignore[arg-type]

    def test_commitment_record_matches_risk_gate_status(self) -> None:
        candidate_set = self._candidate_set()
        action = candidate_set.actions[0]
        action_hash = control_action_fingerprint(action)
        decision = RiskGate().evaluate(
            selection=RobustSelection(
                schema_version="exp09-robust-selection-v1",
                action=action,
                action_hash=action_hash,
                worst_case_risk_ppm=100000,
                scenario_count=1,
                tie_break_key=action_hash,
            ),
            candidate_set=candidate_set,
            evaluations=tuple(
                self._evaluation(
                    control_action_fingerprint(candidate),
                    "member-a",
                    100000 if candidate == action else 200000,
                )
                for candidate in candidate_set.actions
            ),
            calibration=self._calibration(250000),
        )
        record = CommitmentRecord(
            schema_version=COMMITMENT_RECORD_SCHEMA_VERSION,
            commitment_id="commitment-1",
            decision=decision,
            budget_ledger_hash="5" * 64,
            committed=True,
        )
        self.assertTrue(record.committed)

        with self.assertRaises(ValueError):
            CommitmentRecord(
                schema_version=COMMITMENT_RECORD_SCHEMA_VERSION,
                commitment_id="commitment-1",
                decision=decision,
                budget_ledger_hash="5" * 64,
                committed=False,
            )

        unavoidable = RiskGate().evaluate(
            selection=RobustSelection(
                schema_version="exp09-robust-selection-v1",
                action=action,
                action_hash=action_hash,
                worst_case_risk_ppm=800000,
                scenario_count=1,
                tie_break_key=action_hash,
            ),
            candidate_set=candidate_set,
            evaluations=tuple(
                self._evaluation(
                    control_action_fingerprint(candidate),
                    "member-a",
                    800000,
                )
                for candidate in candidate_set.actions
            ),
            calibration=self._calibration(250000),
        )
        unavoidable_record = CommitmentRecord(
            schema_version=COMMITMENT_RECORD_SCHEMA_VERSION,
            commitment_id="commitment-unavoidable",
            decision=unavoidable,
            budget_ledger_hash="6" * 64,
            committed=True,
        )
        self.assertEqual(
            unavoidable_record.decision.status,
            RiskGateDecisionStatus.UNAVOIDABLE_RISK,
        )

    def test_c08_bundle_is_hash_bound(self) -> None:
        report = validate_c08_bundle(PROJECT_ROOT)
        self.assertTrue(report.passed, report.reasons)

    def test_c08_bundle_cannot_enable_performance_claims(self) -> None:
        from exp09.validation import c08

        original = c08._load_json

        def load_with_performance_claim(path):
            record = original(path)
            if path.name == "rmpc_mechanism_report.json":
                record = deepcopy(record)
                record["performance_claim_allowed"] = True
            return record

        with patch.object(c08, "_load_json", side_effect=load_with_performance_claim):
            report = validate_c08_bundle(PROJECT_ROOT)
        self.assertFalse(report.passed)
        self.assertIn("C08 RMPC mechanism report performance_claim_allowed mismatch", report.reasons)

    def test_c08_bundle_rejects_resealed_constructed_case_semantics(self) -> None:
        from exp09.validation import c08

        original = c08._load_json

        def load_with_tampered_case(path):
            record = original(path)
            if path.name == "risk_gate_activation_report.json":
                record = deepcopy(record)
                record["constructed_cases"][2]["fallback_risk_ppm"] = 900000
            return record

        with patch.object(c08, "_load_json", side_effect=load_with_tampered_case):
            report = validate_c08_bundle(PROJECT_ROOT)
        self.assertFalse(report.passed)
        self.assertIn("C08 RiskGate constructed case list mismatch", report.reasons)


if __name__ == "__main__":
    unittest.main()
