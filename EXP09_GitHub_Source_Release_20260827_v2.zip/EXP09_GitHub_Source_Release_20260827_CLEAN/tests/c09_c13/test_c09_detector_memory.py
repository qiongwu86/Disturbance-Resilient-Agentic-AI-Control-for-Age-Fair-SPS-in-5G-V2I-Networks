import unittest

from _support import SRC_ROOT

from exp09.control.detector import (
    DETECTOR_CONFIG_SCHEMA_VERSION,
    DETECTOR_OBSERVATION_SCHEMA_VERSION,
    DetectorConfig,
    DetectorObservation,
    DetectorStatus,
    CausalEwmaCusumDetector,
    CalibrationMemoryEntry,
    CalibrationMemorySnapshot,
    ObservationLifecycle,
    assert_residual_only_memory_config,
    detector_mechanism_metrics,
)
from exp09.contracts.time import SimTimeUs
from exp09.validation.import_boundaries import lint_import_boundaries


class C09DetectorMemoryTests(unittest.TestCase):
    def _config(self) -> DetectorConfig:
        return DetectorConfig(
            schema_version=DETECTOR_CONFIG_SCHEMA_VERSION,
            detector_id="detector-1",
            ewma_alpha_ppm=500000,
            watch_threshold_ppm=200000,
            active_threshold_ppm=400000,
            exit_threshold_ppm=150000,
            cusum_reference_ppm=100000,
            cusum_drift_ppm=20000,
            cusum_active_threshold_ppm=600000,
            min_active_observations=2,
        )

    def _obs(self, index: int, residual: int, lifecycle=ObservationLifecycle.COMPLETE):
        return DetectorObservation(
            schema_version=DETECTOR_OBSERVATION_SCHEMA_VERSION,
            observation_id=f"obs-{index}",
            case_id="case-1",
            arm_id="arm-a",
            time_us=SimTimeUs(index * 1000),
            risk_residual_ppm=residual,
            lifecycle=lifecycle,
        )

    def test_c09_package_boundaries_are_clean(self) -> None:
        self.assertEqual(lint_import_boundaries(SRC_ROOT), ())

    def test_detector_triggers_with_delay_and_preserves_prefix_invariance(self) -> None:
        detector = CausalEwmaCusumDetector(self._config())
        state = detector_state = __import__(
            "exp09.control.detector", fromlist=["DetectorState"]
        ).DetectorState.initial(
            detector_id="detector-1",
            case_id="case-1",
            arm_id="arm-a",
            time_us=SimTimeUs(0),
        )
        observations = (
            self._obs(1, 50000),
            self._obs(2, 100000),
            self._obs(3, 600000),
            self._obs(4, 650000),
            self._obs(5, 700000),
        )
        prefix = detector.replay(state, observations[:3])
        full = detector.replay(detector_state, observations)
        self.assertEqual(tuple(dec.next_state.state_hash for dec in prefix), tuple(dec.next_state.state_hash for dec in full[:3]))
        self.assertTrue(any(dec.triggered for dec in full))
        self.assertEqual(full[-1].next_state.status, DetectorStatus.ACTIVE)

        metrics = detector_mechanism_metrics(full, disturbance_start_index=2)
        self.assertEqual(metrics.false_positive_count, 0)
        self.assertEqual(metrics.first_trigger_index, 3)
        self.assertEqual(metrics.detection_delay_steps, 1)

    def test_detector_rejects_cross_case_and_censored_lifecycle_is_explicit(self) -> None:
        detector = CausalEwmaCusumDetector(self._config())
        from exp09.control.detector import DetectorState

        state = DetectorState.initial(
            detector_id="detector-1",
            case_id="case-1",
            arm_id="arm-a",
            time_us=SimTimeUs(0),
        )
        bad_case = DetectorObservation(
            schema_version=DETECTOR_OBSERVATION_SCHEMA_VERSION,
            observation_id="bad",
            case_id="case-2",
            arm_id="arm-a",
            time_us=SimTimeUs(1000),
            risk_residual_ppm=100000,
            lifecycle=ObservationLifecycle.COMPLETE,
        )
        with self.assertRaisesRegex(ValueError, "case/arm isolated"):
            detector.update(state, bad_case)

        censored = detector.update(state, self._obs(1, 0, ObservationLifecycle.CENSORED))
        self.assertTrue(censored.censored)
        self.assertTrue(censored.next_state.complete)

    def test_calibration_memory_is_residual_only_and_case_arm_isolated(self) -> None:
        entries = (
            CalibrationMemoryEntry(
                schema_version="exp09-calibration-memory-entry-v1",
                case_id="case-1",
                arm_id="arm-a",
                residual_ppm=100000,
                lifecycle=ObservationLifecycle.COMPLETE,
            ),
            CalibrationMemoryEntry(
                schema_version="exp09-calibration-memory-entry-v1",
                case_id="case-1",
                arm_id="arm-a",
                residual_ppm=300000,
                lifecycle=ObservationLifecycle.COMPLETE,
            ),
            CalibrationMemoryEntry(
                schema_version="exp09-calibration-memory-entry-v1",
                case_id="case-2",
                arm_id="arm-a",
                residual_ppm=900000,
                lifecycle=ObservationLifecycle.COMPLETE,
            ),
            CalibrationMemoryEntry(
                schema_version="exp09-calibration-memory-entry-v1",
                case_id="case-1",
                arm_id="arm-a",
                residual_ppm=700000,
                lifecycle=ObservationLifecycle.COMPLETE,
            ),
            CalibrationMemoryEntry(
                schema_version="exp09-calibration-memory-entry-v1",
                case_id="case-1",
                arm_id="arm-a",
                residual_ppm=999999,
                lifecycle=ObservationLifecycle.CENSORED,
            ),
        )
        snapshot = CalibrationMemorySnapshot.create(memory_id="memory-1", entries=entries)
        self.assertEqual(snapshot.interval_for(case_id="case-1", arm_id="arm-a"), (100000, 700000))
        self.assertEqual(snapshot.mean_absolute_error_ppm(case_id="case-1", arm_id="arm-a"), 366666)
        self.assertNotIn("selected_action", snapshot.snapshot_hash)

        assert_residual_only_memory_config({"residual_source": "detector", "max_age": 3})
        with self.assertRaisesRegex(ValueError, "residual-only"):
            assert_residual_only_memory_config({"action_bonus": 1})

        with self.assertRaisesRegex(ValueError, "snapshot_hash does not bind"):
            CalibrationMemorySnapshot(
                schema_version=snapshot.schema_version,
                memory_id=snapshot.memory_id,
                snapshot_hash=snapshot.snapshot_hash,
                entries=entries[:-1],
            )
        with self.assertRaisesRegex(ValueError, "snapshot_hash does not bind"):
            CalibrationMemorySnapshot(
                schema_version=snapshot.schema_version,
                memory_id=snapshot.memory_id,
                snapshot_hash="e" * 64,
                entries=entries,
            )


if __name__ == "__main__":
    unittest.main()
