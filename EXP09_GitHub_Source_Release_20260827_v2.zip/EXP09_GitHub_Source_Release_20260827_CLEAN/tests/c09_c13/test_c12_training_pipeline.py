import unittest

from _support import SRC_ROOT

from exp09.baselines.registry import C07_METHOD_IDS
from exp09.baselines.training_pipeline import (
    BASELINE_QUALIFICATION_SCHEMA_VERSION,
    CHECKPOINT_RECORD_SCHEMA_VERSION,
    SEED_RECORD_SCHEMA_VERSION,
    CheckpointRecord,
    TRAINING_SPEC_SCHEMA_VERSION,
    BaselineQualificationRecord,
    TrainingManifest,
    TrainingSeedRecord,
    TrainingSpec,
    build_synthetic_training_manifest,
)
from exp09.validation.import_boundaries import lint_import_boundaries


class C12TrainingPipelineTests(unittest.TestCase):
    def _spec(self, method_id: str = "DQN") -> TrainingSpec:
        return TrainingSpec(
            schema_version=TRAINING_SPEC_SCHEMA_VERSION,
            spec_id=f"{method_id}-spec",
            method_id=method_id,
            observation_fields=("busy_fraction_ppm", "decode_success_ppm", "current_rri_us"),
            reward_fields=("mean_age_delta", "collision_penalty"),
            transition_budget=32,
            validation_split_hash="b" * 64,
        )

    def test_c12_package_boundaries_are_clean(self) -> None:
        self.assertEqual(lint_import_boundaries(SRC_ROOT), ())

    def test_training_spec_rejects_truth_observation_and_seed_selection_is_validation_only(self) -> None:
        with self.assertRaisesRegex(ValueError, "truth"):
            TrainingSpec(
                schema_version=TRAINING_SPEC_SCHEMA_VERSION,
                spec_id="bad",
                method_id="DQN",
                observation_fields=("plant_state_truth",),
                reward_fields=("mean_age_delta",),
                transition_budget=32,
                validation_split_hash="b" * 64,
            )
        manifest = build_synthetic_training_manifest(spec=self._spec(), seeds=(1, 2, 3))
        self.assertEqual(len(manifest.seed_records), 3)
        self.assertEqual(manifest.total_consumed_transitions, 96)
        selected = [item for item in manifest.checkpoints if item.selected_by_validation]
        self.assertEqual(len(selected), 1)
        self.assertEqual(
            selected[0],
            max(manifest.checkpoints, key=lambda item: (item.validation_score_ppm, item.checkpoint_hash)),
        )

    def test_baseline_qualification_preserves_all_registered_methods(self) -> None:
        manifests = tuple(
            build_synthetic_training_manifest(spec=self._spec(method_id), seeds=(1, 2))
            for method_id in C07_METHOD_IDS
        )
        record = BaselineQualificationRecord(
            schema_version=BASELINE_QUALIFICATION_SCHEMA_VERSION,
            qualification_id="b-all",
            method_ids=C07_METHOD_IDS,
            manifest_hashes=tuple(manifest.manifest_hash for manifest in manifests),
            manifests=manifests,
            capability_status="QUALIFIED_FOR_PIPELINE_NO_PERFORMANCE_CLAIM",
        )
        self.assertEqual(record.method_ids, C07_METHOD_IDS)

        with self.assertRaisesRegex(ValueError, "full registered method set"):
            BaselineQualificationRecord(
                schema_version=BASELINE_QUALIFICATION_SCHEMA_VERSION,
                qualification_id="bad",
                method_ids=C07_METHOD_IDS[:-1],
                manifest_hashes=("c" * 64,),
                manifests=manifests[:1],
                capability_status="QUALIFIED_FOR_PIPELINE_NO_PERFORMANCE_CLAIM",
            )

        with self.assertRaisesRegex(ValueError, "bound to TrainingManifest"):
            BaselineQualificationRecord(
                schema_version=BASELINE_QUALIFICATION_SCHEMA_VERSION,
                qualification_id="bad-hash-source",
                method_ids=C07_METHOD_IDS,
                manifest_hashes=tuple(manifest.checkpoints[0].checkpoint_hash for manifest in manifests),
                manifests=manifests,
                capability_status="QUALIFIED_FOR_PIPELINE_NO_PERFORMANCE_CLAIM",
            )

    def test_seed_checkpoint_and_manifest_hashes_bind_semantics(self) -> None:
        manifest = build_synthetic_training_manifest(spec=self._spec(), seeds=(1, 2, 3))
        seed = manifest.seed_records[0]
        with self.assertRaisesRegex(ValueError, "seed_hash does not bind"):
            TrainingSeedRecord(
                schema_version=SEED_RECORD_SCHEMA_VERSION,
                method_id=seed.method_id,
                seed=seed.seed + 10,
                seed_hash=seed.seed_hash,
                transition_budget=seed.transition_budget,
                consumed_transitions=seed.consumed_transitions,
            )
        with self.assertRaisesRegex(ValueError, "seed_hash does not bind"):
            TrainingSeedRecord(
                schema_version=SEED_RECORD_SCHEMA_VERSION,
                method_id=seed.method_id,
                seed=seed.seed,
                seed_hash="e" * 64,
                transition_budget=seed.transition_budget + 1,
                consumed_transitions=seed.consumed_transitions,
            )

        checkpoint = manifest.checkpoints[0]
        with self.assertRaisesRegex(ValueError, "checkpoint_hash does not bind"):
            CheckpointRecord(
                schema_version=CHECKPOINT_RECORD_SCHEMA_VERSION,
                checkpoint_id=checkpoint.checkpoint_id,
                method_id=checkpoint.method_id,
                seed_hash=checkpoint.seed_hash,
                validation_score_ppm=checkpoint.validation_score_ppm + 1,
                checkpoint_hash=checkpoint.checkpoint_hash,
                selected_by_validation=checkpoint.selected_by_validation,
            )
        with self.assertRaisesRegex(ValueError, "checkpoint_hash does not bind"):
            CheckpointRecord(
                schema_version=CHECKPOINT_RECORD_SCHEMA_VERSION,
                checkpoint_id=checkpoint.checkpoint_id,
                method_id=checkpoint.method_id,
                seed_hash=checkpoint.seed_hash,
                validation_score_ppm=checkpoint.validation_score_ppm,
                checkpoint_hash="f" * 64,
                selected_by_validation=not checkpoint.selected_by_validation,
            )

        with self.assertRaisesRegex(ValueError, "manifest_hash does not bind"):
            TrainingManifest(
                schema_version=manifest.schema_version,
                manifest_hash="d" * 64,
                spec=manifest.spec,
                seed_records=manifest.seed_records[::-1],
                checkpoints=manifest.checkpoints,
            )


if __name__ == "__main__":
    unittest.main()
