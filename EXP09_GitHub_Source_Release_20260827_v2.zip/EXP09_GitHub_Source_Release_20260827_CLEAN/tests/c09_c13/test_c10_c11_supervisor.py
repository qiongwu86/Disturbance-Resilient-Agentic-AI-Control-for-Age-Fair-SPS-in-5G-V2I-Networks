import unittest

from _support import SRC_ROOT

from exp09.contracts.ids import ProgramId, RequestId
from exp09.contracts.supervisor import (
    PROGRAM_PROPOSAL_SCHEMA_VERSION,
    ProgramProposal,
    RationaleCode,
    TransitionId,
)
from exp09.contracts.time import SimTimeUs
from exp09.supervisor.programs import (
    RECOVERY_PROGRAM_SCHEMA_VERSION,
    RecoveryProgram,
    ProgramLibrary,
    ProgramState,
    ProgramProposalVerifier,
    ProgramOrchestrator,
    ProviderOutcome,
    eligible_proposals,
)
from exp09.supervisor.providers import (
    EVIDENCE_BUNDLE_SCHEMA_VERSION,
    PROVIDER_CACHE_SCHEMA_VERSION,
    PROVIDER_CONFIG_SCHEMA_VERSION,
    EvidenceBundle,
    OfflineLlmReplayAdapter,
    ProviderCache,
    ProviderConfig,
    ProviderKind,
    ProviderResponse,
    RuleProvider,
    TunedNonLLMProvider,
    canonical_provider_request,
    provider_response_hash,
)
from exp09.validation.import_boundaries import lint_import_boundaries


class C10C11SupervisorTests(unittest.TestCase):
    def _library(self) -> ProgramLibrary:
        return ProgramLibrary(
            schema_version="exp09-program-library-v1",
            library_id="library-1",
            programs=(
                RecoveryProgram(
                    schema_version=RECOVERY_PROGRAM_SCHEMA_VERSION,
                    program_id=ProgramId("balanced"),
                    priority=10,
                    ttl_us=10_000,
                    min_dwell_us=0,
                    budget_cost_units=1,
                ),
                RecoveryProgram(
                    schema_version=RECOVERY_PROGRAM_SCHEMA_VERSION,
                    program_id=ProgramId("protect"),
                    priority=1,
                    ttl_us=5_000,
                    min_dwell_us=1_000,
                    budget_cost_units=2,
                ),
            ),
        )

    def _state(self) -> ProgramState:
        return ProgramState.create(
            current_program_id=ProgramId("balanced"),
            current_started_us=SimTimeUs(0),
            last_transition_us=SimTimeUs(0),
            remaining_budget_units=3,
        )

    def _evidence(self, *, active: bool = True, risk: int = 800000) -> EvidenceBundle:
        return EvidenceBundle(
            schema_version=EVIDENCE_BUNDLE_SCHEMA_VERSION,
            evidence_id="evidence-1",
            causal_cutoff_us=SimTimeUs(2000),
            detector_active=active,
            risk_ppm=risk,
            memory_interval_low_ppm=100000,
            memory_interval_high_ppm=300000,
        )

    def test_c10_c11_package_boundaries_are_clean(self) -> None:
        self.assertEqual(lint_import_boundaries(SRC_ROOT), ())

    def test_program_eligibility_verifier_executor_and_fallback_are_atomic(self) -> None:
        library = self._library()
        state = self._state()
        eligible = eligible_proposals(
            library=library,
            state=state,
            now_us=SimTimeUs(2000),
            trigger_active=True,
        )
        proposal = ProgramProposal(
            schema_version=PROGRAM_PROPOSAL_SCHEMA_VERSION,
            transition_id=TransitionId.SWITCH,
            target_program_id=ProgramId("protect"),
            rationale_code=RationaleCode.EVIDENCE_SUPPORTED_TRANSITION,
        )
        ProgramProposalVerifier().verify(proposal=proposal, eligible=eligible)
        record = ProgramOrchestrator().apply_provider_proposal(
            library=library,
            state=state,
            proposal=proposal,
            now_us=SimTimeUs(2000),
            trigger_active=True,
        )
        self.assertEqual(record.provider_outcome, ProviderOutcome.ACCEPTED)
        self.assertFalse(record.fast_path_blocked)
        self.assertEqual(record.transition_record.next_state.current_program_id, "protect")
        self.assertEqual(record.transition_record.next_state.remaining_budget_units, 1)

        fallback = ProgramOrchestrator().apply_provider_proposal(
            library=library,
            state=state,
            proposal=None,
            now_us=SimTimeUs(2000),
            trigger_active=True,
        )
        self.assertEqual(fallback.provider_outcome, ProviderOutcome.FALLBACK)
        self.assertEqual(fallback.transition_record.next_state.current_program_id, "balanced")

        illegal = ProgramProposal(
            schema_version=PROGRAM_PROPOSAL_SCHEMA_VERSION,
            transition_id=TransitionId.SWITCH,
            target_program_id=ProgramId("missing"),
            rationale_code=RationaleCode.EVIDENCE_SUPPORTED_TRANSITION,
        )
        with self.assertRaisesRegex(ValueError, "eligible"):
            ProgramProposalVerifier().verify(proposal=illegal, eligible=eligible)

    def test_rule_tuned_and_offline_llm_replay_share_stack_and_cache_namespace(self) -> None:
        library = self._library()
        evidence = self._evidence(active=True, risk=800000)
        rule = RuleProvider().propose(library=library, evidence=evidence)
        tuned = TunedNonLLMProvider(risk_threshold_ppm=500000).propose(
            library=library,
            evidence=evidence,
        )
        self.assertEqual(rule.transition_id, tuned.transition_id)
        self.assertEqual(rule.target_program_id, tuned.target_program_id)

        config = ProviderConfig(
            schema_version=PROVIDER_CONFIG_SCHEMA_VERSION,
            provider_id="offline-llm",
            provider_kind=ProviderKind.OFFLINE_LLM_REPLAY,
            program_library_hash=library.library_hash,
            request_budget_units=1,
            retry_budget=0,
            prompt_schema_hash="a" * 64,
        )
        same_stack_rule = ProviderConfig(
            schema_version=PROVIDER_CONFIG_SCHEMA_VERSION,
            provider_id="rule",
            provider_kind=ProviderKind.RULE,
            program_library_hash=library.library_hash,
            request_budget_units=1,
            retry_budget=0,
            prompt_schema_hash="a" * 64,
        )
        self.assertEqual(config.stack_hash, same_stack_rule.stack_hash)

        request = canonical_provider_request(
            request_id=RequestId("request-1"),
            config=config,
            evidence=evidence,
            namespace="offline-llm",
            attempt_ordinal=0,
        )
        response = ProviderResponse(
            schema_version="exp09-provider-response-v1",
            request_hash=request.request_hash,
            proposal=rule,
            response_hash=provider_response_hash(request.request_hash, rule),
        )
        alternate = ProgramProposal(
            schema_version=PROGRAM_PROPOSAL_SCHEMA_VERSION,
            transition_id=TransitionId.HOLD,
            target_program_id=None,
            rationale_code=RationaleCode.HOLD_UNCERTAIN_EVIDENCE,
        )
        with self.assertRaisesRegex(ValueError, "response_hash does not bind"):
            ProviderResponse(
                schema_version="exp09-provider-response-v1",
                request_hash=request.request_hash,
                proposal=alternate,
                response_hash=response.response_hash,
            )
        with self.assertRaisesRegex(ValueError, "response_hash does not bind"):
            ProviderResponse(
                schema_version="exp09-provider-response-v1",
                request_hash=request.request_hash,
                proposal=rule,
                response_hash="f" * 64,
            )
        cache = ProviderCache(
            schema_version=PROVIDER_CACHE_SCHEMA_VERSION,
            namespace="offline-llm",
        )
        adapter = OfflineLlmReplayAdapter(cache=cache, scripted_responses=(response,))
        self.assertEqual(adapter.propose(request), response)
        self.assertEqual(adapter.propose(request), response)

        other_namespace_request = canonical_provider_request(
            request_id=RequestId("request-1"),
            config=config,
            evidence=evidence,
            namespace="other",
            attempt_ordinal=0,
        )
        with self.assertRaisesRegex(ValueError, "namespace"):
            adapter.propose(other_namespace_request)

        missing = canonical_provider_request(
            request_id=RequestId("request-2"),
            config=config,
            evidence=evidence,
            namespace="offline-llm",
            attempt_ordinal=0,
        )
        with self.assertRaisesRegex(ValueError, "network calls are forbidden"):
            adapter.propose(missing)

        with self.assertRaisesRegex(ValueError, "must not duplicate"):
            OfflineLlmReplayAdapter(
                cache=ProviderCache(
                    schema_version=PROVIDER_CACHE_SCHEMA_VERSION,
                    namespace="offline-llm",
                ),
                scripted_responses=(response, response),
            )


if __name__ == "__main__":
    unittest.main()
