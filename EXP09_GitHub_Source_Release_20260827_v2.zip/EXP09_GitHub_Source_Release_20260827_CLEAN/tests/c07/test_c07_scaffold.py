from copy import deepcopy
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from _support import PROJECT_ROOT, SRC_ROOT

from exp09.baselines.action_api import (
    BASELINE_ACTION_REQUEST_SCHEMA_VERSION,
    AoiAwareHeuristicActionPolicy,
    BaselineActionRequest,
    BaselineDecisionStatus,
    GreedyOneActionPolicy,
    KeepSanityActionPolicy,
    NominalMpcActionPolicy,
)
from exp09.baselines.registry import C07_METHOD_IDS, planned_c07_registry
from exp09.control.candidate_generator import ExpiryCandidateGenerator
from exp09.control.candidate_model_crn import build_candidate_model_crn_evidence
from exp09.contracts.actions import (
    OPPORTUNITY_SCHEMA_VERSION,
    ActionKind,
    ControlOpportunity,
    control_action_fingerprint,
)
from exp09.contracts.ids import ControlOpportunityId, VehicleId
from exp09.contracts.observable import (
    OBSERVABLE_COUNTER_SCHEMA_VERSION,
    OBSERVABLE_FRAME_SCHEMA_VERSION,
    OBSERVED_USER_AGE_SCHEMA_VERSION,
    OBSERVED_USER_STATE_SCHEMA_VERSION,
    IdentityState,
    ObservableCounter,
    ObservableCounterKind,
    ObservableFrame,
    ObservedUserAge,
    ObservedUserState,
)
from exp09.contracts.time import DurationUs, SimTimeUs
from exp09.model.approximate import ApproximateSPSModel, ApproximateSPSModelConfig
from exp09.model.interfaces import (
    MODEL_TRANSITION_BUDGET_SCHEMA_VERSION,
    PREDICTED_TRACE_STEP_SCHEMA_VERSION,
    ModelTransitionBudget,
    PredictedTraceStep,
    RolloutEvaluation,
    ScenarioMember,
)
from exp09.model.mismatch import (
    MISMATCH_LEVEL_SCHEMA_VERSION,
    MISMATCH_PROFILE_SCHEMA_VERSION,
    MismatchDirection,
    MismatchLevel,
    MismatchProfile,
)
from exp09.model.scenarios import ForecastBatchConfig, ForecastBatchFactory
from exp09.model.state_estimator import ControllerStateEstimator
from exp09.validation.c07 import (
    lint_c07_forbidden_legacy_logic,
    validate_c07_scaffold_bundle,
)
from exp09.validation.import_boundaries import lint_import_boundaries


class C07ImplementationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.model_config = ApproximateSPSModelConfig.create()
        self.model = ApproximateSPSModel(self.model_config)
        self.forecast_factory = ForecastBatchFactory(
            ForecastBatchConfig.create(model_config_hash=self.model_config.config_hash)
        )

    def _frame(
        self,
        digest: str = "b" * 64,
        *,
        controlled_age_us: int = 250_000,
        busy: int = 2,
        total: int = 10,
    ) -> ObservableFrame:
        users = (
            ObservedUserState(
                schema_version=OBSERVED_USER_STATE_SCHEMA_VERSION,
                vehicle_id=VehicleId("vehicle-0"),
                ledger_state=IdentityState.FRESH,
                identity_silence_us=0,
                age_us=controlled_age_us,
                age_missing_reason=None,
            ),
            ObservedUserState(
                schema_version=OBSERVED_USER_STATE_SCHEMA_VERSION,
                vehicle_id=VehicleId("vehicle-1"),
                ledger_state=IdentityState.FRESH,
                identity_silence_us=0,
                age_us=80_000,
                age_missing_reason=None,
            ),
        )
        return ObservableFrame(
            schema_version=OBSERVABLE_FRAME_SCHEMA_VERSION,
            source_sequence=1,
            causal_cutoff_us=SimTimeUs(1_000),
            summary_payload_hash=digest,
            counters=(
                self._counter(ObservableCounterKind.FRESH_OBSERVED, 2),
                self._counter(ObservableCounterKind.STALE_RETAINED, 0),
                self._counter(ObservableCounterKind.UNKNOWN_RETAINED, 0),
                self._counter(ObservableCounterKind.BUSY_SENSING_UNIT, busy),
                self._counter(ObservableCounterKind.TOTAL_SENSING_UNIT, total),
                self._counter(ObservableCounterKind.DECODED_SUCCESS, 8),
                self._counter(ObservableCounterKind.OBSERVABLE_DECODE_TRIAL, 10),
            ),
            missing_reasons=(),
            observed_user_ages=(
                ObservedUserAge(
                    schema_version=OBSERVED_USER_AGE_SCHEMA_VERSION,
                    vehicle_id=VehicleId("vehicle-0"),
                    age_us=controlled_age_us,
                ),
                ObservedUserAge(
                    schema_version=OBSERVED_USER_AGE_SCHEMA_VERSION,
                    vehicle_id=VehicleId("vehicle-1"),
                    age_us=80_000,
                ),
            ),
            observed_users=users,
            removals=(),
        )

    def _counter(self, kind: ObservableCounterKind, value: int) -> ObservableCounter:
        return ObservableCounter(
            schema_version=OBSERVABLE_COUNTER_SCHEMA_VERSION,
            kind=kind,
            value=value,
        )

    def _opportunity(self) -> ControlOpportunity:
        return ControlOpportunity(
            schema_version=OPPORTUNITY_SCHEMA_VERSION,
            opportunity_id=ControlOpportunityId("op-1"),
            vehicle_id=VehicleId("vehicle-0"),
            time_us=SimTimeUs(1_000),
            reservation_version=1,
            current_rri_us=DurationUs(100_000),
            legal_rri_us=tuple(
                DurationUs(value)
                for value in (20_000, 50_000, 100_000, 200_000, 300_000, 500_000, 1_000_000)
            ),
        )

    def _state_and_scenarios(self, frame=None):
        frame = frame or self._frame()
        state = ControllerStateEstimator().estimate(frame, self._opportunity())
        return frame, state, self.forecast_factory.build(state)

    def _budget(self, total: int = 100_000) -> ModelTransitionBudget:
        return ModelTransitionBudget(
            schema_version=MODEL_TRANSITION_BUDGET_SCHEMA_VERSION,
            budget_id="budget-1",
            total_transitions=total,
            consumed_transitions=0,
        )

    def _all_rollouts(self, frame, state, scenarios, horizon_us=100_000):
        candidate_set = ExpiryCandidateGenerator().generate(frame, self._opportunity())
        budget = self._budget()
        evaluations = []
        for action in candidate_set.actions:
            rollout_set = self.model.rollout(
                frame,
                state,
                action,
                scenarios,
                DurationUs(horizon_us),
                budget,
            )
            budget = rollout_set.budget_after
            evaluations.extend(rollout_set.evaluations)
        return candidate_set, tuple(evaluations), budget

    def test_c07_package_boundaries_are_clean(self) -> None:
        self.assertEqual(lint_import_boundaries(SRC_ROOT), ())

    def test_state_estimator_binds_public_causal_fields(self) -> None:
        frame = self._frame()
        state = ControllerStateEstimator().estimate(frame, self._opportunity())
        self.assertEqual(state.source_observation_hash, frame.summary_payload_hash)
        self.assertEqual(state.current_rri_us, DurationUs(100_000))
        self.assertEqual(state.busy_fraction_ppm, 200_000)
        self.assertEqual(state.decode_success_ppm, 800_000)
        self.assertEqual(tuple(item.vehicle_id for item in state.user_ages), ("vehicle-0", "vehicle-1"))

        with self.assertRaisesRegex(ValueError, "state_hash"):
            replace(state, state_hash="0" * 64)

    def test_state_estimator_rejects_future_observation(self) -> None:
        opportunity = replace(self._opportunity(), time_us=SimTimeUs(999))
        with self.assertRaisesRegex(ValueError, "cutoff"):
            ControllerStateEstimator().estimate(self._frame(), opportunity)

    def test_forecast_batch_is_deterministic_and_hash_bound(self) -> None:
        _, state, scenarios = self._state_and_scenarios()
        self.assertEqual(scenarios, self.forecast_factory.build(state))
        self.assertEqual(tuple(item.member_id for item in scenarios.members), (
            "forecast-0", "forecast-1", "forecast-2"
        ))
        with self.assertRaisesRegex(ValueError, "scenario_artifact_hash"):
            replace(scenarios.members[0], scenario_artifact_hash="0" * 64)

    def test_forecast_batch_rejects_semantic_resealing(self) -> None:
        frame, state, scenarios = self._state_and_scenarios()
        original = scenarios.members[0]
        resealed = ScenarioMember.create(
            member_id=original.member_id,
            mismatch_profile_hash=original.mismatch_profile_hash,
            load_scale_ppm=900_000,
            grant_phase_ppm=original.grant_phase_ppm,
            background_phase_ppm=original.background_phase_ppm,
            weight_numerator=original.weight_numerator,
            weight_denominator=original.weight_denominator,
        )
        tampered = replace(scenarios, members=(resealed, *scenarios.members[1:]))
        action = ExpiryCandidateGenerator().generate(frame, self._opportunity()).actions[0]
        with self.assertRaisesRegex(ValueError, "frozen forecast"):
            self.model.rollout(
                frame,
                state,
                action,
                tampered,
                DurationUs(100_000),
                self._budget(),
            )

    def test_frozen_load_scales_are_applied_multiplicatively(self) -> None:
        frame, state, scenarios = self._state_and_scenarios(self._frame(busy=0))
        action = ExpiryCandidateGenerator().generate(frame, self._opportunity()).actions[0]
        rollouts = self.model.rollout(
            frame,
            state,
            action,
            scenarios,
            DurationUs(100_000),
            self._budget(),
        )
        self.assertEqual(
            tuple(item.predicted_collision_risk_ppm for item in rollouts.evaluations),
            (90_000, 100_000, 110_000),
        )

    def test_all_legal_rri_values_change_numeric_trajectory_and_attempt_schedule(self) -> None:
        frame, state, scenarios = self._state_and_scenarios(self._frame(busy=0))
        candidates = ExpiryCandidateGenerator().generate(frame, self._opportunity()).actions[1:]
        schedules = []
        trajectories = []
        for action in candidates:
            evaluation = self.model.rollout(
                frame,
                state,
                action,
                scenarios,
                DurationUs(3_000_000),
                self._budget(total=9_000),
            ).evaluations[0]
            schedule = tuple(int(step.elapsed_us) for step in evaluation.trace if step.attempted)
            self.assertTrue(schedule)
            self.assertEqual(evaluation.selected_rri_us, action.target_rri_us)
            if len(schedule) > 1:
                self.assertEqual(
                    {later - earlier for earlier, later in zip(schedule, schedule[1:])},
                    {int(action.target_rri_us)},
                )
            schedules.append(schedule)
            trajectories.append(tuple(step.controlled_age_us for step in evaluation.trace))
        self.assertEqual(len(set(schedules)), len(candidates))
        self.assertEqual(len(set(trajectories)), len(candidates))

    def test_real_model_has_candidate_sensitivity_crn_and_budget_conservation(self) -> None:
        frame, state, scenarios = self._state_and_scenarios()
        candidate_set = ExpiryCandidateGenerator().generate(frame, self._opportunity())
        budget = self._budget(total=1_800)
        first = self.model.rollout(
            frame, state, candidate_set.actions[1], scenarios, DurationUs(300_000), budget
        )
        second = self.model.rollout(
            frame,
            state,
            candidate_set.actions[2],
            scenarios,
            DurationUs(300_000),
            first.budget_after,
        )
        self.assertEqual(first.budget_after.consumed_transitions, 900)
        self.assertEqual(second.budget_after.consumed_transitions, 1_800)
        self.assertEqual(
            tuple(item.scenario_member_id for item in first.evaluations),
            tuple(item.scenario_member_id for item in second.evaluations),
        )
        self.assertEqual({item.transition_count for item in first.evaluations}, {300})
        self.assertNotEqual(
            first.evaluations[0].predicted_metric_hash,
            second.evaluations[0].predicted_metric_hash,
        )
        self.assertNotEqual(
            first.evaluations[0].terminal_mean_age_us,
            second.evaluations[0].terminal_mean_age_us,
        )
        self.assertEqual(state.state_hash, first.evaluations[0].source_state_hash)

    def test_real_model_rejects_budget_exhaustion_and_misaligned_horizon(self) -> None:
        frame, state, scenarios = self._state_and_scenarios()
        action = ExpiryCandidateGenerator().generate(frame, self._opportunity()).actions[1]
        with self.assertRaisesRegex(ValueError, "budget"):
            self.model.rollout(
                frame, state, action, scenarios, DurationUs(100_000), self._budget(total=299)
            )
        with self.assertRaisesRegex(ValueError, "align"):
            self.model.rollout(
                frame, state, action, scenarios, DurationUs(100_001), self._budget()
            )

    def test_candidate_model_evidence_uses_three_second_physical_horizon(self) -> None:
        frame, state, scenarios = self._state_and_scenarios()
        candidate_set = ExpiryCandidateGenerator().generate(frame, self._opportunity())
        evidence = build_candidate_model_crn_evidence(
            evidence_id="evidence-1",
            frame=frame,
            state=state,
            candidate_set=candidate_set,
            scenarios=scenarios,
            horizon_us=DurationUs(3_000_000),
            budget=self._budget(total=72_000),
            model=self.model,
        )
        self.assertEqual(evidence.state_hash_before, evidence.state_hash_after)
        self.assertEqual({trace.transition_count_per_member for trace in evidence.traces}, {3_000})
        self.assertEqual(evidence.budget_after_consumed, 72_000)
        self.assertGreater(len({trace.numeric_rollout_hashes for trace in evidence.traces}), 1)

    def test_candidate_evidence_fails_closed_on_insufficient_budget(self) -> None:
        frame, state, scenarios = self._state_and_scenarios()
        with self.assertRaisesRegex(ValueError, "budget"):
            build_candidate_model_crn_evidence(
                evidence_id="evidence-1",
                frame=frame,
                state=state,
                candidate_set=ExpiryCandidateGenerator().generate(frame, self._opportunity()),
                scenarios=scenarios,
                horizon_us=DurationUs(3_000_000),
                budget=self._budget(total=71_999),
                model=self.model,
            )

    def test_keep_and_adapted_aoi_policies_use_public_evidence(self) -> None:
        frame = self._frame()
        candidate_set = ExpiryCandidateGenerator().generate(frame, self._opportunity())
        keep_request = BaselineActionRequest(
            schema_version=BASELINE_ACTION_REQUEST_SCHEMA_VERSION,
            method_id="KEEP_sanity",
            frame=frame,
            opportunity=self._opportunity(),
            candidate_set=candidate_set,
            rollouts=(),
        )
        keep = KeepSanityActionPolicy().select(keep_request)
        self.assertEqual(keep.action.kind, ActionKind.RETAIN_AT_EXPIRY)
        self.assertTrue(keep.evidence_hashes)
        self.assertEqual(
            keep.decision_status,
            BaselineDecisionStatus.IMPLEMENTED_C07_C12_QUALIFICATION_PENDING,
        )

        age_request = replace(keep_request, method_id="AoI_aware_heuristic")
        age_decision = AoiAwareHeuristicActionPolicy().select(age_request)
        self.assertEqual(age_decision.action.target_rri_us, DurationUs(20_000))

        busy_frame = self._frame(controlled_age_us=80_000, busy=8, total=10)
        busy_request = BaselineActionRequest(
            schema_version=BASELINE_ACTION_REQUEST_SCHEMA_VERSION,
            method_id="AoI_aware_heuristic",
            frame=busy_frame,
            opportunity=self._opportunity(),
            candidate_set=ExpiryCandidateGenerator().generate(busy_frame, self._opportunity()),
            rollouts=(),
        )
        busy_decision = AoiAwareHeuristicActionPolicy().select(busy_request)
        self.assertEqual(busy_decision.action.target_rri_us, DurationUs(1_000_000))

    def test_rollout_backed_request_requires_complete_crn_matrix(self) -> None:
        frame, state, scenarios = self._state_and_scenarios()
        candidate_set, rollouts, _ = self._all_rollouts(frame, state, scenarios)
        with self.assertRaisesRegex(ValueError, "complete ScenarioBatch"):
            BaselineActionRequest(
                schema_version=BASELINE_ACTION_REQUEST_SCHEMA_VERSION,
                method_id="Greedy_1",
                frame=frame,
                opportunity=self._opportunity(),
                candidate_set=candidate_set,
                rollouts=rollouts[:-1],
            )

    def test_greedy_and_nominal_use_different_declared_horizon_summaries(self) -> None:
        frame, state, _ = self._state_and_scenarios()
        candidate_set = ExpiryCandidateGenerator().generate(frame, self._opportunity())
        rollouts = tuple(
            self._scored_rollout(
                action,
                state.state_hash,
                first_worst=100 if index == 0 else 200,
                average_worst=900 if index == 0 else 100 + index,
            )
            for index, action in enumerate(candidate_set.actions)
        )
        greedy = GreedyOneActionPolicy().select(
            BaselineActionRequest(
                schema_version=BASELINE_ACTION_REQUEST_SCHEMA_VERSION,
                method_id="Greedy_1",
                frame=frame,
                opportunity=self._opportunity(),
                candidate_set=candidate_set,
                rollouts=rollouts,
            )
        )
        nominal = NominalMpcActionPolicy().select(
            BaselineActionRequest(
                schema_version=BASELINE_ACTION_REQUEST_SCHEMA_VERSION,
                method_id="Nominal_MPC",
                frame=frame,
                opportunity=self._opportunity(),
                candidate_set=candidate_set,
                rollouts=rollouts,
            )
        )
        self.assertEqual(greedy.action.kind, ActionKind.RETAIN_AT_EXPIRY)
        self.assertEqual(nominal.action.target_rri_us, DurationUs(20_000))

    def _scored_rollout(self, action, state_hash, *, first_worst, average_worst):
        step = PredictedTraceStep(
            schema_version=PREDICTED_TRACE_STEP_SCHEMA_VERSION,
            elapsed_us=DurationUs(1_000),
            controlled_age_us=50,
            mean_age_us=50,
            worst_age_us=50,
            collision_risk_ppm=10,
            attempted=True,
            expected_success_ppm=999_990,
        )
        selected_rri = action.target_rri_us or self._opportunity().current_rri_us
        return RolloutEvaluation.create(
            action_hash=control_action_fingerprint(action),
            scenario_member_id="forecast-0",
            scenario_artifact_hash="a" * 64,
            source_state_hash=state_hash,
            selected_rri_us=selected_rri,
            horizon_us=DurationUs(1_000),
            transition_count=1,
            time_average_mean_age_us=average_worst,
            time_average_worst_age_us=average_worst,
            terminal_mean_age_us=50,
            terminal_worst_age_us=50,
            first_attempt_mean_age_us=first_worst,
            first_attempt_worst_age_us=first_worst,
            predicted_collision_risk_ppm=10,
            expected_collision_events_ppm=10,
            trace=(step,),
        )

    def test_rollout_backed_policies_fail_without_rollouts(self) -> None:
        frame = self._frame()
        candidate_set = ExpiryCandidateGenerator().generate(frame, self._opportunity())
        for method_id in ("Greedy_1", "Nominal_MPC"):
            with self.assertRaisesRegex(ValueError, "rollout"):
                BaselineActionRequest(
                    schema_version=BASELINE_ACTION_REQUEST_SCHEMA_VERSION,
                    method_id=method_id,
                    frame=frame,
                    opportunity=self._opportunity(),
                    candidate_set=candidate_set,
                    rollouts=(),
                )

    def test_registry_contains_all_required_methods(self) -> None:
        registry = planned_c07_registry()
        self.assertEqual(tuple(item.method_id for item in registry.entries), C07_METHOD_IDS)

    def test_mismatch_profile_remains_model_only(self) -> None:
        level = MismatchLevel(
            schema_version=MISMATCH_LEVEL_SCHEMA_VERSION,
            axis_id="axis-1",
            level_id="level-1",
            parameterization_hash="1" * 64,
            direction=MismatchDirection.INCREASE,
            injection_point="ControllerModel_only",
        )
        profile = MismatchProfile(
            schema_version=MISMATCH_PROFILE_SCHEMA_VERSION,
            profile_id="profile-1",
            axis_level_grid_hash="2" * 64,
            method_blind_freeze_record_hash="3" * 64,
            levels=(level,),
            supporting_family_run_allowed=False,
        )
        self.assertEqual(profile.levels, (level,))
        with self.assertRaises(ValueError):
            replace(level, injection_point="GroundTruthPlant")

    def test_c07_legacy_lint_detects_forbidden_runtime_tokens(self) -> None:
        with TemporaryDirectory() as directory:
            root = Path(directory)
            module = root / "exp09" / "model" / "bad.py"
            module.parent.mkdir(parents=True)
            module.write_text("r_opt = 3\n", encoding="utf-8")
            violations = lint_c07_forbidden_legacy_logic(root)
        self.assertEqual(tuple(item.token for item in violations), ("r_opt",))

    def test_c07_bundle_is_hash_bound(self) -> None:
        report = validate_c07_scaffold_bundle(PROJECT_ROOT)
        self.assertTrue(report.passed, report.reasons)

    def test_c07_bundle_rejects_stale_manifest_hash(self) -> None:
        from exp09.validation import c07

        original = c07._load_json

        def load_with_stale_hash(path):
            record = original(path)
            if path.name == "scaffold_manifest.json":
                record = deepcopy(record)
                record["artifacts"][0]["sha256"] = "0" * 64
            return record

        with patch.object(c07, "_load_json", side_effect=load_with_stale_hash):
            report = validate_c07_scaffold_bundle(PROJECT_ROOT)
        self.assertFalse(report.passed)
        self.assertTrue(any("hash mismatch" in reason for reason in report.reasons))

    def test_c07_bundle_rejects_resealed_mismatch_semantics(self) -> None:
        from exp09.validation import c07

        original = c07._load_json

        def load_with_resealed_mismatch(path):
            record = original(path)
            if path.name == "mismatch_axis_level_freeze.json":
                record = deepcopy(record)
                level = record["axes"][0]["levels"][1]
                level["parameterization"]["load_scale_ppm"] = 850_000
                level["parameterization_hash"] = c07._canonical_json_sha256(
                    level["parameterization"]
                )
                record["axis_level_grid_hash"] = c07._canonical_json_sha256(record["axes"])
                without_self_hash = {
                    key: value
                    for key, value in record.items()
                    if key != "method_blind_freeze_record_hash"
                }
                record["method_blind_freeze_record_hash"] = c07._canonical_json_sha256(
                    without_self_hash
                )
            return record

        with patch.object(c07, "_load_json", side_effect=load_with_resealed_mismatch):
            report = validate_c07_scaffold_bundle(PROJECT_ROOT)
        self.assertFalse(report.passed)
        self.assertIn("C07 mismatch load-scale levels mismatch", report.reasons)

    def test_c07_bundle_cannot_enable_method_execution(self) -> None:
        from exp09.validation import c07

        original = c07._load_json

        def load_with_execution(path):
            record = original(path)
            if path.name == "g2a_preflight_review.json":
                record = deepcopy(record)
                record["method_execution_allowed"] = True
            return record

        with patch.object(c07, "_load_json", side_effect=load_with_execution):
            report = validate_c07_scaffold_bundle(PROJECT_ROOT)
        self.assertFalse(report.passed)
        self.assertIn("C07 G2-A preflight method_execution_allowed mismatch", report.reasons)


if __name__ == "__main__":
    unittest.main()
