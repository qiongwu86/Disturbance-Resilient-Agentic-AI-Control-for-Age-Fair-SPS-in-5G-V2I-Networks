"""C07 scaffold tests."""

