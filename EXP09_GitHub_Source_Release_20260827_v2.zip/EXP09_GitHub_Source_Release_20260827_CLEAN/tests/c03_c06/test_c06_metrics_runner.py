from dataclasses import replace
import unittest
from unittest.mock import patch

from _support import SRC_ROOT  # noqa: F401

from exp09.contracts.observable import MeasurementEventKind
from exp09.contracts.tape import TapeArm
from exp09.evaluation.disturbance_tape import build_primary_influx_tape
from exp09.evaluation.metrics_accumulator import compute_case_metrics
from exp09.evaluation.runner import (
    RECORDED_ACTION_REPLAY_SCHEMA_VERSION,
    RecordedActionReplay,
    _frame_hash,
    rebuild_metrics,
    replay_observable_frames,
    run_case,
    run_open_loop_case,
)
from exp09.contracts.actions import ACTION_SCHEMA_VERSION, ActionKind, ControlAction
from exp09.contracts.controller import (
    COMMITMENT_SCHEMA_VERSION,
    CommitmentRecord,
)
from exp09.plant.state import (
    PLANT_ADVANCE_RESULT_SCHEMA_VERSION,
    PLANT_SNAPSHOT_SCHEMA_VERSION,
    PLANT_TRACE_SCHEMA_VERSION,
    TX_ATTEMPT_RECORD_SCHEMA_VERSION,
    PlantAdvanceResult,
    PlantSnapshot,
    PlantTrace,
    TerminalOutcome,
    TxAttemptRecord,
)


def _trace(tx_attempts=(), truth_events=()):
    return PlantTrace(
        schema_version=PLANT_TRACE_SCHEMA_VERSION,
        tx_attempts=tx_attempts,
        truth_events=truth_events,
    )


class C06MetricsRunnerTests(unittest.TestCase):
    def test_exact_one_user_hand_fixture_and_half_open_end(self) -> None:
        tape = _one_user_tape(200_000)
        trace = _trace(
            (
                _attempt("inside", 100_000, 100_000, True),
                _attempt("end", 200_000, 200_000, True),
            ),
            (),
        )
        metrics = compute_case_metrics(tape, trace)
        self.assertEqual(metrics.mean_aoi_ms, "100.000000")
        self.assertEqual(metrics.event_paoi_ms, "200.000000")
        self.assertEqual(metrics.success_count, 1)

    def test_dynamic_arrival_changes_cross_sectional_integral(self) -> None:
        tape = build_primary_influx_tape("arrival-metric", TapeArm.EVENT)
        onset = min(int(item.simulation_time_us) for item in tape.arrivals)
        vehicles = tuple(
            replace(
                item,
                departure_simulation_time_us=min(
                    int(item.departure_simulation_time_us), onset + 100_000
                ),
                departure_analysis_tau_us=min(
                    int(item.departure_simulation_time_us), onset + 100_000
                )
                - int(tape.analysis_origin_simulation_time_us),
            )
            for item in tape.vehicles
        )
        tape = replace(
            tape,
            simulation_end_us=onset + 100_000,
            analysis_tau_end_us=(
                onset + 100_000 - int(tape.analysis_origin_simulation_time_us)
            ),
            vehicles=vehicles,
        )
        metrics = compute_case_metrics(tape, _trace())
        self.assertGreater(float(metrics.mean_aoi_ms), 0)
        self.assertEqual(metrics.zero_tx_indicator, 1)
        self.assertEqual(metrics.collision_event_rate, "MISSING_ZERO_TX")

    def test_user_balanced_paoi_differs_from_event_pooling(self) -> None:
        tape = build_primary_influx_tape("paoi-root", TapeArm.REFERENCE)
        vehicles = tuple(
            replace(
                item,
                arrival_analysis_tau_us=0,
                departure_simulation_time_us=400_000,
                departure_analysis_tau_us=400_000,
            )
            for item in tape.vehicles[:2]
        )
        tape = replace(
            tape,
            simulation_end_us=400_000,
            analysis_origin_simulation_time_us=0,
            analysis_tau_end_us=400_000,
            paired_anchor_simulation_time_us=200_000,
            paired_anchor_analysis_tau_us=200_000,
            vehicles=vehicles,
            arrivals=(),
            counters=tuple(
                item
                for item in tape.counters
                if item.vehicle_id in {vehicle.vehicle_id for vehicle in vehicles}
            ),
        )
        trace = _trace(
            (
                _attempt("a1", 100_000, 100_000, True, "vehicle_0"),
                _attempt("a2", 200_000, 200_000, True, "vehicle_0"),
                _attempt("a3", 300_000, 300_000, True, "vehicle_0"),
                _attempt("b1", 300_000, 300_000, True, "vehicle_1"),
            ),
            (),
        )
        metrics = compute_case_metrics(tape, trace)
        self.assertEqual(metrics.event_paoi_user_denominator, 2)
        self.assertEqual(metrics.event_paoi_event_count, 4)
        self.assertNotEqual(metrics.event_paoi_ms, "225.000000")

    def test_runner_raw_trace_is_reversible_and_deterministic(self) -> None:
        left = run_open_loop_case("runner-root", TapeArm.EVENT)
        right = run_open_loop_case("runner-root", TapeArm.EVENT)
        self.assertEqual(left.integrity_hash, right.integrity_hash)
        self.assertEqual(left.metrics, rebuild_metrics(left.raw_trace))
        self.assertEqual(left.metrics, right.metrics)
        self.assertEqual(left.observable_frame_count, 1000)
        replayed_frames = replay_observable_frames(left.raw_trace)
        self.assertEqual(
            replayed_frames,
            tuple(item.frame for item in left.raw_trace.summary_deliveries),
        )
        replay = RecordedActionReplay(
            schema_version=RECORDED_ACTION_REPLAY_SCHEMA_VERSION,
            actions=left.raw_trace.actions,
        )
        replayed = run_case(left.raw_trace.tape, action_replay=replay)
        self.assertEqual(left.raw_trace.plant_trace, replayed.raw_trace.plant_trace)
        self.assertEqual(left.raw_trace.actions, replayed.raw_trace.actions)
        self.assertEqual(
            left.raw_trace.measurement_deliveries,
            replayed.raw_trace.measurement_deliveries,
        )
        self.assertEqual(left.integrity_hash, replayed.integrity_hash)

    def test_runner_never_invokes_controller_during_burn_in(self) -> None:
        calls = []

        class SpyController:
            def reset(self, context):
                calls.append(("reset", context))

            def decide(self, frame, opportunity):
                calls.append(("decide", int(opportunity.time_us)))
                action = ControlAction(
                    schema_version=ACTION_SCHEMA_VERSION,
                    opportunity_id=opportunity.opportunity_id,
                    kind=ActionKind.RETAIN_AT_EXPIRY,
                    target_rri_us=None,
                )
                return CommitmentRecord(
                    schema_version=COMMITMENT_SCHEMA_VERSION,
                    observation_hash=_frame_hash(frame),
                    action=action,
                )

        result = run_open_loop_case(
            "controller-burn-in-boundary",
            TapeArm.REFERENCE,
            controller=SpyController(),
        )
        decision_times = tuple(value for kind, value in calls if kind == "decide")
        self.assertTrue(decision_times)
        self.assertGreaterEqual(min(decision_times), 10_000_000)
        self.assertEqual(sum(kind == "reset" for kind, _ in calls), 1)
        self.assertTrue(
            any(item.time_us < 10_000_000 for item in result.raw_trace.plant_trace.tx_attempts)
        )

    def test_runner_rejects_tape_content_with_stale_identity(self) -> None:
        tape = build_primary_influx_tape("runner-tape-tamper", TapeArm.REFERENCE)
        first_draw = tape.channel_draws[0]
        damaged = replace(
            tape,
            channel_draws=(
                replace(first_draw, uniform_u64=first_draw.uniform_u64 ^ 1),
                *tape.channel_draws[1:],
            ),
        )
        with self.assertRaisesRegex(ValueError, "channel draws|tape_id"):
            run_case(damaged)

    def test_metrics_accept_phase10_tx_at_same_time_as_phase20_departure(self) -> None:
        tape = build_primary_influx_tape("departure-metric-boundary", TapeArm.REFERENCE)
        vehicles = list(tape.vehicles)
        vehicles[1] = replace(
            vehicles[1],
            departure_simulation_time_us=10_100_000,
            departure_analysis_tau_us=100_000,
        )
        boundary_tape = replace(tape, vehicles=tuple(vehicles))
        trace = _trace(
            (
                _attempt(
                    "departure-boundary",
                    10_100_000,
                    10_100_000,
                    False,
                    "vehicle_1",
                ),
            )
        )
        metrics = compute_case_metrics(boundary_tape, trace)
        self.assertEqual(metrics.tx_attempts, 1)
        with self.assertRaisesRegex(ValueError, "outside physical eligibility"):
            compute_case_metrics(
                boundary_tape,
                _trace(
                    (
                        _attempt(
                            "after-departure",
                            10_100_001,
                            10_100_000,
                            False,
                            "vehicle_1",
                        ),
                    )
                ),
            )

    def test_raw_rebuild_rejects_delivery_snapshot_disagreement(self) -> None:
        result = run_open_loop_case("runner-mutation", TapeArm.EVENT)
        damaged = replace(
            result.raw_trace,
            measurement_deliveries=result.raw_trace.measurement_deliveries[:-1],
        )
        with self.assertRaisesRegex(ValueError, "must be one-to-one|do not reproduce"):
            rebuild_metrics(damaged)

    def test_runner_preserves_burn_in_raw_trace_before_analysis_origin(self) -> None:
        tape = _one_user_tape(400_000)
        vehicle = replace(
            tape.vehicles[0],
            arrival_simulation_time_us=0,
            arrival_analysis_tau_us=-100_000,
            departure_simulation_time_us=400_000,
            departure_analysis_tau_us=300_000,
            last_success_generation_us_at_entry=0,
        )
        tape = replace(
            tape,
            analysis_origin_simulation_time_us=100_000,
            analysis_tau_end_us=300_000,
            paired_anchor_simulation_time_us=200_000,
            paired_anchor_analysis_tau_us=100_000,
            vehicles=(vehicle,),
            counters=tuple(
                item for item in tape.counters if item.vehicle_id == vehicle.vehicle_id
            ),
        )
        with patch("exp09.evaluation.runner.validate_primary_tape"):
            result = run_case(tape)
        self.assertEqual(result.raw_trace.summaries[0].header.sequence, 0)
        self.assertEqual(result.raw_trace.summaries[0].header.causal_cutoff_us, 0)
        self.assertEqual(result.raw_trace.summaries[0].header.window_start_us, 0)
        self.assertEqual(result.raw_trace.summaries[0].eligible_sensing_slot_count, 0)
        self.assertEqual(result.metrics, rebuild_metrics(result.raw_trace))
        self.assertEqual(
            replay_observable_frames(result.raw_trace),
            tuple(item.frame for item in result.raw_trace.summary_deliveries),
        )

    def test_raw_rebuild_rejects_plant_attempt_tampering(self) -> None:
        result = run_open_loop_case("runner-attempt-tamper", TapeArm.REFERENCE)
        first = result.raw_trace.plant_trace.tx_attempts[0]
        damaged_trace = replace(
            result.raw_trace.plant_trace,
            tx_attempts=(replace(first, success=False), *result.raw_trace.plant_trace.tx_attempts[1:]),
        )
        with self.assertRaisesRegex(ValueError, "attempt delivery conflicts"):
            rebuild_metrics(replace(result.raw_trace, plant_trace=damaged_trace))

    def test_raw_rebuild_rejects_attempt_identity_or_channel_draw_tampering(self) -> None:
        result = run_open_loop_case("runner-attempt-identity", TapeArm.REFERENCE)
        attempt = result.raw_trace.plant_trace.tx_attempts[0]
        attempt_delivery = next(
            item
            for item in result.raw_trace.measurement_deliveries
            if item.attempt is not None
            and str(item.attempt.event_id) == attempt.attempt_id
        )
        assert attempt_delivery.attempt is not None
        with self.assertRaisesRegex(ValueError, "event ID does not match its payload"):
            replace(
                attempt_delivery,
                attempt=replace(
                    attempt_delivery.attempt,
                    event_id="tampered-attempt-id",
                ),
            )

        changed = replace(
            attempt,
            channel_uniform_u64=attempt.channel_uniform_u64 ^ 1,
        )
        damaged = replace(
            result.raw_trace,
            plant_trace=replace(
                result.raw_trace.plant_trace,
                tx_attempts=(
                    changed,
                    *result.raw_trace.plant_trace.tx_attempts[1:],
                ),
            ),
        )
        with self.assertRaisesRegex(ValueError, "channel"):
            rebuild_metrics(damaged)

    def test_raw_rebuild_rejects_packet_and_delivery_causal_id_tampering(self) -> None:
        result = run_open_loop_case("runner-packet-identity", TapeArm.REFERENCE)
        index = next(
            i
            for i, item in enumerate(result.raw_trace.measurement_deliveries)
            if item.packet is not None
        )
        original = result.raw_trace.measurement_deliveries[index]
        assert original.packet is not None
        for changes in (
            {"packet": replace(original.packet, event_id="tampered-packet-id")},
            {"event_id": "tampered-delivery-id"},
        ):
            with self.subTest(changes=changes):
                with self.assertRaisesRegex(
                    ValueError,
                    "event ID does not match its payload",
                ):
                    replace(original, **changes)

    def test_raw_rebuild_rejects_impossible_channel_or_collision_physics(self) -> None:
        result = run_open_loop_case("runner-physics-tamper", TapeArm.EVENT)
        attempts = result.raw_trace.plant_trace.tx_attempts
        single = next(
            item
            for item in attempts
            if sum(other.time_us == item.time_us for other in attempts) == 1
        )
        damaged_attempts = tuple(
            replace(
                item,
                logical_subchannel_id=1 - item.logical_subchannel_id,
            )
            if item.attempt_id == single.attempt_id
            else item
            for item in attempts
        )
        with self.assertRaisesRegex(ValueError, "packet deliveries|physical plant replay"):
            rebuild_metrics(
                replace(
                    result.raw_trace,
                    plant_trace=replace(
                        result.raw_trace.plant_trace,
                        tx_attempts=damaged_attempts,
                    ),
                )
            )

        collision = next(item for item in attempts if item.collided)
        damaged_attempts = tuple(
            replace(
                item,
                outcome=TerminalOutcome.RX_SUCCESS,
                collided=False,
            )
            if item.attempt_id == collision.attempt_id
            else item
            for item in attempts
        )
        with self.assertRaisesRegex(ValueError, "collision physics"):
            rebuild_metrics(
                replace(
                    result.raw_trace,
                    plant_trace=replace(
                        result.raw_trace.plant_trace,
                        tx_attempts=damaged_attempts,
                    ),
                )
            )

    def test_raw_rebuild_rejects_missing_attempt_or_packet_delivery(self) -> None:
        result = run_open_loop_case("runner-stream-tamper", TapeArm.REFERENCE)
        for kind, expected in (
            (MeasurementEventKind.ATTEMPT, "attempt deliveries must be one-to-one"),
            (MeasurementEventKind.PACKET, "packet deliveries must be one-to-one"),
        ):
            index = next(
                i
                for i, item in enumerate(result.raw_trace.measurement_deliveries)
                if item.kind is kind
            )
            deliveries = (
                *result.raw_trace.measurement_deliveries[:index],
                *result.raw_trace.measurement_deliveries[index + 1 :],
            )
            with self.subTest(kind=kind):
                with self.assertRaisesRegex(ValueError, expected):
                    rebuild_metrics(
                        replace(result.raw_trace, measurement_deliveries=deliveries)
                    )

    def test_raw_replay_rejects_summary_delivery_metadata_mutation(self) -> None:
        result = run_open_loop_case("runner-summary-mutation", TapeArm.EVENT)
        first = result.raw_trace.summary_deliveries[0]
        damaged = replace(
            result.raw_trace,
            summary_deliveries=(
                replace(first, received_at_us=first.received_at_us + 1),
                *result.raw_trace.summary_deliveries[1:],
            ),
        )
        with self.assertRaisesRegex(ValueError, "metadata is inconsistent"):
            replay_observable_frames(damaged)

    def test_raw_rebuild_rejects_summary_payload_tampering(self) -> None:
        result = run_open_loop_case("runner-summary-payload", TapeArm.REFERENCE)
        summary = result.raw_trace.summaries[0]
        damaged = replace(
            result.raw_trace,
            summaries=(
                replace(summary, decode_trial_count=summary.decode_trial_count + 1),
                *result.raw_trace.summaries[1:],
            ),
        )
        with self.assertRaisesRegex(ValueError, "recorded summary"):
            rebuild_metrics(damaged)

    def test_raw_replay_rejects_duplicate_action_opportunity(self) -> None:
        result = run_open_loop_case("runner-action-mutation", TapeArm.REFERENCE)
        self.assertTrue(result.raw_trace.actions)
        damaged = replace(
            result.raw_trace,
            actions=(result.raw_trace.actions[0], *result.raw_trace.actions),
        )
        with self.assertRaisesRegex(ValueError, "opportunity IDs must be unique"):
            replay_observable_frames(damaged)

    def test_completed_raw_rejects_truncated_summary_or_action_history(self) -> None:
        result = run_open_loop_case("runner-truncated-history", TapeArm.REFERENCE)
        cases = (
            replace(
                result.raw_trace,
                summaries=result.raw_trace.summaries[:-1],
                summary_deliveries=result.raw_trace.summary_deliveries[:-1],
            ),
            replace(result.raw_trace, actions=result.raw_trace.actions[:-1]),
        )
        for damaged in cases:
            with self.subTest(
                summaries=len(damaged.summaries), actions=len(damaged.actions)
            ):
                with self.assertRaisesRegex(ValueError, "complete|history"):
                    replay_observable_frames(damaged)

    def test_runner_fails_closed_when_plant_does_not_advance(self) -> None:
        tape = _one_user_tape(200_000)

        class StalledPlant:
            def reset(self, source_tape):
                self._snapshot = PlantSnapshot(
                    schema_version=PLANT_SNAPSHOT_SCHEMA_VERSION,
                    time_us=int(source_tape.simulation_start_us),
                    tape=source_tape,
                    vehicles=(),
                    event_queue=(),
                    pending_opportunity=None,
                    trace=_trace(),
                    observations=(),
                    measurement_delivery_queue=(),
                    measurement_deliveries=(),
                    queue_processed_time_us=None,
                    queue_processed_priority=None,
                    queue_consumed_event_ids=(),
                )
                return self._snapshot

            def snapshot(self):
                return self._snapshot

            def advance_until(self, _time_us):
                return PlantAdvanceResult(
                    schema_version=PLANT_ADVANCE_RESULT_SCHEMA_VERSION,
                    snapshot=self._snapshot,
                    opportunities=(),
                    trace_delta=_trace(),
                    measurement_delivery_delta=(),
                )

        with patch(
            "exp09.evaluation.runner.DiscreteEventSPSPlant",
            return_value=StalledPlant(),
        ), patch("exp09.evaluation.runner.validate_primary_tape"):
            with self.assertRaisesRegex(RuntimeError, "no forward progress"):
                run_case(tape)


def _one_user_tape(end_us):
    tape = build_primary_influx_tape("metric-root", TapeArm.REFERENCE)
    vehicle = replace(
        tape.vehicles[0],
        arrival_simulation_time_us=0,
        arrival_analysis_tau_us=0,
        departure_simulation_time_us=end_us,
        departure_analysis_tau_us=end_us,
        last_success_generation_us_at_entry=-100_000,
    )
    return replace(
        tape,
        simulation_end_us=end_us,
        analysis_origin_simulation_time_us=0,
        analysis_tau_end_us=end_us,
        paired_anchor_simulation_time_us=end_us // 2,
        paired_anchor_analysis_tau_us=end_us // 2,
        vehicles=(vehicle,),
        arrivals=(),
        controlled_vehicle_id=vehicle.vehicle_id,
        background_reselections=(),
        channel_draws=tuple(item for item in tape.channel_draws if item.vehicle_id == vehicle.vehicle_id),
        counters=tuple(item for item in tape.counters if item.vehicle_id == vehicle.vehicle_id),
    )


def _attempt(attempt_id, time_us, generation_us, success, vehicle_id="vehicle_0"):
    return TxAttemptRecord(
        schema_version=TX_ATTEMPT_RECORD_SCHEMA_VERSION,
        attempt_id=attempt_id,
        time_us=time_us,
        vehicle_id=vehicle_id,
        packet_generation_us=generation_us,
        logical_subchannel_id=0,
        channel_uniform_u64=0,
        outcome=TerminalOutcome.RX_SUCCESS if success else TerminalOutcome.COLLISION,
        collided=not success,
        success=success,
    )


if __name__ == "__main__":
    unittest.main()
