from dataclasses import replace
import json
from pathlib import Path
import tempfile
import unittest

from _support import SRC_ROOT  # noqa: F401

from exp09.contracts.tape import TapeArm
from exp09.evaluation.raw_writer import (
    _canonical_mapping_bytes,
    _load_raw_run_trace,
    _sha256_bytes,
    verify_completed_run,
    write_completed_run,
)
from exp09.evaluation.runner import run_open_loop_case


class C06RawWriterTests(unittest.TestCase):
    def test_raw_loader_rejects_retired_top_level_schema_before_nested_decode(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "raw_run.json"
            path.write_bytes(
                _json_bytes(
                    {
                        "schema_version": "exp09-raw-run-trace-v2",
                        "tape": {},
                    }
                )
            )
            with self.assertRaisesRegex(
                ValueError,
                "raw artifact has an unsupported schema",
            ):
                _load_raw_run_trace(path)

    def test_atomic_writer_publishes_complete_verified_case(self) -> None:
        result = run_open_loop_case("writer-root", TapeArm.REFERENCE)
        with tempfile.TemporaryDirectory() as directory:
            artifact = write_completed_run(result, Path(directory))
            self.assertTrue((artifact.path / "COMPLETE").is_file())
            self.assertEqual(artifact.integrity_hash, result.integrity_hash)
            self.assertEqual(verify_completed_run(artifact.path), artifact)
            integrity = json.loads(
                (artifact.path / "integrity.json").read_text(encoding="utf-8")
            )
            self.assertEqual(
                integrity["protocol_generation"], result.raw_trace.tape.protocol_generation
            )
            self.assertEqual(integrity["tape_id"], str(result.raw_trace.tape.tape_id))
            self.assertEqual(integrity["config_hash"], result.raw_trace.tape.config_hash)
            self.assertTrue(integrity["tape_canonical_sha256"])
            self.assertFalse(
                any(item.name.startswith(".") for item in Path(directory).iterdir())
            )

    def test_writer_refuses_to_overwrite_completed_case(self) -> None:
        result = run_open_loop_case("writer-no-overwrite", TapeArm.REFERENCE)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            write_completed_run(result, root)
            with self.assertRaises(FileExistsError):
                write_completed_run(result, root)

    def test_verifier_rejects_missing_marker_and_tampered_raw(self) -> None:
        result = run_open_loop_case("writer-tamper", TapeArm.REFERENCE)
        with tempfile.TemporaryDirectory() as directory:
            artifact = write_completed_run(result, Path(directory))
            marker = artifact.path / "COMPLETE"
            marker_bytes = marker.read_bytes()
            marker.unlink()
            with self.assertRaisesRegex(ValueError, "incomplete"):
                verify_completed_run(artifact.path)
            marker.write_bytes(marker_bytes)
            raw_path = artifact.path / "raw_run.json"
            raw = json.loads(raw_path.read_text(encoding="utf-8"))
            raw["actions"] = []
            raw_path.write_text(json.dumps(raw), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "integrity mismatch"):
                verify_completed_run(artifact.path)

    def test_writer_rejects_result_or_metrics_that_disagree_with_raw(self) -> None:
        result = run_open_loop_case("writer-cross-artifact", TapeArm.REFERENCE)
        inconsistent_results = (
            replace(result, tx_attempts=result.tx_attempts + 1),
            replace(
                result,
                metrics=replace(result.metrics, tx_attempts=result.metrics.tx_attempts + 1),
            ),
        )
        for inconsistent in inconsistent_results:
            with tempfile.TemporaryDirectory() as directory:
                with self.subTest(tx_attempts=inconsistent.tx_attempts):
                    with self.assertRaisesRegex(ValueError, "raw|metrics|result"):
                        write_completed_run(inconsistent, Path(directory))

    def test_verifier_rejects_semantic_tampering_after_all_hashes_are_resealed(
        self,
    ) -> None:
        result = run_open_loop_case("writer-resealed-attack", TapeArm.REFERENCE)
        mutations = (
            ("raw_run.json", _drop_first_action),
            ("metrics_case.json", _increment_metric_attempts),
        )
        for artifact_name, mutate in mutations:
            with self.subTest(artifact=artifact_name):
                with tempfile.TemporaryDirectory() as directory:
                    artifact = write_completed_run(result, Path(directory))
                    _mutate_and_reseal(artifact.path, artifact_name, mutate)
                    with self.assertRaisesRegex(
                        ValueError,
                        "raw|metrics|canonical|integrity|reproduce|agree",
                    ):
                        verify_completed_run(artifact.path)

    def test_verifier_rejects_identity_name_and_exact_file_set_mismatches(self) -> None:
        result = run_open_loop_case("writer-identity-attack", TapeArm.REFERENCE)
        with tempfile.TemporaryDirectory() as directory:
            artifact = write_completed_run(result, Path(directory))
            (artifact.path / "unexpected.txt").write_text("unexpected", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "unexpected file set"):
                verify_completed_run(artifact.path)

        with tempfile.TemporaryDirectory() as directory:
            artifact = write_completed_run(result, Path(directory))
            renamed = artifact.path.with_name("run-000000000000000000000000")
            artifact.path.rename(renamed)
            with self.assertRaisesRegex(ValueError, "directory name"):
                verify_completed_run(renamed)

    def test_verifier_rejects_closed_schema_field_injection_after_reseal(self) -> None:
        result = run_open_loop_case("writer-field-injection", TapeArm.REFERENCE)
        with tempfile.TemporaryDirectory() as directory:
            artifact = write_completed_run(result, Path(directory))

            def inject_unknown(raw):
                raw["unknown_truth_side_channel"] = 1

            _mutate_and_reseal(artifact.path, "raw_run.json", inject_unknown)
            with self.assertRaisesRegex(ValueError, "unexpected field set"):
                verify_completed_run(artifact.path)

    def test_verifier_rejects_resealed_tape_identity_tampering(self) -> None:
        result = run_open_loop_case("writer-tape-identity", TapeArm.REFERENCE)
        with tempfile.TemporaryDirectory() as directory:
            artifact = write_completed_run(result, Path(directory))

            def tamper_tape_identity(raw):
                raw["tape"]["tape_id"] = "A" * 64

            _mutate_and_reseal(artifact.path, "raw_run.json", tamper_tape_identity)
            with self.assertRaisesRegex(ValueError, "tape_id|config_hash"):
                verify_completed_run(artifact.path)


def _drop_first_action(raw):
    raw["actions"] = raw["actions"][1:]


def _increment_metric_attempts(metrics):
    metrics["tx_attempts"] += 1


def _mutate_and_reseal(path: Path, artifact_name: str, mutate) -> None:
    artifact_path = path / artifact_name
    value = json.loads(artifact_path.read_text(encoding="utf-8"))
    mutate(value)
    artifact_bytes = _json_bytes(value)
    artifact_path.write_bytes(artifact_bytes)

    integrity_path = path / "integrity.json"
    integrity = json.loads(integrity_path.read_text(encoding="utf-8"))
    integrity["files"][artifact_name] = {
        "sha256": _sha256_bytes(artifact_bytes),
        "size_bytes": len(artifact_bytes),
    }
    if artifact_name == "raw_run.json":
        integrity["result_integrity_hash"] = _sha256_bytes(artifact_bytes)
    integrity_bytes = _canonical_mapping_bytes(integrity)
    integrity_path.write_bytes(integrity_bytes)

    complete_path = path / "COMPLETE"
    complete = json.loads(complete_path.read_text(encoding="utf-8"))
    complete["integrity_sha256"] = _sha256_bytes(integrity_bytes)
    complete["result_integrity_hash"] = integrity["result_integrity_hash"]
    complete_path.write_bytes(_canonical_mapping_bytes(complete))


def _json_bytes(value) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


if __name__ == "__main__":
    unittest.main()
