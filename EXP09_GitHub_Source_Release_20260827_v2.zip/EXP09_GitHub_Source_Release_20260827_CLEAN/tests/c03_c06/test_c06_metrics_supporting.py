from dataclasses import replace
import unittest

from _support import SRC_ROOT  # noqa: F401

from exp09.contracts.ids import EventId, VehicleId
from exp09.contracts.observable import (
    RECEIVER_IDENTITY_EVENT_SCHEMA_VERSION,
    ReceiverIdentityEvent,
    ReceiverObservableKind,
)
from exp09.contracts.tape import TapeArm
from exp09.contracts.time import SimTimeUs
from exp09.evaluation.disturbance_tape import build_primary_influx_tape
from exp09.evaluation.metrics_accumulator import (
    _pooled_occupation_quantile,
    compute_case_metrics,
)
from exp09.plant.state import (
    PLANT_TRACE_SCHEMA_VERSION,
    TRUTH_EVENT_RECORD_SCHEMA_VERSION,
    TX_ATTEMPT_RECORD_SCHEMA_VERSION,
    PlantTrace,
    TerminalOutcome,
    TruthEventKind,
    TruthEventRecord,
    TxAttemptRecord,
)


def _trace(tx_attempts=(), truth_events=()):
    return PlantTrace(
        schema_version=PLANT_TRACE_SCHEMA_VERSION,
        tx_attempts=tx_attempts,
        truth_events=truth_events,
    )


class C06SupportingMetricTests(unittest.TestCase):
    def test_case_metrics_rejects_retired_v3_schema(self) -> None:
        metrics = compute_case_metrics(_two_user_tape(200_000), _trace())
        with self.assertRaisesRegex(ValueError, "unsupported case-metrics schema"):
            replace(metrics, schema_version="exp09-case-metrics-v3")

    def test_never_observed_uses_receiver_identity_history_not_success(self) -> None:
        tape = _two_user_tape(200_000)
        history = (
            ReceiverIdentityEvent(
                schema_version=RECEIVER_IDENTITY_EVENT_SCHEMA_VERSION,
                event_id=EventId("handover-1"),
                vehicle_id=VehicleId("vehicle_1"),
                observed_at_us=SimTimeUs(0),
                kind=ReceiverObservableKind.AUTHENTICATED_HANDOVER,
                last_success_generation_us=None,
                removal_reason=None,
            ),
        )
        metrics = compute_case_metrics(
            tape,
            _trace((_attempt("success-0", 100_000, 100_000, True),)),
            observable_history=history,
        )
        self.assertEqual(metrics.zero_success_fraction, "0.500000")
        self.assertEqual(metrics.never_observed_fraction, "0.500000")
        observed = {item.vehicle_id: item.observed_ever for item in metrics.per_user}
        self.assertEqual(observed, {"vehicle_0": False, "vehicle_1": True})

    def test_access_survival_and_kaplan_meier_rmst_are_exact(self) -> None:
        tape = _two_user_tape(200_000)
        trace = _trace((_attempt("success-0", 100_000, 100_000, True),))
        metrics = compute_case_metrics(tape, trace)
        self.assertEqual(metrics.access_event_count, 1)
        self.assertEqual(metrics.access_risk_set_count, 2)
        self.assertEqual(metrics.access_rmst_ms, "150.000000")
        self.assertEqual(
            [
                (
                    point.duration_us,
                    point.at_risk,
                    point.event_count,
                    point.censor_count,
                    point.survival_numerator,
                    point.survival_denominator,
                )
                for point in metrics.access_survival
            ],
            [(100_000, 2, 1, 0, 1, 2), (200_000, 1, 0, 1, 1, 2)],
        )

    def test_supporting_reliability_tail_fairness_and_switch_cost(self) -> None:
        tape = _two_user_tape(200_000)
        trace = _trace(
            (
                _attempt("success-0", 100_000, 100_000, True),
                _attempt("collision-1", 100_000, 0, False, "vehicle_1"),
            ),
            (
                TruthEventRecord(
                    schema_version=TRUTH_EVENT_RECORD_SCHEMA_VERSION,
                    event_id="controlled-reselect",
                    time_us=50_000,
                    kind=TruthEventKind.RESERVATION_RESELECT,
                    vehicle_id="vehicle_0",
                    reservation_version=2,
                ),
                TruthEventRecord(
                    schema_version=TRUTH_EVENT_RECORD_SCHEMA_VERSION,
                    event_id="background-reselect",
                    time_us=50_000,
                    kind=TruthEventKind.RESERVATION_RESELECT,
                    vehicle_id="vehicle_1",
                    reservation_version=2,
                ),
            ),
        )
        metrics = compute_case_metrics(tape, trace)
        self.assertEqual(metrics.decode_failure_rate, "0.500000")
        self.assertEqual(metrics.collision_event_rate, "0.500000")
        self.assertEqual(metrics.reselection_count, 1)
        # Only controlled-vehicle reselections count toward controller cost:
        # one event / 0.2 vehicle-seconds = 5 events per vehicle-second.
        self.assertEqual(metrics.reselection_rate_per_vehicle_second, "5.000000")
        self.assertNotEqual(metrics.pooled_occupation_q95_ms, metrics.q95_aoi_ms)
        self.assertGreater(float(metrics.age_cv), 0)
        self.assertGreater(float(metrics.age_max_min_gap_ms), 0)

    def test_primary_influx_reports_containment_and_entrant_adaptation(self) -> None:
        tape = build_primary_influx_tape("containment-root", TapeArm.EVENT)
        onset = min(int(item.simulation_time_us) for item in tape.arrivals)
        end = onset + 200_000
        vehicles = tuple(
            replace(
                item,
                departure_simulation_time_us=min(
                    int(item.departure_simulation_time_us), end
                ),
                departure_analysis_tau_us=min(
                    int(item.departure_simulation_time_us), end
                )
                - int(tape.analysis_origin_simulation_time_us),
            )
            for item in tape.vehicles
        )
        tape = replace(
            tape,
            simulation_end_us=end,
            analysis_tau_end_us=end - int(tape.analysis_origin_simulation_time_us),
            vehicles=vehicles,
        )
        entrant = str(tape.arrivals[0].vehicle_id)
        metrics = compute_case_metrics(
            tape,
            _trace(
                (_attempt("entrant-success", onset + 100_000, onset, True, entrant),),
                (),
            ),
        )
        self.assertEqual(
            metrics.containment_onset_analysis_tau_us,
            int(tape.paired_anchor_analysis_tau_us),
        )
        self.assertNotIn("NOT_APPLICABLE", metrics.containment_mean_aoi_ms)
        self.assertEqual(metrics.adaptation_entrant_access_event_fraction, "0.333333")
        self.assertEqual(metrics.adaptation_entrant_access_rmst_ms, "166.666667")

    def test_containment_excludes_same_time_pre_arrival_attempt(self) -> None:
        tape = build_primary_influx_tape("containment-boundary-root", TapeArm.EVENT)
        onset = min(int(item.simulation_time_us) for item in tape.arrivals)
        trace = _trace(
            (
                _attempt("at-onset", onset, onset - 1, False),
                _attempt(
                    "after-onset",
                    onset + int(tape.slot_duration_us),
                    onset,
                    True,
                ),
            ),
            (),
        )
        metrics = compute_case_metrics(tape, trace)
        self.assertEqual(metrics.collision_event_rate, "0.500000")
        self.assertEqual(metrics.containment_collision_event_rate, "0.000000")

    def test_reference_uses_the_same_hidden_containment_anchor(self) -> None:
        reference = build_primary_influx_tape("paired-containment", TapeArm.REFERENCE)
        event = build_primary_influx_tape("paired-containment", TapeArm.EVENT)
        self.assertEqual(
            reference.paired_anchor_simulation_time_us,
            event.paired_anchor_simulation_time_us,
        )
        self.assertEqual(
            reference.paired_anchor_analysis_tau_us,
            event.paired_anchor_analysis_tau_us,
        )
        reference_metrics = compute_case_metrics(reference, _trace())
        event_metrics = compute_case_metrics(event, _trace())
        self.assertEqual(
            reference_metrics.containment_onset_analysis_tau_us,
            event_metrics.containment_onset_analysis_tau_us,
        )
        self.assertNotIn("NOT_APPLICABLE", reference_metrics.containment_mean_aoi_ms)
        self.assertEqual(
            reference_metrics.adaptation_entrant_access_event_fraction,
            "NOT_APPLICABLE_NO_ENTRANTS",
        )

    def test_truth_trace_accepts_arrival_and_departure_boundaries(self) -> None:
        tape = _two_user_tape(200_000)
        trace = _trace(
            (),
            (
                _truth("arrival", 0, TruthEventKind.VEHICLE_ARRIVAL, version=0),
                _truth("at-arrival", 0, TruthEventKind.RESERVATION_RESELECT, version=1),
                _truth(
                    "departure",
                    200_000,
                    TruthEventKind.VEHICLE_DEPARTURE,
                    version=1,
                ),
            ),
        )
        metrics = compute_case_metrics(tape, trace)
        self.assertEqual(metrics.reselection_count, 1)

    def test_truth_trace_rejects_invalid_identity_time_or_version(self) -> None:
        tape = _two_user_tape(200_000)
        cases = {
            "duplicate truth event": (
                _truth("duplicate", 0, TruthEventKind.VEHICLE_ARRIVAL),
                _truth("duplicate", 1, TruthEventKind.RESERVATION_RESELECT),
            ),
            "unknown vehicle": (
                _truth(
                    "unknown",
                    0,
                    TruthEventKind.RESERVATION_RESELECT,
                    vehicle_id="missing-vehicle",
                ),
            ),
            "physical arrival": (
                _truth("wrong-arrival", 1, TruthEventKind.VEHICLE_ARRIVAL),
            ),
            "physical departure": (
                _truth(
                    "wrong-departure",
                    199_999,
                    TruthEventKind.VEHICLE_DEPARTURE,
                ),
            ),
            "outside physical presence": (
                _truth(
                    "at-departure",
                    200_000,
                    TruthEventKind.CONTROL_OPPORTUNITY,
                ),
            ),
            "non-negative integer": (
                _truth(
                    "negative-version",
                    0,
                    TruthEventKind.RESERVATION_RESELECT,
                    version=-1,
                ),
            ),
            "regressed": (
                _truth("version-2", 0, TruthEventKind.RESERVATION_RESELECT, version=2),
                _truth("version-1", 1, TruthEventKind.RESERVATION_RESELECT, version=1),
            ),
        }
        for expected_error, truth_events in cases.items():
            with self.subTest(expected_error=expected_error):
                with self.assertRaisesRegex(ValueError, expected_error):
                    compute_case_metrics(tape, _trace(truth_events=truth_events))

    def test_access_risk_begins_at_nonzero_analysis_start(self) -> None:
        tape = _two_user_tape(300_000)
        vehicles = tuple(
            replace(
                item,
                arrival_analysis_tau_us=-100_000,
                departure_analysis_tau_us=200_000,
            )
            for item in tape.vehicles
        )
        tape = replace(
            tape,
            analysis_origin_simulation_time_us=100_000,
            analysis_tau_end_us=200_000,
            paired_anchor_simulation_time_us=150_000,
            paired_anchor_analysis_tau_us=50_000,
            vehicles=vehicles,
        )
        metrics = compute_case_metrics(
            tape,
            _trace((_attempt("success-0", 150_000, 150_000, True),)),
        )
        records = {item.vehicle_id: item for item in metrics.access_delay}
        self.assertEqual(records["vehicle_0"].duration_us, 50_000)
        self.assertEqual(records["vehicle_1"].duration_us, 200_000)
        self.assertEqual(metrics.access_rmst_ms, "125.000000")

    def test_controlled_vehicle_denominator_fails_closed_when_missing(self) -> None:
        tape = _two_user_tape(200_000)
        with self.assertRaisesRegex(ValueError, "controlled vehicle"):
            compute_case_metrics(
                replace(tape, controlled_vehicle_id="missing-controlled"),
                _trace(),
            )

    def test_controlled_vehicle_denominator_fails_closed_when_zero(self) -> None:
        tape = _two_user_tape(200_000)
        controlled = replace(
            tape.vehicles[0],
            arrival_analysis_tau_us=-100_000,
            departure_simulation_time_us=100_000,
            departure_analysis_tau_us=0,
        )
        other = replace(
            tape.vehicles[1],
            arrival_analysis_tau_us=-100_000,
            departure_analysis_tau_us=100_000,
        )
        with self.assertRaisesRegex(ValueError, "controlled vehicle"):
            compute_case_metrics(
                replace(
                    tape,
                    analysis_origin_simulation_time_us=100_000,
                    analysis_tau_end_us=100_000,
                    paired_anchor_simulation_time_us=150_000,
                    paired_anchor_analysis_tau_us=50_000,
                    vehicles=(controlled, other),
                    controlled_vehicle_id=controlled.vehicle_id,
                ),
                _trace(),
            )

    def test_pooled_occupation_endpoint_sweep_is_exact(self) -> None:
        self.assertEqual(
            _pooled_occupation_quantile([(0, 10), (5, 10)], 1, 2),
            15 / 2,
        )
        self.assertEqual(
            _pooled_occupation_quantile([(0, 3), (10, 1)], 3, 4),
            3,
        )

    def test_pooled_occupation_endpoint_sweep_handles_large_overlap(self) -> None:
        segments = [(index % 101, 10_000 + index % 17) for index in range(20_000)]
        value = _pooled_occupation_quantile(segments, 95, 100)
        self.assertGreaterEqual(value, 0)
        self.assertLessEqual(value, max(age + duration for age, duration in segments))

    def test_pooled_occupation_rejects_invalid_segments(self) -> None:
        for segments in ([(-1, 1)], [(0, 0)], [(0, -1)]):
            with self.subTest(segments=segments):
                with self.assertRaises(ValueError):
                    _pooled_occupation_quantile(segments, 95, 100)


def _two_user_tape(end_us):
    tape = build_primary_influx_tape("supporting-metric-root", TapeArm.REFERENCE)
    vehicles = tuple(
        replace(
            item,
            arrival_simulation_time_us=0,
            arrival_analysis_tau_us=0,
            departure_simulation_time_us=end_us,
            departure_analysis_tau_us=end_us,
            last_success_generation_us_at_entry=-100_000,
        )
        for item in tape.vehicles[:2]
    )
    return replace(
        tape,
        simulation_end_us=end_us,
        analysis_origin_simulation_time_us=0,
        analysis_tau_end_us=end_us,
        paired_anchor_simulation_time_us=end_us // 2,
        paired_anchor_analysis_tau_us=end_us // 2,
        vehicles=vehicles,
        arrivals=(),
        controlled_vehicle_id=vehicles[0].vehicle_id,
        background_reselections=(),
        channel_draws=tuple(
            item for item in tape.channel_draws if item.vehicle_id in {v.vehicle_id for v in vehicles}
        ),
        counters=tuple(
            item for item in tape.counters if item.vehicle_id in {v.vehicle_id for v in vehicles}
        ),
    )


def _attempt(attempt_id, time_us, generation_us, success, vehicle_id="vehicle_0"):
    return TxAttemptRecord(
        schema_version=TX_ATTEMPT_RECORD_SCHEMA_VERSION,
        attempt_id=attempt_id,
        time_us=time_us,
        vehicle_id=vehicle_id,
        packet_generation_us=generation_us,
        logical_subchannel_id=0,
        channel_uniform_u64=0,
        outcome=TerminalOutcome.RX_SUCCESS if success else TerminalOutcome.COLLISION,
        collided=not success,
        success=success,
    )


def _truth(event_id, time_us, kind, vehicle_id="vehicle_0", version=0):
    return TruthEventRecord(
        schema_version=TRUTH_EVENT_RECORD_SCHEMA_VERSION,
        event_id=event_id,
        time_us=time_us,
        kind=kind,
        vehicle_id=vehicle_id,
        reservation_version=version,
    )


if __name__ == "__main__":
    unittest.main()
