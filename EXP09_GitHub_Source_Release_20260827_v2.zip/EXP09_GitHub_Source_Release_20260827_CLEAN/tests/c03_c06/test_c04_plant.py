from dataclasses import replace
import unittest

from _support import SRC_ROOT  # noqa: F401

from exp09.contracts.actions import ACTION_SCHEMA_VERSION, ActionKind, ControlAction
from exp09.contracts.events import EventKind
from exp09.contracts.ids import ControlOpportunityId
from exp09.contracts.tape import (
    CounterNamespace,
    TAPE_GRANT_SCHEMA_VERSION,
    TapeArm,
    TapeGrant,
)
from exp09.evaluation.disturbance_tape import (
    ScenarioSemanticValidator,
    build_primary_influx_tape,
)
from exp09.plant.event_queue import EventQueue, make_event
from exp09.plant.plant import DiscreteEventSPSPlant


class C04PlantTests(unittest.TestCase):
    def test_same_tape_replays_identical_trace(self) -> None:
        tape = build_primary_influx_tape("replay-root", TapeArm.REFERENCE)
        self.assertEqual(_run_until_end(tape), _run_until_end(tape))

    def test_arriving_vehicle_never_moves_time_backwards(self) -> None:
        tape = build_primary_influx_tape("arrival-root", TapeArm.EVENT)
        plant = DiscreteEventSPSPlant()
        plant.reset(tape)
        previous = 0
        while previous < int(tape.simulation_end_us):
            result = plant.advance_until(int(tape.simulation_end_us))
            self.assertGreaterEqual(result.snapshot.time_us, previous)
            previous = result.snapshot.time_us
            if result.opportunities:
                _retain(plant, result.opportunities[0])
            else:
                break

    def test_control_opportunity_only_after_counter_expiry(self) -> None:
        tape = build_primary_influx_tape("counter-root", TapeArm.REFERENCE)
        plant = DiscreteEventSPSPlant()
        plant.reset(tape)
        result = plant.advance_until(int(tape.simulation_end_us))
        controlled_attempts = [
            item for item in result.snapshot.trace.tx_attempts if item.vehicle_id == "vehicle_0"
        ]
        self.assertGreaterEqual(len(controlled_attempts), 5)
        self.assertGreaterEqual(
            int(result.opportunities[0].time_us),
            int(tape.analysis_origin_simulation_time_us),
        )
        self.assertEqual(
            int(result.opportunities[0].time_us),
            max(
                item.time_us
                for item in controlled_attempts
                if item.time_us <= int(result.opportunities[0].time_us)
            ),
        )

    def test_invalid_action_id_and_rri_fail_closed(self) -> None:
        tape = build_primary_influx_tape("action-root", TapeArm.REFERENCE)
        plant = DiscreteEventSPSPlant()
        plant.reset(tape)
        opportunity = plant.advance_until(int(tape.simulation_end_us)).opportunities[0]
        with self.assertRaises(ValueError):
            plant.apply(
                opportunity,
                ControlAction(
                    schema_version=ACTION_SCHEMA_VERSION,
                    opportunity_id=ControlOpportunityId("wrong"),
                    kind=ActionKind.RETAIN_AT_EXPIRY,
                    target_rri_us=None,
                ),
            )
        with self.assertRaises(ValueError):
            plant.apply(
                opportunity,
                ControlAction(
                    schema_version=ACTION_SCHEMA_VERSION,
                    opportunity_id=opportunity.opportunity_id,
                    kind=ActionKind.RESELECT,
                    target_rri_us=12345,
                ),
            )

    def test_reselect_schedules_earliest_strictly_future_grant(self) -> None:
        tape = build_primary_influx_tape("reselect-root", TapeArm.REFERENCE)
        plant = DiscreteEventSPSPlant()
        plant.reset(tape)
        opportunity = plant.advance_until(int(tape.simulation_end_us)).opportunities[0]
        snapshot = plant.apply(
            opportunity,
            ControlAction(
                schema_version=ACTION_SCHEMA_VERSION,
                opportunity_id=opportunity.opportunity_id,
                kind=ActionKind.RESELECT,
                target_rri_us=opportunity.legal_rri_us[0],
            ),
        )
        controlled = next(item for item in snapshot.vehicles if item.vehicle_id == "vehicle_0")
        first_tx = min(
            int(item.header.time_us)
            for item in snapshot.event_queue
            if item.vehicle_id == "vehicle_0" and item.header.kind.value == "tx"
        )
        self.assertGreater(first_tx, int(opportunity.time_us))
        self.assertEqual(first_tx % controlled.grant.rri_us, controlled.grant.slot_offset_us)

    def test_snapshot_restore_preserves_observation_ids(self) -> None:
        tape = build_primary_influx_tape("snapshot-root", TapeArm.REFERENCE)
        plant = DiscreteEventSPSPlant()
        plant.reset(tape)
        snapshot = plant.advance_until(2_000_000).snapshot
        restored = DiscreteEventSPSPlant()
        restored.restore(snapshot)
        self.assertEqual(restored.snapshot(), snapshot)

    def test_snapshot_restore_replays_applied_action_certificate(self) -> None:
        tape = build_primary_influx_tape("snapshot-action-certificate", TapeArm.REFERENCE)
        plant = DiscreteEventSPSPlant()
        plant.reset(tape)
        opportunity = plant.advance_until(int(tape.simulation_end_us)).opportunities[0]
        snapshot = _retain(plant, opportunity)
        self.assertEqual(len(snapshot.action_history), 1)

        restored = DiscreteEventSPSPlant()
        restored.restore(snapshot)
        self.assertEqual(restored.snapshot(), snapshot)
        with self.assertRaises(ValueError):
            DiscreteEventSPSPlant().restore(replace(snapshot, action_history=()))

    def test_snapshot_restore_preserves_consumed_event_id_tombstones(self) -> None:
        tape = build_primary_influx_tape("snapshot-event-tombstone", TapeArm.REFERENCE)
        plant = DiscreteEventSPSPlant()
        snapshot = plant.reset(tape)
        queued_id = str(snapshot.event_queue[0].header.event_id)
        progressed = plant.advance_until(1).snapshot
        self.assertIn(queued_id, progressed.queue_consumed_event_ids)

        restored = DiscreteEventSPSPlant()
        restored.restore(progressed)
        with self.assertRaisesRegex(ValueError, "duplicate event_id"):
            restored._queue.push(  # noqa: SLF001 - exercises the restored scheduler boundary.
                make_event(EventKind.TX, 1_000_000, queued_id, "vehicle_0")
            )

    def test_snapshot_restore_rejects_deleted_consumed_tombstone_and_id_reuse(
        self,
    ) -> None:
        tape = build_primary_influx_tape("snapshot-tombstone-integrity", TapeArm.REFERENCE)
        plant = DiscreteEventSPSPlant()
        plant.reset(tape)
        snapshot = plant.advance_until(1).snapshot
        consumed_id = snapshot.queue_consumed_event_ids[0]
        without_tombstone = replace(
            snapshot,
            queue_consumed_event_ids=tuple(
                item for item in snapshot.queue_consumed_event_ids if item != consumed_id
            ),
        )
        reused = make_event(
            EventKind.TX,
            1_000_000,
            consumed_id,
            str(tape.controlled_vehicle_id),
        )
        cases = (
            without_tombstone,
            replace(
                without_tombstone,
                event_queue=without_tombstone.event_queue + (reused,),
            ),
        )
        for invalid_snapshot in cases:
            with self.subTest(reused=invalid_snapshot is cases[1]):
                with self.assertRaises(ValueError):
                    DiscreteEventSPSPlant().restore(invalid_snapshot)

    def test_snapshot_restore_rejects_deleted_injected_and_modified_future_event(
        self,
    ) -> None:
        tape = build_primary_influx_tape("snapshot-future-queue-integrity", TapeArm.REFERENCE)
        plant = DiscreteEventSPSPlant()
        plant.reset(tape)
        snapshot = plant.advance_until(1).snapshot
        future_tx = next(
            item for item in snapshot.event_queue if item.header.kind is EventKind.TX
        )
        injected = make_event(
            EventKind.TX,
            int(future_tx.header.time_us) + 1,
            "injected-future-event",
            future_tx.vehicle_id,
        )
        modified = replace(
            future_tx,
            header=replace(
                future_tx.header,
                time_us=int(future_tx.header.time_us) + 1,
            ),
        )
        without_tx = tuple(item for item in snapshot.event_queue if item != future_tx)
        cases = (
            replace(snapshot, event_queue=without_tx),
            replace(snapshot, event_queue=snapshot.event_queue + (injected,)),
            replace(snapshot, event_queue=without_tx + (modified,)),
        )
        for invalid_snapshot in cases:
            with self.subTest(event_count=len(invalid_snapshot.event_queue)):
                with self.assertRaises(ValueError):
                    DiscreteEventSPSPlant().restore(invalid_snapshot)

    def test_snapshot_restore_rejects_invalid_time_and_vehicle_population(self) -> None:
        tape = build_primary_influx_tape("snapshot-invalid-state", TapeArm.REFERENCE)
        plant = DiscreteEventSPSPlant()
        snapshot = plant.reset(tape)
        controlled_id = str(tape.controlled_vehicle_id)
        non_controlled = next(
            item for item in snapshot.vehicles if item.vehicle_id != controlled_id
        )
        cases = (
            replace(snapshot, time_us=-1),
            replace(snapshot, time_us=int(tape.simulation_end_us) + 1),
            replace(snapshot, vehicles=snapshot.vehicles + (non_controlled,)),
            replace(
                snapshot,
                vehicles=tuple(
                    item for item in snapshot.vehicles if item != non_controlled
                ),
            ),
            replace(
                snapshot,
                vehicles=tuple(
                    item for item in snapshot.vehicles if item.vehicle_id != controlled_id
                ),
            ),
        )
        for invalid_snapshot in cases:
            with self.subTest(invalid_snapshot=invalid_snapshot):
                with self.assertRaises(ValueError):
                    DiscreteEventSPSPlant().restore(invalid_snapshot)

    def test_vehicle_state_rejects_negative_counters_ordinals_and_packet_time(self) -> None:
        tape = build_primary_influx_tape("snapshot-invalid-fields", TapeArm.REFERENCE)
        snapshot = DiscreteEventSPSPlant().reset(tape)
        state = snapshot.vehicles[0]
        invalid_fields = {
            "reselection_counter": -1,
            "reservation_version": -1,
            "tx_ordinal": -1,
            "reselection_ordinal": -1,
            "next_packet_generation_us": -1,
            "waiting_packet_generation_us": -1,
        }
        for field_name, value in invalid_fields.items():
            with self.subTest(field_name=field_name):
                with self.assertRaises(ValueError):
                    replace(state, **{field_name: value})

    def test_snapshot_restore_rejects_vehicle_timeline_and_packet_lattice_conflicts(
        self,
    ) -> None:
        tape = build_primary_influx_tape("snapshot-invalid-timeline", TapeArm.EVENT)
        plant = DiscreteEventSPSPlant()
        snapshot = plant.reset(tape)
        initial = next(item for item in snapshot.vehicles if item.present)
        future = next(item for item in snapshot.vehicles if not item.present)
        cases = (
            replace(initial, present=False),
            replace(future, present=True),
            replace(
                initial,
                next_packet_generation_us=initial.next_packet_generation_us + 1,
            ),
        )
        for invalid_state in cases:
            vehicles = tuple(
                invalid_state if item.vehicle_id == invalid_state.vehicle_id else item
                for item in snapshot.vehicles
            )
            with self.subTest(vehicle_id=invalid_state.vehicle_id):
                with self.assertRaises(ValueError):
                    DiscreteEventSPSPlant().restore(
                        replace(snapshot, vehicles=vehicles)
                    )

    def test_snapshot_restore_rejects_truncated_nonempty_histories(self) -> None:
        tape = build_primary_influx_tape("snapshot-truncated-history", TapeArm.REFERENCE)
        plant = DiscreteEventSPSPlant()
        plant.reset(tape)
        snapshot = plant.advance_until(int(tape.simulation_end_us)).snapshot
        self.assertTrue(snapshot.trace.tx_attempts)
        self.assertTrue(snapshot.observations)
        self.assertTrue(snapshot.measurement_deliveries)
        cases = (
            replace(
                snapshot,
                trace=replace(
                    snapshot.trace,
                    tx_attempts=snapshot.trace.tx_attempts[:-1],
                ),
            ),
            replace(snapshot, observations=snapshot.observations[:-1]),
            replace(
                snapshot,
                measurement_deliveries=snapshot.measurement_deliveries[:-1],
            ),
        )
        for invalid_snapshot in cases:
            with self.subTest(invalid_snapshot=invalid_snapshot):
                with self.assertRaises(ValueError):
                    DiscreteEventSPSPlant().restore(invalid_snapshot)

    def test_snapshot_restore_rejects_queue_watermark_and_past_event(self) -> None:
        tape = build_primary_influx_tape("snapshot-invalid-queue", TapeArm.REFERENCE)
        plant = DiscreteEventSPSPlant()
        plant.reset(tape)
        snapshot = plant.advance_until(1).snapshot
        event = snapshot.event_queue[0]
        past_event = replace(event, header=replace(event.header, time_us=0))
        cases = (
            replace(snapshot, queue_processed_priority=None),
            replace(
                snapshot,
                queue_processed_time_us=snapshot.time_us + 1,
                queue_processed_priority=10,
            ),
            replace(
                snapshot,
                event_queue=(past_event,) + snapshot.event_queue[1:],
            ),
        )
        for invalid_snapshot in cases:
            with self.subTest(invalid_snapshot=invalid_snapshot):
                with self.assertRaises(ValueError):
                    DiscreteEventSPSPlant().restore(invalid_snapshot)

    def test_snapshot_restore_rejects_event_at_exclusive_analysis_end(self) -> None:
        tape = build_primary_influx_tape("snapshot-end-boundary", TapeArm.REFERENCE)
        snapshot = DiscreteEventSPSPlant().reset(tape)
        event = next(
            item
            for item in snapshot.event_queue
            if item.header.kind is not EventKind.MEASUREMENT_DELIVERY
        )
        invalid_event = replace(
            event,
            header=replace(event.header, time_us=int(tape.simulation_end_us)),
        )
        invalid_snapshot = replace(
            snapshot,
            event_queue=(invalid_event,)
            + tuple(item for item in snapshot.event_queue if item is not event),
        )
        with self.assertRaises(ValueError):
            DiscreteEventSPSPlant().restore(invalid_snapshot)

    def test_snapshot_restore_accepts_same_time_multivehicle_and_departure_edges(
        self,
    ) -> None:
        tape = build_primary_influx_tape("snapshot-valid-edges", TapeArm.REFERENCE)
        vehicles = list(tape.vehicles)
        same_grant = TapeGrant(TAPE_GRANT_SCHEMA_VERSION, 100_000, 50_000, 0)
        vehicles[0] = replace(
            vehicles[0],
            initial_grant=same_grant,
            packet_phase_us=0,
            last_success_generation_us_at_entry=-1,
        )
        vehicles[1] = replace(
            vehicles[1],
            initial_grant=same_grant,
            packet_phase_us=0,
            departure_simulation_time_us=150_000,
            departure_analysis_tau_us=-9_850_000,
        )
        tape = replace(tape, vehicles=tuple(vehicles))
        plant = DiscreteEventSPSPlant()
        plant.reset(tape)
        snapshot = plant.advance_until(150_001).snapshot
        same_time_attempts = tuple(
            item for item in snapshot.trace.tx_attempts if item.time_us == 50_000
        )
        self.assertGreaterEqual(len(same_time_attempts), 2)
        self.assertFalse(
            next(item for item in snapshot.vehicles if item.vehicle_id == "vehicle_1").present
        )
        restored = DiscreteEventSPSPlant()
        restored.restore(snapshot)
        self.assertEqual(restored.snapshot(), snapshot)

    def test_snapshot_restore_rejects_inconsistent_pending_opportunity(self) -> None:
        tape = build_primary_influx_tape("snapshot-invalid-opportunity", TapeArm.REFERENCE)
        plant = DiscreteEventSPSPlant()
        plant.reset(tape)
        snapshot = plant.advance_until(int(tape.simulation_end_us)).snapshot
        opportunity = snapshot.pending_opportunity
        self.assertIsNotNone(opportunity)
        assert opportunity is not None
        non_controlled = next(
            item
            for item in snapshot.vehicles
            if item.vehicle_id != str(tape.controlled_vehicle_id)
        )
        cases = (
            replace(
                snapshot,
                pending_opportunity=replace(
                    opportunity, time_us=int(opportunity.time_us) + 1
                ),
            ),
            replace(
                snapshot,
                pending_opportunity=replace(
                    opportunity, vehicle_id=non_controlled.vehicle_id
                ),
            ),
            replace(
                snapshot,
                pending_opportunity=replace(
                    opportunity,
                    reservation_version=opportunity.reservation_version + 1,
                ),
            ),
        )
        for invalid_snapshot in cases:
            with self.subTest(invalid_snapshot=invalid_snapshot):
                with self.assertRaises(ValueError):
                    DiscreteEventSPSPlant().restore(invalid_snapshot)

    def test_snapshot_restore_rejects_measurement_delivery_conflicts(self) -> None:
        tape = build_primary_influx_tape("snapshot-invalid-delivery", TapeArm.REFERENCE)
        plant = DiscreteEventSPSPlant()
        queued_snapshot = plant.reset(tape)
        queued = queued_snapshot.measurement_delivery_queue[0]
        delivered_snapshot = plant.advance_until(1).snapshot
        delivered = delivered_snapshot.measurement_deliveries[0]
        cases = (
            replace(
                queued_snapshot,
                measurement_delivery_queue=(queued, queued)
                + queued_snapshot.measurement_delivery_queue[1:],
            ),
            replace(
                delivered_snapshot,
                measurement_deliveries=delivered_snapshot.measurement_deliveries
                + (delivered,),
            ),
            replace(
                queued_snapshot,
                measurement_deliveries=(queued,),
            ),
        )
        for invalid_snapshot in cases:
            with self.subTest(invalid_snapshot=invalid_snapshot):
                with self.assertRaises(ValueError):
                    DiscreteEventSPSPlant().restore(invalid_snapshot)

    def test_failed_snapshot_restore_does_not_mutate_the_plant(self) -> None:
        tape = build_primary_influx_tape("snapshot-atomic-restore", TapeArm.REFERENCE)
        plant = DiscreteEventSPSPlant()
        original = plant.reset(tape)
        with self.assertRaises(ValueError):
            plant.restore(replace(original, time_us=-1))
        self.assertEqual(plant.snapshot(), original)

    def test_phase60_delivery_is_committed_before_same_time_opportunity(self) -> None:
        tape = build_primary_influx_tape("phase60-order", TapeArm.REFERENCE)
        plant = DiscreteEventSPSPlant()
        plant.reset(tape)
        result = plant.advance_until(int(tape.simulation_end_us))
        opportunity = result.opportunities[0]
        same_time = tuple(
            event
            for event in result.measurement_delivery_delta
            if int(event.delivered_at_us) == int(opportunity.time_us)
        )
        self.assertTrue(same_time)
        self.assertEqual(result.snapshot.queue_processed_priority, 70)
        self.assertTrue(
            set(same_time).issubset(set(result.snapshot.measurement_deliveries))
        )

    def test_collision_requires_waiting_packets_before_same_time_tx(self) -> None:
        tape = build_primary_influx_tape("collision-root", TapeArm.REFERENCE)
        grant = TapeGrant(TAPE_GRANT_SCHEMA_VERSION, 100_000, 50_000, 0)
        vehicles = list(tape.vehicles)
        vehicles[0] = replace(vehicles[0], initial_grant=grant, packet_phase_us=0)
        vehicles[1] = replace(vehicles[1], initial_grant=grant, packet_phase_us=0)
        tape = replace(tape, vehicles=tuple(vehicles))
        plant = DiscreteEventSPSPlant()
        plant.reset(tape)
        result = plant.advance_until(200_000)
        self.assertTrue(any(record.collided for record in result.snapshot.trace.tx_attempts))

    def test_empty_buffer_reschedule_uses_a_distinct_event_id(self) -> None:
        tape = build_primary_influx_tape("empty-buffer-event-id", TapeArm.REFERENCE)
        plant = DiscreteEventSPSPlant()
        snapshot = plant.reset(tape)
        vehicle = next(
            item
            for item in snapshot.vehicles
            if int(item.grant.slot_offset_us) < int(item.next_packet_generation_us)
        )
        original_tx = next(
            item
            for item in snapshot.event_queue
            if item.vehicle_id == vehicle.vehicle_id and item.header.kind is EventKind.TX
        )
        result = plant.advance_until(int(original_tx.header.time_us) + 1)
        rescheduled_tx = next(
            item
            for item in result.snapshot.event_queue
            if item.vehicle_id == vehicle.vehicle_id and item.header.kind is EventKind.TX
        )
        self.assertGreater(int(rescheduled_tx.header.time_us), int(original_tx.header.time_us))
        self.assertNotEqual(rescheduled_tx.header.event_id, original_tx.header.event_id)

    def test_counter_expiry_and_control_opportunity_are_explicit_events(self) -> None:
        tape = build_primary_influx_tape("explicit-expiry", TapeArm.REFERENCE)
        plant = DiscreteEventSPSPlant()
        plant.reset(tape)
        opportunity = plant.advance_until(int(tape.simulation_end_us)).opportunities[0]
        snapshot = plant.snapshot()
        self.assertEqual(int(opportunity.time_us), snapshot.time_us)
        self.assertEqual(snapshot.queue_processed_priority, 70)

    def test_burn_in_auto_retain_and_exact_origin_expiry_is_scored(self) -> None:
        tape = build_primary_influx_tape("burn-in-boundary", TapeArm.REFERENCE)
        grant = TapeGrant(TAPE_GRANT_SCHEMA_VERSION, 100_000, 0, 0)
        vehicles = list(tape.vehicles)
        vehicles[0] = replace(
            vehicles[0],
            initial_grant=grant,
            packet_phase_us=0,
        )
        counters = tuple(
            replace(item, value=5)
            if str(item.vehicle_id) == "vehicle_0"
            else item
            for item in tape.counters
        )
        plant = DiscreteEventSPSPlant()
        plant.reset(replace(tape, vehicles=tuple(vehicles), counters=counters))
        result = plant.advance_until(10_000_001)
        self.assertEqual(len(result.opportunities), 1)
        self.assertEqual(int(result.opportunities[0].time_us), 10_000_000)
        controlled = next(
            item for item in result.snapshot.vehicles if item.vehicle_id == "vehicle_0"
        )
        self.assertGreater(controlled.reservation_version, 0)
        expected = next(
            item.value
            for item in counters
            if str(item.vehicle_id) == "vehicle_0"
            and item.counter_namespace is CounterNamespace.REBUILD
            and item.counter_ordinal == controlled.reservation_version
        )
        self.assertEqual(expected, 5)
        self.assertTrue(
            all(
                item.time_us >= 10_000_000
                for item in result.snapshot.trace.truth_events
                if item.kind.value == "CONTROL_OPPORTUNITY"
            )
        )

    def test_departure_cancels_all_future_vehicle_events(self) -> None:
        tape = build_primary_influx_tape("departure-cancel", TapeArm.REFERENCE)
        vehicles = list(tape.vehicles)
        vehicles[1] = replace(
            vehicles[1],
            departure_simulation_time_us=150_000,
            departure_analysis_tau_us=-9_850_000,
        )
        tape = replace(tape, vehicles=tuple(vehicles))
        plant = DiscreteEventSPSPlant()
        plant.reset(tape)
        result = plant.advance_until(200_000)
        departed = next(item for item in result.snapshot.vehicles if item.vehicle_id == "vehicle_1")
        self.assertFalse(departed.present)
        self.assertFalse(
            any(
                item.vehicle_id == "vehicle_1"
                and item.header.kind is not EventKind.MEASUREMENT_DELIVERY
                for item in result.snapshot.event_queue
            )
        )

    def test_departure_preserves_same_time_phase60_delivery(self) -> None:
        tape = build_primary_influx_tape("departure-phase60", TapeArm.REFERENCE)
        vehicle = tape.vehicles[1]
        departure_us = int(vehicle.initial_grant.slot_offset_us)
        vehicles = list(tape.vehicles)
        vehicles[1] = replace(
            vehicle,
            packet_phase_us=0,
            departure_simulation_time_us=departure_us,
            departure_analysis_tau_us=departure_us - 10_000_000,
        )
        plant = DiscreteEventSPSPlant()
        plant.reset(replace(tape, vehicles=tuple(vehicles)))
        result = plant.advance_until(departure_us + 1)
        same_time = tuple(
            event
            for event in result.measurement_delivery_delta
            if int(event.delivered_at_us) == departure_us
        )
        self.assertTrue(any(event.attempt is not None for event in same_time))
        self.assertTrue(any(event.identity is not None for event in same_time))

    def test_dynamic_same_time_phase_drain_handles_later_child(self) -> None:
        queue = EventQueue(
            (
                make_event(EventKind.TX, 300_000, "tx", "vehicle_0"),
                make_event(EventKind.PACKET_GENERATE, 300_000, "packet", "vehicle_6"),
            )
        )
        self.assertEqual(queue.pop_phase_batch()[0].header.kind, EventKind.TX)
        queue.push(
            make_event(
                EventKind.CONTROL_OPPORTUNITY,
                300_000,
                "opportunity",
                "vehicle_0",
            )
        )
        self.assertEqual(queue.pop_phase_batch()[0].header.kind, EventKind.PACKET_GENERATE)
        self.assertEqual(queue.pop_phase_batch()[0].header.kind, EventKind.CONTROL_OPPORTUNITY)

    def test_primary_realized_truth_delta_matches_registry(self) -> None:
        reference = build_primary_influx_tape("truth-delta", TapeArm.REFERENCE)
        event = build_primary_influx_tape("truth-delta", TapeArm.EVENT)
        reference_snapshot = _run_until_end(reference)
        event_snapshot = _run_until_end(event)
        ScenarioSemanticValidator.validate_truth_delta(
            reference_snapshot.trace,
            event_snapshot.trace,
        )


def _retain(plant, opportunity):
    return plant.apply(
        opportunity,
        ControlAction(
            schema_version=ACTION_SCHEMA_VERSION,
            opportunity_id=opportunity.opportunity_id,
            kind=ActionKind.RETAIN_AT_EXPIRY,
            target_rri_us=None,
        ),
    )


def _run_until_end(tape):
    plant = DiscreteEventSPSPlant()
    plant.reset(tape)
    while plant.snapshot().time_us < int(tape.simulation_end_us):
        result = plant.advance_until(int(tape.simulation_end_us))
        if result.opportunities:
            _retain(plant, result.opportunities[0])
        else:
            break
    return plant.snapshot()


if __name__ == "__main__":
    unittest.main()
