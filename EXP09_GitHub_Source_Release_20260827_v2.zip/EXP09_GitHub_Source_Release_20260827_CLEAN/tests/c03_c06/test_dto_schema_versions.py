from dataclasses import MISSING, fields, replace
import unittest

from _support import SRC_ROOT  # noqa: F401

from exp09.contracts.events import EventKind
from exp09.contracts.observable import (
    MeasurementDeliveryEvent,
    ReceiverAttemptObservation,
)
from exp09.contracts.tape import TapeArm
from exp09.evaluation.disturbance_tape import build_primary_influx_tape
from exp09.evaluation.runner import (
    RAW_RUN_TRACE_SCHEMA_VERSION,
    RawRunTrace,
    RunResult,
)
from exp09.measurement.receiver_ledger import (
    DeliveredSummary,
    LedgerSnapshot,
    MeasurementSummary,
    ReceiverMeasurementLedger,
    deliver_summary,
)
from exp09.plant.event_queue import QueuedEvent, make_event
from exp09.plant.plant import DiscreteEventSPSPlant
from exp09.plant.state import (
    PlantAdvanceResult,
    PlantSnapshot,
    PlantTrace,
    TruthEventRecord,
    TxAttemptRecord,
    VehicleState,
)


class DtoSchemaVersionTests(unittest.TestCase):
    def test_schema_version_is_required_for_each_state_transport_dto(self) -> None:
        dto_types = (
            QueuedEvent,
            VehicleState,
            TxAttemptRecord,
            TruthEventRecord,
            PlantTrace,
            PlantSnapshot,
            PlantAdvanceResult,
            MeasurementSummary,
            DeliveredSummary,
            LedgerSnapshot,
            ReceiverAttemptObservation,
            MeasurementDeliveryEvent,
            RawRunTrace,
            RunResult,
        )
        for dto_type in dto_types:
            with self.subTest(dto=dto_type.__name__):
                schema_field = next(
                    field for field in fields(dto_type) if field.name == "schema_version"
                )
                self.assertIs(schema_field.default, MISSING)
                self.assertIs(schema_field.default_factory, MISSING)

    def test_each_state_transport_dto_rejects_unknown_schema_version(self) -> None:
        for instance in _valid_dto_instances():
            with self.subTest(dto=type(instance).__name__):
                with self.assertRaisesRegex(ValueError, "unsupported .* schema version"):
                    replace(instance, schema_version="wrong")

    def test_upgraded_dtos_reject_their_actual_retired_schema_versions(self) -> None:
        instances = _valid_dto_instances()
        by_type = {type(instance): instance for instance in instances}
        retired_versions = (
            (ReceiverAttemptObservation, "exp09-receiver-attempt-observation-v1"),
            (MeasurementDeliveryEvent, "exp09-measurement-delivery-event-v1"),
            (PlantSnapshot, "exp09-plant-snapshot-v2"),
            (PlantAdvanceResult, "exp09-plant-advance-result-v1"),
            (MeasurementSummary, "exp09-measurement-summary-v1"),
            (LedgerSnapshot, "exp09-ledger-snapshot-v1"),
            (RawRunTrace, "exp09-raw-run-trace-v2"),
        )
        for dto_type, retired_version in retired_versions:
            with self.subTest(dto=dto_type.__name__, version=retired_version):
                with self.assertRaisesRegex(ValueError, "unsupported .* schema"):
                    replace(by_type[dto_type], schema_version=retired_version)

        raw = by_type[RawRunTrace]
        with self.assertRaisesRegex(ValueError, "unsupported run-result schema"):
            RunResult(
                schema_version="exp09-run-result-v1",
                root_case_id=str(raw.tape.root_case_id),
                arm=raw.tape.arm,
                metrics=None,  # type: ignore[arg-type] - schema rejection precedes payload use.
                observable_frame_count=0,
                tx_attempts=0,
                raw_trace=raw,
                integrity_hash="",
            )


def _valid_dto_instances():
    tape = build_primary_influx_tape("dto-version-contract", TapeArm.REFERENCE)
    plant = DiscreteEventSPSPlant()
    snapshot = plant.reset(tape)
    advance_result = plant.advance_until(int(tape.simulation_end_us))
    trace = advance_result.snapshot.trace
    if not trace.tx_attempts or not trace.truth_events:
        raise AssertionError("plant fixture must produce attempt and truth records")

    ledger = ReceiverMeasurementLedger()
    summary = ledger.summarize(50_000)
    delivery = next(
        item
        for item in advance_result.snapshot.measurement_deliveries
        if item.attempt is not None
    )
    assert delivery.attempt is not None
    raw = RawRunTrace(
        schema_version=RAW_RUN_TRACE_SCHEMA_VERSION,
        tape=tape,
        plant_trace=trace,
        actions=(),
        measurement_deliveries=(),
        ledger_snapshot=ledger.snapshot(),
        summaries=(),
        summary_deliveries=(),
    )
    return (
        make_event(EventKind.TX, 10, "dto-event", "vehicle_0"),
        snapshot.vehicles[0],
        trace.tx_attempts[0],
        trace.truth_events[0],
        trace,
        snapshot,
        advance_result,
        summary,
        deliver_summary(summary),
        ledger.snapshot(),
        delivery.attempt,
        delivery,
        raw,
    )


if __name__ == "__main__":
    unittest.main()
