from dataclasses import replace
import json
import tempfile
import unittest
from pathlib import Path

from _support import SRC_ROOT  # noqa: F401

from exp09.contracts.determinism import stable_event_id
from exp09.contracts.events import EventKind
from exp09.contracts.ids import TapeId
from exp09.contracts.tape import TapeArm
from exp09.evaluation.disturbance_tape import (
    ScenarioSemanticValidator,
    _expected_tape_id,
    _generation_config_primitive,
    _stable_config_hash,
    build_primary_influx_tape,
    load_tape,
    save_tape,
    tape_from_bytes,
    tape_to_bytes,
)
from exp09.evaluation.rng import stable_digest_hex
from exp09.plant.event_queue import EVENT_PRIORITIES, EventQueue, make_event


class C03TapeQueueTests(unittest.TestCase):
    def test_primary_pair_shares_all_initial_vehicle_fields(self) -> None:
        reference = build_primary_influx_tape("root-a", TapeArm.REFERENCE)
        event = build_primary_influx_tape("root-a", TapeArm.EVENT)
        self.assertEqual(reference.vehicles, event.vehicles[:6])
        self.assertEqual(reference.background_reselections, event.background_reselections)
        self.assertEqual(reference.channel_draws, event.channel_draws)
        self.assertEqual(
            reference.paired_anchor_simulation_time_us,
            event.paired_anchor_simulation_time_us,
        )
        self.assertEqual(
            reference.paired_anchor_analysis_tau_us,
            event.paired_anchor_analysis_tau_us,
        )
        self.assertEqual(
            event.paired_anchor_simulation_time_us,
            event.arrivals[0].simulation_time_us,
        )
        self.assertEqual(
            event.paired_anchor_analysis_tau_us,
            event.arrivals[0].analysis_tau_us,
        )
        self.assertEqual(reference.counters, event.counters[: len(reference.counters)])
        self.assertEqual(len(event.arrivals), 3)
        ScenarioSemanticValidator.validate_pair(reference, event)

    def test_pair_validator_rejects_mismatched_hidden_anchor(self) -> None:
        reference = build_primary_influx_tape("anchor-invalid", TapeArm.REFERENCE)
        event = build_primary_influx_tape("anchor-invalid", TapeArm.EVENT)
        alternatives = tuple(
            value
            for value in (20_000_000, 22_000_000, 24_000_000)
            if value != int(reference.paired_anchor_simulation_time_us)
        )
        with self.assertRaisesRegex(ValueError, "paired_anchor_simulation_time_us"):
            ScenarioSemanticValidator.validate_pair(
                replace(
                    reference,
                    paired_anchor_simulation_time_us=alternatives[0],
                    paired_anchor_analysis_tau_us=(
                        alternatives[0]
                        - int(reference.analysis_origin_simulation_time_us)
                    ),
                ),
                event,
            )

    def test_tape_canonical_round_trip_is_byte_identical(self) -> None:
        tape = build_primary_influx_tape("roundtrip", TapeArm.EVENT)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "tape.json"
            save_tape(tape, path)
            restored = load_tape(path)
        self.assertEqual(restored, tape)
        self.assertEqual(tape_to_bytes(restored), tape_to_bytes(tape))

    def test_tape_loader_rejects_retired_v1_schema(self) -> None:
        tape = build_primary_influx_tape("retired-v1", TapeArm.EVENT)
        payload = json.loads(tape_to_bytes(tape))
        payload["schema_version"] = "exp09-disturbance-tape-v1"
        with self.assertRaisesRegex(ValueError, "unsupported disturbance-tape schema version"):
            tape_from_bytes(json.dumps(payload).encode("utf-8"))

    def test_event_queue_matches_frozen_ten_phase_order(self) -> None:
        ordered_kinds = (
            EventKind.TX,
            EventKind.VEHICLE_DEPARTURE,
            EventKind.VEHICLE_ARRIVAL,
            EventKind.PACKET_GENERATE,
            EventKind.BACKGROUND_COUNTER_EXPIRE,
            EventKind.MEASUREMENT_DELIVERY,
            EventKind.CONTROL_OPPORTUNITY,
            EventKind.PROPOSAL_VERIFICATION,
            EventKind.FRAME_BUILD,
            EventKind.RESERVATION_COMMIT,
        )
        queue = EventQueue(
            tuple(
                make_event(kind, 10, f"event-{10-index:02d}", "vehicle_0")
                for index, kind in enumerate(reversed(ordered_kinds))
            )
        )
        actual = tuple(event.header.kind for event in queue.pop_time_batch())
        self.assertEqual(actual, ordered_kinds)
        self.assertEqual(
            sorted(set(EVENT_PRIORITIES.values())),
            [10, 20, 30, 40, 50, 60, 70, 80, 90, 100],
        )

    def test_duplicate_event_id_fails_without_corrupting_queue(self) -> None:
        queue = EventQueue((make_event(EventKind.TX, 10, "same", "vehicle_0"),))
        with self.assertRaises(ValueError):
            queue.push(make_event(EventKind.TX, 10, "same", "vehicle_1"))
        self.assertEqual(len(queue.snapshot()), 1)

    def test_same_time_later_phase_can_be_dynamically_drained(self) -> None:
        queue = EventQueue((make_event(EventKind.TX, 10, "tx", "vehicle_0"),))
        self.assertEqual(queue.pop_phase_batch()[0].header.kind, EventKind.TX)
        queue.push(make_event(EventKind.PACKET_GENERATE, 10, "packet", "vehicle_0"))
        self.assertEqual(queue.pop_phase_batch()[0].header.kind, EventKind.PACKET_GENERATE)

    def test_same_time_processed_phase_reinsertion_fails_closed(self) -> None:
        queue = EventQueue((make_event(EventKind.PACKET_GENERATE, 10, "packet", "vehicle_0"),))
        queue.pop_phase_batch()
        with self.assertRaises(ValueError):
            queue.push(make_event(EventKind.VEHICLE_ARRIVAL, 10, "arrival", "vehicle_1"))

    def test_consumed_or_cancelled_event_id_cannot_be_reused(self) -> None:
        removers = (
            lambda queue: queue.pop(),
            lambda queue: queue.cancel_where(lambda _: True),
        )
        for remove in removers:
            queue = EventQueue(
                (make_event(EventKind.TX, 10, "lifetime-id", "vehicle_0"),)
            )
            remove(queue)
            with self.subTest(remove=remove):
                with self.assertRaisesRegex(ValueError, "duplicate event_id"):
                    queue.push(
                        make_event(EventKind.TX, 20, "lifetime-id", "vehicle_0")
                    )

    def test_generation_inputs_bind_config_hash(self) -> None:
        tape = build_primary_influx_tape("config-root", TapeArm.EVENT)
        changed = _generation_config_primitive("config-root")
        changed["onset_analysis_tau_candidates_us"] = [11_000_000]
        self.assertNotEqual(tape.config_hash, _stable_config_hash(changed))

    def test_tape_id_binds_canonical_exogenous_content(self) -> None:
        tape = build_primary_influx_tape("content-id", TapeArm.EVENT)
        first = replace(tape.channel_draws[0], uniform_u64=tape.channel_draws[0].uniform_u64 ^ 1)
        changed = replace(tape, channel_draws=(first, *tape.channel_draws[1:]))
        with self.assertRaises(ValueError):
            tape_from_bytes(tape_to_bytes(changed))

    def test_tape_loader_rejects_resealed_truncation_or_draw_mutation(self) -> None:
        tape = build_primary_influx_tape("resealed-content", TapeArm.EVENT)
        changed_draw = replace(
            tape.channel_draws[0],
            uniform_u64=tape.channel_draws[0].uniform_u64 ^ 1,
        )
        cases = (
            replace(tape, channel_draws=tape.channel_draws[:-1]),
            replace(tape, channel_draws=(changed_draw, *tape.channel_draws[1:])),
            replace(tape, background_reselections=tape.background_reselections[:-1]),
            replace(tape, counters=tape.counters[:-1]),
        )
        for changed in cases:
            resealed = replace(changed, tape_id=TapeId(_expected_tape_id(changed)))
            with self.subTest(
                channel_draws=len(resealed.channel_draws),
                reselections=len(resealed.background_reselections),
            ):
                with self.assertRaisesRegex(ValueError, "keyed generation"):
                    tape_from_bytes(tape_to_bytes(resealed))

    def test_counter_tape_is_keyed_paired_and_fail_closed(self) -> None:
        reference = build_primary_influx_tape("counter-pair", TapeArm.REFERENCE)
        event = build_primary_influx_tape("counter-pair", TapeArm.EVENT)
        self.assertEqual(reference.counters, event.counters[: len(reference.counters)])
        self.assertTrue(all(5 <= item.value <= 15 for item in event.counters))
        damaged = replace(event, counters=event.counters[:-1])
        resealed = replace(damaged, tape_id=TapeId(_expected_tape_id(damaged)))
        with self.assertRaisesRegex(ValueError, "keyed generation"):
            tape_from_bytes(tape_to_bytes(resealed))

    def test_pair_validator_rejects_compound_channel_delta(self) -> None:
        reference = build_primary_influx_tape("pair-invalid", TapeArm.REFERENCE)
        event = build_primary_influx_tape("pair-invalid", TapeArm.EVENT)
        first = replace(event.channel_draws[0], uniform_u64=event.channel_draws[0].uniform_u64 ^ 1)
        changed = replace(event, channel_draws=(first, *event.channel_draws[1:]))
        with self.assertRaises(ValueError):
            ScenarioSemanticValidator.validate_pair(reference, changed)

    def test_tape_rejects_duplicate_or_gapped_draw_ordinals(self) -> None:
        tape = build_primary_influx_tape("ordinal-invalid", TapeArm.EVENT)
        for field in ("background_reselections", "channel_draws"):
            items = list(getattr(tape, field))
            first_vehicle = items[0].vehicle_id
            first_two = [index for index, item in enumerate(items) if item.vehicle_id == first_vehicle][:2]
            items[first_two[1]] = replace(
                items[first_two[1]], ordinal=items[first_two[0]].ordinal
            )
            with self.subTest(field=field):
                with self.assertRaisesRegex(ValueError, "ordinal"):
                    replace(tape, **{field: tuple(items)})

    def test_tape_rejects_illegal_reselection_grant(self) -> None:
        tape = build_primary_influx_tape("draw-domain-invalid", TapeArm.EVENT)
        invalid_grant = replace(
            tape.background_reselections[0].grant,
            logical_subchannel_id=tape.logical_subchannel_count,
        )
        invalid_reselection = replace(
            tape.background_reselections[0], grant=invalid_grant
        )
        with self.assertRaisesRegex(ValueError, "outside the logical grid"):
            replace(
                tape,
                background_reselections=(
                    invalid_reselection,
                    *tape.background_reselections[1:],
                ),
            )

    def test_typed_rng_encoding_has_no_separator_or_type_collision(self) -> None:
        self.assertNotEqual(stable_digest_hex("a\x1fb", "c"), stable_digest_hex("a", "b\x1fc"))
        self.assertNotEqual(stable_digest_hex(1), stable_digest_hex("1"))

    def test_stable_event_id_requires_the_frozen_five_components(self) -> None:
        base = stable_event_id(None, "tx", "vehicle_0", "resource_0", 0)
        variants = (
            stable_event_id("parent", "tx", "vehicle_0", "resource_0", 0),
            stable_event_id(None, "packet_generate", "vehicle_0", "resource_0", 0),
            stable_event_id(None, "tx", "vehicle_1", "resource_0", 0),
            stable_event_id(None, "tx", "vehicle_0", "resource_1", 0),
            stable_event_id(None, "tx", "vehicle_0", "resource_0", 1),
        )
        self.assertEqual(len(set((base, *variants))), 6)
        for invalid in (-1, True, "0"):
            with self.subTest(invalid=invalid):
                with self.assertRaisesRegex(ValueError, "ordinal"):
                    stable_event_id(None, "tx", "vehicle_0", None, invalid)  # type: ignore[arg-type]


if __name__ == "__main__":
    unittest.main()
