import dataclasses
from dataclasses import replace
import unittest

from _support import SRC_ROOT  # noqa: F401

from exp09.contracts.ids import EventId, VehicleId
from exp09.contracts.observable import (
    RECEIVER_ATTEMPT_OBSERVATION_SCHEMA_VERSION,
    RECEIVER_IDENTITY_EVENT_SCHEMA_VERSION,
    RECEIVER_PACKET_OBSERVATION_SCHEMA_VERSION,
    MissingReasonCode,
    ObservableCounterKind,
    ReceiverAttemptObservation,
    ReceiverIdentityEvent,
    ReceiverObservableKind,
    ReceiverPacketObservation,
)
from exp09.contracts.time import SimTimeUs
from exp09.measurement.receiver_ledger import ObservationAdapter, ReceiverMeasurementLedger
from exp09.measurement.receiver_ledger import (
    DELIVERED_SUMMARY_SCHEMA_VERSION,
    LEDGER_SNAPSHOT_SCHEMA_VERSION,
    DeliveredSummary,
    LedgerSnapshot,
    SummaryDeliveryReceiver,
    deliver_summary,
    transport_summary,
)


class C05MeasurementTests(unittest.TestCase):
    def test_window_counts_terminal_trials_and_busy_slots(self) -> None:
        ledger = ReceiverMeasurementLedger()
        ledger.ingest(_attempt("old", 0, False))
        ledger.ingest(_attempt("a", 100_000, True))
        ledger.ingest(_attempt("b", 100_000, False))
        summary = ledger.summarize(500_000)
        self.assertEqual(summary.decode_trial_count, 2)
        self.assertEqual(summary.decoded_success_count, 1)
        self.assertEqual(summary.busy_sensing_slot_count, 1)
        frame = ObservationAdapter().build(summary, 510_000)
        counts = {item.kind: item.value for item in frame.counters}
        self.assertEqual(counts[ObservableCounterKind.OBSERVABLE_DECODE_TRIAL], 2)

    def test_zero_trial_is_missing_not_zero_ratio(self) -> None:
        summary = ReceiverMeasurementLedger().summarize(50_000)
        frame = ObservationAdapter().build(summary, 60_000)
        self.assertIn(MissingReasonCode.ZERO_DECODE_TRIAL, frame.missing_reasons)

    def test_authenticated_handover_retains_unknown_then_departure_removes(self) -> None:
        ledger = ReceiverMeasurementLedger()
        ledger.ingest(_identity("in", "vehicle_8", 50_000, ReceiverObservableKind.AUTHENTICATED_HANDOVER))
        summary = ledger.summarize(1_100_000)
        self.assertEqual(summary.known_vehicle_count, 1)
        self.assertEqual(summary.unknown_count, 1)
        ledger.ingest(_identity("out", "vehicle_8", 1_150_000, ReceiverObservableKind.AUTHENTICATED_DEPARTURE))
        self.assertEqual(ledger.summarize(1_200_000).known_vehicle_count, 0)

    def test_summary_hash_covers_observed_time_and_stale_summary_hides_payload(self) -> None:
        ledger = ReceiverMeasurementLedger()
        ledger.ingest(_packet("rx", "vehicle_0", 100_000, 90_000))
        summary = ledger.summarize(150_000)
        fresh = ObservationAdapter().build(summary, 160_000)
        stale = ObservationAdapter().build(summary, 300_001)
        self.assertNotEqual(fresh.counters, ())
        self.assertEqual(stale.counters, ())
        self.assertEqual(stale.missing_reasons, (MissingReasonCode.SUMMARY_STALE,))
        self.assertTrue(fresh.observed_user_ages)
        self.assertFalse(_has_truth_field(fresh))

    def test_event_ids_are_unique_across_all_ledger_payload_types(self) -> None:
        ledger = ReceiverMeasurementLedger()
        packet = _packet("shared", "vehicle_0", 100_000, 90_000)
        ledger.ingest(packet)
        ledger.ingest(packet)  # An identical retry is idempotent.
        with self.assertRaisesRegex(ValueError, "across receiver ledger"):
            ledger.ingest(_attempt("shared", 100_000, True))
        self.assertEqual(ledger.snapshot().packet_observations, (packet,))

    def test_ledger_snapshot_rejects_cross_type_ids_and_retired_schema(self) -> None:
        packet = _packet("shared", "vehicle_0", 100_000, 90_000)
        attempt = _attempt("shared", 100_000, True)
        with self.assertRaisesRegex(ValueError, "globally unique"):
            LedgerSnapshot(
                schema_version=LEDGER_SNAPSHOT_SCHEMA_VERSION,
                packet_observations=(packet,),
                attempt_observations=(attempt,),
                identity_events=(),
            )
        with self.assertRaisesRegex(ValueError, "unsupported ledger-snapshot"):
            LedgerSnapshot(
                schema_version="exp09-ledger-snapshot-v1",
                packet_observations=(),
                attempt_observations=(),
                identity_events=(),
            )

    def test_summary_receiver_rejects_duplicate_and_reordered_delivery(self) -> None:
        ledger = ReceiverMeasurementLedger()
        first = deliver_summary(ledger.summarize(100_000))
        second = deliver_summary(ledger.summarize(150_000))
        receiver = SummaryDeliveryReceiver()
        receiver.receive(second)
        with self.assertRaisesRegex(ValueError, "duplicate"):
            receiver.receive(second)
        with self.assertRaisesRegex(ValueError, "out-of-order"):
            receiver.receive(first)

    def test_summary_receiver_rejects_same_sequence_with_changed_payload(self) -> None:
        ledger = ReceiverMeasurementLedger()
        original = deliver_summary(ledger.summarize(100_000))
        receiver = SummaryDeliveryReceiver()
        receiver.receive(original)
        ledger.ingest(_packet("late-ingest", "vehicle_0", 100_000, 90_000))
        changed = deliver_summary(ledger.summarize(100_000))
        with self.assertRaisesRegex(ValueError, "duplicate"):
            receiver.receive(changed)

    def test_over_age_receiver_frame_hides_all_summary_payload(self) -> None:
        ledger = ReceiverMeasurementLedger()
        ledger.ingest(_packet("rx", "vehicle_0", 100_000, 90_000))
        summary = ledger.summarize(150_000)
        delivery = DeliveredSummary(
            schema_version=DELIVERED_SUMMARY_SCHEMA_VERSION,
            summary=summary,
            received_at_vehicle_us=250_001,
        )
        frame = SummaryDeliveryReceiver().receive(delivery)
        self.assertEqual(frame.counters, ())
        self.assertEqual(frame.observed_user_ages, ())
        self.assertEqual(frame.observed_users, ())
        self.assertEqual(frame.removals, ())
        self.assertEqual(frame.missing_reasons, (MissingReasonCode.SUMMARY_STALE,))

    def test_dropout_uses_generated_time_and_changes_only_assistance_delivery(self) -> None:
        ledger = ReceiverMeasurementLedger()
        ledger.ingest(_packet("past", "vehicle_0", 100_000, 90_000))
        before_snapshot = ledger.snapshot()
        summaries = tuple(ledger.summarize(time_us) for time_us in (100_000, 550_000, 600_000))
        transported = tuple(
            transport_summary(summary, dropout_anchor_us=100_000)
            for summary in summaries
        )
        self.assertEqual(transported[:2], (None, None))
        self.assertIsNotNone(transported[2])
        self.assertEqual(ledger.snapshot(), before_snapshot)
        self.assertEqual(
            summaries,
            tuple(ledger.summarize(time_us) for time_us in (100_000, 550_000, 600_000)),
        )

    def test_summary_prefix_is_invariant_to_future_observations(self) -> None:
        ledger = ReceiverMeasurementLedger()
        ledger.ingest(_packet("past", "vehicle_0", 100_000, 90_000))
        before = ledger.summarize(150_000)
        ledger.ingest(_packet("future", "vehicle_1", 200_000, 190_000))
        self.assertEqual(ledger.summarize(150_000), before)

    def test_summary_dto_rejects_cross_field_and_causal_inconsistency(self) -> None:
        ledger = ReceiverMeasurementLedger()
        ledger.ingest(_packet("rx", "vehicle_0", 100_000, 90_000))
        summary = ledger.summarize(150_000)
        invalid_changes = (
            {"known_vehicle_count": 99},
            {"decoded_success_count": 1, "decode_trial_count": 0},
            {
                "busy_sensing_slot_count": summary.eligible_sensing_slot_count + 1,
            },
            {"last_observed_at_by_vehicle": (("vehicle_0", 150_001),)},
            {"removed_vehicle_ids": ("vehicle_0",)},
        )
        for changes in invalid_changes:
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                replace(summary, **changes)


def _packet(event_id, vehicle_id, observed_at_us, generation_us):
    return ReceiverPacketObservation(
        RECEIVER_PACKET_OBSERVATION_SCHEMA_VERSION,
        EventId(event_id),
        VehicleId(vehicle_id),
        SimTimeUs(observed_at_us),
        SimTimeUs(generation_us),
    )


def _attempt(event_id, observed_at_us, decoded, vehicle_id="vehicle_0"):
    return ReceiverAttemptObservation(
        RECEIVER_ATTEMPT_OBSERVATION_SCHEMA_VERSION,
        EventId(event_id),
        VehicleId(vehicle_id),
        SimTimeUs(observed_at_us),
        decoded,
        SimTimeUs(observed_at_us),
    )


def _identity(event_id, vehicle_id, observed_at_us, kind):
    return ReceiverIdentityEvent(
        RECEIVER_IDENTITY_EVENT_SCHEMA_VERSION,
        EventId(event_id),
        VehicleId(vehicle_id),
        SimTimeUs(observed_at_us),
        kind,
        None,
        None,
    )


def _has_truth_field(value) -> bool:
    return bool(
        {field.name for field in dataclasses.fields(value)}
        & {"true_active_set", "shock_label", "future_tape", "plant_parameters"}
    )


if __name__ == "__main__":
    unittest.main()
