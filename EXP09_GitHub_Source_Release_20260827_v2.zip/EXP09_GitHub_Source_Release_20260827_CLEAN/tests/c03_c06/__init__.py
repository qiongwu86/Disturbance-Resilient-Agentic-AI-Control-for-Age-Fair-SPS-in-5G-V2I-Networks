"""C03-C06 regression tests."""
